<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-12 00:39:22 --> Config Class Initialized
INFO - 2016-12-12 00:39:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:39:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:39:22 --> Utf8 Class Initialized
INFO - 2016-12-12 00:39:22 --> URI Class Initialized
INFO - 2016-12-12 00:39:22 --> Router Class Initialized
INFO - 2016-12-12 00:39:22 --> Output Class Initialized
INFO - 2016-12-12 00:39:22 --> Security Class Initialized
DEBUG - 2016-12-12 00:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:39:22 --> Input Class Initialized
INFO - 2016-12-12 00:39:22 --> Language Class Initialized
INFO - 2016-12-12 00:39:22 --> Loader Class Initialized
INFO - 2016-12-12 00:39:22 --> Database Driver Class Initialized
INFO - 2016-12-12 00:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:39:22 --> Controller Class Initialized
INFO - 2016-12-12 00:39:22 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:39:22 --> Email Class Initialized
INFO - 2016-12-12 00:39:22 --> Final output sent to browser
DEBUG - 2016-12-12 00:39:22 --> Total execution time: 0.1055
INFO - 2016-12-12 00:42:12 --> Config Class Initialized
INFO - 2016-12-12 00:42:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:42:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:42:12 --> Utf8 Class Initialized
INFO - 2016-12-12 00:42:12 --> URI Class Initialized
INFO - 2016-12-12 00:42:12 --> Router Class Initialized
INFO - 2016-12-12 00:42:12 --> Config Class Initialized
INFO - 2016-12-12 00:42:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:42:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:42:12 --> Utf8 Class Initialized
INFO - 2016-12-12 00:42:12 --> URI Class Initialized
INFO - 2016-12-12 00:42:12 --> Router Class Initialized
INFO - 2016-12-12 00:42:12 --> Output Class Initialized
INFO - 2016-12-12 00:42:12 --> Output Class Initialized
INFO - 2016-12-12 00:42:12 --> Security Class Initialized
INFO - 2016-12-12 00:42:12 --> Security Class Initialized
DEBUG - 2016-12-12 00:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:42:12 --> Input Class Initialized
INFO - 2016-12-12 00:42:12 --> Language Class Initialized
DEBUG - 2016-12-12 00:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:42:12 --> Input Class Initialized
INFO - 2016-12-12 00:42:12 --> Language Class Initialized
INFO - 2016-12-12 00:42:12 --> Loader Class Initialized
INFO - 2016-12-12 00:42:12 --> Loader Class Initialized
INFO - 2016-12-12 00:42:12 --> Database Driver Class Initialized
INFO - 2016-12-12 00:42:12 --> Database Driver Class Initialized
INFO - 2016-12-12 00:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:42:12 --> Controller Class Initialized
INFO - 2016-12-12 00:42:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:42:12 --> Email Class Initialized
INFO - 2016-12-12 00:42:12 --> Final output sent to browser
DEBUG - 2016-12-12 00:42:12 --> Total execution time: 0.2870
INFO - 2016-12-12 00:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:42:12 --> Controller Class Initialized
INFO - 2016-12-12 00:42:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:42:12 --> Email Class Initialized
INFO - 2016-12-12 00:42:12 --> Final output sent to browser
DEBUG - 2016-12-12 00:42:12 --> Total execution time: 0.3697
INFO - 2016-12-12 00:45:49 --> Config Class Initialized
INFO - 2016-12-12 00:45:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:45:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:45:49 --> Utf8 Class Initialized
INFO - 2016-12-12 00:45:49 --> URI Class Initialized
DEBUG - 2016-12-12 00:45:49 --> No URI present. Default controller set.
INFO - 2016-12-12 00:45:49 --> Router Class Initialized
INFO - 2016-12-12 00:45:49 --> Output Class Initialized
INFO - 2016-12-12 00:45:49 --> Security Class Initialized
DEBUG - 2016-12-12 00:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:45:49 --> Input Class Initialized
INFO - 2016-12-12 00:45:49 --> Language Class Initialized
INFO - 2016-12-12 00:45:49 --> Loader Class Initialized
INFO - 2016-12-12 00:45:49 --> Database Driver Class Initialized
INFO - 2016-12-12 00:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:45:49 --> Controller Class Initialized
INFO - 2016-12-12 00:45:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:45:49 --> Email Class Initialized
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:45:49 --> Final output sent to browser
DEBUG - 2016-12-12 00:45:49 --> Total execution time: 0.0439
INFO - 2016-12-12 00:45:49 --> Config Class Initialized
INFO - 2016-12-12 00:45:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:45:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:45:49 --> Utf8 Class Initialized
INFO - 2016-12-12 00:45:49 --> URI Class Initialized
INFO - 2016-12-12 00:45:49 --> Router Class Initialized
INFO - 2016-12-12 00:45:49 --> Output Class Initialized
INFO - 2016-12-12 00:45:49 --> Security Class Initialized
DEBUG - 2016-12-12 00:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:45:49 --> Input Class Initialized
INFO - 2016-12-12 00:45:49 --> Language Class Initialized
INFO - 2016-12-12 00:45:49 --> Loader Class Initialized
INFO - 2016-12-12 00:45:49 --> Database Driver Class Initialized
INFO - 2016-12-12 00:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:45:49 --> Controller Class Initialized
INFO - 2016-12-12 00:45:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:45:49 --> Email Class Initialized
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:45:49 --> Final output sent to browser
DEBUG - 2016-12-12 00:45:49 --> Total execution time: 0.0149
INFO - 2016-12-12 00:46:23 --> Config Class Initialized
INFO - 2016-12-12 00:46:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:46:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:46:23 --> Utf8 Class Initialized
INFO - 2016-12-12 00:46:23 --> URI Class Initialized
DEBUG - 2016-12-12 00:46:23 --> No URI present. Default controller set.
INFO - 2016-12-12 00:46:23 --> Router Class Initialized
INFO - 2016-12-12 00:46:23 --> Output Class Initialized
INFO - 2016-12-12 00:46:23 --> Security Class Initialized
DEBUG - 2016-12-12 00:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:46:23 --> Input Class Initialized
INFO - 2016-12-12 00:46:23 --> Language Class Initialized
INFO - 2016-12-12 00:46:23 --> Loader Class Initialized
INFO - 2016-12-12 00:46:23 --> Database Driver Class Initialized
INFO - 2016-12-12 00:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:46:23 --> Controller Class Initialized
INFO - 2016-12-12 00:46:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:46:23 --> Email Class Initialized
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:46:23 --> Final output sent to browser
DEBUG - 2016-12-12 00:46:23 --> Total execution time: 0.0153
INFO - 2016-12-12 00:46:23 --> Config Class Initialized
INFO - 2016-12-12 00:46:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:46:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:46:23 --> Utf8 Class Initialized
INFO - 2016-12-12 00:46:23 --> URI Class Initialized
INFO - 2016-12-12 00:46:23 --> Router Class Initialized
INFO - 2016-12-12 00:46:23 --> Output Class Initialized
INFO - 2016-12-12 00:46:23 --> Security Class Initialized
DEBUG - 2016-12-12 00:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:46:23 --> Input Class Initialized
INFO - 2016-12-12 00:46:23 --> Language Class Initialized
INFO - 2016-12-12 00:46:23 --> Loader Class Initialized
INFO - 2016-12-12 00:46:23 --> Database Driver Class Initialized
INFO - 2016-12-12 00:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:46:23 --> Controller Class Initialized
INFO - 2016-12-12 00:46:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:46:23 --> Email Class Initialized
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:46:23 --> Final output sent to browser
DEBUG - 2016-12-12 00:46:23 --> Total execution time: 0.0151
INFO - 2016-12-12 00:47:14 --> Config Class Initialized
INFO - 2016-12-12 00:47:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:47:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:47:14 --> Utf8 Class Initialized
INFO - 2016-12-12 00:47:14 --> URI Class Initialized
INFO - 2016-12-12 00:47:14 --> Router Class Initialized
INFO - 2016-12-12 00:47:14 --> Output Class Initialized
INFO - 2016-12-12 00:47:14 --> Security Class Initialized
DEBUG - 2016-12-12 00:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:47:14 --> Input Class Initialized
INFO - 2016-12-12 00:47:14 --> Language Class Initialized
INFO - 2016-12-12 00:47:14 --> Loader Class Initialized
INFO - 2016-12-12 00:47:14 --> Database Driver Class Initialized
INFO - 2016-12-12 00:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:47:14 --> Controller Class Initialized
INFO - 2016-12-12 00:47:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:47:14 --> Email Class Initialized
INFO - 2016-12-12 00:47:14 --> Final output sent to browser
DEBUG - 2016-12-12 00:47:14 --> Total execution time: 0.0152
INFO - 2016-12-12 00:52:32 --> Config Class Initialized
INFO - 2016-12-12 00:52:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:52:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:52:32 --> Utf8 Class Initialized
INFO - 2016-12-12 00:52:32 --> URI Class Initialized
INFO - 2016-12-12 00:52:32 --> Router Class Initialized
INFO - 2016-12-12 00:52:32 --> Output Class Initialized
INFO - 2016-12-12 00:52:32 --> Security Class Initialized
DEBUG - 2016-12-12 00:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:52:32 --> Input Class Initialized
INFO - 2016-12-12 00:52:32 --> Language Class Initialized
INFO - 2016-12-12 00:52:32 --> Loader Class Initialized
INFO - 2016-12-12 00:52:32 --> Database Driver Class Initialized
INFO - 2016-12-12 00:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:52:33 --> Controller Class Initialized
INFO - 2016-12-12 00:52:33 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:52:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:52:33 --> Email Class Initialized
INFO - 2016-12-12 00:52:33 --> Final output sent to browser
DEBUG - 2016-12-12 00:52:33 --> Total execution time: 0.7693
INFO - 2016-12-12 00:58:23 --> Config Class Initialized
INFO - 2016-12-12 00:58:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:58:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:58:23 --> Utf8 Class Initialized
INFO - 2016-12-12 00:58:23 --> URI Class Initialized
DEBUG - 2016-12-12 00:58:23 --> No URI present. Default controller set.
INFO - 2016-12-12 00:58:23 --> Router Class Initialized
INFO - 2016-12-12 00:58:23 --> Output Class Initialized
INFO - 2016-12-12 00:58:23 --> Security Class Initialized
DEBUG - 2016-12-12 00:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:58:23 --> Input Class Initialized
INFO - 2016-12-12 00:58:23 --> Language Class Initialized
INFO - 2016-12-12 00:58:23 --> Loader Class Initialized
INFO - 2016-12-12 00:58:23 --> Database Driver Class Initialized
INFO - 2016-12-12 00:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:58:23 --> Controller Class Initialized
INFO - 2016-12-12 00:58:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:58:23 --> Email Class Initialized
INFO - 2016-12-12 00:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:58:23 --> Final output sent to browser
DEBUG - 2016-12-12 00:58:23 --> Total execution time: 0.0143
INFO - 2016-12-12 00:58:24 --> Config Class Initialized
INFO - 2016-12-12 00:58:24 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:58:24 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:58:24 --> Utf8 Class Initialized
INFO - 2016-12-12 00:58:24 --> URI Class Initialized
INFO - 2016-12-12 00:58:24 --> Router Class Initialized
INFO - 2016-12-12 00:58:24 --> Output Class Initialized
INFO - 2016-12-12 00:58:24 --> Security Class Initialized
DEBUG - 2016-12-12 00:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:58:24 --> Input Class Initialized
INFO - 2016-12-12 00:58:24 --> Language Class Initialized
INFO - 2016-12-12 00:58:24 --> Loader Class Initialized
INFO - 2016-12-12 00:58:24 --> Database Driver Class Initialized
INFO - 2016-12-12 00:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:58:24 --> Controller Class Initialized
INFO - 2016-12-12 00:58:24 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:58:24 --> Email Class Initialized
INFO - 2016-12-12 00:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:58:24 --> Final output sent to browser
DEBUG - 2016-12-12 00:58:24 --> Total execution time: 0.0142
INFO - 2016-12-12 00:58:30 --> Config Class Initialized
INFO - 2016-12-12 00:58:30 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:58:30 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:58:30 --> Utf8 Class Initialized
INFO - 2016-12-12 00:58:30 --> URI Class Initialized
INFO - 2016-12-12 00:58:30 --> Router Class Initialized
INFO - 2016-12-12 00:58:30 --> Output Class Initialized
INFO - 2016-12-12 00:58:30 --> Security Class Initialized
DEBUG - 2016-12-12 00:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:58:30 --> Input Class Initialized
INFO - 2016-12-12 00:58:30 --> Language Class Initialized
INFO - 2016-12-12 00:58:30 --> Loader Class Initialized
INFO - 2016-12-12 00:58:30 --> Database Driver Class Initialized
INFO - 2016-12-12 00:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:58:30 --> Controller Class Initialized
INFO - 2016-12-12 00:58:30 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:58:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:58:30 --> Email Class Initialized
INFO - 2016-12-12 00:58:30 --> Final output sent to browser
DEBUG - 2016-12-12 00:58:30 --> Total execution time: 0.0139
INFO - 2016-12-12 00:59:13 --> Config Class Initialized
INFO - 2016-12-12 00:59:13 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:59:13 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:59:13 --> Utf8 Class Initialized
INFO - 2016-12-12 00:59:13 --> URI Class Initialized
DEBUG - 2016-12-12 00:59:13 --> No URI present. Default controller set.
INFO - 2016-12-12 00:59:13 --> Router Class Initialized
INFO - 2016-12-12 00:59:13 --> Output Class Initialized
INFO - 2016-12-12 00:59:13 --> Security Class Initialized
DEBUG - 2016-12-12 00:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:59:13 --> Input Class Initialized
INFO - 2016-12-12 00:59:13 --> Language Class Initialized
INFO - 2016-12-12 00:59:13 --> Loader Class Initialized
INFO - 2016-12-12 00:59:13 --> Database Driver Class Initialized
INFO - 2016-12-12 00:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:59:13 --> Controller Class Initialized
INFO - 2016-12-12 00:59:13 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:59:13 --> Email Class Initialized
INFO - 2016-12-12 00:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:59:13 --> Final output sent to browser
DEBUG - 2016-12-12 00:59:13 --> Total execution time: 0.0146
INFO - 2016-12-12 00:59:14 --> Config Class Initialized
INFO - 2016-12-12 00:59:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:59:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:59:14 --> Utf8 Class Initialized
INFO - 2016-12-12 00:59:14 --> URI Class Initialized
INFO - 2016-12-12 00:59:14 --> Router Class Initialized
INFO - 2016-12-12 00:59:14 --> Output Class Initialized
INFO - 2016-12-12 00:59:14 --> Security Class Initialized
DEBUG - 2016-12-12 00:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:59:14 --> Input Class Initialized
INFO - 2016-12-12 00:59:14 --> Language Class Initialized
INFO - 2016-12-12 00:59:14 --> Loader Class Initialized
INFO - 2016-12-12 00:59:14 --> Database Driver Class Initialized
INFO - 2016-12-12 00:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:59:14 --> Controller Class Initialized
INFO - 2016-12-12 00:59:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:59:14 --> Email Class Initialized
INFO - 2016-12-12 00:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:59:14 --> Final output sent to browser
DEBUG - 2016-12-12 00:59:14 --> Total execution time: 0.0160
INFO - 2016-12-12 00:59:19 --> Config Class Initialized
INFO - 2016-12-12 00:59:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:59:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:59:19 --> Utf8 Class Initialized
INFO - 2016-12-12 00:59:19 --> URI Class Initialized
INFO - 2016-12-12 00:59:19 --> Router Class Initialized
INFO - 2016-12-12 00:59:19 --> Output Class Initialized
INFO - 2016-12-12 00:59:19 --> Security Class Initialized
DEBUG - 2016-12-12 00:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:59:19 --> Input Class Initialized
INFO - 2016-12-12 00:59:19 --> Language Class Initialized
INFO - 2016-12-12 00:59:19 --> Loader Class Initialized
INFO - 2016-12-12 00:59:19 --> Database Driver Class Initialized
INFO - 2016-12-12 00:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:59:19 --> Controller Class Initialized
INFO - 2016-12-12 00:59:19 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:59:19 --> Email Class Initialized
INFO - 2016-12-12 00:59:19 --> Final output sent to browser
DEBUG - 2016-12-12 00:59:19 --> Total execution time: 0.0140
INFO - 2016-12-12 00:59:39 --> Config Class Initialized
INFO - 2016-12-12 00:59:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:59:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:59:39 --> Utf8 Class Initialized
INFO - 2016-12-12 00:59:39 --> URI Class Initialized
DEBUG - 2016-12-12 00:59:39 --> No URI present. Default controller set.
INFO - 2016-12-12 00:59:39 --> Router Class Initialized
INFO - 2016-12-12 00:59:39 --> Output Class Initialized
INFO - 2016-12-12 00:59:39 --> Security Class Initialized
DEBUG - 2016-12-12 00:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:59:39 --> Input Class Initialized
INFO - 2016-12-12 00:59:39 --> Language Class Initialized
INFO - 2016-12-12 00:59:39 --> Loader Class Initialized
INFO - 2016-12-12 00:59:39 --> Database Driver Class Initialized
INFO - 2016-12-12 00:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:59:39 --> Controller Class Initialized
INFO - 2016-12-12 00:59:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:59:39 --> Email Class Initialized
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:59:39 --> Final output sent to browser
DEBUG - 2016-12-12 00:59:39 --> Total execution time: 0.0150
INFO - 2016-12-12 00:59:39 --> Config Class Initialized
INFO - 2016-12-12 00:59:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:59:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:59:39 --> Utf8 Class Initialized
INFO - 2016-12-12 00:59:39 --> URI Class Initialized
INFO - 2016-12-12 00:59:39 --> Router Class Initialized
INFO - 2016-12-12 00:59:39 --> Output Class Initialized
INFO - 2016-12-12 00:59:39 --> Security Class Initialized
DEBUG - 2016-12-12 00:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:59:39 --> Input Class Initialized
INFO - 2016-12-12 00:59:39 --> Language Class Initialized
INFO - 2016-12-12 00:59:39 --> Loader Class Initialized
INFO - 2016-12-12 00:59:39 --> Database Driver Class Initialized
INFO - 2016-12-12 00:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:59:39 --> Controller Class Initialized
INFO - 2016-12-12 00:59:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:59:39 --> Email Class Initialized
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:59:39 --> Final output sent to browser
DEBUG - 2016-12-12 00:59:39 --> Total execution time: 0.0149
INFO - 2016-12-12 00:59:46 --> Config Class Initialized
INFO - 2016-12-12 00:59:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:59:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:59:46 --> Utf8 Class Initialized
INFO - 2016-12-12 00:59:46 --> URI Class Initialized
INFO - 2016-12-12 00:59:46 --> Router Class Initialized
INFO - 2016-12-12 00:59:46 --> Output Class Initialized
INFO - 2016-12-12 00:59:46 --> Security Class Initialized
DEBUG - 2016-12-12 00:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:59:46 --> Input Class Initialized
INFO - 2016-12-12 00:59:46 --> Language Class Initialized
INFO - 2016-12-12 00:59:46 --> Loader Class Initialized
INFO - 2016-12-12 00:59:46 --> Database Driver Class Initialized
INFO - 2016-12-12 00:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:59:46 --> Controller Class Initialized
INFO - 2016-12-12 00:59:46 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:59:46 --> Email Class Initialized
INFO - 2016-12-12 00:59:46 --> Final output sent to browser
DEBUG - 2016-12-12 00:59:46 --> Total execution time: 0.0152
INFO - 2016-12-12 00:59:56 --> Config Class Initialized
INFO - 2016-12-12 00:59:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 00:59:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 00:59:56 --> Utf8 Class Initialized
INFO - 2016-12-12 00:59:56 --> URI Class Initialized
DEBUG - 2016-12-12 00:59:56 --> No URI present. Default controller set.
INFO - 2016-12-12 00:59:56 --> Router Class Initialized
INFO - 2016-12-12 00:59:56 --> Output Class Initialized
INFO - 2016-12-12 00:59:56 --> Security Class Initialized
DEBUG - 2016-12-12 00:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 00:59:56 --> Input Class Initialized
INFO - 2016-12-12 00:59:56 --> Language Class Initialized
INFO - 2016-12-12 00:59:56 --> Loader Class Initialized
INFO - 2016-12-12 00:59:56 --> Database Driver Class Initialized
INFO - 2016-12-12 00:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 00:59:56 --> Controller Class Initialized
INFO - 2016-12-12 00:59:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 00:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 00:59:56 --> Email Class Initialized
INFO - 2016-12-12 00:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 00:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 00:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 00:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 00:59:56 --> Final output sent to browser
DEBUG - 2016-12-12 00:59:56 --> Total execution time: 0.0144
INFO - 2016-12-12 01:00:34 --> Config Class Initialized
INFO - 2016-12-12 01:00:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:00:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:00:34 --> Utf8 Class Initialized
INFO - 2016-12-12 01:00:34 --> URI Class Initialized
INFO - 2016-12-12 01:00:34 --> Router Class Initialized
INFO - 2016-12-12 01:00:34 --> Output Class Initialized
INFO - 2016-12-12 01:00:34 --> Security Class Initialized
DEBUG - 2016-12-12 01:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:00:34 --> Input Class Initialized
INFO - 2016-12-12 01:00:34 --> Language Class Initialized
INFO - 2016-12-12 01:00:34 --> Loader Class Initialized
INFO - 2016-12-12 01:00:34 --> Database Driver Class Initialized
INFO - 2016-12-12 01:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:00:34 --> Controller Class Initialized
INFO - 2016-12-12 01:00:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:00:34 --> Email Class Initialized
INFO - 2016-12-12 01:00:34 --> Final output sent to browser
DEBUG - 2016-12-12 01:00:34 --> Total execution time: 0.1053
INFO - 2016-12-12 01:00:51 --> Config Class Initialized
INFO - 2016-12-12 01:00:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:00:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:00:51 --> Utf8 Class Initialized
INFO - 2016-12-12 01:00:51 --> URI Class Initialized
INFO - 2016-12-12 01:00:51 --> Router Class Initialized
INFO - 2016-12-12 01:00:51 --> Output Class Initialized
INFO - 2016-12-12 01:00:51 --> Security Class Initialized
DEBUG - 2016-12-12 01:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:00:51 --> Input Class Initialized
INFO - 2016-12-12 01:00:51 --> Language Class Initialized
INFO - 2016-12-12 01:00:51 --> Loader Class Initialized
INFO - 2016-12-12 01:00:51 --> Database Driver Class Initialized
INFO - 2016-12-12 01:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:00:51 --> Controller Class Initialized
INFO - 2016-12-12 01:00:51 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:00:51 --> Email Class Initialized
INFO - 2016-12-12 01:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:00:51 --> Final output sent to browser
DEBUG - 2016-12-12 01:00:51 --> Total execution time: 0.0239
INFO - 2016-12-12 01:01:26 --> Config Class Initialized
INFO - 2016-12-12 01:01:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:01:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:01:26 --> Utf8 Class Initialized
INFO - 2016-12-12 01:01:26 --> URI Class Initialized
DEBUG - 2016-12-12 01:01:26 --> No URI present. Default controller set.
INFO - 2016-12-12 01:01:26 --> Router Class Initialized
INFO - 2016-12-12 01:01:26 --> Output Class Initialized
INFO - 2016-12-12 01:01:26 --> Security Class Initialized
DEBUG - 2016-12-12 01:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:01:26 --> Input Class Initialized
INFO - 2016-12-12 01:01:26 --> Language Class Initialized
INFO - 2016-12-12 01:01:26 --> Loader Class Initialized
INFO - 2016-12-12 01:01:26 --> Database Driver Class Initialized
INFO - 2016-12-12 01:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:01:26 --> Controller Class Initialized
INFO - 2016-12-12 01:01:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:01:26 --> Email Class Initialized
INFO - 2016-12-12 01:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:01:26 --> Final output sent to browser
DEBUG - 2016-12-12 01:01:26 --> Total execution time: 0.2490
INFO - 2016-12-12 01:01:41 --> Config Class Initialized
INFO - 2016-12-12 01:01:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:01:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:01:41 --> Utf8 Class Initialized
INFO - 2016-12-12 01:01:41 --> URI Class Initialized
DEBUG - 2016-12-12 01:01:41 --> No URI present. Default controller set.
INFO - 2016-12-12 01:01:41 --> Router Class Initialized
INFO - 2016-12-12 01:01:41 --> Output Class Initialized
INFO - 2016-12-12 01:01:41 --> Security Class Initialized
DEBUG - 2016-12-12 01:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:01:41 --> Input Class Initialized
INFO - 2016-12-12 01:01:41 --> Language Class Initialized
INFO - 2016-12-12 01:01:41 --> Loader Class Initialized
INFO - 2016-12-12 01:01:41 --> Database Driver Class Initialized
INFO - 2016-12-12 01:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:01:41 --> Controller Class Initialized
INFO - 2016-12-12 01:01:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:01:41 --> Email Class Initialized
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:01:41 --> Final output sent to browser
DEBUG - 2016-12-12 01:01:41 --> Total execution time: 0.0145
INFO - 2016-12-12 01:01:41 --> Config Class Initialized
INFO - 2016-12-12 01:01:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:01:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:01:41 --> Utf8 Class Initialized
INFO - 2016-12-12 01:01:41 --> URI Class Initialized
INFO - 2016-12-12 01:01:41 --> Router Class Initialized
INFO - 2016-12-12 01:01:41 --> Output Class Initialized
INFO - 2016-12-12 01:01:41 --> Security Class Initialized
DEBUG - 2016-12-12 01:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:01:41 --> Input Class Initialized
INFO - 2016-12-12 01:01:41 --> Language Class Initialized
INFO - 2016-12-12 01:01:41 --> Loader Class Initialized
INFO - 2016-12-12 01:01:41 --> Database Driver Class Initialized
INFO - 2016-12-12 01:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:01:41 --> Controller Class Initialized
INFO - 2016-12-12 01:01:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:01:41 --> Email Class Initialized
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:01:41 --> Final output sent to browser
DEBUG - 2016-12-12 01:01:41 --> Total execution time: 0.0141
INFO - 2016-12-12 01:01:49 --> Config Class Initialized
INFO - 2016-12-12 01:01:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:01:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:01:49 --> Utf8 Class Initialized
INFO - 2016-12-12 01:01:49 --> URI Class Initialized
INFO - 2016-12-12 01:01:49 --> Router Class Initialized
INFO - 2016-12-12 01:01:49 --> Output Class Initialized
INFO - 2016-12-12 01:01:49 --> Security Class Initialized
DEBUG - 2016-12-12 01:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:01:49 --> Input Class Initialized
INFO - 2016-12-12 01:01:49 --> Language Class Initialized
INFO - 2016-12-12 01:01:49 --> Loader Class Initialized
INFO - 2016-12-12 01:01:49 --> Database Driver Class Initialized
INFO - 2016-12-12 01:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:01:49 --> Controller Class Initialized
INFO - 2016-12-12 01:01:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:01:49 --> Email Class Initialized
INFO - 2016-12-12 01:01:49 --> Final output sent to browser
DEBUG - 2016-12-12 01:01:49 --> Total execution time: 0.0140
INFO - 2016-12-12 01:04:36 --> Config Class Initialized
INFO - 2016-12-12 01:04:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:04:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:04:36 --> Utf8 Class Initialized
INFO - 2016-12-12 01:04:36 --> URI Class Initialized
DEBUG - 2016-12-12 01:04:36 --> No URI present. Default controller set.
INFO - 2016-12-12 01:04:36 --> Router Class Initialized
INFO - 2016-12-12 01:04:36 --> Output Class Initialized
INFO - 2016-12-12 01:04:36 --> Security Class Initialized
DEBUG - 2016-12-12 01:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:04:36 --> Input Class Initialized
INFO - 2016-12-12 01:04:36 --> Language Class Initialized
INFO - 2016-12-12 01:04:36 --> Loader Class Initialized
INFO - 2016-12-12 01:04:36 --> Database Driver Class Initialized
INFO - 2016-12-12 01:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:04:36 --> Controller Class Initialized
INFO - 2016-12-12 01:04:36 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:04:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:04:37 --> Final output sent to browser
DEBUG - 2016-12-12 01:04:37 --> Total execution time: 0.7956
INFO - 2016-12-12 01:04:37 --> Config Class Initialized
INFO - 2016-12-12 01:04:37 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:04:37 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:04:37 --> Utf8 Class Initialized
INFO - 2016-12-12 01:04:37 --> URI Class Initialized
INFO - 2016-12-12 01:04:37 --> Router Class Initialized
INFO - 2016-12-12 01:04:37 --> Output Class Initialized
INFO - 2016-12-12 01:04:37 --> Security Class Initialized
DEBUG - 2016-12-12 01:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:04:37 --> Input Class Initialized
INFO - 2016-12-12 01:04:37 --> Language Class Initialized
INFO - 2016-12-12 01:04:37 --> Loader Class Initialized
INFO - 2016-12-12 01:04:37 --> Database Driver Class Initialized
INFO - 2016-12-12 01:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:04:37 --> Controller Class Initialized
INFO - 2016-12-12 01:04:37 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:04:37 --> Final output sent to browser
DEBUG - 2016-12-12 01:04:37 --> Total execution time: 0.0134
INFO - 2016-12-12 01:04:47 --> Config Class Initialized
INFO - 2016-12-12 01:04:47 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:04:47 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:04:47 --> Utf8 Class Initialized
INFO - 2016-12-12 01:04:47 --> URI Class Initialized
DEBUG - 2016-12-12 01:04:47 --> No URI present. Default controller set.
INFO - 2016-12-12 01:04:47 --> Router Class Initialized
INFO - 2016-12-12 01:04:47 --> Output Class Initialized
INFO - 2016-12-12 01:04:47 --> Security Class Initialized
DEBUG - 2016-12-12 01:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:04:47 --> Input Class Initialized
INFO - 2016-12-12 01:04:47 --> Language Class Initialized
INFO - 2016-12-12 01:04:47 --> Loader Class Initialized
INFO - 2016-12-12 01:04:47 --> Database Driver Class Initialized
INFO - 2016-12-12 01:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:04:47 --> Controller Class Initialized
INFO - 2016-12-12 01:04:47 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:04:47 --> Final output sent to browser
DEBUG - 2016-12-12 01:04:47 --> Total execution time: 0.0300
INFO - 2016-12-12 01:05:00 --> Config Class Initialized
INFO - 2016-12-12 01:05:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:05:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:05:00 --> Utf8 Class Initialized
INFO - 2016-12-12 01:05:00 --> URI Class Initialized
INFO - 2016-12-12 01:05:00 --> Router Class Initialized
INFO - 2016-12-12 01:05:00 --> Output Class Initialized
INFO - 2016-12-12 01:05:00 --> Security Class Initialized
DEBUG - 2016-12-12 01:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:05:00 --> Input Class Initialized
INFO - 2016-12-12 01:05:00 --> Language Class Initialized
INFO - 2016-12-12 01:05:00 --> Loader Class Initialized
INFO - 2016-12-12 01:05:00 --> Database Driver Class Initialized
INFO - 2016-12-12 01:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:05:00 --> Controller Class Initialized
INFO - 2016-12-12 01:05:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:05:00 --> Final output sent to browser
DEBUG - 2016-12-12 01:05:00 --> Total execution time: 0.0125
INFO - 2016-12-12 01:05:31 --> Config Class Initialized
INFO - 2016-12-12 01:05:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:05:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:05:31 --> Utf8 Class Initialized
INFO - 2016-12-12 01:05:31 --> URI Class Initialized
INFO - 2016-12-12 01:05:31 --> Router Class Initialized
INFO - 2016-12-12 01:05:31 --> Output Class Initialized
INFO - 2016-12-12 01:05:31 --> Security Class Initialized
DEBUG - 2016-12-12 01:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:05:31 --> Input Class Initialized
INFO - 2016-12-12 01:05:31 --> Language Class Initialized
INFO - 2016-12-12 01:05:31 --> Loader Class Initialized
INFO - 2016-12-12 01:05:31 --> Database Driver Class Initialized
INFO - 2016-12-12 01:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:05:31 --> Controller Class Initialized
INFO - 2016-12-12 01:05:31 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:05:31 --> Final output sent to browser
DEBUG - 2016-12-12 01:05:31 --> Total execution time: 0.0136
INFO - 2016-12-12 01:10:41 --> Config Class Initialized
INFO - 2016-12-12 01:10:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:10:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:10:41 --> Utf8 Class Initialized
INFO - 2016-12-12 01:10:41 --> URI Class Initialized
INFO - 2016-12-12 01:10:41 --> Router Class Initialized
INFO - 2016-12-12 01:10:41 --> Output Class Initialized
INFO - 2016-12-12 01:10:41 --> Security Class Initialized
DEBUG - 2016-12-12 01:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:10:41 --> Input Class Initialized
INFO - 2016-12-12 01:10:41 --> Language Class Initialized
INFO - 2016-12-12 01:10:41 --> Loader Class Initialized
INFO - 2016-12-12 01:10:41 --> Database Driver Class Initialized
INFO - 2016-12-12 01:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:10:41 --> Controller Class Initialized
INFO - 2016-12-12 01:10:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:10:41 --> Final output sent to browser
DEBUG - 2016-12-12 01:10:41 --> Total execution time: 0.0208
INFO - 2016-12-12 01:11:09 --> Config Class Initialized
INFO - 2016-12-12 01:11:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:11:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:11:09 --> Utf8 Class Initialized
INFO - 2016-12-12 01:11:09 --> URI Class Initialized
DEBUG - 2016-12-12 01:11:09 --> No URI present. Default controller set.
INFO - 2016-12-12 01:11:09 --> Router Class Initialized
INFO - 2016-12-12 01:11:09 --> Output Class Initialized
INFO - 2016-12-12 01:11:09 --> Security Class Initialized
DEBUG - 2016-12-12 01:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:11:09 --> Input Class Initialized
INFO - 2016-12-12 01:11:09 --> Language Class Initialized
INFO - 2016-12-12 01:11:09 --> Loader Class Initialized
INFO - 2016-12-12 01:11:09 --> Database Driver Class Initialized
INFO - 2016-12-12 01:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:11:09 --> Controller Class Initialized
INFO - 2016-12-12 01:11:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:11:09 --> Final output sent to browser
DEBUG - 2016-12-12 01:11:09 --> Total execution time: 0.0143
INFO - 2016-12-12 01:11:50 --> Config Class Initialized
INFO - 2016-12-12 01:11:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:11:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:11:50 --> Utf8 Class Initialized
INFO - 2016-12-12 01:11:50 --> URI Class Initialized
INFO - 2016-12-12 01:11:50 --> Router Class Initialized
INFO - 2016-12-12 01:11:50 --> Output Class Initialized
INFO - 2016-12-12 01:11:50 --> Security Class Initialized
DEBUG - 2016-12-12 01:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:11:50 --> Input Class Initialized
INFO - 2016-12-12 01:11:50 --> Language Class Initialized
INFO - 2016-12-12 01:11:50 --> Loader Class Initialized
INFO - 2016-12-12 01:11:50 --> Database Driver Class Initialized
INFO - 2016-12-12 01:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:11:50 --> Controller Class Initialized
INFO - 2016-12-12 01:11:50 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:11:50 --> Final output sent to browser
DEBUG - 2016-12-12 01:11:50 --> Total execution time: 0.0127
INFO - 2016-12-12 01:12:07 --> Config Class Initialized
INFO - 2016-12-12 01:12:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:12:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:12:07 --> Utf8 Class Initialized
INFO - 2016-12-12 01:12:07 --> URI Class Initialized
INFO - 2016-12-12 01:12:07 --> Router Class Initialized
INFO - 2016-12-12 01:12:07 --> Output Class Initialized
INFO - 2016-12-12 01:12:07 --> Security Class Initialized
DEBUG - 2016-12-12 01:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:12:07 --> Input Class Initialized
INFO - 2016-12-12 01:12:07 --> Language Class Initialized
INFO - 2016-12-12 01:12:07 --> Loader Class Initialized
INFO - 2016-12-12 01:12:07 --> Database Driver Class Initialized
INFO - 2016-12-12 01:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:12:07 --> Controller Class Initialized
INFO - 2016-12-12 01:12:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:12:07 --> Final output sent to browser
DEBUG - 2016-12-12 01:12:07 --> Total execution time: 0.0131
INFO - 2016-12-12 01:12:27 --> Config Class Initialized
INFO - 2016-12-12 01:12:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:12:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:12:27 --> Utf8 Class Initialized
INFO - 2016-12-12 01:12:27 --> URI Class Initialized
INFO - 2016-12-12 01:12:27 --> Router Class Initialized
INFO - 2016-12-12 01:12:27 --> Output Class Initialized
INFO - 2016-12-12 01:12:27 --> Security Class Initialized
DEBUG - 2016-12-12 01:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:12:27 --> Input Class Initialized
INFO - 2016-12-12 01:12:27 --> Language Class Initialized
INFO - 2016-12-12 01:12:27 --> Loader Class Initialized
INFO - 2016-12-12 01:12:27 --> Database Driver Class Initialized
INFO - 2016-12-12 01:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:12:27 --> Controller Class Initialized
INFO - 2016-12-12 01:12:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:12:27 --> Final output sent to browser
DEBUG - 2016-12-12 01:12:27 --> Total execution time: 0.0136
INFO - 2016-12-12 01:28:08 --> Config Class Initialized
INFO - 2016-12-12 01:28:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:28:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:28:08 --> Utf8 Class Initialized
INFO - 2016-12-12 01:28:08 --> URI Class Initialized
DEBUG - 2016-12-12 01:28:08 --> No URI present. Default controller set.
INFO - 2016-12-12 01:28:08 --> Router Class Initialized
INFO - 2016-12-12 01:28:08 --> Output Class Initialized
INFO - 2016-12-12 01:28:08 --> Security Class Initialized
DEBUG - 2016-12-12 01:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:28:08 --> Input Class Initialized
INFO - 2016-12-12 01:28:08 --> Language Class Initialized
INFO - 2016-12-12 01:28:08 --> Loader Class Initialized
INFO - 2016-12-12 01:28:08 --> Database Driver Class Initialized
INFO - 2016-12-12 01:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:28:08 --> Controller Class Initialized
INFO - 2016-12-12 01:28:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:28:08 --> Final output sent to browser
DEBUG - 2016-12-12 01:28:08 --> Total execution time: 0.7323
INFO - 2016-12-12 01:28:09 --> Config Class Initialized
INFO - 2016-12-12 01:28:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:28:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:28:09 --> Utf8 Class Initialized
INFO - 2016-12-12 01:28:09 --> URI Class Initialized
INFO - 2016-12-12 01:28:09 --> Router Class Initialized
INFO - 2016-12-12 01:28:09 --> Output Class Initialized
INFO - 2016-12-12 01:28:09 --> Security Class Initialized
DEBUG - 2016-12-12 01:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:28:09 --> Input Class Initialized
INFO - 2016-12-12 01:28:09 --> Language Class Initialized
INFO - 2016-12-12 01:28:09 --> Loader Class Initialized
INFO - 2016-12-12 01:28:09 --> Database Driver Class Initialized
INFO - 2016-12-12 01:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:28:09 --> Controller Class Initialized
INFO - 2016-12-12 01:28:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:28:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:28:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:28:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:28:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:28:09 --> Final output sent to browser
DEBUG - 2016-12-12 01:28:09 --> Total execution time: 0.0139
INFO - 2016-12-12 01:29:06 --> Config Class Initialized
INFO - 2016-12-12 01:29:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:29:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:29:06 --> Utf8 Class Initialized
INFO - 2016-12-12 01:29:06 --> URI Class Initialized
DEBUG - 2016-12-12 01:29:06 --> No URI present. Default controller set.
INFO - 2016-12-12 01:29:06 --> Router Class Initialized
INFO - 2016-12-12 01:29:06 --> Output Class Initialized
INFO - 2016-12-12 01:29:06 --> Security Class Initialized
DEBUG - 2016-12-12 01:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:29:06 --> Input Class Initialized
INFO - 2016-12-12 01:29:06 --> Language Class Initialized
INFO - 2016-12-12 01:29:06 --> Loader Class Initialized
INFO - 2016-12-12 01:29:06 --> Database Driver Class Initialized
INFO - 2016-12-12 01:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:29:06 --> Controller Class Initialized
INFO - 2016-12-12 01:29:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:29:06 --> Final output sent to browser
DEBUG - 2016-12-12 01:29:06 --> Total execution time: 0.0132
INFO - 2016-12-12 01:29:06 --> Config Class Initialized
INFO - 2016-12-12 01:29:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:29:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:29:06 --> Utf8 Class Initialized
INFO - 2016-12-12 01:29:06 --> URI Class Initialized
INFO - 2016-12-12 01:29:06 --> Router Class Initialized
INFO - 2016-12-12 01:29:06 --> Output Class Initialized
INFO - 2016-12-12 01:29:06 --> Security Class Initialized
DEBUG - 2016-12-12 01:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:29:06 --> Input Class Initialized
INFO - 2016-12-12 01:29:06 --> Language Class Initialized
INFO - 2016-12-12 01:29:06 --> Loader Class Initialized
INFO - 2016-12-12 01:29:06 --> Database Driver Class Initialized
INFO - 2016-12-12 01:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:29:06 --> Controller Class Initialized
INFO - 2016-12-12 01:29:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:29:06 --> Final output sent to browser
DEBUG - 2016-12-12 01:29:06 --> Total execution time: 0.0132
INFO - 2016-12-12 01:29:42 --> Config Class Initialized
INFO - 2016-12-12 01:29:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:29:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:29:42 --> Utf8 Class Initialized
INFO - 2016-12-12 01:29:42 --> URI Class Initialized
DEBUG - 2016-12-12 01:29:42 --> No URI present. Default controller set.
INFO - 2016-12-12 01:29:42 --> Router Class Initialized
INFO - 2016-12-12 01:29:42 --> Output Class Initialized
INFO - 2016-12-12 01:29:42 --> Security Class Initialized
DEBUG - 2016-12-12 01:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:29:42 --> Input Class Initialized
INFO - 2016-12-12 01:29:42 --> Language Class Initialized
INFO - 2016-12-12 01:29:42 --> Loader Class Initialized
INFO - 2016-12-12 01:29:42 --> Database Driver Class Initialized
INFO - 2016-12-12 01:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:29:42 --> Controller Class Initialized
INFO - 2016-12-12 01:29:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:29:42 --> Final output sent to browser
DEBUG - 2016-12-12 01:29:42 --> Total execution time: 0.4763
INFO - 2016-12-12 01:29:42 --> Config Class Initialized
INFO - 2016-12-12 01:29:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:29:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:29:42 --> Utf8 Class Initialized
INFO - 2016-12-12 01:29:42 --> URI Class Initialized
INFO - 2016-12-12 01:29:42 --> Router Class Initialized
INFO - 2016-12-12 01:29:42 --> Output Class Initialized
INFO - 2016-12-12 01:29:42 --> Security Class Initialized
DEBUG - 2016-12-12 01:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:29:42 --> Input Class Initialized
INFO - 2016-12-12 01:29:42 --> Language Class Initialized
INFO - 2016-12-12 01:29:42 --> Loader Class Initialized
INFO - 2016-12-12 01:29:42 --> Database Driver Class Initialized
INFO - 2016-12-12 01:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:29:42 --> Controller Class Initialized
INFO - 2016-12-12 01:29:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:29:42 --> Final output sent to browser
DEBUG - 2016-12-12 01:29:42 --> Total execution time: 0.0131
INFO - 2016-12-12 01:34:08 --> Config Class Initialized
INFO - 2016-12-12 01:34:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:34:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:34:08 --> Utf8 Class Initialized
INFO - 2016-12-12 01:34:08 --> URI Class Initialized
DEBUG - 2016-12-12 01:34:08 --> No URI present. Default controller set.
INFO - 2016-12-12 01:34:08 --> Router Class Initialized
INFO - 2016-12-12 01:34:08 --> Output Class Initialized
INFO - 2016-12-12 01:34:08 --> Security Class Initialized
DEBUG - 2016-12-12 01:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:34:08 --> Input Class Initialized
INFO - 2016-12-12 01:34:08 --> Language Class Initialized
INFO - 2016-12-12 01:34:08 --> Loader Class Initialized
INFO - 2016-12-12 01:34:08 --> Database Driver Class Initialized
INFO - 2016-12-12 01:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:34:08 --> Controller Class Initialized
INFO - 2016-12-12 01:34:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:34:08 --> Final output sent to browser
DEBUG - 2016-12-12 01:34:08 --> Total execution time: 0.0270
INFO - 2016-12-12 01:34:08 --> Config Class Initialized
INFO - 2016-12-12 01:34:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:34:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:34:08 --> Utf8 Class Initialized
INFO - 2016-12-12 01:34:08 --> URI Class Initialized
INFO - 2016-12-12 01:34:08 --> Router Class Initialized
INFO - 2016-12-12 01:34:08 --> Output Class Initialized
INFO - 2016-12-12 01:34:08 --> Security Class Initialized
DEBUG - 2016-12-12 01:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:34:08 --> Input Class Initialized
INFO - 2016-12-12 01:34:08 --> Language Class Initialized
INFO - 2016-12-12 01:34:08 --> Loader Class Initialized
INFO - 2016-12-12 01:34:08 --> Database Driver Class Initialized
INFO - 2016-12-12 01:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:34:08 --> Controller Class Initialized
INFO - 2016-12-12 01:34:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:34:08 --> Final output sent to browser
DEBUG - 2016-12-12 01:34:08 --> Total execution time: 0.0136
INFO - 2016-12-12 01:34:57 --> Config Class Initialized
INFO - 2016-12-12 01:34:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:34:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:34:57 --> Utf8 Class Initialized
INFO - 2016-12-12 01:34:57 --> URI Class Initialized
DEBUG - 2016-12-12 01:34:57 --> No URI present. Default controller set.
INFO - 2016-12-12 01:34:57 --> Router Class Initialized
INFO - 2016-12-12 01:34:57 --> Output Class Initialized
INFO - 2016-12-12 01:34:57 --> Security Class Initialized
DEBUG - 2016-12-12 01:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:34:57 --> Input Class Initialized
INFO - 2016-12-12 01:34:57 --> Language Class Initialized
INFO - 2016-12-12 01:34:57 --> Loader Class Initialized
INFO - 2016-12-12 01:34:57 --> Database Driver Class Initialized
INFO - 2016-12-12 01:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:34:57 --> Controller Class Initialized
INFO - 2016-12-12 01:34:57 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:34:57 --> Final output sent to browser
DEBUG - 2016-12-12 01:34:57 --> Total execution time: 0.0144
INFO - 2016-12-12 01:34:58 --> Config Class Initialized
INFO - 2016-12-12 01:34:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:34:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:34:58 --> Utf8 Class Initialized
INFO - 2016-12-12 01:34:58 --> URI Class Initialized
INFO - 2016-12-12 01:34:58 --> Router Class Initialized
INFO - 2016-12-12 01:34:58 --> Output Class Initialized
INFO - 2016-12-12 01:34:58 --> Security Class Initialized
DEBUG - 2016-12-12 01:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:34:58 --> Input Class Initialized
INFO - 2016-12-12 01:34:58 --> Language Class Initialized
INFO - 2016-12-12 01:34:58 --> Loader Class Initialized
INFO - 2016-12-12 01:34:58 --> Database Driver Class Initialized
INFO - 2016-12-12 01:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:34:58 --> Controller Class Initialized
INFO - 2016-12-12 01:34:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:34:58 --> Final output sent to browser
DEBUG - 2016-12-12 01:34:58 --> Total execution time: 0.0131
INFO - 2016-12-12 01:35:23 --> Config Class Initialized
INFO - 2016-12-12 01:35:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:35:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:35:23 --> Utf8 Class Initialized
INFO - 2016-12-12 01:35:23 --> URI Class Initialized
DEBUG - 2016-12-12 01:35:23 --> No URI present. Default controller set.
INFO - 2016-12-12 01:35:23 --> Router Class Initialized
INFO - 2016-12-12 01:35:23 --> Output Class Initialized
INFO - 2016-12-12 01:35:23 --> Security Class Initialized
DEBUG - 2016-12-12 01:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:35:23 --> Input Class Initialized
INFO - 2016-12-12 01:35:23 --> Language Class Initialized
INFO - 2016-12-12 01:35:23 --> Loader Class Initialized
INFO - 2016-12-12 01:35:23 --> Database Driver Class Initialized
INFO - 2016-12-12 01:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:35:23 --> Controller Class Initialized
INFO - 2016-12-12 01:35:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:35:23 --> Final output sent to browser
DEBUG - 2016-12-12 01:35:23 --> Total execution time: 0.0138
INFO - 2016-12-12 01:35:23 --> Config Class Initialized
INFO - 2016-12-12 01:35:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:35:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:35:23 --> Utf8 Class Initialized
INFO - 2016-12-12 01:35:23 --> URI Class Initialized
INFO - 2016-12-12 01:35:23 --> Router Class Initialized
INFO - 2016-12-12 01:35:23 --> Output Class Initialized
INFO - 2016-12-12 01:35:23 --> Security Class Initialized
DEBUG - 2016-12-12 01:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:35:23 --> Input Class Initialized
INFO - 2016-12-12 01:35:23 --> Language Class Initialized
INFO - 2016-12-12 01:35:23 --> Loader Class Initialized
INFO - 2016-12-12 01:35:23 --> Database Driver Class Initialized
INFO - 2016-12-12 01:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:35:23 --> Controller Class Initialized
INFO - 2016-12-12 01:35:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:35:23 --> Final output sent to browser
DEBUG - 2016-12-12 01:35:23 --> Total execution time: 0.0149
INFO - 2016-12-12 01:35:43 --> Config Class Initialized
INFO - 2016-12-12 01:35:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:35:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:35:43 --> Utf8 Class Initialized
INFO - 2016-12-12 01:35:43 --> URI Class Initialized
DEBUG - 2016-12-12 01:35:43 --> No URI present. Default controller set.
INFO - 2016-12-12 01:35:43 --> Router Class Initialized
INFO - 2016-12-12 01:35:43 --> Output Class Initialized
INFO - 2016-12-12 01:35:43 --> Security Class Initialized
DEBUG - 2016-12-12 01:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:35:43 --> Input Class Initialized
INFO - 2016-12-12 01:35:43 --> Language Class Initialized
INFO - 2016-12-12 01:35:43 --> Loader Class Initialized
INFO - 2016-12-12 01:35:43 --> Database Driver Class Initialized
INFO - 2016-12-12 01:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:35:43 --> Controller Class Initialized
INFO - 2016-12-12 01:35:43 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:35:43 --> Final output sent to browser
DEBUG - 2016-12-12 01:35:43 --> Total execution time: 0.0392
INFO - 2016-12-12 01:35:43 --> Config Class Initialized
INFO - 2016-12-12 01:35:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:35:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:35:43 --> Utf8 Class Initialized
INFO - 2016-12-12 01:35:43 --> URI Class Initialized
INFO - 2016-12-12 01:35:43 --> Router Class Initialized
INFO - 2016-12-12 01:35:43 --> Output Class Initialized
INFO - 2016-12-12 01:35:43 --> Security Class Initialized
DEBUG - 2016-12-12 01:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:35:43 --> Input Class Initialized
INFO - 2016-12-12 01:35:43 --> Language Class Initialized
INFO - 2016-12-12 01:35:43 --> Loader Class Initialized
INFO - 2016-12-12 01:35:43 --> Database Driver Class Initialized
INFO - 2016-12-12 01:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:35:43 --> Controller Class Initialized
INFO - 2016-12-12 01:35:43 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:35:43 --> Final output sent to browser
DEBUG - 2016-12-12 01:35:43 --> Total execution time: 0.0136
INFO - 2016-12-12 01:36:24 --> Config Class Initialized
INFO - 2016-12-12 01:36:24 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:36:24 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:36:24 --> Utf8 Class Initialized
INFO - 2016-12-12 01:36:24 --> URI Class Initialized
INFO - 2016-12-12 01:36:24 --> Router Class Initialized
INFO - 2016-12-12 01:36:24 --> Output Class Initialized
INFO - 2016-12-12 01:36:24 --> Security Class Initialized
DEBUG - 2016-12-12 01:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:36:24 --> Input Class Initialized
INFO - 2016-12-12 01:36:24 --> Language Class Initialized
ERROR - 2016-12-12 01:36:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:37:15 --> Config Class Initialized
INFO - 2016-12-12 01:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:37:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:37:15 --> Utf8 Class Initialized
INFO - 2016-12-12 01:37:15 --> URI Class Initialized
DEBUG - 2016-12-12 01:37:15 --> No URI present. Default controller set.
INFO - 2016-12-12 01:37:15 --> Router Class Initialized
INFO - 2016-12-12 01:37:15 --> Output Class Initialized
INFO - 2016-12-12 01:37:15 --> Security Class Initialized
DEBUG - 2016-12-12 01:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:37:15 --> Input Class Initialized
INFO - 2016-12-12 01:37:15 --> Language Class Initialized
INFO - 2016-12-12 01:37:15 --> Loader Class Initialized
INFO - 2016-12-12 01:37:15 --> Database Driver Class Initialized
INFO - 2016-12-12 01:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:37:15 --> Controller Class Initialized
INFO - 2016-12-12 01:37:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:37:15 --> Final output sent to browser
DEBUG - 2016-12-12 01:37:15 --> Total execution time: 0.0129
INFO - 2016-12-12 01:37:15 --> Config Class Initialized
INFO - 2016-12-12 01:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:37:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:37:15 --> Utf8 Class Initialized
INFO - 2016-12-12 01:37:15 --> URI Class Initialized
INFO - 2016-12-12 01:37:15 --> Router Class Initialized
INFO - 2016-12-12 01:37:15 --> Output Class Initialized
INFO - 2016-12-12 01:37:15 --> Security Class Initialized
DEBUG - 2016-12-12 01:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:37:15 --> Input Class Initialized
INFO - 2016-12-12 01:37:15 --> Language Class Initialized
ERROR - 2016-12-12 01:37:15 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:37:15 --> Config Class Initialized
INFO - 2016-12-12 01:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:37:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:37:15 --> Utf8 Class Initialized
INFO - 2016-12-12 01:37:15 --> URI Class Initialized
INFO - 2016-12-12 01:37:15 --> Router Class Initialized
INFO - 2016-12-12 01:37:15 --> Output Class Initialized
INFO - 2016-12-12 01:37:15 --> Security Class Initialized
DEBUG - 2016-12-12 01:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:37:15 --> Input Class Initialized
INFO - 2016-12-12 01:37:15 --> Language Class Initialized
INFO - 2016-12-12 01:37:15 --> Loader Class Initialized
INFO - 2016-12-12 01:37:15 --> Database Driver Class Initialized
INFO - 2016-12-12 01:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:37:15 --> Controller Class Initialized
INFO - 2016-12-12 01:37:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:37:15 --> Final output sent to browser
DEBUG - 2016-12-12 01:37:15 --> Total execution time: 0.0132
INFO - 2016-12-12 01:37:38 --> Config Class Initialized
INFO - 2016-12-12 01:37:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:37:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:37:38 --> Utf8 Class Initialized
INFO - 2016-12-12 01:37:38 --> URI Class Initialized
DEBUG - 2016-12-12 01:37:38 --> No URI present. Default controller set.
INFO - 2016-12-12 01:37:38 --> Router Class Initialized
INFO - 2016-12-12 01:37:38 --> Output Class Initialized
INFO - 2016-12-12 01:37:38 --> Security Class Initialized
DEBUG - 2016-12-12 01:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:37:38 --> Input Class Initialized
INFO - 2016-12-12 01:37:38 --> Language Class Initialized
INFO - 2016-12-12 01:37:38 --> Loader Class Initialized
INFO - 2016-12-12 01:37:38 --> Database Driver Class Initialized
INFO - 2016-12-12 01:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:37:38 --> Controller Class Initialized
INFO - 2016-12-12 01:37:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:37:38 --> Final output sent to browser
DEBUG - 2016-12-12 01:37:38 --> Total execution time: 0.0132
INFO - 2016-12-12 01:37:38 --> Config Class Initialized
INFO - 2016-12-12 01:37:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:37:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:37:38 --> Utf8 Class Initialized
INFO - 2016-12-12 01:37:38 --> URI Class Initialized
INFO - 2016-12-12 01:37:38 --> Router Class Initialized
INFO - 2016-12-12 01:37:38 --> Output Class Initialized
INFO - 2016-12-12 01:37:38 --> Security Class Initialized
DEBUG - 2016-12-12 01:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:37:38 --> Input Class Initialized
INFO - 2016-12-12 01:37:38 --> Language Class Initialized
ERROR - 2016-12-12 01:37:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:37:39 --> Config Class Initialized
INFO - 2016-12-12 01:37:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:37:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:37:39 --> Utf8 Class Initialized
INFO - 2016-12-12 01:37:39 --> URI Class Initialized
INFO - 2016-12-12 01:37:39 --> Router Class Initialized
INFO - 2016-12-12 01:37:39 --> Output Class Initialized
INFO - 2016-12-12 01:37:39 --> Security Class Initialized
DEBUG - 2016-12-12 01:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:37:39 --> Input Class Initialized
INFO - 2016-12-12 01:37:39 --> Language Class Initialized
INFO - 2016-12-12 01:37:39 --> Loader Class Initialized
INFO - 2016-12-12 01:37:39 --> Database Driver Class Initialized
INFO - 2016-12-12 01:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:37:39 --> Controller Class Initialized
INFO - 2016-12-12 01:37:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:37:39 --> Final output sent to browser
DEBUG - 2016-12-12 01:37:39 --> Total execution time: 0.0140
INFO - 2016-12-12 01:40:17 --> Config Class Initialized
INFO - 2016-12-12 01:40:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:40:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:40:17 --> Utf8 Class Initialized
INFO - 2016-12-12 01:40:17 --> URI Class Initialized
DEBUG - 2016-12-12 01:40:17 --> No URI present. Default controller set.
INFO - 2016-12-12 01:40:17 --> Router Class Initialized
INFO - 2016-12-12 01:40:17 --> Output Class Initialized
INFO - 2016-12-12 01:40:17 --> Security Class Initialized
DEBUG - 2016-12-12 01:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:40:17 --> Input Class Initialized
INFO - 2016-12-12 01:40:17 --> Language Class Initialized
INFO - 2016-12-12 01:40:17 --> Loader Class Initialized
INFO - 2016-12-12 01:40:17 --> Database Driver Class Initialized
INFO - 2016-12-12 01:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:40:17 --> Controller Class Initialized
INFO - 2016-12-12 01:40:17 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:40:17 --> Final output sent to browser
DEBUG - 2016-12-12 01:40:17 --> Total execution time: 0.0252
INFO - 2016-12-12 01:40:17 --> Config Class Initialized
INFO - 2016-12-12 01:40:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:40:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:40:17 --> Utf8 Class Initialized
INFO - 2016-12-12 01:40:17 --> URI Class Initialized
INFO - 2016-12-12 01:40:17 --> Router Class Initialized
INFO - 2016-12-12 01:40:17 --> Output Class Initialized
INFO - 2016-12-12 01:40:17 --> Security Class Initialized
DEBUG - 2016-12-12 01:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:40:17 --> Input Class Initialized
INFO - 2016-12-12 01:40:17 --> Language Class Initialized
ERROR - 2016-12-12 01:40:17 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:40:18 --> Config Class Initialized
INFO - 2016-12-12 01:40:18 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:40:18 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:40:18 --> Utf8 Class Initialized
INFO - 2016-12-12 01:40:18 --> URI Class Initialized
INFO - 2016-12-12 01:40:18 --> Router Class Initialized
INFO - 2016-12-12 01:40:18 --> Output Class Initialized
INFO - 2016-12-12 01:40:18 --> Security Class Initialized
DEBUG - 2016-12-12 01:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:40:18 --> Input Class Initialized
INFO - 2016-12-12 01:40:18 --> Language Class Initialized
INFO - 2016-12-12 01:40:18 --> Loader Class Initialized
INFO - 2016-12-12 01:40:18 --> Database Driver Class Initialized
INFO - 2016-12-12 01:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:40:18 --> Controller Class Initialized
INFO - 2016-12-12 01:40:18 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:40:18 --> Final output sent to browser
DEBUG - 2016-12-12 01:40:18 --> Total execution time: 0.0135
INFO - 2016-12-12 01:41:02 --> Config Class Initialized
INFO - 2016-12-12 01:41:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:41:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:41:02 --> Utf8 Class Initialized
INFO - 2016-12-12 01:41:02 --> URI Class Initialized
DEBUG - 2016-12-12 01:41:02 --> No URI present. Default controller set.
INFO - 2016-12-12 01:41:02 --> Router Class Initialized
INFO - 2016-12-12 01:41:02 --> Output Class Initialized
INFO - 2016-12-12 01:41:02 --> Security Class Initialized
DEBUG - 2016-12-12 01:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:41:02 --> Input Class Initialized
INFO - 2016-12-12 01:41:02 --> Language Class Initialized
INFO - 2016-12-12 01:41:02 --> Loader Class Initialized
INFO - 2016-12-12 01:41:02 --> Database Driver Class Initialized
INFO - 2016-12-12 01:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:41:02 --> Controller Class Initialized
INFO - 2016-12-12 01:41:02 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:41:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:41:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:41:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:41:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:41:02 --> Final output sent to browser
DEBUG - 2016-12-12 01:41:02 --> Total execution time: 0.0150
INFO - 2016-12-12 01:41:02 --> Config Class Initialized
INFO - 2016-12-12 01:41:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:41:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:41:02 --> Utf8 Class Initialized
INFO - 2016-12-12 01:41:02 --> URI Class Initialized
INFO - 2016-12-12 01:41:02 --> Router Class Initialized
INFO - 2016-12-12 01:41:02 --> Output Class Initialized
INFO - 2016-12-12 01:41:02 --> Security Class Initialized
DEBUG - 2016-12-12 01:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:41:02 --> Input Class Initialized
INFO - 2016-12-12 01:41:02 --> Language Class Initialized
ERROR - 2016-12-12 01:41:02 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:41:03 --> Config Class Initialized
INFO - 2016-12-12 01:41:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:41:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:41:03 --> Utf8 Class Initialized
INFO - 2016-12-12 01:41:03 --> URI Class Initialized
INFO - 2016-12-12 01:41:03 --> Router Class Initialized
INFO - 2016-12-12 01:41:03 --> Output Class Initialized
INFO - 2016-12-12 01:41:03 --> Security Class Initialized
DEBUG - 2016-12-12 01:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:41:03 --> Input Class Initialized
INFO - 2016-12-12 01:41:03 --> Language Class Initialized
INFO - 2016-12-12 01:41:03 --> Loader Class Initialized
INFO - 2016-12-12 01:41:03 --> Database Driver Class Initialized
INFO - 2016-12-12 01:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:41:03 --> Controller Class Initialized
INFO - 2016-12-12 01:41:03 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:41:03 --> Final output sent to browser
DEBUG - 2016-12-12 01:41:03 --> Total execution time: 0.0143
INFO - 2016-12-12 01:46:26 --> Config Class Initialized
INFO - 2016-12-12 01:46:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:46:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:46:26 --> Utf8 Class Initialized
INFO - 2016-12-12 01:46:26 --> URI Class Initialized
DEBUG - 2016-12-12 01:46:26 --> No URI present. Default controller set.
INFO - 2016-12-12 01:46:26 --> Router Class Initialized
INFO - 2016-12-12 01:46:26 --> Output Class Initialized
INFO - 2016-12-12 01:46:26 --> Security Class Initialized
DEBUG - 2016-12-12 01:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:46:26 --> Input Class Initialized
INFO - 2016-12-12 01:46:26 --> Language Class Initialized
INFO - 2016-12-12 01:46:26 --> Loader Class Initialized
INFO - 2016-12-12 01:46:26 --> Database Driver Class Initialized
INFO - 2016-12-12 01:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:46:26 --> Controller Class Initialized
INFO - 2016-12-12 01:46:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:46:26 --> Final output sent to browser
DEBUG - 2016-12-12 01:46:26 --> Total execution time: 0.0723
INFO - 2016-12-12 01:46:37 --> Config Class Initialized
INFO - 2016-12-12 01:46:37 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:46:37 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:46:37 --> Utf8 Class Initialized
INFO - 2016-12-12 01:46:37 --> URI Class Initialized
INFO - 2016-12-12 01:46:37 --> Router Class Initialized
INFO - 2016-12-12 01:46:37 --> Output Class Initialized
INFO - 2016-12-12 01:46:37 --> Security Class Initialized
DEBUG - 2016-12-12 01:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:46:37 --> Input Class Initialized
INFO - 2016-12-12 01:46:37 --> Language Class Initialized
INFO - 2016-12-12 01:46:37 --> Loader Class Initialized
INFO - 2016-12-12 01:46:37 --> Database Driver Class Initialized
INFO - 2016-12-12 01:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:46:37 --> Controller Class Initialized
INFO - 2016-12-12 01:46:37 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:46:37 --> Final output sent to browser
DEBUG - 2016-12-12 01:46:37 --> Total execution time: 0.0135
INFO - 2016-12-12 01:47:58 --> Config Class Initialized
INFO - 2016-12-12 01:47:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:47:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:47:58 --> Utf8 Class Initialized
INFO - 2016-12-12 01:47:58 --> URI Class Initialized
DEBUG - 2016-12-12 01:47:58 --> No URI present. Default controller set.
INFO - 2016-12-12 01:47:58 --> Router Class Initialized
INFO - 2016-12-12 01:47:58 --> Output Class Initialized
INFO - 2016-12-12 01:47:58 --> Security Class Initialized
DEBUG - 2016-12-12 01:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:47:58 --> Input Class Initialized
INFO - 2016-12-12 01:47:58 --> Language Class Initialized
INFO - 2016-12-12 01:47:58 --> Loader Class Initialized
INFO - 2016-12-12 01:47:58 --> Database Driver Class Initialized
INFO - 2016-12-12 01:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:47:58 --> Controller Class Initialized
INFO - 2016-12-12 01:47:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:47:58 --> Final output sent to browser
DEBUG - 2016-12-12 01:47:58 --> Total execution time: 0.0137
INFO - 2016-12-12 01:47:58 --> Config Class Initialized
INFO - 2016-12-12 01:47:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:47:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:47:58 --> Utf8 Class Initialized
INFO - 2016-12-12 01:47:58 --> URI Class Initialized
INFO - 2016-12-12 01:47:58 --> Router Class Initialized
INFO - 2016-12-12 01:47:58 --> Output Class Initialized
INFO - 2016-12-12 01:47:58 --> Security Class Initialized
DEBUG - 2016-12-12 01:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:47:58 --> Input Class Initialized
INFO - 2016-12-12 01:47:58 --> Language Class Initialized
ERROR - 2016-12-12 01:47:58 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:47:59 --> Config Class Initialized
INFO - 2016-12-12 01:47:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:47:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:47:59 --> Utf8 Class Initialized
INFO - 2016-12-12 01:47:59 --> URI Class Initialized
INFO - 2016-12-12 01:47:59 --> Router Class Initialized
INFO - 2016-12-12 01:47:59 --> Output Class Initialized
INFO - 2016-12-12 01:47:59 --> Security Class Initialized
DEBUG - 2016-12-12 01:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:47:59 --> Input Class Initialized
INFO - 2016-12-12 01:47:59 --> Language Class Initialized
INFO - 2016-12-12 01:47:59 --> Loader Class Initialized
INFO - 2016-12-12 01:47:59 --> Database Driver Class Initialized
INFO - 2016-12-12 01:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:47:59 --> Controller Class Initialized
INFO - 2016-12-12 01:47:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:47:59 --> Final output sent to browser
DEBUG - 2016-12-12 01:47:59 --> Total execution time: 0.0127
INFO - 2016-12-12 01:49:24 --> Config Class Initialized
INFO - 2016-12-12 01:49:24 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:49:24 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:49:24 --> Utf8 Class Initialized
INFO - 2016-12-12 01:49:24 --> URI Class Initialized
DEBUG - 2016-12-12 01:49:24 --> No URI present. Default controller set.
INFO - 2016-12-12 01:49:24 --> Router Class Initialized
INFO - 2016-12-12 01:49:24 --> Output Class Initialized
INFO - 2016-12-12 01:49:24 --> Security Class Initialized
DEBUG - 2016-12-12 01:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:49:24 --> Input Class Initialized
INFO - 2016-12-12 01:49:24 --> Language Class Initialized
INFO - 2016-12-12 01:49:24 --> Loader Class Initialized
INFO - 2016-12-12 01:49:24 --> Database Driver Class Initialized
INFO - 2016-12-12 01:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:49:24 --> Controller Class Initialized
INFO - 2016-12-12 01:49:24 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:49:24 --> Final output sent to browser
DEBUG - 2016-12-12 01:49:24 --> Total execution time: 0.0132
INFO - 2016-12-12 01:49:25 --> Config Class Initialized
INFO - 2016-12-12 01:49:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:49:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:49:25 --> Utf8 Class Initialized
INFO - 2016-12-12 01:49:25 --> URI Class Initialized
INFO - 2016-12-12 01:49:25 --> Router Class Initialized
INFO - 2016-12-12 01:49:25 --> Output Class Initialized
INFO - 2016-12-12 01:49:25 --> Security Class Initialized
DEBUG - 2016-12-12 01:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:49:25 --> Input Class Initialized
INFO - 2016-12-12 01:49:25 --> Language Class Initialized
ERROR - 2016-12-12 01:49:25 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:49:25 --> Config Class Initialized
INFO - 2016-12-12 01:49:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:49:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:49:25 --> Utf8 Class Initialized
INFO - 2016-12-12 01:49:25 --> URI Class Initialized
INFO - 2016-12-12 01:49:25 --> Router Class Initialized
INFO - 2016-12-12 01:49:25 --> Output Class Initialized
INFO - 2016-12-12 01:49:25 --> Security Class Initialized
DEBUG - 2016-12-12 01:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:49:25 --> Input Class Initialized
INFO - 2016-12-12 01:49:25 --> Language Class Initialized
INFO - 2016-12-12 01:49:25 --> Loader Class Initialized
INFO - 2016-12-12 01:49:25 --> Database Driver Class Initialized
INFO - 2016-12-12 01:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:49:25 --> Controller Class Initialized
INFO - 2016-12-12 01:49:25 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:49:25 --> Final output sent to browser
DEBUG - 2016-12-12 01:49:25 --> Total execution time: 0.0133
INFO - 2016-12-12 01:49:44 --> Config Class Initialized
INFO - 2016-12-12 01:49:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:49:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:49:44 --> Utf8 Class Initialized
INFO - 2016-12-12 01:49:44 --> URI Class Initialized
DEBUG - 2016-12-12 01:49:44 --> No URI present. Default controller set.
INFO - 2016-12-12 01:49:44 --> Router Class Initialized
INFO - 2016-12-12 01:49:45 --> Output Class Initialized
INFO - 2016-12-12 01:49:45 --> Security Class Initialized
DEBUG - 2016-12-12 01:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:49:45 --> Input Class Initialized
INFO - 2016-12-12 01:49:45 --> Language Class Initialized
INFO - 2016-12-12 01:49:45 --> Loader Class Initialized
INFO - 2016-12-12 01:49:45 --> Database Driver Class Initialized
INFO - 2016-12-12 01:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:49:45 --> Controller Class Initialized
INFO - 2016-12-12 01:49:45 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:49:45 --> Final output sent to browser
DEBUG - 2016-12-12 01:49:45 --> Total execution time: 0.0131
INFO - 2016-12-12 01:49:45 --> Config Class Initialized
INFO - 2016-12-12 01:49:45 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:49:45 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:49:45 --> Utf8 Class Initialized
INFO - 2016-12-12 01:49:45 --> URI Class Initialized
INFO - 2016-12-12 01:49:45 --> Router Class Initialized
INFO - 2016-12-12 01:49:45 --> Output Class Initialized
INFO - 2016-12-12 01:49:45 --> Security Class Initialized
DEBUG - 2016-12-12 01:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:49:45 --> Input Class Initialized
INFO - 2016-12-12 01:49:45 --> Language Class Initialized
ERROR - 2016-12-12 01:49:45 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:49:45 --> Config Class Initialized
INFO - 2016-12-12 01:49:45 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:49:45 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:49:45 --> Utf8 Class Initialized
INFO - 2016-12-12 01:49:45 --> URI Class Initialized
INFO - 2016-12-12 01:49:45 --> Router Class Initialized
INFO - 2016-12-12 01:49:45 --> Output Class Initialized
INFO - 2016-12-12 01:49:45 --> Security Class Initialized
DEBUG - 2016-12-12 01:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:49:45 --> Input Class Initialized
INFO - 2016-12-12 01:49:45 --> Language Class Initialized
INFO - 2016-12-12 01:49:45 --> Loader Class Initialized
INFO - 2016-12-12 01:49:45 --> Database Driver Class Initialized
INFO - 2016-12-12 01:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:49:45 --> Controller Class Initialized
INFO - 2016-12-12 01:49:45 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:49:45 --> Final output sent to browser
DEBUG - 2016-12-12 01:49:45 --> Total execution time: 0.0132
INFO - 2016-12-12 01:50:07 --> Config Class Initialized
INFO - 2016-12-12 01:50:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:50:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:50:07 --> Utf8 Class Initialized
INFO - 2016-12-12 01:50:07 --> URI Class Initialized
DEBUG - 2016-12-12 01:50:07 --> No URI present. Default controller set.
INFO - 2016-12-12 01:50:07 --> Router Class Initialized
INFO - 2016-12-12 01:50:07 --> Output Class Initialized
INFO - 2016-12-12 01:50:07 --> Security Class Initialized
DEBUG - 2016-12-12 01:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:50:07 --> Input Class Initialized
INFO - 2016-12-12 01:50:07 --> Language Class Initialized
INFO - 2016-12-12 01:50:07 --> Loader Class Initialized
INFO - 2016-12-12 01:50:07 --> Database Driver Class Initialized
INFO - 2016-12-12 01:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:50:07 --> Controller Class Initialized
INFO - 2016-12-12 01:50:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:50:07 --> Final output sent to browser
DEBUG - 2016-12-12 01:50:07 --> Total execution time: 0.0202
INFO - 2016-12-12 01:50:07 --> Config Class Initialized
INFO - 2016-12-12 01:50:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:50:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:50:07 --> Utf8 Class Initialized
INFO - 2016-12-12 01:50:07 --> URI Class Initialized
INFO - 2016-12-12 01:50:07 --> Router Class Initialized
INFO - 2016-12-12 01:50:07 --> Output Class Initialized
INFO - 2016-12-12 01:50:07 --> Security Class Initialized
DEBUG - 2016-12-12 01:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:50:07 --> Input Class Initialized
INFO - 2016-12-12 01:50:07 --> Language Class Initialized
ERROR - 2016-12-12 01:50:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:50:08 --> Config Class Initialized
INFO - 2016-12-12 01:50:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:50:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:50:08 --> Utf8 Class Initialized
INFO - 2016-12-12 01:50:08 --> URI Class Initialized
INFO - 2016-12-12 01:50:08 --> Router Class Initialized
INFO - 2016-12-12 01:50:08 --> Output Class Initialized
INFO - 2016-12-12 01:50:08 --> Security Class Initialized
DEBUG - 2016-12-12 01:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:50:08 --> Input Class Initialized
INFO - 2016-12-12 01:50:08 --> Language Class Initialized
INFO - 2016-12-12 01:50:08 --> Loader Class Initialized
INFO - 2016-12-12 01:50:08 --> Database Driver Class Initialized
INFO - 2016-12-12 01:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:50:08 --> Controller Class Initialized
INFO - 2016-12-12 01:50:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:50:08 --> Final output sent to browser
DEBUG - 2016-12-12 01:50:08 --> Total execution time: 0.0144
INFO - 2016-12-12 01:51:30 --> Config Class Initialized
INFO - 2016-12-12 01:51:30 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:30 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:30 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:30 --> URI Class Initialized
DEBUG - 2016-12-12 01:51:30 --> No URI present. Default controller set.
INFO - 2016-12-12 01:51:30 --> Router Class Initialized
INFO - 2016-12-12 01:51:30 --> Output Class Initialized
INFO - 2016-12-12 01:51:30 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:30 --> Input Class Initialized
INFO - 2016-12-12 01:51:30 --> Language Class Initialized
INFO - 2016-12-12 01:51:30 --> Loader Class Initialized
INFO - 2016-12-12 01:51:30 --> Database Driver Class Initialized
INFO - 2016-12-12 01:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:51:30 --> Controller Class Initialized
INFO - 2016-12-12 01:51:30 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:51:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:51:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:51:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:51:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:51:30 --> Final output sent to browser
DEBUG - 2016-12-12 01:51:30 --> Total execution time: 0.0128
INFO - 2016-12-12 01:51:30 --> Config Class Initialized
INFO - 2016-12-12 01:51:30 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:30 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:30 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:30 --> URI Class Initialized
INFO - 2016-12-12 01:51:30 --> Router Class Initialized
INFO - 2016-12-12 01:51:30 --> Output Class Initialized
INFO - 2016-12-12 01:51:30 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:30 --> Input Class Initialized
INFO - 2016-12-12 01:51:30 --> Language Class Initialized
ERROR - 2016-12-12 01:51:30 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:51:31 --> Config Class Initialized
INFO - 2016-12-12 01:51:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:31 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:31 --> URI Class Initialized
INFO - 2016-12-12 01:51:31 --> Router Class Initialized
INFO - 2016-12-12 01:51:31 --> Output Class Initialized
INFO - 2016-12-12 01:51:31 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:31 --> Input Class Initialized
INFO - 2016-12-12 01:51:31 --> Language Class Initialized
INFO - 2016-12-12 01:51:31 --> Loader Class Initialized
INFO - 2016-12-12 01:51:31 --> Database Driver Class Initialized
INFO - 2016-12-12 01:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:51:31 --> Controller Class Initialized
INFO - 2016-12-12 01:51:31 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:51:31 --> Final output sent to browser
DEBUG - 2016-12-12 01:51:31 --> Total execution time: 0.0135
INFO - 2016-12-12 01:51:49 --> Config Class Initialized
INFO - 2016-12-12 01:51:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:49 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:49 --> URI Class Initialized
DEBUG - 2016-12-12 01:51:49 --> No URI present. Default controller set.
INFO - 2016-12-12 01:51:49 --> Router Class Initialized
INFO - 2016-12-12 01:51:49 --> Output Class Initialized
INFO - 2016-12-12 01:51:49 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:49 --> Input Class Initialized
INFO - 2016-12-12 01:51:49 --> Language Class Initialized
INFO - 2016-12-12 01:51:49 --> Loader Class Initialized
INFO - 2016-12-12 01:51:49 --> Database Driver Class Initialized
INFO - 2016-12-12 01:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:51:49 --> Controller Class Initialized
INFO - 2016-12-12 01:51:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:51:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:51:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:51:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:51:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:51:49 --> Final output sent to browser
DEBUG - 2016-12-12 01:51:49 --> Total execution time: 0.0157
INFO - 2016-12-12 01:51:50 --> Config Class Initialized
INFO - 2016-12-12 01:51:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:50 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:50 --> URI Class Initialized
INFO - 2016-12-12 01:51:50 --> Router Class Initialized
INFO - 2016-12-12 01:51:50 --> Output Class Initialized
INFO - 2016-12-12 01:51:50 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:50 --> Input Class Initialized
INFO - 2016-12-12 01:51:50 --> Language Class Initialized
ERROR - 2016-12-12 01:51:50 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:51:50 --> Config Class Initialized
INFO - 2016-12-12 01:51:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:50 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:50 --> URI Class Initialized
INFO - 2016-12-12 01:51:50 --> Router Class Initialized
INFO - 2016-12-12 01:51:50 --> Output Class Initialized
INFO - 2016-12-12 01:51:50 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:50 --> Input Class Initialized
INFO - 2016-12-12 01:51:50 --> Language Class Initialized
INFO - 2016-12-12 01:51:50 --> Loader Class Initialized
INFO - 2016-12-12 01:51:50 --> Database Driver Class Initialized
INFO - 2016-12-12 01:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:51:50 --> Controller Class Initialized
INFO - 2016-12-12 01:51:50 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:51:50 --> Final output sent to browser
DEBUG - 2016-12-12 01:51:50 --> Total execution time: 0.0137
INFO - 2016-12-12 01:51:59 --> Config Class Initialized
INFO - 2016-12-12 01:51:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:59 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:59 --> URI Class Initialized
DEBUG - 2016-12-12 01:51:59 --> No URI present. Default controller set.
INFO - 2016-12-12 01:51:59 --> Router Class Initialized
INFO - 2016-12-12 01:51:59 --> Output Class Initialized
INFO - 2016-12-12 01:51:59 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:59 --> Input Class Initialized
INFO - 2016-12-12 01:51:59 --> Language Class Initialized
INFO - 2016-12-12 01:51:59 --> Loader Class Initialized
INFO - 2016-12-12 01:51:59 --> Database Driver Class Initialized
INFO - 2016-12-12 01:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:51:59 --> Controller Class Initialized
INFO - 2016-12-12 01:51:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:51:59 --> Final output sent to browser
DEBUG - 2016-12-12 01:51:59 --> Total execution time: 0.0130
INFO - 2016-12-12 01:51:59 --> Config Class Initialized
INFO - 2016-12-12 01:51:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:59 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:59 --> URI Class Initialized
INFO - 2016-12-12 01:51:59 --> Router Class Initialized
INFO - 2016-12-12 01:51:59 --> Output Class Initialized
INFO - 2016-12-12 01:51:59 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:59 --> Input Class Initialized
INFO - 2016-12-12 01:51:59 --> Language Class Initialized
ERROR - 2016-12-12 01:51:59 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:51:59 --> Config Class Initialized
INFO - 2016-12-12 01:51:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:51:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:51:59 --> Utf8 Class Initialized
INFO - 2016-12-12 01:51:59 --> URI Class Initialized
INFO - 2016-12-12 01:51:59 --> Router Class Initialized
INFO - 2016-12-12 01:51:59 --> Output Class Initialized
INFO - 2016-12-12 01:51:59 --> Security Class Initialized
DEBUG - 2016-12-12 01:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:51:59 --> Input Class Initialized
INFO - 2016-12-12 01:51:59 --> Language Class Initialized
INFO - 2016-12-12 01:51:59 --> Loader Class Initialized
INFO - 2016-12-12 01:51:59 --> Database Driver Class Initialized
INFO - 2016-12-12 01:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:51:59 --> Controller Class Initialized
INFO - 2016-12-12 01:51:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:51:59 --> Final output sent to browser
DEBUG - 2016-12-12 01:51:59 --> Total execution time: 0.0132
INFO - 2016-12-12 01:52:09 --> Config Class Initialized
INFO - 2016-12-12 01:52:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:52:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:52:09 --> Utf8 Class Initialized
INFO - 2016-12-12 01:52:09 --> URI Class Initialized
DEBUG - 2016-12-12 01:52:09 --> No URI present. Default controller set.
INFO - 2016-12-12 01:52:09 --> Router Class Initialized
INFO - 2016-12-12 01:52:09 --> Output Class Initialized
INFO - 2016-12-12 01:52:09 --> Security Class Initialized
DEBUG - 2016-12-12 01:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:52:09 --> Input Class Initialized
INFO - 2016-12-12 01:52:09 --> Language Class Initialized
INFO - 2016-12-12 01:52:09 --> Loader Class Initialized
INFO - 2016-12-12 01:52:09 --> Database Driver Class Initialized
INFO - 2016-12-12 01:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:52:09 --> Controller Class Initialized
INFO - 2016-12-12 01:52:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:52:09 --> Final output sent to browser
DEBUG - 2016-12-12 01:52:09 --> Total execution time: 0.0133
INFO - 2016-12-12 01:52:09 --> Config Class Initialized
INFO - 2016-12-12 01:52:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:52:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:52:09 --> Utf8 Class Initialized
INFO - 2016-12-12 01:52:09 --> URI Class Initialized
INFO - 2016-12-12 01:52:09 --> Router Class Initialized
INFO - 2016-12-12 01:52:09 --> Output Class Initialized
INFO - 2016-12-12 01:52:09 --> Security Class Initialized
DEBUG - 2016-12-12 01:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:52:09 --> Input Class Initialized
INFO - 2016-12-12 01:52:09 --> Language Class Initialized
ERROR - 2016-12-12 01:52:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:52:09 --> Config Class Initialized
INFO - 2016-12-12 01:52:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:52:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:52:09 --> Utf8 Class Initialized
INFO - 2016-12-12 01:52:09 --> URI Class Initialized
INFO - 2016-12-12 01:52:09 --> Router Class Initialized
INFO - 2016-12-12 01:52:09 --> Output Class Initialized
INFO - 2016-12-12 01:52:09 --> Security Class Initialized
DEBUG - 2016-12-12 01:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:52:09 --> Input Class Initialized
INFO - 2016-12-12 01:52:09 --> Language Class Initialized
INFO - 2016-12-12 01:52:09 --> Loader Class Initialized
INFO - 2016-12-12 01:52:09 --> Database Driver Class Initialized
INFO - 2016-12-12 01:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:52:09 --> Controller Class Initialized
INFO - 2016-12-12 01:52:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:52:09 --> Final output sent to browser
DEBUG - 2016-12-12 01:52:09 --> Total execution time: 0.0134
INFO - 2016-12-12 01:55:42 --> Config Class Initialized
INFO - 2016-12-12 01:55:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:55:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:55:42 --> Utf8 Class Initialized
INFO - 2016-12-12 01:55:42 --> URI Class Initialized
DEBUG - 2016-12-12 01:55:42 --> No URI present. Default controller set.
INFO - 2016-12-12 01:55:42 --> Router Class Initialized
INFO - 2016-12-12 01:55:42 --> Output Class Initialized
INFO - 2016-12-12 01:55:42 --> Security Class Initialized
DEBUG - 2016-12-12 01:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:55:42 --> Input Class Initialized
INFO - 2016-12-12 01:55:42 --> Language Class Initialized
INFO - 2016-12-12 01:55:42 --> Loader Class Initialized
INFO - 2016-12-12 01:55:42 --> Database Driver Class Initialized
INFO - 2016-12-12 01:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:55:42 --> Controller Class Initialized
INFO - 2016-12-12 01:55:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:55:42 --> Final output sent to browser
DEBUG - 2016-12-12 01:55:42 --> Total execution time: 0.0134
INFO - 2016-12-12 01:55:43 --> Config Class Initialized
INFO - 2016-12-12 01:55:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:55:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:55:43 --> Utf8 Class Initialized
INFO - 2016-12-12 01:55:43 --> URI Class Initialized
INFO - 2016-12-12 01:55:43 --> Router Class Initialized
INFO - 2016-12-12 01:55:43 --> Output Class Initialized
INFO - 2016-12-12 01:55:43 --> Security Class Initialized
DEBUG - 2016-12-12 01:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:55:43 --> Input Class Initialized
INFO - 2016-12-12 01:55:43 --> Language Class Initialized
ERROR - 2016-12-12 01:55:43 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:55:43 --> Config Class Initialized
INFO - 2016-12-12 01:55:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:55:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:55:43 --> Utf8 Class Initialized
INFO - 2016-12-12 01:55:43 --> URI Class Initialized
INFO - 2016-12-12 01:55:43 --> Router Class Initialized
INFO - 2016-12-12 01:55:43 --> Output Class Initialized
INFO - 2016-12-12 01:55:43 --> Security Class Initialized
DEBUG - 2016-12-12 01:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:55:43 --> Input Class Initialized
INFO - 2016-12-12 01:55:43 --> Language Class Initialized
INFO - 2016-12-12 01:55:43 --> Loader Class Initialized
INFO - 2016-12-12 01:55:43 --> Database Driver Class Initialized
INFO - 2016-12-12 01:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:55:43 --> Controller Class Initialized
INFO - 2016-12-12 01:55:43 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:55:43 --> Final output sent to browser
DEBUG - 2016-12-12 01:55:43 --> Total execution time: 0.0134
INFO - 2016-12-12 01:56:41 --> Config Class Initialized
INFO - 2016-12-12 01:56:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:56:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:56:41 --> Utf8 Class Initialized
INFO - 2016-12-12 01:56:41 --> URI Class Initialized
DEBUG - 2016-12-12 01:56:41 --> No URI present. Default controller set.
INFO - 2016-12-12 01:56:41 --> Router Class Initialized
INFO - 2016-12-12 01:56:41 --> Output Class Initialized
INFO - 2016-12-12 01:56:41 --> Security Class Initialized
DEBUG - 2016-12-12 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:56:41 --> Input Class Initialized
INFO - 2016-12-12 01:56:41 --> Language Class Initialized
INFO - 2016-12-12 01:56:41 --> Loader Class Initialized
INFO - 2016-12-12 01:56:41 --> Database Driver Class Initialized
INFO - 2016-12-12 01:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:56:41 --> Controller Class Initialized
INFO - 2016-12-12 01:56:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:56:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:56:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:56:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:56:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:56:41 --> Final output sent to browser
DEBUG - 2016-12-12 01:56:41 --> Total execution time: 0.0129
INFO - 2016-12-12 01:56:42 --> Config Class Initialized
INFO - 2016-12-12 01:56:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:56:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:56:42 --> Utf8 Class Initialized
INFO - 2016-12-12 01:56:42 --> URI Class Initialized
INFO - 2016-12-12 01:56:42 --> Router Class Initialized
INFO - 2016-12-12 01:56:42 --> Output Class Initialized
INFO - 2016-12-12 01:56:42 --> Security Class Initialized
DEBUG - 2016-12-12 01:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:56:42 --> Input Class Initialized
INFO - 2016-12-12 01:56:42 --> Language Class Initialized
ERROR - 2016-12-12 01:56:42 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:56:42 --> Config Class Initialized
INFO - 2016-12-12 01:56:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:56:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:56:42 --> Utf8 Class Initialized
INFO - 2016-12-12 01:56:42 --> URI Class Initialized
INFO - 2016-12-12 01:56:42 --> Router Class Initialized
INFO - 2016-12-12 01:56:42 --> Output Class Initialized
INFO - 2016-12-12 01:56:42 --> Security Class Initialized
DEBUG - 2016-12-12 01:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:56:42 --> Input Class Initialized
INFO - 2016-12-12 01:56:42 --> Language Class Initialized
INFO - 2016-12-12 01:56:42 --> Loader Class Initialized
INFO - 2016-12-12 01:56:42 --> Database Driver Class Initialized
INFO - 2016-12-12 01:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:56:42 --> Controller Class Initialized
INFO - 2016-12-12 01:56:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:56:42 --> Final output sent to browser
DEBUG - 2016-12-12 01:56:42 --> Total execution time: 0.0132
INFO - 2016-12-12 01:56:49 --> Config Class Initialized
INFO - 2016-12-12 01:56:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:56:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:56:49 --> Utf8 Class Initialized
INFO - 2016-12-12 01:56:49 --> URI Class Initialized
DEBUG - 2016-12-12 01:56:49 --> No URI present. Default controller set.
INFO - 2016-12-12 01:56:49 --> Router Class Initialized
INFO - 2016-12-12 01:56:49 --> Output Class Initialized
INFO - 2016-12-12 01:56:49 --> Security Class Initialized
DEBUG - 2016-12-12 01:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:56:49 --> Input Class Initialized
INFO - 2016-12-12 01:56:49 --> Language Class Initialized
INFO - 2016-12-12 01:56:49 --> Loader Class Initialized
INFO - 2016-12-12 01:56:49 --> Database Driver Class Initialized
INFO - 2016-12-12 01:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:56:49 --> Controller Class Initialized
INFO - 2016-12-12 01:56:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:56:49 --> Final output sent to browser
DEBUG - 2016-12-12 01:56:49 --> Total execution time: 0.0133
INFO - 2016-12-12 01:56:50 --> Config Class Initialized
INFO - 2016-12-12 01:56:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:56:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:56:50 --> Utf8 Class Initialized
INFO - 2016-12-12 01:56:50 --> URI Class Initialized
INFO - 2016-12-12 01:56:50 --> Router Class Initialized
INFO - 2016-12-12 01:56:50 --> Output Class Initialized
INFO - 2016-12-12 01:56:50 --> Security Class Initialized
DEBUG - 2016-12-12 01:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:56:50 --> Input Class Initialized
INFO - 2016-12-12 01:56:50 --> Language Class Initialized
ERROR - 2016-12-12 01:56:50 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:56:50 --> Config Class Initialized
INFO - 2016-12-12 01:56:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:56:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:56:50 --> Utf8 Class Initialized
INFO - 2016-12-12 01:56:50 --> URI Class Initialized
INFO - 2016-12-12 01:56:50 --> Router Class Initialized
INFO - 2016-12-12 01:56:50 --> Output Class Initialized
INFO - 2016-12-12 01:56:50 --> Security Class Initialized
DEBUG - 2016-12-12 01:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:56:50 --> Input Class Initialized
INFO - 2016-12-12 01:56:50 --> Language Class Initialized
INFO - 2016-12-12 01:56:50 --> Loader Class Initialized
INFO - 2016-12-12 01:56:50 --> Database Driver Class Initialized
INFO - 2016-12-12 01:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:56:50 --> Controller Class Initialized
INFO - 2016-12-12 01:56:50 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:56:50 --> Final output sent to browser
DEBUG - 2016-12-12 01:56:50 --> Total execution time: 0.0130
INFO - 2016-12-12 01:59:46 --> Config Class Initialized
INFO - 2016-12-12 01:59:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:59:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:59:46 --> Utf8 Class Initialized
INFO - 2016-12-12 01:59:46 --> URI Class Initialized
DEBUG - 2016-12-12 01:59:46 --> No URI present. Default controller set.
INFO - 2016-12-12 01:59:46 --> Router Class Initialized
INFO - 2016-12-12 01:59:46 --> Output Class Initialized
INFO - 2016-12-12 01:59:46 --> Security Class Initialized
DEBUG - 2016-12-12 01:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:59:46 --> Input Class Initialized
INFO - 2016-12-12 01:59:46 --> Language Class Initialized
INFO - 2016-12-12 01:59:46 --> Loader Class Initialized
INFO - 2016-12-12 01:59:46 --> Database Driver Class Initialized
INFO - 2016-12-12 01:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:59:46 --> Controller Class Initialized
INFO - 2016-12-12 01:59:46 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:59:46 --> Final output sent to browser
DEBUG - 2016-12-12 01:59:46 --> Total execution time: 0.0133
INFO - 2016-12-12 01:59:46 --> Config Class Initialized
INFO - 2016-12-12 01:59:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:59:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:59:46 --> Utf8 Class Initialized
INFO - 2016-12-12 01:59:46 --> URI Class Initialized
INFO - 2016-12-12 01:59:46 --> Router Class Initialized
INFO - 2016-12-12 01:59:46 --> Output Class Initialized
INFO - 2016-12-12 01:59:46 --> Security Class Initialized
DEBUG - 2016-12-12 01:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:59:46 --> Input Class Initialized
INFO - 2016-12-12 01:59:46 --> Language Class Initialized
ERROR - 2016-12-12 01:59:46 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 01:59:46 --> Config Class Initialized
INFO - 2016-12-12 01:59:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 01:59:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 01:59:46 --> Utf8 Class Initialized
INFO - 2016-12-12 01:59:46 --> URI Class Initialized
INFO - 2016-12-12 01:59:46 --> Router Class Initialized
INFO - 2016-12-12 01:59:46 --> Output Class Initialized
INFO - 2016-12-12 01:59:46 --> Security Class Initialized
DEBUG - 2016-12-12 01:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 01:59:46 --> Input Class Initialized
INFO - 2016-12-12 01:59:46 --> Language Class Initialized
INFO - 2016-12-12 01:59:46 --> Loader Class Initialized
INFO - 2016-12-12 01:59:46 --> Database Driver Class Initialized
INFO - 2016-12-12 01:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 01:59:46 --> Controller Class Initialized
INFO - 2016-12-12 01:59:46 --> Helper loaded: url_helper
DEBUG - 2016-12-12 01:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 01:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 01:59:46 --> Final output sent to browser
DEBUG - 2016-12-12 01:59:46 --> Total execution time: 0.0131
INFO - 2016-12-12 02:00:59 --> Config Class Initialized
INFO - 2016-12-12 02:00:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:00:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:00:59 --> Utf8 Class Initialized
INFO - 2016-12-12 02:00:59 --> URI Class Initialized
DEBUG - 2016-12-12 02:00:59 --> No URI present. Default controller set.
INFO - 2016-12-12 02:00:59 --> Router Class Initialized
INFO - 2016-12-12 02:00:59 --> Output Class Initialized
INFO - 2016-12-12 02:00:59 --> Security Class Initialized
DEBUG - 2016-12-12 02:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:00:59 --> Input Class Initialized
INFO - 2016-12-12 02:00:59 --> Language Class Initialized
INFO - 2016-12-12 02:00:59 --> Loader Class Initialized
INFO - 2016-12-12 02:00:59 --> Database Driver Class Initialized
INFO - 2016-12-12 02:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:00:59 --> Controller Class Initialized
INFO - 2016-12-12 02:00:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:00:59 --> Final output sent to browser
DEBUG - 2016-12-12 02:00:59 --> Total execution time: 0.0134
INFO - 2016-12-12 02:01:00 --> Config Class Initialized
INFO - 2016-12-12 02:01:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:01:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:01:00 --> Utf8 Class Initialized
INFO - 2016-12-12 02:01:00 --> URI Class Initialized
INFO - 2016-12-12 02:01:00 --> Router Class Initialized
INFO - 2016-12-12 02:01:00 --> Output Class Initialized
INFO - 2016-12-12 02:01:00 --> Security Class Initialized
DEBUG - 2016-12-12 02:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:01:00 --> Input Class Initialized
INFO - 2016-12-12 02:01:00 --> Language Class Initialized
ERROR - 2016-12-12 02:01:00 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:01:00 --> Config Class Initialized
INFO - 2016-12-12 02:01:01 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:01:01 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:01:01 --> Utf8 Class Initialized
INFO - 2016-12-12 02:01:01 --> URI Class Initialized
INFO - 2016-12-12 02:01:01 --> Router Class Initialized
INFO - 2016-12-12 02:01:01 --> Output Class Initialized
INFO - 2016-12-12 02:01:01 --> Security Class Initialized
DEBUG - 2016-12-12 02:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:01:01 --> Input Class Initialized
INFO - 2016-12-12 02:01:01 --> Language Class Initialized
INFO - 2016-12-12 02:01:01 --> Loader Class Initialized
INFO - 2016-12-12 02:01:01 --> Database Driver Class Initialized
INFO - 2016-12-12 02:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:01:01 --> Controller Class Initialized
INFO - 2016-12-12 02:01:01 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:01:01 --> Final output sent to browser
DEBUG - 2016-12-12 02:01:01 --> Total execution time: 0.8981
INFO - 2016-12-12 02:03:15 --> Config Class Initialized
INFO - 2016-12-12 02:03:15 --> Hooks Class Initialized
INFO - 2016-12-12 02:03:15 --> Config Class Initialized
INFO - 2016-12-12 02:03:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:15 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:15 --> URI Class Initialized
DEBUG - 2016-12-12 02:03:15 --> No URI present. Default controller set.
INFO - 2016-12-12 02:03:15 --> Router Class Initialized
DEBUG - 2016-12-12 02:03:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:15 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:15 --> Output Class Initialized
INFO - 2016-12-12 02:03:15 --> URI Class Initialized
INFO - 2016-12-12 02:03:15 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:15 --> No URI present. Default controller set.
INFO - 2016-12-12 02:03:15 --> Router Class Initialized
DEBUG - 2016-12-12 02:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:15 --> Input Class Initialized
INFO - 2016-12-12 02:03:15 --> Language Class Initialized
INFO - 2016-12-12 02:03:15 --> Output Class Initialized
INFO - 2016-12-12 02:03:15 --> Loader Class Initialized
INFO - 2016-12-12 02:03:15 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:15 --> Input Class Initialized
INFO - 2016-12-12 02:03:15 --> Language Class Initialized
INFO - 2016-12-12 02:03:15 --> Database Driver Class Initialized
INFO - 2016-12-12 02:03:15 --> Loader Class Initialized
INFO - 2016-12-12 02:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:03:15 --> Controller Class Initialized
INFO - 2016-12-12 02:03:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:03:15 --> Database Driver Class Initialized
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:03:15 --> Final output sent to browser
DEBUG - 2016-12-12 02:03:15 --> Total execution time: 5.8535
INFO - 2016-12-12 02:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:03:15 --> Controller Class Initialized
INFO - 2016-12-12 02:03:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:03:15 --> Final output sent to browser
DEBUG - 2016-12-12 02:03:15 --> Total execution time: 2.2394
INFO - 2016-12-12 02:03:15 --> Config Class Initialized
INFO - 2016-12-12 02:03:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:15 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:15 --> URI Class Initialized
INFO - 2016-12-12 02:03:15 --> Router Class Initialized
INFO - 2016-12-12 02:03:15 --> Output Class Initialized
INFO - 2016-12-12 02:03:15 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:15 --> Input Class Initialized
INFO - 2016-12-12 02:03:15 --> Language Class Initialized
ERROR - 2016-12-12 02:03:15 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:03:15 --> Config Class Initialized
INFO - 2016-12-12 02:03:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:15 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:15 --> URI Class Initialized
INFO - 2016-12-12 02:03:15 --> Router Class Initialized
INFO - 2016-12-12 02:03:15 --> Output Class Initialized
INFO - 2016-12-12 02:03:15 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:15 --> Input Class Initialized
INFO - 2016-12-12 02:03:15 --> Language Class Initialized
INFO - 2016-12-12 02:03:15 --> Loader Class Initialized
INFO - 2016-12-12 02:03:15 --> Database Driver Class Initialized
INFO - 2016-12-12 02:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:03:15 --> Controller Class Initialized
INFO - 2016-12-12 02:03:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:03:15 --> Final output sent to browser
DEBUG - 2016-12-12 02:03:15 --> Total execution time: 0.0131
INFO - 2016-12-12 02:03:24 --> Config Class Initialized
INFO - 2016-12-12 02:03:24 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:24 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:24 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:24 --> URI Class Initialized
DEBUG - 2016-12-12 02:03:24 --> No URI present. Default controller set.
INFO - 2016-12-12 02:03:24 --> Router Class Initialized
INFO - 2016-12-12 02:03:24 --> Output Class Initialized
INFO - 2016-12-12 02:03:24 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:24 --> Input Class Initialized
INFO - 2016-12-12 02:03:24 --> Language Class Initialized
INFO - 2016-12-12 02:03:24 --> Loader Class Initialized
INFO - 2016-12-12 02:03:24 --> Database Driver Class Initialized
INFO - 2016-12-12 02:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:03:24 --> Controller Class Initialized
INFO - 2016-12-12 02:03:24 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:03:24 --> Final output sent to browser
DEBUG - 2016-12-12 02:03:24 --> Total execution time: 0.0132
INFO - 2016-12-12 02:03:24 --> Config Class Initialized
INFO - 2016-12-12 02:03:24 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:24 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:24 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:24 --> URI Class Initialized
INFO - 2016-12-12 02:03:24 --> Router Class Initialized
INFO - 2016-12-12 02:03:24 --> Output Class Initialized
INFO - 2016-12-12 02:03:24 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:24 --> Input Class Initialized
INFO - 2016-12-12 02:03:24 --> Language Class Initialized
ERROR - 2016-12-12 02:03:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:03:25 --> Config Class Initialized
INFO - 2016-12-12 02:03:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:25 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:25 --> URI Class Initialized
INFO - 2016-12-12 02:03:25 --> Router Class Initialized
INFO - 2016-12-12 02:03:25 --> Output Class Initialized
INFO - 2016-12-12 02:03:25 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:25 --> Input Class Initialized
INFO - 2016-12-12 02:03:25 --> Language Class Initialized
INFO - 2016-12-12 02:03:25 --> Loader Class Initialized
INFO - 2016-12-12 02:03:25 --> Database Driver Class Initialized
INFO - 2016-12-12 02:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:03:25 --> Controller Class Initialized
INFO - 2016-12-12 02:03:25 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:03:25 --> Final output sent to browser
DEBUG - 2016-12-12 02:03:25 --> Total execution time: 0.0134
INFO - 2016-12-12 02:03:42 --> Config Class Initialized
INFO - 2016-12-12 02:03:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:42 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:42 --> URI Class Initialized
DEBUG - 2016-12-12 02:03:42 --> No URI present. Default controller set.
INFO - 2016-12-12 02:03:42 --> Router Class Initialized
INFO - 2016-12-12 02:03:42 --> Output Class Initialized
INFO - 2016-12-12 02:03:42 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:42 --> Input Class Initialized
INFO - 2016-12-12 02:03:42 --> Language Class Initialized
INFO - 2016-12-12 02:03:42 --> Loader Class Initialized
INFO - 2016-12-12 02:03:42 --> Database Driver Class Initialized
INFO - 2016-12-12 02:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:03:42 --> Controller Class Initialized
INFO - 2016-12-12 02:03:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:03:42 --> Final output sent to browser
DEBUG - 2016-12-12 02:03:42 --> Total execution time: 0.0135
INFO - 2016-12-12 02:03:42 --> Config Class Initialized
INFO - 2016-12-12 02:03:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:42 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:42 --> URI Class Initialized
INFO - 2016-12-12 02:03:42 --> Router Class Initialized
INFO - 2016-12-12 02:03:42 --> Output Class Initialized
INFO - 2016-12-12 02:03:42 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:42 --> Input Class Initialized
INFO - 2016-12-12 02:03:42 --> Language Class Initialized
ERROR - 2016-12-12 02:03:42 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:03:42 --> Config Class Initialized
INFO - 2016-12-12 02:03:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:03:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:03:42 --> Utf8 Class Initialized
INFO - 2016-12-12 02:03:42 --> URI Class Initialized
INFO - 2016-12-12 02:03:42 --> Router Class Initialized
INFO - 2016-12-12 02:03:42 --> Output Class Initialized
INFO - 2016-12-12 02:03:42 --> Security Class Initialized
DEBUG - 2016-12-12 02:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:03:42 --> Input Class Initialized
INFO - 2016-12-12 02:03:42 --> Language Class Initialized
INFO - 2016-12-12 02:03:42 --> Loader Class Initialized
INFO - 2016-12-12 02:03:42 --> Database Driver Class Initialized
INFO - 2016-12-12 02:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:03:42 --> Controller Class Initialized
INFO - 2016-12-12 02:03:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:03:42 --> Final output sent to browser
DEBUG - 2016-12-12 02:03:42 --> Total execution time: 0.0128
INFO - 2016-12-12 02:04:09 --> Config Class Initialized
INFO - 2016-12-12 02:04:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:04:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:04:09 --> Utf8 Class Initialized
INFO - 2016-12-12 02:04:09 --> URI Class Initialized
DEBUG - 2016-12-12 02:04:09 --> No URI present. Default controller set.
INFO - 2016-12-12 02:04:09 --> Router Class Initialized
INFO - 2016-12-12 02:04:09 --> Output Class Initialized
INFO - 2016-12-12 02:04:09 --> Security Class Initialized
DEBUG - 2016-12-12 02:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:04:09 --> Input Class Initialized
INFO - 2016-12-12 02:04:09 --> Language Class Initialized
INFO - 2016-12-12 02:04:09 --> Loader Class Initialized
INFO - 2016-12-12 02:04:09 --> Database Driver Class Initialized
INFO - 2016-12-12 02:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:04:09 --> Controller Class Initialized
INFO - 2016-12-12 02:04:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:04:09 --> Final output sent to browser
DEBUG - 2016-12-12 02:04:09 --> Total execution time: 0.0131
INFO - 2016-12-12 02:04:09 --> Config Class Initialized
INFO - 2016-12-12 02:04:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:04:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:04:09 --> Utf8 Class Initialized
INFO - 2016-12-12 02:04:09 --> URI Class Initialized
INFO - 2016-12-12 02:04:09 --> Router Class Initialized
INFO - 2016-12-12 02:04:09 --> Output Class Initialized
INFO - 2016-12-12 02:04:09 --> Security Class Initialized
DEBUG - 2016-12-12 02:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:04:09 --> Input Class Initialized
INFO - 2016-12-12 02:04:09 --> Language Class Initialized
ERROR - 2016-12-12 02:04:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:04:10 --> Config Class Initialized
INFO - 2016-12-12 02:04:10 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:04:10 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:04:10 --> Utf8 Class Initialized
INFO - 2016-12-12 02:04:10 --> URI Class Initialized
INFO - 2016-12-12 02:04:10 --> Router Class Initialized
INFO - 2016-12-12 02:04:10 --> Output Class Initialized
INFO - 2016-12-12 02:04:10 --> Security Class Initialized
DEBUG - 2016-12-12 02:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:04:10 --> Input Class Initialized
INFO - 2016-12-12 02:04:10 --> Language Class Initialized
INFO - 2016-12-12 02:04:10 --> Loader Class Initialized
INFO - 2016-12-12 02:04:10 --> Database Driver Class Initialized
INFO - 2016-12-12 02:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:04:10 --> Controller Class Initialized
INFO - 2016-12-12 02:04:10 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:04:10 --> Final output sent to browser
DEBUG - 2016-12-12 02:04:10 --> Total execution time: 0.0137
INFO - 2016-12-12 02:04:40 --> Config Class Initialized
INFO - 2016-12-12 02:04:40 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:04:40 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:04:40 --> Utf8 Class Initialized
INFO - 2016-12-12 02:04:40 --> URI Class Initialized
DEBUG - 2016-12-12 02:04:40 --> No URI present. Default controller set.
INFO - 2016-12-12 02:04:40 --> Router Class Initialized
INFO - 2016-12-12 02:04:40 --> Output Class Initialized
INFO - 2016-12-12 02:04:40 --> Security Class Initialized
DEBUG - 2016-12-12 02:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:04:41 --> Input Class Initialized
INFO - 2016-12-12 02:04:41 --> Language Class Initialized
INFO - 2016-12-12 02:04:41 --> Loader Class Initialized
INFO - 2016-12-12 02:04:41 --> Database Driver Class Initialized
INFO - 2016-12-12 02:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:04:41 --> Controller Class Initialized
INFO - 2016-12-12 02:04:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:04:41 --> Final output sent to browser
DEBUG - 2016-12-12 02:04:41 --> Total execution time: 0.0136
INFO - 2016-12-12 02:04:41 --> Config Class Initialized
INFO - 2016-12-12 02:04:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:04:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:04:41 --> Utf8 Class Initialized
INFO - 2016-12-12 02:04:41 --> URI Class Initialized
INFO - 2016-12-12 02:04:41 --> Router Class Initialized
INFO - 2016-12-12 02:04:41 --> Output Class Initialized
INFO - 2016-12-12 02:04:41 --> Security Class Initialized
DEBUG - 2016-12-12 02:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:04:41 --> Input Class Initialized
INFO - 2016-12-12 02:04:41 --> Language Class Initialized
ERROR - 2016-12-12 02:04:41 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:04:41 --> Config Class Initialized
INFO - 2016-12-12 02:04:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:04:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:04:41 --> Utf8 Class Initialized
INFO - 2016-12-12 02:04:41 --> URI Class Initialized
INFO - 2016-12-12 02:04:41 --> Router Class Initialized
INFO - 2016-12-12 02:04:41 --> Output Class Initialized
INFO - 2016-12-12 02:04:41 --> Security Class Initialized
DEBUG - 2016-12-12 02:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:04:41 --> Input Class Initialized
INFO - 2016-12-12 02:04:41 --> Language Class Initialized
INFO - 2016-12-12 02:04:41 --> Loader Class Initialized
INFO - 2016-12-12 02:04:41 --> Database Driver Class Initialized
INFO - 2016-12-12 02:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:04:41 --> Controller Class Initialized
INFO - 2016-12-12 02:04:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:04:41 --> Final output sent to browser
DEBUG - 2016-12-12 02:04:41 --> Total execution time: 0.0130
INFO - 2016-12-12 02:09:41 --> Config Class Initialized
INFO - 2016-12-12 02:09:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:09:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:09:41 --> Utf8 Class Initialized
INFO - 2016-12-12 02:09:41 --> URI Class Initialized
DEBUG - 2016-12-12 02:09:41 --> No URI present. Default controller set.
INFO - 2016-12-12 02:09:41 --> Router Class Initialized
INFO - 2016-12-12 02:09:41 --> Output Class Initialized
INFO - 2016-12-12 02:09:41 --> Security Class Initialized
DEBUG - 2016-12-12 02:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:09:41 --> Input Class Initialized
INFO - 2016-12-12 02:09:41 --> Language Class Initialized
INFO - 2016-12-12 02:09:41 --> Loader Class Initialized
INFO - 2016-12-12 02:09:41 --> Database Driver Class Initialized
INFO - 2016-12-12 02:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:09:41 --> Controller Class Initialized
INFO - 2016-12-12 02:09:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:09:41 --> Final output sent to browser
DEBUG - 2016-12-12 02:09:41 --> Total execution time: 0.0134
INFO - 2016-12-12 02:09:42 --> Config Class Initialized
INFO - 2016-12-12 02:09:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:09:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:09:42 --> Utf8 Class Initialized
INFO - 2016-12-12 02:09:42 --> URI Class Initialized
INFO - 2016-12-12 02:09:42 --> Router Class Initialized
INFO - 2016-12-12 02:09:42 --> Output Class Initialized
INFO - 2016-12-12 02:09:42 --> Security Class Initialized
DEBUG - 2016-12-12 02:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:09:42 --> Input Class Initialized
INFO - 2016-12-12 02:09:42 --> Language Class Initialized
ERROR - 2016-12-12 02:09:42 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:09:42 --> Config Class Initialized
INFO - 2016-12-12 02:09:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:09:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:09:42 --> Utf8 Class Initialized
INFO - 2016-12-12 02:09:42 --> URI Class Initialized
INFO - 2016-12-12 02:09:42 --> Router Class Initialized
INFO - 2016-12-12 02:09:42 --> Output Class Initialized
INFO - 2016-12-12 02:09:42 --> Security Class Initialized
DEBUG - 2016-12-12 02:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:09:42 --> Input Class Initialized
INFO - 2016-12-12 02:09:42 --> Language Class Initialized
INFO - 2016-12-12 02:09:42 --> Loader Class Initialized
INFO - 2016-12-12 02:09:42 --> Database Driver Class Initialized
INFO - 2016-12-12 02:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:09:42 --> Controller Class Initialized
INFO - 2016-12-12 02:09:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:09:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:09:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:09:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:09:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:09:42 --> Final output sent to browser
DEBUG - 2016-12-12 02:09:42 --> Total execution time: 0.0128
INFO - 2016-12-12 02:09:58 --> Config Class Initialized
INFO - 2016-12-12 02:09:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:09:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:09:58 --> Utf8 Class Initialized
INFO - 2016-12-12 02:09:58 --> URI Class Initialized
DEBUG - 2016-12-12 02:09:58 --> No URI present. Default controller set.
INFO - 2016-12-12 02:09:58 --> Router Class Initialized
INFO - 2016-12-12 02:09:58 --> Output Class Initialized
INFO - 2016-12-12 02:09:58 --> Security Class Initialized
DEBUG - 2016-12-12 02:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:09:58 --> Input Class Initialized
INFO - 2016-12-12 02:09:58 --> Language Class Initialized
INFO - 2016-12-12 02:09:58 --> Loader Class Initialized
INFO - 2016-12-12 02:09:58 --> Database Driver Class Initialized
INFO - 2016-12-12 02:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:09:58 --> Controller Class Initialized
INFO - 2016-12-12 02:09:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:09:58 --> Final output sent to browser
DEBUG - 2016-12-12 02:09:58 --> Total execution time: 0.0167
INFO - 2016-12-12 02:10:18 --> Config Class Initialized
INFO - 2016-12-12 02:10:18 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:18 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:18 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:18 --> URI Class Initialized
INFO - 2016-12-12 02:10:18 --> Router Class Initialized
INFO - 2016-12-12 02:10:18 --> Output Class Initialized
INFO - 2016-12-12 02:10:18 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:18 --> Input Class Initialized
INFO - 2016-12-12 02:10:18 --> Language Class Initialized
INFO - 2016-12-12 02:10:18 --> Loader Class Initialized
INFO - 2016-12-12 02:10:18 --> Database Driver Class Initialized
INFO - 2016-12-12 02:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:10:18 --> Controller Class Initialized
INFO - 2016-12-12 02:10:18 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:10:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:10:18 --> Final output sent to browser
DEBUG - 2016-12-12 02:10:18 --> Total execution time: 0.0124
INFO - 2016-12-12 02:10:26 --> Config Class Initialized
INFO - 2016-12-12 02:10:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:26 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:26 --> URI Class Initialized
DEBUG - 2016-12-12 02:10:26 --> No URI present. Default controller set.
INFO - 2016-12-12 02:10:26 --> Router Class Initialized
INFO - 2016-12-12 02:10:26 --> Output Class Initialized
INFO - 2016-12-12 02:10:26 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:26 --> Input Class Initialized
INFO - 2016-12-12 02:10:26 --> Language Class Initialized
INFO - 2016-12-12 02:10:26 --> Loader Class Initialized
INFO - 2016-12-12 02:10:26 --> Database Driver Class Initialized
INFO - 2016-12-12 02:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:10:26 --> Controller Class Initialized
INFO - 2016-12-12 02:10:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:10:26 --> Final output sent to browser
DEBUG - 2016-12-12 02:10:26 --> Total execution time: 0.0130
INFO - 2016-12-12 02:10:27 --> Config Class Initialized
INFO - 2016-12-12 02:10:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:27 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:27 --> URI Class Initialized
INFO - 2016-12-12 02:10:27 --> Router Class Initialized
INFO - 2016-12-12 02:10:27 --> Output Class Initialized
INFO - 2016-12-12 02:10:27 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:27 --> Input Class Initialized
INFO - 2016-12-12 02:10:27 --> Language Class Initialized
ERROR - 2016-12-12 02:10:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:10:27 --> Config Class Initialized
INFO - 2016-12-12 02:10:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:27 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:27 --> URI Class Initialized
INFO - 2016-12-12 02:10:27 --> Router Class Initialized
INFO - 2016-12-12 02:10:27 --> Output Class Initialized
INFO - 2016-12-12 02:10:27 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:27 --> Input Class Initialized
INFO - 2016-12-12 02:10:27 --> Language Class Initialized
INFO - 2016-12-12 02:10:27 --> Loader Class Initialized
INFO - 2016-12-12 02:10:27 --> Database Driver Class Initialized
INFO - 2016-12-12 02:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:10:27 --> Controller Class Initialized
INFO - 2016-12-12 02:10:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:10:27 --> Final output sent to browser
DEBUG - 2016-12-12 02:10:27 --> Total execution time: 0.0132
INFO - 2016-12-12 02:10:36 --> Config Class Initialized
INFO - 2016-12-12 02:10:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:36 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:36 --> URI Class Initialized
DEBUG - 2016-12-12 02:10:36 --> No URI present. Default controller set.
INFO - 2016-12-12 02:10:36 --> Router Class Initialized
INFO - 2016-12-12 02:10:36 --> Output Class Initialized
INFO - 2016-12-12 02:10:36 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:36 --> Input Class Initialized
INFO - 2016-12-12 02:10:36 --> Language Class Initialized
ERROR - 2016-12-12 02:10:36 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:36 --> Config Class Initialized
INFO - 2016-12-12 02:10:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:36 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:36 --> URI Class Initialized
INFO - 2016-12-12 02:10:36 --> Router Class Initialized
INFO - 2016-12-12 02:10:36 --> Output Class Initialized
INFO - 2016-12-12 02:10:36 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:36 --> Input Class Initialized
INFO - 2016-12-12 02:10:36 --> Language Class Initialized
ERROR - 2016-12-12 02:10:36 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:41 --> Config Class Initialized
INFO - 2016-12-12 02:10:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:41 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:41 --> URI Class Initialized
INFO - 2016-12-12 02:10:41 --> Router Class Initialized
INFO - 2016-12-12 02:10:41 --> Output Class Initialized
INFO - 2016-12-12 02:10:41 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:41 --> Input Class Initialized
INFO - 2016-12-12 02:10:41 --> Language Class Initialized
ERROR - 2016-12-12 02:10:41 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:42 --> Config Class Initialized
INFO - 2016-12-12 02:10:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:42 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:42 --> URI Class Initialized
INFO - 2016-12-12 02:10:42 --> Router Class Initialized
INFO - 2016-12-12 02:10:42 --> Output Class Initialized
INFO - 2016-12-12 02:10:42 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:42 --> Input Class Initialized
INFO - 2016-12-12 02:10:42 --> Language Class Initialized
ERROR - 2016-12-12 02:10:42 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:50 --> Config Class Initialized
INFO - 2016-12-12 02:10:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:50 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:50 --> URI Class Initialized
DEBUG - 2016-12-12 02:10:50 --> No URI present. Default controller set.
INFO - 2016-12-12 02:10:50 --> Router Class Initialized
INFO - 2016-12-12 02:10:50 --> Output Class Initialized
INFO - 2016-12-12 02:10:50 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:50 --> Input Class Initialized
INFO - 2016-12-12 02:10:50 --> Language Class Initialized
ERROR - 2016-12-12 02:10:50 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:50 --> Config Class Initialized
INFO - 2016-12-12 02:10:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:50 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:50 --> URI Class Initialized
INFO - 2016-12-12 02:10:50 --> Router Class Initialized
INFO - 2016-12-12 02:10:50 --> Output Class Initialized
INFO - 2016-12-12 02:10:50 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:50 --> Input Class Initialized
INFO - 2016-12-12 02:10:50 --> Language Class Initialized
ERROR - 2016-12-12 02:10:50 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:51 --> Config Class Initialized
INFO - 2016-12-12 02:10:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:51 --> URI Class Initialized
DEBUG - 2016-12-12 02:10:51 --> No URI present. Default controller set.
INFO - 2016-12-12 02:10:51 --> Router Class Initialized
INFO - 2016-12-12 02:10:51 --> Output Class Initialized
INFO - 2016-12-12 02:10:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:51 --> Input Class Initialized
INFO - 2016-12-12 02:10:51 --> Language Class Initialized
ERROR - 2016-12-12 02:10:51 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:51 --> Config Class Initialized
INFO - 2016-12-12 02:10:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:51 --> URI Class Initialized
INFO - 2016-12-12 02:10:51 --> Router Class Initialized
INFO - 2016-12-12 02:10:51 --> Output Class Initialized
INFO - 2016-12-12 02:10:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:51 --> Input Class Initialized
INFO - 2016-12-12 02:10:51 --> Language Class Initialized
ERROR - 2016-12-12 02:10:51 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:51 --> Config Class Initialized
INFO - 2016-12-12 02:10:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:51 --> URI Class Initialized
DEBUG - 2016-12-12 02:10:51 --> No URI present. Default controller set.
INFO - 2016-12-12 02:10:51 --> Router Class Initialized
INFO - 2016-12-12 02:10:51 --> Output Class Initialized
INFO - 2016-12-12 02:10:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:51 --> Input Class Initialized
INFO - 2016-12-12 02:10:51 --> Language Class Initialized
ERROR - 2016-12-12 02:10:51 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:51 --> Config Class Initialized
INFO - 2016-12-12 02:10:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:51 --> URI Class Initialized
INFO - 2016-12-12 02:10:51 --> Router Class Initialized
INFO - 2016-12-12 02:10:51 --> Output Class Initialized
INFO - 2016-12-12 02:10:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:51 --> Input Class Initialized
INFO - 2016-12-12 02:10:51 --> Language Class Initialized
ERROR - 2016-12-12 02:10:51 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:51 --> Config Class Initialized
INFO - 2016-12-12 02:10:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:51 --> URI Class Initialized
DEBUG - 2016-12-12 02:10:51 --> No URI present. Default controller set.
INFO - 2016-12-12 02:10:51 --> Router Class Initialized
INFO - 2016-12-12 02:10:51 --> Output Class Initialized
INFO - 2016-12-12 02:10:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:51 --> Input Class Initialized
INFO - 2016-12-12 02:10:51 --> Language Class Initialized
ERROR - 2016-12-12 02:10:51 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:10:52 --> Config Class Initialized
INFO - 2016-12-12 02:10:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:10:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:10:52 --> Utf8 Class Initialized
INFO - 2016-12-12 02:10:52 --> URI Class Initialized
INFO - 2016-12-12 02:10:52 --> Router Class Initialized
INFO - 2016-12-12 02:10:52 --> Output Class Initialized
INFO - 2016-12-12 02:10:52 --> Security Class Initialized
DEBUG - 2016-12-12 02:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:10:52 --> Input Class Initialized
INFO - 2016-12-12 02:10:52 --> Language Class Initialized
ERROR - 2016-12-12 02:10:52 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 156
INFO - 2016-12-12 02:11:01 --> Config Class Initialized
INFO - 2016-12-12 02:11:01 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:11:01 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:11:01 --> Utf8 Class Initialized
INFO - 2016-12-12 02:11:01 --> URI Class Initialized
INFO - 2016-12-12 02:11:01 --> Router Class Initialized
INFO - 2016-12-12 02:11:01 --> Output Class Initialized
INFO - 2016-12-12 02:11:01 --> Security Class Initialized
DEBUG - 2016-12-12 02:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:11:01 --> Input Class Initialized
INFO - 2016-12-12 02:11:01 --> Language Class Initialized
INFO - 2016-12-12 02:11:01 --> Loader Class Initialized
INFO - 2016-12-12 02:11:01 --> Database Driver Class Initialized
INFO - 2016-12-12 02:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:11:01 --> Controller Class Initialized
INFO - 2016-12-12 02:11:01 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:11:01 --> Final output sent to browser
DEBUG - 2016-12-12 02:11:01 --> Total execution time: 0.0141
INFO - 2016-12-12 02:11:02 --> Config Class Initialized
INFO - 2016-12-12 02:11:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:11:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:11:02 --> Utf8 Class Initialized
INFO - 2016-12-12 02:11:02 --> URI Class Initialized
DEBUG - 2016-12-12 02:11:02 --> No URI present. Default controller set.
INFO - 2016-12-12 02:11:02 --> Router Class Initialized
INFO - 2016-12-12 02:11:02 --> Output Class Initialized
INFO - 2016-12-12 02:11:02 --> Security Class Initialized
DEBUG - 2016-12-12 02:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:11:02 --> Input Class Initialized
INFO - 2016-12-12 02:11:02 --> Language Class Initialized
INFO - 2016-12-12 02:11:02 --> Loader Class Initialized
INFO - 2016-12-12 02:11:02 --> Database Driver Class Initialized
INFO - 2016-12-12 02:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:11:02 --> Controller Class Initialized
INFO - 2016-12-12 02:11:02 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:11:02 --> Final output sent to browser
DEBUG - 2016-12-12 02:11:02 --> Total execution time: 0.0134
INFO - 2016-12-12 02:11:03 --> Config Class Initialized
INFO - 2016-12-12 02:11:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:11:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:11:03 --> Utf8 Class Initialized
INFO - 2016-12-12 02:11:03 --> URI Class Initialized
INFO - 2016-12-12 02:11:03 --> Router Class Initialized
INFO - 2016-12-12 02:11:03 --> Output Class Initialized
INFO - 2016-12-12 02:11:03 --> Security Class Initialized
DEBUG - 2016-12-12 02:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:11:03 --> Input Class Initialized
INFO - 2016-12-12 02:11:03 --> Language Class Initialized
ERROR - 2016-12-12 02:11:03 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:11:03 --> Config Class Initialized
INFO - 2016-12-12 02:11:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:11:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:11:03 --> Utf8 Class Initialized
INFO - 2016-12-12 02:11:03 --> URI Class Initialized
INFO - 2016-12-12 02:11:03 --> Router Class Initialized
INFO - 2016-12-12 02:11:03 --> Output Class Initialized
INFO - 2016-12-12 02:11:03 --> Security Class Initialized
DEBUG - 2016-12-12 02:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:11:03 --> Input Class Initialized
INFO - 2016-12-12 02:11:03 --> Language Class Initialized
INFO - 2016-12-12 02:11:03 --> Loader Class Initialized
INFO - 2016-12-12 02:11:03 --> Database Driver Class Initialized
INFO - 2016-12-12 02:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:11:03 --> Controller Class Initialized
INFO - 2016-12-12 02:11:03 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:11:03 --> Final output sent to browser
DEBUG - 2016-12-12 02:11:03 --> Total execution time: 0.0136
INFO - 2016-12-12 02:11:14 --> Config Class Initialized
INFO - 2016-12-12 02:11:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:11:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:11:14 --> Utf8 Class Initialized
INFO - 2016-12-12 02:11:14 --> URI Class Initialized
INFO - 2016-12-12 02:11:14 --> Router Class Initialized
INFO - 2016-12-12 02:11:14 --> Output Class Initialized
INFO - 2016-12-12 02:11:14 --> Security Class Initialized
DEBUG - 2016-12-12 02:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:11:14 --> Input Class Initialized
INFO - 2016-12-12 02:11:14 --> Language Class Initialized
INFO - 2016-12-12 02:11:14 --> Loader Class Initialized
INFO - 2016-12-12 02:11:14 --> Database Driver Class Initialized
INFO - 2016-12-12 02:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:11:14 --> Controller Class Initialized
INFO - 2016-12-12 02:11:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:11:14 --> Final output sent to browser
DEBUG - 2016-12-12 02:11:14 --> Total execution time: 0.0142
INFO - 2016-12-12 02:11:59 --> Config Class Initialized
INFO - 2016-12-12 02:11:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:11:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:11:59 --> Utf8 Class Initialized
INFO - 2016-12-12 02:11:59 --> URI Class Initialized
DEBUG - 2016-12-12 02:11:59 --> No URI present. Default controller set.
INFO - 2016-12-12 02:11:59 --> Router Class Initialized
INFO - 2016-12-12 02:11:59 --> Output Class Initialized
INFO - 2016-12-12 02:11:59 --> Security Class Initialized
DEBUG - 2016-12-12 02:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:11:59 --> Input Class Initialized
INFO - 2016-12-12 02:11:59 --> Language Class Initialized
INFO - 2016-12-12 02:11:59 --> Loader Class Initialized
INFO - 2016-12-12 02:11:59 --> Database Driver Class Initialized
INFO - 2016-12-12 02:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:11:59 --> Controller Class Initialized
INFO - 2016-12-12 02:11:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:11:59 --> Final output sent to browser
DEBUG - 2016-12-12 02:11:59 --> Total execution time: 0.2380
INFO - 2016-12-12 02:12:13 --> Config Class Initialized
INFO - 2016-12-12 02:12:13 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:12:13 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:12:13 --> Utf8 Class Initialized
INFO - 2016-12-12 02:12:13 --> URI Class Initialized
INFO - 2016-12-12 02:12:13 --> Router Class Initialized
INFO - 2016-12-12 02:12:13 --> Output Class Initialized
INFO - 2016-12-12 02:12:13 --> Security Class Initialized
DEBUG - 2016-12-12 02:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:12:13 --> Input Class Initialized
INFO - 2016-12-12 02:12:13 --> Language Class Initialized
INFO - 2016-12-12 02:12:13 --> Loader Class Initialized
INFO - 2016-12-12 02:12:13 --> Database Driver Class Initialized
INFO - 2016-12-12 02:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:12:13 --> Controller Class Initialized
INFO - 2016-12-12 02:12:13 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:12:13 --> Final output sent to browser
DEBUG - 2016-12-12 02:12:13 --> Total execution time: 0.0129
INFO - 2016-12-12 02:12:21 --> Config Class Initialized
INFO - 2016-12-12 02:12:21 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:12:21 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:12:21 --> Utf8 Class Initialized
INFO - 2016-12-12 02:12:21 --> URI Class Initialized
INFO - 2016-12-12 02:12:21 --> Router Class Initialized
INFO - 2016-12-12 02:12:21 --> Output Class Initialized
INFO - 2016-12-12 02:12:21 --> Security Class Initialized
DEBUG - 2016-12-12 02:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:12:21 --> Input Class Initialized
INFO - 2016-12-12 02:12:21 --> Language Class Initialized
INFO - 2016-12-12 02:12:21 --> Loader Class Initialized
INFO - 2016-12-12 02:12:21 --> Database Driver Class Initialized
INFO - 2016-12-12 02:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:12:21 --> Controller Class Initialized
INFO - 2016-12-12 02:12:21 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:12:21 --> Final output sent to browser
DEBUG - 2016-12-12 02:12:21 --> Total execution time: 0.0127
INFO - 2016-12-12 02:12:53 --> Config Class Initialized
INFO - 2016-12-12 02:12:53 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:12:53 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:12:53 --> Utf8 Class Initialized
INFO - 2016-12-12 02:12:53 --> URI Class Initialized
INFO - 2016-12-12 02:12:53 --> Router Class Initialized
INFO - 2016-12-12 02:12:53 --> Output Class Initialized
INFO - 2016-12-12 02:12:53 --> Security Class Initialized
DEBUG - 2016-12-12 02:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:12:53 --> Input Class Initialized
INFO - 2016-12-12 02:12:53 --> Language Class Initialized
INFO - 2016-12-12 02:12:53 --> Loader Class Initialized
INFO - 2016-12-12 02:12:53 --> Database Driver Class Initialized
INFO - 2016-12-12 02:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:12:53 --> Controller Class Initialized
INFO - 2016-12-12 02:12:53 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:12:53 --> Final output sent to browser
DEBUG - 2016-12-12 02:12:53 --> Total execution time: 0.1222
INFO - 2016-12-12 02:12:54 --> Config Class Initialized
INFO - 2016-12-12 02:12:54 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:12:54 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:12:54 --> Utf8 Class Initialized
INFO - 2016-12-12 02:12:54 --> URI Class Initialized
INFO - 2016-12-12 02:12:54 --> Router Class Initialized
INFO - 2016-12-12 02:12:54 --> Output Class Initialized
INFO - 2016-12-12 02:12:54 --> Security Class Initialized
DEBUG - 2016-12-12 02:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:12:54 --> Input Class Initialized
INFO - 2016-12-12 02:12:54 --> Language Class Initialized
INFO - 2016-12-12 02:12:54 --> Loader Class Initialized
INFO - 2016-12-12 02:12:54 --> Database Driver Class Initialized
INFO - 2016-12-12 02:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:12:54 --> Controller Class Initialized
INFO - 2016-12-12 02:12:54 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:12:54 --> Final output sent to browser
DEBUG - 2016-12-12 02:12:54 --> Total execution time: 0.0125
INFO - 2016-12-12 02:13:03 --> Config Class Initialized
INFO - 2016-12-12 02:13:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:03 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:03 --> URI Class Initialized
INFO - 2016-12-12 02:13:03 --> Router Class Initialized
INFO - 2016-12-12 02:13:03 --> Output Class Initialized
INFO - 2016-12-12 02:13:03 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:03 --> Input Class Initialized
INFO - 2016-12-12 02:13:03 --> Language Class Initialized
INFO - 2016-12-12 02:13:03 --> Loader Class Initialized
INFO - 2016-12-12 02:13:03 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:03 --> Controller Class Initialized
INFO - 2016-12-12 02:13:03 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:03 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:03 --> Total execution time: 0.0145
INFO - 2016-12-12 02:13:03 --> Config Class Initialized
INFO - 2016-12-12 02:13:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:03 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:03 --> URI Class Initialized
INFO - 2016-12-12 02:13:03 --> Router Class Initialized
INFO - 2016-12-12 02:13:03 --> Output Class Initialized
INFO - 2016-12-12 02:13:03 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:03 --> Input Class Initialized
INFO - 2016-12-12 02:13:03 --> Language Class Initialized
INFO - 2016-12-12 02:13:03 --> Loader Class Initialized
INFO - 2016-12-12 02:13:03 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:03 --> Controller Class Initialized
INFO - 2016-12-12 02:13:03 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:13:03 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:03 --> Total execution time: 0.0135
INFO - 2016-12-12 02:13:35 --> Config Class Initialized
INFO - 2016-12-12 02:13:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:35 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:35 --> URI Class Initialized
DEBUG - 2016-12-12 02:13:35 --> No URI present. Default controller set.
INFO - 2016-12-12 02:13:35 --> Router Class Initialized
INFO - 2016-12-12 02:13:35 --> Output Class Initialized
INFO - 2016-12-12 02:13:35 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:35 --> Input Class Initialized
INFO - 2016-12-12 02:13:35 --> Language Class Initialized
INFO - 2016-12-12 02:13:35 --> Loader Class Initialized
INFO - 2016-12-12 02:13:35 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:35 --> Controller Class Initialized
INFO - 2016-12-12 02:13:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:13:35 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:35 --> Total execution time: 0.0130
INFO - 2016-12-12 02:13:35 --> Config Class Initialized
INFO - 2016-12-12 02:13:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:35 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:35 --> URI Class Initialized
INFO - 2016-12-12 02:13:35 --> Router Class Initialized
INFO - 2016-12-12 02:13:35 --> Output Class Initialized
INFO - 2016-12-12 02:13:35 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:35 --> Input Class Initialized
INFO - 2016-12-12 02:13:35 --> Language Class Initialized
ERROR - 2016-12-12 02:13:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:13:35 --> Config Class Initialized
INFO - 2016-12-12 02:13:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:35 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:35 --> URI Class Initialized
INFO - 2016-12-12 02:13:35 --> Router Class Initialized
INFO - 2016-12-12 02:13:35 --> Output Class Initialized
INFO - 2016-12-12 02:13:35 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:35 --> Input Class Initialized
INFO - 2016-12-12 02:13:35 --> Language Class Initialized
INFO - 2016-12-12 02:13:35 --> Loader Class Initialized
INFO - 2016-12-12 02:13:35 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:35 --> Controller Class Initialized
INFO - 2016-12-12 02:13:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:13:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:13:35 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:35 --> Total execution time: 0.0134
INFO - 2016-12-12 02:13:46 --> Config Class Initialized
INFO - 2016-12-12 02:13:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:46 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:46 --> URI Class Initialized
DEBUG - 2016-12-12 02:13:46 --> No URI present. Default controller set.
INFO - 2016-12-12 02:13:46 --> Router Class Initialized
INFO - 2016-12-12 02:13:46 --> Output Class Initialized
INFO - 2016-12-12 02:13:46 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:46 --> Input Class Initialized
INFO - 2016-12-12 02:13:46 --> Language Class Initialized
INFO - 2016-12-12 02:13:46 --> Loader Class Initialized
INFO - 2016-12-12 02:13:46 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:46 --> Controller Class Initialized
INFO - 2016-12-12 02:13:46 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:13:46 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:46 --> Total execution time: 0.0127
INFO - 2016-12-12 02:13:46 --> Config Class Initialized
INFO - 2016-12-12 02:13:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:46 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:46 --> URI Class Initialized
INFO - 2016-12-12 02:13:46 --> Router Class Initialized
INFO - 2016-12-12 02:13:47 --> Output Class Initialized
INFO - 2016-12-12 02:13:47 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:47 --> Input Class Initialized
INFO - 2016-12-12 02:13:47 --> Language Class Initialized
ERROR - 2016-12-12 02:13:47 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:13:47 --> Config Class Initialized
INFO - 2016-12-12 02:13:47 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:47 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:47 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:47 --> URI Class Initialized
INFO - 2016-12-12 02:13:47 --> Router Class Initialized
INFO - 2016-12-12 02:13:47 --> Output Class Initialized
INFO - 2016-12-12 02:13:47 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:47 --> Input Class Initialized
INFO - 2016-12-12 02:13:47 --> Language Class Initialized
INFO - 2016-12-12 02:13:47 --> Loader Class Initialized
INFO - 2016-12-12 02:13:47 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:47 --> Controller Class Initialized
INFO - 2016-12-12 02:13:47 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:13:47 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:47 --> Total execution time: 0.0416
INFO - 2016-12-12 02:13:57 --> Config Class Initialized
INFO - 2016-12-12 02:13:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:57 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:57 --> URI Class Initialized
DEBUG - 2016-12-12 02:13:57 --> No URI present. Default controller set.
INFO - 2016-12-12 02:13:57 --> Router Class Initialized
INFO - 2016-12-12 02:13:57 --> Output Class Initialized
INFO - 2016-12-12 02:13:57 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:57 --> Input Class Initialized
INFO - 2016-12-12 02:13:57 --> Language Class Initialized
INFO - 2016-12-12 02:13:57 --> Loader Class Initialized
INFO - 2016-12-12 02:13:57 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:57 --> Controller Class Initialized
INFO - 2016-12-12 02:13:57 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:13:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:13:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:13:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:13:57 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:57 --> Total execution time: 0.0135
INFO - 2016-12-12 02:13:58 --> Config Class Initialized
INFO - 2016-12-12 02:13:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:58 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:58 --> URI Class Initialized
INFO - 2016-12-12 02:13:58 --> Router Class Initialized
INFO - 2016-12-12 02:13:58 --> Output Class Initialized
INFO - 2016-12-12 02:13:58 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:58 --> Input Class Initialized
INFO - 2016-12-12 02:13:58 --> Language Class Initialized
ERROR - 2016-12-12 02:13:58 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:13:58 --> Config Class Initialized
INFO - 2016-12-12 02:13:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:13:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:13:58 --> Utf8 Class Initialized
INFO - 2016-12-12 02:13:58 --> URI Class Initialized
INFO - 2016-12-12 02:13:58 --> Router Class Initialized
INFO - 2016-12-12 02:13:58 --> Output Class Initialized
INFO - 2016-12-12 02:13:58 --> Security Class Initialized
DEBUG - 2016-12-12 02:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:13:58 --> Input Class Initialized
INFO - 2016-12-12 02:13:58 --> Language Class Initialized
INFO - 2016-12-12 02:13:58 --> Loader Class Initialized
INFO - 2016-12-12 02:13:58 --> Database Driver Class Initialized
INFO - 2016-12-12 02:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:13:58 --> Controller Class Initialized
INFO - 2016-12-12 02:13:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:13:58 --> Final output sent to browser
DEBUG - 2016-12-12 02:13:58 --> Total execution time: 0.0145
INFO - 2016-12-12 02:14:06 --> Config Class Initialized
INFO - 2016-12-12 02:14:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:06 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:06 --> URI Class Initialized
DEBUG - 2016-12-12 02:14:06 --> No URI present. Default controller set.
INFO - 2016-12-12 02:14:06 --> Router Class Initialized
INFO - 2016-12-12 02:14:06 --> Output Class Initialized
INFO - 2016-12-12 02:14:06 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:06 --> Input Class Initialized
INFO - 2016-12-12 02:14:06 --> Language Class Initialized
INFO - 2016-12-12 02:14:06 --> Loader Class Initialized
INFO - 2016-12-12 02:14:06 --> Database Driver Class Initialized
INFO - 2016-12-12 02:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:14:06 --> Controller Class Initialized
INFO - 2016-12-12 02:14:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:14:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:14:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:14:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:14:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:14:06 --> Final output sent to browser
DEBUG - 2016-12-12 02:14:06 --> Total execution time: 0.0130
INFO - 2016-12-12 02:14:07 --> Config Class Initialized
INFO - 2016-12-12 02:14:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:07 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:07 --> URI Class Initialized
INFO - 2016-12-12 02:14:07 --> Router Class Initialized
INFO - 2016-12-12 02:14:07 --> Output Class Initialized
INFO - 2016-12-12 02:14:07 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:07 --> Input Class Initialized
INFO - 2016-12-12 02:14:07 --> Language Class Initialized
ERROR - 2016-12-12 02:14:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:14:07 --> Config Class Initialized
INFO - 2016-12-12 02:14:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:07 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:07 --> URI Class Initialized
INFO - 2016-12-12 02:14:07 --> Router Class Initialized
INFO - 2016-12-12 02:14:07 --> Output Class Initialized
INFO - 2016-12-12 02:14:07 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:07 --> Input Class Initialized
INFO - 2016-12-12 02:14:07 --> Language Class Initialized
INFO - 2016-12-12 02:14:07 --> Loader Class Initialized
INFO - 2016-12-12 02:14:07 --> Database Driver Class Initialized
INFO - 2016-12-12 02:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:14:07 --> Controller Class Initialized
INFO - 2016-12-12 02:14:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:14:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:14:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:14:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:14:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:14:07 --> Final output sent to browser
DEBUG - 2016-12-12 02:14:07 --> Total execution time: 0.0130
INFO - 2016-12-12 02:14:20 --> Config Class Initialized
INFO - 2016-12-12 02:14:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:20 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:20 --> URI Class Initialized
INFO - 2016-12-12 02:14:20 --> Router Class Initialized
INFO - 2016-12-12 02:14:20 --> Output Class Initialized
INFO - 2016-12-12 02:14:20 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:20 --> Input Class Initialized
INFO - 2016-12-12 02:14:20 --> Language Class Initialized
INFO - 2016-12-12 02:14:20 --> Loader Class Initialized
INFO - 2016-12-12 02:14:20 --> Database Driver Class Initialized
INFO - 2016-12-12 02:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:14:20 --> Controller Class Initialized
INFO - 2016-12-12 02:14:20 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:14:20 --> Final output sent to browser
DEBUG - 2016-12-12 02:14:20 --> Total execution time: 0.0128
INFO - 2016-12-12 02:14:20 --> Config Class Initialized
INFO - 2016-12-12 02:14:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:20 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:20 --> URI Class Initialized
INFO - 2016-12-12 02:14:20 --> Router Class Initialized
INFO - 2016-12-12 02:14:20 --> Output Class Initialized
INFO - 2016-12-12 02:14:20 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:20 --> Input Class Initialized
INFO - 2016-12-12 02:14:20 --> Language Class Initialized
INFO - 2016-12-12 02:14:20 --> Loader Class Initialized
INFO - 2016-12-12 02:14:20 --> Database Driver Class Initialized
INFO - 2016-12-12 02:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:14:20 --> Controller Class Initialized
INFO - 2016-12-12 02:14:20 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:14:20 --> Final output sent to browser
DEBUG - 2016-12-12 02:14:20 --> Total execution time: 0.0132
INFO - 2016-12-12 02:14:35 --> Config Class Initialized
INFO - 2016-12-12 02:14:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:35 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:35 --> URI Class Initialized
INFO - 2016-12-12 02:14:35 --> Router Class Initialized
INFO - 2016-12-12 02:14:35 --> Output Class Initialized
INFO - 2016-12-12 02:14:35 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:35 --> Input Class Initialized
INFO - 2016-12-12 02:14:35 --> Language Class Initialized
INFO - 2016-12-12 02:14:35 --> Loader Class Initialized
INFO - 2016-12-12 02:14:35 --> Database Driver Class Initialized
INFO - 2016-12-12 02:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:14:35 --> Controller Class Initialized
INFO - 2016-12-12 02:14:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:14:35 --> Final output sent to browser
DEBUG - 2016-12-12 02:14:35 --> Total execution time: 0.0128
INFO - 2016-12-12 02:14:36 --> Config Class Initialized
INFO - 2016-12-12 02:14:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:36 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:36 --> URI Class Initialized
INFO - 2016-12-12 02:14:36 --> Router Class Initialized
INFO - 2016-12-12 02:14:36 --> Output Class Initialized
INFO - 2016-12-12 02:14:36 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:36 --> Input Class Initialized
INFO - 2016-12-12 02:14:36 --> Language Class Initialized
ERROR - 2016-12-12 02:14:36 --> 404 Page Not Found: User_pagina_inicial_controller/index
INFO - 2016-12-12 02:14:37 --> Config Class Initialized
INFO - 2016-12-12 02:14:37 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:14:37 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:14:37 --> Utf8 Class Initialized
INFO - 2016-12-12 02:14:37 --> URI Class Initialized
INFO - 2016-12-12 02:14:37 --> Router Class Initialized
INFO - 2016-12-12 02:14:37 --> Output Class Initialized
INFO - 2016-12-12 02:14:37 --> Security Class Initialized
DEBUG - 2016-12-12 02:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:14:37 --> Input Class Initialized
INFO - 2016-12-12 02:14:37 --> Language Class Initialized
INFO - 2016-12-12 02:14:37 --> Loader Class Initialized
INFO - 2016-12-12 02:14:37 --> Database Driver Class Initialized
INFO - 2016-12-12 02:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:14:37 --> Controller Class Initialized
INFO - 2016-12-12 02:14:37 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:14:37 --> Final output sent to browser
DEBUG - 2016-12-12 02:14:37 --> Total execution time: 0.0199
INFO - 2016-12-12 02:15:06 --> Config Class Initialized
INFO - 2016-12-12 02:15:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:15:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:15:06 --> Utf8 Class Initialized
INFO - 2016-12-12 02:15:06 --> URI Class Initialized
INFO - 2016-12-12 02:15:06 --> Router Class Initialized
INFO - 2016-12-12 02:15:06 --> Output Class Initialized
INFO - 2016-12-12 02:15:06 --> Security Class Initialized
DEBUG - 2016-12-12 02:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:15:06 --> Input Class Initialized
INFO - 2016-12-12 02:15:06 --> Language Class Initialized
ERROR - 2016-12-12 02:15:06 --> 404 Page Not Found: User_pagina_inicial_controller/send_mail
INFO - 2016-12-12 02:15:37 --> Config Class Initialized
INFO - 2016-12-12 02:15:37 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:15:37 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:15:37 --> Utf8 Class Initialized
INFO - 2016-12-12 02:15:37 --> URI Class Initialized
DEBUG - 2016-12-12 02:15:37 --> No URI present. Default controller set.
INFO - 2016-12-12 02:15:37 --> Router Class Initialized
INFO - 2016-12-12 02:15:37 --> Output Class Initialized
INFO - 2016-12-12 02:15:37 --> Security Class Initialized
DEBUG - 2016-12-12 02:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:15:37 --> Input Class Initialized
INFO - 2016-12-12 02:15:37 --> Language Class Initialized
INFO - 2016-12-12 02:15:37 --> Loader Class Initialized
INFO - 2016-12-12 02:15:37 --> Database Driver Class Initialized
INFO - 2016-12-12 02:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:15:37 --> Controller Class Initialized
INFO - 2016-12-12 02:15:37 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:15:37 --> Final output sent to browser
DEBUG - 2016-12-12 02:15:37 --> Total execution time: 0.0130
INFO - 2016-12-12 02:15:37 --> Config Class Initialized
INFO - 2016-12-12 02:15:37 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:15:37 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:15:37 --> Utf8 Class Initialized
INFO - 2016-12-12 02:15:37 --> URI Class Initialized
INFO - 2016-12-12 02:15:37 --> Router Class Initialized
INFO - 2016-12-12 02:15:37 --> Output Class Initialized
INFO - 2016-12-12 02:15:37 --> Security Class Initialized
DEBUG - 2016-12-12 02:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:15:37 --> Input Class Initialized
INFO - 2016-12-12 02:15:37 --> Language Class Initialized
ERROR - 2016-12-12 02:15:37 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:15:38 --> Config Class Initialized
INFO - 2016-12-12 02:15:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:15:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:15:38 --> Utf8 Class Initialized
INFO - 2016-12-12 02:15:38 --> URI Class Initialized
INFO - 2016-12-12 02:15:38 --> Router Class Initialized
INFO - 2016-12-12 02:15:38 --> Output Class Initialized
INFO - 2016-12-12 02:15:38 --> Security Class Initialized
DEBUG - 2016-12-12 02:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:15:38 --> Input Class Initialized
INFO - 2016-12-12 02:15:38 --> Language Class Initialized
INFO - 2016-12-12 02:15:38 --> Loader Class Initialized
INFO - 2016-12-12 02:15:38 --> Database Driver Class Initialized
INFO - 2016-12-12 02:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:15:38 --> Controller Class Initialized
INFO - 2016-12-12 02:15:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:15:38 --> Final output sent to browser
DEBUG - 2016-12-12 02:15:38 --> Total execution time: 0.0131
INFO - 2016-12-12 02:15:42 --> Config Class Initialized
INFO - 2016-12-12 02:15:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:15:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:15:42 --> Utf8 Class Initialized
INFO - 2016-12-12 02:15:42 --> URI Class Initialized
INFO - 2016-12-12 02:15:42 --> Router Class Initialized
INFO - 2016-12-12 02:15:42 --> Output Class Initialized
INFO - 2016-12-12 02:15:42 --> Security Class Initialized
DEBUG - 2016-12-12 02:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:15:42 --> Input Class Initialized
INFO - 2016-12-12 02:15:42 --> Language Class Initialized
INFO - 2016-12-12 02:15:42 --> Loader Class Initialized
INFO - 2016-12-12 02:15:42 --> Database Driver Class Initialized
INFO - 2016-12-12 02:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:15:42 --> Controller Class Initialized
INFO - 2016-12-12 02:15:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:15:42 --> Email Class Initialized
INFO - 2016-12-12 02:15:43 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-12 02:15:43 --> Final output sent to browser
DEBUG - 2016-12-12 02:15:43 --> Total execution time: 0.3248
INFO - 2016-12-12 02:16:54 --> Config Class Initialized
INFO - 2016-12-12 02:16:54 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:16:54 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:16:54 --> Utf8 Class Initialized
INFO - 2016-12-12 02:16:54 --> URI Class Initialized
DEBUG - 2016-12-12 02:16:54 --> No URI present. Default controller set.
INFO - 2016-12-12 02:16:54 --> Router Class Initialized
INFO - 2016-12-12 02:16:54 --> Output Class Initialized
INFO - 2016-12-12 02:16:54 --> Security Class Initialized
DEBUG - 2016-12-12 02:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:16:54 --> Input Class Initialized
INFO - 2016-12-12 02:16:54 --> Language Class Initialized
INFO - 2016-12-12 02:16:54 --> Loader Class Initialized
INFO - 2016-12-12 02:16:54 --> Database Driver Class Initialized
INFO - 2016-12-12 02:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:16:54 --> Controller Class Initialized
INFO - 2016-12-12 02:16:54 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:16:54 --> Final output sent to browser
DEBUG - 2016-12-12 02:16:54 --> Total execution time: 0.0134
INFO - 2016-12-12 02:17:16 --> Config Class Initialized
INFO - 2016-12-12 02:17:16 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:17:16 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:17:16 --> Utf8 Class Initialized
INFO - 2016-12-12 02:17:16 --> URI Class Initialized
INFO - 2016-12-12 02:17:16 --> Router Class Initialized
INFO - 2016-12-12 02:17:16 --> Output Class Initialized
INFO - 2016-12-12 02:17:16 --> Security Class Initialized
DEBUG - 2016-12-12 02:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:17:16 --> Input Class Initialized
INFO - 2016-12-12 02:17:16 --> Language Class Initialized
INFO - 2016-12-12 02:17:16 --> Loader Class Initialized
INFO - 2016-12-12 02:17:16 --> Database Driver Class Initialized
INFO - 2016-12-12 02:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:17:16 --> Controller Class Initialized
INFO - 2016-12-12 02:17:16 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:17:16 --> Final output sent to browser
DEBUG - 2016-12-12 02:17:16 --> Total execution time: 0.0126
INFO - 2016-12-12 02:18:38 --> Config Class Initialized
INFO - 2016-12-12 02:18:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:18:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:18:38 --> Utf8 Class Initialized
INFO - 2016-12-12 02:18:38 --> URI Class Initialized
DEBUG - 2016-12-12 02:18:38 --> No URI present. Default controller set.
INFO - 2016-12-12 02:18:38 --> Router Class Initialized
INFO - 2016-12-12 02:18:38 --> Output Class Initialized
INFO - 2016-12-12 02:18:38 --> Security Class Initialized
DEBUG - 2016-12-12 02:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:18:38 --> Input Class Initialized
INFO - 2016-12-12 02:18:38 --> Language Class Initialized
INFO - 2016-12-12 02:18:38 --> Loader Class Initialized
INFO - 2016-12-12 02:18:38 --> Database Driver Class Initialized
INFO - 2016-12-12 02:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:18:38 --> Controller Class Initialized
INFO - 2016-12-12 02:18:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:18:38 --> Final output sent to browser
DEBUG - 2016-12-12 02:18:38 --> Total execution time: 0.0133
INFO - 2016-12-12 02:18:47 --> Config Class Initialized
INFO - 2016-12-12 02:18:47 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:18:47 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:18:47 --> Utf8 Class Initialized
INFO - 2016-12-12 02:18:47 --> URI Class Initialized
INFO - 2016-12-12 02:18:47 --> Router Class Initialized
INFO - 2016-12-12 02:18:47 --> Output Class Initialized
INFO - 2016-12-12 02:18:47 --> Security Class Initialized
DEBUG - 2016-12-12 02:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:18:47 --> Input Class Initialized
INFO - 2016-12-12 02:18:47 --> Language Class Initialized
INFO - 2016-12-12 02:18:47 --> Loader Class Initialized
INFO - 2016-12-12 02:18:47 --> Database Driver Class Initialized
INFO - 2016-12-12 02:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:18:47 --> Controller Class Initialized
INFO - 2016-12-12 02:18:47 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:18:47 --> Final output sent to browser
DEBUG - 2016-12-12 02:18:47 --> Total execution time: 0.0124
INFO - 2016-12-12 02:19:28 --> Config Class Initialized
INFO - 2016-12-12 02:19:28 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:19:28 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:19:28 --> Utf8 Class Initialized
INFO - 2016-12-12 02:19:28 --> URI Class Initialized
DEBUG - 2016-12-12 02:19:28 --> No URI present. Default controller set.
INFO - 2016-12-12 02:19:28 --> Router Class Initialized
INFO - 2016-12-12 02:19:28 --> Output Class Initialized
INFO - 2016-12-12 02:19:28 --> Security Class Initialized
DEBUG - 2016-12-12 02:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:19:28 --> Input Class Initialized
INFO - 2016-12-12 02:19:28 --> Language Class Initialized
INFO - 2016-12-12 02:19:28 --> Loader Class Initialized
INFO - 2016-12-12 02:19:28 --> Database Driver Class Initialized
INFO - 2016-12-12 02:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:19:28 --> Controller Class Initialized
INFO - 2016-12-12 02:19:28 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:19:28 --> Final output sent to browser
DEBUG - 2016-12-12 02:19:28 --> Total execution time: 0.0136
INFO - 2016-12-12 02:19:38 --> Config Class Initialized
INFO - 2016-12-12 02:19:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:19:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:19:38 --> Utf8 Class Initialized
INFO - 2016-12-12 02:19:38 --> URI Class Initialized
INFO - 2016-12-12 02:19:38 --> Router Class Initialized
INFO - 2016-12-12 02:19:38 --> Output Class Initialized
INFO - 2016-12-12 02:19:38 --> Security Class Initialized
DEBUG - 2016-12-12 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:19:38 --> Input Class Initialized
INFO - 2016-12-12 02:19:38 --> Language Class Initialized
INFO - 2016-12-12 02:19:38 --> Loader Class Initialized
INFO - 2016-12-12 02:19:38 --> Database Driver Class Initialized
INFO - 2016-12-12 02:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:19:38 --> Controller Class Initialized
INFO - 2016-12-12 02:19:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:19:38 --> Final output sent to browser
DEBUG - 2016-12-12 02:19:38 --> Total execution time: 0.0131
INFO - 2016-12-12 02:19:51 --> Config Class Initialized
INFO - 2016-12-12 02:19:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:19:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:19:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:19:51 --> URI Class Initialized
DEBUG - 2016-12-12 02:19:51 --> No URI present. Default controller set.
INFO - 2016-12-12 02:19:51 --> Router Class Initialized
INFO - 2016-12-12 02:19:51 --> Output Class Initialized
INFO - 2016-12-12 02:19:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:19:51 --> Input Class Initialized
INFO - 2016-12-12 02:19:51 --> Language Class Initialized
INFO - 2016-12-12 02:19:51 --> Loader Class Initialized
INFO - 2016-12-12 02:19:51 --> Database Driver Class Initialized
INFO - 2016-12-12 02:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:19:51 --> Controller Class Initialized
INFO - 2016-12-12 02:19:51 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:19:51 --> Final output sent to browser
DEBUG - 2016-12-12 02:19:51 --> Total execution time: 0.0130
INFO - 2016-12-12 02:19:51 --> Config Class Initialized
INFO - 2016-12-12 02:19:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:19:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:19:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:19:51 --> URI Class Initialized
INFO - 2016-12-12 02:19:51 --> Router Class Initialized
INFO - 2016-12-12 02:19:51 --> Output Class Initialized
INFO - 2016-12-12 02:19:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:19:51 --> Input Class Initialized
INFO - 2016-12-12 02:19:51 --> Language Class Initialized
ERROR - 2016-12-12 02:19:51 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:19:52 --> Config Class Initialized
INFO - 2016-12-12 02:19:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:19:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:19:52 --> Utf8 Class Initialized
INFO - 2016-12-12 02:19:52 --> URI Class Initialized
INFO - 2016-12-12 02:19:52 --> Router Class Initialized
INFO - 2016-12-12 02:19:52 --> Output Class Initialized
INFO - 2016-12-12 02:19:52 --> Security Class Initialized
DEBUG - 2016-12-12 02:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:19:52 --> Input Class Initialized
INFO - 2016-12-12 02:19:52 --> Language Class Initialized
INFO - 2016-12-12 02:19:52 --> Loader Class Initialized
INFO - 2016-12-12 02:19:52 --> Database Driver Class Initialized
INFO - 2016-12-12 02:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:19:52 --> Controller Class Initialized
INFO - 2016-12-12 02:19:52 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:19:52 --> Final output sent to browser
DEBUG - 2016-12-12 02:19:52 --> Total execution time: 0.0136
INFO - 2016-12-12 02:20:09 --> Config Class Initialized
INFO - 2016-12-12 02:20:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:20:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:20:09 --> Utf8 Class Initialized
INFO - 2016-12-12 02:20:09 --> URI Class Initialized
DEBUG - 2016-12-12 02:20:09 --> No URI present. Default controller set.
INFO - 2016-12-12 02:20:09 --> Router Class Initialized
INFO - 2016-12-12 02:20:09 --> Output Class Initialized
INFO - 2016-12-12 02:20:09 --> Security Class Initialized
DEBUG - 2016-12-12 02:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:20:09 --> Input Class Initialized
INFO - 2016-12-12 02:20:09 --> Language Class Initialized
INFO - 2016-12-12 02:20:09 --> Loader Class Initialized
INFO - 2016-12-12 02:20:09 --> Database Driver Class Initialized
INFO - 2016-12-12 02:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:20:09 --> Controller Class Initialized
INFO - 2016-12-12 02:20:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:20:09 --> Final output sent to browser
DEBUG - 2016-12-12 02:20:09 --> Total execution time: 0.0136
INFO - 2016-12-12 02:20:17 --> Config Class Initialized
INFO - 2016-12-12 02:20:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:20:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:20:17 --> Utf8 Class Initialized
INFO - 2016-12-12 02:20:17 --> URI Class Initialized
INFO - 2016-12-12 02:20:17 --> Router Class Initialized
INFO - 2016-12-12 02:20:17 --> Output Class Initialized
INFO - 2016-12-12 02:20:17 --> Security Class Initialized
DEBUG - 2016-12-12 02:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:20:17 --> Input Class Initialized
INFO - 2016-12-12 02:20:17 --> Language Class Initialized
INFO - 2016-12-12 02:20:17 --> Loader Class Initialized
INFO - 2016-12-12 02:20:17 --> Database Driver Class Initialized
INFO - 2016-12-12 02:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:20:17 --> Controller Class Initialized
INFO - 2016-12-12 02:20:17 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:20:17 --> Final output sent to browser
DEBUG - 2016-12-12 02:20:17 --> Total execution time: 0.0127
INFO - 2016-12-12 02:20:32 --> Config Class Initialized
INFO - 2016-12-12 02:20:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:20:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:20:32 --> Utf8 Class Initialized
INFO - 2016-12-12 02:20:32 --> URI Class Initialized
INFO - 2016-12-12 02:20:32 --> Router Class Initialized
INFO - 2016-12-12 02:20:32 --> Output Class Initialized
INFO - 2016-12-12 02:20:32 --> Security Class Initialized
DEBUG - 2016-12-12 02:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:20:32 --> Input Class Initialized
INFO - 2016-12-12 02:20:32 --> Language Class Initialized
ERROR - 2016-12-12 02:20:32 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:20:53 --> Config Class Initialized
INFO - 2016-12-12 02:20:53 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:20:53 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:20:53 --> Utf8 Class Initialized
INFO - 2016-12-12 02:20:53 --> URI Class Initialized
DEBUG - 2016-12-12 02:20:53 --> No URI present. Default controller set.
INFO - 2016-12-12 02:20:53 --> Router Class Initialized
INFO - 2016-12-12 02:20:53 --> Output Class Initialized
INFO - 2016-12-12 02:20:53 --> Security Class Initialized
DEBUG - 2016-12-12 02:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:20:53 --> Input Class Initialized
INFO - 2016-12-12 02:20:53 --> Language Class Initialized
INFO - 2016-12-12 02:20:53 --> Loader Class Initialized
INFO - 2016-12-12 02:20:53 --> Database Driver Class Initialized
INFO - 2016-12-12 02:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:20:53 --> Controller Class Initialized
INFO - 2016-12-12 02:20:53 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:20:53 --> Final output sent to browser
DEBUG - 2016-12-12 02:20:53 --> Total execution time: 0.0135
INFO - 2016-12-12 02:20:54 --> Config Class Initialized
INFO - 2016-12-12 02:20:54 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:20:54 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:20:54 --> Utf8 Class Initialized
INFO - 2016-12-12 02:20:54 --> URI Class Initialized
INFO - 2016-12-12 02:20:54 --> Router Class Initialized
INFO - 2016-12-12 02:20:54 --> Output Class Initialized
INFO - 2016-12-12 02:20:54 --> Security Class Initialized
DEBUG - 2016-12-12 02:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:20:54 --> Input Class Initialized
INFO - 2016-12-12 02:20:54 --> Language Class Initialized
ERROR - 2016-12-12 02:20:54 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:21:10 --> Config Class Initialized
INFO - 2016-12-12 02:21:10 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:21:10 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:21:10 --> Utf8 Class Initialized
INFO - 2016-12-12 02:21:10 --> URI Class Initialized
DEBUG - 2016-12-12 02:21:10 --> No URI present. Default controller set.
INFO - 2016-12-12 02:21:10 --> Router Class Initialized
INFO - 2016-12-12 02:21:10 --> Output Class Initialized
INFO - 2016-12-12 02:21:10 --> Security Class Initialized
DEBUG - 2016-12-12 02:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:21:10 --> Input Class Initialized
INFO - 2016-12-12 02:21:10 --> Language Class Initialized
INFO - 2016-12-12 02:21:10 --> Loader Class Initialized
INFO - 2016-12-12 02:21:10 --> Database Driver Class Initialized
INFO - 2016-12-12 02:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:21:10 --> Controller Class Initialized
INFO - 2016-12-12 02:21:10 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:21:10 --> Final output sent to browser
DEBUG - 2016-12-12 02:21:10 --> Total execution time: 0.0128
INFO - 2016-12-12 02:21:28 --> Config Class Initialized
INFO - 2016-12-12 02:21:28 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:21:28 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:21:28 --> Utf8 Class Initialized
INFO - 2016-12-12 02:21:28 --> URI Class Initialized
DEBUG - 2016-12-12 02:21:28 --> No URI present. Default controller set.
INFO - 2016-12-12 02:21:28 --> Router Class Initialized
INFO - 2016-12-12 02:21:28 --> Output Class Initialized
INFO - 2016-12-12 02:21:28 --> Security Class Initialized
DEBUG - 2016-12-12 02:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:21:28 --> Input Class Initialized
INFO - 2016-12-12 02:21:28 --> Language Class Initialized
INFO - 2016-12-12 02:21:28 --> Loader Class Initialized
INFO - 2016-12-12 02:21:28 --> Database Driver Class Initialized
INFO - 2016-12-12 02:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:21:28 --> Controller Class Initialized
INFO - 2016-12-12 02:21:28 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:21:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:21:28 --> Final output sent to browser
DEBUG - 2016-12-12 02:21:28 --> Total execution time: 0.0162
INFO - 2016-12-12 02:21:35 --> Config Class Initialized
INFO - 2016-12-12 02:21:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:21:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:21:35 --> Utf8 Class Initialized
INFO - 2016-12-12 02:21:35 --> URI Class Initialized
INFO - 2016-12-12 02:21:35 --> Router Class Initialized
INFO - 2016-12-12 02:21:35 --> Output Class Initialized
INFO - 2016-12-12 02:21:35 --> Security Class Initialized
DEBUG - 2016-12-12 02:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:21:35 --> Input Class Initialized
INFO - 2016-12-12 02:21:35 --> Language Class Initialized
ERROR - 2016-12-12 02:21:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:21:43 --> Config Class Initialized
INFO - 2016-12-12 02:21:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:21:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:21:43 --> Utf8 Class Initialized
INFO - 2016-12-12 02:21:43 --> URI Class Initialized
INFO - 2016-12-12 02:21:43 --> Router Class Initialized
INFO - 2016-12-12 02:21:43 --> Output Class Initialized
INFO - 2016-12-12 02:21:43 --> Security Class Initialized
DEBUG - 2016-12-12 02:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:21:43 --> Input Class Initialized
INFO - 2016-12-12 02:21:43 --> Language Class Initialized
INFO - 2016-12-12 02:21:43 --> Loader Class Initialized
INFO - 2016-12-12 02:21:43 --> Database Driver Class Initialized
INFO - 2016-12-12 02:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:21:43 --> Controller Class Initialized
INFO - 2016-12-12 02:21:43 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:21:43 --> Final output sent to browser
DEBUG - 2016-12-12 02:21:43 --> Total execution time: 0.0130
INFO - 2016-12-12 02:23:36 --> Config Class Initialized
INFO - 2016-12-12 02:23:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:36 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:36 --> URI Class Initialized
INFO - 2016-12-12 02:23:36 --> Router Class Initialized
INFO - 2016-12-12 02:23:36 --> Output Class Initialized
INFO - 2016-12-12 02:23:36 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:36 --> Input Class Initialized
INFO - 2016-12-12 02:23:36 --> Language Class Initialized
INFO - 2016-12-12 02:23:36 --> Loader Class Initialized
INFO - 2016-12-12 02:23:36 --> Database Driver Class Initialized
INFO - 2016-12-12 02:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:23:36 --> Controller Class Initialized
DEBUG - 2016-12-12 02:23:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:23:36 --> Helper loaded: url_helper
INFO - 2016-12-12 02:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-12 02:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-12 02:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:23:36 --> Final output sent to browser
DEBUG - 2016-12-12 02:23:36 --> Total execution time: 0.0565
INFO - 2016-12-12 02:23:36 --> Config Class Initialized
INFO - 2016-12-12 02:23:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:36 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:36 --> URI Class Initialized
INFO - 2016-12-12 02:23:36 --> Router Class Initialized
INFO - 2016-12-12 02:23:36 --> Output Class Initialized
INFO - 2016-12-12 02:23:36 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:36 --> Input Class Initialized
INFO - 2016-12-12 02:23:36 --> Language Class Initialized
ERROR - 2016-12-12 02:23:36 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:23:36 --> Config Class Initialized
INFO - 2016-12-12 02:23:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:36 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:36 --> URI Class Initialized
INFO - 2016-12-12 02:23:36 --> Router Class Initialized
INFO - 2016-12-12 02:23:36 --> Output Class Initialized
INFO - 2016-12-12 02:23:36 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:36 --> Input Class Initialized
INFO - 2016-12-12 02:23:36 --> Language Class Initialized
ERROR - 2016-12-12 02:23:36 --> Severity: Parsing Error --> syntax error, unexpected '||' (T_BOOLEAN_OR), expecting ')' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:38 --> Config Class Initialized
INFO - 2016-12-12 02:23:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:38 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:38 --> URI Class Initialized
INFO - 2016-12-12 02:23:38 --> Router Class Initialized
INFO - 2016-12-12 02:23:38 --> Output Class Initialized
INFO - 2016-12-12 02:23:38 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:38 --> Input Class Initialized
INFO - 2016-12-12 02:23:38 --> Language Class Initialized
INFO - 2016-12-12 02:23:38 --> Loader Class Initialized
INFO - 2016-12-12 02:23:38 --> Database Driver Class Initialized
INFO - 2016-12-12 02:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:23:38 --> Controller Class Initialized
INFO - 2016-12-12 02:23:38 --> Helper loaded: date_helper
DEBUG - 2016-12-12 02:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:23:38 --> Helper loaded: url_helper
INFO - 2016-12-12 02:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-12 02:23:38 --> Severity: Notice --> Undefined variable: layout_name /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php 10
INFO - 2016-12-12 02:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
ERROR - 2016-12-12 02:23:38 --> Severity: Notice --> Undefined variable: numero_lugares /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 52
INFO - 2016-12-12 02:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-12 02:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:23:38 --> Final output sent to browser
DEBUG - 2016-12-12 02:23:38 --> Total execution time: 0.1898
INFO - 2016-12-12 02:23:39 --> Config Class Initialized
INFO - 2016-12-12 02:23:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:39 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:39 --> Config Class Initialized
INFO - 2016-12-12 02:23:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:39 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:39 --> URI Class Initialized
INFO - 2016-12-12 02:23:39 --> Router Class Initialized
INFO - 2016-12-12 02:23:39 --> Output Class Initialized
INFO - 2016-12-12 02:23:39 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:39 --> Input Class Initialized
INFO - 2016-12-12 02:23:39 --> Language Class Initialized
ERROR - 2016-12-12 02:23:39 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:23:39 --> Config Class Initialized
INFO - 2016-12-12 02:23:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:39 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:39 --> URI Class Initialized
INFO - 2016-12-12 02:23:39 --> Router Class Initialized
INFO - 2016-12-12 02:23:39 --> Output Class Initialized
INFO - 2016-12-12 02:23:39 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:39 --> Input Class Initialized
INFO - 2016-12-12 02:23:39 --> Language Class Initialized
ERROR - 2016-12-12 02:23:39 --> Severity: Parsing Error --> syntax error, unexpected '||' (T_BOOLEAN_OR), expecting ')' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:43 --> Config Class Initialized
INFO - 2016-12-12 02:23:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:43 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:43 --> URI Class Initialized
DEBUG - 2016-12-12 02:23:43 --> No URI present. Default controller set.
INFO - 2016-12-12 02:23:43 --> Router Class Initialized
INFO - 2016-12-12 02:23:43 --> Output Class Initialized
INFO - 2016-12-12 02:23:43 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:43 --> Input Class Initialized
INFO - 2016-12-12 02:23:43 --> Language Class Initialized
ERROR - 2016-12-12 02:23:43 --> Severity: Parsing Error --> syntax error, unexpected '||' (T_BOOLEAN_OR), expecting ')' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:43 --> Config Class Initialized
INFO - 2016-12-12 02:23:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:43 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:43 --> URI Class Initialized
INFO - 2016-12-12 02:23:43 --> Router Class Initialized
INFO - 2016-12-12 02:23:43 --> Output Class Initialized
INFO - 2016-12-12 02:23:43 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:43 --> Input Class Initialized
INFO - 2016-12-12 02:23:43 --> Language Class Initialized
ERROR - 2016-12-12 02:23:43 --> Severity: Parsing Error --> syntax error, unexpected '||' (T_BOOLEAN_OR), expecting ')' /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:52 --> Config Class Initialized
INFO - 2016-12-12 02:23:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:52 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:52 --> URI Class Initialized
DEBUG - 2016-12-12 02:23:52 --> No URI present. Default controller set.
INFO - 2016-12-12 02:23:52 --> Router Class Initialized
INFO - 2016-12-12 02:23:52 --> Output Class Initialized
INFO - 2016-12-12 02:23:52 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:52 --> Input Class Initialized
INFO - 2016-12-12 02:23:52 --> Language Class Initialized
ERROR - 2016-12-12 02:23:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:52 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:52 --> Config Class Initialized
INFO - 2016-12-12 02:23:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:52 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:52 --> URI Class Initialized
INFO - 2016-12-12 02:23:52 --> Router Class Initialized
INFO - 2016-12-12 02:23:52 --> Output Class Initialized
INFO - 2016-12-12 02:23:52 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:52 --> Input Class Initialized
INFO - 2016-12-12 02:23:52 --> Language Class Initialized
ERROR - 2016-12-12 02:23:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:52 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:53 --> Config Class Initialized
INFO - 2016-12-12 02:23:53 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:53 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:53 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:53 --> URI Class Initialized
DEBUG - 2016-12-12 02:23:53 --> No URI present. Default controller set.
INFO - 2016-12-12 02:23:53 --> Router Class Initialized
INFO - 2016-12-12 02:23:53 --> Output Class Initialized
INFO - 2016-12-12 02:23:53 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:53 --> Input Class Initialized
INFO - 2016-12-12 02:23:53 --> Language Class Initialized
ERROR - 2016-12-12 02:23:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:53 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:53 --> Config Class Initialized
INFO - 2016-12-12 02:23:53 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:53 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:53 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:53 --> URI Class Initialized
INFO - 2016-12-12 02:23:53 --> Router Class Initialized
INFO - 2016-12-12 02:23:53 --> Output Class Initialized
INFO - 2016-12-12 02:23:53 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:53 --> Input Class Initialized
INFO - 2016-12-12 02:23:53 --> Language Class Initialized
ERROR - 2016-12-12 02:23:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:53 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:53 --> Config Class Initialized
INFO - 2016-12-12 02:23:53 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:53 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:53 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:53 --> URI Class Initialized
DEBUG - 2016-12-12 02:23:53 --> No URI present. Default controller set.
INFO - 2016-12-12 02:23:53 --> Router Class Initialized
INFO - 2016-12-12 02:23:53 --> Output Class Initialized
INFO - 2016-12-12 02:23:53 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:53 --> Input Class Initialized
INFO - 2016-12-12 02:23:53 --> Language Class Initialized
ERROR - 2016-12-12 02:23:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:53 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:54 --> Config Class Initialized
INFO - 2016-12-12 02:23:54 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:54 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:54 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:54 --> URI Class Initialized
INFO - 2016-12-12 02:23:54 --> Router Class Initialized
INFO - 2016-12-12 02:23:54 --> Output Class Initialized
INFO - 2016-12-12 02:23:54 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:54 --> Input Class Initialized
INFO - 2016-12-12 02:23:54 --> Language Class Initialized
ERROR - 2016-12-12 02:23:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:54 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:54 --> Config Class Initialized
INFO - 2016-12-12 02:23:54 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:54 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:54 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:54 --> URI Class Initialized
DEBUG - 2016-12-12 02:23:54 --> No URI present. Default controller set.
INFO - 2016-12-12 02:23:54 --> Router Class Initialized
INFO - 2016-12-12 02:23:54 --> Output Class Initialized
INFO - 2016-12-12 02:23:54 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:54 --> Input Class Initialized
INFO - 2016-12-12 02:23:54 --> Language Class Initialized
ERROR - 2016-12-12 02:23:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:54 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:54 --> Config Class Initialized
INFO - 2016-12-12 02:23:54 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:54 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:54 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:54 --> URI Class Initialized
INFO - 2016-12-12 02:23:54 --> Router Class Initialized
INFO - 2016-12-12 02:23:54 --> Output Class Initialized
INFO - 2016-12-12 02:23:54 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:54 --> Input Class Initialized
INFO - 2016-12-12 02:23:54 --> Language Class Initialized
ERROR - 2016-12-12 02:23:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:54 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:23:57 --> Config Class Initialized
INFO - 2016-12-12 02:23:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:23:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:23:57 --> Utf8 Class Initialized
INFO - 2016-12-12 02:23:57 --> URI Class Initialized
INFO - 2016-12-12 02:23:57 --> Router Class Initialized
INFO - 2016-12-12 02:23:57 --> Output Class Initialized
INFO - 2016-12-12 02:23:57 --> Security Class Initialized
DEBUG - 2016-12-12 02:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:23:57 --> Input Class Initialized
INFO - 2016-12-12 02:23:57 --> Language Class Initialized
ERROR - 2016-12-12 02:23:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:23:57 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:08 --> Config Class Initialized
INFO - 2016-12-12 02:24:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:08 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:08 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:08 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:08 --> Router Class Initialized
INFO - 2016-12-12 02:24:08 --> Output Class Initialized
INFO - 2016-12-12 02:24:08 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:08 --> Input Class Initialized
INFO - 2016-12-12 02:24:08 --> Language Class Initialized
ERROR - 2016-12-12 02:24:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:08 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:08 --> Config Class Initialized
INFO - 2016-12-12 02:24:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:08 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:08 --> URI Class Initialized
INFO - 2016-12-12 02:24:08 --> Router Class Initialized
INFO - 2016-12-12 02:24:08 --> Output Class Initialized
INFO - 2016-12-12 02:24:08 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:08 --> Input Class Initialized
INFO - 2016-12-12 02:24:08 --> Language Class Initialized
ERROR - 2016-12-12 02:24:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:08 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:17 --> Config Class Initialized
INFO - 2016-12-12 02:24:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:17 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:17 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:17 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:17 --> Router Class Initialized
INFO - 2016-12-12 02:24:17 --> Output Class Initialized
INFO - 2016-12-12 02:24:17 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:17 --> Input Class Initialized
INFO - 2016-12-12 02:24:17 --> Language Class Initialized
ERROR - 2016-12-12 02:24:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:17 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:17 --> Config Class Initialized
INFO - 2016-12-12 02:24:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:17 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:17 --> URI Class Initialized
INFO - 2016-12-12 02:24:17 --> Router Class Initialized
INFO - 2016-12-12 02:24:17 --> Output Class Initialized
INFO - 2016-12-12 02:24:17 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:17 --> Input Class Initialized
INFO - 2016-12-12 02:24:17 --> Language Class Initialized
ERROR - 2016-12-12 02:24:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:17 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:19 --> Config Class Initialized
INFO - 2016-12-12 02:24:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:19 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:19 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:19 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:19 --> Router Class Initialized
INFO - 2016-12-12 02:24:19 --> Output Class Initialized
INFO - 2016-12-12 02:24:19 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:19 --> Input Class Initialized
INFO - 2016-12-12 02:24:19 --> Language Class Initialized
ERROR - 2016-12-12 02:24:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:19 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:19 --> Config Class Initialized
INFO - 2016-12-12 02:24:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:19 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:19 --> URI Class Initialized
INFO - 2016-12-12 02:24:19 --> Router Class Initialized
INFO - 2016-12-12 02:24:19 --> Output Class Initialized
INFO - 2016-12-12 02:24:19 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:19 --> Input Class Initialized
INFO - 2016-12-12 02:24:19 --> Language Class Initialized
ERROR - 2016-12-12 02:24:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:19 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:19 --> Config Class Initialized
INFO - 2016-12-12 02:24:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:19 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:19 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:19 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:19 --> Router Class Initialized
INFO - 2016-12-12 02:24:19 --> Output Class Initialized
INFO - 2016-12-12 02:24:19 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:19 --> Input Class Initialized
INFO - 2016-12-12 02:24:19 --> Language Class Initialized
ERROR - 2016-12-12 02:24:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:19 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:19 --> Config Class Initialized
INFO - 2016-12-12 02:24:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:19 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:19 --> URI Class Initialized
INFO - 2016-12-12 02:24:19 --> Router Class Initialized
INFO - 2016-12-12 02:24:19 --> Output Class Initialized
INFO - 2016-12-12 02:24:19 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:19 --> Input Class Initialized
INFO - 2016-12-12 02:24:19 --> Language Class Initialized
ERROR - 2016-12-12 02:24:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:19 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:20 --> Config Class Initialized
INFO - 2016-12-12 02:24:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:20 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:20 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:20 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:20 --> Router Class Initialized
INFO - 2016-12-12 02:24:20 --> Output Class Initialized
INFO - 2016-12-12 02:24:20 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:20 --> Input Class Initialized
INFO - 2016-12-12 02:24:20 --> Language Class Initialized
ERROR - 2016-12-12 02:24:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:20 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:20 --> Config Class Initialized
INFO - 2016-12-12 02:24:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:20 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:20 --> URI Class Initialized
INFO - 2016-12-12 02:24:20 --> Router Class Initialized
INFO - 2016-12-12 02:24:20 --> Output Class Initialized
INFO - 2016-12-12 02:24:20 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:20 --> Input Class Initialized
INFO - 2016-12-12 02:24:20 --> Language Class Initialized
ERROR - 2016-12-12 02:24:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:20 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:20 --> Config Class Initialized
INFO - 2016-12-12 02:24:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:20 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:20 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:20 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:20 --> Router Class Initialized
INFO - 2016-12-12 02:24:20 --> Output Class Initialized
INFO - 2016-12-12 02:24:20 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:20 --> Input Class Initialized
INFO - 2016-12-12 02:24:20 --> Language Class Initialized
ERROR - 2016-12-12 02:24:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:20 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:20 --> Config Class Initialized
INFO - 2016-12-12 02:24:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:20 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:20 --> URI Class Initialized
INFO - 2016-12-12 02:24:20 --> Router Class Initialized
INFO - 2016-12-12 02:24:20 --> Output Class Initialized
INFO - 2016-12-12 02:24:20 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:20 --> Input Class Initialized
INFO - 2016-12-12 02:24:20 --> Language Class Initialized
ERROR - 2016-12-12 02:24:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:20 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:55 --> Config Class Initialized
INFO - 2016-12-12 02:24:55 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:55 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:55 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:55 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:55 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:55 --> Router Class Initialized
INFO - 2016-12-12 02:24:55 --> Output Class Initialized
INFO - 2016-12-12 02:24:55 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:55 --> Input Class Initialized
INFO - 2016-12-12 02:24:55 --> Language Class Initialized
ERROR - 2016-12-12 02:24:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:55 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:55 --> Config Class Initialized
INFO - 2016-12-12 02:24:55 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:55 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:55 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:55 --> URI Class Initialized
INFO - 2016-12-12 02:24:55 --> Router Class Initialized
INFO - 2016-12-12 02:24:55 --> Output Class Initialized
INFO - 2016-12-12 02:24:55 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:55 --> Input Class Initialized
INFO - 2016-12-12 02:24:55 --> Language Class Initialized
ERROR - 2016-12-12 02:24:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:55 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:57 --> Config Class Initialized
INFO - 2016-12-12 02:24:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:57 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:57 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:57 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:57 --> Router Class Initialized
INFO - 2016-12-12 02:24:57 --> Output Class Initialized
INFO - 2016-12-12 02:24:57 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:57 --> Input Class Initialized
INFO - 2016-12-12 02:24:57 --> Language Class Initialized
ERROR - 2016-12-12 02:24:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:57 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:57 --> Config Class Initialized
INFO - 2016-12-12 02:24:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:57 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:57 --> URI Class Initialized
INFO - 2016-12-12 02:24:57 --> Router Class Initialized
INFO - 2016-12-12 02:24:57 --> Output Class Initialized
INFO - 2016-12-12 02:24:57 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:57 --> Input Class Initialized
INFO - 2016-12-12 02:24:57 --> Language Class Initialized
ERROR - 2016-12-12 02:24:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:57 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:57 --> Config Class Initialized
INFO - 2016-12-12 02:24:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:57 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:57 --> URI Class Initialized
DEBUG - 2016-12-12 02:24:57 --> No URI present. Default controller set.
INFO - 2016-12-12 02:24:57 --> Router Class Initialized
INFO - 2016-12-12 02:24:57 --> Output Class Initialized
INFO - 2016-12-12 02:24:57 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:57 --> Input Class Initialized
INFO - 2016-12-12 02:24:57 --> Language Class Initialized
ERROR - 2016-12-12 02:24:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:57 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:24:57 --> Config Class Initialized
INFO - 2016-12-12 02:24:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:24:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:24:57 --> Utf8 Class Initialized
INFO - 2016-12-12 02:24:57 --> URI Class Initialized
INFO - 2016-12-12 02:24:57 --> Router Class Initialized
INFO - 2016-12-12 02:24:57 --> Output Class Initialized
INFO - 2016-12-12 02:24:57 --> Security Class Initialized
DEBUG - 2016-12-12 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:24:57 --> Input Class Initialized
INFO - 2016-12-12 02:24:57 --> Language Class Initialized
ERROR - 2016-12-12 02:24:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:24:57 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:25:02 --> Config Class Initialized
INFO - 2016-12-12 02:25:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:25:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:25:02 --> Utf8 Class Initialized
INFO - 2016-12-12 02:25:02 --> URI Class Initialized
DEBUG - 2016-12-12 02:25:02 --> No URI present. Default controller set.
INFO - 2016-12-12 02:25:02 --> Router Class Initialized
INFO - 2016-12-12 02:25:02 --> Output Class Initialized
INFO - 2016-12-12 02:25:02 --> Security Class Initialized
DEBUG - 2016-12-12 02:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:25:02 --> Input Class Initialized
INFO - 2016-12-12 02:25:02 --> Language Class Initialized
ERROR - 2016-12-12 02:25:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:25:02 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:25:03 --> Config Class Initialized
INFO - 2016-12-12 02:25:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:25:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:25:03 --> Utf8 Class Initialized
INFO - 2016-12-12 02:25:03 --> URI Class Initialized
INFO - 2016-12-12 02:25:03 --> Router Class Initialized
INFO - 2016-12-12 02:25:03 --> Output Class Initialized
INFO - 2016-12-12 02:25:03 --> Security Class Initialized
DEBUG - 2016-12-12 02:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:25:03 --> Input Class Initialized
INFO - 2016-12-12 02:25:03 --> Language Class Initialized
ERROR - 2016-12-12 02:25:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:25:03 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:27:25 --> Config Class Initialized
INFO - 2016-12-12 02:27:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:27:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:27:25 --> Utf8 Class Initialized
INFO - 2016-12-12 02:27:25 --> URI Class Initialized
DEBUG - 2016-12-12 02:27:25 --> No URI present. Default controller set.
INFO - 2016-12-12 02:27:25 --> Router Class Initialized
INFO - 2016-12-12 02:27:25 --> Output Class Initialized
INFO - 2016-12-12 02:27:25 --> Security Class Initialized
DEBUG - 2016-12-12 02:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:27:25 --> Input Class Initialized
INFO - 2016-12-12 02:27:25 --> Language Class Initialized
ERROR - 2016-12-12 02:27:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:27:25 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:27:25 --> Config Class Initialized
INFO - 2016-12-12 02:27:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:27:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:27:25 --> Utf8 Class Initialized
INFO - 2016-12-12 02:27:25 --> URI Class Initialized
INFO - 2016-12-12 02:27:25 --> Router Class Initialized
INFO - 2016-12-12 02:27:25 --> Output Class Initialized
INFO - 2016-12-12 02:27:25 --> Security Class Initialized
DEBUG - 2016-12-12 02:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:27:25 --> Input Class Initialized
INFO - 2016-12-12 02:27:25 --> Language Class Initialized
ERROR - 2016-12-12 02:27:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:27:25 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:03 --> Config Class Initialized
INFO - 2016-12-12 02:29:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:03 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:03 --> URI Class Initialized
DEBUG - 2016-12-12 02:29:03 --> No URI present. Default controller set.
INFO - 2016-12-12 02:29:03 --> Router Class Initialized
INFO - 2016-12-12 02:29:03 --> Output Class Initialized
INFO - 2016-12-12 02:29:03 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:03 --> Input Class Initialized
INFO - 2016-12-12 02:29:03 --> Language Class Initialized
ERROR - 2016-12-12 02:29:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:03 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:04 --> Config Class Initialized
INFO - 2016-12-12 02:29:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:04 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:04 --> URI Class Initialized
INFO - 2016-12-12 02:29:04 --> Router Class Initialized
INFO - 2016-12-12 02:29:04 --> Output Class Initialized
INFO - 2016-12-12 02:29:04 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:04 --> Input Class Initialized
INFO - 2016-12-12 02:29:04 --> Language Class Initialized
ERROR - 2016-12-12 02:29:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:04 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:07 --> Config Class Initialized
INFO - 2016-12-12 02:29:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:07 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:07 --> URI Class Initialized
DEBUG - 2016-12-12 02:29:07 --> No URI present. Default controller set.
INFO - 2016-12-12 02:29:07 --> Router Class Initialized
INFO - 2016-12-12 02:29:07 --> Output Class Initialized
INFO - 2016-12-12 02:29:07 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:07 --> Input Class Initialized
INFO - 2016-12-12 02:29:07 --> Language Class Initialized
ERROR - 2016-12-12 02:29:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:07 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:07 --> Config Class Initialized
INFO - 2016-12-12 02:29:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:07 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:07 --> URI Class Initialized
INFO - 2016-12-12 02:29:07 --> Router Class Initialized
INFO - 2016-12-12 02:29:07 --> Output Class Initialized
INFO - 2016-12-12 02:29:07 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:07 --> Input Class Initialized
INFO - 2016-12-12 02:29:07 --> Language Class Initialized
ERROR - 2016-12-12 02:29:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:07 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:08 --> Config Class Initialized
INFO - 2016-12-12 02:29:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:08 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:08 --> URI Class Initialized
DEBUG - 2016-12-12 02:29:08 --> No URI present. Default controller set.
INFO - 2016-12-12 02:29:08 --> Router Class Initialized
INFO - 2016-12-12 02:29:08 --> Output Class Initialized
INFO - 2016-12-12 02:29:08 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:08 --> Input Class Initialized
INFO - 2016-12-12 02:29:08 --> Language Class Initialized
ERROR - 2016-12-12 02:29:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:08 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:08 --> Config Class Initialized
INFO - 2016-12-12 02:29:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:08 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:08 --> URI Class Initialized
INFO - 2016-12-12 02:29:08 --> Router Class Initialized
INFO - 2016-12-12 02:29:08 --> Output Class Initialized
INFO - 2016-12-12 02:29:08 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:08 --> Input Class Initialized
INFO - 2016-12-12 02:29:08 --> Language Class Initialized
ERROR - 2016-12-12 02:29:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:08 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:17 --> Config Class Initialized
INFO - 2016-12-12 02:29:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:17 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:17 --> URI Class Initialized
INFO - 2016-12-12 02:29:17 --> Router Class Initialized
INFO - 2016-12-12 02:29:17 --> Output Class Initialized
INFO - 2016-12-12 02:29:17 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:17 --> Input Class Initialized
INFO - 2016-12-12 02:29:17 --> Language Class Initialized
ERROR - 2016-12-12 02:29:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:17 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:18 --> Config Class Initialized
INFO - 2016-12-12 02:29:18 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:18 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:18 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:18 --> URI Class Initialized
DEBUG - 2016-12-12 02:29:18 --> No URI present. Default controller set.
INFO - 2016-12-12 02:29:18 --> Router Class Initialized
INFO - 2016-12-12 02:29:18 --> Output Class Initialized
INFO - 2016-12-12 02:29:18 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:18 --> Input Class Initialized
INFO - 2016-12-12 02:29:18 --> Language Class Initialized
ERROR - 2016-12-12 02:29:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:18 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:19 --> Config Class Initialized
INFO - 2016-12-12 02:29:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:19 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:19 --> URI Class Initialized
INFO - 2016-12-12 02:29:19 --> Router Class Initialized
INFO - 2016-12-12 02:29:19 --> Output Class Initialized
INFO - 2016-12-12 02:29:19 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:19 --> Input Class Initialized
INFO - 2016-12-12 02:29:19 --> Language Class Initialized
ERROR - 2016-12-12 02:29:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:19 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:29:59 --> Config Class Initialized
INFO - 2016-12-12 02:29:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:29:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:29:59 --> Utf8 Class Initialized
INFO - 2016-12-12 02:29:59 --> URI Class Initialized
INFO - 2016-12-12 02:29:59 --> Router Class Initialized
INFO - 2016-12-12 02:29:59 --> Output Class Initialized
INFO - 2016-12-12 02:29:59 --> Security Class Initialized
DEBUG - 2016-12-12 02:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:29:59 --> Input Class Initialized
INFO - 2016-12-12 02:29:59 --> Language Class Initialized
ERROR - 2016-12-12 02:29:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:109) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-12 02:29:59 --> Severity: Compile Error --> Can't use method return value in write context /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 109
INFO - 2016-12-12 02:40:06 --> Config Class Initialized
INFO - 2016-12-12 02:40:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:40:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:40:06 --> Utf8 Class Initialized
INFO - 2016-12-12 02:40:06 --> URI Class Initialized
DEBUG - 2016-12-12 02:40:06 --> No URI present. Default controller set.
INFO - 2016-12-12 02:40:06 --> Router Class Initialized
INFO - 2016-12-12 02:40:06 --> Output Class Initialized
INFO - 2016-12-12 02:40:06 --> Security Class Initialized
DEBUG - 2016-12-12 02:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:40:06 --> Input Class Initialized
INFO - 2016-12-12 02:40:06 --> Language Class Initialized
INFO - 2016-12-12 02:40:06 --> Loader Class Initialized
INFO - 2016-12-12 02:40:07 --> Database Driver Class Initialized
INFO - 2016-12-12 02:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:40:07 --> Controller Class Initialized
INFO - 2016-12-12 02:40:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:40:07 --> Final output sent to browser
DEBUG - 2016-12-12 02:40:07 --> Total execution time: 0.5831
INFO - 2016-12-12 02:40:08 --> Config Class Initialized
INFO - 2016-12-12 02:40:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:40:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:40:08 --> Utf8 Class Initialized
INFO - 2016-12-12 02:40:08 --> URI Class Initialized
INFO - 2016-12-12 02:40:08 --> Router Class Initialized
INFO - 2016-12-12 02:40:08 --> Output Class Initialized
INFO - 2016-12-12 02:40:08 --> Security Class Initialized
DEBUG - 2016-12-12 02:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:40:08 --> Input Class Initialized
INFO - 2016-12-12 02:40:08 --> Language Class Initialized
ERROR - 2016-12-12 02:40:08 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:40:35 --> Config Class Initialized
INFO - 2016-12-12 02:40:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:40:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:40:35 --> Utf8 Class Initialized
INFO - 2016-12-12 02:40:35 --> URI Class Initialized
INFO - 2016-12-12 02:40:35 --> Router Class Initialized
INFO - 2016-12-12 02:40:35 --> Output Class Initialized
INFO - 2016-12-12 02:40:35 --> Security Class Initialized
DEBUG - 2016-12-12 02:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:40:35 --> Input Class Initialized
INFO - 2016-12-12 02:40:35 --> Language Class Initialized
ERROR - 2016-12-12 02:40:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:40:39 --> Config Class Initialized
INFO - 2016-12-12 02:40:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:40:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:40:39 --> Utf8 Class Initialized
INFO - 2016-12-12 02:40:39 --> URI Class Initialized
DEBUG - 2016-12-12 02:40:39 --> No URI present. Default controller set.
INFO - 2016-12-12 02:40:39 --> Router Class Initialized
INFO - 2016-12-12 02:40:39 --> Output Class Initialized
INFO - 2016-12-12 02:40:39 --> Security Class Initialized
DEBUG - 2016-12-12 02:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:40:39 --> Input Class Initialized
INFO - 2016-12-12 02:40:39 --> Language Class Initialized
INFO - 2016-12-12 02:40:39 --> Loader Class Initialized
INFO - 2016-12-12 02:40:39 --> Database Driver Class Initialized
INFO - 2016-12-12 02:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:40:39 --> Controller Class Initialized
INFO - 2016-12-12 02:40:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:40:39 --> Final output sent to browser
DEBUG - 2016-12-12 02:40:39 --> Total execution time: 0.0129
INFO - 2016-12-12 02:40:39 --> Config Class Initialized
INFO - 2016-12-12 02:40:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:40:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:40:39 --> Utf8 Class Initialized
INFO - 2016-12-12 02:40:39 --> URI Class Initialized
INFO - 2016-12-12 02:40:39 --> Router Class Initialized
INFO - 2016-12-12 02:40:39 --> Output Class Initialized
INFO - 2016-12-12 02:40:39 --> Security Class Initialized
DEBUG - 2016-12-12 02:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:40:39 --> Input Class Initialized
INFO - 2016-12-12 02:40:39 --> Language Class Initialized
ERROR - 2016-12-12 02:40:39 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:40:41 --> Config Class Initialized
INFO - 2016-12-12 02:40:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:40:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:40:41 --> Utf8 Class Initialized
INFO - 2016-12-12 02:40:41 --> URI Class Initialized
INFO - 2016-12-12 02:40:41 --> Router Class Initialized
INFO - 2016-12-12 02:40:41 --> Output Class Initialized
INFO - 2016-12-12 02:40:41 --> Security Class Initialized
DEBUG - 2016-12-12 02:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:40:41 --> Input Class Initialized
INFO - 2016-12-12 02:40:41 --> Language Class Initialized
ERROR - 2016-12-12 02:40:41 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:40:56 --> Config Class Initialized
INFO - 2016-12-12 02:40:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:40:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:40:56 --> Utf8 Class Initialized
INFO - 2016-12-12 02:40:56 --> URI Class Initialized
INFO - 2016-12-12 02:40:56 --> Router Class Initialized
INFO - 2016-12-12 02:40:56 --> Output Class Initialized
INFO - 2016-12-12 02:40:56 --> Security Class Initialized
DEBUG - 2016-12-12 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:40:56 --> Input Class Initialized
INFO - 2016-12-12 02:40:56 --> Language Class Initialized
INFO - 2016-12-12 02:40:56 --> Loader Class Initialized
INFO - 2016-12-12 02:40:56 --> Database Driver Class Initialized
INFO - 2016-12-12 02:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:40:56 --> Controller Class Initialized
INFO - 2016-12-12 02:40:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:40:56 --> Final output sent to browser
DEBUG - 2016-12-12 02:40:56 --> Total execution time: 0.0139
INFO - 2016-12-12 02:42:31 --> Config Class Initialized
INFO - 2016-12-12 02:42:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:42:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:42:31 --> Utf8 Class Initialized
INFO - 2016-12-12 02:42:31 --> URI Class Initialized
INFO - 2016-12-12 02:42:31 --> Router Class Initialized
INFO - 2016-12-12 02:42:31 --> Output Class Initialized
INFO - 2016-12-12 02:42:31 --> Security Class Initialized
DEBUG - 2016-12-12 02:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:42:31 --> Input Class Initialized
INFO - 2016-12-12 02:42:31 --> Language Class Initialized
INFO - 2016-12-12 02:42:31 --> Loader Class Initialized
INFO - 2016-12-12 02:42:31 --> Database Driver Class Initialized
INFO - 2016-12-12 02:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:42:31 --> Controller Class Initialized
INFO - 2016-12-12 02:42:31 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:42:31 --> Final output sent to browser
DEBUG - 2016-12-12 02:42:31 --> Total execution time: 0.0130
INFO - 2016-12-12 02:42:38 --> Config Class Initialized
INFO - 2016-12-12 02:42:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:42:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:42:38 --> Utf8 Class Initialized
INFO - 2016-12-12 02:42:38 --> URI Class Initialized
DEBUG - 2016-12-12 02:42:38 --> No URI present. Default controller set.
INFO - 2016-12-12 02:42:38 --> Router Class Initialized
INFO - 2016-12-12 02:42:38 --> Output Class Initialized
INFO - 2016-12-12 02:42:38 --> Security Class Initialized
DEBUG - 2016-12-12 02:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:42:38 --> Input Class Initialized
INFO - 2016-12-12 02:42:38 --> Language Class Initialized
INFO - 2016-12-12 02:42:38 --> Loader Class Initialized
INFO - 2016-12-12 02:42:38 --> Database Driver Class Initialized
INFO - 2016-12-12 02:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:42:38 --> Controller Class Initialized
INFO - 2016-12-12 02:42:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:42:38 --> Final output sent to browser
DEBUG - 2016-12-12 02:42:38 --> Total execution time: 0.0133
INFO - 2016-12-12 02:42:38 --> Config Class Initialized
INFO - 2016-12-12 02:42:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:42:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:42:38 --> Utf8 Class Initialized
INFO - 2016-12-12 02:42:38 --> URI Class Initialized
INFO - 2016-12-12 02:42:38 --> Router Class Initialized
INFO - 2016-12-12 02:42:38 --> Output Class Initialized
INFO - 2016-12-12 02:42:38 --> Security Class Initialized
DEBUG - 2016-12-12 02:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:42:38 --> Input Class Initialized
INFO - 2016-12-12 02:42:38 --> Language Class Initialized
ERROR - 2016-12-12 02:42:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:43:11 --> Config Class Initialized
INFO - 2016-12-12 02:43:11 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:43:11 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:43:11 --> Utf8 Class Initialized
INFO - 2016-12-12 02:43:11 --> URI Class Initialized
INFO - 2016-12-12 02:43:11 --> Router Class Initialized
INFO - 2016-12-12 02:43:11 --> Output Class Initialized
INFO - 2016-12-12 02:43:11 --> Security Class Initialized
DEBUG - 2016-12-12 02:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:43:11 --> Input Class Initialized
INFO - 2016-12-12 02:43:11 --> Language Class Initialized
ERROR - 2016-12-12 02:43:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:44:26 --> Config Class Initialized
INFO - 2016-12-12 02:44:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:44:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:44:26 --> Utf8 Class Initialized
INFO - 2016-12-12 02:44:26 --> URI Class Initialized
INFO - 2016-12-12 02:44:26 --> Router Class Initialized
INFO - 2016-12-12 02:44:26 --> Output Class Initialized
INFO - 2016-12-12 02:44:26 --> Security Class Initialized
DEBUG - 2016-12-12 02:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:44:26 --> Input Class Initialized
INFO - 2016-12-12 02:44:26 --> Language Class Initialized
INFO - 2016-12-12 02:44:26 --> Loader Class Initialized
INFO - 2016-12-12 02:44:26 --> Database Driver Class Initialized
INFO - 2016-12-12 02:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:44:26 --> Controller Class Initialized
INFO - 2016-12-12 02:44:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:44:26 --> Final output sent to browser
DEBUG - 2016-12-12 02:44:26 --> Total execution time: 0.0258
INFO - 2016-12-12 02:45:21 --> Config Class Initialized
INFO - 2016-12-12 02:45:21 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:45:21 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:45:21 --> Utf8 Class Initialized
INFO - 2016-12-12 02:45:21 --> URI Class Initialized
INFO - 2016-12-12 02:45:21 --> Router Class Initialized
INFO - 2016-12-12 02:45:21 --> Output Class Initialized
INFO - 2016-12-12 02:45:21 --> Security Class Initialized
DEBUG - 2016-12-12 02:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:45:21 --> Input Class Initialized
INFO - 2016-12-12 02:45:21 --> Language Class Initialized
INFO - 2016-12-12 02:45:21 --> Loader Class Initialized
INFO - 2016-12-12 02:45:21 --> Database Driver Class Initialized
INFO - 2016-12-12 02:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:45:21 --> Controller Class Initialized
INFO - 2016-12-12 02:45:21 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:45:21 --> Final output sent to browser
DEBUG - 2016-12-12 02:45:21 --> Total execution time: 0.0128
INFO - 2016-12-12 02:50:51 --> Config Class Initialized
INFO - 2016-12-12 02:50:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:50:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:50:51 --> Utf8 Class Initialized
INFO - 2016-12-12 02:50:51 --> URI Class Initialized
DEBUG - 2016-12-12 02:50:51 --> No URI present. Default controller set.
INFO - 2016-12-12 02:50:51 --> Router Class Initialized
INFO - 2016-12-12 02:50:51 --> Output Class Initialized
INFO - 2016-12-12 02:50:51 --> Security Class Initialized
DEBUG - 2016-12-12 02:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:50:51 --> Input Class Initialized
INFO - 2016-12-12 02:50:51 --> Language Class Initialized
INFO - 2016-12-12 02:50:51 --> Loader Class Initialized
INFO - 2016-12-12 02:50:51 --> Database Driver Class Initialized
INFO - 2016-12-12 02:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:50:51 --> Controller Class Initialized
INFO - 2016-12-12 02:50:51 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:50:51 --> Final output sent to browser
DEBUG - 2016-12-12 02:50:51 --> Total execution time: 0.0285
INFO - 2016-12-12 02:51:27 --> Config Class Initialized
INFO - 2016-12-12 02:51:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:51:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:51:27 --> Utf8 Class Initialized
INFO - 2016-12-12 02:51:27 --> URI Class Initialized
INFO - 2016-12-12 02:51:27 --> Router Class Initialized
INFO - 2016-12-12 02:51:27 --> Output Class Initialized
INFO - 2016-12-12 02:51:27 --> Security Class Initialized
DEBUG - 2016-12-12 02:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:51:27 --> Input Class Initialized
INFO - 2016-12-12 02:51:27 --> Language Class Initialized
ERROR - 2016-12-12 02:51:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:52:34 --> Config Class Initialized
INFO - 2016-12-12 02:52:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:52:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:52:34 --> Utf8 Class Initialized
INFO - 2016-12-12 02:52:34 --> URI Class Initialized
INFO - 2016-12-12 02:52:34 --> Router Class Initialized
INFO - 2016-12-12 02:52:34 --> Output Class Initialized
INFO - 2016-12-12 02:52:34 --> Security Class Initialized
DEBUG - 2016-12-12 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:52:34 --> Input Class Initialized
INFO - 2016-12-12 02:52:34 --> Language Class Initialized
INFO - 2016-12-12 02:52:34 --> Loader Class Initialized
INFO - 2016-12-12 02:52:34 --> Database Driver Class Initialized
INFO - 2016-12-12 02:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:52:34 --> Controller Class Initialized
INFO - 2016-12-12 02:52:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:52:34 --> Email Class Initialized
INFO - 2016-12-12 02:52:34 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-12 02:52:34 --> Final output sent to browser
DEBUG - 2016-12-12 02:52:34 --> Total execution time: 0.1180
INFO - 2016-12-12 02:54:25 --> Config Class Initialized
INFO - 2016-12-12 02:54:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:54:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:54:25 --> Utf8 Class Initialized
INFO - 2016-12-12 02:54:25 --> URI Class Initialized
DEBUG - 2016-12-12 02:54:25 --> No URI present. Default controller set.
INFO - 2016-12-12 02:54:25 --> Router Class Initialized
INFO - 2016-12-12 02:54:25 --> Output Class Initialized
INFO - 2016-12-12 02:54:25 --> Security Class Initialized
DEBUG - 2016-12-12 02:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:54:25 --> Input Class Initialized
INFO - 2016-12-12 02:54:25 --> Language Class Initialized
ERROR - 2016-12-12 02:54:25 --> Severity: Parsing Error --> syntax error, unexpected '$phone' (T_VARIABLE) /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 141
INFO - 2016-12-12 02:54:48 --> Config Class Initialized
INFO - 2016-12-12 02:54:48 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:54:48 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:54:48 --> Utf8 Class Initialized
INFO - 2016-12-12 02:54:48 --> URI Class Initialized
DEBUG - 2016-12-12 02:54:48 --> No URI present. Default controller set.
INFO - 2016-12-12 02:54:48 --> Router Class Initialized
INFO - 2016-12-12 02:54:48 --> Output Class Initialized
INFO - 2016-12-12 02:54:48 --> Security Class Initialized
DEBUG - 2016-12-12 02:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:54:48 --> Input Class Initialized
INFO - 2016-12-12 02:54:48 --> Language Class Initialized
ERROR - 2016-12-12 02:54:48 --> Severity: Parsing Error --> syntax error, unexpected '$phone' (T_VARIABLE) /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 141
INFO - 2016-12-12 02:55:28 --> Config Class Initialized
INFO - 2016-12-12 02:55:28 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:55:28 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:55:28 --> Utf8 Class Initialized
INFO - 2016-12-12 02:55:28 --> URI Class Initialized
DEBUG - 2016-12-12 02:55:28 --> No URI present. Default controller set.
INFO - 2016-12-12 02:55:28 --> Router Class Initialized
INFO - 2016-12-12 02:55:28 --> Output Class Initialized
INFO - 2016-12-12 02:55:28 --> Security Class Initialized
DEBUG - 2016-12-12 02:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:55:28 --> Input Class Initialized
INFO - 2016-12-12 02:55:28 --> Language Class Initialized
INFO - 2016-12-12 02:55:28 --> Loader Class Initialized
INFO - 2016-12-12 02:55:28 --> Database Driver Class Initialized
INFO - 2016-12-12 02:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:55:28 --> Controller Class Initialized
INFO - 2016-12-12 02:55:28 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:55:28 --> Final output sent to browser
DEBUG - 2016-12-12 02:55:28 --> Total execution time: 0.0134
INFO - 2016-12-12 02:55:29 --> Config Class Initialized
INFO - 2016-12-12 02:55:29 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:55:29 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:55:29 --> Utf8 Class Initialized
INFO - 2016-12-12 02:55:29 --> URI Class Initialized
INFO - 2016-12-12 02:55:29 --> Router Class Initialized
INFO - 2016-12-12 02:55:29 --> Output Class Initialized
INFO - 2016-12-12 02:55:29 --> Security Class Initialized
DEBUG - 2016-12-12 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:55:29 --> Input Class Initialized
INFO - 2016-12-12 02:55:29 --> Language Class Initialized
ERROR - 2016-12-12 02:55:29 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:56:03 --> Config Class Initialized
INFO - 2016-12-12 02:56:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:56:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:56:03 --> Utf8 Class Initialized
INFO - 2016-12-12 02:56:03 --> URI Class Initialized
DEBUG - 2016-12-12 02:56:03 --> No URI present. Default controller set.
INFO - 2016-12-12 02:56:03 --> Router Class Initialized
INFO - 2016-12-12 02:56:03 --> Output Class Initialized
INFO - 2016-12-12 02:56:03 --> Security Class Initialized
DEBUG - 2016-12-12 02:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:56:03 --> Input Class Initialized
INFO - 2016-12-12 02:56:03 --> Language Class Initialized
INFO - 2016-12-12 02:56:03 --> Loader Class Initialized
INFO - 2016-12-12 02:56:04 --> Database Driver Class Initialized
INFO - 2016-12-12 02:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:56:04 --> Controller Class Initialized
INFO - 2016-12-12 02:56:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:56:04 --> Final output sent to browser
DEBUG - 2016-12-12 02:56:04 --> Total execution time: 0.0129
INFO - 2016-12-12 02:56:04 --> Config Class Initialized
INFO - 2016-12-12 02:56:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:56:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:56:04 --> Utf8 Class Initialized
INFO - 2016-12-12 02:56:04 --> URI Class Initialized
INFO - 2016-12-12 02:56:04 --> Router Class Initialized
INFO - 2016-12-12 02:56:04 --> Output Class Initialized
INFO - 2016-12-12 02:56:04 --> Security Class Initialized
DEBUG - 2016-12-12 02:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:56:04 --> Input Class Initialized
INFO - 2016-12-12 02:56:04 --> Language Class Initialized
ERROR - 2016-12-12 02:56:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:56:25 --> Config Class Initialized
INFO - 2016-12-12 02:56:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:56:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:56:25 --> Utf8 Class Initialized
INFO - 2016-12-12 02:56:25 --> URI Class Initialized
DEBUG - 2016-12-12 02:56:25 --> No URI present. Default controller set.
INFO - 2016-12-12 02:56:25 --> Router Class Initialized
INFO - 2016-12-12 02:56:25 --> Output Class Initialized
INFO - 2016-12-12 02:56:25 --> Security Class Initialized
DEBUG - 2016-12-12 02:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:56:25 --> Input Class Initialized
INFO - 2016-12-12 02:56:25 --> Language Class Initialized
INFO - 2016-12-12 02:56:25 --> Loader Class Initialized
INFO - 2016-12-12 02:56:25 --> Database Driver Class Initialized
INFO - 2016-12-12 02:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:56:25 --> Controller Class Initialized
INFO - 2016-12-12 02:56:25 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:56:25 --> Final output sent to browser
DEBUG - 2016-12-12 02:56:25 --> Total execution time: 0.0133
INFO - 2016-12-12 02:56:56 --> Config Class Initialized
INFO - 2016-12-12 02:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:56:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:56:56 --> Utf8 Class Initialized
INFO - 2016-12-12 02:56:56 --> URI Class Initialized
INFO - 2016-12-12 02:56:56 --> Router Class Initialized
INFO - 2016-12-12 02:56:56 --> Output Class Initialized
INFO - 2016-12-12 02:56:56 --> Security Class Initialized
DEBUG - 2016-12-12 02:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:56:56 --> Input Class Initialized
INFO - 2016-12-12 02:56:56 --> Language Class Initialized
ERROR - 2016-12-12 02:56:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:57:48 --> Config Class Initialized
INFO - 2016-12-12 02:57:48 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:57:48 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:57:48 --> Utf8 Class Initialized
INFO - 2016-12-12 02:57:48 --> URI Class Initialized
INFO - 2016-12-12 02:57:48 --> Router Class Initialized
INFO - 2016-12-12 02:57:48 --> Output Class Initialized
INFO - 2016-12-12 02:57:48 --> Security Class Initialized
DEBUG - 2016-12-12 02:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:57:48 --> Input Class Initialized
INFO - 2016-12-12 02:57:48 --> Language Class Initialized
INFO - 2016-12-12 02:57:48 --> Loader Class Initialized
INFO - 2016-12-12 02:57:48 --> Database Driver Class Initialized
INFO - 2016-12-12 02:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:57:48 --> Controller Class Initialized
INFO - 2016-12-12 02:57:48 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:57:48 --> Email Class Initialized
INFO - 2016-12-12 02:57:48 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-12 02:57:48 --> Final output sent to browser
DEBUG - 2016-12-12 02:57:48 --> Total execution time: 0.0889
INFO - 2016-12-12 02:58:45 --> Config Class Initialized
INFO - 2016-12-12 02:58:45 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:58:45 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:58:45 --> Utf8 Class Initialized
INFO - 2016-12-12 02:58:45 --> URI Class Initialized
DEBUG - 2016-12-12 02:58:45 --> No URI present. Default controller set.
INFO - 2016-12-12 02:58:45 --> Router Class Initialized
INFO - 2016-12-12 02:58:45 --> Output Class Initialized
INFO - 2016-12-12 02:58:45 --> Security Class Initialized
DEBUG - 2016-12-12 02:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:58:45 --> Input Class Initialized
INFO - 2016-12-12 02:58:45 --> Language Class Initialized
INFO - 2016-12-12 02:58:45 --> Loader Class Initialized
INFO - 2016-12-12 02:58:45 --> Database Driver Class Initialized
INFO - 2016-12-12 02:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:58:45 --> Controller Class Initialized
INFO - 2016-12-12 02:58:45 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 02:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 02:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 02:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 02:58:45 --> Final output sent to browser
DEBUG - 2016-12-12 02:58:45 --> Total execution time: 0.0133
INFO - 2016-12-12 02:59:16 --> Config Class Initialized
INFO - 2016-12-12 02:59:16 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:59:16 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:59:16 --> Utf8 Class Initialized
INFO - 2016-12-12 02:59:16 --> URI Class Initialized
INFO - 2016-12-12 02:59:16 --> Router Class Initialized
INFO - 2016-12-12 02:59:16 --> Output Class Initialized
INFO - 2016-12-12 02:59:16 --> Security Class Initialized
DEBUG - 2016-12-12 02:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:59:16 --> Input Class Initialized
INFO - 2016-12-12 02:59:16 --> Language Class Initialized
ERROR - 2016-12-12 02:59:16 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 02:59:47 --> Config Class Initialized
INFO - 2016-12-12 02:59:47 --> Hooks Class Initialized
DEBUG - 2016-12-12 02:59:47 --> UTF-8 Support Enabled
INFO - 2016-12-12 02:59:47 --> Utf8 Class Initialized
INFO - 2016-12-12 02:59:47 --> URI Class Initialized
INFO - 2016-12-12 02:59:47 --> Router Class Initialized
INFO - 2016-12-12 02:59:47 --> Output Class Initialized
INFO - 2016-12-12 02:59:47 --> Security Class Initialized
DEBUG - 2016-12-12 02:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 02:59:47 --> Input Class Initialized
INFO - 2016-12-12 02:59:47 --> Language Class Initialized
INFO - 2016-12-12 02:59:47 --> Loader Class Initialized
INFO - 2016-12-12 02:59:47 --> Database Driver Class Initialized
INFO - 2016-12-12 02:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 02:59:47 --> Controller Class Initialized
INFO - 2016-12-12 02:59:47 --> Helper loaded: url_helper
DEBUG - 2016-12-12 02:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 02:59:47 --> Email Class Initialized
INFO - 2016-12-12 02:59:47 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-12 02:59:48 --> Final output sent to browser
DEBUG - 2016-12-12 02:59:48 --> Total execution time: 0.8781
INFO - 2016-12-12 03:01:31 --> Config Class Initialized
INFO - 2016-12-12 03:01:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:01:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:01:31 --> Utf8 Class Initialized
INFO - 2016-12-12 03:01:31 --> URI Class Initialized
DEBUG - 2016-12-12 03:01:31 --> No URI present. Default controller set.
INFO - 2016-12-12 03:01:31 --> Router Class Initialized
INFO - 2016-12-12 03:01:31 --> Output Class Initialized
INFO - 2016-12-12 03:01:31 --> Security Class Initialized
DEBUG - 2016-12-12 03:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:01:31 --> Input Class Initialized
INFO - 2016-12-12 03:01:31 --> Language Class Initialized
INFO - 2016-12-12 03:01:31 --> Loader Class Initialized
INFO - 2016-12-12 03:01:31 --> Database Driver Class Initialized
INFO - 2016-12-12 03:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:01:31 --> Controller Class Initialized
INFO - 2016-12-12 03:01:31 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:01:31 --> Final output sent to browser
DEBUG - 2016-12-12 03:01:31 --> Total execution time: 0.0613
INFO - 2016-12-12 03:01:32 --> Config Class Initialized
INFO - 2016-12-12 03:01:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:01:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:01:32 --> Utf8 Class Initialized
INFO - 2016-12-12 03:01:32 --> URI Class Initialized
INFO - 2016-12-12 03:01:32 --> Router Class Initialized
INFO - 2016-12-12 03:01:32 --> Output Class Initialized
INFO - 2016-12-12 03:01:32 --> Security Class Initialized
DEBUG - 2016-12-12 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:01:32 --> Input Class Initialized
INFO - 2016-12-12 03:01:32 --> Language Class Initialized
ERROR - 2016-12-12 03:01:32 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 03:02:02 --> Config Class Initialized
INFO - 2016-12-12 03:02:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:02:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:02:02 --> Utf8 Class Initialized
INFO - 2016-12-12 03:02:02 --> URI Class Initialized
INFO - 2016-12-12 03:02:02 --> Router Class Initialized
INFO - 2016-12-12 03:02:02 --> Output Class Initialized
INFO - 2016-12-12 03:02:02 --> Security Class Initialized
DEBUG - 2016-12-12 03:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:02:02 --> Input Class Initialized
INFO - 2016-12-12 03:02:02 --> Language Class Initialized
ERROR - 2016-12-12 03:02:02 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 03:02:16 --> Config Class Initialized
INFO - 2016-12-12 03:02:16 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:02:16 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:02:16 --> Utf8 Class Initialized
INFO - 2016-12-12 03:02:16 --> URI Class Initialized
INFO - 2016-12-12 03:02:16 --> Router Class Initialized
INFO - 2016-12-12 03:02:16 --> Output Class Initialized
INFO - 2016-12-12 03:02:16 --> Security Class Initialized
DEBUG - 2016-12-12 03:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:02:16 --> Input Class Initialized
INFO - 2016-12-12 03:02:16 --> Language Class Initialized
INFO - 2016-12-12 03:02:16 --> Loader Class Initialized
INFO - 2016-12-12 03:02:16 --> Database Driver Class Initialized
INFO - 2016-12-12 03:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:02:16 --> Controller Class Initialized
INFO - 2016-12-12 03:02:16 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:02:16 --> Email Class Initialized
INFO - 2016-12-12 03:02:16 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-12 03:02:16 --> Final output sent to browser
DEBUG - 2016-12-12 03:02:16 --> Total execution time: 0.0637
INFO - 2016-12-12 03:03:34 --> Config Class Initialized
INFO - 2016-12-12 03:03:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:03:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:03:34 --> Utf8 Class Initialized
INFO - 2016-12-12 03:03:34 --> URI Class Initialized
DEBUG - 2016-12-12 03:03:34 --> No URI present. Default controller set.
INFO - 2016-12-12 03:03:34 --> Router Class Initialized
INFO - 2016-12-12 03:03:34 --> Output Class Initialized
INFO - 2016-12-12 03:03:34 --> Security Class Initialized
DEBUG - 2016-12-12 03:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:03:34 --> Input Class Initialized
INFO - 2016-12-12 03:03:34 --> Language Class Initialized
INFO - 2016-12-12 03:03:34 --> Loader Class Initialized
INFO - 2016-12-12 03:03:34 --> Database Driver Class Initialized
INFO - 2016-12-12 03:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:03:35 --> Controller Class Initialized
INFO - 2016-12-12 03:03:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:03:35 --> Final output sent to browser
DEBUG - 2016-12-12 03:03:35 --> Total execution time: 0.0138
INFO - 2016-12-12 03:03:35 --> Config Class Initialized
INFO - 2016-12-12 03:03:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:03:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:03:35 --> Utf8 Class Initialized
INFO - 2016-12-12 03:03:35 --> URI Class Initialized
INFO - 2016-12-12 03:03:35 --> Router Class Initialized
INFO - 2016-12-12 03:03:35 --> Output Class Initialized
INFO - 2016-12-12 03:03:35 --> Security Class Initialized
DEBUG - 2016-12-12 03:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:03:35 --> Input Class Initialized
INFO - 2016-12-12 03:03:35 --> Language Class Initialized
ERROR - 2016-12-12 03:03:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 03:03:35 --> Config Class Initialized
INFO - 2016-12-12 03:03:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:03:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:03:35 --> Utf8 Class Initialized
INFO - 2016-12-12 03:03:35 --> URI Class Initialized
INFO - 2016-12-12 03:03:35 --> Router Class Initialized
INFO - 2016-12-12 03:03:35 --> Output Class Initialized
INFO - 2016-12-12 03:03:35 --> Security Class Initialized
DEBUG - 2016-12-12 03:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:03:35 --> Input Class Initialized
INFO - 2016-12-12 03:03:35 --> Language Class Initialized
ERROR - 2016-12-12 03:03:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 03:04:59 --> Config Class Initialized
INFO - 2016-12-12 03:04:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:04:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:05:00 --> Utf8 Class Initialized
INFO - 2016-12-12 03:05:00 --> URI Class Initialized
INFO - 2016-12-12 03:05:00 --> Router Class Initialized
INFO - 2016-12-12 03:05:00 --> Output Class Initialized
INFO - 2016-12-12 03:05:00 --> Security Class Initialized
DEBUG - 2016-12-12 03:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:05:00 --> Input Class Initialized
INFO - 2016-12-12 03:05:00 --> Language Class Initialized
INFO - 2016-12-12 03:05:00 --> Loader Class Initialized
INFO - 2016-12-12 03:05:00 --> Database Driver Class Initialized
INFO - 2016-12-12 03:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:05:00 --> Controller Class Initialized
INFO - 2016-12-12 03:05:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:05:00 --> Email Class Initialized
INFO - 2016-12-12 03:05:00 --> Language file loaded: language/english/email_lang.php
INFO - 2016-12-12 03:05:00 --> Final output sent to browser
DEBUG - 2016-12-12 03:05:00 --> Total execution time: 0.2424
INFO - 2016-12-12 03:39:37 --> Config Class Initialized
INFO - 2016-12-12 03:39:37 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:39:37 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:39:37 --> Utf8 Class Initialized
INFO - 2016-12-12 03:39:37 --> URI Class Initialized
DEBUG - 2016-12-12 03:39:37 --> No URI present. Default controller set.
INFO - 2016-12-12 03:39:38 --> Router Class Initialized
INFO - 2016-12-12 03:39:38 --> Output Class Initialized
INFO - 2016-12-12 03:39:38 --> Security Class Initialized
DEBUG - 2016-12-12 03:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:39:38 --> Input Class Initialized
INFO - 2016-12-12 03:39:38 --> Language Class Initialized
INFO - 2016-12-12 03:39:38 --> Loader Class Initialized
INFO - 2016-12-12 03:39:38 --> Database Driver Class Initialized
INFO - 2016-12-12 03:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:39:38 --> Controller Class Initialized
INFO - 2016-12-12 03:39:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:39:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:39:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:39:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:39:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:39:38 --> Final output sent to browser
DEBUG - 2016-12-12 03:39:38 --> Total execution time: 1.1424
INFO - 2016-12-12 03:39:46 --> Config Class Initialized
INFO - 2016-12-12 03:39:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:39:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:39:46 --> Utf8 Class Initialized
INFO - 2016-12-12 03:39:46 --> URI Class Initialized
INFO - 2016-12-12 03:39:46 --> Router Class Initialized
INFO - 2016-12-12 03:39:46 --> Output Class Initialized
INFO - 2016-12-12 03:39:46 --> Security Class Initialized
DEBUG - 2016-12-12 03:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:39:46 --> Input Class Initialized
INFO - 2016-12-12 03:39:46 --> Language Class Initialized
INFO - 2016-12-12 03:39:46 --> Loader Class Initialized
INFO - 2016-12-12 03:39:46 --> Database Driver Class Initialized
INFO - 2016-12-12 03:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:39:46 --> Controller Class Initialized
INFO - 2016-12-12 03:39:46 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:39:46 --> Final output sent to browser
DEBUG - 2016-12-12 03:39:46 --> Total execution time: 0.0134
INFO - 2016-12-12 03:40:41 --> Config Class Initialized
INFO - 2016-12-12 03:40:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:40:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:40:41 --> Utf8 Class Initialized
INFO - 2016-12-12 03:40:41 --> URI Class Initialized
INFO - 2016-12-12 03:40:41 --> Router Class Initialized
INFO - 2016-12-12 03:40:41 --> Output Class Initialized
INFO - 2016-12-12 03:40:41 --> Security Class Initialized
DEBUG - 2016-12-12 03:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:40:41 --> Input Class Initialized
INFO - 2016-12-12 03:40:41 --> Language Class Initialized
INFO - 2016-12-12 03:40:41 --> Loader Class Initialized
INFO - 2016-12-12 03:40:41 --> Database Driver Class Initialized
INFO - 2016-12-12 03:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:40:41 --> Controller Class Initialized
INFO - 2016-12-12 03:40:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:40:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:40:43 --> Config Class Initialized
INFO - 2016-12-12 03:40:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:40:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:40:43 --> Utf8 Class Initialized
INFO - 2016-12-12 03:40:43 --> URI Class Initialized
INFO - 2016-12-12 03:40:43 --> Router Class Initialized
INFO - 2016-12-12 03:40:43 --> Output Class Initialized
INFO - 2016-12-12 03:40:43 --> Security Class Initialized
DEBUG - 2016-12-12 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:40:43 --> Input Class Initialized
INFO - 2016-12-12 03:40:43 --> Language Class Initialized
INFO - 2016-12-12 03:40:43 --> Loader Class Initialized
INFO - 2016-12-12 03:40:43 --> Database Driver Class Initialized
INFO - 2016-12-12 03:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:40:43 --> Controller Class Initialized
DEBUG - 2016-12-12 03:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:40:43 --> Helper loaded: url_helper
INFO - 2016-12-12 03:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 03:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-12 03:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-12 03:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:40:43 --> Final output sent to browser
DEBUG - 2016-12-12 03:40:43 --> Total execution time: 0.0650
INFO - 2016-12-12 03:40:44 --> Config Class Initialized
INFO - 2016-12-12 03:40:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:40:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:40:44 --> Utf8 Class Initialized
INFO - 2016-12-12 03:40:44 --> URI Class Initialized
INFO - 2016-12-12 03:40:44 --> Router Class Initialized
INFO - 2016-12-12 03:40:44 --> Output Class Initialized
INFO - 2016-12-12 03:40:44 --> Security Class Initialized
DEBUG - 2016-12-12 03:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:40:44 --> Input Class Initialized
INFO - 2016-12-12 03:40:44 --> Language Class Initialized
INFO - 2016-12-12 03:40:44 --> Loader Class Initialized
INFO - 2016-12-12 03:40:44 --> Database Driver Class Initialized
INFO - 2016-12-12 03:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:40:44 --> Controller Class Initialized
INFO - 2016-12-12 03:40:44 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:40:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:40:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:40:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:40:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:40:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:40:44 --> Final output sent to browser
DEBUG - 2016-12-12 03:40:44 --> Total execution time: 0.0130
INFO - 2016-12-12 03:40:48 --> Config Class Initialized
INFO - 2016-12-12 03:40:48 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:40:48 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:40:48 --> Utf8 Class Initialized
INFO - 2016-12-12 03:40:48 --> URI Class Initialized
INFO - 2016-12-12 03:40:48 --> Router Class Initialized
INFO - 2016-12-12 03:40:48 --> Output Class Initialized
INFO - 2016-12-12 03:40:48 --> Security Class Initialized
DEBUG - 2016-12-12 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:40:48 --> Input Class Initialized
INFO - 2016-12-12 03:40:48 --> Language Class Initialized
INFO - 2016-12-12 03:40:48 --> Loader Class Initialized
INFO - 2016-12-12 03:40:48 --> Database Driver Class Initialized
INFO - 2016-12-12 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:40:48 --> Controller Class Initialized
INFO - 2016-12-12 03:40:48 --> Upload Class Initialized
DEBUG - 2016-12-12 03:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:40:49 --> Helper loaded: url_helper
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:40:49 --> Final output sent to browser
DEBUG - 2016-12-12 03:40:49 --> Total execution time: 0.1312
INFO - 2016-12-12 03:40:49 --> Config Class Initialized
INFO - 2016-12-12 03:40:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:40:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:40:49 --> Utf8 Class Initialized
INFO - 2016-12-12 03:40:49 --> URI Class Initialized
INFO - 2016-12-12 03:40:49 --> Router Class Initialized
INFO - 2016-12-12 03:40:49 --> Output Class Initialized
INFO - 2016-12-12 03:40:49 --> Security Class Initialized
DEBUG - 2016-12-12 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:40:49 --> Input Class Initialized
INFO - 2016-12-12 03:40:49 --> Language Class Initialized
INFO - 2016-12-12 03:40:49 --> Loader Class Initialized
INFO - 2016-12-12 03:40:49 --> Database Driver Class Initialized
INFO - 2016-12-12 03:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:40:49 --> Controller Class Initialized
INFO - 2016-12-12 03:40:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:40:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:40:49 --> Final output sent to browser
DEBUG - 2016-12-12 03:40:49 --> Total execution time: 0.0132
INFO - 2016-12-12 03:41:18 --> Config Class Initialized
INFO - 2016-12-12 03:41:18 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:41:18 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:41:18 --> Utf8 Class Initialized
INFO - 2016-12-12 03:41:18 --> URI Class Initialized
INFO - 2016-12-12 03:41:18 --> Router Class Initialized
INFO - 2016-12-12 03:41:18 --> Output Class Initialized
INFO - 2016-12-12 03:41:18 --> Security Class Initialized
DEBUG - 2016-12-12 03:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:41:18 --> Input Class Initialized
INFO - 2016-12-12 03:41:18 --> Language Class Initialized
INFO - 2016-12-12 03:41:18 --> Loader Class Initialized
INFO - 2016-12-12 03:41:18 --> Database Driver Class Initialized
INFO - 2016-12-12 03:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:41:18 --> Controller Class Initialized
DEBUG - 2016-12-12 03:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:41:18 --> Helper loaded: url_helper
INFO - 2016-12-12 03:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:41:19 --> Final output sent to browser
DEBUG - 2016-12-12 03:41:19 --> Total execution time: 0.0631
INFO - 2016-12-12 03:41:19 --> Config Class Initialized
INFO - 2016-12-12 03:41:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:41:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:41:19 --> Utf8 Class Initialized
INFO - 2016-12-12 03:41:19 --> URI Class Initialized
INFO - 2016-12-12 03:41:19 --> Router Class Initialized
INFO - 2016-12-12 03:41:19 --> Output Class Initialized
INFO - 2016-12-12 03:41:19 --> Security Class Initialized
DEBUG - 2016-12-12 03:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:41:19 --> Input Class Initialized
INFO - 2016-12-12 03:41:19 --> Language Class Initialized
INFO - 2016-12-12 03:41:19 --> Loader Class Initialized
INFO - 2016-12-12 03:41:19 --> Database Driver Class Initialized
INFO - 2016-12-12 03:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:41:19 --> Controller Class Initialized
INFO - 2016-12-12 03:41:19 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:41:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:41:19 --> Final output sent to browser
DEBUG - 2016-12-12 03:41:19 --> Total execution time: 0.0188
INFO - 2016-12-12 03:41:23 --> Config Class Initialized
INFO - 2016-12-12 03:41:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:41:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:41:23 --> Utf8 Class Initialized
INFO - 2016-12-12 03:41:23 --> URI Class Initialized
INFO - 2016-12-12 03:41:23 --> Router Class Initialized
INFO - 2016-12-12 03:41:23 --> Output Class Initialized
INFO - 2016-12-12 03:41:23 --> Security Class Initialized
DEBUG - 2016-12-12 03:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:41:23 --> Input Class Initialized
INFO - 2016-12-12 03:41:23 --> Language Class Initialized
INFO - 2016-12-12 03:41:23 --> Loader Class Initialized
INFO - 2016-12-12 03:41:23 --> Database Driver Class Initialized
INFO - 2016-12-12 03:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:41:23 --> Controller Class Initialized
INFO - 2016-12-12 03:41:23 --> Helper loaded: date_helper
DEBUG - 2016-12-12 03:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:41:23 --> Helper loaded: url_helper
INFO - 2016-12-12 03:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 03:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-12 03:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-12 03:41:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:41:23 --> Final output sent to browser
DEBUG - 2016-12-12 03:41:23 --> Total execution time: 0.1147
INFO - 2016-12-12 03:41:24 --> Config Class Initialized
INFO - 2016-12-12 03:41:24 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:41:24 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:41:24 --> Utf8 Class Initialized
INFO - 2016-12-12 03:41:24 --> URI Class Initialized
INFO - 2016-12-12 03:41:24 --> Router Class Initialized
INFO - 2016-12-12 03:41:24 --> Output Class Initialized
INFO - 2016-12-12 03:41:24 --> Security Class Initialized
DEBUG - 2016-12-12 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:41:24 --> Input Class Initialized
INFO - 2016-12-12 03:41:24 --> Language Class Initialized
INFO - 2016-12-12 03:41:24 --> Loader Class Initialized
INFO - 2016-12-12 03:41:24 --> Database Driver Class Initialized
INFO - 2016-12-12 03:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:41:24 --> Controller Class Initialized
INFO - 2016-12-12 03:41:24 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:41:24 --> Final output sent to browser
DEBUG - 2016-12-12 03:41:24 --> Total execution time: 0.0136
INFO - 2016-12-12 03:47:31 --> Config Class Initialized
INFO - 2016-12-12 03:47:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:47:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:47:31 --> Utf8 Class Initialized
INFO - 2016-12-12 03:47:31 --> URI Class Initialized
DEBUG - 2016-12-12 03:47:31 --> No URI present. Default controller set.
INFO - 2016-12-12 03:47:31 --> Router Class Initialized
INFO - 2016-12-12 03:47:31 --> Output Class Initialized
INFO - 2016-12-12 03:47:31 --> Security Class Initialized
DEBUG - 2016-12-12 03:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:47:31 --> Input Class Initialized
INFO - 2016-12-12 03:47:31 --> Language Class Initialized
INFO - 2016-12-12 03:47:31 --> Loader Class Initialized
INFO - 2016-12-12 03:47:32 --> Database Driver Class Initialized
INFO - 2016-12-12 03:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:47:32 --> Controller Class Initialized
INFO - 2016-12-12 03:47:32 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:47:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:47:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:47:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:47:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:47:32 --> Final output sent to browser
DEBUG - 2016-12-12 03:47:32 --> Total execution time: 1.0579
INFO - 2016-12-12 03:47:41 --> Config Class Initialized
INFO - 2016-12-12 03:47:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:47:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:47:41 --> Utf8 Class Initialized
INFO - 2016-12-12 03:47:41 --> URI Class Initialized
INFO - 2016-12-12 03:47:41 --> Router Class Initialized
INFO - 2016-12-12 03:47:41 --> Output Class Initialized
INFO - 2016-12-12 03:47:41 --> Security Class Initialized
DEBUG - 2016-12-12 03:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:47:41 --> Input Class Initialized
INFO - 2016-12-12 03:47:41 --> Language Class Initialized
INFO - 2016-12-12 03:47:41 --> Loader Class Initialized
INFO - 2016-12-12 03:47:41 --> Database Driver Class Initialized
INFO - 2016-12-12 03:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:47:41 --> Controller Class Initialized
INFO - 2016-12-12 03:47:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:47:41 --> Helper loaded: form_helper
INFO - 2016-12-12 03:47:41 --> Form Validation Class Initialized
INFO - 2016-12-12 03:47:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-12 03:47:42 --> Config Class Initialized
INFO - 2016-12-12 03:47:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:47:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:47:42 --> Utf8 Class Initialized
INFO - 2016-12-12 03:47:42 --> URI Class Initialized
INFO - 2016-12-12 03:47:42 --> Router Class Initialized
INFO - 2016-12-12 03:47:42 --> Output Class Initialized
INFO - 2016-12-12 03:47:42 --> Security Class Initialized
DEBUG - 2016-12-12 03:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:47:42 --> Input Class Initialized
INFO - 2016-12-12 03:47:42 --> Language Class Initialized
INFO - 2016-12-12 03:47:42 --> Loader Class Initialized
INFO - 2016-12-12 03:47:42 --> Database Driver Class Initialized
INFO - 2016-12-12 03:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:47:42 --> Controller Class Initialized
INFO - 2016-12-12 03:47:42 --> Helper loaded: date_helper
INFO - 2016-12-12 03:47:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:47:42 --> Helper loaded: form_helper
INFO - 2016-12-12 03:47:42 --> Form Validation Class Initialized
INFO - 2016-12-12 03:47:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:47:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:47:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-12 03:47:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-12 03:47:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:47:42 --> Final output sent to browser
DEBUG - 2016-12-12 03:47:42 --> Total execution time: 0.1365
INFO - 2016-12-12 03:47:42 --> Config Class Initialized
INFO - 2016-12-12 03:47:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:47:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:47:42 --> Utf8 Class Initialized
INFO - 2016-12-12 03:47:42 --> URI Class Initialized
INFO - 2016-12-12 03:47:42 --> Router Class Initialized
INFO - 2016-12-12 03:47:42 --> Output Class Initialized
INFO - 2016-12-12 03:47:42 --> Security Class Initialized
DEBUG - 2016-12-12 03:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:47:42 --> Input Class Initialized
INFO - 2016-12-12 03:47:42 --> Language Class Initialized
ERROR - 2016-12-12 03:47:42 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:47:44 --> Config Class Initialized
INFO - 2016-12-12 03:47:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:47:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:47:44 --> Utf8 Class Initialized
INFO - 2016-12-12 03:47:44 --> URI Class Initialized
INFO - 2016-12-12 03:47:44 --> Router Class Initialized
INFO - 2016-12-12 03:47:44 --> Output Class Initialized
INFO - 2016-12-12 03:47:44 --> Security Class Initialized
DEBUG - 2016-12-12 03:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:47:44 --> Input Class Initialized
INFO - 2016-12-12 03:47:44 --> Language Class Initialized
INFO - 2016-12-12 03:47:44 --> Loader Class Initialized
INFO - 2016-12-12 03:47:44 --> Database Driver Class Initialized
INFO - 2016-12-12 03:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:47:44 --> Controller Class Initialized
INFO - 2016-12-12 03:47:44 --> Helper loaded: date_helper
INFO - 2016-12-12 03:47:44 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:47:44 --> Helper loaded: form_helper
INFO - 2016-12-12 03:47:44 --> Form Validation Class Initialized
INFO - 2016-12-12 03:47:44 --> Final output sent to browser
DEBUG - 2016-12-12 03:47:44 --> Total execution time: 0.0150
INFO - 2016-12-12 03:47:59 --> Config Class Initialized
INFO - 2016-12-12 03:47:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:47:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:47:59 --> Utf8 Class Initialized
INFO - 2016-12-12 03:47:59 --> URI Class Initialized
DEBUG - 2016-12-12 03:47:59 --> No URI present. Default controller set.
INFO - 2016-12-12 03:47:59 --> Router Class Initialized
INFO - 2016-12-12 03:47:59 --> Output Class Initialized
INFO - 2016-12-12 03:47:59 --> Security Class Initialized
DEBUG - 2016-12-12 03:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:47:59 --> Input Class Initialized
INFO - 2016-12-12 03:47:59 --> Language Class Initialized
INFO - 2016-12-12 03:47:59 --> Loader Class Initialized
INFO - 2016-12-12 03:47:59 --> Database Driver Class Initialized
INFO - 2016-12-12 03:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:47:59 --> Controller Class Initialized
INFO - 2016-12-12 03:47:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:47:59 --> Final output sent to browser
DEBUG - 2016-12-12 03:47:59 --> Total execution time: 0.0147
INFO - 2016-12-12 03:48:02 --> Config Class Initialized
INFO - 2016-12-12 03:48:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:02 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:02 --> URI Class Initialized
INFO - 2016-12-12 03:48:02 --> Router Class Initialized
INFO - 2016-12-12 03:48:02 --> Output Class Initialized
INFO - 2016-12-12 03:48:02 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:02 --> Input Class Initialized
INFO - 2016-12-12 03:48:02 --> Language Class Initialized
INFO - 2016-12-12 03:48:02 --> Loader Class Initialized
INFO - 2016-12-12 03:48:02 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:02 --> Controller Class Initialized
INFO - 2016-12-12 03:48:02 --> Upload Class Initialized
INFO - 2016-12-12 03:48:02 --> Helper loaded: date_helper
INFO - 2016-12-12 03:48:02 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:02 --> Helper loaded: form_helper
INFO - 2016-12-12 03:48:02 --> Form Validation Class Initialized
INFO - 2016-12-12 03:48:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:48:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:48:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:48:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:48:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:48:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:48:02 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:02 --> Total execution time: 0.0333
INFO - 2016-12-12 03:48:04 --> Config Class Initialized
INFO - 2016-12-12 03:48:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:04 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:04 --> URI Class Initialized
INFO - 2016-12-12 03:48:04 --> Router Class Initialized
INFO - 2016-12-12 03:48:04 --> Output Class Initialized
INFO - 2016-12-12 03:48:04 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:04 --> Input Class Initialized
INFO - 2016-12-12 03:48:04 --> Language Class Initialized
INFO - 2016-12-12 03:48:04 --> Loader Class Initialized
INFO - 2016-12-12 03:48:04 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:04 --> Controller Class Initialized
INFO - 2016-12-12 03:48:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:48:04 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:04 --> Total execution time: 0.0131
INFO - 2016-12-12 03:48:17 --> Config Class Initialized
INFO - 2016-12-12 03:48:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:17 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:17 --> URI Class Initialized
DEBUG - 2016-12-12 03:48:17 --> No URI present. Default controller set.
INFO - 2016-12-12 03:48:17 --> Router Class Initialized
INFO - 2016-12-12 03:48:17 --> Output Class Initialized
INFO - 2016-12-12 03:48:17 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:17 --> Input Class Initialized
INFO - 2016-12-12 03:48:17 --> Language Class Initialized
INFO - 2016-12-12 03:48:17 --> Loader Class Initialized
INFO - 2016-12-12 03:48:17 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:17 --> Controller Class Initialized
INFO - 2016-12-12 03:48:17 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:48:17 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:17 --> Total execution time: 0.0308
INFO - 2016-12-12 03:48:18 --> Config Class Initialized
INFO - 2016-12-12 03:48:18 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:18 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:18 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:18 --> URI Class Initialized
INFO - 2016-12-12 03:48:18 --> Router Class Initialized
INFO - 2016-12-12 03:48:18 --> Output Class Initialized
INFO - 2016-12-12 03:48:18 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:18 --> Input Class Initialized
INFO - 2016-12-12 03:48:18 --> Language Class Initialized
INFO - 2016-12-12 03:48:18 --> Loader Class Initialized
INFO - 2016-12-12 03:48:18 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:18 --> Controller Class Initialized
INFO - 2016-12-12 03:48:18 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:48:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:48:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:48:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:48:18 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:18 --> Total execution time: 0.0139
INFO - 2016-12-12 03:48:20 --> Config Class Initialized
INFO - 2016-12-12 03:48:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:20 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:20 --> URI Class Initialized
DEBUG - 2016-12-12 03:48:20 --> No URI present. Default controller set.
INFO - 2016-12-12 03:48:20 --> Router Class Initialized
INFO - 2016-12-12 03:48:20 --> Output Class Initialized
INFO - 2016-12-12 03:48:20 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:20 --> Input Class Initialized
INFO - 2016-12-12 03:48:20 --> Language Class Initialized
INFO - 2016-12-12 03:48:20 --> Loader Class Initialized
INFO - 2016-12-12 03:48:20 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:20 --> Controller Class Initialized
INFO - 2016-12-12 03:48:20 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:48:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:48:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:48:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:48:20 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:20 --> Total execution time: 0.0130
INFO - 2016-12-12 03:48:21 --> Config Class Initialized
INFO - 2016-12-12 03:48:21 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:21 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:21 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:21 --> URI Class Initialized
INFO - 2016-12-12 03:48:21 --> Router Class Initialized
INFO - 2016-12-12 03:48:21 --> Output Class Initialized
INFO - 2016-12-12 03:48:21 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:21 --> Input Class Initialized
INFO - 2016-12-12 03:48:21 --> Language Class Initialized
INFO - 2016-12-12 03:48:21 --> Loader Class Initialized
INFO - 2016-12-12 03:48:21 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:21 --> Controller Class Initialized
INFO - 2016-12-12 03:48:21 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:48:21 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:21 --> Total execution time: 0.0130
INFO - 2016-12-12 03:48:21 --> Config Class Initialized
INFO - 2016-12-12 03:48:21 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:21 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:21 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:21 --> URI Class Initialized
DEBUG - 2016-12-12 03:48:21 --> No URI present. Default controller set.
INFO - 2016-12-12 03:48:21 --> Router Class Initialized
INFO - 2016-12-12 03:48:21 --> Output Class Initialized
INFO - 2016-12-12 03:48:21 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:21 --> Input Class Initialized
INFO - 2016-12-12 03:48:21 --> Language Class Initialized
INFO - 2016-12-12 03:48:21 --> Loader Class Initialized
INFO - 2016-12-12 03:48:21 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:21 --> Controller Class Initialized
INFO - 2016-12-12 03:48:21 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:48:21 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:21 --> Total execution time: 0.0130
INFO - 2016-12-12 03:48:21 --> Config Class Initialized
INFO - 2016-12-12 03:48:21 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:21 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:21 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:21 --> URI Class Initialized
INFO - 2016-12-12 03:48:21 --> Router Class Initialized
INFO - 2016-12-12 03:48:21 --> Output Class Initialized
INFO - 2016-12-12 03:48:21 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:21 --> Input Class Initialized
INFO - 2016-12-12 03:48:21 --> Language Class Initialized
INFO - 2016-12-12 03:48:21 --> Loader Class Initialized
INFO - 2016-12-12 03:48:21 --> Database Driver Class Initialized
INFO - 2016-12-12 03:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:48:21 --> Controller Class Initialized
INFO - 2016-12-12 03:48:21 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:48:21 --> Final output sent to browser
DEBUG - 2016-12-12 03:48:21 --> Total execution time: 0.0126
INFO - 2016-12-12 03:48:22 --> Config Class Initialized
INFO - 2016-12-12 03:48:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:48:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:48:22 --> Utf8 Class Initialized
INFO - 2016-12-12 03:48:22 --> URI Class Initialized
INFO - 2016-12-12 03:48:22 --> Router Class Initialized
INFO - 2016-12-12 03:48:22 --> Output Class Initialized
INFO - 2016-12-12 03:48:22 --> Security Class Initialized
DEBUG - 2016-12-12 03:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:48:22 --> Input Class Initialized
INFO - 2016-12-12 03:48:22 --> Language Class Initialized
ERROR - 2016-12-12 03:48:22 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:49:04 --> Config Class Initialized
INFO - 2016-12-12 03:49:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:04 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:04 --> URI Class Initialized
DEBUG - 2016-12-12 03:49:04 --> No URI present. Default controller set.
INFO - 2016-12-12 03:49:04 --> Router Class Initialized
INFO - 2016-12-12 03:49:04 --> Output Class Initialized
INFO - 2016-12-12 03:49:04 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:04 --> Input Class Initialized
INFO - 2016-12-12 03:49:04 --> Language Class Initialized
INFO - 2016-12-12 03:49:04 --> Loader Class Initialized
INFO - 2016-12-12 03:49:04 --> Database Driver Class Initialized
INFO - 2016-12-12 03:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:49:04 --> Controller Class Initialized
INFO - 2016-12-12 03:49:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:49:04 --> Final output sent to browser
DEBUG - 2016-12-12 03:49:04 --> Total execution time: 0.0128
INFO - 2016-12-12 03:49:04 --> Config Class Initialized
INFO - 2016-12-12 03:49:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:04 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:04 --> URI Class Initialized
INFO - 2016-12-12 03:49:04 --> Router Class Initialized
INFO - 2016-12-12 03:49:04 --> Output Class Initialized
INFO - 2016-12-12 03:49:04 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:04 --> Input Class Initialized
INFO - 2016-12-12 03:49:04 --> Language Class Initialized
INFO - 2016-12-12 03:49:04 --> Loader Class Initialized
INFO - 2016-12-12 03:49:04 --> Database Driver Class Initialized
INFO - 2016-12-12 03:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:49:04 --> Controller Class Initialized
INFO - 2016-12-12 03:49:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:49:04 --> Final output sent to browser
DEBUG - 2016-12-12 03:49:04 --> Total execution time: 0.0141
INFO - 2016-12-12 03:49:22 --> Config Class Initialized
INFO - 2016-12-12 03:49:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:22 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:22 --> URI Class Initialized
INFO - 2016-12-12 03:49:22 --> Router Class Initialized
INFO - 2016-12-12 03:49:22 --> Output Class Initialized
INFO - 2016-12-12 03:49:22 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:22 --> Input Class Initialized
INFO - 2016-12-12 03:49:22 --> Language Class Initialized
INFO - 2016-12-12 03:49:22 --> Loader Class Initialized
INFO - 2016-12-12 03:49:22 --> Database Driver Class Initialized
INFO - 2016-12-12 03:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:49:22 --> Controller Class Initialized
INFO - 2016-12-12 03:49:22 --> Upload Class Initialized
INFO - 2016-12-12 03:49:22 --> Helper loaded: date_helper
INFO - 2016-12-12 03:49:22 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:49:22 --> Helper loaded: form_helper
INFO - 2016-12-12 03:49:22 --> Form Validation Class Initialized
INFO - 2016-12-12 03:49:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:49:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:49:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:49:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:49:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:49:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:49:22 --> Final output sent to browser
DEBUG - 2016-12-12 03:49:22 --> Total execution time: 0.0158
INFO - 2016-12-12 03:49:22 --> Config Class Initialized
INFO - 2016-12-12 03:49:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:22 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:22 --> URI Class Initialized
INFO - 2016-12-12 03:49:22 --> Router Class Initialized
INFO - 2016-12-12 03:49:22 --> Output Class Initialized
INFO - 2016-12-12 03:49:22 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:22 --> Input Class Initialized
INFO - 2016-12-12 03:49:22 --> Language Class Initialized
ERROR - 2016-12-12 03:49:22 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:49:35 --> Config Class Initialized
INFO - 2016-12-12 03:49:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:35 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:35 --> URI Class Initialized
DEBUG - 2016-12-12 03:49:35 --> No URI present. Default controller set.
INFO - 2016-12-12 03:49:35 --> Router Class Initialized
INFO - 2016-12-12 03:49:35 --> Output Class Initialized
INFO - 2016-12-12 03:49:35 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:35 --> Input Class Initialized
INFO - 2016-12-12 03:49:35 --> Language Class Initialized
INFO - 2016-12-12 03:49:35 --> Loader Class Initialized
INFO - 2016-12-12 03:49:35 --> Database Driver Class Initialized
INFO - 2016-12-12 03:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:49:35 --> Controller Class Initialized
INFO - 2016-12-12 03:49:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:49:35 --> Final output sent to browser
DEBUG - 2016-12-12 03:49:35 --> Total execution time: 0.0129
INFO - 2016-12-12 03:49:35 --> Config Class Initialized
INFO - 2016-12-12 03:49:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:35 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:35 --> URI Class Initialized
INFO - 2016-12-12 03:49:35 --> Router Class Initialized
INFO - 2016-12-12 03:49:35 --> Output Class Initialized
INFO - 2016-12-12 03:49:35 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:35 --> Input Class Initialized
INFO - 2016-12-12 03:49:35 --> Language Class Initialized
INFO - 2016-12-12 03:49:35 --> Loader Class Initialized
INFO - 2016-12-12 03:49:35 --> Database Driver Class Initialized
INFO - 2016-12-12 03:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:49:35 --> Controller Class Initialized
INFO - 2016-12-12 03:49:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:49:35 --> Final output sent to browser
DEBUG - 2016-12-12 03:49:35 --> Total execution time: 0.0132
INFO - 2016-12-12 03:49:52 --> Config Class Initialized
INFO - 2016-12-12 03:49:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:52 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:52 --> URI Class Initialized
INFO - 2016-12-12 03:49:52 --> Router Class Initialized
INFO - 2016-12-12 03:49:52 --> Output Class Initialized
INFO - 2016-12-12 03:49:52 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:52 --> Input Class Initialized
INFO - 2016-12-12 03:49:52 --> Language Class Initialized
INFO - 2016-12-12 03:49:52 --> Loader Class Initialized
INFO - 2016-12-12 03:49:52 --> Database Driver Class Initialized
INFO - 2016-12-12 03:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:49:52 --> Controller Class Initialized
INFO - 2016-12-12 03:49:52 --> Upload Class Initialized
INFO - 2016-12-12 03:49:52 --> Helper loaded: date_helper
INFO - 2016-12-12 03:49:52 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:49:52 --> Helper loaded: form_helper
INFO - 2016-12-12 03:49:52 --> Form Validation Class Initialized
INFO - 2016-12-12 03:49:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:49:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:49:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:49:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:49:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:49:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:49:52 --> Final output sent to browser
DEBUG - 2016-12-12 03:49:52 --> Total execution time: 0.0149
INFO - 2016-12-12 03:49:52 --> Config Class Initialized
INFO - 2016-12-12 03:49:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:52 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:52 --> URI Class Initialized
INFO - 2016-12-12 03:49:52 --> Router Class Initialized
INFO - 2016-12-12 03:49:52 --> Output Class Initialized
INFO - 2016-12-12 03:49:52 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:52 --> Input Class Initialized
INFO - 2016-12-12 03:49:52 --> Language Class Initialized
ERROR - 2016-12-12 03:49:52 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:49:55 --> Config Class Initialized
INFO - 2016-12-12 03:49:55 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:49:55 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:49:55 --> Utf8 Class Initialized
INFO - 2016-12-12 03:49:55 --> URI Class Initialized
INFO - 2016-12-12 03:49:55 --> Router Class Initialized
INFO - 2016-12-12 03:49:55 --> Output Class Initialized
INFO - 2016-12-12 03:49:55 --> Security Class Initialized
DEBUG - 2016-12-12 03:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:49:55 --> Input Class Initialized
INFO - 2016-12-12 03:49:55 --> Language Class Initialized
INFO - 2016-12-12 03:49:55 --> Loader Class Initialized
INFO - 2016-12-12 03:49:55 --> Database Driver Class Initialized
INFO - 2016-12-12 03:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:49:55 --> Controller Class Initialized
INFO - 2016-12-12 03:49:55 --> Upload Class Initialized
INFO - 2016-12-12 03:49:55 --> Helper loaded: date_helper
INFO - 2016-12-12 03:49:55 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:49:55 --> Helper loaded: form_helper
INFO - 2016-12-12 03:49:55 --> Form Validation Class Initialized
INFO - 2016-12-12 03:49:55 --> Final output sent to browser
DEBUG - 2016-12-12 03:49:55 --> Total execution time: 0.0155
INFO - 2016-12-12 03:50:14 --> Config Class Initialized
INFO - 2016-12-12 03:50:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:50:14 --> Utf8 Class Initialized
INFO - 2016-12-12 03:50:14 --> URI Class Initialized
DEBUG - 2016-12-12 03:50:14 --> No URI present. Default controller set.
INFO - 2016-12-12 03:50:14 --> Router Class Initialized
INFO - 2016-12-12 03:50:14 --> Output Class Initialized
INFO - 2016-12-12 03:50:14 --> Security Class Initialized
DEBUG - 2016-12-12 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:50:14 --> Input Class Initialized
INFO - 2016-12-12 03:50:14 --> Language Class Initialized
INFO - 2016-12-12 03:50:14 --> Loader Class Initialized
INFO - 2016-12-12 03:50:14 --> Database Driver Class Initialized
INFO - 2016-12-12 03:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:50:14 --> Controller Class Initialized
INFO - 2016-12-12 03:50:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:50:14 --> Final output sent to browser
DEBUG - 2016-12-12 03:50:14 --> Total execution time: 0.0129
INFO - 2016-12-12 03:50:14 --> Config Class Initialized
INFO - 2016-12-12 03:50:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:50:14 --> Utf8 Class Initialized
INFO - 2016-12-12 03:50:14 --> URI Class Initialized
INFO - 2016-12-12 03:50:14 --> Router Class Initialized
INFO - 2016-12-12 03:50:14 --> Output Class Initialized
INFO - 2016-12-12 03:50:14 --> Security Class Initialized
DEBUG - 2016-12-12 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:50:14 --> Input Class Initialized
INFO - 2016-12-12 03:50:14 --> Language Class Initialized
INFO - 2016-12-12 03:50:14 --> Loader Class Initialized
INFO - 2016-12-12 03:50:14 --> Database Driver Class Initialized
INFO - 2016-12-12 03:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:50:14 --> Controller Class Initialized
INFO - 2016-12-12 03:50:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:50:14 --> Final output sent to browser
DEBUG - 2016-12-12 03:50:14 --> Total execution time: 0.0132
INFO - 2016-12-12 03:50:56 --> Config Class Initialized
INFO - 2016-12-12 03:50:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:50:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:50:56 --> Utf8 Class Initialized
INFO - 2016-12-12 03:50:56 --> URI Class Initialized
DEBUG - 2016-12-12 03:50:56 --> No URI present. Default controller set.
INFO - 2016-12-12 03:50:56 --> Router Class Initialized
INFO - 2016-12-12 03:50:56 --> Output Class Initialized
INFO - 2016-12-12 03:50:56 --> Security Class Initialized
DEBUG - 2016-12-12 03:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:50:56 --> Input Class Initialized
INFO - 2016-12-12 03:50:56 --> Language Class Initialized
INFO - 2016-12-12 03:50:56 --> Loader Class Initialized
INFO - 2016-12-12 03:50:56 --> Database Driver Class Initialized
INFO - 2016-12-12 03:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:50:56 --> Controller Class Initialized
INFO - 2016-12-12 03:50:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:50:56 --> Final output sent to browser
DEBUG - 2016-12-12 03:50:56 --> Total execution time: 0.0131
INFO - 2016-12-12 03:50:57 --> Config Class Initialized
INFO - 2016-12-12 03:50:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:50:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:50:57 --> Utf8 Class Initialized
INFO - 2016-12-12 03:50:57 --> URI Class Initialized
INFO - 2016-12-12 03:50:57 --> Router Class Initialized
INFO - 2016-12-12 03:50:57 --> Output Class Initialized
INFO - 2016-12-12 03:50:57 --> Security Class Initialized
DEBUG - 2016-12-12 03:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:50:57 --> Input Class Initialized
INFO - 2016-12-12 03:50:57 --> Language Class Initialized
INFO - 2016-12-12 03:50:57 --> Loader Class Initialized
INFO - 2016-12-12 03:50:57 --> Database Driver Class Initialized
INFO - 2016-12-12 03:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:50:57 --> Controller Class Initialized
INFO - 2016-12-12 03:50:57 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:50:57 --> Final output sent to browser
DEBUG - 2016-12-12 03:50:57 --> Total execution time: 0.0132
INFO - 2016-12-12 03:50:57 --> Config Class Initialized
INFO - 2016-12-12 03:50:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:50:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:50:57 --> Utf8 Class Initialized
INFO - 2016-12-12 03:50:57 --> URI Class Initialized
INFO - 2016-12-12 03:50:57 --> Router Class Initialized
INFO - 2016-12-12 03:50:57 --> Output Class Initialized
INFO - 2016-12-12 03:50:57 --> Security Class Initialized
DEBUG - 2016-12-12 03:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:50:57 --> Input Class Initialized
INFO - 2016-12-12 03:50:57 --> Language Class Initialized
INFO - 2016-12-12 03:50:57 --> Loader Class Initialized
INFO - 2016-12-12 03:50:57 --> Database Driver Class Initialized
INFO - 2016-12-12 03:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:50:57 --> Controller Class Initialized
INFO - 2016-12-12 03:50:57 --> Upload Class Initialized
INFO - 2016-12-12 03:50:57 --> Helper loaded: date_helper
INFO - 2016-12-12 03:50:57 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:50:57 --> Helper loaded: form_helper
INFO - 2016-12-12 03:50:57 --> Form Validation Class Initialized
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:50:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:50:57 --> Final output sent to browser
DEBUG - 2016-12-12 03:50:57 --> Total execution time: 0.0150
INFO - 2016-12-12 03:50:58 --> Config Class Initialized
INFO - 2016-12-12 03:50:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:50:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:50:58 --> Utf8 Class Initialized
INFO - 2016-12-12 03:50:58 --> URI Class Initialized
INFO - 2016-12-12 03:50:58 --> Router Class Initialized
INFO - 2016-12-12 03:50:58 --> Output Class Initialized
INFO - 2016-12-12 03:50:58 --> Security Class Initialized
DEBUG - 2016-12-12 03:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:50:58 --> Input Class Initialized
INFO - 2016-12-12 03:50:58 --> Language Class Initialized
ERROR - 2016-12-12 03:50:58 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:51:06 --> Config Class Initialized
INFO - 2016-12-12 03:51:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:06 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:06 --> URI Class Initialized
INFO - 2016-12-12 03:51:06 --> Router Class Initialized
INFO - 2016-12-12 03:51:06 --> Output Class Initialized
INFO - 2016-12-12 03:51:06 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:06 --> Input Class Initialized
INFO - 2016-12-12 03:51:06 --> Language Class Initialized
INFO - 2016-12-12 03:51:06 --> Loader Class Initialized
INFO - 2016-12-12 03:51:06 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:06 --> Controller Class Initialized
INFO - 2016-12-12 03:51:06 --> Upload Class Initialized
INFO - 2016-12-12 03:51:06 --> Helper loaded: date_helper
INFO - 2016-12-12 03:51:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:06 --> Helper loaded: form_helper
INFO - 2016-12-12 03:51:06 --> Form Validation Class Initialized
INFO - 2016-12-12 03:51:06 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:06 --> Total execution time: 0.0148
INFO - 2016-12-12 03:51:08 --> Config Class Initialized
INFO - 2016-12-12 03:51:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:08 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:08 --> URI Class Initialized
DEBUG - 2016-12-12 03:51:08 --> No URI present. Default controller set.
INFO - 2016-12-12 03:51:08 --> Router Class Initialized
INFO - 2016-12-12 03:51:08 --> Output Class Initialized
INFO - 2016-12-12 03:51:08 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:08 --> Input Class Initialized
INFO - 2016-12-12 03:51:08 --> Language Class Initialized
INFO - 2016-12-12 03:51:08 --> Loader Class Initialized
INFO - 2016-12-12 03:51:08 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:08 --> Controller Class Initialized
INFO - 2016-12-12 03:51:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:51:08 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:08 --> Total execution time: 0.0128
INFO - 2016-12-12 03:51:08 --> Config Class Initialized
INFO - 2016-12-12 03:51:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:08 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:08 --> URI Class Initialized
INFO - 2016-12-12 03:51:08 --> Router Class Initialized
INFO - 2016-12-12 03:51:08 --> Output Class Initialized
INFO - 2016-12-12 03:51:08 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:08 --> Input Class Initialized
INFO - 2016-12-12 03:51:08 --> Language Class Initialized
INFO - 2016-12-12 03:51:08 --> Loader Class Initialized
INFO - 2016-12-12 03:51:08 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:08 --> Controller Class Initialized
INFO - 2016-12-12 03:51:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:51:08 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:08 --> Total execution time: 0.0129
INFO - 2016-12-12 03:51:23 --> Config Class Initialized
INFO - 2016-12-12 03:51:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:23 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:23 --> URI Class Initialized
DEBUG - 2016-12-12 03:51:23 --> No URI present. Default controller set.
INFO - 2016-12-12 03:51:23 --> Router Class Initialized
INFO - 2016-12-12 03:51:23 --> Output Class Initialized
INFO - 2016-12-12 03:51:23 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:23 --> Input Class Initialized
INFO - 2016-12-12 03:51:23 --> Language Class Initialized
INFO - 2016-12-12 03:51:23 --> Loader Class Initialized
INFO - 2016-12-12 03:51:23 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:23 --> Controller Class Initialized
INFO - 2016-12-12 03:51:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:51:23 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:23 --> Total execution time: 0.0125
INFO - 2016-12-12 03:51:23 --> Config Class Initialized
INFO - 2016-12-12 03:51:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:23 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:23 --> URI Class Initialized
INFO - 2016-12-12 03:51:23 --> Router Class Initialized
INFO - 2016-12-12 03:51:23 --> Output Class Initialized
INFO - 2016-12-12 03:51:23 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:23 --> Input Class Initialized
INFO - 2016-12-12 03:51:23 --> Language Class Initialized
INFO - 2016-12-12 03:51:23 --> Loader Class Initialized
INFO - 2016-12-12 03:51:23 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:23 --> Controller Class Initialized
INFO - 2016-12-12 03:51:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:51:23 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:23 --> Total execution time: 0.0135
INFO - 2016-12-12 03:51:33 --> Config Class Initialized
INFO - 2016-12-12 03:51:33 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:33 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:33 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:33 --> URI Class Initialized
INFO - 2016-12-12 03:51:33 --> Router Class Initialized
INFO - 2016-12-12 03:51:33 --> Output Class Initialized
INFO - 2016-12-12 03:51:33 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:33 --> Input Class Initialized
INFO - 2016-12-12 03:51:33 --> Language Class Initialized
INFO - 2016-12-12 03:51:33 --> Loader Class Initialized
INFO - 2016-12-12 03:51:33 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:33 --> Controller Class Initialized
INFO - 2016-12-12 03:51:33 --> Upload Class Initialized
INFO - 2016-12-12 03:51:33 --> Helper loaded: date_helper
INFO - 2016-12-12 03:51:33 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:33 --> Helper loaded: form_helper
INFO - 2016-12-12 03:51:33 --> Form Validation Class Initialized
INFO - 2016-12-12 03:51:34 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:34 --> Total execution time: 0.4538
INFO - 2016-12-12 03:51:38 --> Config Class Initialized
INFO - 2016-12-12 03:51:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:38 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:38 --> URI Class Initialized
INFO - 2016-12-12 03:51:38 --> Router Class Initialized
INFO - 2016-12-12 03:51:38 --> Output Class Initialized
INFO - 2016-12-12 03:51:38 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:38 --> Input Class Initialized
INFO - 2016-12-12 03:51:38 --> Language Class Initialized
INFO - 2016-12-12 03:51:38 --> Loader Class Initialized
INFO - 2016-12-12 03:51:38 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:38 --> Controller Class Initialized
INFO - 2016-12-12 03:51:38 --> Upload Class Initialized
INFO - 2016-12-12 03:51:38 --> Helper loaded: date_helper
INFO - 2016-12-12 03:51:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:38 --> Helper loaded: form_helper
INFO - 2016-12-12 03:51:38 --> Form Validation Class Initialized
INFO - 2016-12-12 03:51:38 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:38 --> Total execution time: 0.0323
INFO - 2016-12-12 03:51:44 --> Config Class Initialized
INFO - 2016-12-12 03:51:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:44 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:44 --> URI Class Initialized
INFO - 2016-12-12 03:51:44 --> Router Class Initialized
INFO - 2016-12-12 03:51:44 --> Output Class Initialized
INFO - 2016-12-12 03:51:44 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:44 --> Input Class Initialized
INFO - 2016-12-12 03:51:44 --> Language Class Initialized
INFO - 2016-12-12 03:51:44 --> Loader Class Initialized
INFO - 2016-12-12 03:51:44 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:44 --> Controller Class Initialized
INFO - 2016-12-12 03:51:44 --> Upload Class Initialized
INFO - 2016-12-12 03:51:44 --> Helper loaded: date_helper
INFO - 2016-12-12 03:51:44 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:44 --> Helper loaded: form_helper
INFO - 2016-12-12 03:51:44 --> Form Validation Class Initialized
INFO - 2016-12-12 03:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:51:44 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:44 --> Total execution time: 0.0540
INFO - 2016-12-12 03:51:44 --> Config Class Initialized
INFO - 2016-12-12 03:51:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:44 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:44 --> URI Class Initialized
INFO - 2016-12-12 03:51:44 --> Router Class Initialized
INFO - 2016-12-12 03:51:44 --> Output Class Initialized
INFO - 2016-12-12 03:51:44 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:44 --> Input Class Initialized
INFO - 2016-12-12 03:51:44 --> Language Class Initialized
ERROR - 2016-12-12 03:51:44 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:51:48 --> Config Class Initialized
INFO - 2016-12-12 03:51:48 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:51:48 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:51:48 --> Utf8 Class Initialized
INFO - 2016-12-12 03:51:48 --> URI Class Initialized
INFO - 2016-12-12 03:51:48 --> Router Class Initialized
INFO - 2016-12-12 03:51:48 --> Output Class Initialized
INFO - 2016-12-12 03:51:48 --> Security Class Initialized
DEBUG - 2016-12-12 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:51:48 --> Input Class Initialized
INFO - 2016-12-12 03:51:48 --> Language Class Initialized
INFO - 2016-12-12 03:51:48 --> Loader Class Initialized
INFO - 2016-12-12 03:51:48 --> Database Driver Class Initialized
INFO - 2016-12-12 03:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:51:48 --> Controller Class Initialized
INFO - 2016-12-12 03:51:48 --> Upload Class Initialized
INFO - 2016-12-12 03:51:48 --> Helper loaded: date_helper
INFO - 2016-12-12 03:51:48 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:51:48 --> Helper loaded: form_helper
INFO - 2016-12-12 03:51:48 --> Form Validation Class Initialized
INFO - 2016-12-12 03:51:48 --> Final output sent to browser
DEBUG - 2016-12-12 03:51:48 --> Total execution time: 0.0154
INFO - 2016-12-12 03:52:14 --> Config Class Initialized
INFO - 2016-12-12 03:52:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:52:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:52:14 --> Utf8 Class Initialized
INFO - 2016-12-12 03:52:14 --> URI Class Initialized
INFO - 2016-12-12 03:52:14 --> Router Class Initialized
INFO - 2016-12-12 03:52:15 --> Output Class Initialized
INFO - 2016-12-12 03:52:15 --> Security Class Initialized
DEBUG - 2016-12-12 03:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:52:15 --> Input Class Initialized
INFO - 2016-12-12 03:52:15 --> Language Class Initialized
INFO - 2016-12-12 03:52:15 --> Loader Class Initialized
INFO - 2016-12-12 03:52:15 --> Database Driver Class Initialized
INFO - 2016-12-12 03:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:52:15 --> Controller Class Initialized
INFO - 2016-12-12 03:52:15 --> Upload Class Initialized
INFO - 2016-12-12 03:52:15 --> Helper loaded: date_helper
INFO - 2016-12-12 03:52:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:52:15 --> Helper loaded: form_helper
INFO - 2016-12-12 03:52:15 --> Form Validation Class Initialized
INFO - 2016-12-12 03:52:16 --> Final output sent to browser
DEBUG - 2016-12-12 03:52:16 --> Total execution time: 1.2083
INFO - 2016-12-12 03:52:16 --> Config Class Initialized
INFO - 2016-12-12 03:52:16 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:52:16 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:52:16 --> Utf8 Class Initialized
INFO - 2016-12-12 03:52:16 --> URI Class Initialized
DEBUG - 2016-12-12 03:52:16 --> No URI present. Default controller set.
INFO - 2016-12-12 03:52:16 --> Router Class Initialized
INFO - 2016-12-12 03:52:16 --> Output Class Initialized
INFO - 2016-12-12 03:52:16 --> Security Class Initialized
DEBUG - 2016-12-12 03:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:52:16 --> Input Class Initialized
INFO - 2016-12-12 03:52:16 --> Language Class Initialized
INFO - 2016-12-12 03:52:16 --> Loader Class Initialized
INFO - 2016-12-12 03:52:16 --> Database Driver Class Initialized
INFO - 2016-12-12 03:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:52:16 --> Controller Class Initialized
INFO - 2016-12-12 03:52:16 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:52:16 --> Final output sent to browser
DEBUG - 2016-12-12 03:52:16 --> Total execution time: 0.4936
INFO - 2016-12-12 03:52:17 --> Config Class Initialized
INFO - 2016-12-12 03:52:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:52:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:52:17 --> Utf8 Class Initialized
INFO - 2016-12-12 03:52:17 --> URI Class Initialized
INFO - 2016-12-12 03:52:17 --> Router Class Initialized
INFO - 2016-12-12 03:52:17 --> Output Class Initialized
INFO - 2016-12-12 03:52:17 --> Security Class Initialized
DEBUG - 2016-12-12 03:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:52:17 --> Input Class Initialized
INFO - 2016-12-12 03:52:17 --> Language Class Initialized
INFO - 2016-12-12 03:52:17 --> Loader Class Initialized
INFO - 2016-12-12 03:52:17 --> Database Driver Class Initialized
INFO - 2016-12-12 03:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:52:17 --> Controller Class Initialized
INFO - 2016-12-12 03:52:17 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:52:17 --> Final output sent to browser
DEBUG - 2016-12-12 03:52:17 --> Total execution time: 0.0138
INFO - 2016-12-12 03:53:00 --> Config Class Initialized
INFO - 2016-12-12 03:53:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:53:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:53:00 --> Utf8 Class Initialized
INFO - 2016-12-12 03:53:00 --> URI Class Initialized
DEBUG - 2016-12-12 03:53:00 --> No URI present. Default controller set.
INFO - 2016-12-12 03:53:00 --> Router Class Initialized
INFO - 2016-12-12 03:53:00 --> Output Class Initialized
INFO - 2016-12-12 03:53:00 --> Security Class Initialized
DEBUG - 2016-12-12 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:53:00 --> Input Class Initialized
INFO - 2016-12-12 03:53:00 --> Language Class Initialized
INFO - 2016-12-12 03:53:00 --> Loader Class Initialized
INFO - 2016-12-12 03:53:00 --> Database Driver Class Initialized
INFO - 2016-12-12 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:53:00 --> Controller Class Initialized
INFO - 2016-12-12 03:53:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:53:00 --> Final output sent to browser
DEBUG - 2016-12-12 03:53:00 --> Total execution time: 0.0134
INFO - 2016-12-12 03:53:00 --> Config Class Initialized
INFO - 2016-12-12 03:53:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:53:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:53:00 --> Utf8 Class Initialized
INFO - 2016-12-12 03:53:00 --> URI Class Initialized
INFO - 2016-12-12 03:53:00 --> Router Class Initialized
INFO - 2016-12-12 03:53:00 --> Output Class Initialized
INFO - 2016-12-12 03:53:00 --> Security Class Initialized
DEBUG - 2016-12-12 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:53:00 --> Input Class Initialized
INFO - 2016-12-12 03:53:00 --> Language Class Initialized
INFO - 2016-12-12 03:53:00 --> Loader Class Initialized
INFO - 2016-12-12 03:53:00 --> Database Driver Class Initialized
INFO - 2016-12-12 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:53:00 --> Controller Class Initialized
INFO - 2016-12-12 03:53:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:53:00 --> Final output sent to browser
DEBUG - 2016-12-12 03:53:00 --> Total execution time: 0.0133
INFO - 2016-12-12 03:53:25 --> Config Class Initialized
INFO - 2016-12-12 03:53:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:53:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:53:25 --> Utf8 Class Initialized
INFO - 2016-12-12 03:53:25 --> URI Class Initialized
DEBUG - 2016-12-12 03:53:25 --> No URI present. Default controller set.
INFO - 2016-12-12 03:53:25 --> Router Class Initialized
INFO - 2016-12-12 03:53:25 --> Output Class Initialized
INFO - 2016-12-12 03:53:25 --> Security Class Initialized
DEBUG - 2016-12-12 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:53:25 --> Input Class Initialized
INFO - 2016-12-12 03:53:25 --> Language Class Initialized
INFO - 2016-12-12 03:53:25 --> Loader Class Initialized
INFO - 2016-12-12 03:53:25 --> Database Driver Class Initialized
INFO - 2016-12-12 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:53:25 --> Controller Class Initialized
INFO - 2016-12-12 03:53:25 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:53:25 --> Final output sent to browser
DEBUG - 2016-12-12 03:53:25 --> Total execution time: 0.0211
INFO - 2016-12-12 03:53:25 --> Config Class Initialized
INFO - 2016-12-12 03:53:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:53:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:53:25 --> Utf8 Class Initialized
INFO - 2016-12-12 03:53:25 --> URI Class Initialized
INFO - 2016-12-12 03:53:25 --> Router Class Initialized
INFO - 2016-12-12 03:53:25 --> Output Class Initialized
INFO - 2016-12-12 03:53:25 --> Security Class Initialized
DEBUG - 2016-12-12 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:53:25 --> Input Class Initialized
INFO - 2016-12-12 03:53:25 --> Language Class Initialized
INFO - 2016-12-12 03:53:25 --> Loader Class Initialized
INFO - 2016-12-12 03:53:25 --> Database Driver Class Initialized
INFO - 2016-12-12 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:53:25 --> Controller Class Initialized
INFO - 2016-12-12 03:53:25 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:53:25 --> Final output sent to browser
DEBUG - 2016-12-12 03:53:25 --> Total execution time: 0.0144
INFO - 2016-12-12 03:53:39 --> Config Class Initialized
INFO - 2016-12-12 03:53:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:53:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:53:39 --> Utf8 Class Initialized
INFO - 2016-12-12 03:53:39 --> URI Class Initialized
DEBUG - 2016-12-12 03:53:39 --> No URI present. Default controller set.
INFO - 2016-12-12 03:53:39 --> Router Class Initialized
INFO - 2016-12-12 03:53:39 --> Output Class Initialized
INFO - 2016-12-12 03:53:39 --> Security Class Initialized
DEBUG - 2016-12-12 03:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:53:39 --> Input Class Initialized
INFO - 2016-12-12 03:53:39 --> Language Class Initialized
INFO - 2016-12-12 03:53:39 --> Loader Class Initialized
INFO - 2016-12-12 03:53:39 --> Database Driver Class Initialized
INFO - 2016-12-12 03:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:53:39 --> Controller Class Initialized
INFO - 2016-12-12 03:53:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:53:39 --> Final output sent to browser
DEBUG - 2016-12-12 03:53:39 --> Total execution time: 0.0125
INFO - 2016-12-12 03:53:40 --> Config Class Initialized
INFO - 2016-12-12 03:53:40 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:53:40 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:53:40 --> Utf8 Class Initialized
INFO - 2016-12-12 03:53:40 --> URI Class Initialized
INFO - 2016-12-12 03:53:40 --> Router Class Initialized
INFO - 2016-12-12 03:53:40 --> Output Class Initialized
INFO - 2016-12-12 03:53:40 --> Security Class Initialized
DEBUG - 2016-12-12 03:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:53:40 --> Input Class Initialized
INFO - 2016-12-12 03:53:40 --> Language Class Initialized
INFO - 2016-12-12 03:53:40 --> Loader Class Initialized
INFO - 2016-12-12 03:53:40 --> Database Driver Class Initialized
INFO - 2016-12-12 03:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:53:40 --> Controller Class Initialized
INFO - 2016-12-12 03:53:40 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:53:40 --> Final output sent to browser
DEBUG - 2016-12-12 03:53:40 --> Total execution time: 0.0129
INFO - 2016-12-12 03:54:38 --> Config Class Initialized
INFO - 2016-12-12 03:54:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:54:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:54:38 --> Utf8 Class Initialized
INFO - 2016-12-12 03:54:38 --> URI Class Initialized
DEBUG - 2016-12-12 03:54:38 --> No URI present. Default controller set.
INFO - 2016-12-12 03:54:38 --> Router Class Initialized
INFO - 2016-12-12 03:54:38 --> Output Class Initialized
INFO - 2016-12-12 03:54:38 --> Security Class Initialized
DEBUG - 2016-12-12 03:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:54:38 --> Input Class Initialized
INFO - 2016-12-12 03:54:38 --> Language Class Initialized
INFO - 2016-12-12 03:54:38 --> Loader Class Initialized
INFO - 2016-12-12 03:54:38 --> Database Driver Class Initialized
INFO - 2016-12-12 03:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:54:38 --> Controller Class Initialized
INFO - 2016-12-12 03:54:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:54:38 --> Final output sent to browser
DEBUG - 2016-12-12 03:54:38 --> Total execution time: 0.0140
INFO - 2016-12-12 03:54:38 --> Config Class Initialized
INFO - 2016-12-12 03:54:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:54:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:54:38 --> Utf8 Class Initialized
INFO - 2016-12-12 03:54:38 --> URI Class Initialized
INFO - 2016-12-12 03:54:38 --> Router Class Initialized
INFO - 2016-12-12 03:54:38 --> Output Class Initialized
INFO - 2016-12-12 03:54:38 --> Security Class Initialized
DEBUG - 2016-12-12 03:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:54:38 --> Input Class Initialized
INFO - 2016-12-12 03:54:38 --> Language Class Initialized
INFO - 2016-12-12 03:54:38 --> Loader Class Initialized
INFO - 2016-12-12 03:54:38 --> Database Driver Class Initialized
INFO - 2016-12-12 03:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:54:38 --> Controller Class Initialized
INFO - 2016-12-12 03:54:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:54:38 --> Final output sent to browser
DEBUG - 2016-12-12 03:54:38 --> Total execution time: 0.0132
INFO - 2016-12-12 03:55:44 --> Config Class Initialized
INFO - 2016-12-12 03:55:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:55:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:55:44 --> Utf8 Class Initialized
INFO - 2016-12-12 03:55:44 --> URI Class Initialized
INFO - 2016-12-12 03:55:44 --> Router Class Initialized
INFO - 2016-12-12 03:55:44 --> Output Class Initialized
INFO - 2016-12-12 03:55:44 --> Security Class Initialized
DEBUG - 2016-12-12 03:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:55:44 --> Input Class Initialized
INFO - 2016-12-12 03:55:44 --> Language Class Initialized
ERROR - 2016-12-12 03:55:44 --> Severity: Parsing Error --> syntax error, unexpected 'cupones' (T_STRING), expecting '(' /home/graduafe/public_html/application/controllers/Admin_cupones_controller.php 41
INFO - 2016-12-12 03:56:02 --> Config Class Initialized
INFO - 2016-12-12 03:56:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:56:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:56:02 --> Utf8 Class Initialized
INFO - 2016-12-12 03:56:02 --> URI Class Initialized
INFO - 2016-12-12 03:56:02 --> Router Class Initialized
INFO - 2016-12-12 03:56:02 --> Output Class Initialized
INFO - 2016-12-12 03:56:02 --> Security Class Initialized
DEBUG - 2016-12-12 03:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:56:02 --> Input Class Initialized
INFO - 2016-12-12 03:56:02 --> Language Class Initialized
ERROR - 2016-12-12 03:56:02 --> Severity: Parsing Error --> syntax error, unexpected 'cupones' (T_STRING), expecting '(' /home/graduafe/public_html/application/controllers/Admin_cupones_controller.php 41
INFO - 2016-12-12 03:56:03 --> Config Class Initialized
INFO - 2016-12-12 03:56:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:56:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:56:03 --> Utf8 Class Initialized
INFO - 2016-12-12 03:56:03 --> URI Class Initialized
INFO - 2016-12-12 03:56:03 --> Router Class Initialized
INFO - 2016-12-12 03:56:03 --> Output Class Initialized
INFO - 2016-12-12 03:56:03 --> Security Class Initialized
DEBUG - 2016-12-12 03:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:56:03 --> Input Class Initialized
INFO - 2016-12-12 03:56:03 --> Language Class Initialized
ERROR - 2016-12-12 03:56:03 --> Severity: Parsing Error --> syntax error, unexpected 'cupones' (T_STRING), expecting '(' /home/graduafe/public_html/application/controllers/Admin_cupones_controller.php 41
INFO - 2016-12-12 03:56:56 --> Config Class Initialized
INFO - 2016-12-12 03:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:56:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:56:56 --> Utf8 Class Initialized
INFO - 2016-12-12 03:56:56 --> URI Class Initialized
INFO - 2016-12-12 03:56:56 --> Router Class Initialized
INFO - 2016-12-12 03:56:56 --> Output Class Initialized
INFO - 2016-12-12 03:56:56 --> Security Class Initialized
DEBUG - 2016-12-12 03:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:56:56 --> Input Class Initialized
INFO - 2016-12-12 03:56:56 --> Language Class Initialized
INFO - 2016-12-12 03:56:56 --> Loader Class Initialized
INFO - 2016-12-12 03:56:56 --> Database Driver Class Initialized
INFO - 2016-12-12 03:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:56:56 --> Controller Class Initialized
INFO - 2016-12-12 03:56:56 --> Upload Class Initialized
INFO - 2016-12-12 03:56:56 --> Helper loaded: date_helper
INFO - 2016-12-12 03:56:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:56:56 --> Helper loaded: form_helper
INFO - 2016-12-12 03:56:56 --> Form Validation Class Initialized
INFO - 2016-12-12 03:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:56:56 --> Final output sent to browser
DEBUG - 2016-12-12 03:56:56 --> Total execution time: 0.0637
INFO - 2016-12-12 03:56:56 --> Config Class Initialized
INFO - 2016-12-12 03:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:56:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:56:56 --> Utf8 Class Initialized
INFO - 2016-12-12 03:56:56 --> URI Class Initialized
INFO - 2016-12-12 03:56:56 --> Router Class Initialized
INFO - 2016-12-12 03:56:56 --> Output Class Initialized
INFO - 2016-12-12 03:56:56 --> Security Class Initialized
DEBUG - 2016-12-12 03:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:56:56 --> Input Class Initialized
INFO - 2016-12-12 03:56:56 --> Language Class Initialized
ERROR - 2016-12-12 03:56:56 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:57:01 --> Config Class Initialized
INFO - 2016-12-12 03:57:01 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:57:01 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:57:01 --> Utf8 Class Initialized
INFO - 2016-12-12 03:57:01 --> URI Class Initialized
INFO - 2016-12-12 03:57:01 --> Router Class Initialized
INFO - 2016-12-12 03:57:01 --> Output Class Initialized
INFO - 2016-12-12 03:57:01 --> Security Class Initialized
DEBUG - 2016-12-12 03:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:57:01 --> Input Class Initialized
INFO - 2016-12-12 03:57:01 --> Language Class Initialized
INFO - 2016-12-12 03:57:01 --> Loader Class Initialized
INFO - 2016-12-12 03:57:01 --> Database Driver Class Initialized
INFO - 2016-12-12 03:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:57:01 --> Controller Class Initialized
INFO - 2016-12-12 03:57:01 --> Upload Class Initialized
INFO - 2016-12-12 03:57:01 --> Helper loaded: date_helper
INFO - 2016-12-12 03:57:01 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:57:01 --> Helper loaded: form_helper
INFO - 2016-12-12 03:57:01 --> Form Validation Class Initialized
INFO - 2016-12-12 03:57:01 --> Final output sent to browser
DEBUG - 2016-12-12 03:57:01 --> Total execution time: 0.0157
INFO - 2016-12-12 03:57:26 --> Config Class Initialized
INFO - 2016-12-12 03:57:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:57:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:57:26 --> Utf8 Class Initialized
INFO - 2016-12-12 03:57:26 --> URI Class Initialized
INFO - 2016-12-12 03:57:26 --> Router Class Initialized
INFO - 2016-12-12 03:57:26 --> Output Class Initialized
INFO - 2016-12-12 03:57:26 --> Security Class Initialized
DEBUG - 2016-12-12 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:57:26 --> Input Class Initialized
INFO - 2016-12-12 03:57:26 --> Language Class Initialized
INFO - 2016-12-12 03:57:26 --> Loader Class Initialized
INFO - 2016-12-12 03:57:26 --> Database Driver Class Initialized
INFO - 2016-12-12 03:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:57:26 --> Controller Class Initialized
INFO - 2016-12-12 03:57:26 --> Upload Class Initialized
INFO - 2016-12-12 03:57:26 --> Helper loaded: date_helper
INFO - 2016-12-12 03:57:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:57:26 --> Helper loaded: form_helper
INFO - 2016-12-12 03:57:26 --> Form Validation Class Initialized
INFO - 2016-12-12 03:57:26 --> Final output sent to browser
DEBUG - 2016-12-12 03:57:26 --> Total execution time: 0.7735
INFO - 2016-12-12 03:57:29 --> Config Class Initialized
INFO - 2016-12-12 03:57:29 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:57:29 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:57:29 --> Utf8 Class Initialized
INFO - 2016-12-12 03:57:29 --> URI Class Initialized
INFO - 2016-12-12 03:57:29 --> Router Class Initialized
INFO - 2016-12-12 03:57:29 --> Output Class Initialized
INFO - 2016-12-12 03:57:29 --> Security Class Initialized
DEBUG - 2016-12-12 03:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:57:29 --> Input Class Initialized
INFO - 2016-12-12 03:57:29 --> Language Class Initialized
ERROR - 2016-12-12 03:57:29 --> 404 Page Not Found: Admin/cupones
INFO - 2016-12-12 03:57:50 --> Config Class Initialized
INFO - 2016-12-12 03:57:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:57:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:57:50 --> Utf8 Class Initialized
INFO - 2016-12-12 03:57:50 --> URI Class Initialized
INFO - 2016-12-12 03:57:50 --> Router Class Initialized
INFO - 2016-12-12 03:57:50 --> Output Class Initialized
INFO - 2016-12-12 03:57:50 --> Security Class Initialized
DEBUG - 2016-12-12 03:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:57:50 --> Input Class Initialized
INFO - 2016-12-12 03:57:50 --> Language Class Initialized
INFO - 2016-12-12 03:57:50 --> Loader Class Initialized
INFO - 2016-12-12 03:57:50 --> Database Driver Class Initialized
INFO - 2016-12-12 03:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:57:50 --> Controller Class Initialized
INFO - 2016-12-12 03:57:50 --> Upload Class Initialized
INFO - 2016-12-12 03:57:50 --> Helper loaded: date_helper
INFO - 2016-12-12 03:57:50 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:57:50 --> Helper loaded: form_helper
INFO - 2016-12-12 03:57:50 --> Form Validation Class Initialized
INFO - 2016-12-12 03:57:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:57:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:57:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:57:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:57:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:57:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:57:50 --> Final output sent to browser
DEBUG - 2016-12-12 03:57:50 --> Total execution time: 0.0161
INFO - 2016-12-12 03:57:50 --> Config Class Initialized
INFO - 2016-12-12 03:57:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:57:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:57:50 --> Utf8 Class Initialized
INFO - 2016-12-12 03:57:50 --> URI Class Initialized
INFO - 2016-12-12 03:57:50 --> Router Class Initialized
INFO - 2016-12-12 03:57:50 --> Output Class Initialized
INFO - 2016-12-12 03:57:50 --> Security Class Initialized
DEBUG - 2016-12-12 03:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:57:50 --> Input Class Initialized
INFO - 2016-12-12 03:57:50 --> Language Class Initialized
ERROR - 2016-12-12 03:57:50 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:58:08 --> Config Class Initialized
INFO - 2016-12-12 03:58:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:58:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:58:08 --> Utf8 Class Initialized
INFO - 2016-12-12 03:58:08 --> URI Class Initialized
INFO - 2016-12-12 03:58:08 --> Router Class Initialized
INFO - 2016-12-12 03:58:08 --> Output Class Initialized
INFO - 2016-12-12 03:58:08 --> Security Class Initialized
DEBUG - 2016-12-12 03:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:58:08 --> Input Class Initialized
INFO - 2016-12-12 03:58:08 --> Language Class Initialized
INFO - 2016-12-12 03:58:08 --> Loader Class Initialized
INFO - 2016-12-12 03:58:08 --> Database Driver Class Initialized
INFO - 2016-12-12 03:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:58:08 --> Controller Class Initialized
INFO - 2016-12-12 03:58:08 --> Upload Class Initialized
INFO - 2016-12-12 03:58:08 --> Helper loaded: date_helper
INFO - 2016-12-12 03:58:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:58:08 --> Helper loaded: form_helper
INFO - 2016-12-12 03:58:08 --> Form Validation Class Initialized
INFO - 2016-12-12 03:58:08 --> Final output sent to browser
DEBUG - 2016-12-12 03:58:08 --> Total execution time: 0.0162
INFO - 2016-12-12 03:58:23 --> Config Class Initialized
INFO - 2016-12-12 03:58:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:58:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:58:23 --> Utf8 Class Initialized
INFO - 2016-12-12 03:58:23 --> URI Class Initialized
DEBUG - 2016-12-12 03:58:23 --> No URI present. Default controller set.
INFO - 2016-12-12 03:58:23 --> Router Class Initialized
INFO - 2016-12-12 03:58:23 --> Output Class Initialized
INFO - 2016-12-12 03:58:23 --> Security Class Initialized
DEBUG - 2016-12-12 03:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:58:23 --> Input Class Initialized
INFO - 2016-12-12 03:58:23 --> Language Class Initialized
INFO - 2016-12-12 03:58:23 --> Loader Class Initialized
INFO - 2016-12-12 03:58:23 --> Database Driver Class Initialized
INFO - 2016-12-12 03:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:58:23 --> Controller Class Initialized
INFO - 2016-12-12 03:58:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:58:23 --> Final output sent to browser
DEBUG - 2016-12-12 03:58:23 --> Total execution time: 0.0129
INFO - 2016-12-12 03:58:23 --> Config Class Initialized
INFO - 2016-12-12 03:58:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:58:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:58:23 --> Utf8 Class Initialized
INFO - 2016-12-12 03:58:23 --> URI Class Initialized
INFO - 2016-12-12 03:58:23 --> Router Class Initialized
INFO - 2016-12-12 03:58:23 --> Output Class Initialized
INFO - 2016-12-12 03:58:23 --> Security Class Initialized
DEBUG - 2016-12-12 03:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:58:23 --> Input Class Initialized
INFO - 2016-12-12 03:58:23 --> Language Class Initialized
INFO - 2016-12-12 03:58:23 --> Loader Class Initialized
INFO - 2016-12-12 03:58:23 --> Database Driver Class Initialized
INFO - 2016-12-12 03:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:58:23 --> Controller Class Initialized
INFO - 2016-12-12 03:58:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 03:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 03:58:23 --> Final output sent to browser
DEBUG - 2016-12-12 03:58:23 --> Total execution time: 0.0661
INFO - 2016-12-12 03:58:26 --> Config Class Initialized
INFO - 2016-12-12 03:58:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:58:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:58:26 --> Utf8 Class Initialized
INFO - 2016-12-12 03:58:26 --> URI Class Initialized
INFO - 2016-12-12 03:58:26 --> Router Class Initialized
INFO - 2016-12-12 03:58:26 --> Output Class Initialized
INFO - 2016-12-12 03:58:26 --> Security Class Initialized
DEBUG - 2016-12-12 03:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:58:26 --> Input Class Initialized
INFO - 2016-12-12 03:58:26 --> Language Class Initialized
INFO - 2016-12-12 03:58:26 --> Loader Class Initialized
INFO - 2016-12-12 03:58:26 --> Database Driver Class Initialized
INFO - 2016-12-12 03:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:58:26 --> Controller Class Initialized
INFO - 2016-12-12 03:58:26 --> Upload Class Initialized
INFO - 2016-12-12 03:58:26 --> Helper loaded: date_helper
INFO - 2016-12-12 03:58:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:58:26 --> Helper loaded: form_helper
INFO - 2016-12-12 03:58:26 --> Form Validation Class Initialized
INFO - 2016-12-12 03:58:26 --> Final output sent to browser
DEBUG - 2016-12-12 03:58:26 --> Total execution time: 0.0154
INFO - 2016-12-12 03:59:21 --> Config Class Initialized
INFO - 2016-12-12 03:59:21 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:59:21 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:59:21 --> Utf8 Class Initialized
INFO - 2016-12-12 03:59:21 --> URI Class Initialized
INFO - 2016-12-12 03:59:21 --> Router Class Initialized
INFO - 2016-12-12 03:59:21 --> Output Class Initialized
INFO - 2016-12-12 03:59:21 --> Security Class Initialized
DEBUG - 2016-12-12 03:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:59:21 --> Input Class Initialized
INFO - 2016-12-12 03:59:21 --> Language Class Initialized
ERROR - 2016-12-12 03:59:21 --> 404 Page Not Found: Admin/cupones
INFO - 2016-12-12 03:59:42 --> Config Class Initialized
INFO - 2016-12-12 03:59:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:59:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:59:42 --> Utf8 Class Initialized
INFO - 2016-12-12 03:59:42 --> URI Class Initialized
INFO - 2016-12-12 03:59:42 --> Router Class Initialized
INFO - 2016-12-12 03:59:42 --> Output Class Initialized
INFO - 2016-12-12 03:59:42 --> Security Class Initialized
DEBUG - 2016-12-12 03:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:59:42 --> Input Class Initialized
INFO - 2016-12-12 03:59:42 --> Language Class Initialized
INFO - 2016-12-12 03:59:42 --> Loader Class Initialized
INFO - 2016-12-12 03:59:42 --> Database Driver Class Initialized
INFO - 2016-12-12 03:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:59:42 --> Controller Class Initialized
INFO - 2016-12-12 03:59:42 --> Upload Class Initialized
INFO - 2016-12-12 03:59:42 --> Helper loaded: date_helper
INFO - 2016-12-12 03:59:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:59:42 --> Helper loaded: form_helper
INFO - 2016-12-12 03:59:42 --> Form Validation Class Initialized
INFO - 2016-12-12 03:59:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 03:59:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 03:59:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 03:59:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 03:59:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 03:59:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 03:59:42 --> Final output sent to browser
DEBUG - 2016-12-12 03:59:42 --> Total execution time: 0.0157
INFO - 2016-12-12 03:59:42 --> Config Class Initialized
INFO - 2016-12-12 03:59:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:59:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:59:42 --> Utf8 Class Initialized
INFO - 2016-12-12 03:59:42 --> URI Class Initialized
INFO - 2016-12-12 03:59:42 --> Router Class Initialized
INFO - 2016-12-12 03:59:42 --> Output Class Initialized
INFO - 2016-12-12 03:59:42 --> Security Class Initialized
DEBUG - 2016-12-12 03:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:59:42 --> Input Class Initialized
INFO - 2016-12-12 03:59:42 --> Language Class Initialized
ERROR - 2016-12-12 03:59:42 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 03:59:45 --> Config Class Initialized
INFO - 2016-12-12 03:59:45 --> Hooks Class Initialized
DEBUG - 2016-12-12 03:59:45 --> UTF-8 Support Enabled
INFO - 2016-12-12 03:59:45 --> Utf8 Class Initialized
INFO - 2016-12-12 03:59:45 --> URI Class Initialized
INFO - 2016-12-12 03:59:45 --> Router Class Initialized
INFO - 2016-12-12 03:59:45 --> Output Class Initialized
INFO - 2016-12-12 03:59:45 --> Security Class Initialized
DEBUG - 2016-12-12 03:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 03:59:45 --> Input Class Initialized
INFO - 2016-12-12 03:59:45 --> Language Class Initialized
INFO - 2016-12-12 03:59:45 --> Loader Class Initialized
INFO - 2016-12-12 03:59:45 --> Database Driver Class Initialized
INFO - 2016-12-12 03:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 03:59:45 --> Controller Class Initialized
INFO - 2016-12-12 03:59:45 --> Upload Class Initialized
INFO - 2016-12-12 03:59:45 --> Helper loaded: date_helper
INFO - 2016-12-12 03:59:45 --> Helper loaded: url_helper
DEBUG - 2016-12-12 03:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 03:59:45 --> Helper loaded: form_helper
INFO - 2016-12-12 03:59:45 --> Form Validation Class Initialized
INFO - 2016-12-12 03:59:45 --> Final output sent to browser
DEBUG - 2016-12-12 03:59:45 --> Total execution time: 0.0149
INFO - 2016-12-12 04:00:08 --> Config Class Initialized
INFO - 2016-12-12 04:00:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:00:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:00:08 --> Utf8 Class Initialized
INFO - 2016-12-12 04:00:08 --> URI Class Initialized
INFO - 2016-12-12 04:00:08 --> Router Class Initialized
INFO - 2016-12-12 04:00:08 --> Output Class Initialized
INFO - 2016-12-12 04:00:08 --> Security Class Initialized
DEBUG - 2016-12-12 04:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:00:08 --> Input Class Initialized
INFO - 2016-12-12 04:00:08 --> Language Class Initialized
INFO - 2016-12-12 04:00:08 --> Loader Class Initialized
INFO - 2016-12-12 04:00:08 --> Database Driver Class Initialized
INFO - 2016-12-12 04:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:00:08 --> Controller Class Initialized
INFO - 2016-12-12 04:00:08 --> Upload Class Initialized
INFO - 2016-12-12 04:00:08 --> Helper loaded: date_helper
INFO - 2016-12-12 04:00:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:00:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:00:08 --> Helper loaded: form_helper
INFO - 2016-12-12 04:00:08 --> Form Validation Class Initialized
INFO - 2016-12-12 04:00:08 --> Final output sent to browser
DEBUG - 2016-12-12 04:00:08 --> Total execution time: 0.0168
INFO - 2016-12-12 04:00:39 --> Config Class Initialized
INFO - 2016-12-12 04:00:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:00:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:00:39 --> Utf8 Class Initialized
INFO - 2016-12-12 04:00:39 --> URI Class Initialized
INFO - 2016-12-12 04:00:39 --> Router Class Initialized
INFO - 2016-12-12 04:00:39 --> Output Class Initialized
INFO - 2016-12-12 04:00:39 --> Security Class Initialized
DEBUG - 2016-12-12 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:00:39 --> Input Class Initialized
INFO - 2016-12-12 04:00:39 --> Language Class Initialized
INFO - 2016-12-12 04:00:39 --> Loader Class Initialized
INFO - 2016-12-12 04:00:39 --> Database Driver Class Initialized
INFO - 2016-12-12 04:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:00:39 --> Controller Class Initialized
INFO - 2016-12-12 04:00:39 --> Upload Class Initialized
INFO - 2016-12-12 04:00:39 --> Helper loaded: date_helper
INFO - 2016-12-12 04:00:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:00:39 --> Helper loaded: form_helper
INFO - 2016-12-12 04:00:39 --> Form Validation Class Initialized
INFO - 2016-12-12 04:00:39 --> Final output sent to browser
DEBUG - 2016-12-12 04:00:39 --> Total execution time: 0.0154
INFO - 2016-12-12 04:00:44 --> Config Class Initialized
INFO - 2016-12-12 04:00:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:00:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:00:44 --> Utf8 Class Initialized
INFO - 2016-12-12 04:00:44 --> URI Class Initialized
INFO - 2016-12-12 04:00:44 --> Router Class Initialized
INFO - 2016-12-12 04:00:44 --> Output Class Initialized
INFO - 2016-12-12 04:00:44 --> Security Class Initialized
DEBUG - 2016-12-12 04:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:00:44 --> Input Class Initialized
INFO - 2016-12-12 04:00:44 --> Language Class Initialized
INFO - 2016-12-12 04:00:44 --> Loader Class Initialized
INFO - 2016-12-12 04:00:44 --> Database Driver Class Initialized
INFO - 2016-12-12 04:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:00:44 --> Controller Class Initialized
INFO - 2016-12-12 04:00:44 --> Upload Class Initialized
INFO - 2016-12-12 04:00:44 --> Helper loaded: date_helper
INFO - 2016-12-12 04:00:44 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:00:44 --> Helper loaded: form_helper
INFO - 2016-12-12 04:00:44 --> Form Validation Class Initialized
INFO - 2016-12-12 04:00:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:00:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:00:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 04:00:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 04:00:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 04:00:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:00:44 --> Final output sent to browser
DEBUG - 2016-12-12 04:00:44 --> Total execution time: 0.0161
INFO - 2016-12-12 04:00:44 --> Config Class Initialized
INFO - 2016-12-12 04:00:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:00:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:00:44 --> Utf8 Class Initialized
INFO - 2016-12-12 04:00:44 --> URI Class Initialized
INFO - 2016-12-12 04:00:44 --> Router Class Initialized
INFO - 2016-12-12 04:00:44 --> Output Class Initialized
INFO - 2016-12-12 04:00:44 --> Security Class Initialized
DEBUG - 2016-12-12 04:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:00:44 --> Input Class Initialized
INFO - 2016-12-12 04:00:44 --> Language Class Initialized
ERROR - 2016-12-12 04:00:44 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 04:00:46 --> Config Class Initialized
INFO - 2016-12-12 04:00:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:00:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:00:46 --> Utf8 Class Initialized
INFO - 2016-12-12 04:00:46 --> URI Class Initialized
INFO - 2016-12-12 04:00:46 --> Router Class Initialized
INFO - 2016-12-12 04:00:46 --> Output Class Initialized
INFO - 2016-12-12 04:00:46 --> Security Class Initialized
DEBUG - 2016-12-12 04:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:00:46 --> Input Class Initialized
INFO - 2016-12-12 04:00:46 --> Language Class Initialized
INFO - 2016-12-12 04:00:46 --> Loader Class Initialized
INFO - 2016-12-12 04:00:46 --> Database Driver Class Initialized
INFO - 2016-12-12 04:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:00:46 --> Controller Class Initialized
INFO - 2016-12-12 04:00:46 --> Upload Class Initialized
INFO - 2016-12-12 04:00:46 --> Helper loaded: date_helper
INFO - 2016-12-12 04:00:46 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:00:46 --> Helper loaded: form_helper
INFO - 2016-12-12 04:00:46 --> Form Validation Class Initialized
INFO - 2016-12-12 04:00:46 --> Final output sent to browser
DEBUG - 2016-12-12 04:00:46 --> Total execution time: 0.0150
INFO - 2016-12-12 04:01:14 --> Config Class Initialized
INFO - 2016-12-12 04:01:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:14 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:14 --> URI Class Initialized
INFO - 2016-12-12 04:01:14 --> Router Class Initialized
INFO - 2016-12-12 04:01:14 --> Output Class Initialized
INFO - 2016-12-12 04:01:14 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:14 --> Input Class Initialized
INFO - 2016-12-12 04:01:14 --> Language Class Initialized
INFO - 2016-12-12 04:01:14 --> Loader Class Initialized
INFO - 2016-12-12 04:01:14 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:14 --> Controller Class Initialized
INFO - 2016-12-12 04:01:14 --> Upload Class Initialized
INFO - 2016-12-12 04:01:14 --> Helper loaded: date_helper
INFO - 2016-12-12 04:01:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:14 --> Helper loaded: form_helper
INFO - 2016-12-12 04:01:14 --> Form Validation Class Initialized
INFO - 2016-12-12 04:01:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:01:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:01:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 04:01:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 04:01:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 04:01:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:01:14 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:14 --> Total execution time: 0.0151
INFO - 2016-12-12 04:01:14 --> Config Class Initialized
INFO - 2016-12-12 04:01:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:14 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:14 --> URI Class Initialized
INFO - 2016-12-12 04:01:14 --> Router Class Initialized
INFO - 2016-12-12 04:01:14 --> Output Class Initialized
INFO - 2016-12-12 04:01:14 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:14 --> Input Class Initialized
INFO - 2016-12-12 04:01:14 --> Language Class Initialized
ERROR - 2016-12-12 04:01:14 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 04:01:17 --> Config Class Initialized
INFO - 2016-12-12 04:01:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:17 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:17 --> URI Class Initialized
INFO - 2016-12-12 04:01:17 --> Router Class Initialized
INFO - 2016-12-12 04:01:17 --> Output Class Initialized
INFO - 2016-12-12 04:01:17 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:17 --> Input Class Initialized
INFO - 2016-12-12 04:01:17 --> Language Class Initialized
INFO - 2016-12-12 04:01:17 --> Loader Class Initialized
INFO - 2016-12-12 04:01:17 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:17 --> Controller Class Initialized
INFO - 2016-12-12 04:01:17 --> Upload Class Initialized
INFO - 2016-12-12 04:01:17 --> Helper loaded: date_helper
INFO - 2016-12-12 04:01:17 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:17 --> Helper loaded: form_helper
INFO - 2016-12-12 04:01:17 --> Form Validation Class Initialized
INFO - 2016-12-12 04:01:17 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:17 --> Total execution time: 0.0204
INFO - 2016-12-12 04:01:17 --> Config Class Initialized
INFO - 2016-12-12 04:01:17 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:17 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:17 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:17 --> URI Class Initialized
DEBUG - 2016-12-12 04:01:17 --> No URI present. Default controller set.
INFO - 2016-12-12 04:01:17 --> Router Class Initialized
INFO - 2016-12-12 04:01:17 --> Output Class Initialized
INFO - 2016-12-12 04:01:17 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:17 --> Input Class Initialized
INFO - 2016-12-12 04:01:17 --> Language Class Initialized
INFO - 2016-12-12 04:01:17 --> Loader Class Initialized
INFO - 2016-12-12 04:01:17 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:17 --> Controller Class Initialized
INFO - 2016-12-12 04:01:17 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:01:17 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:17 --> Total execution time: 0.0130
INFO - 2016-12-12 04:01:18 --> Config Class Initialized
INFO - 2016-12-12 04:01:18 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:18 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:18 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:18 --> URI Class Initialized
INFO - 2016-12-12 04:01:18 --> Router Class Initialized
INFO - 2016-12-12 04:01:18 --> Output Class Initialized
INFO - 2016-12-12 04:01:18 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:18 --> Input Class Initialized
INFO - 2016-12-12 04:01:18 --> Language Class Initialized
INFO - 2016-12-12 04:01:18 --> Loader Class Initialized
INFO - 2016-12-12 04:01:18 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:18 --> Controller Class Initialized
INFO - 2016-12-12 04:01:18 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:01:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:01:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:01:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:01:18 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:18 --> Total execution time: 0.0133
INFO - 2016-12-12 04:01:24 --> Config Class Initialized
INFO - 2016-12-12 04:01:24 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:24 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:24 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:24 --> URI Class Initialized
INFO - 2016-12-12 04:01:24 --> Router Class Initialized
INFO - 2016-12-12 04:01:24 --> Output Class Initialized
INFO - 2016-12-12 04:01:24 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:24 --> Input Class Initialized
INFO - 2016-12-12 04:01:24 --> Language Class Initialized
INFO - 2016-12-12 04:01:24 --> Loader Class Initialized
INFO - 2016-12-12 04:01:24 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:24 --> Controller Class Initialized
INFO - 2016-12-12 04:01:24 --> Upload Class Initialized
INFO - 2016-12-12 04:01:24 --> Helper loaded: date_helper
INFO - 2016-12-12 04:01:24 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:24 --> Helper loaded: form_helper
INFO - 2016-12-12 04:01:24 --> Form Validation Class Initialized
INFO - 2016-12-12 04:01:24 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:24 --> Total execution time: 0.0144
INFO - 2016-12-12 04:01:27 --> Config Class Initialized
INFO - 2016-12-12 04:01:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:27 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:27 --> URI Class Initialized
INFO - 2016-12-12 04:01:27 --> Router Class Initialized
INFO - 2016-12-12 04:01:27 --> Output Class Initialized
INFO - 2016-12-12 04:01:27 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:27 --> Input Class Initialized
INFO - 2016-12-12 04:01:27 --> Language Class Initialized
INFO - 2016-12-12 04:01:27 --> Loader Class Initialized
INFO - 2016-12-12 04:01:27 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:27 --> Controller Class Initialized
INFO - 2016-12-12 04:01:27 --> Upload Class Initialized
INFO - 2016-12-12 04:01:27 --> Helper loaded: date_helper
INFO - 2016-12-12 04:01:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:27 --> Helper loaded: form_helper
INFO - 2016-12-12 04:01:27 --> Form Validation Class Initialized
INFO - 2016-12-12 04:01:27 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:27 --> Total execution time: 0.0159
INFO - 2016-12-12 04:01:32 --> Config Class Initialized
INFO - 2016-12-12 04:01:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:32 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:32 --> URI Class Initialized
INFO - 2016-12-12 04:01:32 --> Router Class Initialized
INFO - 2016-12-12 04:01:32 --> Output Class Initialized
INFO - 2016-12-12 04:01:32 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:32 --> Input Class Initialized
INFO - 2016-12-12 04:01:32 --> Language Class Initialized
INFO - 2016-12-12 04:01:32 --> Loader Class Initialized
INFO - 2016-12-12 04:01:32 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:32 --> Controller Class Initialized
INFO - 2016-12-12 04:01:32 --> Upload Class Initialized
INFO - 2016-12-12 04:01:32 --> Helper loaded: date_helper
INFO - 2016-12-12 04:01:32 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:32 --> Helper loaded: form_helper
INFO - 2016-12-12 04:01:32 --> Form Validation Class Initialized
INFO - 2016-12-12 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:01:32 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:32 --> Total execution time: 0.0154
INFO - 2016-12-12 04:01:32 --> Config Class Initialized
INFO - 2016-12-12 04:01:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:32 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:32 --> URI Class Initialized
INFO - 2016-12-12 04:01:32 --> Router Class Initialized
INFO - 2016-12-12 04:01:32 --> Output Class Initialized
INFO - 2016-12-12 04:01:32 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:32 --> Input Class Initialized
INFO - 2016-12-12 04:01:32 --> Language Class Initialized
ERROR - 2016-12-12 04:01:32 --> 404 Page Not Found: Templates/administrador
INFO - 2016-12-12 04:01:35 --> Config Class Initialized
INFO - 2016-12-12 04:01:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:01:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:01:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:01:35 --> URI Class Initialized
INFO - 2016-12-12 04:01:35 --> Router Class Initialized
INFO - 2016-12-12 04:01:35 --> Output Class Initialized
INFO - 2016-12-12 04:01:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:01:35 --> Input Class Initialized
INFO - 2016-12-12 04:01:35 --> Language Class Initialized
INFO - 2016-12-12 04:01:35 --> Loader Class Initialized
INFO - 2016-12-12 04:01:35 --> Database Driver Class Initialized
INFO - 2016-12-12 04:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:01:35 --> Controller Class Initialized
INFO - 2016-12-12 04:01:35 --> Upload Class Initialized
INFO - 2016-12-12 04:01:35 --> Helper loaded: date_helper
INFO - 2016-12-12 04:01:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:01:35 --> Helper loaded: form_helper
INFO - 2016-12-12 04:01:35 --> Form Validation Class Initialized
INFO - 2016-12-12 04:01:35 --> Final output sent to browser
DEBUG - 2016-12-12 04:01:35 --> Total execution time: 0.0149
INFO - 2016-12-12 04:03:08 --> Config Class Initialized
INFO - 2016-12-12 04:03:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:03:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:03:08 --> Utf8 Class Initialized
INFO - 2016-12-12 04:03:08 --> URI Class Initialized
DEBUG - 2016-12-12 04:03:08 --> No URI present. Default controller set.
INFO - 2016-12-12 04:03:08 --> Router Class Initialized
INFO - 2016-12-12 04:03:08 --> Output Class Initialized
INFO - 2016-12-12 04:03:08 --> Security Class Initialized
DEBUG - 2016-12-12 04:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:03:08 --> Input Class Initialized
INFO - 2016-12-12 04:03:08 --> Language Class Initialized
INFO - 2016-12-12 04:03:08 --> Loader Class Initialized
INFO - 2016-12-12 04:03:08 --> Database Driver Class Initialized
INFO - 2016-12-12 04:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:03:08 --> Controller Class Initialized
INFO - 2016-12-12 04:03:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:03:09 --> Final output sent to browser
DEBUG - 2016-12-12 04:03:09 --> Total execution time: 0.9762
INFO - 2016-12-12 04:03:09 --> Config Class Initialized
INFO - 2016-12-12 04:03:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:03:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:03:09 --> Utf8 Class Initialized
INFO - 2016-12-12 04:03:09 --> URI Class Initialized
INFO - 2016-12-12 04:03:09 --> Router Class Initialized
INFO - 2016-12-12 04:03:09 --> Output Class Initialized
INFO - 2016-12-12 04:03:09 --> Security Class Initialized
DEBUG - 2016-12-12 04:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:03:09 --> Input Class Initialized
INFO - 2016-12-12 04:03:09 --> Language Class Initialized
INFO - 2016-12-12 04:03:09 --> Loader Class Initialized
INFO - 2016-12-12 04:03:09 --> Database Driver Class Initialized
INFO - 2016-12-12 04:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:03:09 --> Controller Class Initialized
INFO - 2016-12-12 04:03:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:03:09 --> Final output sent to browser
DEBUG - 2016-12-12 04:03:09 --> Total execution time: 0.0134
INFO - 2016-12-12 04:06:09 --> Config Class Initialized
INFO - 2016-12-12 04:06:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:06:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:06:09 --> Utf8 Class Initialized
INFO - 2016-12-12 04:06:09 --> URI Class Initialized
DEBUG - 2016-12-12 04:06:09 --> No URI present. Default controller set.
INFO - 2016-12-12 04:06:09 --> Router Class Initialized
INFO - 2016-12-12 04:06:09 --> Output Class Initialized
INFO - 2016-12-12 04:06:09 --> Security Class Initialized
DEBUG - 2016-12-12 04:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:06:09 --> Input Class Initialized
INFO - 2016-12-12 04:06:09 --> Language Class Initialized
INFO - 2016-12-12 04:06:09 --> Loader Class Initialized
INFO - 2016-12-12 04:06:09 --> Database Driver Class Initialized
INFO - 2016-12-12 04:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:06:09 --> Controller Class Initialized
INFO - 2016-12-12 04:06:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:06:09 --> Final output sent to browser
DEBUG - 2016-12-12 04:06:09 --> Total execution time: 0.0134
INFO - 2016-12-12 04:06:10 --> Config Class Initialized
INFO - 2016-12-12 04:06:10 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:06:10 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:06:10 --> Utf8 Class Initialized
INFO - 2016-12-12 04:06:10 --> URI Class Initialized
INFO - 2016-12-12 04:06:10 --> Router Class Initialized
INFO - 2016-12-12 04:06:10 --> Output Class Initialized
INFO - 2016-12-12 04:06:10 --> Security Class Initialized
DEBUG - 2016-12-12 04:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:06:10 --> Input Class Initialized
INFO - 2016-12-12 04:06:10 --> Language Class Initialized
INFO - 2016-12-12 04:06:10 --> Loader Class Initialized
INFO - 2016-12-12 04:06:10 --> Database Driver Class Initialized
INFO - 2016-12-12 04:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:06:10 --> Controller Class Initialized
INFO - 2016-12-12 04:06:10 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:06:10 --> Final output sent to browser
DEBUG - 2016-12-12 04:06:10 --> Total execution time: 0.0133
INFO - 2016-12-12 04:06:34 --> Config Class Initialized
INFO - 2016-12-12 04:06:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:06:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:06:34 --> Utf8 Class Initialized
INFO - 2016-12-12 04:06:34 --> URI Class Initialized
DEBUG - 2016-12-12 04:06:34 --> No URI present. Default controller set.
INFO - 2016-12-12 04:06:34 --> Router Class Initialized
INFO - 2016-12-12 04:06:34 --> Output Class Initialized
INFO - 2016-12-12 04:06:34 --> Security Class Initialized
DEBUG - 2016-12-12 04:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:06:34 --> Input Class Initialized
INFO - 2016-12-12 04:06:34 --> Language Class Initialized
INFO - 2016-12-12 04:06:34 --> Loader Class Initialized
INFO - 2016-12-12 04:06:34 --> Database Driver Class Initialized
INFO - 2016-12-12 04:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:06:34 --> Controller Class Initialized
INFO - 2016-12-12 04:06:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:06:34 --> Final output sent to browser
DEBUG - 2016-12-12 04:06:34 --> Total execution time: 0.0339
INFO - 2016-12-12 04:06:34 --> Config Class Initialized
INFO - 2016-12-12 04:06:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:06:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:06:34 --> Utf8 Class Initialized
INFO - 2016-12-12 04:06:34 --> URI Class Initialized
INFO - 2016-12-12 04:06:34 --> Router Class Initialized
INFO - 2016-12-12 04:06:34 --> Output Class Initialized
INFO - 2016-12-12 04:06:34 --> Security Class Initialized
DEBUG - 2016-12-12 04:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:06:34 --> Input Class Initialized
INFO - 2016-12-12 04:06:34 --> Language Class Initialized
INFO - 2016-12-12 04:06:34 --> Loader Class Initialized
INFO - 2016-12-12 04:06:34 --> Database Driver Class Initialized
INFO - 2016-12-12 04:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:06:34 --> Controller Class Initialized
INFO - 2016-12-12 04:06:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:06:34 --> Final output sent to browser
DEBUG - 2016-12-12 04:06:34 --> Total execution time: 0.0132
INFO - 2016-12-12 04:06:41 --> Config Class Initialized
INFO - 2016-12-12 04:06:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:06:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:06:41 --> Utf8 Class Initialized
INFO - 2016-12-12 04:06:41 --> URI Class Initialized
INFO - 2016-12-12 04:06:41 --> Router Class Initialized
INFO - 2016-12-12 04:06:41 --> Output Class Initialized
INFO - 2016-12-12 04:06:41 --> Security Class Initialized
DEBUG - 2016-12-12 04:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:06:41 --> Input Class Initialized
INFO - 2016-12-12 04:06:41 --> Language Class Initialized
ERROR - 2016-12-12 04:06:41 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:07:04 --> Config Class Initialized
INFO - 2016-12-12 04:07:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:07:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:07:04 --> Utf8 Class Initialized
INFO - 2016-12-12 04:07:04 --> URI Class Initialized
DEBUG - 2016-12-12 04:07:04 --> No URI present. Default controller set.
INFO - 2016-12-12 04:07:04 --> Router Class Initialized
INFO - 2016-12-12 04:07:04 --> Output Class Initialized
INFO - 2016-12-12 04:07:04 --> Security Class Initialized
DEBUG - 2016-12-12 04:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:07:04 --> Input Class Initialized
INFO - 2016-12-12 04:07:04 --> Language Class Initialized
INFO - 2016-12-12 04:07:04 --> Loader Class Initialized
INFO - 2016-12-12 04:07:04 --> Database Driver Class Initialized
INFO - 2016-12-12 04:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:07:04 --> Controller Class Initialized
INFO - 2016-12-12 04:07:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:07:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:07:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:07:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:07:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:07:04 --> Final output sent to browser
DEBUG - 2016-12-12 04:07:04 --> Total execution time: 0.0133
INFO - 2016-12-12 04:07:05 --> Config Class Initialized
INFO - 2016-12-12 04:07:05 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:07:05 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:07:05 --> Utf8 Class Initialized
INFO - 2016-12-12 04:07:05 --> URI Class Initialized
INFO - 2016-12-12 04:07:05 --> Router Class Initialized
INFO - 2016-12-12 04:07:05 --> Output Class Initialized
INFO - 2016-12-12 04:07:05 --> Security Class Initialized
DEBUG - 2016-12-12 04:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:07:05 --> Input Class Initialized
INFO - 2016-12-12 04:07:05 --> Language Class Initialized
INFO - 2016-12-12 04:07:05 --> Loader Class Initialized
INFO - 2016-12-12 04:07:05 --> Database Driver Class Initialized
INFO - 2016-12-12 04:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:07:05 --> Controller Class Initialized
INFO - 2016-12-12 04:07:05 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:07:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:07:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:07:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:07:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:07:05 --> Final output sent to browser
DEBUG - 2016-12-12 04:07:05 --> Total execution time: 0.0255
INFO - 2016-12-12 04:08:11 --> Config Class Initialized
INFO - 2016-12-12 04:08:11 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:08:11 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:08:11 --> Utf8 Class Initialized
INFO - 2016-12-12 04:08:11 --> URI Class Initialized
DEBUG - 2016-12-12 04:08:11 --> No URI present. Default controller set.
INFO - 2016-12-12 04:08:11 --> Router Class Initialized
INFO - 2016-12-12 04:08:11 --> Output Class Initialized
INFO - 2016-12-12 04:08:11 --> Security Class Initialized
DEBUG - 2016-12-12 04:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:08:11 --> Input Class Initialized
INFO - 2016-12-12 04:08:11 --> Language Class Initialized
INFO - 2016-12-12 04:08:11 --> Loader Class Initialized
INFO - 2016-12-12 04:08:11 --> Database Driver Class Initialized
INFO - 2016-12-12 04:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:08:11 --> Controller Class Initialized
INFO - 2016-12-12 04:08:11 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:08:11 --> Final output sent to browser
DEBUG - 2016-12-12 04:08:11 --> Total execution time: 0.0139
INFO - 2016-12-12 04:08:12 --> Config Class Initialized
INFO - 2016-12-12 04:08:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:08:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:08:12 --> Utf8 Class Initialized
INFO - 2016-12-12 04:08:12 --> URI Class Initialized
INFO - 2016-12-12 04:08:12 --> Router Class Initialized
INFO - 2016-12-12 04:08:12 --> Output Class Initialized
INFO - 2016-12-12 04:08:12 --> Security Class Initialized
DEBUG - 2016-12-12 04:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:08:12 --> Input Class Initialized
INFO - 2016-12-12 04:08:12 --> Language Class Initialized
INFO - 2016-12-12 04:08:12 --> Loader Class Initialized
INFO - 2016-12-12 04:08:12 --> Database Driver Class Initialized
INFO - 2016-12-12 04:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:08:12 --> Controller Class Initialized
INFO - 2016-12-12 04:08:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:08:12 --> Final output sent to browser
DEBUG - 2016-12-12 04:08:12 --> Total execution time: 0.0150
INFO - 2016-12-12 04:08:35 --> Config Class Initialized
INFO - 2016-12-12 04:08:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:08:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:08:35 --> URI Class Initialized
DEBUG - 2016-12-12 04:08:35 --> No URI present. Default controller set.
INFO - 2016-12-12 04:08:35 --> Router Class Initialized
INFO - 2016-12-12 04:08:35 --> Output Class Initialized
INFO - 2016-12-12 04:08:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:08:35 --> Input Class Initialized
INFO - 2016-12-12 04:08:35 --> Language Class Initialized
INFO - 2016-12-12 04:08:35 --> Loader Class Initialized
INFO - 2016-12-12 04:08:35 --> Database Driver Class Initialized
INFO - 2016-12-12 04:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:08:35 --> Controller Class Initialized
INFO - 2016-12-12 04:08:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:08:35 --> Final output sent to browser
DEBUG - 2016-12-12 04:08:35 --> Total execution time: 0.0134
INFO - 2016-12-12 04:08:35 --> Config Class Initialized
INFO - 2016-12-12 04:08:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:08:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:08:35 --> URI Class Initialized
INFO - 2016-12-12 04:08:35 --> Router Class Initialized
INFO - 2016-12-12 04:08:35 --> Output Class Initialized
INFO - 2016-12-12 04:08:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:08:35 --> Input Class Initialized
INFO - 2016-12-12 04:08:35 --> Language Class Initialized
INFO - 2016-12-12 04:08:35 --> Loader Class Initialized
INFO - 2016-12-12 04:08:35 --> Database Driver Class Initialized
INFO - 2016-12-12 04:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:08:35 --> Controller Class Initialized
INFO - 2016-12-12 04:08:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:08:35 --> Final output sent to browser
DEBUG - 2016-12-12 04:08:35 --> Total execution time: 0.0135
INFO - 2016-12-12 04:09:27 --> Config Class Initialized
INFO - 2016-12-12 04:09:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:09:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:09:27 --> Utf8 Class Initialized
INFO - 2016-12-12 04:09:27 --> URI Class Initialized
DEBUG - 2016-12-12 04:09:27 --> No URI present. Default controller set.
INFO - 2016-12-12 04:09:27 --> Router Class Initialized
INFO - 2016-12-12 04:09:27 --> Output Class Initialized
INFO - 2016-12-12 04:09:27 --> Security Class Initialized
DEBUG - 2016-12-12 04:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:09:27 --> Input Class Initialized
INFO - 2016-12-12 04:09:27 --> Language Class Initialized
INFO - 2016-12-12 04:09:27 --> Loader Class Initialized
INFO - 2016-12-12 04:09:27 --> Database Driver Class Initialized
INFO - 2016-12-12 04:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:09:27 --> Controller Class Initialized
INFO - 2016-12-12 04:09:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:09:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:09:27 --> Final output sent to browser
DEBUG - 2016-12-12 04:09:27 --> Total execution time: 0.0140
INFO - 2016-12-12 04:09:27 --> Config Class Initialized
INFO - 2016-12-12 04:09:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:09:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:09:27 --> Utf8 Class Initialized
INFO - 2016-12-12 04:09:27 --> URI Class Initialized
INFO - 2016-12-12 04:09:27 --> Router Class Initialized
INFO - 2016-12-12 04:09:27 --> Output Class Initialized
INFO - 2016-12-12 04:09:27 --> Security Class Initialized
DEBUG - 2016-12-12 04:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:09:27 --> Input Class Initialized
INFO - 2016-12-12 04:09:27 --> Language Class Initialized
INFO - 2016-12-12 04:09:27 --> Loader Class Initialized
INFO - 2016-12-12 04:09:27 --> Database Driver Class Initialized
INFO - 2016-12-12 04:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:09:27 --> Controller Class Initialized
INFO - 2016-12-12 04:09:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:09:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:09:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:09:27 --> Final output sent to browser
DEBUG - 2016-12-12 04:09:27 --> Total execution time: 0.0131
INFO - 2016-12-12 04:11:45 --> Config Class Initialized
INFO - 2016-12-12 04:11:45 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:11:45 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:11:45 --> Utf8 Class Initialized
INFO - 2016-12-12 04:11:45 --> URI Class Initialized
DEBUG - 2016-12-12 04:11:45 --> No URI present. Default controller set.
INFO - 2016-12-12 04:11:45 --> Router Class Initialized
INFO - 2016-12-12 04:11:45 --> Output Class Initialized
INFO - 2016-12-12 04:11:45 --> Security Class Initialized
DEBUG - 2016-12-12 04:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:11:45 --> Input Class Initialized
INFO - 2016-12-12 04:11:45 --> Language Class Initialized
INFO - 2016-12-12 04:11:45 --> Loader Class Initialized
INFO - 2016-12-12 04:11:45 --> Database Driver Class Initialized
INFO - 2016-12-12 04:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:11:45 --> Controller Class Initialized
INFO - 2016-12-12 04:11:45 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:11:45 --> Final output sent to browser
DEBUG - 2016-12-12 04:11:45 --> Total execution time: 0.0144
INFO - 2016-12-12 04:11:46 --> Config Class Initialized
INFO - 2016-12-12 04:11:46 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:11:46 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:11:46 --> Utf8 Class Initialized
INFO - 2016-12-12 04:11:46 --> URI Class Initialized
INFO - 2016-12-12 04:11:46 --> Router Class Initialized
INFO - 2016-12-12 04:11:46 --> Output Class Initialized
INFO - 2016-12-12 04:11:46 --> Security Class Initialized
DEBUG - 2016-12-12 04:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:11:46 --> Input Class Initialized
INFO - 2016-12-12 04:11:46 --> Language Class Initialized
INFO - 2016-12-12 04:11:46 --> Loader Class Initialized
INFO - 2016-12-12 04:11:46 --> Database Driver Class Initialized
INFO - 2016-12-12 04:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:11:46 --> Controller Class Initialized
INFO - 2016-12-12 04:11:46 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:11:46 --> Final output sent to browser
DEBUG - 2016-12-12 04:11:46 --> Total execution time: 0.0132
INFO - 2016-12-12 04:12:05 --> Config Class Initialized
INFO - 2016-12-12 04:12:05 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:05 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:05 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:05 --> URI Class Initialized
DEBUG - 2016-12-12 04:12:05 --> No URI present. Default controller set.
INFO - 2016-12-12 04:12:05 --> Router Class Initialized
INFO - 2016-12-12 04:12:05 --> Output Class Initialized
INFO - 2016-12-12 04:12:05 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:05 --> Input Class Initialized
INFO - 2016-12-12 04:12:05 --> Language Class Initialized
INFO - 2016-12-12 04:12:05 --> Loader Class Initialized
INFO - 2016-12-12 04:12:05 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:05 --> Controller Class Initialized
INFO - 2016-12-12 04:12:05 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:05 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:05 --> Total execution time: 0.0141
INFO - 2016-12-12 04:12:05 --> Config Class Initialized
INFO - 2016-12-12 04:12:05 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:05 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:05 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:05 --> URI Class Initialized
INFO - 2016-12-12 04:12:05 --> Router Class Initialized
INFO - 2016-12-12 04:12:05 --> Output Class Initialized
INFO - 2016-12-12 04:12:05 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:05 --> Input Class Initialized
INFO - 2016-12-12 04:12:05 --> Language Class Initialized
INFO - 2016-12-12 04:12:05 --> Loader Class Initialized
INFO - 2016-12-12 04:12:05 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:05 --> Controller Class Initialized
INFO - 2016-12-12 04:12:05 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:05 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:05 --> Total execution time: 0.0137
INFO - 2016-12-12 04:12:09 --> Config Class Initialized
INFO - 2016-12-12 04:12:09 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:09 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:09 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:09 --> URI Class Initialized
DEBUG - 2016-12-12 04:12:09 --> No URI present. Default controller set.
INFO - 2016-12-12 04:12:09 --> Router Class Initialized
INFO - 2016-12-12 04:12:09 --> Output Class Initialized
INFO - 2016-12-12 04:12:09 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:09 --> Input Class Initialized
INFO - 2016-12-12 04:12:09 --> Language Class Initialized
INFO - 2016-12-12 04:12:09 --> Loader Class Initialized
INFO - 2016-12-12 04:12:09 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:09 --> Controller Class Initialized
INFO - 2016-12-12 04:12:09 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:09 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:09 --> Total execution time: 0.0138
INFO - 2016-12-12 04:12:10 --> Config Class Initialized
INFO - 2016-12-12 04:12:10 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:10 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:10 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:10 --> URI Class Initialized
INFO - 2016-12-12 04:12:10 --> Router Class Initialized
INFO - 2016-12-12 04:12:10 --> Output Class Initialized
INFO - 2016-12-12 04:12:10 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:10 --> Input Class Initialized
INFO - 2016-12-12 04:12:10 --> Language Class Initialized
INFO - 2016-12-12 04:12:10 --> Loader Class Initialized
INFO - 2016-12-12 04:12:10 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:10 --> Controller Class Initialized
INFO - 2016-12-12 04:12:10 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:10 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:10 --> Total execution time: 0.0145
INFO - 2016-12-12 04:12:22 --> Config Class Initialized
INFO - 2016-12-12 04:12:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:22 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:22 --> URI Class Initialized
DEBUG - 2016-12-12 04:12:22 --> No URI present. Default controller set.
INFO - 2016-12-12 04:12:22 --> Router Class Initialized
INFO - 2016-12-12 04:12:22 --> Output Class Initialized
INFO - 2016-12-12 04:12:22 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:22 --> Input Class Initialized
INFO - 2016-12-12 04:12:22 --> Language Class Initialized
INFO - 2016-12-12 04:12:22 --> Loader Class Initialized
INFO - 2016-12-12 04:12:22 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:22 --> Controller Class Initialized
INFO - 2016-12-12 04:12:22 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:22 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:22 --> Total execution time: 0.0135
INFO - 2016-12-12 04:12:22 --> Config Class Initialized
INFO - 2016-12-12 04:12:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:22 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:22 --> URI Class Initialized
INFO - 2016-12-12 04:12:22 --> Router Class Initialized
INFO - 2016-12-12 04:12:22 --> Output Class Initialized
INFO - 2016-12-12 04:12:22 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:22 --> Input Class Initialized
INFO - 2016-12-12 04:12:22 --> Language Class Initialized
INFO - 2016-12-12 04:12:22 --> Loader Class Initialized
INFO - 2016-12-12 04:12:22 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:22 --> Controller Class Initialized
INFO - 2016-12-12 04:12:22 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:22 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:22 --> Total execution time: 0.0144
INFO - 2016-12-12 04:12:25 --> Config Class Initialized
INFO - 2016-12-12 04:12:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:25 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:25 --> URI Class Initialized
DEBUG - 2016-12-12 04:12:25 --> No URI present. Default controller set.
INFO - 2016-12-12 04:12:25 --> Router Class Initialized
INFO - 2016-12-12 04:12:25 --> Output Class Initialized
INFO - 2016-12-12 04:12:25 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:25 --> Input Class Initialized
INFO - 2016-12-12 04:12:25 --> Language Class Initialized
INFO - 2016-12-12 04:12:25 --> Loader Class Initialized
INFO - 2016-12-12 04:12:25 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:25 --> Controller Class Initialized
INFO - 2016-12-12 04:12:25 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:25 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:25 --> Total execution time: 0.0136
INFO - 2016-12-12 04:12:25 --> Config Class Initialized
INFO - 2016-12-12 04:12:25 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:12:25 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:12:25 --> Utf8 Class Initialized
INFO - 2016-12-12 04:12:25 --> URI Class Initialized
INFO - 2016-12-12 04:12:25 --> Router Class Initialized
INFO - 2016-12-12 04:12:25 --> Output Class Initialized
INFO - 2016-12-12 04:12:25 --> Security Class Initialized
DEBUG - 2016-12-12 04:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:12:25 --> Input Class Initialized
INFO - 2016-12-12 04:12:25 --> Language Class Initialized
INFO - 2016-12-12 04:12:25 --> Loader Class Initialized
INFO - 2016-12-12 04:12:25 --> Database Driver Class Initialized
INFO - 2016-12-12 04:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:12:25 --> Controller Class Initialized
INFO - 2016-12-12 04:12:25 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:12:25 --> Final output sent to browser
DEBUG - 2016-12-12 04:12:25 --> Total execution time: 0.0134
INFO - 2016-12-12 04:13:12 --> Config Class Initialized
INFO - 2016-12-12 04:13:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:12 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:12 --> URI Class Initialized
DEBUG - 2016-12-12 04:13:12 --> No URI present. Default controller set.
INFO - 2016-12-12 04:13:12 --> Router Class Initialized
INFO - 2016-12-12 04:13:12 --> Output Class Initialized
INFO - 2016-12-12 04:13:12 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:12 --> Input Class Initialized
INFO - 2016-12-12 04:13:12 --> Language Class Initialized
INFO - 2016-12-12 04:13:12 --> Loader Class Initialized
INFO - 2016-12-12 04:13:12 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:12 --> Controller Class Initialized
INFO - 2016-12-12 04:13:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:12 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:12 --> Total execution time: 0.0141
INFO - 2016-12-12 04:13:12 --> Config Class Initialized
INFO - 2016-12-12 04:13:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:12 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:12 --> URI Class Initialized
INFO - 2016-12-12 04:13:12 --> Router Class Initialized
INFO - 2016-12-12 04:13:12 --> Output Class Initialized
INFO - 2016-12-12 04:13:12 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:12 --> Input Class Initialized
INFO - 2016-12-12 04:13:12 --> Language Class Initialized
INFO - 2016-12-12 04:13:12 --> Loader Class Initialized
INFO - 2016-12-12 04:13:12 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:12 --> Controller Class Initialized
INFO - 2016-12-12 04:13:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:12 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:12 --> Total execution time: 0.0134
INFO - 2016-12-12 04:13:14 --> Config Class Initialized
INFO - 2016-12-12 04:13:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:14 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:14 --> URI Class Initialized
DEBUG - 2016-12-12 04:13:14 --> No URI present. Default controller set.
INFO - 2016-12-12 04:13:14 --> Router Class Initialized
INFO - 2016-12-12 04:13:14 --> Output Class Initialized
INFO - 2016-12-12 04:13:14 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:14 --> Input Class Initialized
INFO - 2016-12-12 04:13:14 --> Language Class Initialized
INFO - 2016-12-12 04:13:14 --> Loader Class Initialized
INFO - 2016-12-12 04:13:14 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:14 --> Controller Class Initialized
INFO - 2016-12-12 04:13:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:14 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:14 --> Total execution time: 0.0132
INFO - 2016-12-12 04:13:14 --> Config Class Initialized
INFO - 2016-12-12 04:13:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:14 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:14 --> URI Class Initialized
INFO - 2016-12-12 04:13:14 --> Router Class Initialized
INFO - 2016-12-12 04:13:14 --> Output Class Initialized
INFO - 2016-12-12 04:13:14 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:14 --> Input Class Initialized
INFO - 2016-12-12 04:13:14 --> Language Class Initialized
INFO - 2016-12-12 04:13:14 --> Loader Class Initialized
INFO - 2016-12-12 04:13:14 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:14 --> Controller Class Initialized
INFO - 2016-12-12 04:13:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:14 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:14 --> Total execution time: 0.0680
INFO - 2016-12-12 04:13:14 --> Config Class Initialized
INFO - 2016-12-12 04:13:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:14 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:14 --> URI Class Initialized
DEBUG - 2016-12-12 04:13:14 --> No URI present. Default controller set.
INFO - 2016-12-12 04:13:14 --> Router Class Initialized
INFO - 2016-12-12 04:13:14 --> Output Class Initialized
INFO - 2016-12-12 04:13:14 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:14 --> Input Class Initialized
INFO - 2016-12-12 04:13:14 --> Language Class Initialized
INFO - 2016-12-12 04:13:14 --> Loader Class Initialized
INFO - 2016-12-12 04:13:14 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:14 --> Controller Class Initialized
INFO - 2016-12-12 04:13:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:14 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:14 --> Total execution time: 0.0143
INFO - 2016-12-12 04:13:15 --> Config Class Initialized
INFO - 2016-12-12 04:13:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:15 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:15 --> URI Class Initialized
INFO - 2016-12-12 04:13:15 --> Router Class Initialized
INFO - 2016-12-12 04:13:15 --> Output Class Initialized
INFO - 2016-12-12 04:13:15 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:15 --> Input Class Initialized
INFO - 2016-12-12 04:13:15 --> Language Class Initialized
INFO - 2016-12-12 04:13:15 --> Loader Class Initialized
INFO - 2016-12-12 04:13:15 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:15 --> Controller Class Initialized
INFO - 2016-12-12 04:13:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:15 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:15 --> Total execution time: 0.0134
INFO - 2016-12-12 04:13:51 --> Config Class Initialized
INFO - 2016-12-12 04:13:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:51 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:51 --> URI Class Initialized
DEBUG - 2016-12-12 04:13:51 --> No URI present. Default controller set.
INFO - 2016-12-12 04:13:51 --> Router Class Initialized
INFO - 2016-12-12 04:13:51 --> Output Class Initialized
INFO - 2016-12-12 04:13:51 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:51 --> Input Class Initialized
INFO - 2016-12-12 04:13:51 --> Language Class Initialized
INFO - 2016-12-12 04:13:51 --> Loader Class Initialized
INFO - 2016-12-12 04:13:51 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:51 --> Controller Class Initialized
INFO - 2016-12-12 04:13:51 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:51 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:51 --> Total execution time: 0.0135
INFO - 2016-12-12 04:13:51 --> Config Class Initialized
INFO - 2016-12-12 04:13:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:13:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:13:51 --> Utf8 Class Initialized
INFO - 2016-12-12 04:13:51 --> URI Class Initialized
INFO - 2016-12-12 04:13:51 --> Router Class Initialized
INFO - 2016-12-12 04:13:51 --> Output Class Initialized
INFO - 2016-12-12 04:13:51 --> Security Class Initialized
DEBUG - 2016-12-12 04:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:13:51 --> Input Class Initialized
INFO - 2016-12-12 04:13:51 --> Language Class Initialized
INFO - 2016-12-12 04:13:51 --> Loader Class Initialized
INFO - 2016-12-12 04:13:51 --> Database Driver Class Initialized
INFO - 2016-12-12 04:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:13:51 --> Controller Class Initialized
INFO - 2016-12-12 04:13:51 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:13:51 --> Final output sent to browser
DEBUG - 2016-12-12 04:13:51 --> Total execution time: 0.0130
INFO - 2016-12-12 04:14:08 --> Config Class Initialized
INFO - 2016-12-12 04:14:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:14:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:14:08 --> Utf8 Class Initialized
INFO - 2016-12-12 04:14:08 --> URI Class Initialized
DEBUG - 2016-12-12 04:14:08 --> No URI present. Default controller set.
INFO - 2016-12-12 04:14:08 --> Router Class Initialized
INFO - 2016-12-12 04:14:08 --> Output Class Initialized
INFO - 2016-12-12 04:14:08 --> Security Class Initialized
DEBUG - 2016-12-12 04:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:14:08 --> Input Class Initialized
INFO - 2016-12-12 04:14:08 --> Language Class Initialized
INFO - 2016-12-12 04:14:08 --> Loader Class Initialized
INFO - 2016-12-12 04:14:08 --> Database Driver Class Initialized
INFO - 2016-12-12 04:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:14:08 --> Controller Class Initialized
INFO - 2016-12-12 04:14:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:14:08 --> Final output sent to browser
DEBUG - 2016-12-12 04:14:08 --> Total execution time: 0.0127
INFO - 2016-12-12 04:14:08 --> Config Class Initialized
INFO - 2016-12-12 04:14:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:14:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:14:08 --> Utf8 Class Initialized
INFO - 2016-12-12 04:14:08 --> URI Class Initialized
INFO - 2016-12-12 04:14:08 --> Router Class Initialized
INFO - 2016-12-12 04:14:08 --> Output Class Initialized
INFO - 2016-12-12 04:14:08 --> Security Class Initialized
DEBUG - 2016-12-12 04:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:14:08 --> Input Class Initialized
INFO - 2016-12-12 04:14:08 --> Language Class Initialized
INFO - 2016-12-12 04:14:08 --> Loader Class Initialized
INFO - 2016-12-12 04:14:08 --> Database Driver Class Initialized
INFO - 2016-12-12 04:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:14:08 --> Controller Class Initialized
INFO - 2016-12-12 04:14:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:14:08 --> Final output sent to browser
DEBUG - 2016-12-12 04:14:08 --> Total execution time: 0.0138
INFO - 2016-12-12 04:15:31 --> Config Class Initialized
INFO - 2016-12-12 04:15:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:15:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:15:31 --> Utf8 Class Initialized
INFO - 2016-12-12 04:15:31 --> URI Class Initialized
DEBUG - 2016-12-12 04:15:31 --> No URI present. Default controller set.
INFO - 2016-12-12 04:15:31 --> Router Class Initialized
INFO - 2016-12-12 04:15:31 --> Output Class Initialized
INFO - 2016-12-12 04:15:31 --> Security Class Initialized
DEBUG - 2016-12-12 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:15:31 --> Input Class Initialized
INFO - 2016-12-12 04:15:31 --> Language Class Initialized
INFO - 2016-12-12 04:15:31 --> Loader Class Initialized
INFO - 2016-12-12 04:15:31 --> Database Driver Class Initialized
INFO - 2016-12-12 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:15:31 --> Controller Class Initialized
INFO - 2016-12-12 04:15:31 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:15:31 --> Final output sent to browser
DEBUG - 2016-12-12 04:15:31 --> Total execution time: 0.0130
INFO - 2016-12-12 04:15:31 --> Config Class Initialized
INFO - 2016-12-12 04:15:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:15:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:15:31 --> Utf8 Class Initialized
INFO - 2016-12-12 04:15:31 --> URI Class Initialized
INFO - 2016-12-12 04:15:31 --> Router Class Initialized
INFO - 2016-12-12 04:15:31 --> Output Class Initialized
INFO - 2016-12-12 04:15:31 --> Security Class Initialized
DEBUG - 2016-12-12 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:15:31 --> Input Class Initialized
INFO - 2016-12-12 04:15:31 --> Language Class Initialized
INFO - 2016-12-12 04:15:31 --> Loader Class Initialized
INFO - 2016-12-12 04:15:31 --> Database Driver Class Initialized
INFO - 2016-12-12 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:15:31 --> Controller Class Initialized
INFO - 2016-12-12 04:15:31 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:15:31 --> Final output sent to browser
DEBUG - 2016-12-12 04:15:31 --> Total execution time: 0.0129
INFO - 2016-12-12 04:15:48 --> Config Class Initialized
INFO - 2016-12-12 04:15:48 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:15:48 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:15:48 --> Utf8 Class Initialized
INFO - 2016-12-12 04:15:48 --> URI Class Initialized
INFO - 2016-12-12 04:15:48 --> Router Class Initialized
INFO - 2016-12-12 04:15:48 --> Output Class Initialized
INFO - 2016-12-12 04:15:48 --> Security Class Initialized
DEBUG - 2016-12-12 04:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:15:48 --> Input Class Initialized
INFO - 2016-12-12 04:15:48 --> Language Class Initialized
ERROR - 2016-12-12 04:15:48 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:18:10 --> Config Class Initialized
INFO - 2016-12-12 04:18:10 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:18:10 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:18:10 --> Utf8 Class Initialized
INFO - 2016-12-12 04:18:10 --> URI Class Initialized
DEBUG - 2016-12-12 04:18:10 --> No URI present. Default controller set.
INFO - 2016-12-12 04:18:10 --> Router Class Initialized
INFO - 2016-12-12 04:18:10 --> Output Class Initialized
INFO - 2016-12-12 04:18:10 --> Security Class Initialized
DEBUG - 2016-12-12 04:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:18:10 --> Input Class Initialized
INFO - 2016-12-12 04:18:10 --> Language Class Initialized
INFO - 2016-12-12 04:18:10 --> Loader Class Initialized
INFO - 2016-12-12 04:18:10 --> Database Driver Class Initialized
INFO - 2016-12-12 04:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:18:10 --> Controller Class Initialized
INFO - 2016-12-12 04:18:10 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:18:10 --> Final output sent to browser
DEBUG - 2016-12-12 04:18:10 --> Total execution time: 0.0160
INFO - 2016-12-12 04:18:11 --> Config Class Initialized
INFO - 2016-12-12 04:18:11 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:18:11 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:18:11 --> Utf8 Class Initialized
INFO - 2016-12-12 04:18:11 --> URI Class Initialized
INFO - 2016-12-12 04:18:11 --> Router Class Initialized
INFO - 2016-12-12 04:18:11 --> Output Class Initialized
INFO - 2016-12-12 04:18:11 --> Security Class Initialized
DEBUG - 2016-12-12 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:18:11 --> Input Class Initialized
INFO - 2016-12-12 04:18:11 --> Language Class Initialized
ERROR - 2016-12-12 04:18:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:18:11 --> Config Class Initialized
INFO - 2016-12-12 04:18:11 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:18:11 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:18:11 --> Utf8 Class Initialized
INFO - 2016-12-12 04:18:11 --> URI Class Initialized
INFO - 2016-12-12 04:18:11 --> Router Class Initialized
INFO - 2016-12-12 04:18:11 --> Output Class Initialized
INFO - 2016-12-12 04:18:11 --> Security Class Initialized
DEBUG - 2016-12-12 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:18:11 --> Input Class Initialized
INFO - 2016-12-12 04:18:11 --> Language Class Initialized
INFO - 2016-12-12 04:18:11 --> Loader Class Initialized
INFO - 2016-12-12 04:18:11 --> Database Driver Class Initialized
INFO - 2016-12-12 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:18:11 --> Controller Class Initialized
INFO - 2016-12-12 04:18:11 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:18:11 --> Final output sent to browser
DEBUG - 2016-12-12 04:18:11 --> Total execution time: 0.0472
INFO - 2016-12-12 04:19:04 --> Config Class Initialized
INFO - 2016-12-12 04:19:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:19:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:19:04 --> Utf8 Class Initialized
INFO - 2016-12-12 04:19:04 --> URI Class Initialized
DEBUG - 2016-12-12 04:19:04 --> No URI present. Default controller set.
INFO - 2016-12-12 04:19:04 --> Router Class Initialized
INFO - 2016-12-12 04:19:04 --> Output Class Initialized
INFO - 2016-12-12 04:19:04 --> Security Class Initialized
DEBUG - 2016-12-12 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:19:04 --> Input Class Initialized
INFO - 2016-12-12 04:19:04 --> Language Class Initialized
INFO - 2016-12-12 04:19:04 --> Loader Class Initialized
INFO - 2016-12-12 04:19:04 --> Database Driver Class Initialized
INFO - 2016-12-12 04:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:19:04 --> Controller Class Initialized
INFO - 2016-12-12 04:19:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:19:04 --> Final output sent to browser
DEBUG - 2016-12-12 04:19:04 --> Total execution time: 0.0131
INFO - 2016-12-12 04:19:04 --> Config Class Initialized
INFO - 2016-12-12 04:19:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:19:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:19:04 --> Utf8 Class Initialized
INFO - 2016-12-12 04:19:04 --> URI Class Initialized
INFO - 2016-12-12 04:19:04 --> Router Class Initialized
INFO - 2016-12-12 04:19:04 --> Output Class Initialized
INFO - 2016-12-12 04:19:04 --> Security Class Initialized
DEBUG - 2016-12-12 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:19:04 --> Input Class Initialized
INFO - 2016-12-12 04:19:04 --> Language Class Initialized
ERROR - 2016-12-12 04:19:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:19:05 --> Config Class Initialized
INFO - 2016-12-12 04:19:05 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:19:05 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:19:05 --> Utf8 Class Initialized
INFO - 2016-12-12 04:19:05 --> URI Class Initialized
INFO - 2016-12-12 04:19:05 --> Router Class Initialized
INFO - 2016-12-12 04:19:05 --> Output Class Initialized
INFO - 2016-12-12 04:19:05 --> Security Class Initialized
DEBUG - 2016-12-12 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:19:05 --> Input Class Initialized
INFO - 2016-12-12 04:19:05 --> Language Class Initialized
INFO - 2016-12-12 04:19:05 --> Loader Class Initialized
INFO - 2016-12-12 04:19:05 --> Database Driver Class Initialized
INFO - 2016-12-12 04:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:19:05 --> Controller Class Initialized
INFO - 2016-12-12 04:19:05 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:19:05 --> Final output sent to browser
DEBUG - 2016-12-12 04:19:05 --> Total execution time: 0.0132
INFO - 2016-12-12 04:19:22 --> Config Class Initialized
INFO - 2016-12-12 04:19:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:19:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:19:22 --> Utf8 Class Initialized
INFO - 2016-12-12 04:19:22 --> URI Class Initialized
DEBUG - 2016-12-12 04:19:22 --> No URI present. Default controller set.
INFO - 2016-12-12 04:19:22 --> Router Class Initialized
INFO - 2016-12-12 04:19:22 --> Output Class Initialized
INFO - 2016-12-12 04:19:22 --> Security Class Initialized
DEBUG - 2016-12-12 04:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:19:22 --> Input Class Initialized
INFO - 2016-12-12 04:19:22 --> Language Class Initialized
INFO - 2016-12-12 04:19:22 --> Loader Class Initialized
INFO - 2016-12-12 04:19:22 --> Database Driver Class Initialized
INFO - 2016-12-12 04:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:19:22 --> Controller Class Initialized
INFO - 2016-12-12 04:19:22 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:19:22 --> Final output sent to browser
DEBUG - 2016-12-12 04:19:22 --> Total execution time: 0.0132
INFO - 2016-12-12 04:19:22 --> Config Class Initialized
INFO - 2016-12-12 04:19:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:19:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:19:22 --> Utf8 Class Initialized
INFO - 2016-12-12 04:19:22 --> URI Class Initialized
INFO - 2016-12-12 04:19:22 --> Router Class Initialized
INFO - 2016-12-12 04:19:22 --> Output Class Initialized
INFO - 2016-12-12 04:19:22 --> Security Class Initialized
DEBUG - 2016-12-12 04:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:19:22 --> Input Class Initialized
INFO - 2016-12-12 04:19:22 --> Language Class Initialized
ERROR - 2016-12-12 04:19:22 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:19:23 --> Config Class Initialized
INFO - 2016-12-12 04:19:23 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:19:23 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:19:23 --> Utf8 Class Initialized
INFO - 2016-12-12 04:19:23 --> URI Class Initialized
INFO - 2016-12-12 04:19:23 --> Router Class Initialized
INFO - 2016-12-12 04:19:23 --> Output Class Initialized
INFO - 2016-12-12 04:19:23 --> Security Class Initialized
DEBUG - 2016-12-12 04:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:19:23 --> Input Class Initialized
INFO - 2016-12-12 04:19:23 --> Language Class Initialized
INFO - 2016-12-12 04:19:23 --> Loader Class Initialized
INFO - 2016-12-12 04:19:23 --> Database Driver Class Initialized
INFO - 2016-12-12 04:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:19:23 --> Controller Class Initialized
INFO - 2016-12-12 04:19:23 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:19:23 --> Final output sent to browser
DEBUG - 2016-12-12 04:19:23 --> Total execution time: 0.0132
INFO - 2016-12-12 04:33:56 --> Config Class Initialized
INFO - 2016-12-12 04:33:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:33:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:33:57 --> Utf8 Class Initialized
INFO - 2016-12-12 04:33:57 --> URI Class Initialized
DEBUG - 2016-12-12 04:33:57 --> No URI present. Default controller set.
INFO - 2016-12-12 04:33:57 --> Router Class Initialized
INFO - 2016-12-12 04:33:57 --> Output Class Initialized
INFO - 2016-12-12 04:33:57 --> Security Class Initialized
DEBUG - 2016-12-12 04:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:33:57 --> Input Class Initialized
INFO - 2016-12-12 04:33:57 --> Language Class Initialized
INFO - 2016-12-12 04:33:57 --> Loader Class Initialized
INFO - 2016-12-12 04:33:57 --> Database Driver Class Initialized
INFO - 2016-12-12 04:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:33:57 --> Controller Class Initialized
INFO - 2016-12-12 04:33:57 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:33:57 --> Final output sent to browser
DEBUG - 2016-12-12 04:33:57 --> Total execution time: 1.0913
INFO - 2016-12-12 04:33:58 --> Config Class Initialized
INFO - 2016-12-12 04:33:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:33:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:33:58 --> Utf8 Class Initialized
INFO - 2016-12-12 04:33:58 --> URI Class Initialized
INFO - 2016-12-12 04:33:58 --> Router Class Initialized
INFO - 2016-12-12 04:33:58 --> Output Class Initialized
INFO - 2016-12-12 04:33:58 --> Security Class Initialized
DEBUG - 2016-12-12 04:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:33:58 --> Input Class Initialized
INFO - 2016-12-12 04:33:58 --> Language Class Initialized
ERROR - 2016-12-12 04:33:58 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:33:58 --> Config Class Initialized
INFO - 2016-12-12 04:33:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:33:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:33:58 --> Utf8 Class Initialized
INFO - 2016-12-12 04:33:58 --> URI Class Initialized
INFO - 2016-12-12 04:33:58 --> Router Class Initialized
INFO - 2016-12-12 04:33:58 --> Output Class Initialized
INFO - 2016-12-12 04:33:58 --> Security Class Initialized
DEBUG - 2016-12-12 04:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:33:58 --> Input Class Initialized
INFO - 2016-12-12 04:33:58 --> Language Class Initialized
INFO - 2016-12-12 04:33:58 --> Loader Class Initialized
INFO - 2016-12-12 04:33:58 --> Database Driver Class Initialized
INFO - 2016-12-12 04:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:33:58 --> Controller Class Initialized
INFO - 2016-12-12 04:33:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:33:58 --> Final output sent to browser
DEBUG - 2016-12-12 04:33:58 --> Total execution time: 0.0132
INFO - 2016-12-12 04:34:19 --> Config Class Initialized
INFO - 2016-12-12 04:34:19 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:34:19 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:34:19 --> Utf8 Class Initialized
INFO - 2016-12-12 04:34:19 --> URI Class Initialized
DEBUG - 2016-12-12 04:34:19 --> No URI present. Default controller set.
INFO - 2016-12-12 04:34:19 --> Router Class Initialized
INFO - 2016-12-12 04:34:19 --> Output Class Initialized
INFO - 2016-12-12 04:34:19 --> Security Class Initialized
DEBUG - 2016-12-12 04:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:34:19 --> Input Class Initialized
INFO - 2016-12-12 04:34:19 --> Language Class Initialized
INFO - 2016-12-12 04:34:19 --> Loader Class Initialized
INFO - 2016-12-12 04:34:19 --> Database Driver Class Initialized
INFO - 2016-12-12 04:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:34:19 --> Controller Class Initialized
INFO - 2016-12-12 04:34:19 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:34:19 --> Final output sent to browser
DEBUG - 2016-12-12 04:34:19 --> Total execution time: 0.0134
INFO - 2016-12-12 04:34:20 --> Config Class Initialized
INFO - 2016-12-12 04:34:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:34:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:34:20 --> Utf8 Class Initialized
INFO - 2016-12-12 04:34:20 --> URI Class Initialized
INFO - 2016-12-12 04:34:20 --> Router Class Initialized
INFO - 2016-12-12 04:34:20 --> Output Class Initialized
INFO - 2016-12-12 04:34:20 --> Security Class Initialized
DEBUG - 2016-12-12 04:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:34:20 --> Input Class Initialized
INFO - 2016-12-12 04:34:20 --> Language Class Initialized
ERROR - 2016-12-12 04:34:20 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:34:20 --> Config Class Initialized
INFO - 2016-12-12 04:34:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:34:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:34:20 --> Utf8 Class Initialized
INFO - 2016-12-12 04:34:20 --> URI Class Initialized
INFO - 2016-12-12 04:34:20 --> Router Class Initialized
INFO - 2016-12-12 04:34:20 --> Output Class Initialized
INFO - 2016-12-12 04:34:20 --> Security Class Initialized
DEBUG - 2016-12-12 04:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:34:20 --> Input Class Initialized
INFO - 2016-12-12 04:34:20 --> Language Class Initialized
INFO - 2016-12-12 04:34:20 --> Loader Class Initialized
INFO - 2016-12-12 04:34:20 --> Database Driver Class Initialized
INFO - 2016-12-12 04:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:34:20 --> Controller Class Initialized
INFO - 2016-12-12 04:34:20 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:34:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:34:20 --> Final output sent to browser
DEBUG - 2016-12-12 04:34:20 --> Total execution time: 0.0140
INFO - 2016-12-12 04:35:12 --> Config Class Initialized
INFO - 2016-12-12 04:35:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:35:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:35:12 --> Utf8 Class Initialized
INFO - 2016-12-12 04:35:12 --> URI Class Initialized
DEBUG - 2016-12-12 04:35:12 --> No URI present. Default controller set.
INFO - 2016-12-12 04:35:12 --> Router Class Initialized
INFO - 2016-12-12 04:35:12 --> Output Class Initialized
INFO - 2016-12-12 04:35:12 --> Security Class Initialized
DEBUG - 2016-12-12 04:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:35:12 --> Input Class Initialized
INFO - 2016-12-12 04:35:12 --> Language Class Initialized
INFO - 2016-12-12 04:35:12 --> Loader Class Initialized
INFO - 2016-12-12 04:35:12 --> Database Driver Class Initialized
INFO - 2016-12-12 04:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:35:12 --> Controller Class Initialized
INFO - 2016-12-12 04:35:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:35:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:35:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:35:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:35:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:35:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:35:12 --> Final output sent to browser
DEBUG - 2016-12-12 04:35:12 --> Total execution time: 0.0134
INFO - 2016-12-12 04:35:12 --> Config Class Initialized
INFO - 2016-12-12 04:35:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:35:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:35:12 --> Utf8 Class Initialized
INFO - 2016-12-12 04:35:12 --> URI Class Initialized
INFO - 2016-12-12 04:35:12 --> Router Class Initialized
INFO - 2016-12-12 04:35:12 --> Output Class Initialized
INFO - 2016-12-12 04:35:12 --> Security Class Initialized
DEBUG - 2016-12-12 04:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:35:12 --> Input Class Initialized
INFO - 2016-12-12 04:35:12 --> Language Class Initialized
ERROR - 2016-12-12 04:35:12 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:35:13 --> Config Class Initialized
INFO - 2016-12-12 04:35:13 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:35:13 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:35:13 --> Utf8 Class Initialized
INFO - 2016-12-12 04:35:13 --> URI Class Initialized
INFO - 2016-12-12 04:35:13 --> Router Class Initialized
INFO - 2016-12-12 04:35:13 --> Output Class Initialized
INFO - 2016-12-12 04:35:13 --> Security Class Initialized
DEBUG - 2016-12-12 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:35:13 --> Input Class Initialized
INFO - 2016-12-12 04:35:13 --> Language Class Initialized
INFO - 2016-12-12 04:35:13 --> Loader Class Initialized
INFO - 2016-12-12 04:35:13 --> Database Driver Class Initialized
INFO - 2016-12-12 04:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:35:13 --> Controller Class Initialized
INFO - 2016-12-12 04:35:13 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:35:13 --> Final output sent to browser
DEBUG - 2016-12-12 04:35:13 --> Total execution time: 0.0136
INFO - 2016-12-12 04:35:51 --> Config Class Initialized
INFO - 2016-12-12 04:35:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:35:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:35:51 --> Utf8 Class Initialized
INFO - 2016-12-12 04:35:51 --> URI Class Initialized
DEBUG - 2016-12-12 04:35:51 --> No URI present. Default controller set.
INFO - 2016-12-12 04:35:51 --> Router Class Initialized
INFO - 2016-12-12 04:35:51 --> Output Class Initialized
INFO - 2016-12-12 04:35:51 --> Security Class Initialized
DEBUG - 2016-12-12 04:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:35:51 --> Input Class Initialized
INFO - 2016-12-12 04:35:51 --> Language Class Initialized
INFO - 2016-12-12 04:35:51 --> Loader Class Initialized
INFO - 2016-12-12 04:35:51 --> Database Driver Class Initialized
INFO - 2016-12-12 04:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:35:51 --> Controller Class Initialized
INFO - 2016-12-12 04:35:51 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:35:51 --> Final output sent to browser
DEBUG - 2016-12-12 04:35:51 --> Total execution time: 0.0134
INFO - 2016-12-12 04:35:52 --> Config Class Initialized
INFO - 2016-12-12 04:35:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:35:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:35:52 --> Utf8 Class Initialized
INFO - 2016-12-12 04:35:52 --> URI Class Initialized
INFO - 2016-12-12 04:35:52 --> Router Class Initialized
INFO - 2016-12-12 04:35:52 --> Output Class Initialized
INFO - 2016-12-12 04:35:52 --> Security Class Initialized
DEBUG - 2016-12-12 04:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:35:52 --> Input Class Initialized
INFO - 2016-12-12 04:35:52 --> Language Class Initialized
ERROR - 2016-12-12 04:35:52 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:35:52 --> Config Class Initialized
INFO - 2016-12-12 04:35:52 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:35:52 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:35:52 --> Utf8 Class Initialized
INFO - 2016-12-12 04:35:52 --> URI Class Initialized
INFO - 2016-12-12 04:35:52 --> Router Class Initialized
INFO - 2016-12-12 04:35:52 --> Output Class Initialized
INFO - 2016-12-12 04:35:52 --> Security Class Initialized
DEBUG - 2016-12-12 04:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:35:52 --> Input Class Initialized
INFO - 2016-12-12 04:35:52 --> Language Class Initialized
INFO - 2016-12-12 04:35:52 --> Loader Class Initialized
INFO - 2016-12-12 04:35:52 --> Database Driver Class Initialized
INFO - 2016-12-12 04:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:35:52 --> Controller Class Initialized
INFO - 2016-12-12 04:35:52 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:35:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:35:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:35:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:35:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:35:52 --> Final output sent to browser
DEBUG - 2016-12-12 04:35:52 --> Total execution time: 0.0135
INFO - 2016-12-12 04:36:06 --> Config Class Initialized
INFO - 2016-12-12 04:36:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:36:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:36:06 --> Utf8 Class Initialized
INFO - 2016-12-12 04:36:06 --> URI Class Initialized
DEBUG - 2016-12-12 04:36:06 --> No URI present. Default controller set.
INFO - 2016-12-12 04:36:06 --> Router Class Initialized
INFO - 2016-12-12 04:36:06 --> Output Class Initialized
INFO - 2016-12-12 04:36:06 --> Security Class Initialized
DEBUG - 2016-12-12 04:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:36:06 --> Input Class Initialized
INFO - 2016-12-12 04:36:06 --> Language Class Initialized
INFO - 2016-12-12 04:36:06 --> Loader Class Initialized
INFO - 2016-12-12 04:36:07 --> Database Driver Class Initialized
INFO - 2016-12-12 04:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:36:07 --> Controller Class Initialized
INFO - 2016-12-12 04:36:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:36:07 --> Final output sent to browser
DEBUG - 2016-12-12 04:36:07 --> Total execution time: 0.0128
INFO - 2016-12-12 04:36:07 --> Config Class Initialized
INFO - 2016-12-12 04:36:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:36:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:36:07 --> Utf8 Class Initialized
INFO - 2016-12-12 04:36:07 --> URI Class Initialized
INFO - 2016-12-12 04:36:07 --> Router Class Initialized
INFO - 2016-12-12 04:36:07 --> Output Class Initialized
INFO - 2016-12-12 04:36:07 --> Security Class Initialized
DEBUG - 2016-12-12 04:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:36:07 --> Input Class Initialized
INFO - 2016-12-12 04:36:07 --> Language Class Initialized
ERROR - 2016-12-12 04:36:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:36:07 --> Config Class Initialized
INFO - 2016-12-12 04:36:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:36:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:36:07 --> Utf8 Class Initialized
INFO - 2016-12-12 04:36:07 --> URI Class Initialized
INFO - 2016-12-12 04:36:07 --> Router Class Initialized
INFO - 2016-12-12 04:36:07 --> Output Class Initialized
INFO - 2016-12-12 04:36:07 --> Security Class Initialized
DEBUG - 2016-12-12 04:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:36:07 --> Input Class Initialized
INFO - 2016-12-12 04:36:07 --> Language Class Initialized
INFO - 2016-12-12 04:36:07 --> Loader Class Initialized
INFO - 2016-12-12 04:36:07 --> Database Driver Class Initialized
INFO - 2016-12-12 04:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:36:07 --> Controller Class Initialized
INFO - 2016-12-12 04:36:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:36:07 --> Final output sent to browser
DEBUG - 2016-12-12 04:36:07 --> Total execution time: 0.0134
INFO - 2016-12-12 04:37:00 --> Config Class Initialized
INFO - 2016-12-12 04:37:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:37:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:37:00 --> Utf8 Class Initialized
INFO - 2016-12-12 04:37:00 --> URI Class Initialized
DEBUG - 2016-12-12 04:37:00 --> No URI present. Default controller set.
INFO - 2016-12-12 04:37:00 --> Router Class Initialized
INFO - 2016-12-12 04:37:00 --> Output Class Initialized
INFO - 2016-12-12 04:37:00 --> Security Class Initialized
DEBUG - 2016-12-12 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:37:00 --> Input Class Initialized
INFO - 2016-12-12 04:37:00 --> Language Class Initialized
INFO - 2016-12-12 04:37:00 --> Loader Class Initialized
INFO - 2016-12-12 04:37:00 --> Database Driver Class Initialized
INFO - 2016-12-12 04:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:37:00 --> Controller Class Initialized
INFO - 2016-12-12 04:37:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:37:00 --> Final output sent to browser
DEBUG - 2016-12-12 04:37:00 --> Total execution time: 0.0136
INFO - 2016-12-12 04:37:00 --> Config Class Initialized
INFO - 2016-12-12 04:37:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:37:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:37:00 --> Utf8 Class Initialized
INFO - 2016-12-12 04:37:00 --> URI Class Initialized
INFO - 2016-12-12 04:37:00 --> Router Class Initialized
INFO - 2016-12-12 04:37:00 --> Output Class Initialized
INFO - 2016-12-12 04:37:00 --> Security Class Initialized
DEBUG - 2016-12-12 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:37:00 --> Input Class Initialized
INFO - 2016-12-12 04:37:00 --> Language Class Initialized
ERROR - 2016-12-12 04:37:00 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:37:01 --> Config Class Initialized
INFO - 2016-12-12 04:37:01 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:37:01 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:37:01 --> Utf8 Class Initialized
INFO - 2016-12-12 04:37:01 --> URI Class Initialized
INFO - 2016-12-12 04:37:01 --> Router Class Initialized
INFO - 2016-12-12 04:37:01 --> Output Class Initialized
INFO - 2016-12-12 04:37:01 --> Security Class Initialized
DEBUG - 2016-12-12 04:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:37:01 --> Input Class Initialized
INFO - 2016-12-12 04:37:01 --> Language Class Initialized
INFO - 2016-12-12 04:37:01 --> Loader Class Initialized
INFO - 2016-12-12 04:37:01 --> Database Driver Class Initialized
INFO - 2016-12-12 04:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:37:01 --> Controller Class Initialized
INFO - 2016-12-12 04:37:01 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:37:01 --> Final output sent to browser
DEBUG - 2016-12-12 04:37:01 --> Total execution time: 0.0612
INFO - 2016-12-12 04:38:12 --> Config Class Initialized
INFO - 2016-12-12 04:38:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:38:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:38:12 --> Utf8 Class Initialized
INFO - 2016-12-12 04:38:12 --> URI Class Initialized
DEBUG - 2016-12-12 04:38:12 --> No URI present. Default controller set.
INFO - 2016-12-12 04:38:12 --> Router Class Initialized
INFO - 2016-12-12 04:38:12 --> Output Class Initialized
INFO - 2016-12-12 04:38:12 --> Security Class Initialized
DEBUG - 2016-12-12 04:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:38:12 --> Input Class Initialized
INFO - 2016-12-12 04:38:12 --> Language Class Initialized
INFO - 2016-12-12 04:38:12 --> Loader Class Initialized
INFO - 2016-12-12 04:38:12 --> Database Driver Class Initialized
INFO - 2016-12-12 04:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:38:12 --> Controller Class Initialized
INFO - 2016-12-12 04:38:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:38:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:38:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:38:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:38:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:38:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:38:12 --> Final output sent to browser
DEBUG - 2016-12-12 04:38:12 --> Total execution time: 0.0133
INFO - 2016-12-12 04:38:13 --> Config Class Initialized
INFO - 2016-12-12 04:38:13 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:38:13 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:38:13 --> Utf8 Class Initialized
INFO - 2016-12-12 04:38:13 --> URI Class Initialized
INFO - 2016-12-12 04:38:13 --> Router Class Initialized
INFO - 2016-12-12 04:38:13 --> Output Class Initialized
INFO - 2016-12-12 04:38:13 --> Security Class Initialized
DEBUG - 2016-12-12 04:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:38:13 --> Input Class Initialized
INFO - 2016-12-12 04:38:13 --> Language Class Initialized
ERROR - 2016-12-12 04:38:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:38:13 --> Config Class Initialized
INFO - 2016-12-12 04:38:13 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:38:13 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:38:13 --> Utf8 Class Initialized
INFO - 2016-12-12 04:38:13 --> URI Class Initialized
INFO - 2016-12-12 04:38:13 --> Router Class Initialized
INFO - 2016-12-12 04:38:13 --> Output Class Initialized
INFO - 2016-12-12 04:38:13 --> Security Class Initialized
DEBUG - 2016-12-12 04:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:38:13 --> Input Class Initialized
INFO - 2016-12-12 04:38:13 --> Language Class Initialized
INFO - 2016-12-12 04:38:13 --> Loader Class Initialized
INFO - 2016-12-12 04:38:13 --> Database Driver Class Initialized
INFO - 2016-12-12 04:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:38:13 --> Controller Class Initialized
INFO - 2016-12-12 04:38:13 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:38:13 --> Final output sent to browser
DEBUG - 2016-12-12 04:38:13 --> Total execution time: 0.0133
INFO - 2016-12-12 04:38:34 --> Config Class Initialized
INFO - 2016-12-12 04:38:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:38:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:38:34 --> Utf8 Class Initialized
INFO - 2016-12-12 04:38:34 --> URI Class Initialized
DEBUG - 2016-12-12 04:38:34 --> No URI present. Default controller set.
INFO - 2016-12-12 04:38:34 --> Router Class Initialized
INFO - 2016-12-12 04:38:34 --> Output Class Initialized
INFO - 2016-12-12 04:38:34 --> Security Class Initialized
DEBUG - 2016-12-12 04:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:38:34 --> Input Class Initialized
INFO - 2016-12-12 04:38:34 --> Language Class Initialized
INFO - 2016-12-12 04:38:34 --> Loader Class Initialized
INFO - 2016-12-12 04:38:34 --> Database Driver Class Initialized
INFO - 2016-12-12 04:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:38:34 --> Controller Class Initialized
INFO - 2016-12-12 04:38:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:38:34 --> Final output sent to browser
DEBUG - 2016-12-12 04:38:34 --> Total execution time: 0.0140
INFO - 2016-12-12 04:38:35 --> Config Class Initialized
INFO - 2016-12-12 04:38:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:38:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:38:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:38:35 --> URI Class Initialized
INFO - 2016-12-12 04:38:35 --> Router Class Initialized
INFO - 2016-12-12 04:38:35 --> Output Class Initialized
INFO - 2016-12-12 04:38:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:38:35 --> Input Class Initialized
INFO - 2016-12-12 04:38:35 --> Language Class Initialized
ERROR - 2016-12-12 04:38:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:38:35 --> Config Class Initialized
INFO - 2016-12-12 04:38:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:38:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:38:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:38:35 --> URI Class Initialized
INFO - 2016-12-12 04:38:35 --> Router Class Initialized
INFO - 2016-12-12 04:38:35 --> Output Class Initialized
INFO - 2016-12-12 04:38:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:38:35 --> Input Class Initialized
INFO - 2016-12-12 04:38:35 --> Language Class Initialized
INFO - 2016-12-12 04:38:35 --> Loader Class Initialized
INFO - 2016-12-12 04:38:35 --> Database Driver Class Initialized
INFO - 2016-12-12 04:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:38:35 --> Controller Class Initialized
INFO - 2016-12-12 04:38:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:38:35 --> Final output sent to browser
DEBUG - 2016-12-12 04:38:35 --> Total execution time: 0.0528
INFO - 2016-12-12 04:39:55 --> Config Class Initialized
INFO - 2016-12-12 04:39:55 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:39:55 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:39:55 --> Utf8 Class Initialized
INFO - 2016-12-12 04:39:55 --> URI Class Initialized
DEBUG - 2016-12-12 04:39:55 --> No URI present. Default controller set.
INFO - 2016-12-12 04:39:55 --> Router Class Initialized
INFO - 2016-12-12 04:39:55 --> Output Class Initialized
INFO - 2016-12-12 04:39:55 --> Security Class Initialized
DEBUG - 2016-12-12 04:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:39:55 --> Input Class Initialized
INFO - 2016-12-12 04:39:55 --> Language Class Initialized
INFO - 2016-12-12 04:39:55 --> Loader Class Initialized
INFO - 2016-12-12 04:39:55 --> Database Driver Class Initialized
INFO - 2016-12-12 04:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:39:55 --> Controller Class Initialized
INFO - 2016-12-12 04:39:55 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:39:55 --> Final output sent to browser
DEBUG - 2016-12-12 04:39:55 --> Total execution time: 0.0143
INFO - 2016-12-12 04:39:55 --> Config Class Initialized
INFO - 2016-12-12 04:39:55 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:39:55 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:39:55 --> Utf8 Class Initialized
INFO - 2016-12-12 04:39:55 --> URI Class Initialized
INFO - 2016-12-12 04:39:55 --> Router Class Initialized
INFO - 2016-12-12 04:39:55 --> Output Class Initialized
INFO - 2016-12-12 04:39:55 --> Security Class Initialized
DEBUG - 2016-12-12 04:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:39:55 --> Input Class Initialized
INFO - 2016-12-12 04:39:55 --> Language Class Initialized
ERROR - 2016-12-12 04:39:55 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:39:56 --> Config Class Initialized
INFO - 2016-12-12 04:39:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:39:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:39:56 --> Utf8 Class Initialized
INFO - 2016-12-12 04:39:56 --> URI Class Initialized
INFO - 2016-12-12 04:39:56 --> Router Class Initialized
INFO - 2016-12-12 04:39:56 --> Output Class Initialized
INFO - 2016-12-12 04:39:56 --> Security Class Initialized
DEBUG - 2016-12-12 04:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:39:56 --> Input Class Initialized
INFO - 2016-12-12 04:39:56 --> Language Class Initialized
INFO - 2016-12-12 04:39:56 --> Loader Class Initialized
INFO - 2016-12-12 04:39:56 --> Database Driver Class Initialized
INFO - 2016-12-12 04:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:39:56 --> Controller Class Initialized
INFO - 2016-12-12 04:39:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:39:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:39:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:39:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:39:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:39:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:39:56 --> Final output sent to browser
DEBUG - 2016-12-12 04:39:56 --> Total execution time: 0.0136
INFO - 2016-12-12 04:40:38 --> Config Class Initialized
INFO - 2016-12-12 04:40:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:40:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:40:38 --> Utf8 Class Initialized
INFO - 2016-12-12 04:40:38 --> URI Class Initialized
DEBUG - 2016-12-12 04:40:38 --> No URI present. Default controller set.
INFO - 2016-12-12 04:40:38 --> Router Class Initialized
INFO - 2016-12-12 04:40:38 --> Output Class Initialized
INFO - 2016-12-12 04:40:38 --> Security Class Initialized
DEBUG - 2016-12-12 04:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:40:38 --> Input Class Initialized
INFO - 2016-12-12 04:40:38 --> Language Class Initialized
INFO - 2016-12-12 04:40:38 --> Loader Class Initialized
INFO - 2016-12-12 04:40:38 --> Database Driver Class Initialized
INFO - 2016-12-12 04:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:40:38 --> Controller Class Initialized
INFO - 2016-12-12 04:40:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:40:38 --> Final output sent to browser
DEBUG - 2016-12-12 04:40:38 --> Total execution time: 0.0131
INFO - 2016-12-12 04:40:39 --> Config Class Initialized
INFO - 2016-12-12 04:40:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:40:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:40:39 --> Utf8 Class Initialized
INFO - 2016-12-12 04:40:39 --> URI Class Initialized
INFO - 2016-12-12 04:40:39 --> Router Class Initialized
INFO - 2016-12-12 04:40:39 --> Output Class Initialized
INFO - 2016-12-12 04:40:39 --> Security Class Initialized
DEBUG - 2016-12-12 04:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:40:39 --> Input Class Initialized
INFO - 2016-12-12 04:40:39 --> Language Class Initialized
ERROR - 2016-12-12 04:40:39 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:40:39 --> Config Class Initialized
INFO - 2016-12-12 04:40:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:40:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:40:39 --> Utf8 Class Initialized
INFO - 2016-12-12 04:40:39 --> URI Class Initialized
INFO - 2016-12-12 04:40:39 --> Router Class Initialized
INFO - 2016-12-12 04:40:39 --> Output Class Initialized
INFO - 2016-12-12 04:40:39 --> Security Class Initialized
DEBUG - 2016-12-12 04:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:40:39 --> Input Class Initialized
INFO - 2016-12-12 04:40:39 --> Language Class Initialized
INFO - 2016-12-12 04:40:39 --> Loader Class Initialized
INFO - 2016-12-12 04:40:39 --> Database Driver Class Initialized
INFO - 2016-12-12 04:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:40:39 --> Controller Class Initialized
INFO - 2016-12-12 04:40:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:40:39 --> Final output sent to browser
DEBUG - 2016-12-12 04:40:39 --> Total execution time: 0.0150
INFO - 2016-12-12 04:40:58 --> Config Class Initialized
INFO - 2016-12-12 04:40:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:40:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:40:58 --> Utf8 Class Initialized
INFO - 2016-12-12 04:40:58 --> URI Class Initialized
DEBUG - 2016-12-12 04:40:58 --> No URI present. Default controller set.
INFO - 2016-12-12 04:40:58 --> Router Class Initialized
INFO - 2016-12-12 04:40:58 --> Output Class Initialized
INFO - 2016-12-12 04:40:58 --> Security Class Initialized
DEBUG - 2016-12-12 04:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:40:58 --> Input Class Initialized
INFO - 2016-12-12 04:40:58 --> Language Class Initialized
INFO - 2016-12-12 04:40:58 --> Loader Class Initialized
INFO - 2016-12-12 04:40:58 --> Database Driver Class Initialized
INFO - 2016-12-12 04:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:40:58 --> Controller Class Initialized
INFO - 2016-12-12 04:40:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:40:58 --> Final output sent to browser
DEBUG - 2016-12-12 04:40:58 --> Total execution time: 0.0134
INFO - 2016-12-12 04:40:58 --> Config Class Initialized
INFO - 2016-12-12 04:40:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:40:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:40:58 --> Utf8 Class Initialized
INFO - 2016-12-12 04:40:58 --> URI Class Initialized
INFO - 2016-12-12 04:40:58 --> Router Class Initialized
INFO - 2016-12-12 04:40:58 --> Output Class Initialized
INFO - 2016-12-12 04:40:58 --> Security Class Initialized
DEBUG - 2016-12-12 04:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:40:58 --> Input Class Initialized
INFO - 2016-12-12 04:40:58 --> Language Class Initialized
ERROR - 2016-12-12 04:40:58 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:40:59 --> Config Class Initialized
INFO - 2016-12-12 04:40:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:40:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:40:59 --> Utf8 Class Initialized
INFO - 2016-12-12 04:40:59 --> URI Class Initialized
INFO - 2016-12-12 04:40:59 --> Router Class Initialized
INFO - 2016-12-12 04:40:59 --> Output Class Initialized
INFO - 2016-12-12 04:40:59 --> Security Class Initialized
DEBUG - 2016-12-12 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:40:59 --> Input Class Initialized
INFO - 2016-12-12 04:40:59 --> Language Class Initialized
INFO - 2016-12-12 04:40:59 --> Loader Class Initialized
INFO - 2016-12-12 04:40:59 --> Database Driver Class Initialized
INFO - 2016-12-12 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:40:59 --> Controller Class Initialized
INFO - 2016-12-12 04:40:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:40:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:40:59 --> Final output sent to browser
DEBUG - 2016-12-12 04:40:59 --> Total execution time: 0.0137
INFO - 2016-12-12 04:51:06 --> Config Class Initialized
INFO - 2016-12-12 04:51:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:51:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:51:07 --> Utf8 Class Initialized
INFO - 2016-12-12 04:51:07 --> URI Class Initialized
DEBUG - 2016-12-12 04:51:07 --> No URI present. Default controller set.
INFO - 2016-12-12 04:51:07 --> Router Class Initialized
INFO - 2016-12-12 04:51:07 --> Output Class Initialized
INFO - 2016-12-12 04:51:07 --> Security Class Initialized
DEBUG - 2016-12-12 04:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:51:07 --> Input Class Initialized
INFO - 2016-12-12 04:51:07 --> Language Class Initialized
INFO - 2016-12-12 04:51:07 --> Loader Class Initialized
INFO - 2016-12-12 04:51:07 --> Database Driver Class Initialized
INFO - 2016-12-12 04:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:51:07 --> Controller Class Initialized
INFO - 2016-12-12 04:51:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:51:07 --> Final output sent to browser
DEBUG - 2016-12-12 04:51:07 --> Total execution time: 1.0840
INFO - 2016-12-12 04:51:08 --> Config Class Initialized
INFO - 2016-12-12 04:51:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:51:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:51:08 --> Utf8 Class Initialized
INFO - 2016-12-12 04:51:08 --> URI Class Initialized
INFO - 2016-12-12 04:51:08 --> Router Class Initialized
INFO - 2016-12-12 04:51:08 --> Output Class Initialized
INFO - 2016-12-12 04:51:08 --> Security Class Initialized
DEBUG - 2016-12-12 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:51:08 --> Input Class Initialized
INFO - 2016-12-12 04:51:08 --> Language Class Initialized
ERROR - 2016-12-12 04:51:08 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:51:08 --> Config Class Initialized
INFO - 2016-12-12 04:51:08 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:51:08 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:51:08 --> Utf8 Class Initialized
INFO - 2016-12-12 04:51:08 --> URI Class Initialized
INFO - 2016-12-12 04:51:08 --> Router Class Initialized
INFO - 2016-12-12 04:51:08 --> Output Class Initialized
INFO - 2016-12-12 04:51:08 --> Security Class Initialized
DEBUG - 2016-12-12 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:51:08 --> Input Class Initialized
INFO - 2016-12-12 04:51:08 --> Language Class Initialized
INFO - 2016-12-12 04:51:08 --> Loader Class Initialized
INFO - 2016-12-12 04:51:08 --> Database Driver Class Initialized
INFO - 2016-12-12 04:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:51:08 --> Controller Class Initialized
INFO - 2016-12-12 04:51:08 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:51:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:51:08 --> Final output sent to browser
DEBUG - 2016-12-12 04:51:08 --> Total execution time: 0.0134
INFO - 2016-12-12 04:51:50 --> Config Class Initialized
INFO - 2016-12-12 04:51:50 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:51:50 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:51:50 --> Utf8 Class Initialized
INFO - 2016-12-12 04:51:50 --> URI Class Initialized
DEBUG - 2016-12-12 04:51:50 --> No URI present. Default controller set.
INFO - 2016-12-12 04:51:50 --> Router Class Initialized
INFO - 2016-12-12 04:51:50 --> Output Class Initialized
INFO - 2016-12-12 04:51:50 --> Security Class Initialized
DEBUG - 2016-12-12 04:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:51:50 --> Input Class Initialized
INFO - 2016-12-12 04:51:50 --> Language Class Initialized
INFO - 2016-12-12 04:51:50 --> Loader Class Initialized
INFO - 2016-12-12 04:51:50 --> Database Driver Class Initialized
INFO - 2016-12-12 04:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:51:50 --> Controller Class Initialized
INFO - 2016-12-12 04:51:50 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:51:50 --> Final output sent to browser
DEBUG - 2016-12-12 04:51:50 --> Total execution time: 0.0125
INFO - 2016-12-12 04:51:51 --> Config Class Initialized
INFO - 2016-12-12 04:51:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:51:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:51:51 --> Utf8 Class Initialized
INFO - 2016-12-12 04:51:51 --> URI Class Initialized
INFO - 2016-12-12 04:51:51 --> Router Class Initialized
INFO - 2016-12-12 04:51:51 --> Output Class Initialized
INFO - 2016-12-12 04:51:51 --> Security Class Initialized
DEBUG - 2016-12-12 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:51:51 --> Input Class Initialized
INFO - 2016-12-12 04:51:51 --> Language Class Initialized
ERROR - 2016-12-12 04:51:51 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:51:51 --> Config Class Initialized
INFO - 2016-12-12 04:51:51 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:51:51 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:51:51 --> Utf8 Class Initialized
INFO - 2016-12-12 04:51:51 --> URI Class Initialized
INFO - 2016-12-12 04:51:51 --> Router Class Initialized
INFO - 2016-12-12 04:51:51 --> Output Class Initialized
INFO - 2016-12-12 04:51:51 --> Security Class Initialized
DEBUG - 2016-12-12 04:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:51:51 --> Input Class Initialized
INFO - 2016-12-12 04:51:51 --> Language Class Initialized
INFO - 2016-12-12 04:51:51 --> Loader Class Initialized
INFO - 2016-12-12 04:51:51 --> Database Driver Class Initialized
INFO - 2016-12-12 04:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:51:51 --> Controller Class Initialized
INFO - 2016-12-12 04:51:51 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:51:51 --> Final output sent to browser
DEBUG - 2016-12-12 04:51:51 --> Total execution time: 0.0142
INFO - 2016-12-12 04:52:15 --> Config Class Initialized
INFO - 2016-12-12 04:52:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:15 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:15 --> URI Class Initialized
DEBUG - 2016-12-12 04:52:15 --> No URI present. Default controller set.
INFO - 2016-12-12 04:52:15 --> Router Class Initialized
INFO - 2016-12-12 04:52:15 --> Output Class Initialized
INFO - 2016-12-12 04:52:15 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:15 --> Input Class Initialized
INFO - 2016-12-12 04:52:15 --> Language Class Initialized
INFO - 2016-12-12 04:52:15 --> Loader Class Initialized
INFO - 2016-12-12 04:52:15 --> Database Driver Class Initialized
INFO - 2016-12-12 04:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:52:15 --> Controller Class Initialized
INFO - 2016-12-12 04:52:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:52:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:52:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:52:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:52:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:52:15 --> Final output sent to browser
DEBUG - 2016-12-12 04:52:15 --> Total execution time: 0.0132
INFO - 2016-12-12 04:52:16 --> Config Class Initialized
INFO - 2016-12-12 04:52:16 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:16 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:16 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:16 --> URI Class Initialized
INFO - 2016-12-12 04:52:16 --> Router Class Initialized
INFO - 2016-12-12 04:52:16 --> Output Class Initialized
INFO - 2016-12-12 04:52:16 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:16 --> Input Class Initialized
INFO - 2016-12-12 04:52:16 --> Language Class Initialized
ERROR - 2016-12-12 04:52:16 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:52:16 --> Config Class Initialized
INFO - 2016-12-12 04:52:16 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:16 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:16 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:16 --> URI Class Initialized
INFO - 2016-12-12 04:52:16 --> Router Class Initialized
INFO - 2016-12-12 04:52:16 --> Output Class Initialized
INFO - 2016-12-12 04:52:16 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:16 --> Input Class Initialized
INFO - 2016-12-12 04:52:16 --> Language Class Initialized
INFO - 2016-12-12 04:52:16 --> Loader Class Initialized
INFO - 2016-12-12 04:52:16 --> Database Driver Class Initialized
INFO - 2016-12-12 04:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:52:16 --> Controller Class Initialized
INFO - 2016-12-12 04:52:16 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:52:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:52:16 --> Final output sent to browser
DEBUG - 2016-12-12 04:52:16 --> Total execution time: 0.0142
INFO - 2016-12-12 04:52:36 --> Config Class Initialized
INFO - 2016-12-12 04:52:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:36 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:36 --> URI Class Initialized
DEBUG - 2016-12-12 04:52:36 --> No URI present. Default controller set.
INFO - 2016-12-12 04:52:36 --> Router Class Initialized
INFO - 2016-12-12 04:52:36 --> Output Class Initialized
INFO - 2016-12-12 04:52:36 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:36 --> Input Class Initialized
INFO - 2016-12-12 04:52:36 --> Language Class Initialized
INFO - 2016-12-12 04:52:36 --> Loader Class Initialized
INFO - 2016-12-12 04:52:36 --> Database Driver Class Initialized
INFO - 2016-12-12 04:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:52:36 --> Controller Class Initialized
INFO - 2016-12-12 04:52:36 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:52:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:52:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:52:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:52:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:52:36 --> Final output sent to browser
DEBUG - 2016-12-12 04:52:36 --> Total execution time: 0.0187
INFO - 2016-12-12 04:52:36 --> Config Class Initialized
INFO - 2016-12-12 04:52:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:36 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:36 --> URI Class Initialized
INFO - 2016-12-12 04:52:36 --> Router Class Initialized
INFO - 2016-12-12 04:52:36 --> Output Class Initialized
INFO - 2016-12-12 04:52:36 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:36 --> Input Class Initialized
INFO - 2016-12-12 04:52:36 --> Language Class Initialized
ERROR - 2016-12-12 04:52:36 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:52:37 --> Config Class Initialized
INFO - 2016-12-12 04:52:37 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:37 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:37 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:37 --> URI Class Initialized
INFO - 2016-12-12 04:52:37 --> Router Class Initialized
INFO - 2016-12-12 04:52:37 --> Output Class Initialized
INFO - 2016-12-12 04:52:37 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:37 --> Input Class Initialized
INFO - 2016-12-12 04:52:37 --> Language Class Initialized
INFO - 2016-12-12 04:52:37 --> Loader Class Initialized
INFO - 2016-12-12 04:52:37 --> Database Driver Class Initialized
INFO - 2016-12-12 04:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:52:37 --> Controller Class Initialized
INFO - 2016-12-12 04:52:37 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:52:37 --> Final output sent to browser
DEBUG - 2016-12-12 04:52:37 --> Total execution time: 0.0135
INFO - 2016-12-12 04:52:49 --> Config Class Initialized
INFO - 2016-12-12 04:52:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:49 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:49 --> URI Class Initialized
DEBUG - 2016-12-12 04:52:49 --> No URI present. Default controller set.
INFO - 2016-12-12 04:52:49 --> Router Class Initialized
INFO - 2016-12-12 04:52:49 --> Output Class Initialized
INFO - 2016-12-12 04:52:49 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:49 --> Input Class Initialized
INFO - 2016-12-12 04:52:49 --> Language Class Initialized
INFO - 2016-12-12 04:52:49 --> Loader Class Initialized
INFO - 2016-12-12 04:52:49 --> Database Driver Class Initialized
INFO - 2016-12-12 04:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:52:49 --> Controller Class Initialized
INFO - 2016-12-12 04:52:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:52:49 --> Final output sent to browser
DEBUG - 2016-12-12 04:52:49 --> Total execution time: 0.0138
INFO - 2016-12-12 04:52:49 --> Config Class Initialized
INFO - 2016-12-12 04:52:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:49 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:49 --> URI Class Initialized
INFO - 2016-12-12 04:52:49 --> Router Class Initialized
INFO - 2016-12-12 04:52:49 --> Output Class Initialized
INFO - 2016-12-12 04:52:49 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:49 --> Input Class Initialized
INFO - 2016-12-12 04:52:49 --> Language Class Initialized
ERROR - 2016-12-12 04:52:49 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:52:49 --> Config Class Initialized
INFO - 2016-12-12 04:52:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:52:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:52:49 --> Utf8 Class Initialized
INFO - 2016-12-12 04:52:49 --> URI Class Initialized
INFO - 2016-12-12 04:52:49 --> Router Class Initialized
INFO - 2016-12-12 04:52:49 --> Output Class Initialized
INFO - 2016-12-12 04:52:49 --> Security Class Initialized
DEBUG - 2016-12-12 04:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:52:49 --> Input Class Initialized
INFO - 2016-12-12 04:52:49 --> Language Class Initialized
INFO - 2016-12-12 04:52:49 --> Loader Class Initialized
INFO - 2016-12-12 04:52:49 --> Database Driver Class Initialized
INFO - 2016-12-12 04:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:52:49 --> Controller Class Initialized
INFO - 2016-12-12 04:52:49 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:52:49 --> Final output sent to browser
DEBUG - 2016-12-12 04:52:49 --> Total execution time: 0.0137
INFO - 2016-12-12 04:53:34 --> Config Class Initialized
INFO - 2016-12-12 04:53:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:53:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:53:34 --> Utf8 Class Initialized
INFO - 2016-12-12 04:53:34 --> URI Class Initialized
DEBUG - 2016-12-12 04:53:34 --> No URI present. Default controller set.
INFO - 2016-12-12 04:53:34 --> Router Class Initialized
INFO - 2016-12-12 04:53:34 --> Output Class Initialized
INFO - 2016-12-12 04:53:34 --> Security Class Initialized
DEBUG - 2016-12-12 04:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:53:34 --> Input Class Initialized
INFO - 2016-12-12 04:53:34 --> Language Class Initialized
INFO - 2016-12-12 04:53:34 --> Loader Class Initialized
INFO - 2016-12-12 04:53:34 --> Database Driver Class Initialized
INFO - 2016-12-12 04:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:53:34 --> Controller Class Initialized
INFO - 2016-12-12 04:53:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:53:34 --> Final output sent to browser
DEBUG - 2016-12-12 04:53:34 --> Total execution time: 0.0132
INFO - 2016-12-12 04:53:35 --> Config Class Initialized
INFO - 2016-12-12 04:53:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:53:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:53:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:53:35 --> URI Class Initialized
INFO - 2016-12-12 04:53:35 --> Router Class Initialized
INFO - 2016-12-12 04:53:35 --> Output Class Initialized
INFO - 2016-12-12 04:53:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:53:35 --> Input Class Initialized
INFO - 2016-12-12 04:53:35 --> Language Class Initialized
ERROR - 2016-12-12 04:53:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-12 04:53:35 --> Config Class Initialized
INFO - 2016-12-12 04:53:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:53:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:53:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:53:35 --> URI Class Initialized
INFO - 2016-12-12 04:53:35 --> Router Class Initialized
INFO - 2016-12-12 04:53:35 --> Output Class Initialized
INFO - 2016-12-12 04:53:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:53:35 --> Input Class Initialized
INFO - 2016-12-12 04:53:35 --> Language Class Initialized
INFO - 2016-12-12 04:53:35 --> Loader Class Initialized
INFO - 2016-12-12 04:53:35 --> Database Driver Class Initialized
INFO - 2016-12-12 04:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:53:35 --> Controller Class Initialized
INFO - 2016-12-12 04:53:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:53:35 --> Final output sent to browser
DEBUG - 2016-12-12 04:53:35 --> Total execution time: 0.0136
INFO - 2016-12-12 04:55:30 --> Config Class Initialized
INFO - 2016-12-12 04:55:30 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:30 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:30 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:30 --> URI Class Initialized
INFO - 2016-12-12 04:55:30 --> Router Class Initialized
INFO - 2016-12-12 04:55:30 --> Output Class Initialized
INFO - 2016-12-12 04:55:30 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:30 --> Input Class Initialized
INFO - 2016-12-12 04:55:30 --> Language Class Initialized
INFO - 2016-12-12 04:55:30 --> Loader Class Initialized
INFO - 2016-12-12 04:55:30 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:30 --> Controller Class Initialized
INFO - 2016-12-12 04:55:30 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:31 --> Config Class Initialized
INFO - 2016-12-12 04:55:31 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:31 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:31 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:31 --> URI Class Initialized
INFO - 2016-12-12 04:55:31 --> Router Class Initialized
INFO - 2016-12-12 04:55:31 --> Output Class Initialized
INFO - 2016-12-12 04:55:31 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:31 --> Input Class Initialized
INFO - 2016-12-12 04:55:31 --> Language Class Initialized
INFO - 2016-12-12 04:55:31 --> Loader Class Initialized
INFO - 2016-12-12 04:55:31 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:31 --> Controller Class Initialized
DEBUG - 2016-12-12 04:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:31 --> Helper loaded: url_helper
INFO - 2016-12-12 04:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-12 04:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-12 04:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:31 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:31 --> Total execution time: 0.0756
INFO - 2016-12-12 04:55:32 --> Config Class Initialized
INFO - 2016-12-12 04:55:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:32 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:32 --> URI Class Initialized
INFO - 2016-12-12 04:55:32 --> Router Class Initialized
INFO - 2016-12-12 04:55:32 --> Output Class Initialized
INFO - 2016-12-12 04:55:32 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:32 --> Input Class Initialized
INFO - 2016-12-12 04:55:32 --> Language Class Initialized
INFO - 2016-12-12 04:55:32 --> Loader Class Initialized
INFO - 2016-12-12 04:55:32 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:32 --> Controller Class Initialized
INFO - 2016-12-12 04:55:32 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:55:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:55:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:55:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:32 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:32 --> Total execution time: 0.0134
INFO - 2016-12-12 04:55:34 --> Config Class Initialized
INFO - 2016-12-12 04:55:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:34 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:34 --> URI Class Initialized
INFO - 2016-12-12 04:55:34 --> Router Class Initialized
INFO - 2016-12-12 04:55:34 --> Output Class Initialized
INFO - 2016-12-12 04:55:34 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:34 --> Input Class Initialized
INFO - 2016-12-12 04:55:34 --> Language Class Initialized
INFO - 2016-12-12 04:55:34 --> Loader Class Initialized
INFO - 2016-12-12 04:55:34 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:34 --> Controller Class Initialized
INFO - 2016-12-12 04:55:34 --> Helper loaded: date_helper
DEBUG - 2016-12-12 04:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:34 --> Helper loaded: url_helper
INFO - 2016-12-12 04:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-12 04:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-12 04:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:34 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:34 --> Total execution time: 0.1180
INFO - 2016-12-12 04:55:35 --> Config Class Initialized
INFO - 2016-12-12 04:55:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:35 --> URI Class Initialized
INFO - 2016-12-12 04:55:35 --> Router Class Initialized
INFO - 2016-12-12 04:55:35 --> Output Class Initialized
INFO - 2016-12-12 04:55:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:35 --> Input Class Initialized
INFO - 2016-12-12 04:55:35 --> Language Class Initialized
INFO - 2016-12-12 04:55:35 --> Loader Class Initialized
INFO - 2016-12-12 04:55:35 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:35 --> Controller Class Initialized
INFO - 2016-12-12 04:55:35 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:35 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:35 --> Total execution time: 0.0134
INFO - 2016-12-12 04:55:36 --> Config Class Initialized
INFO - 2016-12-12 04:55:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:36 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:36 --> URI Class Initialized
INFO - 2016-12-12 04:55:36 --> Router Class Initialized
INFO - 2016-12-12 04:55:36 --> Output Class Initialized
INFO - 2016-12-12 04:55:36 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:36 --> Input Class Initialized
INFO - 2016-12-12 04:55:36 --> Language Class Initialized
INFO - 2016-12-12 04:55:36 --> Loader Class Initialized
INFO - 2016-12-12 04:55:36 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:36 --> Controller Class Initialized
DEBUG - 2016-12-12 04:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:36 --> Helper loaded: url_helper
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:36 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:36 --> Total execution time: 0.0132
INFO - 2016-12-12 04:55:36 --> Config Class Initialized
INFO - 2016-12-12 04:55:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:36 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:36 --> URI Class Initialized
INFO - 2016-12-12 04:55:36 --> Router Class Initialized
INFO - 2016-12-12 04:55:36 --> Output Class Initialized
INFO - 2016-12-12 04:55:36 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:36 --> Input Class Initialized
INFO - 2016-12-12 04:55:36 --> Language Class Initialized
INFO - 2016-12-12 04:55:36 --> Loader Class Initialized
INFO - 2016-12-12 04:55:36 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:36 --> Controller Class Initialized
INFO - 2016-12-12 04:55:36 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:36 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:36 --> Total execution time: 0.0136
INFO - 2016-12-12 04:55:43 --> Config Class Initialized
INFO - 2016-12-12 04:55:43 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:43 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:43 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:43 --> URI Class Initialized
INFO - 2016-12-12 04:55:43 --> Router Class Initialized
INFO - 2016-12-12 04:55:43 --> Output Class Initialized
INFO - 2016-12-12 04:55:43 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:43 --> Input Class Initialized
INFO - 2016-12-12 04:55:43 --> Language Class Initialized
INFO - 2016-12-12 04:55:43 --> Loader Class Initialized
INFO - 2016-12-12 04:55:43 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:43 --> Controller Class Initialized
INFO - 2016-12-12 04:55:43 --> Helper loaded: date_helper
DEBUG - 2016-12-12 04:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:43 --> Helper loaded: url_helper
INFO - 2016-12-12 04:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-12 04:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-12 04:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:43 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:43 --> Total execution time: 0.0175
INFO - 2016-12-12 04:55:44 --> Config Class Initialized
INFO - 2016-12-12 04:55:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:44 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:44 --> URI Class Initialized
INFO - 2016-12-12 04:55:44 --> Router Class Initialized
INFO - 2016-12-12 04:55:44 --> Output Class Initialized
INFO - 2016-12-12 04:55:44 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:44 --> Input Class Initialized
INFO - 2016-12-12 04:55:44 --> Language Class Initialized
INFO - 2016-12-12 04:55:44 --> Loader Class Initialized
INFO - 2016-12-12 04:55:44 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:44 --> Controller Class Initialized
INFO - 2016-12-12 04:55:44 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:55:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:55:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:55:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:55:44 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:44 --> Total execution time: 0.0133
INFO - 2016-12-12 04:55:58 --> Config Class Initialized
INFO - 2016-12-12 04:55:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:55:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:55:58 --> Utf8 Class Initialized
INFO - 2016-12-12 04:55:58 --> URI Class Initialized
INFO - 2016-12-12 04:55:58 --> Router Class Initialized
INFO - 2016-12-12 04:55:58 --> Output Class Initialized
INFO - 2016-12-12 04:55:58 --> Security Class Initialized
DEBUG - 2016-12-12 04:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:55:58 --> Input Class Initialized
INFO - 2016-12-12 04:55:58 --> Language Class Initialized
INFO - 2016-12-12 04:55:58 --> Loader Class Initialized
INFO - 2016-12-12 04:55:58 --> Database Driver Class Initialized
INFO - 2016-12-12 04:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:55:58 --> Controller Class Initialized
INFO - 2016-12-12 04:55:58 --> Helper loaded: date_helper
INFO - 2016-12-12 04:55:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:55:58 --> Helper loaded: form_helper
INFO - 2016-12-12 04:55:58 --> Form Validation Class Initialized
INFO - 2016-12-12 04:55:58 --> Final output sent to browser
DEBUG - 2016-12-12 04:55:58 --> Total execution time: 0.1503
INFO - 2016-12-12 04:56:27 --> Config Class Initialized
INFO - 2016-12-12 04:56:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:27 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:27 --> URI Class Initialized
INFO - 2016-12-12 04:56:27 --> Router Class Initialized
INFO - 2016-12-12 04:56:27 --> Output Class Initialized
INFO - 2016-12-12 04:56:27 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:27 --> Input Class Initialized
INFO - 2016-12-12 04:56:27 --> Language Class Initialized
INFO - 2016-12-12 04:56:27 --> Loader Class Initialized
INFO - 2016-12-12 04:56:27 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:27 --> Controller Class Initialized
DEBUG - 2016-12-12 04:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:27 --> Helper loaded: url_helper
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:27 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:27 --> Total execution time: 0.0646
INFO - 2016-12-12 04:56:27 --> Config Class Initialized
INFO - 2016-12-12 04:56:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:27 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:27 --> URI Class Initialized
INFO - 2016-12-12 04:56:27 --> Router Class Initialized
INFO - 2016-12-12 04:56:27 --> Output Class Initialized
INFO - 2016-12-12 04:56:27 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:27 --> Input Class Initialized
INFO - 2016-12-12 04:56:27 --> Language Class Initialized
INFO - 2016-12-12 04:56:27 --> Loader Class Initialized
INFO - 2016-12-12 04:56:27 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:27 --> Controller Class Initialized
INFO - 2016-12-12 04:56:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:27 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:27 --> Total execution time: 0.0139
INFO - 2016-12-12 04:56:32 --> Config Class Initialized
INFO - 2016-12-12 04:56:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:32 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:32 --> URI Class Initialized
INFO - 2016-12-12 04:56:32 --> Router Class Initialized
INFO - 2016-12-12 04:56:32 --> Output Class Initialized
INFO - 2016-12-12 04:56:32 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:32 --> Input Class Initialized
INFO - 2016-12-12 04:56:32 --> Language Class Initialized
INFO - 2016-12-12 04:56:32 --> Loader Class Initialized
INFO - 2016-12-12 04:56:32 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:32 --> Controller Class Initialized
INFO - 2016-12-12 04:56:32 --> Helper loaded: date_helper
DEBUG - 2016-12-12 04:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:32 --> Helper loaded: url_helper
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:32 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:32 --> Total execution time: 0.0170
INFO - 2016-12-12 04:56:32 --> Config Class Initialized
INFO - 2016-12-12 04:56:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:32 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:32 --> URI Class Initialized
INFO - 2016-12-12 04:56:32 --> Router Class Initialized
INFO - 2016-12-12 04:56:32 --> Output Class Initialized
INFO - 2016-12-12 04:56:32 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:32 --> Input Class Initialized
INFO - 2016-12-12 04:56:32 --> Language Class Initialized
INFO - 2016-12-12 04:56:32 --> Loader Class Initialized
INFO - 2016-12-12 04:56:32 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:32 --> Controller Class Initialized
INFO - 2016-12-12 04:56:32 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:32 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:32 --> Total execution time: 0.0133
INFO - 2016-12-12 04:56:33 --> Config Class Initialized
INFO - 2016-12-12 04:56:33 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:33 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:33 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:33 --> URI Class Initialized
INFO - 2016-12-12 04:56:33 --> Router Class Initialized
INFO - 2016-12-12 04:56:33 --> Output Class Initialized
INFO - 2016-12-12 04:56:33 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:33 --> Input Class Initialized
INFO - 2016-12-12 04:56:33 --> Language Class Initialized
INFO - 2016-12-12 04:56:33 --> Loader Class Initialized
INFO - 2016-12-12 04:56:33 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:33 --> Controller Class Initialized
DEBUG - 2016-12-12 04:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:33 --> Helper loaded: url_helper
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:33 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:33 --> Total execution time: 0.0133
INFO - 2016-12-12 04:56:33 --> Config Class Initialized
INFO - 2016-12-12 04:56:33 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:33 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:33 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:33 --> URI Class Initialized
INFO - 2016-12-12 04:56:33 --> Router Class Initialized
INFO - 2016-12-12 04:56:33 --> Output Class Initialized
INFO - 2016-12-12 04:56:33 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:33 --> Input Class Initialized
INFO - 2016-12-12 04:56:33 --> Language Class Initialized
INFO - 2016-12-12 04:56:33 --> Loader Class Initialized
INFO - 2016-12-12 04:56:33 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:33 --> Controller Class Initialized
INFO - 2016-12-12 04:56:33 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:33 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:33 --> Total execution time: 0.0137
INFO - 2016-12-12 04:56:35 --> Config Class Initialized
INFO - 2016-12-12 04:56:35 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:35 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:35 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:35 --> URI Class Initialized
INFO - 2016-12-12 04:56:35 --> Router Class Initialized
INFO - 2016-12-12 04:56:35 --> Output Class Initialized
INFO - 2016-12-12 04:56:35 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:35 --> Input Class Initialized
INFO - 2016-12-12 04:56:35 --> Language Class Initialized
INFO - 2016-12-12 04:56:35 --> Loader Class Initialized
INFO - 2016-12-12 04:56:35 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:35 --> Controller Class Initialized
DEBUG - 2016-12-12 04:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:35 --> Helper loaded: url_helper
INFO - 2016-12-12 04:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-12 04:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-12 04:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-12 04:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:35 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:35 --> Total execution time: 0.0123
INFO - 2016-12-12 04:56:36 --> Config Class Initialized
INFO - 2016-12-12 04:56:36 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:36 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:36 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:36 --> URI Class Initialized
INFO - 2016-12-12 04:56:36 --> Router Class Initialized
INFO - 2016-12-12 04:56:36 --> Output Class Initialized
INFO - 2016-12-12 04:56:36 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:36 --> Input Class Initialized
INFO - 2016-12-12 04:56:36 --> Language Class Initialized
INFO - 2016-12-12 04:56:36 --> Loader Class Initialized
INFO - 2016-12-12 04:56:36 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:36 --> Controller Class Initialized
INFO - 2016-12-12 04:56:36 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:36 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:36 --> Total execution time: 0.0135
INFO - 2016-12-12 04:56:38 --> Config Class Initialized
INFO - 2016-12-12 04:56:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:38 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:38 --> URI Class Initialized
INFO - 2016-12-12 04:56:38 --> Router Class Initialized
INFO - 2016-12-12 04:56:38 --> Output Class Initialized
INFO - 2016-12-12 04:56:38 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:38 --> Input Class Initialized
INFO - 2016-12-12 04:56:38 --> Language Class Initialized
INFO - 2016-12-12 04:56:38 --> Loader Class Initialized
INFO - 2016-12-12 04:56:38 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:38 --> Controller Class Initialized
INFO - 2016-12-12 04:56:38 --> Upload Class Initialized
DEBUG - 2016-12-12 04:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:38 --> Helper loaded: url_helper
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:38 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:38 --> Total execution time: 0.1157
INFO - 2016-12-12 04:56:38 --> Config Class Initialized
INFO - 2016-12-12 04:56:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:38 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:38 --> URI Class Initialized
INFO - 2016-12-12 04:56:38 --> Router Class Initialized
INFO - 2016-12-12 04:56:38 --> Output Class Initialized
INFO - 2016-12-12 04:56:38 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:38 --> Input Class Initialized
INFO - 2016-12-12 04:56:38 --> Language Class Initialized
INFO - 2016-12-12 04:56:38 --> Loader Class Initialized
INFO - 2016-12-12 04:56:38 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:38 --> Controller Class Initialized
INFO - 2016-12-12 04:56:38 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:38 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:38 --> Total execution time: 0.0132
INFO - 2016-12-12 04:56:47 --> Config Class Initialized
INFO - 2016-12-12 04:56:47 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:47 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:47 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:47 --> URI Class Initialized
INFO - 2016-12-12 04:56:47 --> Router Class Initialized
INFO - 2016-12-12 04:56:47 --> Output Class Initialized
INFO - 2016-12-12 04:56:47 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:47 --> Input Class Initialized
INFO - 2016-12-12 04:56:47 --> Language Class Initialized
INFO - 2016-12-12 04:56:47 --> Loader Class Initialized
INFO - 2016-12-12 04:56:47 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:47 --> Controller Class Initialized
INFO - 2016-12-12 04:56:47 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:47 --> Helper loaded: form_helper
INFO - 2016-12-12 04:56:47 --> Form Validation Class Initialized
INFO - 2016-12-12 04:56:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:56:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-12 04:56:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:56:47 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:47 --> Total execution time: 0.0571
INFO - 2016-12-12 04:56:47 --> Config Class Initialized
INFO - 2016-12-12 04:56:47 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:47 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:47 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:47 --> URI Class Initialized
INFO - 2016-12-12 04:56:47 --> Router Class Initialized
INFO - 2016-12-12 04:56:47 --> Output Class Initialized
INFO - 2016-12-12 04:56:47 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:47 --> Input Class Initialized
INFO - 2016-12-12 04:56:47 --> Language Class Initialized
INFO - 2016-12-12 04:56:47 --> Loader Class Initialized
INFO - 2016-12-12 04:56:47 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:47 --> Controller Class Initialized
INFO - 2016-12-12 04:56:47 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:47 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:47 --> Total execution time: 0.0133
INFO - 2016-12-12 04:56:56 --> Config Class Initialized
INFO - 2016-12-12 04:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:56 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:56 --> URI Class Initialized
INFO - 2016-12-12 04:56:56 --> Router Class Initialized
INFO - 2016-12-12 04:56:56 --> Output Class Initialized
INFO - 2016-12-12 04:56:56 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:56 --> Input Class Initialized
INFO - 2016-12-12 04:56:56 --> Language Class Initialized
INFO - 2016-12-12 04:56:56 --> Loader Class Initialized
INFO - 2016-12-12 04:56:56 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:56 --> Controller Class Initialized
INFO - 2016-12-12 04:56:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:56 --> Helper loaded: form_helper
INFO - 2016-12-12 04:56:56 --> Form Validation Class Initialized
INFO - 2016-12-12 04:56:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-12 04:56:56 --> Config Class Initialized
INFO - 2016-12-12 04:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:56 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:56 --> URI Class Initialized
INFO - 2016-12-12 04:56:56 --> Router Class Initialized
INFO - 2016-12-12 04:56:56 --> Output Class Initialized
INFO - 2016-12-12 04:56:56 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:56 --> Input Class Initialized
INFO - 2016-12-12 04:56:56 --> Language Class Initialized
INFO - 2016-12-12 04:56:56 --> Loader Class Initialized
INFO - 2016-12-12 04:56:56 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:56 --> Controller Class Initialized
INFO - 2016-12-12 04:56:56 --> Helper loaded: date_helper
INFO - 2016-12-12 04:56:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:56 --> Helper loaded: form_helper
INFO - 2016-12-12 04:56:56 --> Form Validation Class Initialized
INFO - 2016-12-12 04:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-12 04:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-12 04:56:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:56:56 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:56 --> Total execution time: 0.1131
INFO - 2016-12-12 04:56:56 --> Config Class Initialized
INFO - 2016-12-12 04:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:56 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:56 --> URI Class Initialized
INFO - 2016-12-12 04:56:56 --> Router Class Initialized
INFO - 2016-12-12 04:56:56 --> Output Class Initialized
INFO - 2016-12-12 04:56:56 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:56 --> Input Class Initialized
INFO - 2016-12-12 04:56:56 --> Language Class Initialized
INFO - 2016-12-12 04:56:56 --> Loader Class Initialized
INFO - 2016-12-12 04:56:56 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:56 --> Controller Class Initialized
INFO - 2016-12-12 04:56:56 --> Helper loaded: date_helper
INFO - 2016-12-12 04:56:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:56 --> Helper loaded: form_helper
INFO - 2016-12-12 04:56:56 --> Form Validation Class Initialized
INFO - 2016-12-12 04:56:56 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:56 --> Total execution time: 0.0148
INFO - 2016-12-12 04:56:57 --> Config Class Initialized
INFO - 2016-12-12 04:56:57 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:57 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:57 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:57 --> URI Class Initialized
INFO - 2016-12-12 04:56:57 --> Router Class Initialized
INFO - 2016-12-12 04:56:57 --> Output Class Initialized
INFO - 2016-12-12 04:56:57 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:57 --> Input Class Initialized
INFO - 2016-12-12 04:56:57 --> Language Class Initialized
INFO - 2016-12-12 04:56:57 --> Loader Class Initialized
INFO - 2016-12-12 04:56:57 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:57 --> Controller Class Initialized
INFO - 2016-12-12 04:56:57 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:57 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:57 --> Total execution time: 0.0128
INFO - 2016-12-12 04:56:59 --> Config Class Initialized
INFO - 2016-12-12 04:56:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:59 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:59 --> URI Class Initialized
INFO - 2016-12-12 04:56:59 --> Router Class Initialized
INFO - 2016-12-12 04:56:59 --> Output Class Initialized
INFO - 2016-12-12 04:56:59 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:59 --> Input Class Initialized
INFO - 2016-12-12 04:56:59 --> Language Class Initialized
INFO - 2016-12-12 04:56:59 --> Loader Class Initialized
INFO - 2016-12-12 04:56:59 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:59 --> Controller Class Initialized
INFO - 2016-12-12 04:56:59 --> Upload Class Initialized
INFO - 2016-12-12 04:56:59 --> Helper loaded: date_helper
INFO - 2016-12-12 04:56:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:59 --> Helper loaded: form_helper
INFO - 2016-12-12 04:56:59 --> Form Validation Class Initialized
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:56:59 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:59 --> Total execution time: 0.0154
INFO - 2016-12-12 04:56:59 --> Config Class Initialized
INFO - 2016-12-12 04:56:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:59 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:59 --> URI Class Initialized
INFO - 2016-12-12 04:56:59 --> Router Class Initialized
INFO - 2016-12-12 04:56:59 --> Output Class Initialized
INFO - 2016-12-12 04:56:59 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:59 --> Input Class Initialized
INFO - 2016-12-12 04:56:59 --> Language Class Initialized
INFO - 2016-12-12 04:56:59 --> Loader Class Initialized
INFO - 2016-12-12 04:56:59 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:59 --> Controller Class Initialized
INFO - 2016-12-12 04:56:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:56:59 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:59 --> Total execution time: 0.0138
INFO - 2016-12-12 04:56:59 --> Config Class Initialized
INFO - 2016-12-12 04:56:59 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:56:59 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:56:59 --> Utf8 Class Initialized
INFO - 2016-12-12 04:56:59 --> URI Class Initialized
INFO - 2016-12-12 04:56:59 --> Router Class Initialized
INFO - 2016-12-12 04:56:59 --> Output Class Initialized
INFO - 2016-12-12 04:56:59 --> Security Class Initialized
DEBUG - 2016-12-12 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:56:59 --> Input Class Initialized
INFO - 2016-12-12 04:56:59 --> Language Class Initialized
INFO - 2016-12-12 04:56:59 --> Loader Class Initialized
INFO - 2016-12-12 04:56:59 --> Database Driver Class Initialized
INFO - 2016-12-12 04:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:56:59 --> Controller Class Initialized
INFO - 2016-12-12 04:56:59 --> Helper loaded: date_helper
INFO - 2016-12-12 04:56:59 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:56:59 --> Helper loaded: form_helper
INFO - 2016-12-12 04:56:59 --> Form Validation Class Initialized
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-12 04:56:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:56:59 --> Final output sent to browser
DEBUG - 2016-12-12 04:56:59 --> Total execution time: 0.0159
INFO - 2016-12-12 04:57:00 --> Config Class Initialized
INFO - 2016-12-12 04:57:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:00 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:00 --> URI Class Initialized
INFO - 2016-12-12 04:57:00 --> Router Class Initialized
INFO - 2016-12-12 04:57:00 --> Output Class Initialized
INFO - 2016-12-12 04:57:00 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:00 --> Input Class Initialized
INFO - 2016-12-12 04:57:00 --> Language Class Initialized
INFO - 2016-12-12 04:57:00 --> Loader Class Initialized
INFO - 2016-12-12 04:57:00 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:00 --> Config Class Initialized
INFO - 2016-12-12 04:57:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:00 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:00 --> URI Class Initialized
INFO - 2016-12-12 04:57:00 --> Router Class Initialized
INFO - 2016-12-12 04:57:00 --> Output Class Initialized
INFO - 2016-12-12 04:57:00 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:00 --> Input Class Initialized
INFO - 2016-12-12 04:57:00 --> Language Class Initialized
INFO - 2016-12-12 04:57:00 --> Loader Class Initialized
INFO - 2016-12-12 04:57:00 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:00 --> Controller Class Initialized
INFO - 2016-12-12 04:57:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:57:00 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:00 --> Total execution time: 0.0287
INFO - 2016-12-12 04:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:00 --> Controller Class Initialized
INFO - 2016-12-12 04:57:00 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:00 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:00 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:00 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:00 --> Total execution time: 0.0862
INFO - 2016-12-12 04:57:02 --> Config Class Initialized
INFO - 2016-12-12 04:57:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:02 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:02 --> URI Class Initialized
INFO - 2016-12-12 04:57:02 --> Router Class Initialized
INFO - 2016-12-12 04:57:02 --> Output Class Initialized
INFO - 2016-12-12 04:57:02 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:02 --> Input Class Initialized
INFO - 2016-12-12 04:57:02 --> Language Class Initialized
INFO - 2016-12-12 04:57:02 --> Loader Class Initialized
INFO - 2016-12-12 04:57:02 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:02 --> Controller Class Initialized
INFO - 2016-12-12 04:57:02 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:02 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:02 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:02 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:02 --> Config Class Initialized
INFO - 2016-12-12 04:57:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:02 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:02 --> URI Class Initialized
INFO - 2016-12-12 04:57:02 --> Router Class Initialized
INFO - 2016-12-12 04:57:02 --> Output Class Initialized
INFO - 2016-12-12 04:57:02 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:02 --> Input Class Initialized
INFO - 2016-12-12 04:57:02 --> Language Class Initialized
INFO - 2016-12-12 04:57:02 --> Loader Class Initialized
INFO - 2016-12-12 04:57:02 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:02 --> Total execution time: 0.0861
INFO - 2016-12-12 04:57:02 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:02 --> Controller Class Initialized
INFO - 2016-12-12 04:57:02 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:02 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:02 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:02 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:02 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:02 --> Total execution time: 0.0222
INFO - 2016-12-12 04:57:04 --> Config Class Initialized
INFO - 2016-12-12 04:57:04 --> Hooks Class Initialized
INFO - 2016-12-12 04:57:04 --> Config Class Initialized
INFO - 2016-12-12 04:57:04 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:04 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:04 --> URI Class Initialized
INFO - 2016-12-12 04:57:04 --> Router Class Initialized
INFO - 2016-12-12 04:57:04 --> Output Class Initialized
INFO - 2016-12-12 04:57:04 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:04 --> Input Class Initialized
INFO - 2016-12-12 04:57:04 --> Language Class Initialized
INFO - 2016-12-12 04:57:04 --> Loader Class Initialized
DEBUG - 2016-12-12 04:57:04 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:04 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:04 --> URI Class Initialized
INFO - 2016-12-12 04:57:04 --> Router Class Initialized
INFO - 2016-12-12 04:57:04 --> Output Class Initialized
INFO - 2016-12-12 04:57:04 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:04 --> Input Class Initialized
INFO - 2016-12-12 04:57:04 --> Language Class Initialized
INFO - 2016-12-12 04:57:04 --> Loader Class Initialized
INFO - 2016-12-12 04:57:04 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:04 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:04 --> Controller Class Initialized
INFO - 2016-12-12 04:57:04 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:04 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:04 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:04 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:04 --> Total execution time: 0.0866
INFO - 2016-12-12 04:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:04 --> Controller Class Initialized
INFO - 2016-12-12 04:57:04 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:04 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:04 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:04 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:04 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:04 --> Total execution time: 0.1137
INFO - 2016-12-12 04:57:26 --> Config Class Initialized
INFO - 2016-12-12 04:57:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:26 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:26 --> URI Class Initialized
INFO - 2016-12-12 04:57:26 --> Router Class Initialized
INFO - 2016-12-12 04:57:26 --> Output Class Initialized
INFO - 2016-12-12 04:57:26 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:26 --> Input Class Initialized
INFO - 2016-12-12 04:57:26 --> Language Class Initialized
INFO - 2016-12-12 04:57:26 --> Loader Class Initialized
INFO - 2016-12-12 04:57:26 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:26 --> Controller Class Initialized
INFO - 2016-12-12 04:57:26 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:26 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:26 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:57:26 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:26 --> Total execution time: 0.0472
INFO - 2016-12-12 04:57:26 --> Config Class Initialized
INFO - 2016-12-12 04:57:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:26 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:26 --> URI Class Initialized
INFO - 2016-12-12 04:57:26 --> Router Class Initialized
INFO - 2016-12-12 04:57:26 --> Output Class Initialized
INFO - 2016-12-12 04:57:26 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:26 --> Input Class Initialized
INFO - 2016-12-12 04:57:26 --> Language Class Initialized
INFO - 2016-12-12 04:57:26 --> Loader Class Initialized
INFO - 2016-12-12 04:57:26 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:26 --> Controller Class Initialized
INFO - 2016-12-12 04:57:26 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:26 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:26 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:26 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:26 --> Total execution time: 0.0144
INFO - 2016-12-12 04:57:26 --> Config Class Initialized
INFO - 2016-12-12 04:57:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:26 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:26 --> URI Class Initialized
INFO - 2016-12-12 04:57:26 --> Router Class Initialized
INFO - 2016-12-12 04:57:26 --> Output Class Initialized
INFO - 2016-12-12 04:57:26 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:26 --> Input Class Initialized
INFO - 2016-12-12 04:57:26 --> Language Class Initialized
INFO - 2016-12-12 04:57:26 --> Loader Class Initialized
INFO - 2016-12-12 04:57:26 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:26 --> Controller Class Initialized
INFO - 2016-12-12 04:57:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:57:26 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:26 --> Total execution time: 0.0164
INFO - 2016-12-12 04:57:30 --> Config Class Initialized
INFO - 2016-12-12 04:57:30 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:30 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:30 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:30 --> URI Class Initialized
INFO - 2016-12-12 04:57:30 --> Router Class Initialized
INFO - 2016-12-12 04:57:30 --> Output Class Initialized
INFO - 2016-12-12 04:57:30 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:30 --> Input Class Initialized
INFO - 2016-12-12 04:57:30 --> Language Class Initialized
INFO - 2016-12-12 04:57:30 --> Loader Class Initialized
INFO - 2016-12-12 04:57:30 --> Config Class Initialized
INFO - 2016-12-12 04:57:30 --> Hooks Class Initialized
INFO - 2016-12-12 04:57:30 --> Database Driver Class Initialized
DEBUG - 2016-12-12 04:57:30 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:30 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:30 --> URI Class Initialized
INFO - 2016-12-12 04:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:30 --> Controller Class Initialized
INFO - 2016-12-12 04:57:30 --> Router Class Initialized
INFO - 2016-12-12 04:57:30 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:30 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:30 --> Output Class Initialized
INFO - 2016-12-12 04:57:30 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:30 --> Input Class Initialized
INFO - 2016-12-12 04:57:30 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:30 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:30 --> Language Class Initialized
INFO - 2016-12-12 04:57:30 --> Loader Class Initialized
INFO - 2016-12-12 04:57:30 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:30 --> Total execution time: 0.0227
INFO - 2016-12-12 04:57:30 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:30 --> Controller Class Initialized
INFO - 2016-12-12 04:57:30 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:30 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:30 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:30 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:30 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:30 --> Total execution time: 0.0779
INFO - 2016-12-12 04:57:41 --> Config Class Initialized
INFO - 2016-12-12 04:57:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:41 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:41 --> URI Class Initialized
INFO - 2016-12-12 04:57:41 --> Router Class Initialized
INFO - 2016-12-12 04:57:41 --> Output Class Initialized
INFO - 2016-12-12 04:57:41 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:41 --> Input Class Initialized
INFO - 2016-12-12 04:57:41 --> Language Class Initialized
INFO - 2016-12-12 04:57:41 --> Loader Class Initialized
INFO - 2016-12-12 04:57:41 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:41 --> Controller Class Initialized
INFO - 2016-12-12 04:57:41 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:41 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:41 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 04:57:41 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:41 --> Total execution time: 0.0527
INFO - 2016-12-12 04:57:41 --> Config Class Initialized
INFO - 2016-12-12 04:57:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:41 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:41 --> URI Class Initialized
INFO - 2016-12-12 04:57:41 --> Router Class Initialized
INFO - 2016-12-12 04:57:41 --> Output Class Initialized
INFO - 2016-12-12 04:57:41 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:41 --> Input Class Initialized
INFO - 2016-12-12 04:57:41 --> Language Class Initialized
INFO - 2016-12-12 04:57:41 --> Loader Class Initialized
INFO - 2016-12-12 04:57:41 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:41 --> Controller Class Initialized
INFO - 2016-12-12 04:57:41 --> Helper loaded: date_helper
INFO - 2016-12-12 04:57:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:41 --> Helper loaded: form_helper
INFO - 2016-12-12 04:57:41 --> Form Validation Class Initialized
INFO - 2016-12-12 04:57:41 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:41 --> Total execution time: 0.0142
INFO - 2016-12-12 04:57:41 --> Config Class Initialized
INFO - 2016-12-12 04:57:41 --> Hooks Class Initialized
DEBUG - 2016-12-12 04:57:41 --> UTF-8 Support Enabled
INFO - 2016-12-12 04:57:41 --> Utf8 Class Initialized
INFO - 2016-12-12 04:57:41 --> URI Class Initialized
INFO - 2016-12-12 04:57:41 --> Router Class Initialized
INFO - 2016-12-12 04:57:41 --> Output Class Initialized
INFO - 2016-12-12 04:57:41 --> Security Class Initialized
DEBUG - 2016-12-12 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 04:57:41 --> Input Class Initialized
INFO - 2016-12-12 04:57:41 --> Language Class Initialized
INFO - 2016-12-12 04:57:41 --> Loader Class Initialized
INFO - 2016-12-12 04:57:41 --> Database Driver Class Initialized
INFO - 2016-12-12 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 04:57:41 --> Controller Class Initialized
INFO - 2016-12-12 04:57:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 04:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 04:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 04:57:41 --> Final output sent to browser
DEBUG - 2016-12-12 04:57:41 --> Total execution time: 0.0129
INFO - 2016-12-12 05:58:20 --> Config Class Initialized
INFO - 2016-12-12 05:58:20 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:58:20 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:58:20 --> Utf8 Class Initialized
INFO - 2016-12-12 05:58:20 --> URI Class Initialized
INFO - 2016-12-12 05:58:20 --> Router Class Initialized
INFO - 2016-12-12 05:58:20 --> Output Class Initialized
INFO - 2016-12-12 05:58:20 --> Security Class Initialized
DEBUG - 2016-12-12 05:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:58:20 --> Input Class Initialized
INFO - 2016-12-12 05:58:20 --> Language Class Initialized
INFO - 2016-12-12 05:58:20 --> Loader Class Initialized
INFO - 2016-12-12 05:58:21 --> Database Driver Class Initialized
INFO - 2016-12-12 05:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:58:21 --> Controller Class Initialized
INFO - 2016-12-12 05:58:21 --> Helper loaded: date_helper
INFO - 2016-12-12 05:58:21 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:58:21 --> Helper loaded: form_helper
INFO - 2016-12-12 05:58:21 --> Form Validation Class Initialized
INFO - 2016-12-12 05:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 05:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-12 05:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2016-12-12 05:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2016-12-12 05:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 05:58:21 --> Final output sent to browser
DEBUG - 2016-12-12 05:58:21 --> Total execution time: 1.4622
INFO - 2016-12-12 05:58:22 --> Config Class Initialized
INFO - 2016-12-12 05:58:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:58:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:58:22 --> Utf8 Class Initialized
INFO - 2016-12-12 05:58:22 --> URI Class Initialized
INFO - 2016-12-12 05:58:22 --> Router Class Initialized
INFO - 2016-12-12 05:58:22 --> Output Class Initialized
INFO - 2016-12-12 05:58:22 --> Security Class Initialized
DEBUG - 2016-12-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:58:22 --> Input Class Initialized
INFO - 2016-12-12 05:58:22 --> Language Class Initialized
INFO - 2016-12-12 05:58:22 --> Loader Class Initialized
INFO - 2016-12-12 05:58:22 --> Database Driver Class Initialized
INFO - 2016-12-12 05:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:58:22 --> Controller Class Initialized
INFO - 2016-12-12 05:58:22 --> Helper loaded: date_helper
INFO - 2016-12-12 05:58:22 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:58:22 --> Helper loaded: form_helper
INFO - 2016-12-12 05:58:22 --> Form Validation Class Initialized
INFO - 2016-12-12 05:58:22 --> Final output sent to browser
DEBUG - 2016-12-12 05:58:22 --> Total execution time: 0.0144
INFO - 2016-12-12 05:58:22 --> Config Class Initialized
INFO - 2016-12-12 05:58:22 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:58:22 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:58:22 --> Utf8 Class Initialized
INFO - 2016-12-12 05:58:22 --> URI Class Initialized
INFO - 2016-12-12 05:58:22 --> Router Class Initialized
INFO - 2016-12-12 05:58:22 --> Output Class Initialized
INFO - 2016-12-12 05:58:22 --> Security Class Initialized
DEBUG - 2016-12-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:58:22 --> Input Class Initialized
INFO - 2016-12-12 05:58:22 --> Language Class Initialized
INFO - 2016-12-12 05:58:22 --> Loader Class Initialized
INFO - 2016-12-12 05:58:22 --> Database Driver Class Initialized
INFO - 2016-12-12 05:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:58:22 --> Controller Class Initialized
INFO - 2016-12-12 05:58:22 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:58:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 05:58:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 05:58:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 05:58:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 05:58:22 --> Final output sent to browser
DEBUG - 2016-12-12 05:58:22 --> Total execution time: 0.1350
INFO - 2016-12-12 05:58:27 --> Config Class Initialized
INFO - 2016-12-12 05:58:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:58:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:58:27 --> Utf8 Class Initialized
INFO - 2016-12-12 05:58:27 --> URI Class Initialized
DEBUG - 2016-12-12 05:58:27 --> No URI present. Default controller set.
INFO - 2016-12-12 05:58:27 --> Router Class Initialized
INFO - 2016-12-12 05:58:27 --> Output Class Initialized
INFO - 2016-12-12 05:58:27 --> Security Class Initialized
DEBUG - 2016-12-12 05:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:58:27 --> Input Class Initialized
INFO - 2016-12-12 05:58:27 --> Language Class Initialized
INFO - 2016-12-12 05:58:27 --> Loader Class Initialized
INFO - 2016-12-12 05:58:27 --> Database Driver Class Initialized
INFO - 2016-12-12 05:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:58:27 --> Controller Class Initialized
INFO - 2016-12-12 05:58:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 05:58:27 --> Final output sent to browser
DEBUG - 2016-12-12 05:58:27 --> Total execution time: 0.0146
INFO - 2016-12-12 05:58:27 --> Config Class Initialized
INFO - 2016-12-12 05:58:27 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:58:27 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:58:27 --> Utf8 Class Initialized
INFO - 2016-12-12 05:58:27 --> URI Class Initialized
INFO - 2016-12-12 05:58:27 --> Router Class Initialized
INFO - 2016-12-12 05:58:27 --> Output Class Initialized
INFO - 2016-12-12 05:58:27 --> Security Class Initialized
DEBUG - 2016-12-12 05:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:58:27 --> Input Class Initialized
INFO - 2016-12-12 05:58:27 --> Language Class Initialized
INFO - 2016-12-12 05:58:27 --> Loader Class Initialized
INFO - 2016-12-12 05:58:27 --> Database Driver Class Initialized
INFO - 2016-12-12 05:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:58:27 --> Controller Class Initialized
INFO - 2016-12-12 05:58:27 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 05:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 05:58:27 --> Final output sent to browser
DEBUG - 2016-12-12 05:58:27 --> Total execution time: 0.0134
INFO - 2016-12-12 05:59:14 --> Config Class Initialized
INFO - 2016-12-12 05:59:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:59:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:59:14 --> Utf8 Class Initialized
INFO - 2016-12-12 05:59:14 --> URI Class Initialized
DEBUG - 2016-12-12 05:59:14 --> No URI present. Default controller set.
INFO - 2016-12-12 05:59:14 --> Router Class Initialized
INFO - 2016-12-12 05:59:14 --> Output Class Initialized
INFO - 2016-12-12 05:59:14 --> Security Class Initialized
DEBUG - 2016-12-12 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:59:14 --> Input Class Initialized
INFO - 2016-12-12 05:59:14 --> Language Class Initialized
INFO - 2016-12-12 05:59:14 --> Loader Class Initialized
INFO - 2016-12-12 05:59:14 --> Database Driver Class Initialized
INFO - 2016-12-12 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:59:14 --> Controller Class Initialized
INFO - 2016-12-12 05:59:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 05:59:14 --> Final output sent to browser
DEBUG - 2016-12-12 05:59:14 --> Total execution time: 0.0135
INFO - 2016-12-12 05:59:14 --> Config Class Initialized
INFO - 2016-12-12 05:59:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:59:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:59:14 --> Utf8 Class Initialized
INFO - 2016-12-12 05:59:14 --> URI Class Initialized
INFO - 2016-12-12 05:59:14 --> Router Class Initialized
INFO - 2016-12-12 05:59:14 --> Output Class Initialized
INFO - 2016-12-12 05:59:14 --> Security Class Initialized
DEBUG - 2016-12-12 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:59:14 --> Input Class Initialized
INFO - 2016-12-12 05:59:14 --> Language Class Initialized
INFO - 2016-12-12 05:59:14 --> Loader Class Initialized
INFO - 2016-12-12 05:59:14 --> Database Driver Class Initialized
INFO - 2016-12-12 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:59:14 --> Controller Class Initialized
INFO - 2016-12-12 05:59:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 05:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 05:59:14 --> Final output sent to browser
DEBUG - 2016-12-12 05:59:14 --> Total execution time: 0.0134
INFO - 2016-12-12 05:59:33 --> Config Class Initialized
INFO - 2016-12-12 05:59:33 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:59:33 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:59:33 --> Utf8 Class Initialized
INFO - 2016-12-12 05:59:33 --> URI Class Initialized
DEBUG - 2016-12-12 05:59:33 --> No URI present. Default controller set.
INFO - 2016-12-12 05:59:33 --> Router Class Initialized
INFO - 2016-12-12 05:59:33 --> Output Class Initialized
INFO - 2016-12-12 05:59:33 --> Security Class Initialized
DEBUG - 2016-12-12 05:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:59:33 --> Input Class Initialized
INFO - 2016-12-12 05:59:33 --> Language Class Initialized
INFO - 2016-12-12 05:59:33 --> Loader Class Initialized
INFO - 2016-12-12 05:59:33 --> Database Driver Class Initialized
INFO - 2016-12-12 05:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:59:33 --> Controller Class Initialized
INFO - 2016-12-12 05:59:33 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 05:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 05:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 05:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 05:59:33 --> Final output sent to browser
DEBUG - 2016-12-12 05:59:33 --> Total execution time: 0.0133
INFO - 2016-12-12 05:59:34 --> Config Class Initialized
INFO - 2016-12-12 05:59:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 05:59:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 05:59:34 --> Utf8 Class Initialized
INFO - 2016-12-12 05:59:34 --> URI Class Initialized
INFO - 2016-12-12 05:59:34 --> Router Class Initialized
INFO - 2016-12-12 05:59:34 --> Output Class Initialized
INFO - 2016-12-12 05:59:34 --> Security Class Initialized
DEBUG - 2016-12-12 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 05:59:34 --> Input Class Initialized
INFO - 2016-12-12 05:59:34 --> Language Class Initialized
INFO - 2016-12-12 05:59:34 --> Loader Class Initialized
INFO - 2016-12-12 05:59:34 --> Database Driver Class Initialized
INFO - 2016-12-12 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 05:59:34 --> Controller Class Initialized
INFO - 2016-12-12 05:59:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 05:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 05:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 05:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 05:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 05:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 05:59:34 --> Final output sent to browser
DEBUG - 2016-12-12 05:59:34 --> Total execution time: 0.0134
INFO - 2016-12-12 15:47:38 --> Config Class Initialized
INFO - 2016-12-12 15:47:38 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:47:38 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:47:38 --> Utf8 Class Initialized
INFO - 2016-12-12 15:47:38 --> URI Class Initialized
DEBUG - 2016-12-12 15:47:38 --> No URI present. Default controller set.
INFO - 2016-12-12 15:47:38 --> Router Class Initialized
INFO - 2016-12-12 15:47:38 --> Output Class Initialized
INFO - 2016-12-12 15:47:38 --> Security Class Initialized
DEBUG - 2016-12-12 15:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:47:38 --> Input Class Initialized
INFO - 2016-12-12 15:47:38 --> Language Class Initialized
INFO - 2016-12-12 15:47:38 --> Loader Class Initialized
INFO - 2016-12-12 15:47:38 --> Database Driver Class Initialized
INFO - 2016-12-12 15:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:47:39 --> Controller Class Initialized
INFO - 2016-12-12 15:47:39 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:47:39 --> Final output sent to browser
DEBUG - 2016-12-12 15:47:39 --> Total execution time: 1.9287
INFO - 2016-12-12 15:47:45 --> Config Class Initialized
INFO - 2016-12-12 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:47:45 --> Utf8 Class Initialized
INFO - 2016-12-12 15:47:45 --> URI Class Initialized
INFO - 2016-12-12 15:47:45 --> Router Class Initialized
INFO - 2016-12-12 15:47:45 --> Output Class Initialized
INFO - 2016-12-12 15:47:45 --> Security Class Initialized
DEBUG - 2016-12-12 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:47:45 --> Input Class Initialized
INFO - 2016-12-12 15:47:45 --> Language Class Initialized
INFO - 2016-12-12 15:47:45 --> Loader Class Initialized
INFO - 2016-12-12 15:47:45 --> Database Driver Class Initialized
INFO - 2016-12-12 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:47:45 --> Controller Class Initialized
INFO - 2016-12-12 15:47:45 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:47:45 --> Final output sent to browser
DEBUG - 2016-12-12 15:47:45 --> Total execution time: 0.0132
INFO - 2016-12-12 15:48:07 --> Config Class Initialized
INFO - 2016-12-12 15:48:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:48:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:48:07 --> Utf8 Class Initialized
INFO - 2016-12-12 15:48:07 --> URI Class Initialized
INFO - 2016-12-12 15:48:07 --> Router Class Initialized
INFO - 2016-12-12 15:48:07 --> Output Class Initialized
INFO - 2016-12-12 15:48:07 --> Security Class Initialized
DEBUG - 2016-12-12 15:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:48:07 --> Input Class Initialized
INFO - 2016-12-12 15:48:07 --> Language Class Initialized
INFO - 2016-12-12 15:48:07 --> Loader Class Initialized
INFO - 2016-12-12 15:48:07 --> Database Driver Class Initialized
INFO - 2016-12-12 15:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:48:07 --> Controller Class Initialized
INFO - 2016-12-12 15:48:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:48:07 --> Final output sent to browser
DEBUG - 2016-12-12 15:48:07 --> Total execution time: 0.0537
INFO - 2016-12-12 15:48:07 --> Config Class Initialized
INFO - 2016-12-12 15:48:07 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:48:07 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:48:07 --> Utf8 Class Initialized
INFO - 2016-12-12 15:48:07 --> URI Class Initialized
INFO - 2016-12-12 15:48:07 --> Router Class Initialized
INFO - 2016-12-12 15:48:07 --> Output Class Initialized
INFO - 2016-12-12 15:48:07 --> Security Class Initialized
DEBUG - 2016-12-12 15:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:48:07 --> Input Class Initialized
INFO - 2016-12-12 15:48:07 --> Language Class Initialized
INFO - 2016-12-12 15:48:07 --> Loader Class Initialized
INFO - 2016-12-12 15:48:07 --> Database Driver Class Initialized
INFO - 2016-12-12 15:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:48:07 --> Controller Class Initialized
INFO - 2016-12-12 15:48:07 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:48:07 --> Final output sent to browser
DEBUG - 2016-12-12 15:48:07 --> Total execution time: 0.0144
INFO - 2016-12-12 15:48:12 --> Config Class Initialized
INFO - 2016-12-12 15:48:12 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:48:12 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:48:12 --> Utf8 Class Initialized
INFO - 2016-12-12 15:48:12 --> URI Class Initialized
DEBUG - 2016-12-12 15:48:12 --> No URI present. Default controller set.
INFO - 2016-12-12 15:48:12 --> Router Class Initialized
INFO - 2016-12-12 15:48:12 --> Output Class Initialized
INFO - 2016-12-12 15:48:12 --> Security Class Initialized
DEBUG - 2016-12-12 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:48:12 --> Input Class Initialized
INFO - 2016-12-12 15:48:12 --> Language Class Initialized
INFO - 2016-12-12 15:48:12 --> Loader Class Initialized
INFO - 2016-12-12 15:48:12 --> Database Driver Class Initialized
INFO - 2016-12-12 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:48:12 --> Controller Class Initialized
INFO - 2016-12-12 15:48:12 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:48:12 --> Final output sent to browser
DEBUG - 2016-12-12 15:48:12 --> Total execution time: 0.0142
INFO - 2016-12-12 15:48:14 --> Config Class Initialized
INFO - 2016-12-12 15:48:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:48:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:48:14 --> Utf8 Class Initialized
INFO - 2016-12-12 15:48:14 --> URI Class Initialized
INFO - 2016-12-12 15:48:14 --> Router Class Initialized
INFO - 2016-12-12 15:48:14 --> Output Class Initialized
INFO - 2016-12-12 15:48:14 --> Security Class Initialized
DEBUG - 2016-12-12 15:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:48:14 --> Input Class Initialized
INFO - 2016-12-12 15:48:14 --> Language Class Initialized
INFO - 2016-12-12 15:48:14 --> Loader Class Initialized
INFO - 2016-12-12 15:48:14 --> Database Driver Class Initialized
INFO - 2016-12-12 15:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:48:14 --> Controller Class Initialized
INFO - 2016-12-12 15:48:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:48:14 --> Final output sent to browser
DEBUG - 2016-12-12 15:48:14 --> Total execution time: 0.0729
INFO - 2016-12-12 15:50:56 --> Config Class Initialized
INFO - 2016-12-12 15:50:56 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:50:56 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:50:56 --> Utf8 Class Initialized
INFO - 2016-12-12 15:50:56 --> URI Class Initialized
DEBUG - 2016-12-12 15:50:56 --> No URI present. Default controller set.
INFO - 2016-12-12 15:50:56 --> Router Class Initialized
INFO - 2016-12-12 15:50:56 --> Output Class Initialized
INFO - 2016-12-12 15:50:56 --> Security Class Initialized
DEBUG - 2016-12-12 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:50:56 --> Input Class Initialized
INFO - 2016-12-12 15:50:56 --> Language Class Initialized
INFO - 2016-12-12 15:50:56 --> Loader Class Initialized
INFO - 2016-12-12 15:50:56 --> Database Driver Class Initialized
INFO - 2016-12-12 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:50:56 --> Controller Class Initialized
INFO - 2016-12-12 15:50:56 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:50:56 --> Final output sent to browser
DEBUG - 2016-12-12 15:50:56 --> Total execution time: 0.0139
INFO - 2016-12-12 15:50:58 --> Config Class Initialized
INFO - 2016-12-12 15:50:58 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:50:58 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:50:58 --> Utf8 Class Initialized
INFO - 2016-12-12 15:50:58 --> URI Class Initialized
INFO - 2016-12-12 15:50:58 --> Router Class Initialized
INFO - 2016-12-12 15:50:58 --> Output Class Initialized
INFO - 2016-12-12 15:50:58 --> Security Class Initialized
DEBUG - 2016-12-12 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:50:58 --> Input Class Initialized
INFO - 2016-12-12 15:50:58 --> Language Class Initialized
INFO - 2016-12-12 15:50:58 --> Loader Class Initialized
INFO - 2016-12-12 15:50:58 --> Database Driver Class Initialized
INFO - 2016-12-12 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:50:58 --> Controller Class Initialized
INFO - 2016-12-12 15:50:58 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:50:58 --> Final output sent to browser
DEBUG - 2016-12-12 15:50:58 --> Total execution time: 0.0154
INFO - 2016-12-12 15:51:06 --> Config Class Initialized
INFO - 2016-12-12 15:51:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:06 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:06 --> URI Class Initialized
INFO - 2016-12-12 15:51:06 --> Router Class Initialized
INFO - 2016-12-12 15:51:06 --> Output Class Initialized
INFO - 2016-12-12 15:51:06 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:06 --> Input Class Initialized
INFO - 2016-12-12 15:51:06 --> Language Class Initialized
INFO - 2016-12-12 15:51:06 --> Loader Class Initialized
INFO - 2016-12-12 15:51:06 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:06 --> Controller Class Initialized
INFO - 2016-12-12 15:51:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:06 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:06 --> Total execution time: 0.0181
INFO - 2016-12-12 15:51:06 --> Config Class Initialized
INFO - 2016-12-12 15:51:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:06 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:06 --> URI Class Initialized
INFO - 2016-12-12 15:51:06 --> Router Class Initialized
INFO - 2016-12-12 15:51:06 --> Output Class Initialized
INFO - 2016-12-12 15:51:06 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:06 --> Input Class Initialized
INFO - 2016-12-12 15:51:06 --> Language Class Initialized
INFO - 2016-12-12 15:51:06 --> Loader Class Initialized
INFO - 2016-12-12 15:51:06 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:06 --> Controller Class Initialized
INFO - 2016-12-12 15:51:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:51:06 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:06 --> Total execution time: 0.0134
INFO - 2016-12-12 15:51:14 --> Config Class Initialized
INFO - 2016-12-12 15:51:14 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:14 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:14 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:14 --> URI Class Initialized
INFO - 2016-12-12 15:51:14 --> Router Class Initialized
INFO - 2016-12-12 15:51:14 --> Output Class Initialized
INFO - 2016-12-12 15:51:14 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:14 --> Input Class Initialized
INFO - 2016-12-12 15:51:14 --> Language Class Initialized
INFO - 2016-12-12 15:51:14 --> Loader Class Initialized
INFO - 2016-12-12 15:51:14 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:14 --> Controller Class Initialized
INFO - 2016-12-12 15:51:14 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:14 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:14 --> Total execution time: 0.0137
INFO - 2016-12-12 15:51:15 --> Config Class Initialized
INFO - 2016-12-12 15:51:15 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:15 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:15 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:15 --> URI Class Initialized
INFO - 2016-12-12 15:51:15 --> Router Class Initialized
INFO - 2016-12-12 15:51:15 --> Output Class Initialized
INFO - 2016-12-12 15:51:15 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:15 --> Input Class Initialized
INFO - 2016-12-12 15:51:15 --> Language Class Initialized
INFO - 2016-12-12 15:51:15 --> Loader Class Initialized
INFO - 2016-12-12 15:51:15 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:15 --> Controller Class Initialized
INFO - 2016-12-12 15:51:15 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:51:15 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:15 --> Total execution time: 0.0146
INFO - 2016-12-12 15:51:26 --> Config Class Initialized
INFO - 2016-12-12 15:51:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:26 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:26 --> URI Class Initialized
INFO - 2016-12-12 15:51:26 --> Router Class Initialized
INFO - 2016-12-12 15:51:26 --> Output Class Initialized
INFO - 2016-12-12 15:51:26 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:26 --> Input Class Initialized
INFO - 2016-12-12 15:51:26 --> Language Class Initialized
INFO - 2016-12-12 15:51:26 --> Loader Class Initialized
INFO - 2016-12-12 15:51:26 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:26 --> Controller Class Initialized
INFO - 2016-12-12 15:51:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:26 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:26 --> Total execution time: 0.0139
INFO - 2016-12-12 15:51:26 --> Config Class Initialized
INFO - 2016-12-12 15:51:26 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:26 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:26 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:26 --> URI Class Initialized
INFO - 2016-12-12 15:51:26 --> Router Class Initialized
INFO - 2016-12-12 15:51:26 --> Output Class Initialized
INFO - 2016-12-12 15:51:26 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:26 --> Input Class Initialized
INFO - 2016-12-12 15:51:26 --> Language Class Initialized
INFO - 2016-12-12 15:51:26 --> Loader Class Initialized
INFO - 2016-12-12 15:51:26 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:26 --> Controller Class Initialized
INFO - 2016-12-12 15:51:26 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:51:26 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:26 --> Total execution time: 0.0134
INFO - 2016-12-12 15:51:40 --> Config Class Initialized
INFO - 2016-12-12 15:51:40 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:40 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:40 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:40 --> URI Class Initialized
DEBUG - 2016-12-12 15:51:40 --> No URI present. Default controller set.
INFO - 2016-12-12 15:51:40 --> Router Class Initialized
INFO - 2016-12-12 15:51:40 --> Output Class Initialized
INFO - 2016-12-12 15:51:40 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:40 --> Input Class Initialized
INFO - 2016-12-12 15:51:40 --> Language Class Initialized
INFO - 2016-12-12 15:51:40 --> Loader Class Initialized
INFO - 2016-12-12 15:51:40 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:40 --> Controller Class Initialized
INFO - 2016-12-12 15:51:40 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:51:40 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:40 --> Total execution time: 0.0140
INFO - 2016-12-12 15:51:42 --> Config Class Initialized
INFO - 2016-12-12 15:51:42 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:42 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:42 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:42 --> URI Class Initialized
INFO - 2016-12-12 15:51:42 --> Router Class Initialized
INFO - 2016-12-12 15:51:42 --> Output Class Initialized
INFO - 2016-12-12 15:51:42 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:42 --> Input Class Initialized
INFO - 2016-12-12 15:51:42 --> Language Class Initialized
INFO - 2016-12-12 15:51:42 --> Loader Class Initialized
INFO - 2016-12-12 15:51:42 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:42 --> Controller Class Initialized
INFO - 2016-12-12 15:51:42 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:51:42 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:42 --> Total execution time: 0.0138
INFO - 2016-12-12 15:51:44 --> Config Class Initialized
INFO - 2016-12-12 15:51:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:44 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:44 --> URI Class Initialized
INFO - 2016-12-12 15:51:44 --> Router Class Initialized
INFO - 2016-12-12 15:51:44 --> Output Class Initialized
INFO - 2016-12-12 15:51:44 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:44 --> Input Class Initialized
INFO - 2016-12-12 15:51:44 --> Language Class Initialized
INFO - 2016-12-12 15:51:44 --> Loader Class Initialized
INFO - 2016-12-12 15:51:44 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:44 --> Controller Class Initialized
INFO - 2016-12-12 15:51:44 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:44 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:44 --> Total execution time: 0.0129
INFO - 2016-12-12 15:51:44 --> Config Class Initialized
INFO - 2016-12-12 15:51:44 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:51:44 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:51:44 --> Utf8 Class Initialized
INFO - 2016-12-12 15:51:44 --> URI Class Initialized
INFO - 2016-12-12 15:51:44 --> Router Class Initialized
INFO - 2016-12-12 15:51:44 --> Output Class Initialized
INFO - 2016-12-12 15:51:44 --> Security Class Initialized
DEBUG - 2016-12-12 15:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:51:44 --> Input Class Initialized
INFO - 2016-12-12 15:51:44 --> Language Class Initialized
INFO - 2016-12-12 15:51:44 --> Loader Class Initialized
INFO - 2016-12-12 15:51:44 --> Database Driver Class Initialized
INFO - 2016-12-12 15:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:51:44 --> Controller Class Initialized
INFO - 2016-12-12 15:51:44 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:51:44 --> Final output sent to browser
DEBUG - 2016-12-12 15:51:44 --> Total execution time: 0.0132
INFO - 2016-12-12 15:52:06 --> Config Class Initialized
INFO - 2016-12-12 15:52:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:52:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:52:06 --> Utf8 Class Initialized
INFO - 2016-12-12 15:52:06 --> URI Class Initialized
INFO - 2016-12-12 15:52:06 --> Router Class Initialized
INFO - 2016-12-12 15:52:06 --> Output Class Initialized
INFO - 2016-12-12 15:52:06 --> Security Class Initialized
DEBUG - 2016-12-12 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:52:06 --> Input Class Initialized
INFO - 2016-12-12 15:52:06 --> Language Class Initialized
INFO - 2016-12-12 15:52:06 --> Loader Class Initialized
INFO - 2016-12-12 15:52:06 --> Database Driver Class Initialized
INFO - 2016-12-12 15:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:52:06 --> Controller Class Initialized
INFO - 2016-12-12 15:52:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:52:06 --> Final output sent to browser
DEBUG - 2016-12-12 15:52:06 --> Total execution time: 0.0686
INFO - 2016-12-12 15:52:06 --> Config Class Initialized
INFO - 2016-12-12 15:52:06 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:52:06 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:52:06 --> Utf8 Class Initialized
INFO - 2016-12-12 15:52:06 --> URI Class Initialized
INFO - 2016-12-12 15:52:06 --> Router Class Initialized
INFO - 2016-12-12 15:52:06 --> Output Class Initialized
INFO - 2016-12-12 15:52:06 --> Security Class Initialized
DEBUG - 2016-12-12 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:52:06 --> Input Class Initialized
INFO - 2016-12-12 15:52:06 --> Language Class Initialized
INFO - 2016-12-12 15:52:06 --> Loader Class Initialized
INFO - 2016-12-12 15:52:06 --> Database Driver Class Initialized
INFO - 2016-12-12 15:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:52:06 --> Controller Class Initialized
INFO - 2016-12-12 15:52:06 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:52:06 --> Final output sent to browser
DEBUG - 2016-12-12 15:52:06 --> Total execution time: 0.0173
INFO - 2016-12-12 15:52:29 --> Config Class Initialized
INFO - 2016-12-12 15:52:29 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:52:29 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:52:29 --> Utf8 Class Initialized
INFO - 2016-12-12 15:52:29 --> URI Class Initialized
INFO - 2016-12-12 15:52:29 --> Router Class Initialized
INFO - 2016-12-12 15:52:29 --> Output Class Initialized
INFO - 2016-12-12 15:52:29 --> Security Class Initialized
DEBUG - 2016-12-12 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:52:29 --> Input Class Initialized
INFO - 2016-12-12 15:52:29 --> Language Class Initialized
INFO - 2016-12-12 15:52:29 --> Loader Class Initialized
INFO - 2016-12-12 15:52:29 --> Database Driver Class Initialized
INFO - 2016-12-12 15:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:52:29 --> Controller Class Initialized
INFO - 2016-12-12 15:52:29 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:52:29 --> Final output sent to browser
DEBUG - 2016-12-12 15:52:29 --> Total execution time: 0.0130
INFO - 2016-12-12 15:52:32 --> Config Class Initialized
INFO - 2016-12-12 15:52:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:52:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:52:32 --> Utf8 Class Initialized
INFO - 2016-12-12 15:52:32 --> URI Class Initialized
INFO - 2016-12-12 15:52:32 --> Router Class Initialized
INFO - 2016-12-12 15:52:32 --> Output Class Initialized
INFO - 2016-12-12 15:52:32 --> Security Class Initialized
DEBUG - 2016-12-12 15:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:52:32 --> Input Class Initialized
INFO - 2016-12-12 15:52:32 --> Language Class Initialized
INFO - 2016-12-12 15:52:32 --> Loader Class Initialized
INFO - 2016-12-12 15:52:32 --> Database Driver Class Initialized
INFO - 2016-12-12 15:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:52:32 --> Controller Class Initialized
INFO - 2016-12-12 15:52:32 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:52:32 --> Final output sent to browser
DEBUG - 2016-12-12 15:52:32 --> Total execution time: 0.0135
INFO - 2016-12-12 15:52:34 --> Config Class Initialized
INFO - 2016-12-12 15:52:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:52:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:52:34 --> Utf8 Class Initialized
INFO - 2016-12-12 15:52:34 --> URI Class Initialized
INFO - 2016-12-12 15:52:34 --> Router Class Initialized
INFO - 2016-12-12 15:52:34 --> Output Class Initialized
INFO - 2016-12-12 15:52:34 --> Security Class Initialized
DEBUG - 2016-12-12 15:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:52:34 --> Input Class Initialized
INFO - 2016-12-12 15:52:34 --> Language Class Initialized
INFO - 2016-12-12 15:52:34 --> Loader Class Initialized
INFO - 2016-12-12 15:52:34 --> Database Driver Class Initialized
INFO - 2016-12-12 15:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:52:34 --> Controller Class Initialized
INFO - 2016-12-12 15:52:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:52:34 --> Final output sent to browser
DEBUG - 2016-12-12 15:52:34 --> Total execution time: 0.0147
INFO - 2016-12-12 15:52:34 --> Config Class Initialized
INFO - 2016-12-12 15:52:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 15:52:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 15:52:34 --> Utf8 Class Initialized
INFO - 2016-12-12 15:52:34 --> URI Class Initialized
INFO - 2016-12-12 15:52:34 --> Router Class Initialized
INFO - 2016-12-12 15:52:34 --> Output Class Initialized
INFO - 2016-12-12 15:52:34 --> Security Class Initialized
DEBUG - 2016-12-12 15:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 15:52:34 --> Input Class Initialized
INFO - 2016-12-12 15:52:34 --> Language Class Initialized
INFO - 2016-12-12 15:52:34 --> Loader Class Initialized
INFO - 2016-12-12 15:52:34 --> Database Driver Class Initialized
INFO - 2016-12-12 15:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 15:52:34 --> Controller Class Initialized
INFO - 2016-12-12 15:52:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 15:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 15:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 15:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 15:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 15:52:34 --> Final output sent to browser
DEBUG - 2016-12-12 15:52:34 --> Total execution time: 0.0151
INFO - 2016-12-12 19:33:49 --> Config Class Initialized
INFO - 2016-12-12 19:33:49 --> Hooks Class Initialized
DEBUG - 2016-12-12 19:33:49 --> UTF-8 Support Enabled
INFO - 2016-12-12 19:33:49 --> Utf8 Class Initialized
INFO - 2016-12-12 19:33:49 --> URI Class Initialized
DEBUG - 2016-12-12 19:33:49 --> No URI present. Default controller set.
INFO - 2016-12-12 19:33:49 --> Router Class Initialized
INFO - 2016-12-12 19:33:49 --> Output Class Initialized
INFO - 2016-12-12 19:33:49 --> Security Class Initialized
DEBUG - 2016-12-12 19:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 19:33:50 --> Input Class Initialized
INFO - 2016-12-12 19:33:50 --> Language Class Initialized
INFO - 2016-12-12 19:33:50 --> Loader Class Initialized
INFO - 2016-12-12 19:33:50 --> Database Driver Class Initialized
INFO - 2016-12-12 19:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 19:33:50 --> Controller Class Initialized
INFO - 2016-12-12 19:33:50 --> Helper loaded: url_helper
DEBUG - 2016-12-12 19:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 19:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 19:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 19:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 19:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 19:33:51 --> Final output sent to browser
DEBUG - 2016-12-12 19:33:51 --> Total execution time: 2.0161
INFO - 2016-12-12 19:34:00 --> Config Class Initialized
INFO - 2016-12-12 19:34:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 19:34:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 19:34:00 --> Utf8 Class Initialized
INFO - 2016-12-12 19:34:00 --> URI Class Initialized
INFO - 2016-12-12 19:34:00 --> Router Class Initialized
INFO - 2016-12-12 19:34:00 --> Output Class Initialized
INFO - 2016-12-12 19:34:00 --> Security Class Initialized
DEBUG - 2016-12-12 19:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 19:34:00 --> Input Class Initialized
INFO - 2016-12-12 19:34:00 --> Language Class Initialized
INFO - 2016-12-12 19:34:00 --> Loader Class Initialized
INFO - 2016-12-12 19:34:00 --> Database Driver Class Initialized
INFO - 2016-12-12 19:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 19:34:00 --> Controller Class Initialized
INFO - 2016-12-12 19:34:00 --> Helper loaded: url_helper
DEBUG - 2016-12-12 19:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 19:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 19:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 19:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 19:34:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 19:34:00 --> Config Class Initialized
INFO - 2016-12-12 19:34:00 --> Hooks Class Initialized
DEBUG - 2016-12-12 19:34:00 --> UTF-8 Support Enabled
INFO - 2016-12-12 19:34:00 --> Utf8 Class Initialized
INFO - 2016-12-12 19:34:00 --> URI Class Initialized
INFO - 2016-12-12 19:34:00 --> Router Class Initialized
INFO - 2016-12-12 19:34:00 --> Output Class Initialized
INFO - 2016-12-12 19:34:00 --> Security Class Initialized
DEBUG - 2016-12-12 19:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 19:34:00 --> Input Class Initialized
INFO - 2016-12-12 19:34:00 --> Language Class Initialized
INFO - 2016-12-12 19:34:00 --> Final output sent to browser
DEBUG - 2016-12-12 19:34:00 --> Total execution time: 0.0137
INFO - 2016-12-12 19:34:00 --> Loader Class Initialized
INFO - 2016-12-12 19:34:00 --> Database Driver Class Initialized
INFO - 2016-12-12 19:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 19:34:00 --> Controller Class Initialized
INFO - 2016-12-12 19:34:01 --> Helper loaded: date_helper
INFO - 2016-12-12 19:34:01 --> Helper loaded: url_helper
DEBUG - 2016-12-12 19:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 19:34:01 --> Helper loaded: form_helper
INFO - 2016-12-12 19:34:01 --> Form Validation Class Initialized
INFO - 2016-12-12 19:34:01 --> Config Class Initialized
INFO - 2016-12-12 19:34:01 --> Hooks Class Initialized
DEBUG - 2016-12-12 19:34:01 --> UTF-8 Support Enabled
INFO - 2016-12-12 19:34:01 --> Utf8 Class Initialized
INFO - 2016-12-12 19:34:01 --> URI Class Initialized
INFO - 2016-12-12 19:34:01 --> Router Class Initialized
INFO - 2016-12-12 19:34:01 --> Output Class Initialized
INFO - 2016-12-12 19:34:01 --> Security Class Initialized
DEBUG - 2016-12-12 19:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 19:34:01 --> Input Class Initialized
INFO - 2016-12-12 19:34:01 --> Language Class Initialized
INFO - 2016-12-12 19:34:01 --> Loader Class Initialized
INFO - 2016-12-12 19:34:01 --> Database Driver Class Initialized
INFO - 2016-12-12 19:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 19:34:01 --> Controller Class Initialized
INFO - 2016-12-12 19:34:01 --> Helper loaded: url_helper
DEBUG - 2016-12-12 19:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 19:34:01 --> Helper loaded: form_helper
INFO - 2016-12-12 19:34:01 --> Form Validation Class Initialized
INFO - 2016-12-12 19:34:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-12 19:34:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-12 19:34:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-12 19:34:01 --> Final output sent to browser
DEBUG - 2016-12-12 19:34:01 --> Total execution time: 0.0826
INFO - 2016-12-12 19:34:02 --> Config Class Initialized
INFO - 2016-12-12 19:34:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 19:34:02 --> UTF-8 Support Enabled
INFO - 2016-12-12 19:34:02 --> Utf8 Class Initialized
INFO - 2016-12-12 19:34:02 --> URI Class Initialized
INFO - 2016-12-12 19:34:02 --> Router Class Initialized
INFO - 2016-12-12 19:34:02 --> Output Class Initialized
INFO - 2016-12-12 19:34:02 --> Security Class Initialized
DEBUG - 2016-12-12 19:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 19:34:02 --> Input Class Initialized
INFO - 2016-12-12 19:34:02 --> Language Class Initialized
INFO - 2016-12-12 19:34:02 --> Loader Class Initialized
INFO - 2016-12-12 19:34:02 --> Database Driver Class Initialized
INFO - 2016-12-12 19:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 19:34:02 --> Controller Class Initialized
INFO - 2016-12-12 19:34:02 --> Upload Class Initialized
DEBUG - 2016-12-12 19:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 19:34:02 --> Helper loaded: url_helper
INFO - 2016-12-12 19:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 19:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-12 19:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-12 19:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-12 19:34:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-12 19:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 19:34:02 --> Final output sent to browser
DEBUG - 2016-12-12 19:34:02 --> Total execution time: 0.2595
INFO - 2016-12-12 19:34:03 --> Config Class Initialized
INFO - 2016-12-12 19:34:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 19:34:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 19:34:03 --> Utf8 Class Initialized
INFO - 2016-12-12 19:34:03 --> URI Class Initialized
INFO - 2016-12-12 19:34:03 --> Router Class Initialized
INFO - 2016-12-12 19:34:03 --> Output Class Initialized
INFO - 2016-12-12 19:34:03 --> Security Class Initialized
DEBUG - 2016-12-12 19:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 19:34:03 --> Input Class Initialized
INFO - 2016-12-12 19:34:03 --> Language Class Initialized
INFO - 2016-12-12 19:34:03 --> Loader Class Initialized
INFO - 2016-12-12 19:34:03 --> Database Driver Class Initialized
INFO - 2016-12-12 19:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 19:34:03 --> Controller Class Initialized
INFO - 2016-12-12 19:34:03 --> Helper loaded: url_helper
DEBUG - 2016-12-12 19:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 19:34:03 --> Final output sent to browser
DEBUG - 2016-12-12 19:34:03 --> Total execution time: 0.0139
INFO - 2016-12-12 19:34:03 --> Config Class Initialized
INFO - 2016-12-12 19:34:03 --> Hooks Class Initialized
DEBUG - 2016-12-12 19:34:03 --> UTF-8 Support Enabled
INFO - 2016-12-12 19:34:03 --> Utf8 Class Initialized
INFO - 2016-12-12 19:34:03 --> URI Class Initialized
INFO - 2016-12-12 19:34:03 --> Router Class Initialized
INFO - 2016-12-12 19:34:03 --> Output Class Initialized
INFO - 2016-12-12 19:34:03 --> Security Class Initialized
DEBUG - 2016-12-12 19:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 19:34:03 --> Input Class Initialized
INFO - 2016-12-12 19:34:03 --> Language Class Initialized
INFO - 2016-12-12 19:34:03 --> Loader Class Initialized
INFO - 2016-12-12 19:34:03 --> Database Driver Class Initialized
INFO - 2016-12-12 19:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 19:34:03 --> Controller Class Initialized
INFO - 2016-12-12 19:34:03 --> Helper loaded: url_helper
DEBUG - 2016-12-12 19:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 19:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 19:34:03 --> Final output sent to browser
DEBUG - 2016-12-12 19:34:03 --> Total execution time: 0.0131
INFO - 2016-12-12 22:35:39 --> Config Class Initialized
INFO - 2016-12-12 22:35:39 --> Hooks Class Initialized
DEBUG - 2016-12-12 22:35:39 --> UTF-8 Support Enabled
INFO - 2016-12-12 22:35:39 --> Utf8 Class Initialized
INFO - 2016-12-12 22:35:39 --> URI Class Initialized
DEBUG - 2016-12-12 22:35:39 --> No URI present. Default controller set.
INFO - 2016-12-12 22:35:39 --> Router Class Initialized
INFO - 2016-12-12 22:35:39 --> Output Class Initialized
INFO - 2016-12-12 22:35:39 --> Security Class Initialized
DEBUG - 2016-12-12 22:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 22:35:39 --> Input Class Initialized
INFO - 2016-12-12 22:35:39 --> Language Class Initialized
INFO - 2016-12-12 22:35:39 --> Loader Class Initialized
INFO - 2016-12-12 22:35:40 --> Database Driver Class Initialized
INFO - 2016-12-12 22:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 22:35:40 --> Controller Class Initialized
INFO - 2016-12-12 22:35:40 --> Helper loaded: url_helper
DEBUG - 2016-12-12 22:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 22:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 22:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 22:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 22:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 22:35:41 --> Final output sent to browser
DEBUG - 2016-12-12 22:35:41 --> Total execution time: 1.9231
INFO - 2016-12-12 23:48:31 --> Config Class Initialized
INFO - 2016-12-12 23:48:32 --> Hooks Class Initialized
DEBUG - 2016-12-12 23:48:32 --> UTF-8 Support Enabled
INFO - 2016-12-12 23:48:32 --> Utf8 Class Initialized
INFO - 2016-12-12 23:48:32 --> URI Class Initialized
INFO - 2016-12-12 23:48:32 --> Router Class Initialized
INFO - 2016-12-12 23:48:32 --> Output Class Initialized
INFO - 2016-12-12 23:48:32 --> Security Class Initialized
DEBUG - 2016-12-12 23:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 23:48:32 --> Input Class Initialized
INFO - 2016-12-12 23:48:32 --> Language Class Initialized
INFO - 2016-12-12 23:48:32 --> Loader Class Initialized
INFO - 2016-12-12 23:48:32 --> Database Driver Class Initialized
INFO - 2016-12-12 23:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 23:48:32 --> Controller Class Initialized
DEBUG - 2016-12-12 23:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 23:48:32 --> Helper loaded: url_helper
INFO - 2016-12-12 23:48:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 23:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-12 23:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-12 23:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 23:48:33 --> Final output sent to browser
DEBUG - 2016-12-12 23:48:33 --> Total execution time: 1.2630
INFO - 2016-12-12 23:48:34 --> Config Class Initialized
INFO - 2016-12-12 23:48:34 --> Hooks Class Initialized
DEBUG - 2016-12-12 23:48:34 --> UTF-8 Support Enabled
INFO - 2016-12-12 23:48:34 --> Utf8 Class Initialized
INFO - 2016-12-12 23:48:34 --> URI Class Initialized
DEBUG - 2016-12-12 23:48:34 --> No URI present. Default controller set.
INFO - 2016-12-12 23:48:34 --> Router Class Initialized
INFO - 2016-12-12 23:48:34 --> Output Class Initialized
INFO - 2016-12-12 23:48:34 --> Security Class Initialized
DEBUG - 2016-12-12 23:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-12 23:48:34 --> Input Class Initialized
INFO - 2016-12-12 23:48:34 --> Language Class Initialized
INFO - 2016-12-12 23:48:34 --> Loader Class Initialized
INFO - 2016-12-12 23:48:34 --> Database Driver Class Initialized
INFO - 2016-12-12 23:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-12 23:48:34 --> Controller Class Initialized
INFO - 2016-12-12 23:48:34 --> Helper loaded: url_helper
DEBUG - 2016-12-12 23:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-12 23:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-12 23:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-12 23:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-12 23:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-12 23:48:34 --> Final output sent to browser
DEBUG - 2016-12-12 23:48:34 --> Total execution time: 0.0448

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-02 00:39:31 --> Config Class Initialized
INFO - 2017-03-02 00:39:32 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:39:32 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:39:32 --> Utf8 Class Initialized
INFO - 2017-03-02 00:39:32 --> URI Class Initialized
DEBUG - 2017-03-02 00:39:32 --> No URI present. Default controller set.
INFO - 2017-03-02 00:39:32 --> Router Class Initialized
INFO - 2017-03-02 00:39:32 --> Output Class Initialized
INFO - 2017-03-02 00:39:32 --> Security Class Initialized
DEBUG - 2017-03-02 00:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:39:32 --> Input Class Initialized
INFO - 2017-03-02 00:39:32 --> Language Class Initialized
INFO - 2017-03-02 00:39:32 --> Loader Class Initialized
INFO - 2017-03-02 00:39:32 --> Database Driver Class Initialized
INFO - 2017-03-02 00:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:39:32 --> Controller Class Initialized
INFO - 2017-03-02 00:39:33 --> Helper loaded: url_helper
DEBUG - 2017-03-02 00:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 00:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 00:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 00:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 00:39:33 --> Final output sent to browser
DEBUG - 2017-03-02 00:39:33 --> Total execution time: 1.6210
INFO - 2017-03-02 00:54:52 --> Config Class Initialized
INFO - 2017-03-02 00:54:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:54:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:54:52 --> Utf8 Class Initialized
INFO - 2017-03-02 00:54:52 --> URI Class Initialized
DEBUG - 2017-03-02 00:54:52 --> No URI present. Default controller set.
INFO - 2017-03-02 00:54:52 --> Router Class Initialized
INFO - 2017-03-02 00:54:52 --> Output Class Initialized
INFO - 2017-03-02 00:54:52 --> Security Class Initialized
DEBUG - 2017-03-02 00:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:54:52 --> Input Class Initialized
INFO - 2017-03-02 00:54:52 --> Language Class Initialized
INFO - 2017-03-02 00:54:52 --> Loader Class Initialized
INFO - 2017-03-02 00:54:53 --> Database Driver Class Initialized
INFO - 2017-03-02 00:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:54:53 --> Controller Class Initialized
INFO - 2017-03-02 00:54:53 --> Helper loaded: url_helper
DEBUG - 2017-03-02 00:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 00:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 00:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 00:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 00:54:53 --> Final output sent to browser
DEBUG - 2017-03-02 00:54:53 --> Total execution time: 1.2095
INFO - 2017-03-02 00:55:46 --> Config Class Initialized
INFO - 2017-03-02 00:55:46 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:55:46 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:55:46 --> Utf8 Class Initialized
INFO - 2017-03-02 00:55:46 --> URI Class Initialized
INFO - 2017-03-02 00:55:46 --> Router Class Initialized
INFO - 2017-03-02 00:55:46 --> Output Class Initialized
INFO - 2017-03-02 00:55:46 --> Security Class Initialized
DEBUG - 2017-03-02 00:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:55:46 --> Input Class Initialized
INFO - 2017-03-02 00:55:46 --> Language Class Initialized
INFO - 2017-03-02 00:55:47 --> Loader Class Initialized
INFO - 2017-03-02 00:55:47 --> Database Driver Class Initialized
INFO - 2017-03-02 00:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:55:47 --> Controller Class Initialized
INFO - 2017-03-02 00:55:47 --> Helper loaded: url_helper
DEBUG - 2017-03-02 00:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:55:49 --> Config Class Initialized
INFO - 2017-03-02 00:55:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:55:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:55:49 --> Utf8 Class Initialized
INFO - 2017-03-02 00:55:49 --> URI Class Initialized
INFO - 2017-03-02 00:55:50 --> Router Class Initialized
INFO - 2017-03-02 00:55:50 --> Output Class Initialized
INFO - 2017-03-02 00:55:50 --> Security Class Initialized
DEBUG - 2017-03-02 00:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:55:50 --> Input Class Initialized
INFO - 2017-03-02 00:55:50 --> Language Class Initialized
INFO - 2017-03-02 00:55:50 --> Loader Class Initialized
INFO - 2017-03-02 00:55:50 --> Database Driver Class Initialized
INFO - 2017-03-02 00:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:55:50 --> Controller Class Initialized
INFO - 2017-03-02 00:55:50 --> Helper loaded: date_helper
DEBUG - 2017-03-02 00:55:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:55:50 --> Helper loaded: url_helper
INFO - 2017-03-02 00:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 00:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 00:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 00:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 00:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 00:55:50 --> Final output sent to browser
DEBUG - 2017-03-02 00:55:50 --> Total execution time: 0.4728
INFO - 2017-03-02 00:56:01 --> Config Class Initialized
INFO - 2017-03-02 00:56:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:56:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:56:01 --> Utf8 Class Initialized
INFO - 2017-03-02 00:56:01 --> URI Class Initialized
INFO - 2017-03-02 00:56:01 --> Router Class Initialized
INFO - 2017-03-02 00:56:01 --> Output Class Initialized
INFO - 2017-03-02 00:56:01 --> Security Class Initialized
DEBUG - 2017-03-02 00:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:56:01 --> Input Class Initialized
INFO - 2017-03-02 00:56:01 --> Language Class Initialized
INFO - 2017-03-02 00:56:01 --> Loader Class Initialized
INFO - 2017-03-02 00:56:01 --> Database Driver Class Initialized
INFO - 2017-03-02 00:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:56:01 --> Controller Class Initialized
INFO - 2017-03-02 00:56:01 --> Helper loaded: date_helper
DEBUG - 2017-03-02 00:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:56:01 --> Helper loaded: url_helper
INFO - 2017-03-02 00:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 00:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 00:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 00:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 00:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 00:56:01 --> Final output sent to browser
DEBUG - 2017-03-02 00:56:01 --> Total execution time: 0.0142
INFO - 2017-03-02 00:56:06 --> Config Class Initialized
INFO - 2017-03-02 00:56:06 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:56:06 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:56:06 --> Utf8 Class Initialized
INFO - 2017-03-02 00:56:06 --> URI Class Initialized
INFO - 2017-03-02 00:56:06 --> Router Class Initialized
INFO - 2017-03-02 00:56:06 --> Output Class Initialized
INFO - 2017-03-02 00:56:06 --> Security Class Initialized
DEBUG - 2017-03-02 00:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:56:06 --> Input Class Initialized
INFO - 2017-03-02 00:56:06 --> Language Class Initialized
INFO - 2017-03-02 00:56:06 --> Loader Class Initialized
INFO - 2017-03-02 00:56:06 --> Database Driver Class Initialized
INFO - 2017-03-02 00:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:56:06 --> Controller Class Initialized
INFO - 2017-03-02 00:56:06 --> Helper loaded: url_helper
DEBUG - 2017-03-02 00:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:56:07 --> Config Class Initialized
INFO - 2017-03-02 00:56:07 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:56:07 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:56:07 --> Utf8 Class Initialized
INFO - 2017-03-02 00:56:07 --> URI Class Initialized
INFO - 2017-03-02 00:56:07 --> Router Class Initialized
INFO - 2017-03-02 00:56:07 --> Output Class Initialized
INFO - 2017-03-02 00:56:07 --> Security Class Initialized
DEBUG - 2017-03-02 00:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:56:07 --> Input Class Initialized
INFO - 2017-03-02 00:56:07 --> Language Class Initialized
INFO - 2017-03-02 00:56:07 --> Loader Class Initialized
INFO - 2017-03-02 00:56:07 --> Database Driver Class Initialized
INFO - 2017-03-02 00:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:56:07 --> Controller Class Initialized
INFO - 2017-03-02 00:56:07 --> Helper loaded: date_helper
DEBUG - 2017-03-02 00:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:56:07 --> Helper loaded: url_helper
INFO - 2017-03-02 00:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 00:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 00:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 00:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 00:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 00:56:07 --> Final output sent to browser
DEBUG - 2017-03-02 00:56:07 --> Total execution time: 0.0159
INFO - 2017-03-02 00:56:12 --> Config Class Initialized
INFO - 2017-03-02 00:56:12 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:56:12 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:56:12 --> Utf8 Class Initialized
INFO - 2017-03-02 00:56:12 --> URI Class Initialized
DEBUG - 2017-03-02 00:56:12 --> No URI present. Default controller set.
INFO - 2017-03-02 00:56:12 --> Router Class Initialized
INFO - 2017-03-02 00:56:12 --> Output Class Initialized
INFO - 2017-03-02 00:56:12 --> Security Class Initialized
DEBUG - 2017-03-02 00:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:56:12 --> Input Class Initialized
INFO - 2017-03-02 00:56:12 --> Language Class Initialized
INFO - 2017-03-02 00:56:12 --> Loader Class Initialized
INFO - 2017-03-02 00:56:12 --> Database Driver Class Initialized
INFO - 2017-03-02 00:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:56:12 --> Controller Class Initialized
INFO - 2017-03-02 00:56:12 --> Helper loaded: url_helper
DEBUG - 2017-03-02 00:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 00:56:13 --> Final output sent to browser
DEBUG - 2017-03-02 00:56:13 --> Total execution time: 0.9218
INFO - 2017-03-02 00:57:14 --> Config Class Initialized
INFO - 2017-03-02 00:57:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:57:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:57:14 --> Utf8 Class Initialized
INFO - 2017-03-02 00:57:14 --> URI Class Initialized
DEBUG - 2017-03-02 00:57:14 --> No URI present. Default controller set.
INFO - 2017-03-02 00:57:14 --> Router Class Initialized
INFO - 2017-03-02 00:57:14 --> Output Class Initialized
INFO - 2017-03-02 00:57:14 --> Security Class Initialized
DEBUG - 2017-03-02 00:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:57:14 --> Input Class Initialized
INFO - 2017-03-02 00:57:14 --> Language Class Initialized
INFO - 2017-03-02 00:57:14 --> Loader Class Initialized
INFO - 2017-03-02 00:57:14 --> Database Driver Class Initialized
INFO - 2017-03-02 00:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:57:14 --> Controller Class Initialized
INFO - 2017-03-02 00:57:14 --> Helper loaded: url_helper
DEBUG - 2017-03-02 00:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 00:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 00:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 00:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 00:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 00:57:15 --> Final output sent to browser
DEBUG - 2017-03-02 00:57:15 --> Total execution time: 1.3057
INFO - 2017-03-02 01:12:23 --> Config Class Initialized
INFO - 2017-03-02 01:12:23 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:12:24 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:12:24 --> Utf8 Class Initialized
INFO - 2017-03-02 01:12:24 --> URI Class Initialized
INFO - 2017-03-02 01:12:24 --> Router Class Initialized
INFO - 2017-03-02 01:12:24 --> Output Class Initialized
INFO - 2017-03-02 01:12:24 --> Security Class Initialized
DEBUG - 2017-03-02 01:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:12:24 --> Input Class Initialized
INFO - 2017-03-02 01:12:24 --> Language Class Initialized
INFO - 2017-03-02 01:12:24 --> Loader Class Initialized
INFO - 2017-03-02 01:12:24 --> Database Driver Class Initialized
INFO - 2017-03-02 01:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:12:25 --> Controller Class Initialized
INFO - 2017-03-02 01:12:25 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:12:25 --> Final output sent to browser
DEBUG - 2017-03-02 01:12:25 --> Total execution time: 1.7542
INFO - 2017-03-02 01:14:35 --> Config Class Initialized
INFO - 2017-03-02 01:14:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:14:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:14:35 --> Utf8 Class Initialized
INFO - 2017-03-02 01:14:35 --> URI Class Initialized
DEBUG - 2017-03-02 01:14:35 --> No URI present. Default controller set.
INFO - 2017-03-02 01:14:35 --> Router Class Initialized
INFO - 2017-03-02 01:14:35 --> Output Class Initialized
INFO - 2017-03-02 01:14:35 --> Security Class Initialized
DEBUG - 2017-03-02 01:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:14:35 --> Input Class Initialized
INFO - 2017-03-02 01:14:35 --> Language Class Initialized
INFO - 2017-03-02 01:14:35 --> Loader Class Initialized
INFO - 2017-03-02 01:14:35 --> Database Driver Class Initialized
INFO - 2017-03-02 01:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:14:35 --> Controller Class Initialized
INFO - 2017-03-02 01:14:35 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:14:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:14:36 --> Final output sent to browser
DEBUG - 2017-03-02 01:14:36 --> Total execution time: 1.2704
INFO - 2017-03-02 01:14:44 --> Config Class Initialized
INFO - 2017-03-02 01:14:44 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:14:44 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:14:44 --> Utf8 Class Initialized
INFO - 2017-03-02 01:14:44 --> URI Class Initialized
INFO - 2017-03-02 01:14:44 --> Router Class Initialized
INFO - 2017-03-02 01:14:44 --> Output Class Initialized
INFO - 2017-03-02 01:14:44 --> Security Class Initialized
DEBUG - 2017-03-02 01:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:14:44 --> Input Class Initialized
INFO - 2017-03-02 01:14:44 --> Language Class Initialized
INFO - 2017-03-02 01:14:44 --> Loader Class Initialized
INFO - 2017-03-02 01:14:44 --> Database Driver Class Initialized
INFO - 2017-03-02 01:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:14:44 --> Controller Class Initialized
INFO - 2017-03-02 01:14:44 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:14:44 --> Final output sent to browser
DEBUG - 2017-03-02 01:14:44 --> Total execution time: 0.0297
INFO - 2017-03-02 01:15:17 --> Config Class Initialized
INFO - 2017-03-02 01:15:17 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:15:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:15:18 --> Utf8 Class Initialized
INFO - 2017-03-02 01:15:18 --> URI Class Initialized
INFO - 2017-03-02 01:15:18 --> Router Class Initialized
INFO - 2017-03-02 01:15:18 --> Output Class Initialized
INFO - 2017-03-02 01:15:18 --> Security Class Initialized
DEBUG - 2017-03-02 01:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:15:18 --> Input Class Initialized
INFO - 2017-03-02 01:15:18 --> Language Class Initialized
INFO - 2017-03-02 01:15:18 --> Loader Class Initialized
INFO - 2017-03-02 01:15:18 --> Database Driver Class Initialized
INFO - 2017-03-02 01:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:15:19 --> Controller Class Initialized
INFO - 2017-03-02 01:15:19 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:15:21 --> Config Class Initialized
INFO - 2017-03-02 01:15:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:15:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:15:21 --> Utf8 Class Initialized
INFO - 2017-03-02 01:15:21 --> URI Class Initialized
INFO - 2017-03-02 01:15:21 --> Router Class Initialized
INFO - 2017-03-02 01:15:21 --> Output Class Initialized
INFO - 2017-03-02 01:15:21 --> Security Class Initialized
DEBUG - 2017-03-02 01:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:15:21 --> Input Class Initialized
INFO - 2017-03-02 01:15:21 --> Language Class Initialized
INFO - 2017-03-02 01:15:21 --> Loader Class Initialized
INFO - 2017-03-02 01:15:21 --> Database Driver Class Initialized
INFO - 2017-03-02 01:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:15:21 --> Controller Class Initialized
INFO - 2017-03-02 01:15:21 --> Helper loaded: date_helper
DEBUG - 2017-03-02 01:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:15:21 --> Helper loaded: url_helper
INFO - 2017-03-02 01:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 01:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 01:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 01:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:15:21 --> Final output sent to browser
DEBUG - 2017-03-02 01:15:21 --> Total execution time: 0.2036
INFO - 2017-03-02 01:15:21 --> Config Class Initialized
INFO - 2017-03-02 01:15:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:15:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:15:21 --> Utf8 Class Initialized
INFO - 2017-03-02 01:15:21 --> URI Class Initialized
INFO - 2017-03-02 01:15:21 --> Router Class Initialized
INFO - 2017-03-02 01:15:21 --> Output Class Initialized
INFO - 2017-03-02 01:15:21 --> Security Class Initialized
DEBUG - 2017-03-02 01:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:15:21 --> Input Class Initialized
INFO - 2017-03-02 01:15:21 --> Language Class Initialized
INFO - 2017-03-02 01:15:21 --> Loader Class Initialized
INFO - 2017-03-02 01:15:21 --> Database Driver Class Initialized
INFO - 2017-03-02 01:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:15:21 --> Controller Class Initialized
INFO - 2017-03-02 01:15:21 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:15:22 --> Final output sent to browser
DEBUG - 2017-03-02 01:15:22 --> Total execution time: 0.0517
INFO - 2017-03-02 01:15:33 --> Config Class Initialized
INFO - 2017-03-02 01:15:33 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:15:33 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:15:33 --> Utf8 Class Initialized
INFO - 2017-03-02 01:15:33 --> URI Class Initialized
DEBUG - 2017-03-02 01:15:33 --> No URI present. Default controller set.
INFO - 2017-03-02 01:15:33 --> Router Class Initialized
INFO - 2017-03-02 01:15:33 --> Output Class Initialized
INFO - 2017-03-02 01:15:33 --> Security Class Initialized
DEBUG - 2017-03-02 01:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:15:33 --> Input Class Initialized
INFO - 2017-03-02 01:15:33 --> Language Class Initialized
INFO - 2017-03-02 01:15:33 --> Loader Class Initialized
INFO - 2017-03-02 01:15:33 --> Database Driver Class Initialized
INFO - 2017-03-02 01:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:15:33 --> Controller Class Initialized
INFO - 2017-03-02 01:15:33 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:15:33 --> Final output sent to browser
DEBUG - 2017-03-02 01:15:33 --> Total execution time: 0.0142
INFO - 2017-03-02 01:15:34 --> Config Class Initialized
INFO - 2017-03-02 01:15:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:15:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:15:34 --> Utf8 Class Initialized
INFO - 2017-03-02 01:15:34 --> URI Class Initialized
INFO - 2017-03-02 01:15:34 --> Router Class Initialized
INFO - 2017-03-02 01:15:34 --> Output Class Initialized
INFO - 2017-03-02 01:15:34 --> Security Class Initialized
DEBUG - 2017-03-02 01:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:15:34 --> Input Class Initialized
INFO - 2017-03-02 01:15:34 --> Language Class Initialized
INFO - 2017-03-02 01:15:34 --> Loader Class Initialized
INFO - 2017-03-02 01:15:34 --> Database Driver Class Initialized
INFO - 2017-03-02 01:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:15:34 --> Controller Class Initialized
INFO - 2017-03-02 01:15:34 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:15:34 --> Final output sent to browser
DEBUG - 2017-03-02 01:15:34 --> Total execution time: 0.0148
INFO - 2017-03-02 01:15:49 --> Config Class Initialized
INFO - 2017-03-02 01:15:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:15:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:15:49 --> Utf8 Class Initialized
INFO - 2017-03-02 01:15:49 --> URI Class Initialized
INFO - 2017-03-02 01:15:49 --> Router Class Initialized
INFO - 2017-03-02 01:15:49 --> Output Class Initialized
INFO - 2017-03-02 01:15:49 --> Security Class Initialized
DEBUG - 2017-03-02 01:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:15:49 --> Input Class Initialized
INFO - 2017-03-02 01:15:49 --> Language Class Initialized
INFO - 2017-03-02 01:15:49 --> Loader Class Initialized
INFO - 2017-03-02 01:15:49 --> Database Driver Class Initialized
INFO - 2017-03-02 01:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:15:50 --> Controller Class Initialized
INFO - 2017-03-02 01:15:50 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:15:50 --> Final output sent to browser
DEBUG - 2017-03-02 01:15:50 --> Total execution time: 0.2802
INFO - 2017-03-02 01:15:51 --> Config Class Initialized
INFO - 2017-03-02 01:15:51 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:15:51 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:15:51 --> Utf8 Class Initialized
INFO - 2017-03-02 01:15:51 --> URI Class Initialized
INFO - 2017-03-02 01:15:51 --> Router Class Initialized
INFO - 2017-03-02 01:15:51 --> Output Class Initialized
INFO - 2017-03-02 01:15:51 --> Security Class Initialized
DEBUG - 2017-03-02 01:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:15:51 --> Input Class Initialized
INFO - 2017-03-02 01:15:51 --> Language Class Initialized
INFO - 2017-03-02 01:15:51 --> Loader Class Initialized
INFO - 2017-03-02 01:15:51 --> Database Driver Class Initialized
INFO - 2017-03-02 01:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:15:51 --> Controller Class Initialized
INFO - 2017-03-02 01:15:51 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:15:51 --> Final output sent to browser
DEBUG - 2017-03-02 01:15:51 --> Total execution time: 0.0145
INFO - 2017-03-02 01:16:12 --> Config Class Initialized
INFO - 2017-03-02 01:16:12 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:16:12 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:16:12 --> Utf8 Class Initialized
INFO - 2017-03-02 01:16:12 --> URI Class Initialized
INFO - 2017-03-02 01:16:12 --> Router Class Initialized
INFO - 2017-03-02 01:16:12 --> Output Class Initialized
INFO - 2017-03-02 01:16:12 --> Security Class Initialized
DEBUG - 2017-03-02 01:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:16:12 --> Input Class Initialized
INFO - 2017-03-02 01:16:12 --> Language Class Initialized
INFO - 2017-03-02 01:16:12 --> Loader Class Initialized
INFO - 2017-03-02 01:16:12 --> Database Driver Class Initialized
INFO - 2017-03-02 01:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:16:12 --> Controller Class Initialized
INFO - 2017-03-02 01:16:12 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:16:12 --> Config Class Initialized
INFO - 2017-03-02 01:16:12 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:16:12 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:16:12 --> Utf8 Class Initialized
INFO - 2017-03-02 01:16:12 --> URI Class Initialized
INFO - 2017-03-02 01:16:12 --> Router Class Initialized
INFO - 2017-03-02 01:16:12 --> Output Class Initialized
INFO - 2017-03-02 01:16:12 --> Security Class Initialized
DEBUG - 2017-03-02 01:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:16:12 --> Input Class Initialized
INFO - 2017-03-02 01:16:12 --> Language Class Initialized
INFO - 2017-03-02 01:16:12 --> Loader Class Initialized
INFO - 2017-03-02 01:16:12 --> Database Driver Class Initialized
INFO - 2017-03-02 01:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:16:12 --> Controller Class Initialized
INFO - 2017-03-02 01:16:12 --> Helper loaded: date_helper
DEBUG - 2017-03-02 01:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:16:12 --> Helper loaded: url_helper
INFO - 2017-03-02 01:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 01:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 01:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 01:16:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:16:12 --> Final output sent to browser
DEBUG - 2017-03-02 01:16:12 --> Total execution time: 0.0147
INFO - 2017-03-02 01:16:13 --> Config Class Initialized
INFO - 2017-03-02 01:16:13 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:16:13 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:16:13 --> Utf8 Class Initialized
INFO - 2017-03-02 01:16:13 --> URI Class Initialized
INFO - 2017-03-02 01:16:13 --> Router Class Initialized
INFO - 2017-03-02 01:16:13 --> Output Class Initialized
INFO - 2017-03-02 01:16:13 --> Security Class Initialized
DEBUG - 2017-03-02 01:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:16:13 --> Input Class Initialized
INFO - 2017-03-02 01:16:13 --> Language Class Initialized
INFO - 2017-03-02 01:16:13 --> Loader Class Initialized
INFO - 2017-03-02 01:16:13 --> Database Driver Class Initialized
INFO - 2017-03-02 01:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:16:13 --> Controller Class Initialized
INFO - 2017-03-02 01:16:13 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:16:13 --> Final output sent to browser
DEBUG - 2017-03-02 01:16:13 --> Total execution time: 0.0138
INFO - 2017-03-02 01:17:39 --> Config Class Initialized
INFO - 2017-03-02 01:17:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:17:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:17:39 --> Utf8 Class Initialized
INFO - 2017-03-02 01:17:39 --> URI Class Initialized
DEBUG - 2017-03-02 01:17:39 --> No URI present. Default controller set.
INFO - 2017-03-02 01:17:39 --> Router Class Initialized
INFO - 2017-03-02 01:17:39 --> Output Class Initialized
INFO - 2017-03-02 01:17:39 --> Security Class Initialized
DEBUG - 2017-03-02 01:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:17:39 --> Input Class Initialized
INFO - 2017-03-02 01:17:39 --> Language Class Initialized
INFO - 2017-03-02 01:17:39 --> Loader Class Initialized
INFO - 2017-03-02 01:17:39 --> Database Driver Class Initialized
INFO - 2017-03-02 01:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:17:39 --> Controller Class Initialized
INFO - 2017-03-02 01:17:39 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:17:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:17:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:17:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:17:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:17:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:17:39 --> Final output sent to browser
DEBUG - 2017-03-02 01:17:39 --> Total execution time: 0.0150
INFO - 2017-03-02 01:17:40 --> Config Class Initialized
INFO - 2017-03-02 01:17:40 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:17:40 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:17:40 --> Utf8 Class Initialized
INFO - 2017-03-02 01:17:40 --> URI Class Initialized
INFO - 2017-03-02 01:17:40 --> Router Class Initialized
INFO - 2017-03-02 01:17:40 --> Output Class Initialized
INFO - 2017-03-02 01:17:40 --> Security Class Initialized
DEBUG - 2017-03-02 01:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:17:40 --> Input Class Initialized
INFO - 2017-03-02 01:17:40 --> Language Class Initialized
INFO - 2017-03-02 01:17:40 --> Loader Class Initialized
INFO - 2017-03-02 01:17:40 --> Database Driver Class Initialized
INFO - 2017-03-02 01:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:17:40 --> Controller Class Initialized
INFO - 2017-03-02 01:17:40 --> Helper loaded: url_helper
DEBUG - 2017-03-02 01:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 01:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 01:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 01:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 01:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 01:17:40 --> Final output sent to browser
DEBUG - 2017-03-02 01:17:40 --> Total execution time: 0.0145
INFO - 2017-03-02 02:21:25 --> Config Class Initialized
INFO - 2017-03-02 02:21:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:21:26 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:21:26 --> Utf8 Class Initialized
INFO - 2017-03-02 02:21:26 --> URI Class Initialized
DEBUG - 2017-03-02 02:21:26 --> No URI present. Default controller set.
INFO - 2017-03-02 02:21:26 --> Router Class Initialized
INFO - 2017-03-02 02:21:26 --> Output Class Initialized
INFO - 2017-03-02 02:21:26 --> Security Class Initialized
DEBUG - 2017-03-02 02:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:21:26 --> Input Class Initialized
INFO - 2017-03-02 02:21:26 --> Language Class Initialized
INFO - 2017-03-02 02:21:26 --> Loader Class Initialized
INFO - 2017-03-02 02:21:26 --> Database Driver Class Initialized
INFO - 2017-03-02 02:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:21:27 --> Controller Class Initialized
INFO - 2017-03-02 02:21:27 --> Helper loaded: url_helper
DEBUG - 2017-03-02 02:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 02:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 02:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 02:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 02:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 02:21:27 --> Final output sent to browser
DEBUG - 2017-03-02 02:21:27 --> Total execution time: 1.7676
INFO - 2017-03-02 02:43:15 --> Config Class Initialized
INFO - 2017-03-02 02:43:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:15 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:15 --> URI Class Initialized
DEBUG - 2017-03-02 02:43:15 --> No URI present. Default controller set.
INFO - 2017-03-02 02:43:15 --> Router Class Initialized
INFO - 2017-03-02 02:43:15 --> Output Class Initialized
INFO - 2017-03-02 02:43:15 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:15 --> Input Class Initialized
INFO - 2017-03-02 02:43:15 --> Language Class Initialized
INFO - 2017-03-02 02:43:15 --> Loader Class Initialized
INFO - 2017-03-02 02:43:16 --> Database Driver Class Initialized
INFO - 2017-03-02 02:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:16 --> Controller Class Initialized
INFO - 2017-03-02 02:43:16 --> Helper loaded: url_helper
DEBUG - 2017-03-02 02:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 02:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 02:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 02:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 02:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 02:43:16 --> Final output sent to browser
DEBUG - 2017-03-02 02:43:16 --> Total execution time: 1.7434
INFO - 2017-03-02 02:46:21 --> Config Class Initialized
INFO - 2017-03-02 02:46:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:21 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:21 --> URI Class Initialized
DEBUG - 2017-03-02 02:46:21 --> No URI present. Default controller set.
INFO - 2017-03-02 02:46:21 --> Router Class Initialized
INFO - 2017-03-02 02:46:21 --> Output Class Initialized
INFO - 2017-03-02 02:46:21 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:22 --> Input Class Initialized
INFO - 2017-03-02 02:46:22 --> Language Class Initialized
INFO - 2017-03-02 02:46:22 --> Loader Class Initialized
INFO - 2017-03-02 02:46:22 --> Database Driver Class Initialized
INFO - 2017-03-02 02:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:22 --> Controller Class Initialized
INFO - 2017-03-02 02:46:22 --> Helper loaded: url_helper
DEBUG - 2017-03-02 02:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 02:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 02:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 02:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 02:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 02:46:22 --> Final output sent to browser
DEBUG - 2017-03-02 02:46:22 --> Total execution time: 1.2625
INFO - 2017-03-02 02:52:25 --> Config Class Initialized
INFO - 2017-03-02 02:52:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:52:25 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:52:25 --> Utf8 Class Initialized
INFO - 2017-03-02 02:52:25 --> URI Class Initialized
DEBUG - 2017-03-02 02:52:25 --> No URI present. Default controller set.
INFO - 2017-03-02 02:52:25 --> Router Class Initialized
INFO - 2017-03-02 02:52:25 --> Output Class Initialized
INFO - 2017-03-02 02:52:25 --> Security Class Initialized
DEBUG - 2017-03-02 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:52:25 --> Input Class Initialized
INFO - 2017-03-02 02:52:25 --> Language Class Initialized
INFO - 2017-03-02 02:52:25 --> Loader Class Initialized
INFO - 2017-03-02 02:52:26 --> Database Driver Class Initialized
INFO - 2017-03-02 02:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:52:26 --> Controller Class Initialized
INFO - 2017-03-02 02:52:26 --> Helper loaded: url_helper
DEBUG - 2017-03-02 02:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 02:52:26 --> Final output sent to browser
DEBUG - 2017-03-02 02:52:26 --> Total execution time: 1.5243
INFO - 2017-03-02 04:17:15 --> Config Class Initialized
INFO - 2017-03-02 04:17:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 04:17:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 04:17:16 --> Utf8 Class Initialized
INFO - 2017-03-02 04:17:16 --> URI Class Initialized
DEBUG - 2017-03-02 04:17:16 --> No URI present. Default controller set.
INFO - 2017-03-02 04:17:16 --> Router Class Initialized
INFO - 2017-03-02 04:17:16 --> Output Class Initialized
INFO - 2017-03-02 04:17:16 --> Security Class Initialized
DEBUG - 2017-03-02 04:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 04:17:16 --> Input Class Initialized
INFO - 2017-03-02 04:17:16 --> Language Class Initialized
INFO - 2017-03-02 04:17:16 --> Loader Class Initialized
INFO - 2017-03-02 04:17:16 --> Database Driver Class Initialized
INFO - 2017-03-02 04:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 04:17:17 --> Controller Class Initialized
INFO - 2017-03-02 04:17:17 --> Helper loaded: url_helper
DEBUG - 2017-03-02 04:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 04:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 04:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 04:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 04:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 04:17:17 --> Final output sent to browser
DEBUG - 2017-03-02 04:17:17 --> Total execution time: 1.4521
INFO - 2017-03-02 04:17:24 --> Config Class Initialized
INFO - 2017-03-02 04:17:24 --> Hooks Class Initialized
DEBUG - 2017-03-02 04:17:24 --> UTF-8 Support Enabled
INFO - 2017-03-02 04:17:24 --> Utf8 Class Initialized
INFO - 2017-03-02 04:17:24 --> URI Class Initialized
INFO - 2017-03-02 04:17:24 --> Router Class Initialized
INFO - 2017-03-02 04:17:24 --> Output Class Initialized
INFO - 2017-03-02 04:17:24 --> Security Class Initialized
DEBUG - 2017-03-02 04:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 04:17:25 --> Input Class Initialized
INFO - 2017-03-02 04:17:25 --> Language Class Initialized
INFO - 2017-03-02 04:17:25 --> Loader Class Initialized
INFO - 2017-03-02 04:17:25 --> Database Driver Class Initialized
INFO - 2017-03-02 04:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 04:17:25 --> Controller Class Initialized
INFO - 2017-03-02 04:17:25 --> Helper loaded: url_helper
DEBUG - 2017-03-02 04:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 04:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 04:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 04:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 04:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 04:17:25 --> Final output sent to browser
DEBUG - 2017-03-02 04:17:25 --> Total execution time: 1.2212
INFO - 2017-03-02 04:18:14 --> Config Class Initialized
INFO - 2017-03-02 04:18:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 04:18:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 04:18:14 --> Utf8 Class Initialized
INFO - 2017-03-02 04:18:14 --> URI Class Initialized
DEBUG - 2017-03-02 04:18:14 --> No URI present. Default controller set.
INFO - 2017-03-02 04:18:14 --> Router Class Initialized
INFO - 2017-03-02 04:18:14 --> Output Class Initialized
INFO - 2017-03-02 04:18:14 --> Security Class Initialized
DEBUG - 2017-03-02 04:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 04:18:14 --> Input Class Initialized
INFO - 2017-03-02 04:18:14 --> Language Class Initialized
INFO - 2017-03-02 04:18:14 --> Loader Class Initialized
INFO - 2017-03-02 04:18:14 --> Database Driver Class Initialized
INFO - 2017-03-02 04:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 04:18:14 --> Controller Class Initialized
INFO - 2017-03-02 04:18:14 --> Helper loaded: url_helper
DEBUG - 2017-03-02 04:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 04:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 04:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 04:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 04:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 04:18:14 --> Final output sent to browser
DEBUG - 2017-03-02 04:18:14 --> Total execution time: 0.0577
INFO - 2017-03-02 04:18:17 --> Config Class Initialized
INFO - 2017-03-02 04:18:17 --> Hooks Class Initialized
DEBUG - 2017-03-02 04:18:17 --> UTF-8 Support Enabled
INFO - 2017-03-02 04:18:17 --> Utf8 Class Initialized
INFO - 2017-03-02 04:18:17 --> URI Class Initialized
INFO - 2017-03-02 04:18:17 --> Router Class Initialized
INFO - 2017-03-02 04:18:17 --> Output Class Initialized
INFO - 2017-03-02 04:18:17 --> Security Class Initialized
DEBUG - 2017-03-02 04:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 04:18:17 --> Input Class Initialized
INFO - 2017-03-02 04:18:17 --> Language Class Initialized
INFO - 2017-03-02 04:18:17 --> Loader Class Initialized
INFO - 2017-03-02 04:18:17 --> Database Driver Class Initialized
INFO - 2017-03-02 04:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 04:18:17 --> Controller Class Initialized
INFO - 2017-03-02 04:18:17 --> Helper loaded: url_helper
DEBUG - 2017-03-02 04:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 04:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 04:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 04:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 04:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 04:18:17 --> Final output sent to browser
DEBUG - 2017-03-02 04:18:17 --> Total execution time: 0.0139
INFO - 2017-03-02 04:19:52 --> Config Class Initialized
INFO - 2017-03-02 04:19:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 04:19:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 04:19:52 --> Utf8 Class Initialized
INFO - 2017-03-02 04:19:52 --> URI Class Initialized
INFO - 2017-03-02 04:19:52 --> Router Class Initialized
INFO - 2017-03-02 04:19:52 --> Output Class Initialized
INFO - 2017-03-02 04:19:52 --> Security Class Initialized
DEBUG - 2017-03-02 04:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 04:19:52 --> Input Class Initialized
INFO - 2017-03-02 04:19:52 --> Language Class Initialized
INFO - 2017-03-02 04:19:52 --> Loader Class Initialized
INFO - 2017-03-02 04:19:52 --> Database Driver Class Initialized
INFO - 2017-03-02 04:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 04:19:52 --> Controller Class Initialized
INFO - 2017-03-02 04:19:52 --> Helper loaded: url_helper
DEBUG - 2017-03-02 04:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 04:19:55 --> Config Class Initialized
INFO - 2017-03-02 04:19:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 04:19:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 04:19:55 --> Utf8 Class Initialized
INFO - 2017-03-02 04:19:55 --> URI Class Initialized
INFO - 2017-03-02 04:19:55 --> Router Class Initialized
INFO - 2017-03-02 04:19:55 --> Output Class Initialized
INFO - 2017-03-02 04:19:55 --> Security Class Initialized
DEBUG - 2017-03-02 04:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 04:19:55 --> Input Class Initialized
INFO - 2017-03-02 04:19:55 --> Language Class Initialized
INFO - 2017-03-02 04:19:55 --> Loader Class Initialized
INFO - 2017-03-02 04:19:55 --> Database Driver Class Initialized
INFO - 2017-03-02 04:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 04:19:55 --> Controller Class Initialized
INFO - 2017-03-02 04:19:55 --> Helper loaded: date_helper
DEBUG - 2017-03-02 04:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 04:19:55 --> Helper loaded: url_helper
INFO - 2017-03-02 04:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 04:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 04:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 04:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 04:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 04:19:55 --> Final output sent to browser
DEBUG - 2017-03-02 04:19:55 --> Total execution time: 0.1744
INFO - 2017-03-02 04:19:56 --> Config Class Initialized
INFO - 2017-03-02 04:19:56 --> Hooks Class Initialized
DEBUG - 2017-03-02 04:19:56 --> UTF-8 Support Enabled
INFO - 2017-03-02 04:19:56 --> Utf8 Class Initialized
INFO - 2017-03-02 04:19:56 --> URI Class Initialized
INFO - 2017-03-02 04:19:56 --> Router Class Initialized
INFO - 2017-03-02 04:19:56 --> Output Class Initialized
INFO - 2017-03-02 04:19:56 --> Security Class Initialized
DEBUG - 2017-03-02 04:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 04:19:56 --> Input Class Initialized
INFO - 2017-03-02 04:19:56 --> Language Class Initialized
INFO - 2017-03-02 04:19:56 --> Loader Class Initialized
INFO - 2017-03-02 04:19:56 --> Database Driver Class Initialized
INFO - 2017-03-02 04:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 04:19:56 --> Controller Class Initialized
INFO - 2017-03-02 04:19:56 --> Helper loaded: url_helper
DEBUG - 2017-03-02 04:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 04:19:56 --> Final output sent to browser
DEBUG - 2017-03-02 04:19:56 --> Total execution time: 0.0227
INFO - 2017-03-02 05:12:27 --> Config Class Initialized
INFO - 2017-03-02 05:12:27 --> Config Class Initialized
INFO - 2017-03-02 05:12:27 --> Hooks Class Initialized
INFO - 2017-03-02 05:12:27 --> Hooks Class Initialized
DEBUG - 2017-03-02 05:12:27 --> UTF-8 Support Enabled
DEBUG - 2017-03-02 05:12:27 --> UTF-8 Support Enabled
INFO - 2017-03-02 05:12:27 --> Utf8 Class Initialized
INFO - 2017-03-02 05:12:27 --> Utf8 Class Initialized
INFO - 2017-03-02 05:12:27 --> URI Class Initialized
INFO - 2017-03-02 05:12:27 --> URI Class Initialized
INFO - 2017-03-02 05:12:27 --> Router Class Initialized
INFO - 2017-03-02 05:12:27 --> Router Class Initialized
INFO - 2017-03-02 05:12:27 --> Output Class Initialized
INFO - 2017-03-02 05:12:27 --> Output Class Initialized
INFO - 2017-03-02 05:12:27 --> Security Class Initialized
INFO - 2017-03-02 05:12:27 --> Security Class Initialized
DEBUG - 2017-03-02 05:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 05:12:27 --> Input Class Initialized
INFO - 2017-03-02 05:12:27 --> Language Class Initialized
DEBUG - 2017-03-02 05:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 05:12:27 --> Input Class Initialized
INFO - 2017-03-02 05:12:27 --> Language Class Initialized
INFO - 2017-03-02 05:12:27 --> Loader Class Initialized
INFO - 2017-03-02 05:12:28 --> Loader Class Initialized
INFO - 2017-03-02 05:12:28 --> Database Driver Class Initialized
INFO - 2017-03-02 05:12:28 --> Database Driver Class Initialized
INFO - 2017-03-02 05:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 05:12:28 --> Controller Class Initialized
INFO - 2017-03-02 05:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 05:12:28 --> Controller Class Initialized
INFO - 2017-03-02 05:12:28 --> Helper loaded: url_helper
INFO - 2017-03-02 05:12:28 --> Helper loaded: url_helper
DEBUG - 2017-03-02 05:12:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-02 05:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 05:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 05:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-02 05:12:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-02 05:12:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-02 05:12:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-02 05:12:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
ERROR - 2017-03-02 05:12:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-02 05:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-02 05:12:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-02 05:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 05:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 05:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 05:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 05:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 05:12:29 --> Final output sent to browser
DEBUG - 2017-03-02 05:12:29 --> Total execution time: 1.5709
INFO - 2017-03-02 05:12:29 --> Final output sent to browser
DEBUG - 2017-03-02 05:12:29 --> Total execution time: 1.5711
INFO - 2017-03-02 05:12:36 --> Config Class Initialized
INFO - 2017-03-02 05:12:36 --> Hooks Class Initialized
DEBUG - 2017-03-02 05:12:36 --> UTF-8 Support Enabled
INFO - 2017-03-02 05:12:36 --> Utf8 Class Initialized
INFO - 2017-03-02 05:12:36 --> URI Class Initialized
INFO - 2017-03-02 05:12:36 --> Router Class Initialized
INFO - 2017-03-02 05:12:36 --> Output Class Initialized
INFO - 2017-03-02 05:12:37 --> Security Class Initialized
DEBUG - 2017-03-02 05:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 05:12:37 --> Input Class Initialized
INFO - 2017-03-02 05:12:37 --> Language Class Initialized
INFO - 2017-03-02 05:12:37 --> Loader Class Initialized
INFO - 2017-03-02 05:12:37 --> Database Driver Class Initialized
INFO - 2017-03-02 05:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 05:12:37 --> Controller Class Initialized
INFO - 2017-03-02 05:12:37 --> Helper loaded: url_helper
DEBUG - 2017-03-02 05:12:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 05:12:41 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 05:12:41 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Angelica Ortiz')
INFO - 2017-03-02 05:12:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 05:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 13:16:04 --> Config Class Initialized
INFO - 2017-03-02 13:16:04 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:16:04 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:16:04 --> Utf8 Class Initialized
INFO - 2017-03-02 13:16:04 --> URI Class Initialized
DEBUG - 2017-03-02 13:16:04 --> No URI present. Default controller set.
INFO - 2017-03-02 13:16:04 --> Router Class Initialized
INFO - 2017-03-02 13:16:04 --> Output Class Initialized
INFO - 2017-03-02 13:16:05 --> Security Class Initialized
DEBUG - 2017-03-02 13:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:16:05 --> Input Class Initialized
INFO - 2017-03-02 13:16:05 --> Language Class Initialized
INFO - 2017-03-02 13:16:05 --> Loader Class Initialized
INFO - 2017-03-02 13:16:05 --> Database Driver Class Initialized
INFO - 2017-03-02 13:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:16:05 --> Controller Class Initialized
INFO - 2017-03-02 13:16:05 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:16:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:16:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:16:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:16:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:16:06 --> Final output sent to browser
DEBUG - 2017-03-02 13:16:06 --> Total execution time: 1.4783
INFO - 2017-03-02 13:16:24 --> Config Class Initialized
INFO - 2017-03-02 13:16:24 --> Config Class Initialized
INFO - 2017-03-02 13:16:24 --> Hooks Class Initialized
INFO - 2017-03-02 13:16:24 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:16:24 --> UTF-8 Support Enabled
DEBUG - 2017-03-02 13:16:24 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:16:24 --> Utf8 Class Initialized
INFO - 2017-03-02 13:16:24 --> Utf8 Class Initialized
INFO - 2017-03-02 13:16:24 --> URI Class Initialized
INFO - 2017-03-02 13:16:24 --> URI Class Initialized
INFO - 2017-03-02 13:16:24 --> Router Class Initialized
INFO - 2017-03-02 13:16:24 --> Router Class Initialized
INFO - 2017-03-02 13:16:24 --> Output Class Initialized
INFO - 2017-03-02 13:16:24 --> Output Class Initialized
INFO - 2017-03-02 13:16:24 --> Security Class Initialized
INFO - 2017-03-02 13:16:24 --> Security Class Initialized
DEBUG - 2017-03-02 13:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:16:24 --> Input Class Initialized
INFO - 2017-03-02 13:16:24 --> Language Class Initialized
DEBUG - 2017-03-02 13:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:16:24 --> Input Class Initialized
INFO - 2017-03-02 13:16:24 --> Language Class Initialized
INFO - 2017-03-02 13:16:24 --> Loader Class Initialized
INFO - 2017-03-02 13:16:24 --> Loader Class Initialized
INFO - 2017-03-02 13:16:25 --> Database Driver Class Initialized
INFO - 2017-03-02 13:16:25 --> Database Driver Class Initialized
INFO - 2017-03-02 13:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:16:25 --> Controller Class Initialized
INFO - 2017-03-02 13:16:25 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:16:25 --> Controller Class Initialized
INFO - 2017-03-02 13:16:25 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-02 13:16:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-02 13:16:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-02 13:16:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-02 13:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:16:25 --> Final output sent to browser
DEBUG - 2017-03-02 13:16:25 --> Total execution time: 1.2341
INFO - 2017-03-02 13:16:27 --> Config Class Initialized
INFO - 2017-03-02 13:16:27 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:16:27 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:16:27 --> Utf8 Class Initialized
INFO - 2017-03-02 13:16:27 --> URI Class Initialized
INFO - 2017-03-02 13:16:27 --> Router Class Initialized
INFO - 2017-03-02 13:16:27 --> Output Class Initialized
INFO - 2017-03-02 13:16:27 --> Security Class Initialized
DEBUG - 2017-03-02 13:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:16:27 --> Input Class Initialized
INFO - 2017-03-02 13:16:27 --> Language Class Initialized
INFO - 2017-03-02 13:16:28 --> Loader Class Initialized
INFO - 2017-03-02 13:16:28 --> Database Driver Class Initialized
INFO - 2017-03-02 13:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:16:28 --> Controller Class Initialized
INFO - 2017-03-02 13:16:28 --> Helper loaded: date_helper
DEBUG - 2017-03-02 13:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:16:28 --> Helper loaded: url_helper
INFO - 2017-03-02 13:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 13:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 13:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 13:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:16:28 --> Final output sent to browser
DEBUG - 2017-03-02 13:16:28 --> Total execution time: 0.4887
INFO - 2017-03-02 13:17:10 --> Config Class Initialized
INFO - 2017-03-02 13:17:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:17:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:17:10 --> Utf8 Class Initialized
INFO - 2017-03-02 13:17:10 --> URI Class Initialized
DEBUG - 2017-03-02 13:17:10 --> No URI present. Default controller set.
INFO - 2017-03-02 13:17:10 --> Router Class Initialized
INFO - 2017-03-02 13:17:10 --> Output Class Initialized
INFO - 2017-03-02 13:17:10 --> Security Class Initialized
DEBUG - 2017-03-02 13:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:17:10 --> Input Class Initialized
INFO - 2017-03-02 13:17:10 --> Language Class Initialized
INFO - 2017-03-02 13:17:10 --> Loader Class Initialized
INFO - 2017-03-02 13:17:11 --> Database Driver Class Initialized
INFO - 2017-03-02 13:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:17:11 --> Controller Class Initialized
INFO - 2017-03-02 13:17:11 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:17:12 --> Final output sent to browser
DEBUG - 2017-03-02 13:17:12 --> Total execution time: 1.4797
INFO - 2017-03-02 13:17:27 --> Config Class Initialized
INFO - 2017-03-02 13:17:27 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:17:27 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:17:27 --> Utf8 Class Initialized
INFO - 2017-03-02 13:17:27 --> URI Class Initialized
INFO - 2017-03-02 13:17:27 --> Router Class Initialized
INFO - 2017-03-02 13:17:27 --> Output Class Initialized
INFO - 2017-03-02 13:17:27 --> Security Class Initialized
DEBUG - 2017-03-02 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:17:28 --> Input Class Initialized
INFO - 2017-03-02 13:17:28 --> Language Class Initialized
INFO - 2017-03-02 13:17:28 --> Loader Class Initialized
INFO - 2017-03-02 13:17:28 --> Database Driver Class Initialized
INFO - 2017-03-02 13:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:17:28 --> Controller Class Initialized
INFO - 2017-03-02 13:17:28 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:17:28 --> Final output sent to browser
DEBUG - 2017-03-02 13:17:28 --> Total execution time: 1.2099
INFO - 2017-03-02 13:17:51 --> Config Class Initialized
INFO - 2017-03-02 13:17:51 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:17:51 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:17:51 --> Utf8 Class Initialized
INFO - 2017-03-02 13:17:51 --> URI Class Initialized
DEBUG - 2017-03-02 13:17:51 --> No URI present. Default controller set.
INFO - 2017-03-02 13:17:51 --> Router Class Initialized
INFO - 2017-03-02 13:17:51 --> Output Class Initialized
INFO - 2017-03-02 13:17:51 --> Security Class Initialized
DEBUG - 2017-03-02 13:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:17:51 --> Input Class Initialized
INFO - 2017-03-02 13:17:51 --> Language Class Initialized
INFO - 2017-03-02 13:17:52 --> Loader Class Initialized
INFO - 2017-03-02 13:17:52 --> Database Driver Class Initialized
INFO - 2017-03-02 13:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:17:52 --> Controller Class Initialized
INFO - 2017-03-02 13:17:52 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:17:53 --> Final output sent to browser
DEBUG - 2017-03-02 13:17:53 --> Total execution time: 1.4689
INFO - 2017-03-02 13:18:17 --> Config Class Initialized
INFO - 2017-03-02 13:18:17 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:18:17 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:18:17 --> Utf8 Class Initialized
INFO - 2017-03-02 13:18:17 --> URI Class Initialized
INFO - 2017-03-02 13:18:17 --> Router Class Initialized
INFO - 2017-03-02 13:18:17 --> Output Class Initialized
INFO - 2017-03-02 13:18:17 --> Security Class Initialized
DEBUG - 2017-03-02 13:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:18:17 --> Input Class Initialized
INFO - 2017-03-02 13:18:17 --> Language Class Initialized
INFO - 2017-03-02 13:18:17 --> Loader Class Initialized
INFO - 2017-03-02 13:18:17 --> Database Driver Class Initialized
INFO - 2017-03-02 13:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:18:17 --> Controller Class Initialized
INFO - 2017-03-02 13:18:17 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:18:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 13:18:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 13:18:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'RoOze GLoom')
INFO - 2017-03-02 13:18:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 13:18:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 13:18:22 --> Config Class Initialized
INFO - 2017-03-02 13:18:22 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:18:22 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:18:22 --> Utf8 Class Initialized
INFO - 2017-03-02 13:18:22 --> URI Class Initialized
INFO - 2017-03-02 13:18:22 --> Router Class Initialized
INFO - 2017-03-02 13:18:22 --> Output Class Initialized
INFO - 2017-03-02 13:18:22 --> Security Class Initialized
DEBUG - 2017-03-02 13:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:18:22 --> Input Class Initialized
INFO - 2017-03-02 13:18:22 --> Language Class Initialized
INFO - 2017-03-02 13:18:22 --> Loader Class Initialized
INFO - 2017-03-02 13:18:22 --> Database Driver Class Initialized
INFO - 2017-03-02 13:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:18:23 --> Controller Class Initialized
INFO - 2017-03-02 13:18:23 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:18:23 --> Config Class Initialized
INFO - 2017-03-02 13:18:23 --> Hooks Class Initialized
INFO - 2017-03-02 13:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-02 13:18:23 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:18:23 --> Utf8 Class Initialized
INFO - 2017-03-02 13:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:18:23 --> URI Class Initialized
INFO - 2017-03-02 13:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:18:23 --> Router Class Initialized
INFO - 2017-03-02 13:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:18:23 --> Output Class Initialized
INFO - 2017-03-02 13:18:23 --> Security Class Initialized
DEBUG - 2017-03-02 13:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:18:23 --> Input Class Initialized
INFO - 2017-03-02 13:18:23 --> Language Class Initialized
INFO - 2017-03-02 13:18:23 --> Final output sent to browser
DEBUG - 2017-03-02 13:18:23 --> Total execution time: 1.8048
INFO - 2017-03-02 13:18:23 --> Loader Class Initialized
INFO - 2017-03-02 13:18:24 --> Database Driver Class Initialized
INFO - 2017-03-02 13:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:18:24 --> Controller Class Initialized
INFO - 2017-03-02 13:18:24 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:18:25 --> Final output sent to browser
DEBUG - 2017-03-02 13:18:25 --> Total execution time: 1.5617
INFO - 2017-03-02 13:18:35 --> Config Class Initialized
INFO - 2017-03-02 13:18:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:18:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:18:35 --> Utf8 Class Initialized
INFO - 2017-03-02 13:18:35 --> URI Class Initialized
INFO - 2017-03-02 13:18:35 --> Router Class Initialized
INFO - 2017-03-02 13:18:35 --> Output Class Initialized
INFO - 2017-03-02 13:18:35 --> Security Class Initialized
DEBUG - 2017-03-02 13:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:18:35 --> Input Class Initialized
INFO - 2017-03-02 13:18:35 --> Language Class Initialized
INFO - 2017-03-02 13:18:35 --> Loader Class Initialized
INFO - 2017-03-02 13:18:35 --> Database Driver Class Initialized
INFO - 2017-03-02 13:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:18:36 --> Controller Class Initialized
INFO - 2017-03-02 13:18:36 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:18:38 --> Config Class Initialized
INFO - 2017-03-02 13:18:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:18:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:18:38 --> Utf8 Class Initialized
INFO - 2017-03-02 13:18:38 --> URI Class Initialized
INFO - 2017-03-02 13:18:38 --> Router Class Initialized
INFO - 2017-03-02 13:18:38 --> Output Class Initialized
INFO - 2017-03-02 13:18:38 --> Security Class Initialized
DEBUG - 2017-03-02 13:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:18:38 --> Input Class Initialized
INFO - 2017-03-02 13:18:38 --> Language Class Initialized
INFO - 2017-03-02 13:18:38 --> Loader Class Initialized
INFO - 2017-03-02 13:18:38 --> Database Driver Class Initialized
INFO - 2017-03-02 13:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:18:38 --> Controller Class Initialized
INFO - 2017-03-02 13:18:38 --> Helper loaded: date_helper
DEBUG - 2017-03-02 13:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:18:38 --> Helper loaded: url_helper
INFO - 2017-03-02 13:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 13:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 13:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 13:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:18:38 --> Final output sent to browser
DEBUG - 2017-03-02 13:18:38 --> Total execution time: 0.1076
INFO - 2017-03-02 13:18:40 --> Config Class Initialized
INFO - 2017-03-02 13:18:40 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:18:40 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:18:40 --> Utf8 Class Initialized
INFO - 2017-03-02 13:18:40 --> URI Class Initialized
INFO - 2017-03-02 13:18:40 --> Router Class Initialized
INFO - 2017-03-02 13:18:40 --> Output Class Initialized
INFO - 2017-03-02 13:18:40 --> Security Class Initialized
DEBUG - 2017-03-02 13:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:18:40 --> Input Class Initialized
INFO - 2017-03-02 13:18:40 --> Language Class Initialized
INFO - 2017-03-02 13:18:40 --> Loader Class Initialized
INFO - 2017-03-02 13:18:40 --> Database Driver Class Initialized
INFO - 2017-03-02 13:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:18:40 --> Controller Class Initialized
INFO - 2017-03-02 13:18:40 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:18:40 --> Final output sent to browser
DEBUG - 2017-03-02 13:18:40 --> Total execution time: 0.0222
INFO - 2017-03-02 13:22:29 --> Config Class Initialized
INFO - 2017-03-02 13:22:29 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:22:29 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:22:29 --> Utf8 Class Initialized
INFO - 2017-03-02 13:22:29 --> URI Class Initialized
INFO - 2017-03-02 13:22:29 --> Router Class Initialized
INFO - 2017-03-02 13:22:29 --> Output Class Initialized
INFO - 2017-03-02 13:22:29 --> Security Class Initialized
DEBUG - 2017-03-02 13:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:22:29 --> Input Class Initialized
INFO - 2017-03-02 13:22:29 --> Language Class Initialized
INFO - 2017-03-02 13:22:29 --> Loader Class Initialized
INFO - 2017-03-02 13:22:29 --> Database Driver Class Initialized
INFO - 2017-03-02 13:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:22:29 --> Controller Class Initialized
INFO - 2017-03-02 13:22:29 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:22:30 --> Config Class Initialized
INFO - 2017-03-02 13:22:30 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:22:30 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:22:30 --> Utf8 Class Initialized
INFO - 2017-03-02 13:22:30 --> URI Class Initialized
INFO - 2017-03-02 13:22:30 --> Router Class Initialized
INFO - 2017-03-02 13:22:30 --> Output Class Initialized
INFO - 2017-03-02 13:22:30 --> Security Class Initialized
DEBUG - 2017-03-02 13:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:22:30 --> Input Class Initialized
INFO - 2017-03-02 13:22:30 --> Language Class Initialized
INFO - 2017-03-02 13:22:30 --> Loader Class Initialized
INFO - 2017-03-02 13:22:30 --> Database Driver Class Initialized
INFO - 2017-03-02 13:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:22:30 --> Controller Class Initialized
INFO - 2017-03-02 13:22:30 --> Helper loaded: date_helper
DEBUG - 2017-03-02 13:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:22:30 --> Helper loaded: url_helper
INFO - 2017-03-02 13:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 13:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 13:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 13:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:22:30 --> Final output sent to browser
DEBUG - 2017-03-02 13:22:30 --> Total execution time: 0.0141
INFO - 2017-03-02 13:22:39 --> Config Class Initialized
INFO - 2017-03-02 13:22:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:22:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:22:39 --> Utf8 Class Initialized
INFO - 2017-03-02 13:22:39 --> URI Class Initialized
DEBUG - 2017-03-02 13:22:39 --> No URI present. Default controller set.
INFO - 2017-03-02 13:22:39 --> Router Class Initialized
INFO - 2017-03-02 13:22:39 --> Output Class Initialized
INFO - 2017-03-02 13:22:39 --> Security Class Initialized
DEBUG - 2017-03-02 13:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:22:39 --> Input Class Initialized
INFO - 2017-03-02 13:22:39 --> Language Class Initialized
INFO - 2017-03-02 13:22:39 --> Loader Class Initialized
INFO - 2017-03-02 13:22:39 --> Database Driver Class Initialized
INFO - 2017-03-02 13:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:22:39 --> Controller Class Initialized
INFO - 2017-03-02 13:22:39 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:22:39 --> Final output sent to browser
DEBUG - 2017-03-02 13:22:39 --> Total execution time: 0.0134
INFO - 2017-03-02 13:34:59 --> Config Class Initialized
INFO - 2017-03-02 13:34:59 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:34:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:34:59 --> Utf8 Class Initialized
INFO - 2017-03-02 13:34:59 --> URI Class Initialized
INFO - 2017-03-02 13:34:59 --> Router Class Initialized
INFO - 2017-03-02 13:34:59 --> Output Class Initialized
INFO - 2017-03-02 13:34:59 --> Security Class Initialized
DEBUG - 2017-03-02 13:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:34:59 --> Input Class Initialized
INFO - 2017-03-02 13:34:59 --> Language Class Initialized
INFO - 2017-03-02 13:34:59 --> Loader Class Initialized
INFO - 2017-03-02 13:34:59 --> Database Driver Class Initialized
INFO - 2017-03-02 13:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:34:59 --> Controller Class Initialized
INFO - 2017-03-02 13:34:59 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:35:00 --> Final output sent to browser
DEBUG - 2017-03-02 13:35:00 --> Total execution time: 1.2204
INFO - 2017-03-02 13:35:00 --> Config Class Initialized
INFO - 2017-03-02 13:35:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 13:35:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 13:35:00 --> Utf8 Class Initialized
INFO - 2017-03-02 13:35:00 --> URI Class Initialized
DEBUG - 2017-03-02 13:35:00 --> No URI present. Default controller set.
INFO - 2017-03-02 13:35:00 --> Router Class Initialized
INFO - 2017-03-02 13:35:00 --> Output Class Initialized
INFO - 2017-03-02 13:35:00 --> Security Class Initialized
DEBUG - 2017-03-02 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 13:35:00 --> Input Class Initialized
INFO - 2017-03-02 13:35:00 --> Language Class Initialized
INFO - 2017-03-02 13:35:00 --> Loader Class Initialized
INFO - 2017-03-02 13:35:00 --> Database Driver Class Initialized
INFO - 2017-03-02 13:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 13:35:00 --> Controller Class Initialized
INFO - 2017-03-02 13:35:00 --> Helper loaded: url_helper
DEBUG - 2017-03-02 13:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 13:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 13:35:00 --> Final output sent to browser
DEBUG - 2017-03-02 13:35:00 --> Total execution time: 0.0138
INFO - 2017-03-02 15:05:46 --> Config Class Initialized
INFO - 2017-03-02 15:05:46 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:05:46 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:05:46 --> Utf8 Class Initialized
INFO - 2017-03-02 15:05:46 --> URI Class Initialized
DEBUG - 2017-03-02 15:05:46 --> No URI present. Default controller set.
INFO - 2017-03-02 15:05:46 --> Router Class Initialized
INFO - 2017-03-02 15:05:46 --> Output Class Initialized
INFO - 2017-03-02 15:05:46 --> Security Class Initialized
DEBUG - 2017-03-02 15:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:05:46 --> Input Class Initialized
INFO - 2017-03-02 15:05:46 --> Language Class Initialized
INFO - 2017-03-02 15:05:46 --> Loader Class Initialized
INFO - 2017-03-02 15:05:47 --> Database Driver Class Initialized
INFO - 2017-03-02 15:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:05:47 --> Controller Class Initialized
INFO - 2017-03-02 15:05:47 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 15:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 15:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:05:47 --> Final output sent to browser
DEBUG - 2017-03-02 15:05:47 --> Total execution time: 1.2200
INFO - 2017-03-02 15:07:09 --> Config Class Initialized
INFO - 2017-03-02 15:07:09 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:07:09 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:07:09 --> Utf8 Class Initialized
INFO - 2017-03-02 15:07:10 --> URI Class Initialized
DEBUG - 2017-03-02 15:07:10 --> No URI present. Default controller set.
INFO - 2017-03-02 15:07:10 --> Router Class Initialized
INFO - 2017-03-02 15:07:10 --> Output Class Initialized
INFO - 2017-03-02 15:07:10 --> Security Class Initialized
DEBUG - 2017-03-02 15:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:07:10 --> Input Class Initialized
INFO - 2017-03-02 15:07:10 --> Language Class Initialized
INFO - 2017-03-02 15:07:10 --> Loader Class Initialized
INFO - 2017-03-02 15:07:10 --> Database Driver Class Initialized
INFO - 2017-03-02 15:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:07:10 --> Controller Class Initialized
INFO - 2017-03-02 15:07:10 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 15:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 15:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:07:10 --> Final output sent to browser
DEBUG - 2017-03-02 15:07:10 --> Total execution time: 1.2607
INFO - 2017-03-02 15:07:12 --> Config Class Initialized
INFO - 2017-03-02 15:07:12 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:07:12 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:07:12 --> Utf8 Class Initialized
INFO - 2017-03-02 15:07:12 --> URI Class Initialized
INFO - 2017-03-02 15:07:12 --> Router Class Initialized
INFO - 2017-03-02 15:07:12 --> Output Class Initialized
INFO - 2017-03-02 15:07:12 --> Security Class Initialized
DEBUG - 2017-03-02 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:07:12 --> Input Class Initialized
INFO - 2017-03-02 15:07:12 --> Language Class Initialized
INFO - 2017-03-02 15:07:12 --> Loader Class Initialized
INFO - 2017-03-02 15:07:12 --> Database Driver Class Initialized
INFO - 2017-03-02 15:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:07:12 --> Controller Class Initialized
INFO - 2017-03-02 15:07:12 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 15:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 15:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:07:12 --> Final output sent to browser
DEBUG - 2017-03-02 15:07:12 --> Total execution time: 0.0233
INFO - 2017-03-02 15:07:25 --> Config Class Initialized
INFO - 2017-03-02 15:07:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:07:25 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:07:25 --> Utf8 Class Initialized
INFO - 2017-03-02 15:07:25 --> URI Class Initialized
INFO - 2017-03-02 15:07:25 --> Router Class Initialized
INFO - 2017-03-02 15:07:25 --> Output Class Initialized
INFO - 2017-03-02 15:07:25 --> Security Class Initialized
DEBUG - 2017-03-02 15:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:07:25 --> Input Class Initialized
INFO - 2017-03-02 15:07:25 --> Language Class Initialized
INFO - 2017-03-02 15:07:25 --> Loader Class Initialized
INFO - 2017-03-02 15:07:25 --> Database Driver Class Initialized
INFO - 2017-03-02 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:07:25 --> Controller Class Initialized
INFO - 2017-03-02 15:07:25 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:07:27 --> Config Class Initialized
INFO - 2017-03-02 15:07:27 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:07:27 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:07:27 --> Utf8 Class Initialized
INFO - 2017-03-02 15:07:27 --> URI Class Initialized
INFO - 2017-03-02 15:07:27 --> Router Class Initialized
INFO - 2017-03-02 15:07:27 --> Output Class Initialized
INFO - 2017-03-02 15:07:27 --> Security Class Initialized
DEBUG - 2017-03-02 15:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:07:27 --> Input Class Initialized
INFO - 2017-03-02 15:07:27 --> Language Class Initialized
INFO - 2017-03-02 15:07:27 --> Loader Class Initialized
INFO - 2017-03-02 15:07:27 --> Database Driver Class Initialized
INFO - 2017-03-02 15:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:07:27 --> Controller Class Initialized
INFO - 2017-03-02 15:07:27 --> Helper loaded: date_helper
DEBUG - 2017-03-02 15:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:07:27 --> Helper loaded: url_helper
INFO - 2017-03-02 15:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 15:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 15:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 15:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:07:27 --> Final output sent to browser
DEBUG - 2017-03-02 15:07:27 --> Total execution time: 0.1011
INFO - 2017-03-02 15:08:03 --> Config Class Initialized
INFO - 2017-03-02 15:08:03 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:03 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:03 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:03 --> URI Class Initialized
INFO - 2017-03-02 15:08:03 --> Router Class Initialized
INFO - 2017-03-02 15:08:04 --> Output Class Initialized
INFO - 2017-03-02 15:08:04 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:04 --> Input Class Initialized
INFO - 2017-03-02 15:08:04 --> Language Class Initialized
INFO - 2017-03-02 15:08:04 --> Loader Class Initialized
INFO - 2017-03-02 15:08:04 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:04 --> Controller Class Initialized
INFO - 2017-03-02 15:08:04 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:08:07 --> Config Class Initialized
INFO - 2017-03-02 15:08:07 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:07 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:07 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:07 --> URI Class Initialized
INFO - 2017-03-02 15:08:07 --> Router Class Initialized
INFO - 2017-03-02 15:08:07 --> Output Class Initialized
INFO - 2017-03-02 15:08:07 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:07 --> Input Class Initialized
INFO - 2017-03-02 15:08:07 --> Language Class Initialized
INFO - 2017-03-02 15:08:07 --> Loader Class Initialized
INFO - 2017-03-02 15:08:08 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:08 --> Controller Class Initialized
INFO - 2017-03-02 15:08:08 --> Helper loaded: date_helper
DEBUG - 2017-03-02 15:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:08:08 --> Helper loaded: url_helper
INFO - 2017-03-02 15:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 15:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 15:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 15:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:08:08 --> Final output sent to browser
DEBUG - 2017-03-02 15:08:08 --> Total execution time: 1.0508
INFO - 2017-03-02 15:08:09 --> Config Class Initialized
INFO - 2017-03-02 15:08:09 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:09 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:09 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:09 --> URI Class Initialized
INFO - 2017-03-02 15:08:09 --> Router Class Initialized
INFO - 2017-03-02 15:08:09 --> Output Class Initialized
INFO - 2017-03-02 15:08:09 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:09 --> Input Class Initialized
INFO - 2017-03-02 15:08:09 --> Language Class Initialized
INFO - 2017-03-02 15:08:09 --> Loader Class Initialized
INFO - 2017-03-02 15:08:09 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:09 --> Controller Class Initialized
INFO - 2017-03-02 15:08:09 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 15:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 15:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:08:10 --> Final output sent to browser
DEBUG - 2017-03-02 15:08:10 --> Total execution time: 0.2189
INFO - 2017-03-02 15:08:14 --> Config Class Initialized
INFO - 2017-03-02 15:08:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:14 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:14 --> URI Class Initialized
DEBUG - 2017-03-02 15:08:14 --> No URI present. Default controller set.
INFO - 2017-03-02 15:08:14 --> Router Class Initialized
INFO - 2017-03-02 15:08:14 --> Output Class Initialized
INFO - 2017-03-02 15:08:14 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:14 --> Input Class Initialized
INFO - 2017-03-02 15:08:14 --> Language Class Initialized
INFO - 2017-03-02 15:08:14 --> Loader Class Initialized
INFO - 2017-03-02 15:08:14 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:14 --> Controller Class Initialized
INFO - 2017-03-02 15:08:14 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 15:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 15:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:08:14 --> Final output sent to browser
DEBUG - 2017-03-02 15:08:14 --> Total execution time: 0.0140
INFO - 2017-03-02 15:08:26 --> Config Class Initialized
INFO - 2017-03-02 15:08:26 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:26 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:26 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:26 --> URI Class Initialized
INFO - 2017-03-02 15:08:26 --> Router Class Initialized
INFO - 2017-03-02 15:08:26 --> Output Class Initialized
INFO - 2017-03-02 15:08:26 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:27 --> Input Class Initialized
INFO - 2017-03-02 15:08:27 --> Language Class Initialized
INFO - 2017-03-02 15:08:27 --> Loader Class Initialized
INFO - 2017-03-02 15:08:27 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:27 --> Controller Class Initialized
INFO - 2017-03-02 15:08:27 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:08:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 15:08:30 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 15:08:30 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kenia Diaz')
INFO - 2017-03-02 15:08:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 15:08:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 15:08:34 --> Config Class Initialized
INFO - 2017-03-02 15:08:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:34 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:34 --> URI Class Initialized
DEBUG - 2017-03-02 15:08:34 --> No URI present. Default controller set.
INFO - 2017-03-02 15:08:34 --> Router Class Initialized
INFO - 2017-03-02 15:08:34 --> Output Class Initialized
INFO - 2017-03-02 15:08:34 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:34 --> Input Class Initialized
INFO - 2017-03-02 15:08:34 --> Language Class Initialized
INFO - 2017-03-02 15:08:34 --> Loader Class Initialized
INFO - 2017-03-02 15:08:34 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:35 --> Controller Class Initialized
INFO - 2017-03-02 15:08:35 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 15:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 15:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:08:35 --> Final output sent to browser
DEBUG - 2017-03-02 15:08:35 --> Total execution time: 1.5110
INFO - 2017-03-02 15:08:46 --> Config Class Initialized
INFO - 2017-03-02 15:08:46 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:46 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:46 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:46 --> URI Class Initialized
INFO - 2017-03-02 15:08:46 --> Router Class Initialized
INFO - 2017-03-02 15:08:46 --> Output Class Initialized
INFO - 2017-03-02 15:08:46 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:46 --> Input Class Initialized
INFO - 2017-03-02 15:08:46 --> Language Class Initialized
INFO - 2017-03-02 15:08:46 --> Loader Class Initialized
INFO - 2017-03-02 15:08:46 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:46 --> Controller Class Initialized
INFO - 2017-03-02 15:08:46 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:08:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 15:08:47 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 15:08:47 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kenia Diaz')
INFO - 2017-03-02 15:08:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 15:08:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 15:08:52 --> Config Class Initialized
INFO - 2017-03-02 15:08:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:08:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:08:52 --> Utf8 Class Initialized
INFO - 2017-03-02 15:08:52 --> URI Class Initialized
INFO - 2017-03-02 15:08:52 --> Router Class Initialized
INFO - 2017-03-02 15:08:52 --> Output Class Initialized
INFO - 2017-03-02 15:08:52 --> Security Class Initialized
DEBUG - 2017-03-02 15:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:08:52 --> Input Class Initialized
INFO - 2017-03-02 15:08:52 --> Language Class Initialized
INFO - 2017-03-02 15:08:52 --> Loader Class Initialized
INFO - 2017-03-02 15:08:52 --> Database Driver Class Initialized
INFO - 2017-03-02 15:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:08:52 --> Controller Class Initialized
INFO - 2017-03-02 15:08:52 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:08:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 15:08:52 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 15:08:52 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kenia Diaz')
INFO - 2017-03-02 15:08:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 15:08:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 15:09:01 --> Config Class Initialized
INFO - 2017-03-02 15:09:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:09:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:09:01 --> Utf8 Class Initialized
INFO - 2017-03-02 15:09:01 --> URI Class Initialized
INFO - 2017-03-02 15:09:01 --> Router Class Initialized
INFO - 2017-03-02 15:09:01 --> Output Class Initialized
INFO - 2017-03-02 15:09:01 --> Security Class Initialized
DEBUG - 2017-03-02 15:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:09:01 --> Input Class Initialized
INFO - 2017-03-02 15:09:01 --> Language Class Initialized
INFO - 2017-03-02 15:09:01 --> Loader Class Initialized
INFO - 2017-03-02 15:09:01 --> Database Driver Class Initialized
INFO - 2017-03-02 15:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:09:01 --> Controller Class Initialized
INFO - 2017-03-02 15:09:01 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:09:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 15:09:02 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 15:09:02 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kenia Diaz')
INFO - 2017-03-02 15:09:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 15:09:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 15:39:10 --> Config Class Initialized
INFO - 2017-03-02 15:39:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:39:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:39:10 --> Utf8 Class Initialized
INFO - 2017-03-02 15:39:10 --> URI Class Initialized
DEBUG - 2017-03-02 15:39:10 --> No URI present. Default controller set.
INFO - 2017-03-02 15:39:10 --> Router Class Initialized
INFO - 2017-03-02 15:39:10 --> Output Class Initialized
INFO - 2017-03-02 15:39:10 --> Security Class Initialized
DEBUG - 2017-03-02 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:39:10 --> Input Class Initialized
INFO - 2017-03-02 15:39:10 --> Language Class Initialized
INFO - 2017-03-02 15:39:10 --> Loader Class Initialized
INFO - 2017-03-02 15:39:11 --> Database Driver Class Initialized
INFO - 2017-03-02 15:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:39:11 --> Controller Class Initialized
INFO - 2017-03-02 15:39:11 --> Helper loaded: url_helper
DEBUG - 2017-03-02 15:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 15:39:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 15:39:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 15:39:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 15:39:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 15:39:11 --> Final output sent to browser
DEBUG - 2017-03-02 15:39:11 --> Total execution time: 1.4867
INFO - 2017-03-02 17:15:59 --> Config Class Initialized
INFO - 2017-03-02 17:15:59 --> Hooks Class Initialized
DEBUG - 2017-03-02 17:15:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 17:15:59 --> Utf8 Class Initialized
INFO - 2017-03-02 17:15:59 --> URI Class Initialized
DEBUG - 2017-03-02 17:15:59 --> No URI present. Default controller set.
INFO - 2017-03-02 17:15:59 --> Router Class Initialized
INFO - 2017-03-02 17:15:59 --> Output Class Initialized
INFO - 2017-03-02 17:15:59 --> Security Class Initialized
DEBUG - 2017-03-02 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 17:15:59 --> Input Class Initialized
INFO - 2017-03-02 17:15:59 --> Language Class Initialized
INFO - 2017-03-02 17:15:59 --> Loader Class Initialized
INFO - 2017-03-02 17:16:00 --> Database Driver Class Initialized
INFO - 2017-03-02 17:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 17:16:00 --> Controller Class Initialized
INFO - 2017-03-02 17:16:00 --> Helper loaded: url_helper
DEBUG - 2017-03-02 17:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 17:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 17:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 17:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 17:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 17:16:00 --> Final output sent to browser
DEBUG - 2017-03-02 17:16:00 --> Total execution time: 1.7293
INFO - 2017-03-02 17:16:13 --> Config Class Initialized
INFO - 2017-03-02 17:16:13 --> Hooks Class Initialized
DEBUG - 2017-03-02 17:16:13 --> UTF-8 Support Enabled
INFO - 2017-03-02 17:16:13 --> Utf8 Class Initialized
INFO - 2017-03-02 17:16:13 --> URI Class Initialized
INFO - 2017-03-02 17:16:13 --> Router Class Initialized
INFO - 2017-03-02 17:16:13 --> Output Class Initialized
INFO - 2017-03-02 17:16:13 --> Security Class Initialized
DEBUG - 2017-03-02 17:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 17:16:13 --> Input Class Initialized
INFO - 2017-03-02 17:16:13 --> Language Class Initialized
INFO - 2017-03-02 17:16:13 --> Loader Class Initialized
INFO - 2017-03-02 17:16:13 --> Database Driver Class Initialized
INFO - 2017-03-02 17:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 17:16:13 --> Controller Class Initialized
INFO - 2017-03-02 17:16:13 --> Helper loaded: url_helper
DEBUG - 2017-03-02 17:16:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 17:16:15 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 17:16:15 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kenia Diaz')
INFO - 2017-03-02 17:16:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 17:16:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 18:36:58 --> Config Class Initialized
INFO - 2017-03-02 18:36:58 --> Hooks Class Initialized
DEBUG - 2017-03-02 18:36:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 18:36:59 --> Utf8 Class Initialized
INFO - 2017-03-02 18:36:59 --> URI Class Initialized
INFO - 2017-03-02 18:36:59 --> Router Class Initialized
INFO - 2017-03-02 18:36:59 --> Output Class Initialized
INFO - 2017-03-02 18:36:59 --> Security Class Initialized
DEBUG - 2017-03-02 18:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 18:36:59 --> Input Class Initialized
INFO - 2017-03-02 18:36:59 --> Language Class Initialized
INFO - 2017-03-02 18:36:59 --> Loader Class Initialized
INFO - 2017-03-02 18:36:59 --> Database Driver Class Initialized
INFO - 2017-03-02 18:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 18:37:00 --> Controller Class Initialized
INFO - 2017-03-02 18:37:00 --> Helper loaded: date_helper
DEBUG - 2017-03-02 18:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 18:37:00 --> Helper loaded: url_helper
INFO - 2017-03-02 18:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 18:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 18:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 18:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 18:37:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 18:37:00 --> Final output sent to browser
DEBUG - 2017-03-02 18:37:00 --> Total execution time: 1.6510
INFO - 2017-03-02 19:49:21 --> Config Class Initialized
INFO - 2017-03-02 19:49:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:49:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:49:21 --> Utf8 Class Initialized
INFO - 2017-03-02 19:49:21 --> URI Class Initialized
DEBUG - 2017-03-02 19:49:21 --> No URI present. Default controller set.
INFO - 2017-03-02 19:49:21 --> Router Class Initialized
INFO - 2017-03-02 19:49:21 --> Output Class Initialized
INFO - 2017-03-02 19:49:21 --> Security Class Initialized
DEBUG - 2017-03-02 19:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:49:22 --> Input Class Initialized
INFO - 2017-03-02 19:49:22 --> Language Class Initialized
INFO - 2017-03-02 19:49:22 --> Loader Class Initialized
INFO - 2017-03-02 19:49:22 --> Database Driver Class Initialized
INFO - 2017-03-02 19:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:49:22 --> Controller Class Initialized
INFO - 2017-03-02 19:49:22 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 19:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 19:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:49:23 --> Final output sent to browser
DEBUG - 2017-03-02 19:49:23 --> Total execution time: 1.7627
INFO - 2017-03-02 19:49:29 --> Config Class Initialized
INFO - 2017-03-02 19:49:29 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:49:29 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:49:29 --> Utf8 Class Initialized
INFO - 2017-03-02 19:49:29 --> URI Class Initialized
INFO - 2017-03-02 19:49:29 --> Router Class Initialized
INFO - 2017-03-02 19:49:29 --> Output Class Initialized
INFO - 2017-03-02 19:49:29 --> Security Class Initialized
DEBUG - 2017-03-02 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:49:29 --> Input Class Initialized
INFO - 2017-03-02 19:49:29 --> Language Class Initialized
INFO - 2017-03-02 19:49:29 --> Loader Class Initialized
INFO - 2017-03-02 19:49:30 --> Database Driver Class Initialized
INFO - 2017-03-02 19:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:49:30 --> Controller Class Initialized
INFO - 2017-03-02 19:49:30 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 19:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 19:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:49:30 --> Final output sent to browser
DEBUG - 2017-03-02 19:49:30 --> Total execution time: 1.1870
INFO - 2017-03-02 19:49:35 --> Config Class Initialized
INFO - 2017-03-02 19:49:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:49:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:49:35 --> Utf8 Class Initialized
INFO - 2017-03-02 19:49:35 --> URI Class Initialized
INFO - 2017-03-02 19:49:35 --> Router Class Initialized
INFO - 2017-03-02 19:49:35 --> Output Class Initialized
INFO - 2017-03-02 19:49:35 --> Security Class Initialized
DEBUG - 2017-03-02 19:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:49:35 --> Input Class Initialized
INFO - 2017-03-02 19:49:35 --> Language Class Initialized
INFO - 2017-03-02 19:49:35 --> Loader Class Initialized
INFO - 2017-03-02 19:49:35 --> Database Driver Class Initialized
INFO - 2017-03-02 19:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:49:35 --> Controller Class Initialized
INFO - 2017-03-02 19:49:35 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:49:37 --> Config Class Initialized
INFO - 2017-03-02 19:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:49:37 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:49:37 --> Utf8 Class Initialized
INFO - 2017-03-02 19:49:37 --> URI Class Initialized
INFO - 2017-03-02 19:49:37 --> Router Class Initialized
INFO - 2017-03-02 19:49:37 --> Output Class Initialized
INFO - 2017-03-02 19:49:37 --> Security Class Initialized
DEBUG - 2017-03-02 19:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:49:37 --> Input Class Initialized
INFO - 2017-03-02 19:49:37 --> Language Class Initialized
INFO - 2017-03-02 19:49:37 --> Loader Class Initialized
INFO - 2017-03-02 19:49:37 --> Database Driver Class Initialized
INFO - 2017-03-02 19:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:49:37 --> Controller Class Initialized
INFO - 2017-03-02 19:49:37 --> Helper loaded: date_helper
DEBUG - 2017-03-02 19:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:49:37 --> Helper loaded: url_helper
INFO - 2017-03-02 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:49:37 --> Final output sent to browser
DEBUG - 2017-03-02 19:49:37 --> Total execution time: 0.1726
INFO - 2017-03-02 19:49:37 --> Config Class Initialized
INFO - 2017-03-02 19:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:49:37 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:49:37 --> Utf8 Class Initialized
INFO - 2017-03-02 19:49:37 --> URI Class Initialized
INFO - 2017-03-02 19:49:37 --> Router Class Initialized
INFO - 2017-03-02 19:49:37 --> Output Class Initialized
INFO - 2017-03-02 19:49:37 --> Security Class Initialized
DEBUG - 2017-03-02 19:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:49:37 --> Input Class Initialized
INFO - 2017-03-02 19:49:37 --> Language Class Initialized
INFO - 2017-03-02 19:49:37 --> Loader Class Initialized
INFO - 2017-03-02 19:49:37 --> Database Driver Class Initialized
INFO - 2017-03-02 19:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:49:37 --> Controller Class Initialized
INFO - 2017-03-02 19:49:37 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:49:38 --> Final output sent to browser
DEBUG - 2017-03-02 19:49:38 --> Total execution time: 0.0488
INFO - 2017-03-02 19:49:46 --> Config Class Initialized
INFO - 2017-03-02 19:49:46 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:49:46 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:49:46 --> Utf8 Class Initialized
INFO - 2017-03-02 19:49:46 --> URI Class Initialized
DEBUG - 2017-03-02 19:49:46 --> No URI present. Default controller set.
INFO - 2017-03-02 19:49:46 --> Router Class Initialized
INFO - 2017-03-02 19:49:46 --> Output Class Initialized
INFO - 2017-03-02 19:49:46 --> Security Class Initialized
DEBUG - 2017-03-02 19:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:49:46 --> Input Class Initialized
INFO - 2017-03-02 19:49:46 --> Language Class Initialized
INFO - 2017-03-02 19:49:46 --> Loader Class Initialized
INFO - 2017-03-02 19:49:46 --> Database Driver Class Initialized
INFO - 2017-03-02 19:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:49:46 --> Controller Class Initialized
INFO - 2017-03-02 19:49:46 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 19:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 19:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:49:46 --> Final output sent to browser
DEBUG - 2017-03-02 19:49:46 --> Total execution time: 0.6641
INFO - 2017-03-02 19:49:47 --> Config Class Initialized
INFO - 2017-03-02 19:49:47 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:49:47 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:49:47 --> Utf8 Class Initialized
INFO - 2017-03-02 19:49:47 --> URI Class Initialized
INFO - 2017-03-02 19:49:47 --> Router Class Initialized
INFO - 2017-03-02 19:49:47 --> Output Class Initialized
INFO - 2017-03-02 19:49:47 --> Security Class Initialized
DEBUG - 2017-03-02 19:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:49:47 --> Input Class Initialized
INFO - 2017-03-02 19:49:47 --> Language Class Initialized
INFO - 2017-03-02 19:49:47 --> Loader Class Initialized
INFO - 2017-03-02 19:49:47 --> Database Driver Class Initialized
INFO - 2017-03-02 19:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:49:47 --> Controller Class Initialized
INFO - 2017-03-02 19:49:47 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 19:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 19:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:49:47 --> Final output sent to browser
DEBUG - 2017-03-02 19:49:47 --> Total execution time: 0.0142
INFO - 2017-03-02 19:51:20 --> Config Class Initialized
INFO - 2017-03-02 19:51:20 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:51:20 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:51:20 --> Utf8 Class Initialized
INFO - 2017-03-02 19:51:20 --> URI Class Initialized
INFO - 2017-03-02 19:51:20 --> Router Class Initialized
INFO - 2017-03-02 19:51:20 --> Output Class Initialized
INFO - 2017-03-02 19:51:20 --> Security Class Initialized
DEBUG - 2017-03-02 19:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:51:20 --> Input Class Initialized
INFO - 2017-03-02 19:51:20 --> Language Class Initialized
INFO - 2017-03-02 19:51:20 --> Loader Class Initialized
INFO - 2017-03-02 19:51:20 --> Database Driver Class Initialized
INFO - 2017-03-02 19:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:51:21 --> Controller Class Initialized
INFO - 2017-03-02 19:51:21 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:51:21 --> Config Class Initialized
INFO - 2017-03-02 19:51:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:51:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:51:21 --> Utf8 Class Initialized
INFO - 2017-03-02 19:51:21 --> URI Class Initialized
INFO - 2017-03-02 19:51:21 --> Router Class Initialized
INFO - 2017-03-02 19:51:21 --> Output Class Initialized
INFO - 2017-03-02 19:51:21 --> Security Class Initialized
DEBUG - 2017-03-02 19:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:51:21 --> Input Class Initialized
INFO - 2017-03-02 19:51:21 --> Language Class Initialized
INFO - 2017-03-02 19:51:21 --> Loader Class Initialized
INFO - 2017-03-02 19:51:21 --> Database Driver Class Initialized
INFO - 2017-03-02 19:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:51:21 --> Controller Class Initialized
INFO - 2017-03-02 19:51:21 --> Helper loaded: date_helper
DEBUG - 2017-03-02 19:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:51:21 --> Helper loaded: url_helper
INFO - 2017-03-02 19:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 19:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 19:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 19:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:51:21 --> Final output sent to browser
DEBUG - 2017-03-02 19:51:21 --> Total execution time: 0.2407
INFO - 2017-03-02 19:51:22 --> Config Class Initialized
INFO - 2017-03-02 19:51:22 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:51:22 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:51:22 --> Utf8 Class Initialized
INFO - 2017-03-02 19:51:22 --> URI Class Initialized
INFO - 2017-03-02 19:51:22 --> Router Class Initialized
INFO - 2017-03-02 19:51:22 --> Output Class Initialized
INFO - 2017-03-02 19:51:22 --> Security Class Initialized
DEBUG - 2017-03-02 19:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:51:22 --> Input Class Initialized
INFO - 2017-03-02 19:51:22 --> Language Class Initialized
INFO - 2017-03-02 19:51:22 --> Loader Class Initialized
INFO - 2017-03-02 19:51:22 --> Database Driver Class Initialized
INFO - 2017-03-02 19:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:51:22 --> Controller Class Initialized
INFO - 2017-03-02 19:51:22 --> Helper loaded: url_helper
DEBUG - 2017-03-02 19:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 19:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 19:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 19:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 19:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 19:51:22 --> Final output sent to browser
DEBUG - 2017-03-02 19:51:22 --> Total execution time: 0.0326
INFO - 2017-03-02 20:45:34 --> Config Class Initialized
INFO - 2017-03-02 20:45:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:45:35 --> Utf8 Class Initialized
INFO - 2017-03-02 20:45:35 --> URI Class Initialized
DEBUG - 2017-03-02 20:45:35 --> No URI present. Default controller set.
INFO - 2017-03-02 20:45:35 --> Router Class Initialized
INFO - 2017-03-02 20:45:35 --> Output Class Initialized
INFO - 2017-03-02 20:45:35 --> Security Class Initialized
DEBUG - 2017-03-02 20:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:45:35 --> Input Class Initialized
INFO - 2017-03-02 20:45:35 --> Language Class Initialized
INFO - 2017-03-02 20:45:35 --> Loader Class Initialized
INFO - 2017-03-02 20:45:35 --> Database Driver Class Initialized
INFO - 2017-03-02 20:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:45:36 --> Controller Class Initialized
INFO - 2017-03-02 20:45:36 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 20:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 20:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 20:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 20:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 20:45:36 --> Final output sent to browser
DEBUG - 2017-03-02 20:45:36 --> Total execution time: 1.8960
INFO - 2017-03-02 20:45:42 --> Config Class Initialized
INFO - 2017-03-02 20:45:42 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:45:42 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:45:42 --> Utf8 Class Initialized
INFO - 2017-03-02 20:45:42 --> URI Class Initialized
INFO - 2017-03-02 20:45:42 --> Router Class Initialized
INFO - 2017-03-02 20:45:42 --> Output Class Initialized
INFO - 2017-03-02 20:45:42 --> Security Class Initialized
DEBUG - 2017-03-02 20:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:45:42 --> Input Class Initialized
INFO - 2017-03-02 20:45:42 --> Language Class Initialized
INFO - 2017-03-02 20:45:42 --> Loader Class Initialized
INFO - 2017-03-02 20:45:42 --> Database Driver Class Initialized
INFO - 2017-03-02 20:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:45:42 --> Controller Class Initialized
INFO - 2017-03-02 20:45:42 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 20:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 20:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 20:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 20:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 20:45:42 --> Final output sent to browser
DEBUG - 2017-03-02 20:45:42 --> Total execution time: 0.0136
INFO - 2017-03-02 20:46:26 --> Config Class Initialized
INFO - 2017-03-02 20:46:26 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:26 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:26 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:26 --> URI Class Initialized
INFO - 2017-03-02 20:46:27 --> Router Class Initialized
INFO - 2017-03-02 20:46:27 --> Output Class Initialized
INFO - 2017-03-02 20:46:27 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:27 --> Input Class Initialized
INFO - 2017-03-02 20:46:27 --> Language Class Initialized
INFO - 2017-03-02 20:46:27 --> Loader Class Initialized
INFO - 2017-03-02 20:46:27 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:27 --> Controller Class Initialized
INFO - 2017-03-02 20:46:27 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 20:46:30 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 20:46:30 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Javier Calvillo')
INFO - 2017-03-02 20:46:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 20:46:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 20:46:30 --> Config Class Initialized
INFO - 2017-03-02 20:46:30 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:30 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:31 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:31 --> URI Class Initialized
INFO - 2017-03-02 20:46:31 --> Router Class Initialized
INFO - 2017-03-02 20:46:31 --> Output Class Initialized
INFO - 2017-03-02 20:46:31 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:31 --> Input Class Initialized
INFO - 2017-03-02 20:46:31 --> Language Class Initialized
INFO - 2017-03-02 20:46:31 --> Loader Class Initialized
INFO - 2017-03-02 20:46:31 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:31 --> Controller Class Initialized
INFO - 2017-03-02 20:46:31 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 20:46:31 --> Final output sent to browser
DEBUG - 2017-03-02 20:46:31 --> Total execution time: 0.7426
INFO - 2017-03-02 20:46:38 --> Config Class Initialized
INFO - 2017-03-02 20:46:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:38 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:38 --> URI Class Initialized
INFO - 2017-03-02 20:46:38 --> Router Class Initialized
INFO - 2017-03-02 20:46:38 --> Output Class Initialized
INFO - 2017-03-02 20:46:38 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:38 --> Input Class Initialized
INFO - 2017-03-02 20:46:38 --> Language Class Initialized
INFO - 2017-03-02 20:46:38 --> Loader Class Initialized
INFO - 2017-03-02 20:46:38 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:38 --> Controller Class Initialized
INFO - 2017-03-02 20:46:38 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 20:46:39 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 20:46:39 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Javier Calvillo')
INFO - 2017-03-02 20:46:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 20:46:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 20:46:39 --> Config Class Initialized
INFO - 2017-03-02 20:46:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:39 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:39 --> URI Class Initialized
INFO - 2017-03-02 20:46:39 --> Router Class Initialized
INFO - 2017-03-02 20:46:39 --> Output Class Initialized
INFO - 2017-03-02 20:46:39 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:39 --> Input Class Initialized
INFO - 2017-03-02 20:46:39 --> Language Class Initialized
INFO - 2017-03-02 20:46:39 --> Loader Class Initialized
INFO - 2017-03-02 20:46:39 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:39 --> Controller Class Initialized
INFO - 2017-03-02 20:46:39 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 20:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 20:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 20:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 20:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 20:46:39 --> Final output sent to browser
DEBUG - 2017-03-02 20:46:39 --> Total execution time: 0.0137
INFO - 2017-03-02 20:46:41 --> Config Class Initialized
INFO - 2017-03-02 20:46:41 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:41 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:41 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:41 --> URI Class Initialized
DEBUG - 2017-03-02 20:46:41 --> No URI present. Default controller set.
INFO - 2017-03-02 20:46:41 --> Router Class Initialized
INFO - 2017-03-02 20:46:41 --> Output Class Initialized
INFO - 2017-03-02 20:46:41 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:41 --> Input Class Initialized
INFO - 2017-03-02 20:46:41 --> Language Class Initialized
INFO - 2017-03-02 20:46:41 --> Loader Class Initialized
INFO - 2017-03-02 20:46:41 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:41 --> Controller Class Initialized
INFO - 2017-03-02 20:46:41 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 20:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 20:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 20:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 20:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 20:46:41 --> Final output sent to browser
DEBUG - 2017-03-02 20:46:41 --> Total execution time: 0.0460
INFO - 2017-03-02 20:46:42 --> Config Class Initialized
INFO - 2017-03-02 20:46:42 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:42 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:42 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:42 --> URI Class Initialized
INFO - 2017-03-02 20:46:42 --> Router Class Initialized
INFO - 2017-03-02 20:46:42 --> Output Class Initialized
INFO - 2017-03-02 20:46:42 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:42 --> Input Class Initialized
INFO - 2017-03-02 20:46:42 --> Language Class Initialized
INFO - 2017-03-02 20:46:42 --> Loader Class Initialized
INFO - 2017-03-02 20:46:42 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:42 --> Controller Class Initialized
INFO - 2017-03-02 20:46:42 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 20:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 20:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 20:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 20:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 20:46:42 --> Final output sent to browser
DEBUG - 2017-03-02 20:46:42 --> Total execution time: 0.0143
INFO - 2017-03-02 20:46:48 --> Config Class Initialized
INFO - 2017-03-02 20:46:48 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:48 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:48 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:48 --> URI Class Initialized
INFO - 2017-03-02 20:46:48 --> Router Class Initialized
INFO - 2017-03-02 20:46:48 --> Output Class Initialized
INFO - 2017-03-02 20:46:48 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:48 --> Input Class Initialized
INFO - 2017-03-02 20:46:48 --> Language Class Initialized
INFO - 2017-03-02 20:46:48 --> Loader Class Initialized
INFO - 2017-03-02 20:46:49 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:49 --> Controller Class Initialized
INFO - 2017-03-02 20:46:49 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-02 20:46:50 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-02 20:46:50 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Javier Calvillo')
INFO - 2017-03-02 20:46:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-02 20:46:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-02 20:46:50 --> Config Class Initialized
INFO - 2017-03-02 20:46:50 --> Hooks Class Initialized
DEBUG - 2017-03-02 20:46:50 --> UTF-8 Support Enabled
INFO - 2017-03-02 20:46:50 --> Utf8 Class Initialized
INFO - 2017-03-02 20:46:50 --> URI Class Initialized
INFO - 2017-03-02 20:46:50 --> Router Class Initialized
INFO - 2017-03-02 20:46:50 --> Output Class Initialized
INFO - 2017-03-02 20:46:50 --> Security Class Initialized
DEBUG - 2017-03-02 20:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 20:46:50 --> Input Class Initialized
INFO - 2017-03-02 20:46:50 --> Language Class Initialized
INFO - 2017-03-02 20:46:50 --> Loader Class Initialized
INFO - 2017-03-02 20:46:50 --> Database Driver Class Initialized
INFO - 2017-03-02 20:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 20:46:50 --> Controller Class Initialized
INFO - 2017-03-02 20:46:50 --> Helper loaded: url_helper
DEBUG - 2017-03-02 20:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 20:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 20:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 20:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 20:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 20:46:50 --> Final output sent to browser
DEBUG - 2017-03-02 20:46:50 --> Total execution time: 0.1789
INFO - 2017-03-02 21:03:40 --> Config Class Initialized
INFO - 2017-03-02 21:03:40 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:03:40 --> Utf8 Class Initialized
INFO - 2017-03-02 21:03:40 --> URI Class Initialized
DEBUG - 2017-03-02 21:03:40 --> No URI present. Default controller set.
INFO - 2017-03-02 21:03:40 --> Router Class Initialized
INFO - 2017-03-02 21:03:40 --> Output Class Initialized
INFO - 2017-03-02 21:03:40 --> Security Class Initialized
DEBUG - 2017-03-02 21:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:03:40 --> Input Class Initialized
INFO - 2017-03-02 21:03:40 --> Language Class Initialized
INFO - 2017-03-02 21:03:40 --> Loader Class Initialized
INFO - 2017-03-02 21:03:41 --> Database Driver Class Initialized
INFO - 2017-03-02 21:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:03:41 --> Controller Class Initialized
INFO - 2017-03-02 21:03:41 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:03:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:03:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:03:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:03:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:03:41 --> Final output sent to browser
DEBUG - 2017-03-02 21:03:41 --> Total execution time: 1.7847
INFO - 2017-03-02 21:31:33 --> Config Class Initialized
INFO - 2017-03-02 21:31:33 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:31:33 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:31:33 --> Utf8 Class Initialized
INFO - 2017-03-02 21:31:33 --> URI Class Initialized
DEBUG - 2017-03-02 21:31:33 --> No URI present. Default controller set.
INFO - 2017-03-02 21:31:33 --> Router Class Initialized
INFO - 2017-03-02 21:31:33 --> Output Class Initialized
INFO - 2017-03-02 21:31:33 --> Security Class Initialized
DEBUG - 2017-03-02 21:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:31:34 --> Input Class Initialized
INFO - 2017-03-02 21:31:34 --> Language Class Initialized
INFO - 2017-03-02 21:31:34 --> Loader Class Initialized
INFO - 2017-03-02 21:31:34 --> Database Driver Class Initialized
INFO - 2017-03-02 21:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:31:34 --> Controller Class Initialized
INFO - 2017-03-02 21:31:34 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:31:35 --> Final output sent to browser
DEBUG - 2017-03-02 21:31:35 --> Total execution time: 1.7511
INFO - 2017-03-02 21:31:50 --> Config Class Initialized
INFO - 2017-03-02 21:31:50 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:31:50 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:31:50 --> Utf8 Class Initialized
INFO - 2017-03-02 21:31:50 --> URI Class Initialized
INFO - 2017-03-02 21:31:51 --> Router Class Initialized
INFO - 2017-03-02 21:31:51 --> Output Class Initialized
INFO - 2017-03-02 21:31:51 --> Security Class Initialized
DEBUG - 2017-03-02 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:31:51 --> Input Class Initialized
INFO - 2017-03-02 21:31:51 --> Language Class Initialized
INFO - 2017-03-02 21:31:51 --> Loader Class Initialized
INFO - 2017-03-02 21:31:51 --> Database Driver Class Initialized
INFO - 2017-03-02 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:31:51 --> Controller Class Initialized
INFO - 2017-03-02 21:31:51 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:31:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:31:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:31:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:31:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:31:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:31:52 --> Final output sent to browser
DEBUG - 2017-03-02 21:31:52 --> Total execution time: 1.8945
INFO - 2017-03-02 21:33:20 --> Config Class Initialized
INFO - 2017-03-02 21:33:20 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:20 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:20 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:20 --> URI Class Initialized
DEBUG - 2017-03-02 21:33:20 --> No URI present. Default controller set.
INFO - 2017-03-02 21:33:20 --> Router Class Initialized
INFO - 2017-03-02 21:33:20 --> Output Class Initialized
INFO - 2017-03-02 21:33:20 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:20 --> Input Class Initialized
INFO - 2017-03-02 21:33:20 --> Language Class Initialized
INFO - 2017-03-02 21:33:20 --> Loader Class Initialized
INFO - 2017-03-02 21:33:20 --> Database Driver Class Initialized
INFO - 2017-03-02 21:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:21 --> Controller Class Initialized
INFO - 2017-03-02 21:33:21 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:33:21 --> Final output sent to browser
DEBUG - 2017-03-02 21:33:21 --> Total execution time: 1.4877
INFO - 2017-03-02 21:33:26 --> Config Class Initialized
INFO - 2017-03-02 21:33:26 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:26 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:26 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:26 --> URI Class Initialized
INFO - 2017-03-02 21:33:26 --> Router Class Initialized
INFO - 2017-03-02 21:33:26 --> Output Class Initialized
INFO - 2017-03-02 21:33:26 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:26 --> Input Class Initialized
INFO - 2017-03-02 21:33:26 --> Language Class Initialized
INFO - 2017-03-02 21:33:26 --> Loader Class Initialized
INFO - 2017-03-02 21:33:26 --> Database Driver Class Initialized
INFO - 2017-03-02 21:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:26 --> Controller Class Initialized
INFO - 2017-03-02 21:33:26 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:33:26 --> Final output sent to browser
DEBUG - 2017-03-02 21:33:26 --> Total execution time: 0.0131
INFO - 2017-03-02 21:33:52 --> Config Class Initialized
INFO - 2017-03-02 21:33:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:52 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:52 --> URI Class Initialized
INFO - 2017-03-02 21:33:52 --> Router Class Initialized
INFO - 2017-03-02 21:33:52 --> Output Class Initialized
INFO - 2017-03-02 21:33:52 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:52 --> Input Class Initialized
INFO - 2017-03-02 21:33:52 --> Language Class Initialized
INFO - 2017-03-02 21:33:52 --> Loader Class Initialized
INFO - 2017-03-02 21:33:53 --> Database Driver Class Initialized
INFO - 2017-03-02 21:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:53 --> Controller Class Initialized
INFO - 2017-03-02 21:33:53 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:33:53 --> Final output sent to browser
DEBUG - 2017-03-02 21:33:53 --> Total execution time: 1.2445
INFO - 2017-03-02 21:33:57 --> Config Class Initialized
INFO - 2017-03-02 21:33:57 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:57 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:57 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:57 --> URI Class Initialized
INFO - 2017-03-02 21:33:57 --> Router Class Initialized
INFO - 2017-03-02 21:33:57 --> Output Class Initialized
INFO - 2017-03-02 21:33:57 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:57 --> Input Class Initialized
INFO - 2017-03-02 21:33:57 --> Language Class Initialized
INFO - 2017-03-02 21:33:57 --> Loader Class Initialized
INFO - 2017-03-02 21:33:57 --> Database Driver Class Initialized
INFO - 2017-03-02 21:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:57 --> Controller Class Initialized
INFO - 2017-03-02 21:33:57 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:33:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:33:57 --> Final output sent to browser
DEBUG - 2017-03-02 21:33:57 --> Total execution time: 0.0129
INFO - 2017-03-02 21:34:52 --> Config Class Initialized
INFO - 2017-03-02 21:34:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:34:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:34:52 --> Utf8 Class Initialized
INFO - 2017-03-02 21:34:52 --> URI Class Initialized
INFO - 2017-03-02 21:34:52 --> Router Class Initialized
INFO - 2017-03-02 21:34:52 --> Output Class Initialized
INFO - 2017-03-02 21:34:52 --> Security Class Initialized
DEBUG - 2017-03-02 21:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:34:52 --> Input Class Initialized
INFO - 2017-03-02 21:34:52 --> Language Class Initialized
INFO - 2017-03-02 21:34:52 --> Loader Class Initialized
INFO - 2017-03-02 21:34:53 --> Database Driver Class Initialized
INFO - 2017-03-02 21:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:34:53 --> Controller Class Initialized
INFO - 2017-03-02 21:34:53 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:34:53 --> Final output sent to browser
DEBUG - 2017-03-02 21:34:53 --> Total execution time: 1.2710
INFO - 2017-03-02 21:34:55 --> Config Class Initialized
INFO - 2017-03-02 21:34:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:34:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:34:55 --> Utf8 Class Initialized
INFO - 2017-03-02 21:34:55 --> URI Class Initialized
INFO - 2017-03-02 21:34:55 --> Router Class Initialized
INFO - 2017-03-02 21:34:55 --> Output Class Initialized
INFO - 2017-03-02 21:34:55 --> Security Class Initialized
DEBUG - 2017-03-02 21:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:34:55 --> Input Class Initialized
INFO - 2017-03-02 21:34:55 --> Language Class Initialized
INFO - 2017-03-02 21:34:55 --> Loader Class Initialized
INFO - 2017-03-02 21:34:55 --> Database Driver Class Initialized
INFO - 2017-03-02 21:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:34:55 --> Controller Class Initialized
INFO - 2017-03-02 21:34:55 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:34:55 --> Final output sent to browser
DEBUG - 2017-03-02 21:34:55 --> Total execution time: 0.0153
INFO - 2017-03-02 21:36:17 --> Config Class Initialized
INFO - 2017-03-02 21:36:17 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:36:17 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:36:17 --> Utf8 Class Initialized
INFO - 2017-03-02 21:36:17 --> URI Class Initialized
INFO - 2017-03-02 21:36:17 --> Router Class Initialized
INFO - 2017-03-02 21:36:17 --> Output Class Initialized
INFO - 2017-03-02 21:36:17 --> Security Class Initialized
DEBUG - 2017-03-02 21:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:36:17 --> Input Class Initialized
INFO - 2017-03-02 21:36:17 --> Language Class Initialized
INFO - 2017-03-02 21:36:17 --> Loader Class Initialized
INFO - 2017-03-02 21:36:17 --> Database Driver Class Initialized
INFO - 2017-03-02 21:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:36:18 --> Controller Class Initialized
INFO - 2017-03-02 21:36:18 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:36:18 --> Config Class Initialized
INFO - 2017-03-02 21:36:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:36:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:36:18 --> Utf8 Class Initialized
INFO - 2017-03-02 21:36:18 --> URI Class Initialized
INFO - 2017-03-02 21:36:18 --> Router Class Initialized
INFO - 2017-03-02 21:36:18 --> Output Class Initialized
INFO - 2017-03-02 21:36:18 --> Security Class Initialized
DEBUG - 2017-03-02 21:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:36:18 --> Input Class Initialized
INFO - 2017-03-02 21:36:18 --> Language Class Initialized
INFO - 2017-03-02 21:36:18 --> Loader Class Initialized
INFO - 2017-03-02 21:36:18 --> Database Driver Class Initialized
INFO - 2017-03-02 21:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:36:18 --> Controller Class Initialized
INFO - 2017-03-02 21:36:18 --> Helper loaded: date_helper
DEBUG - 2017-03-02 21:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:36:18 --> Helper loaded: url_helper
INFO - 2017-03-02 21:36:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:36:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 21:36:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 21:36:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 21:36:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:36:18 --> Final output sent to browser
DEBUG - 2017-03-02 21:36:18 --> Total execution time: 0.1471
INFO - 2017-03-02 21:36:19 --> Config Class Initialized
INFO - 2017-03-02 21:36:19 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:36:19 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:36:19 --> Utf8 Class Initialized
INFO - 2017-03-02 21:36:19 --> URI Class Initialized
INFO - 2017-03-02 21:36:19 --> Router Class Initialized
INFO - 2017-03-02 21:36:19 --> Output Class Initialized
INFO - 2017-03-02 21:36:19 --> Security Class Initialized
DEBUG - 2017-03-02 21:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:36:19 --> Input Class Initialized
INFO - 2017-03-02 21:36:19 --> Language Class Initialized
INFO - 2017-03-02 21:36:19 --> Loader Class Initialized
INFO - 2017-03-02 21:36:19 --> Database Driver Class Initialized
INFO - 2017-03-02 21:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:36:19 --> Controller Class Initialized
INFO - 2017-03-02 21:36:19 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:36:19 --> Final output sent to browser
DEBUG - 2017-03-02 21:36:19 --> Total execution time: 0.0138
INFO - 2017-03-02 21:36:27 --> Config Class Initialized
INFO - 2017-03-02 21:36:27 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:36:27 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:36:27 --> Utf8 Class Initialized
INFO - 2017-03-02 21:36:27 --> URI Class Initialized
DEBUG - 2017-03-02 21:36:27 --> No URI present. Default controller set.
INFO - 2017-03-02 21:36:27 --> Router Class Initialized
INFO - 2017-03-02 21:36:27 --> Output Class Initialized
INFO - 2017-03-02 21:36:27 --> Security Class Initialized
DEBUG - 2017-03-02 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:36:27 --> Input Class Initialized
INFO - 2017-03-02 21:36:27 --> Language Class Initialized
INFO - 2017-03-02 21:36:27 --> Loader Class Initialized
INFO - 2017-03-02 21:36:27 --> Database Driver Class Initialized
INFO - 2017-03-02 21:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:36:27 --> Controller Class Initialized
INFO - 2017-03-02 21:36:27 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:36:27 --> Final output sent to browser
DEBUG - 2017-03-02 21:36:27 --> Total execution time: 0.0140
INFO - 2017-03-02 21:36:30 --> Config Class Initialized
INFO - 2017-03-02 21:36:30 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:36:30 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:36:30 --> Utf8 Class Initialized
INFO - 2017-03-02 21:36:30 --> URI Class Initialized
INFO - 2017-03-02 21:36:30 --> Router Class Initialized
INFO - 2017-03-02 21:36:30 --> Output Class Initialized
INFO - 2017-03-02 21:36:30 --> Security Class Initialized
DEBUG - 2017-03-02 21:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:36:30 --> Input Class Initialized
INFO - 2017-03-02 21:36:30 --> Language Class Initialized
INFO - 2017-03-02 21:36:30 --> Loader Class Initialized
INFO - 2017-03-02 21:36:30 --> Database Driver Class Initialized
INFO - 2017-03-02 21:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:36:30 --> Controller Class Initialized
INFO - 2017-03-02 21:36:30 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:36:30 --> Final output sent to browser
DEBUG - 2017-03-02 21:36:30 --> Total execution time: 0.0141
INFO - 2017-03-02 21:40:16 --> Config Class Initialized
INFO - 2017-03-02 21:40:16 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:40:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:40:16 --> Utf8 Class Initialized
INFO - 2017-03-02 21:40:16 --> URI Class Initialized
INFO - 2017-03-02 21:40:17 --> Router Class Initialized
INFO - 2017-03-02 21:40:17 --> Output Class Initialized
INFO - 2017-03-02 21:40:17 --> Security Class Initialized
DEBUG - 2017-03-02 21:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:40:17 --> Input Class Initialized
INFO - 2017-03-02 21:40:17 --> Language Class Initialized
INFO - 2017-03-02 21:40:17 --> Loader Class Initialized
INFO - 2017-03-02 21:40:17 --> Database Driver Class Initialized
INFO - 2017-03-02 21:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:40:17 --> Controller Class Initialized
INFO - 2017-03-02 21:40:17 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:40:17 --> Final output sent to browser
DEBUG - 2017-03-02 21:40:17 --> Total execution time: 0.9705
INFO - 2017-03-02 21:41:10 --> Config Class Initialized
INFO - 2017-03-02 21:41:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:41:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:41:10 --> Utf8 Class Initialized
INFO - 2017-03-02 21:41:10 --> URI Class Initialized
INFO - 2017-03-02 21:41:10 --> Router Class Initialized
INFO - 2017-03-02 21:41:10 --> Output Class Initialized
INFO - 2017-03-02 21:41:11 --> Security Class Initialized
DEBUG - 2017-03-02 21:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:41:11 --> Input Class Initialized
INFO - 2017-03-02 21:41:11 --> Language Class Initialized
INFO - 2017-03-02 21:41:11 --> Loader Class Initialized
INFO - 2017-03-02 21:41:11 --> Database Driver Class Initialized
INFO - 2017-03-02 21:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:41:11 --> Controller Class Initialized
INFO - 2017-03-02 21:41:11 --> Helper loaded: date_helper
DEBUG - 2017-03-02 21:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:41:11 --> Helper loaded: url_helper
INFO - 2017-03-02 21:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 21:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 21:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 21:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:41:11 --> Final output sent to browser
DEBUG - 2017-03-02 21:41:11 --> Total execution time: 1.1044
INFO - 2017-03-02 21:41:12 --> Config Class Initialized
INFO - 2017-03-02 21:41:12 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:41:12 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:41:12 --> Utf8 Class Initialized
INFO - 2017-03-02 21:41:12 --> URI Class Initialized
INFO - 2017-03-02 21:41:12 --> Router Class Initialized
INFO - 2017-03-02 21:41:12 --> Output Class Initialized
INFO - 2017-03-02 21:41:12 --> Security Class Initialized
DEBUG - 2017-03-02 21:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:41:12 --> Input Class Initialized
INFO - 2017-03-02 21:41:12 --> Language Class Initialized
INFO - 2017-03-02 21:41:12 --> Loader Class Initialized
INFO - 2017-03-02 21:41:12 --> Database Driver Class Initialized
INFO - 2017-03-02 21:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:41:12 --> Controller Class Initialized
INFO - 2017-03-02 21:41:12 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:41:13 --> Final output sent to browser
DEBUG - 2017-03-02 21:41:13 --> Total execution time: 0.2487
INFO - 2017-03-02 21:41:16 --> Config Class Initialized
INFO - 2017-03-02 21:41:16 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:41:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:41:16 --> Utf8 Class Initialized
INFO - 2017-03-02 21:41:16 --> URI Class Initialized
DEBUG - 2017-03-02 21:41:16 --> No URI present. Default controller set.
INFO - 2017-03-02 21:41:16 --> Router Class Initialized
INFO - 2017-03-02 21:41:16 --> Output Class Initialized
INFO - 2017-03-02 21:41:16 --> Security Class Initialized
DEBUG - 2017-03-02 21:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:41:16 --> Input Class Initialized
INFO - 2017-03-02 21:41:16 --> Language Class Initialized
INFO - 2017-03-02 21:41:16 --> Loader Class Initialized
INFO - 2017-03-02 21:41:17 --> Database Driver Class Initialized
INFO - 2017-03-02 21:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:41:17 --> Controller Class Initialized
INFO - 2017-03-02 21:41:17 --> Helper loaded: url_helper
DEBUG - 2017-03-02 21:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 21:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 21:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 21:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 21:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 21:41:17 --> Final output sent to browser
DEBUG - 2017-03-02 21:41:17 --> Total execution time: 0.6254
INFO - 2017-03-02 22:02:28 --> Config Class Initialized
INFO - 2017-03-02 22:02:28 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:02:28 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:02:28 --> Utf8 Class Initialized
INFO - 2017-03-02 22:02:28 --> URI Class Initialized
DEBUG - 2017-03-02 22:02:28 --> No URI present. Default controller set.
INFO - 2017-03-02 22:02:28 --> Router Class Initialized
INFO - 2017-03-02 22:02:28 --> Output Class Initialized
INFO - 2017-03-02 22:02:28 --> Security Class Initialized
DEBUG - 2017-03-02 22:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:02:28 --> Input Class Initialized
INFO - 2017-03-02 22:02:28 --> Language Class Initialized
INFO - 2017-03-02 22:02:28 --> Loader Class Initialized
INFO - 2017-03-02 22:02:28 --> Database Driver Class Initialized
INFO - 2017-03-02 22:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:02:29 --> Controller Class Initialized
INFO - 2017-03-02 22:02:29 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:02:29 --> Final output sent to browser
DEBUG - 2017-03-02 22:02:29 --> Total execution time: 1.2384
INFO - 2017-03-02 22:27:01 --> Config Class Initialized
INFO - 2017-03-02 22:27:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:27:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:27:01 --> Utf8 Class Initialized
INFO - 2017-03-02 22:27:01 --> URI Class Initialized
INFO - 2017-03-02 22:27:01 --> Router Class Initialized
INFO - 2017-03-02 22:27:01 --> Output Class Initialized
INFO - 2017-03-02 22:27:01 --> Security Class Initialized
DEBUG - 2017-03-02 22:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:27:01 --> Input Class Initialized
INFO - 2017-03-02 22:27:01 --> Language Class Initialized
INFO - 2017-03-02 22:27:01 --> Loader Class Initialized
INFO - 2017-03-02 22:27:01 --> Database Driver Class Initialized
INFO - 2017-03-02 22:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:27:01 --> Controller Class Initialized
INFO - 2017-03-02 22:27:01 --> Helper loaded: date_helper
DEBUG - 2017-03-02 22:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:27:01 --> Helper loaded: url_helper
INFO - 2017-03-02 22:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 22:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 22:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 22:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:27:02 --> Final output sent to browser
DEBUG - 2017-03-02 22:27:02 --> Total execution time: 1.0865
INFO - 2017-03-02 22:27:03 --> Config Class Initialized
INFO - 2017-03-02 22:27:03 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:27:03 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:27:03 --> Utf8 Class Initialized
INFO - 2017-03-02 22:27:03 --> URI Class Initialized
INFO - 2017-03-02 22:27:03 --> Router Class Initialized
INFO - 2017-03-02 22:27:03 --> Output Class Initialized
INFO - 2017-03-02 22:27:03 --> Security Class Initialized
DEBUG - 2017-03-02 22:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:27:03 --> Input Class Initialized
INFO - 2017-03-02 22:27:03 --> Language Class Initialized
INFO - 2017-03-02 22:27:03 --> Loader Class Initialized
INFO - 2017-03-02 22:27:03 --> Database Driver Class Initialized
INFO - 2017-03-02 22:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:27:03 --> Controller Class Initialized
INFO - 2017-03-02 22:27:03 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:27:03 --> Final output sent to browser
DEBUG - 2017-03-02 22:27:03 --> Total execution time: 0.2429
INFO - 2017-03-02 22:27:13 --> Config Class Initialized
INFO - 2017-03-02 22:27:13 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:27:13 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:27:13 --> Utf8 Class Initialized
INFO - 2017-03-02 22:27:13 --> URI Class Initialized
DEBUG - 2017-03-02 22:27:13 --> No URI present. Default controller set.
INFO - 2017-03-02 22:27:13 --> Router Class Initialized
INFO - 2017-03-02 22:27:13 --> Output Class Initialized
INFO - 2017-03-02 22:27:13 --> Security Class Initialized
DEBUG - 2017-03-02 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:27:13 --> Input Class Initialized
INFO - 2017-03-02 22:27:13 --> Language Class Initialized
INFO - 2017-03-02 22:27:13 --> Loader Class Initialized
INFO - 2017-03-02 22:27:13 --> Database Driver Class Initialized
INFO - 2017-03-02 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:27:13 --> Controller Class Initialized
INFO - 2017-03-02 22:27:13 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:27:13 --> Final output sent to browser
DEBUG - 2017-03-02 22:27:13 --> Total execution time: 0.0129
INFO - 2017-03-02 22:27:16 --> Config Class Initialized
INFO - 2017-03-02 22:27:16 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:27:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:27:16 --> Utf8 Class Initialized
INFO - 2017-03-02 22:27:16 --> URI Class Initialized
INFO - 2017-03-02 22:27:16 --> Router Class Initialized
INFO - 2017-03-02 22:27:16 --> Output Class Initialized
INFO - 2017-03-02 22:27:16 --> Security Class Initialized
DEBUG - 2017-03-02 22:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:27:16 --> Input Class Initialized
INFO - 2017-03-02 22:27:16 --> Language Class Initialized
INFO - 2017-03-02 22:27:16 --> Loader Class Initialized
INFO - 2017-03-02 22:27:16 --> Database Driver Class Initialized
INFO - 2017-03-02 22:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:27:16 --> Controller Class Initialized
INFO - 2017-03-02 22:27:16 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:27:16 --> Final output sent to browser
DEBUG - 2017-03-02 22:27:16 --> Total execution time: 0.0135
INFO - 2017-03-02 22:32:28 --> Config Class Initialized
INFO - 2017-03-02 22:32:28 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:32:28 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:32:28 --> Utf8 Class Initialized
INFO - 2017-03-02 22:32:28 --> URI Class Initialized
DEBUG - 2017-03-02 22:32:28 --> No URI present. Default controller set.
INFO - 2017-03-02 22:32:28 --> Router Class Initialized
INFO - 2017-03-02 22:32:28 --> Output Class Initialized
INFO - 2017-03-02 22:32:28 --> Security Class Initialized
DEBUG - 2017-03-02 22:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:32:28 --> Input Class Initialized
INFO - 2017-03-02 22:32:28 --> Language Class Initialized
INFO - 2017-03-02 22:32:28 --> Loader Class Initialized
INFO - 2017-03-02 22:32:29 --> Database Driver Class Initialized
INFO - 2017-03-02 22:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:32:29 --> Controller Class Initialized
INFO - 2017-03-02 22:32:29 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:32:29 --> Final output sent to browser
DEBUG - 2017-03-02 22:32:29 --> Total execution time: 1.2845
INFO - 2017-03-02 22:32:54 --> Config Class Initialized
INFO - 2017-03-02 22:32:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:32:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:32:54 --> Utf8 Class Initialized
INFO - 2017-03-02 22:32:54 --> URI Class Initialized
INFO - 2017-03-02 22:32:54 --> Router Class Initialized
INFO - 2017-03-02 22:32:54 --> Output Class Initialized
INFO - 2017-03-02 22:32:54 --> Security Class Initialized
DEBUG - 2017-03-02 22:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:32:54 --> Input Class Initialized
INFO - 2017-03-02 22:32:54 --> Language Class Initialized
INFO - 2017-03-02 22:32:54 --> Loader Class Initialized
INFO - 2017-03-02 22:32:55 --> Database Driver Class Initialized
INFO - 2017-03-02 22:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:32:55 --> Controller Class Initialized
INFO - 2017-03-02 22:32:55 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:32:55 --> Final output sent to browser
DEBUG - 2017-03-02 22:32:55 --> Total execution time: 1.2346
INFO - 2017-03-02 22:33:31 --> Config Class Initialized
INFO - 2017-03-02 22:33:31 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:33:31 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:33:31 --> Utf8 Class Initialized
INFO - 2017-03-02 22:33:31 --> URI Class Initialized
DEBUG - 2017-03-02 22:33:31 --> No URI present. Default controller set.
INFO - 2017-03-02 22:33:31 --> Router Class Initialized
INFO - 2017-03-02 22:33:31 --> Output Class Initialized
INFO - 2017-03-02 22:33:31 --> Security Class Initialized
DEBUG - 2017-03-02 22:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:33:31 --> Input Class Initialized
INFO - 2017-03-02 22:33:31 --> Language Class Initialized
INFO - 2017-03-02 22:33:31 --> Loader Class Initialized
INFO - 2017-03-02 22:33:32 --> Database Driver Class Initialized
INFO - 2017-03-02 22:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:33:32 --> Controller Class Initialized
INFO - 2017-03-02 22:33:32 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:33:32 --> Final output sent to browser
DEBUG - 2017-03-02 22:33:32 --> Total execution time: 1.2679
INFO - 2017-03-02 22:33:35 --> Config Class Initialized
INFO - 2017-03-02 22:33:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:33:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:33:35 --> Utf8 Class Initialized
INFO - 2017-03-02 22:33:35 --> URI Class Initialized
INFO - 2017-03-02 22:33:36 --> Router Class Initialized
INFO - 2017-03-02 22:33:36 --> Output Class Initialized
INFO - 2017-03-02 22:33:36 --> Security Class Initialized
DEBUG - 2017-03-02 22:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:33:36 --> Input Class Initialized
INFO - 2017-03-02 22:33:36 --> Language Class Initialized
INFO - 2017-03-02 22:33:36 --> Loader Class Initialized
INFO - 2017-03-02 22:33:36 --> Database Driver Class Initialized
INFO - 2017-03-02 22:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:33:36 --> Controller Class Initialized
INFO - 2017-03-02 22:33:36 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:33:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:33:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:33:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:33:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:33:37 --> Final output sent to browser
DEBUG - 2017-03-02 22:33:37 --> Total execution time: 1.3250
INFO - 2017-03-02 22:48:19 --> Config Class Initialized
INFO - 2017-03-02 22:48:19 --> Hooks Class Initialized
DEBUG - 2017-03-02 22:48:19 --> UTF-8 Support Enabled
INFO - 2017-03-02 22:48:20 --> Utf8 Class Initialized
INFO - 2017-03-02 22:48:20 --> URI Class Initialized
DEBUG - 2017-03-02 22:48:20 --> No URI present. Default controller set.
INFO - 2017-03-02 22:48:20 --> Router Class Initialized
INFO - 2017-03-02 22:48:20 --> Output Class Initialized
INFO - 2017-03-02 22:48:20 --> Security Class Initialized
DEBUG - 2017-03-02 22:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 22:48:20 --> Input Class Initialized
INFO - 2017-03-02 22:48:20 --> Language Class Initialized
INFO - 2017-03-02 22:48:20 --> Loader Class Initialized
INFO - 2017-03-02 22:48:20 --> Database Driver Class Initialized
INFO - 2017-03-02 22:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 22:48:20 --> Controller Class Initialized
INFO - 2017-03-02 22:48:20 --> Helper loaded: url_helper
DEBUG - 2017-03-02 22:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 22:48:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 22:48:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 22:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 22:48:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 22:48:21 --> Final output sent to browser
DEBUG - 2017-03-02 22:48:21 --> Total execution time: 1.2151
INFO - 2017-03-02 23:10:57 --> Config Class Initialized
INFO - 2017-03-02 23:10:57 --> Hooks Class Initialized
DEBUG - 2017-03-02 23:10:57 --> UTF-8 Support Enabled
INFO - 2017-03-02 23:10:57 --> Utf8 Class Initialized
INFO - 2017-03-02 23:10:57 --> URI Class Initialized
INFO - 2017-03-02 23:10:57 --> Router Class Initialized
INFO - 2017-03-02 23:10:57 --> Output Class Initialized
INFO - 2017-03-02 23:10:57 --> Security Class Initialized
DEBUG - 2017-03-02 23:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 23:10:57 --> Input Class Initialized
INFO - 2017-03-02 23:10:57 --> Language Class Initialized
INFO - 2017-03-02 23:10:57 --> Loader Class Initialized
INFO - 2017-03-02 23:10:57 --> Database Driver Class Initialized
INFO - 2017-03-02 23:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 23:10:57 --> Controller Class Initialized
INFO - 2017-03-02 23:10:57 --> Helper loaded: date_helper
DEBUG - 2017-03-02 23:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 23:10:57 --> Helper loaded: url_helper
INFO - 2017-03-02 23:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 23:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-02 23:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-02 23:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-02 23:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 23:10:58 --> Final output sent to browser
DEBUG - 2017-03-02 23:10:58 --> Total execution time: 1.1073
INFO - 2017-03-02 23:11:00 --> Config Class Initialized
INFO - 2017-03-02 23:11:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 23:11:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 23:11:00 --> Utf8 Class Initialized
INFO - 2017-03-02 23:11:00 --> URI Class Initialized
INFO - 2017-03-02 23:11:00 --> Router Class Initialized
INFO - 2017-03-02 23:11:00 --> Output Class Initialized
INFO - 2017-03-02 23:11:00 --> Security Class Initialized
DEBUG - 2017-03-02 23:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 23:11:00 --> Input Class Initialized
INFO - 2017-03-02 23:11:00 --> Language Class Initialized
INFO - 2017-03-02 23:11:00 --> Loader Class Initialized
INFO - 2017-03-02 23:11:00 --> Database Driver Class Initialized
INFO - 2017-03-02 23:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 23:11:00 --> Controller Class Initialized
INFO - 2017-03-02 23:11:00 --> Helper loaded: url_helper
DEBUG - 2017-03-02 23:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 23:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 23:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 23:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 23:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 23:11:00 --> Final output sent to browser
DEBUG - 2017-03-02 23:11:00 --> Total execution time: 0.2434
INFO - 2017-03-02 23:31:55 --> Config Class Initialized
INFO - 2017-03-02 23:31:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 23:31:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 23:31:55 --> Utf8 Class Initialized
INFO - 2017-03-02 23:31:55 --> URI Class Initialized
DEBUG - 2017-03-02 23:31:55 --> No URI present. Default controller set.
INFO - 2017-03-02 23:31:55 --> Router Class Initialized
INFO - 2017-03-02 23:31:55 --> Output Class Initialized
INFO - 2017-03-02 23:31:55 --> Security Class Initialized
DEBUG - 2017-03-02 23:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 23:31:55 --> Input Class Initialized
INFO - 2017-03-02 23:31:55 --> Language Class Initialized
INFO - 2017-03-02 23:31:55 --> Loader Class Initialized
INFO - 2017-03-02 23:31:55 --> Database Driver Class Initialized
INFO - 2017-03-02 23:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 23:31:56 --> Controller Class Initialized
INFO - 2017-03-02 23:31:56 --> Helper loaded: url_helper
DEBUG - 2017-03-02 23:31:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 23:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 23:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 23:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 23:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 23:31:56 --> Final output sent to browser
DEBUG - 2017-03-02 23:31:56 --> Total execution time: 1.2460
INFO - 2017-03-02 23:33:27 --> Config Class Initialized
INFO - 2017-03-02 23:33:27 --> Hooks Class Initialized
DEBUG - 2017-03-02 23:33:28 --> UTF-8 Support Enabled
INFO - 2017-03-02 23:33:28 --> Utf8 Class Initialized
INFO - 2017-03-02 23:33:28 --> URI Class Initialized
INFO - 2017-03-02 23:33:28 --> Router Class Initialized
INFO - 2017-03-02 23:33:28 --> Output Class Initialized
INFO - 2017-03-02 23:33:28 --> Security Class Initialized
DEBUG - 2017-03-02 23:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 23:33:28 --> Input Class Initialized
INFO - 2017-03-02 23:33:28 --> Language Class Initialized
INFO - 2017-03-02 23:33:28 --> Loader Class Initialized
INFO - 2017-03-02 23:33:28 --> Database Driver Class Initialized
INFO - 2017-03-02 23:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 23:33:28 --> Controller Class Initialized
INFO - 2017-03-02 23:33:28 --> Helper loaded: url_helper
DEBUG - 2017-03-02 23:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 23:33:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-02 23:33:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-02 23:33:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-02 23:33:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-02 23:33:29 --> Final output sent to browser
DEBUG - 2017-03-02 23:33:29 --> Total execution time: 1.2525

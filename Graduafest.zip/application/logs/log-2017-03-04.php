<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-04 00:34:51 --> Config Class Initialized
INFO - 2017-03-04 00:34:52 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:34:52 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:34:52 --> Utf8 Class Initialized
INFO - 2017-03-04 00:34:52 --> URI Class Initialized
DEBUG - 2017-03-04 00:34:52 --> No URI present. Default controller set.
INFO - 2017-03-04 00:34:52 --> Router Class Initialized
INFO - 2017-03-04 00:34:52 --> Output Class Initialized
INFO - 2017-03-04 00:34:52 --> Security Class Initialized
DEBUG - 2017-03-04 00:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:34:52 --> Input Class Initialized
INFO - 2017-03-04 00:34:52 --> Language Class Initialized
INFO - 2017-03-04 00:34:52 --> Loader Class Initialized
INFO - 2017-03-04 00:34:52 --> Database Driver Class Initialized
INFO - 2017-03-04 00:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:34:53 --> Controller Class Initialized
INFO - 2017-03-04 00:34:53 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 00:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 00:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:34:53 --> Final output sent to browser
DEBUG - 2017-03-04 00:34:53 --> Total execution time: 2.1119
INFO - 2017-03-04 00:34:57 --> Config Class Initialized
INFO - 2017-03-04 00:34:57 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:34:57 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:34:57 --> Utf8 Class Initialized
INFO - 2017-03-04 00:34:57 --> URI Class Initialized
INFO - 2017-03-04 00:34:57 --> Router Class Initialized
INFO - 2017-03-04 00:34:57 --> Output Class Initialized
INFO - 2017-03-04 00:34:57 --> Security Class Initialized
DEBUG - 2017-03-04 00:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:34:57 --> Input Class Initialized
INFO - 2017-03-04 00:34:57 --> Language Class Initialized
INFO - 2017-03-04 00:34:57 --> Loader Class Initialized
INFO - 2017-03-04 00:34:57 --> Database Driver Class Initialized
INFO - 2017-03-04 00:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:34:57 --> Controller Class Initialized
INFO - 2017-03-04 00:34:57 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:34:57 --> Final output sent to browser
DEBUG - 2017-03-04 00:34:57 --> Total execution time: 0.0134
INFO - 2017-03-04 00:35:14 --> Config Class Initialized
INFO - 2017-03-04 00:35:14 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:14 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:14 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:14 --> URI Class Initialized
INFO - 2017-03-04 00:35:14 --> Router Class Initialized
INFO - 2017-03-04 00:35:15 --> Output Class Initialized
INFO - 2017-03-04 00:35:15 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:15 --> Input Class Initialized
INFO - 2017-03-04 00:35:15 --> Language Class Initialized
INFO - 2017-03-04 00:35:15 --> Loader Class Initialized
INFO - 2017-03-04 00:35:15 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:15 --> Controller Class Initialized
INFO - 2017-03-04 00:35:15 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:18 --> Config Class Initialized
INFO - 2017-03-04 00:35:18 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:18 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:18 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:18 --> URI Class Initialized
INFO - 2017-03-04 00:35:18 --> Router Class Initialized
INFO - 2017-03-04 00:35:18 --> Output Class Initialized
INFO - 2017-03-04 00:35:18 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:18 --> Input Class Initialized
INFO - 2017-03-04 00:35:18 --> Language Class Initialized
INFO - 2017-03-04 00:35:18 --> Loader Class Initialized
INFO - 2017-03-04 00:35:19 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:19 --> Controller Class Initialized
INFO - 2017-03-04 00:35:19 --> Helper loaded: date_helper
DEBUG - 2017-03-04 00:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:19 --> Helper loaded: url_helper
INFO - 2017-03-04 00:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 00:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 00:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 00:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:19 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:19 --> Total execution time: 1.1461
INFO - 2017-03-04 00:35:20 --> Config Class Initialized
INFO - 2017-03-04 00:35:20 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:20 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:20 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:20 --> URI Class Initialized
INFO - 2017-03-04 00:35:20 --> Router Class Initialized
INFO - 2017-03-04 00:35:20 --> Output Class Initialized
INFO - 2017-03-04 00:35:20 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:20 --> Input Class Initialized
INFO - 2017-03-04 00:35:20 --> Language Class Initialized
INFO - 2017-03-04 00:35:20 --> Loader Class Initialized
INFO - 2017-03-04 00:35:20 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:20 --> Controller Class Initialized
INFO - 2017-03-04 00:35:20 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 00:35:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 00:35:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:21 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:21 --> Total execution time: 0.2600
INFO - 2017-03-04 00:35:35 --> Config Class Initialized
INFO - 2017-03-04 00:35:35 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:35 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:35 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:35 --> URI Class Initialized
INFO - 2017-03-04 00:35:35 --> Router Class Initialized
INFO - 2017-03-04 00:35:35 --> Output Class Initialized
INFO - 2017-03-04 00:35:35 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:35 --> Input Class Initialized
INFO - 2017-03-04 00:35:35 --> Language Class Initialized
INFO - 2017-03-04 00:35:35 --> Loader Class Initialized
INFO - 2017-03-04 00:35:36 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:36 --> Controller Class Initialized
INFO - 2017-03-04 00:35:36 --> Helper loaded: date_helper
DEBUG - 2017-03-04 00:35:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:36 --> Helper loaded: url_helper
INFO - 2017-03-04 00:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 00:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 00:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 00:35:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:36 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:36 --> Total execution time: 1.2140
INFO - 2017-03-04 00:35:38 --> Config Class Initialized
INFO - 2017-03-04 00:35:38 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:38 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:38 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:38 --> URI Class Initialized
INFO - 2017-03-04 00:35:38 --> Router Class Initialized
INFO - 2017-03-04 00:35:38 --> Output Class Initialized
INFO - 2017-03-04 00:35:38 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:38 --> Input Class Initialized
INFO - 2017-03-04 00:35:38 --> Language Class Initialized
INFO - 2017-03-04 00:35:38 --> Loader Class Initialized
INFO - 2017-03-04 00:35:38 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:38 --> Controller Class Initialized
INFO - 2017-03-04 00:35:38 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 00:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 00:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:38 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:38 --> Total execution time: 1.0192
INFO - 2017-03-04 00:35:43 --> Config Class Initialized
INFO - 2017-03-04 00:35:43 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:43 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:43 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:43 --> URI Class Initialized
INFO - 2017-03-04 00:35:43 --> Router Class Initialized
INFO - 2017-03-04 00:35:43 --> Output Class Initialized
INFO - 2017-03-04 00:35:43 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:43 --> Input Class Initialized
INFO - 2017-03-04 00:35:43 --> Language Class Initialized
INFO - 2017-03-04 00:35:43 --> Loader Class Initialized
INFO - 2017-03-04 00:35:43 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:43 --> Controller Class Initialized
INFO - 2017-03-04 00:35:43 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:44 --> Config Class Initialized
INFO - 2017-03-04 00:35:44 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:44 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:44 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:44 --> URI Class Initialized
INFO - 2017-03-04 00:35:44 --> Router Class Initialized
INFO - 2017-03-04 00:35:44 --> Output Class Initialized
INFO - 2017-03-04 00:35:44 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:44 --> Input Class Initialized
INFO - 2017-03-04 00:35:44 --> Language Class Initialized
INFO - 2017-03-04 00:35:44 --> Loader Class Initialized
INFO - 2017-03-04 00:35:44 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:44 --> Controller Class Initialized
INFO - 2017-03-04 00:35:44 --> Helper loaded: date_helper
DEBUG - 2017-03-04 00:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:44 --> Helper loaded: url_helper
INFO - 2017-03-04 00:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 00:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 00:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 00:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:44 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:44 --> Total execution time: 0.0630
INFO - 2017-03-04 00:35:45 --> Config Class Initialized
INFO - 2017-03-04 00:35:45 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:45 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:45 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:45 --> URI Class Initialized
INFO - 2017-03-04 00:35:45 --> Router Class Initialized
INFO - 2017-03-04 00:35:45 --> Output Class Initialized
INFO - 2017-03-04 00:35:45 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:45 --> Input Class Initialized
INFO - 2017-03-04 00:35:45 --> Language Class Initialized
INFO - 2017-03-04 00:35:45 --> Loader Class Initialized
INFO - 2017-03-04 00:35:45 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:45 --> Controller Class Initialized
INFO - 2017-03-04 00:35:45 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 00:35:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 00:35:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:45 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:45 --> Total execution time: 0.0152
INFO - 2017-03-04 00:35:50 --> Config Class Initialized
INFO - 2017-03-04 00:35:50 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:50 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:50 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:50 --> URI Class Initialized
DEBUG - 2017-03-04 00:35:50 --> No URI present. Default controller set.
INFO - 2017-03-04 00:35:50 --> Router Class Initialized
INFO - 2017-03-04 00:35:50 --> Output Class Initialized
INFO - 2017-03-04 00:35:50 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:50 --> Input Class Initialized
INFO - 2017-03-04 00:35:50 --> Language Class Initialized
INFO - 2017-03-04 00:35:50 --> Loader Class Initialized
INFO - 2017-03-04 00:35:50 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:51 --> Controller Class Initialized
INFO - 2017-03-04 00:35:51 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 00:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 00:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:51 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:51 --> Total execution time: 1.2376
INFO - 2017-03-04 00:35:55 --> Config Class Initialized
INFO - 2017-03-04 00:35:55 --> Hooks Class Initialized
DEBUG - 2017-03-04 00:35:55 --> UTF-8 Support Enabled
INFO - 2017-03-04 00:35:55 --> Utf8 Class Initialized
INFO - 2017-03-04 00:35:55 --> URI Class Initialized
INFO - 2017-03-04 00:35:55 --> Router Class Initialized
INFO - 2017-03-04 00:35:55 --> Output Class Initialized
INFO - 2017-03-04 00:35:55 --> Security Class Initialized
DEBUG - 2017-03-04 00:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 00:35:55 --> Input Class Initialized
INFO - 2017-03-04 00:35:55 --> Language Class Initialized
INFO - 2017-03-04 00:35:55 --> Loader Class Initialized
INFO - 2017-03-04 00:35:56 --> Database Driver Class Initialized
INFO - 2017-03-04 00:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 00:35:56 --> Controller Class Initialized
INFO - 2017-03-04 00:35:56 --> Helper loaded: url_helper
DEBUG - 2017-03-04 00:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 00:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 00:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 00:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 00:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 00:35:56 --> Final output sent to browser
DEBUG - 2017-03-04 00:35:56 --> Total execution time: 1.5545
INFO - 2017-03-04 05:00:37 --> Config Class Initialized
INFO - 2017-03-04 05:00:37 --> Hooks Class Initialized
DEBUG - 2017-03-04 05:00:37 --> UTF-8 Support Enabled
INFO - 2017-03-04 05:00:37 --> Utf8 Class Initialized
INFO - 2017-03-04 05:00:37 --> URI Class Initialized
DEBUG - 2017-03-04 05:00:38 --> No URI present. Default controller set.
INFO - 2017-03-04 05:00:38 --> Router Class Initialized
INFO - 2017-03-04 05:00:38 --> Output Class Initialized
INFO - 2017-03-04 05:00:38 --> Security Class Initialized
DEBUG - 2017-03-04 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 05:00:38 --> Input Class Initialized
INFO - 2017-03-04 05:00:38 --> Language Class Initialized
INFO - 2017-03-04 05:00:38 --> Loader Class Initialized
INFO - 2017-03-04 05:00:38 --> Database Driver Class Initialized
INFO - 2017-03-04 05:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 05:00:39 --> Controller Class Initialized
INFO - 2017-03-04 05:00:39 --> Helper loaded: url_helper
DEBUG - 2017-03-04 05:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 05:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 05:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 05:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 05:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 05:00:39 --> Final output sent to browser
DEBUG - 2017-03-04 05:00:39 --> Total execution time: 1.7694
INFO - 2017-03-04 14:12:42 --> Config Class Initialized
INFO - 2017-03-04 14:12:42 --> Hooks Class Initialized
DEBUG - 2017-03-04 14:12:42 --> UTF-8 Support Enabled
INFO - 2017-03-04 14:12:42 --> Utf8 Class Initialized
INFO - 2017-03-04 14:12:42 --> URI Class Initialized
DEBUG - 2017-03-04 14:12:42 --> No URI present. Default controller set.
INFO - 2017-03-04 14:12:42 --> Router Class Initialized
INFO - 2017-03-04 14:12:42 --> Output Class Initialized
INFO - 2017-03-04 14:12:42 --> Security Class Initialized
DEBUG - 2017-03-04 14:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 14:12:42 --> Input Class Initialized
INFO - 2017-03-04 14:12:42 --> Language Class Initialized
INFO - 2017-03-04 14:12:42 --> Loader Class Initialized
INFO - 2017-03-04 14:12:43 --> Database Driver Class Initialized
INFO - 2017-03-04 14:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 14:12:43 --> Controller Class Initialized
INFO - 2017-03-04 14:12:43 --> Helper loaded: url_helper
DEBUG - 2017-03-04 14:12:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 14:12:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 14:12:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 14:12:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 14:12:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 14:12:44 --> Final output sent to browser
DEBUG - 2017-03-04 14:12:44 --> Total execution time: 2.0680
INFO - 2017-03-04 14:12:46 --> Config Class Initialized
INFO - 2017-03-04 14:12:46 --> Hooks Class Initialized
DEBUG - 2017-03-04 14:12:46 --> UTF-8 Support Enabled
INFO - 2017-03-04 14:12:46 --> Utf8 Class Initialized
INFO - 2017-03-04 14:12:46 --> URI Class Initialized
INFO - 2017-03-04 14:12:46 --> Router Class Initialized
INFO - 2017-03-04 14:12:46 --> Output Class Initialized
INFO - 2017-03-04 14:12:46 --> Security Class Initialized
DEBUG - 2017-03-04 14:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 14:12:46 --> Input Class Initialized
INFO - 2017-03-04 14:12:46 --> Language Class Initialized
INFO - 2017-03-04 14:12:46 --> Loader Class Initialized
INFO - 2017-03-04 14:12:46 --> Database Driver Class Initialized
INFO - 2017-03-04 14:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 14:12:46 --> Controller Class Initialized
INFO - 2017-03-04 14:12:46 --> Helper loaded: url_helper
DEBUG - 2017-03-04 14:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 14:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 14:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 14:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 14:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 14:12:46 --> Final output sent to browser
DEBUG - 2017-03-04 14:12:46 --> Total execution time: 0.0683
INFO - 2017-03-04 17:12:01 --> Config Class Initialized
INFO - 2017-03-04 17:12:01 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:12:01 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:12:01 --> Utf8 Class Initialized
INFO - 2017-03-04 17:12:01 --> URI Class Initialized
DEBUG - 2017-03-04 17:12:02 --> No URI present. Default controller set.
INFO - 2017-03-04 17:12:02 --> Router Class Initialized
INFO - 2017-03-04 17:12:02 --> Output Class Initialized
INFO - 2017-03-04 17:12:02 --> Security Class Initialized
DEBUG - 2017-03-04 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:12:02 --> Input Class Initialized
INFO - 2017-03-04 17:12:02 --> Language Class Initialized
INFO - 2017-03-04 17:12:02 --> Loader Class Initialized
INFO - 2017-03-04 17:12:02 --> Database Driver Class Initialized
INFO - 2017-03-04 17:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:12:03 --> Controller Class Initialized
INFO - 2017-03-04 17:12:03 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 17:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 17:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:12:03 --> Final output sent to browser
DEBUG - 2017-03-04 17:12:03 --> Total execution time: 2.8995
INFO - 2017-03-04 17:56:45 --> Config Class Initialized
INFO - 2017-03-04 17:56:45 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:56:45 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:56:45 --> Utf8 Class Initialized
INFO - 2017-03-04 17:56:45 --> URI Class Initialized
DEBUG - 2017-03-04 17:56:45 --> No URI present. Default controller set.
INFO - 2017-03-04 17:56:45 --> Router Class Initialized
INFO - 2017-03-04 17:56:45 --> Output Class Initialized
INFO - 2017-03-04 17:56:45 --> Security Class Initialized
DEBUG - 2017-03-04 17:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:56:45 --> Input Class Initialized
INFO - 2017-03-04 17:56:45 --> Language Class Initialized
INFO - 2017-03-04 17:56:45 --> Loader Class Initialized
INFO - 2017-03-04 17:56:46 --> Database Driver Class Initialized
INFO - 2017-03-04 17:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:56:46 --> Controller Class Initialized
INFO - 2017-03-04 17:56:46 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:56:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 17:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 17:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:56:46 --> Final output sent to browser
DEBUG - 2017-03-04 17:56:46 --> Total execution time: 1.2946
INFO - 2017-03-04 17:56:55 --> Config Class Initialized
INFO - 2017-03-04 17:56:55 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:56:55 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:56:55 --> Utf8 Class Initialized
INFO - 2017-03-04 17:56:55 --> URI Class Initialized
INFO - 2017-03-04 17:56:55 --> Router Class Initialized
INFO - 2017-03-04 17:56:56 --> Output Class Initialized
INFO - 2017-03-04 17:56:56 --> Security Class Initialized
DEBUG - 2017-03-04 17:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:56:56 --> Input Class Initialized
INFO - 2017-03-04 17:56:56 --> Language Class Initialized
INFO - 2017-03-04 17:56:56 --> Loader Class Initialized
INFO - 2017-03-04 17:56:56 --> Database Driver Class Initialized
INFO - 2017-03-04 17:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:56:56 --> Controller Class Initialized
INFO - 2017-03-04 17:56:56 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 17:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 17:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:56:56 --> Final output sent to browser
DEBUG - 2017-03-04 17:56:56 --> Total execution time: 1.2309
INFO - 2017-03-04 17:58:00 --> Config Class Initialized
INFO - 2017-03-04 17:58:00 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:00 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:00 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:00 --> URI Class Initialized
INFO - 2017-03-04 17:58:00 --> Router Class Initialized
INFO - 2017-03-04 17:58:00 --> Output Class Initialized
INFO - 2017-03-04 17:58:00 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:00 --> Input Class Initialized
INFO - 2017-03-04 17:58:00 --> Language Class Initialized
INFO - 2017-03-04 17:58:00 --> Loader Class Initialized
INFO - 2017-03-04 17:58:01 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:01 --> Controller Class Initialized
INFO - 2017-03-04 17:58:01 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:04 --> Config Class Initialized
INFO - 2017-03-04 17:58:04 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:04 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:04 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:04 --> URI Class Initialized
INFO - 2017-03-04 17:58:04 --> Router Class Initialized
INFO - 2017-03-04 17:58:04 --> Output Class Initialized
INFO - 2017-03-04 17:58:04 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:04 --> Input Class Initialized
INFO - 2017-03-04 17:58:04 --> Language Class Initialized
INFO - 2017-03-04 17:58:04 --> Loader Class Initialized
INFO - 2017-03-04 17:58:04 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:04 --> Controller Class Initialized
INFO - 2017-03-04 17:58:04 --> Helper loaded: date_helper
DEBUG - 2017-03-04 17:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:04 --> Helper loaded: url_helper
INFO - 2017-03-04 17:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 17:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 17:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 17:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:58:04 --> Final output sent to browser
DEBUG - 2017-03-04 17:58:04 --> Total execution time: 0.3168
INFO - 2017-03-04 17:58:05 --> Config Class Initialized
INFO - 2017-03-04 17:58:05 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:05 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:05 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:05 --> URI Class Initialized
INFO - 2017-03-04 17:58:05 --> Router Class Initialized
INFO - 2017-03-04 17:58:05 --> Output Class Initialized
INFO - 2017-03-04 17:58:05 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:05 --> Input Class Initialized
INFO - 2017-03-04 17:58:05 --> Language Class Initialized
INFO - 2017-03-04 17:58:05 --> Loader Class Initialized
INFO - 2017-03-04 17:58:05 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:05 --> Controller Class Initialized
INFO - 2017-03-04 17:58:05 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:58:05 --> Final output sent to browser
DEBUG - 2017-03-04 17:58:05 --> Total execution time: 0.0450
INFO - 2017-03-04 17:58:16 --> Config Class Initialized
INFO - 2017-03-04 17:58:16 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:16 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:16 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:16 --> URI Class Initialized
INFO - 2017-03-04 17:58:16 --> Router Class Initialized
INFO - 2017-03-04 17:58:16 --> Output Class Initialized
INFO - 2017-03-04 17:58:16 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:16 --> Input Class Initialized
INFO - 2017-03-04 17:58:16 --> Language Class Initialized
INFO - 2017-03-04 17:58:16 --> Loader Class Initialized
INFO - 2017-03-04 17:58:16 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:16 --> Controller Class Initialized
INFO - 2017-03-04 17:58:16 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:17 --> Config Class Initialized
INFO - 2017-03-04 17:58:17 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:17 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:17 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:17 --> URI Class Initialized
INFO - 2017-03-04 17:58:17 --> Router Class Initialized
INFO - 2017-03-04 17:58:17 --> Output Class Initialized
INFO - 2017-03-04 17:58:17 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:17 --> Input Class Initialized
INFO - 2017-03-04 17:58:17 --> Language Class Initialized
INFO - 2017-03-04 17:58:17 --> Loader Class Initialized
INFO - 2017-03-04 17:58:17 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:17 --> Controller Class Initialized
INFO - 2017-03-04 17:58:17 --> Helper loaded: date_helper
DEBUG - 2017-03-04 17:58:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:17 --> Helper loaded: url_helper
INFO - 2017-03-04 17:58:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:58:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 17:58:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 17:58:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 17:58:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:58:17 --> Final output sent to browser
DEBUG - 2017-03-04 17:58:17 --> Total execution time: 0.0501
INFO - 2017-03-04 17:58:18 --> Config Class Initialized
INFO - 2017-03-04 17:58:18 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:18 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:18 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:18 --> URI Class Initialized
INFO - 2017-03-04 17:58:18 --> Router Class Initialized
INFO - 2017-03-04 17:58:18 --> Output Class Initialized
INFO - 2017-03-04 17:58:18 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:18 --> Input Class Initialized
INFO - 2017-03-04 17:58:18 --> Language Class Initialized
INFO - 2017-03-04 17:58:18 --> Loader Class Initialized
INFO - 2017-03-04 17:58:18 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:18 --> Controller Class Initialized
INFO - 2017-03-04 17:58:18 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 17:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 17:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:58:18 --> Final output sent to browser
DEBUG - 2017-03-04 17:58:18 --> Total execution time: 0.0142
INFO - 2017-03-04 17:58:24 --> Config Class Initialized
INFO - 2017-03-04 17:58:24 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:24 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:24 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:24 --> URI Class Initialized
DEBUG - 2017-03-04 17:58:24 --> No URI present. Default controller set.
INFO - 2017-03-04 17:58:24 --> Router Class Initialized
INFO - 2017-03-04 17:58:24 --> Output Class Initialized
INFO - 2017-03-04 17:58:24 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:24 --> Input Class Initialized
INFO - 2017-03-04 17:58:24 --> Language Class Initialized
INFO - 2017-03-04 17:58:24 --> Loader Class Initialized
INFO - 2017-03-04 17:58:24 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:24 --> Controller Class Initialized
INFO - 2017-03-04 17:58:24 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 17:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 17:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:58:25 --> Final output sent to browser
DEBUG - 2017-03-04 17:58:25 --> Total execution time: 0.0143
INFO - 2017-03-04 17:58:27 --> Config Class Initialized
INFO - 2017-03-04 17:58:27 --> Hooks Class Initialized
DEBUG - 2017-03-04 17:58:27 --> UTF-8 Support Enabled
INFO - 2017-03-04 17:58:27 --> Utf8 Class Initialized
INFO - 2017-03-04 17:58:27 --> URI Class Initialized
INFO - 2017-03-04 17:58:27 --> Router Class Initialized
INFO - 2017-03-04 17:58:27 --> Output Class Initialized
INFO - 2017-03-04 17:58:27 --> Security Class Initialized
DEBUG - 2017-03-04 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 17:58:27 --> Input Class Initialized
INFO - 2017-03-04 17:58:27 --> Language Class Initialized
INFO - 2017-03-04 17:58:27 --> Loader Class Initialized
INFO - 2017-03-04 17:58:27 --> Database Driver Class Initialized
INFO - 2017-03-04 17:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 17:58:27 --> Controller Class Initialized
INFO - 2017-03-04 17:58:27 --> Helper loaded: url_helper
DEBUG - 2017-03-04 17:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 17:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 17:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 17:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 17:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 17:58:27 --> Final output sent to browser
DEBUG - 2017-03-04 17:58:27 --> Total execution time: 0.0143
INFO - 2017-03-04 18:00:42 --> Config Class Initialized
INFO - 2017-03-04 18:00:42 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:00:43 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:00:43 --> Utf8 Class Initialized
INFO - 2017-03-04 18:00:43 --> URI Class Initialized
INFO - 2017-03-04 18:00:43 --> Router Class Initialized
INFO - 2017-03-04 18:00:43 --> Output Class Initialized
INFO - 2017-03-04 18:00:43 --> Security Class Initialized
DEBUG - 2017-03-04 18:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:00:43 --> Input Class Initialized
INFO - 2017-03-04 18:00:43 --> Language Class Initialized
INFO - 2017-03-04 18:00:43 --> Loader Class Initialized
INFO - 2017-03-04 18:00:43 --> Database Driver Class Initialized
INFO - 2017-03-04 18:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:00:43 --> Controller Class Initialized
INFO - 2017-03-04 18:00:43 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:00:44 --> Final output sent to browser
DEBUG - 2017-03-04 18:00:44 --> Total execution time: 1.3921
INFO - 2017-03-04 18:00:46 --> Config Class Initialized
INFO - 2017-03-04 18:00:46 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:00:46 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:00:46 --> Utf8 Class Initialized
INFO - 2017-03-04 18:00:46 --> URI Class Initialized
INFO - 2017-03-04 18:00:46 --> Router Class Initialized
INFO - 2017-03-04 18:00:47 --> Output Class Initialized
INFO - 2017-03-04 18:00:47 --> Security Class Initialized
DEBUG - 2017-03-04 18:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:00:47 --> Input Class Initialized
INFO - 2017-03-04 18:00:47 --> Language Class Initialized
INFO - 2017-03-04 18:00:47 --> Loader Class Initialized
INFO - 2017-03-04 18:00:47 --> Database Driver Class Initialized
INFO - 2017-03-04 18:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:00:47 --> Controller Class Initialized
INFO - 2017-03-04 18:00:47 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:00:48 --> Final output sent to browser
DEBUG - 2017-03-04 18:00:48 --> Total execution time: 1.3766
INFO - 2017-03-04 18:01:40 --> Config Class Initialized
INFO - 2017-03-04 18:01:40 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:01:40 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:01:40 --> Utf8 Class Initialized
INFO - 2017-03-04 18:01:40 --> URI Class Initialized
INFO - 2017-03-04 18:01:40 --> Router Class Initialized
INFO - 2017-03-04 18:01:40 --> Output Class Initialized
INFO - 2017-03-04 18:01:40 --> Security Class Initialized
DEBUG - 2017-03-04 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:01:41 --> Input Class Initialized
INFO - 2017-03-04 18:01:41 --> Language Class Initialized
INFO - 2017-03-04 18:01:41 --> Loader Class Initialized
INFO - 2017-03-04 18:01:41 --> Database Driver Class Initialized
INFO - 2017-03-04 18:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:01:41 --> Controller Class Initialized
INFO - 2017-03-04 18:01:41 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:01:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:01:41 --> Final output sent to browser
DEBUG - 2017-03-04 18:01:41 --> Total execution time: 1.3644
INFO - 2017-03-04 18:01:44 --> Config Class Initialized
INFO - 2017-03-04 18:01:44 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:01:44 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:01:44 --> Utf8 Class Initialized
INFO - 2017-03-04 18:01:44 --> URI Class Initialized
INFO - 2017-03-04 18:01:44 --> Router Class Initialized
INFO - 2017-03-04 18:01:44 --> Output Class Initialized
INFO - 2017-03-04 18:01:44 --> Security Class Initialized
DEBUG - 2017-03-04 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:01:44 --> Input Class Initialized
INFO - 2017-03-04 18:01:44 --> Language Class Initialized
INFO - 2017-03-04 18:01:44 --> Loader Class Initialized
INFO - 2017-03-04 18:01:44 --> Database Driver Class Initialized
INFO - 2017-03-04 18:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:01:44 --> Controller Class Initialized
INFO - 2017-03-04 18:01:44 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:01:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:01:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:01:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:01:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:01:45 --> Final output sent to browser
DEBUG - 2017-03-04 18:01:45 --> Total execution time: 1.2550
INFO - 2017-03-04 18:02:19 --> Config Class Initialized
INFO - 2017-03-04 18:02:20 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:02:20 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:02:20 --> Utf8 Class Initialized
INFO - 2017-03-04 18:02:20 --> URI Class Initialized
INFO - 2017-03-04 18:02:20 --> Router Class Initialized
INFO - 2017-03-04 18:02:20 --> Output Class Initialized
INFO - 2017-03-04 18:02:20 --> Security Class Initialized
DEBUG - 2017-03-04 18:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:02:20 --> Input Class Initialized
INFO - 2017-03-04 18:02:20 --> Language Class Initialized
INFO - 2017-03-04 18:02:20 --> Loader Class Initialized
INFO - 2017-03-04 18:02:20 --> Database Driver Class Initialized
INFO - 2017-03-04 18:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:02:20 --> Controller Class Initialized
INFO - 2017-03-04 18:02:20 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:02:21 --> Final output sent to browser
DEBUG - 2017-03-04 18:02:21 --> Total execution time: 1.2943
INFO - 2017-03-04 18:02:23 --> Config Class Initialized
INFO - 2017-03-04 18:02:23 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:02:23 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:02:23 --> Utf8 Class Initialized
INFO - 2017-03-04 18:02:23 --> URI Class Initialized
INFO - 2017-03-04 18:02:23 --> Router Class Initialized
INFO - 2017-03-04 18:02:23 --> Output Class Initialized
INFO - 2017-03-04 18:02:23 --> Security Class Initialized
DEBUG - 2017-03-04 18:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:02:23 --> Input Class Initialized
INFO - 2017-03-04 18:02:23 --> Language Class Initialized
INFO - 2017-03-04 18:02:23 --> Loader Class Initialized
INFO - 2017-03-04 18:02:23 --> Database Driver Class Initialized
INFO - 2017-03-04 18:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:02:24 --> Controller Class Initialized
INFO - 2017-03-04 18:02:24 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:02:24 --> Final output sent to browser
DEBUG - 2017-03-04 18:02:24 --> Total execution time: 1.2284
INFO - 2017-03-04 18:02:27 --> Config Class Initialized
INFO - 2017-03-04 18:02:27 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:02:27 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:02:27 --> Utf8 Class Initialized
INFO - 2017-03-04 18:02:27 --> URI Class Initialized
INFO - 2017-03-04 18:02:27 --> Router Class Initialized
INFO - 2017-03-04 18:02:27 --> Output Class Initialized
INFO - 2017-03-04 18:02:27 --> Security Class Initialized
DEBUG - 2017-03-04 18:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:02:27 --> Input Class Initialized
INFO - 2017-03-04 18:02:27 --> Language Class Initialized
INFO - 2017-03-04 18:02:27 --> Loader Class Initialized
INFO - 2017-03-04 18:02:28 --> Database Driver Class Initialized
INFO - 2017-03-04 18:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:02:28 --> Controller Class Initialized
INFO - 2017-03-04 18:02:28 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:02:30 --> Config Class Initialized
INFO - 2017-03-04 18:02:30 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:02:31 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:02:31 --> Utf8 Class Initialized
INFO - 2017-03-04 18:02:31 --> URI Class Initialized
INFO - 2017-03-04 18:02:31 --> Router Class Initialized
INFO - 2017-03-04 18:02:31 --> Output Class Initialized
INFO - 2017-03-04 18:02:31 --> Security Class Initialized
DEBUG - 2017-03-04 18:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:02:31 --> Input Class Initialized
INFO - 2017-03-04 18:02:31 --> Language Class Initialized
INFO - 2017-03-04 18:02:31 --> Loader Class Initialized
INFO - 2017-03-04 18:02:31 --> Database Driver Class Initialized
INFO - 2017-03-04 18:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:02:32 --> Controller Class Initialized
INFO - 2017-03-04 18:02:32 --> Helper loaded: date_helper
DEBUG - 2017-03-04 18:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:02:32 --> Helper loaded: url_helper
INFO - 2017-03-04 18:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 18:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 18:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 18:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:02:32 --> Final output sent to browser
DEBUG - 2017-03-04 18:02:32 --> Total execution time: 1.5728
INFO - 2017-03-04 18:02:33 --> Config Class Initialized
INFO - 2017-03-04 18:02:33 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:02:33 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:02:33 --> Utf8 Class Initialized
INFO - 2017-03-04 18:02:33 --> URI Class Initialized
INFO - 2017-03-04 18:02:33 --> Router Class Initialized
INFO - 2017-03-04 18:02:33 --> Output Class Initialized
INFO - 2017-03-04 18:02:34 --> Security Class Initialized
DEBUG - 2017-03-04 18:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:02:34 --> Input Class Initialized
INFO - 2017-03-04 18:02:34 --> Language Class Initialized
INFO - 2017-03-04 18:02:34 --> Loader Class Initialized
INFO - 2017-03-04 18:02:34 --> Database Driver Class Initialized
INFO - 2017-03-04 18:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:02:34 --> Controller Class Initialized
INFO - 2017-03-04 18:02:34 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:02:34 --> Final output sent to browser
DEBUG - 2017-03-04 18:02:34 --> Total execution time: 1.2304
INFO - 2017-03-04 18:02:43 --> Config Class Initialized
INFO - 2017-03-04 18:02:43 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:02:43 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:02:43 --> Utf8 Class Initialized
INFO - 2017-03-04 18:02:43 --> URI Class Initialized
DEBUG - 2017-03-04 18:02:43 --> No URI present. Default controller set.
INFO - 2017-03-04 18:02:43 --> Router Class Initialized
INFO - 2017-03-04 18:02:43 --> Output Class Initialized
INFO - 2017-03-04 18:02:43 --> Security Class Initialized
DEBUG - 2017-03-04 18:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:02:43 --> Input Class Initialized
INFO - 2017-03-04 18:02:43 --> Language Class Initialized
INFO - 2017-03-04 18:02:43 --> Loader Class Initialized
INFO - 2017-03-04 18:02:44 --> Database Driver Class Initialized
INFO - 2017-03-04 18:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:02:44 --> Controller Class Initialized
INFO - 2017-03-04 18:02:44 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:02:44 --> Final output sent to browser
DEBUG - 2017-03-04 18:02:44 --> Total execution time: 1.3209
INFO - 2017-03-04 18:02:45 --> Config Class Initialized
INFO - 2017-03-04 18:02:45 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:02:45 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:02:45 --> Utf8 Class Initialized
INFO - 2017-03-04 18:02:45 --> URI Class Initialized
INFO - 2017-03-04 18:02:45 --> Router Class Initialized
INFO - 2017-03-04 18:02:45 --> Output Class Initialized
INFO - 2017-03-04 18:02:45 --> Security Class Initialized
DEBUG - 2017-03-04 18:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:02:45 --> Input Class Initialized
INFO - 2017-03-04 18:02:45 --> Language Class Initialized
INFO - 2017-03-04 18:02:45 --> Loader Class Initialized
INFO - 2017-03-04 18:02:45 --> Database Driver Class Initialized
INFO - 2017-03-04 18:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:02:45 --> Controller Class Initialized
INFO - 2017-03-04 18:02:45 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:02:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:02:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:02:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:02:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:02:45 --> Final output sent to browser
DEBUG - 2017-03-04 18:02:45 --> Total execution time: 0.0164
INFO - 2017-03-04 18:03:06 --> Config Class Initialized
INFO - 2017-03-04 18:03:06 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:03:06 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:03:06 --> Utf8 Class Initialized
INFO - 2017-03-04 18:03:06 --> URI Class Initialized
INFO - 2017-03-04 18:03:06 --> Router Class Initialized
INFO - 2017-03-04 18:03:06 --> Output Class Initialized
INFO - 2017-03-04 18:03:06 --> Security Class Initialized
DEBUG - 2017-03-04 18:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:03:06 --> Input Class Initialized
INFO - 2017-03-04 18:03:06 --> Language Class Initialized
INFO - 2017-03-04 18:03:06 --> Loader Class Initialized
INFO - 2017-03-04 18:03:06 --> Database Driver Class Initialized
INFO - 2017-03-04 18:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:03:06 --> Controller Class Initialized
INFO - 2017-03-04 18:03:06 --> Helper loaded: date_helper
DEBUG - 2017-03-04 18:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:03:06 --> Helper loaded: url_helper
INFO - 2017-03-04 18:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 18:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 18:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 18:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:03:06 --> Final output sent to browser
DEBUG - 2017-03-04 18:03:06 --> Total execution time: 0.1507
INFO - 2017-03-04 18:03:07 --> Config Class Initialized
INFO - 2017-03-04 18:03:07 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:03:07 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:03:07 --> Utf8 Class Initialized
INFO - 2017-03-04 18:03:07 --> URI Class Initialized
INFO - 2017-03-04 18:03:07 --> Router Class Initialized
INFO - 2017-03-04 18:03:07 --> Output Class Initialized
INFO - 2017-03-04 18:03:07 --> Security Class Initialized
DEBUG - 2017-03-04 18:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:03:07 --> Input Class Initialized
INFO - 2017-03-04 18:03:07 --> Language Class Initialized
INFO - 2017-03-04 18:03:07 --> Loader Class Initialized
INFO - 2017-03-04 18:03:07 --> Database Driver Class Initialized
INFO - 2017-03-04 18:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:03:07 --> Controller Class Initialized
INFO - 2017-03-04 18:03:07 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:03:07 --> Final output sent to browser
DEBUG - 2017-03-04 18:03:07 --> Total execution time: 0.0219
INFO - 2017-03-04 18:03:13 --> Config Class Initialized
INFO - 2017-03-04 18:03:13 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:03:13 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:03:13 --> Utf8 Class Initialized
INFO - 2017-03-04 18:03:13 --> URI Class Initialized
DEBUG - 2017-03-04 18:03:13 --> No URI present. Default controller set.
INFO - 2017-03-04 18:03:13 --> Router Class Initialized
INFO - 2017-03-04 18:03:13 --> Output Class Initialized
INFO - 2017-03-04 18:03:13 --> Security Class Initialized
DEBUG - 2017-03-04 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:03:13 --> Input Class Initialized
INFO - 2017-03-04 18:03:13 --> Language Class Initialized
INFO - 2017-03-04 18:03:13 --> Loader Class Initialized
INFO - 2017-03-04 18:03:13 --> Database Driver Class Initialized
INFO - 2017-03-04 18:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:03:13 --> Controller Class Initialized
INFO - 2017-03-04 18:03:13 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:03:13 --> Final output sent to browser
DEBUG - 2017-03-04 18:03:13 --> Total execution time: 0.0288
INFO - 2017-03-04 18:03:15 --> Config Class Initialized
INFO - 2017-03-04 18:03:15 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:03:15 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:03:15 --> Utf8 Class Initialized
INFO - 2017-03-04 18:03:15 --> URI Class Initialized
INFO - 2017-03-04 18:03:15 --> Router Class Initialized
INFO - 2017-03-04 18:03:15 --> Output Class Initialized
INFO - 2017-03-04 18:03:15 --> Security Class Initialized
DEBUG - 2017-03-04 18:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:03:15 --> Input Class Initialized
INFO - 2017-03-04 18:03:15 --> Language Class Initialized
INFO - 2017-03-04 18:03:15 --> Loader Class Initialized
INFO - 2017-03-04 18:03:15 --> Database Driver Class Initialized
INFO - 2017-03-04 18:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:03:15 --> Controller Class Initialized
INFO - 2017-03-04 18:03:15 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:03:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:03:15 --> Final output sent to browser
DEBUG - 2017-03-04 18:03:15 --> Total execution time: 0.0176
INFO - 2017-03-04 18:05:12 --> Config Class Initialized
INFO - 2017-03-04 18:05:12 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:05:12 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:05:12 --> Utf8 Class Initialized
INFO - 2017-03-04 18:05:12 --> URI Class Initialized
INFO - 2017-03-04 18:05:12 --> Router Class Initialized
INFO - 2017-03-04 18:05:13 --> Output Class Initialized
INFO - 2017-03-04 18:05:13 --> Security Class Initialized
DEBUG - 2017-03-04 18:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:05:13 --> Input Class Initialized
INFO - 2017-03-04 18:05:13 --> Language Class Initialized
INFO - 2017-03-04 18:05:13 --> Loader Class Initialized
INFO - 2017-03-04 18:05:13 --> Database Driver Class Initialized
INFO - 2017-03-04 18:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:05:13 --> Controller Class Initialized
INFO - 2017-03-04 18:05:13 --> Helper loaded: date_helper
DEBUG - 2017-03-04 18:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:05:13 --> Helper loaded: url_helper
INFO - 2017-03-04 18:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 18:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 18:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 18:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:05:13 --> Final output sent to browser
DEBUG - 2017-03-04 18:05:13 --> Total execution time: 1.0847
INFO - 2017-03-04 18:05:14 --> Config Class Initialized
INFO - 2017-03-04 18:05:14 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:05:14 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:05:14 --> Utf8 Class Initialized
INFO - 2017-03-04 18:05:14 --> URI Class Initialized
INFO - 2017-03-04 18:05:14 --> Router Class Initialized
INFO - 2017-03-04 18:05:14 --> Output Class Initialized
INFO - 2017-03-04 18:05:14 --> Security Class Initialized
DEBUG - 2017-03-04 18:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:05:14 --> Input Class Initialized
INFO - 2017-03-04 18:05:14 --> Language Class Initialized
INFO - 2017-03-04 18:05:14 --> Loader Class Initialized
INFO - 2017-03-04 18:05:14 --> Database Driver Class Initialized
INFO - 2017-03-04 18:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:05:14 --> Controller Class Initialized
INFO - 2017-03-04 18:05:14 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:05:15 --> Final output sent to browser
DEBUG - 2017-03-04 18:05:15 --> Total execution time: 0.2853
INFO - 2017-03-04 18:05:17 --> Config Class Initialized
INFO - 2017-03-04 18:05:17 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:05:17 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:05:17 --> Utf8 Class Initialized
INFO - 2017-03-04 18:05:17 --> URI Class Initialized
DEBUG - 2017-03-04 18:05:17 --> No URI present. Default controller set.
INFO - 2017-03-04 18:05:17 --> Router Class Initialized
INFO - 2017-03-04 18:05:17 --> Output Class Initialized
INFO - 2017-03-04 18:05:17 --> Security Class Initialized
DEBUG - 2017-03-04 18:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:05:17 --> Input Class Initialized
INFO - 2017-03-04 18:05:17 --> Language Class Initialized
INFO - 2017-03-04 18:05:17 --> Loader Class Initialized
INFO - 2017-03-04 18:05:17 --> Database Driver Class Initialized
INFO - 2017-03-04 18:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:05:17 --> Controller Class Initialized
INFO - 2017-03-04 18:05:17 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:05:17 --> Final output sent to browser
DEBUG - 2017-03-04 18:05:17 --> Total execution time: 0.0151
INFO - 2017-03-04 18:05:18 --> Config Class Initialized
INFO - 2017-03-04 18:05:18 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:05:18 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:05:18 --> Utf8 Class Initialized
INFO - 2017-03-04 18:05:18 --> URI Class Initialized
INFO - 2017-03-04 18:05:18 --> Router Class Initialized
INFO - 2017-03-04 18:05:18 --> Output Class Initialized
INFO - 2017-03-04 18:05:18 --> Security Class Initialized
DEBUG - 2017-03-04 18:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:05:18 --> Input Class Initialized
INFO - 2017-03-04 18:05:18 --> Language Class Initialized
INFO - 2017-03-04 18:05:18 --> Loader Class Initialized
INFO - 2017-03-04 18:05:18 --> Database Driver Class Initialized
INFO - 2017-03-04 18:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:05:18 --> Controller Class Initialized
INFO - 2017-03-04 18:05:18 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:05:18 --> Final output sent to browser
DEBUG - 2017-03-04 18:05:18 --> Total execution time: 0.0164
INFO - 2017-03-04 18:06:21 --> Config Class Initialized
INFO - 2017-03-04 18:06:21 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:06:21 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:06:21 --> Utf8 Class Initialized
INFO - 2017-03-04 18:06:21 --> URI Class Initialized
DEBUG - 2017-03-04 18:06:21 --> No URI present. Default controller set.
INFO - 2017-03-04 18:06:21 --> Router Class Initialized
INFO - 2017-03-04 18:06:21 --> Output Class Initialized
INFO - 2017-03-04 18:06:21 --> Security Class Initialized
DEBUG - 2017-03-04 18:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:06:21 --> Input Class Initialized
INFO - 2017-03-04 18:06:21 --> Language Class Initialized
INFO - 2017-03-04 18:06:21 --> Loader Class Initialized
INFO - 2017-03-04 18:06:21 --> Database Driver Class Initialized
INFO - 2017-03-04 18:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:06:21 --> Controller Class Initialized
INFO - 2017-03-04 18:06:21 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:06:21 --> Final output sent to browser
DEBUG - 2017-03-04 18:06:21 --> Total execution time: 0.0138
INFO - 2017-03-04 18:06:25 --> Config Class Initialized
INFO - 2017-03-04 18:06:25 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:06:25 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:06:25 --> Utf8 Class Initialized
INFO - 2017-03-04 18:06:25 --> URI Class Initialized
INFO - 2017-03-04 18:06:25 --> Router Class Initialized
INFO - 2017-03-04 18:06:25 --> Output Class Initialized
INFO - 2017-03-04 18:06:25 --> Security Class Initialized
DEBUG - 2017-03-04 18:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:06:25 --> Input Class Initialized
INFO - 2017-03-04 18:06:25 --> Language Class Initialized
INFO - 2017-03-04 18:06:25 --> Loader Class Initialized
INFO - 2017-03-04 18:06:25 --> Database Driver Class Initialized
INFO - 2017-03-04 18:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:06:25 --> Controller Class Initialized
INFO - 2017-03-04 18:06:25 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:06:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:06:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:06:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:06:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:06:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:06:25 --> Final output sent to browser
DEBUG - 2017-03-04 18:06:25 --> Total execution time: 0.0139
INFO - 2017-03-04 18:06:51 --> Config Class Initialized
INFO - 2017-03-04 18:06:51 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:06:51 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:06:51 --> Utf8 Class Initialized
INFO - 2017-03-04 18:06:51 --> URI Class Initialized
DEBUG - 2017-03-04 18:06:51 --> No URI present. Default controller set.
INFO - 2017-03-04 18:06:51 --> Router Class Initialized
INFO - 2017-03-04 18:06:51 --> Output Class Initialized
INFO - 2017-03-04 18:06:51 --> Security Class Initialized
DEBUG - 2017-03-04 18:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:06:51 --> Input Class Initialized
INFO - 2017-03-04 18:06:51 --> Language Class Initialized
INFO - 2017-03-04 18:06:51 --> Loader Class Initialized
INFO - 2017-03-04 18:06:51 --> Database Driver Class Initialized
INFO - 2017-03-04 18:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:06:51 --> Controller Class Initialized
INFO - 2017-03-04 18:06:51 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:06:51 --> Final output sent to browser
DEBUG - 2017-03-04 18:06:51 --> Total execution time: 0.0139
INFO - 2017-03-04 18:06:55 --> Config Class Initialized
INFO - 2017-03-04 18:06:55 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:06:55 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:06:55 --> Utf8 Class Initialized
INFO - 2017-03-04 18:06:55 --> URI Class Initialized
INFO - 2017-03-04 18:06:55 --> Router Class Initialized
INFO - 2017-03-04 18:06:55 --> Output Class Initialized
INFO - 2017-03-04 18:06:55 --> Security Class Initialized
DEBUG - 2017-03-04 18:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:06:56 --> Input Class Initialized
INFO - 2017-03-04 18:06:56 --> Language Class Initialized
INFO - 2017-03-04 18:06:56 --> Loader Class Initialized
INFO - 2017-03-04 18:06:56 --> Database Driver Class Initialized
INFO - 2017-03-04 18:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:06:56 --> Controller Class Initialized
INFO - 2017-03-04 18:06:56 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:06:56 --> Final output sent to browser
DEBUG - 2017-03-04 18:06:56 --> Total execution time: 1.2096
INFO - 2017-03-04 18:08:03 --> Config Class Initialized
INFO - 2017-03-04 18:08:03 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:08:03 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:08:03 --> Utf8 Class Initialized
INFO - 2017-03-04 18:08:03 --> URI Class Initialized
INFO - 2017-03-04 18:08:03 --> Router Class Initialized
INFO - 2017-03-04 18:08:03 --> Output Class Initialized
INFO - 2017-03-04 18:08:03 --> Security Class Initialized
DEBUG - 2017-03-04 18:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:08:03 --> Input Class Initialized
INFO - 2017-03-04 18:08:03 --> Language Class Initialized
INFO - 2017-03-04 18:08:03 --> Loader Class Initialized
INFO - 2017-03-04 18:08:03 --> Database Driver Class Initialized
INFO - 2017-03-04 18:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:08:03 --> Controller Class Initialized
INFO - 2017-03-04 18:08:03 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:08:03 --> Final output sent to browser
DEBUG - 2017-03-04 18:08:03 --> Total execution time: 0.1641
INFO - 2017-03-04 18:08:05 --> Config Class Initialized
INFO - 2017-03-04 18:08:05 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:08:05 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:08:05 --> Utf8 Class Initialized
INFO - 2017-03-04 18:08:05 --> URI Class Initialized
INFO - 2017-03-04 18:08:05 --> Router Class Initialized
INFO - 2017-03-04 18:08:05 --> Output Class Initialized
INFO - 2017-03-04 18:08:05 --> Security Class Initialized
DEBUG - 2017-03-04 18:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:08:05 --> Input Class Initialized
INFO - 2017-03-04 18:08:05 --> Language Class Initialized
INFO - 2017-03-04 18:08:05 --> Loader Class Initialized
INFO - 2017-03-04 18:08:05 --> Database Driver Class Initialized
INFO - 2017-03-04 18:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:08:05 --> Controller Class Initialized
INFO - 2017-03-04 18:08:05 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:08:05 --> Final output sent to browser
DEBUG - 2017-03-04 18:08:05 --> Total execution time: 0.0143
INFO - 2017-03-04 18:08:31 --> Config Class Initialized
INFO - 2017-03-04 18:08:31 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:08:31 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:08:31 --> Utf8 Class Initialized
INFO - 2017-03-04 18:08:31 --> URI Class Initialized
INFO - 2017-03-04 18:08:31 --> Router Class Initialized
INFO - 2017-03-04 18:08:31 --> Output Class Initialized
INFO - 2017-03-04 18:08:31 --> Security Class Initialized
DEBUG - 2017-03-04 18:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:08:31 --> Input Class Initialized
INFO - 2017-03-04 18:08:31 --> Language Class Initialized
INFO - 2017-03-04 18:08:31 --> Loader Class Initialized
INFO - 2017-03-04 18:08:31 --> Database Driver Class Initialized
INFO - 2017-03-04 18:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:08:31 --> Controller Class Initialized
INFO - 2017-03-04 18:08:31 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:08:31 --> Final output sent to browser
DEBUG - 2017-03-04 18:08:31 --> Total execution time: 0.0150
INFO - 2017-03-04 18:08:32 --> Config Class Initialized
INFO - 2017-03-04 18:08:32 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:08:32 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:08:32 --> Utf8 Class Initialized
INFO - 2017-03-04 18:08:32 --> URI Class Initialized
INFO - 2017-03-04 18:08:32 --> Router Class Initialized
INFO - 2017-03-04 18:08:32 --> Output Class Initialized
INFO - 2017-03-04 18:08:32 --> Security Class Initialized
DEBUG - 2017-03-04 18:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:08:32 --> Input Class Initialized
INFO - 2017-03-04 18:08:32 --> Language Class Initialized
INFO - 2017-03-04 18:08:32 --> Loader Class Initialized
INFO - 2017-03-04 18:08:32 --> Database Driver Class Initialized
INFO - 2017-03-04 18:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:08:32 --> Controller Class Initialized
INFO - 2017-03-04 18:08:32 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:08:32 --> Final output sent to browser
DEBUG - 2017-03-04 18:08:32 --> Total execution time: 0.0154
INFO - 2017-03-04 18:08:59 --> Config Class Initialized
INFO - 2017-03-04 18:08:59 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:08:59 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:08:59 --> Utf8 Class Initialized
INFO - 2017-03-04 18:08:59 --> URI Class Initialized
DEBUG - 2017-03-04 18:08:59 --> No URI present. Default controller set.
INFO - 2017-03-04 18:08:59 --> Router Class Initialized
INFO - 2017-03-04 18:08:59 --> Output Class Initialized
INFO - 2017-03-04 18:08:59 --> Security Class Initialized
DEBUG - 2017-03-04 18:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:08:59 --> Input Class Initialized
INFO - 2017-03-04 18:08:59 --> Language Class Initialized
INFO - 2017-03-04 18:08:59 --> Loader Class Initialized
INFO - 2017-03-04 18:08:59 --> Database Driver Class Initialized
INFO - 2017-03-04 18:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:08:59 --> Controller Class Initialized
INFO - 2017-03-04 18:08:59 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:08:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:08:59 --> Final output sent to browser
DEBUG - 2017-03-04 18:08:59 --> Total execution time: 0.0138
INFO - 2017-03-04 18:09:02 --> Config Class Initialized
INFO - 2017-03-04 18:09:02 --> Hooks Class Initialized
DEBUG - 2017-03-04 18:09:02 --> UTF-8 Support Enabled
INFO - 2017-03-04 18:09:02 --> Utf8 Class Initialized
INFO - 2017-03-04 18:09:02 --> URI Class Initialized
INFO - 2017-03-04 18:09:02 --> Router Class Initialized
INFO - 2017-03-04 18:09:02 --> Output Class Initialized
INFO - 2017-03-04 18:09:02 --> Security Class Initialized
DEBUG - 2017-03-04 18:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 18:09:02 --> Input Class Initialized
INFO - 2017-03-04 18:09:02 --> Language Class Initialized
INFO - 2017-03-04 18:09:02 --> Loader Class Initialized
INFO - 2017-03-04 18:09:02 --> Database Driver Class Initialized
INFO - 2017-03-04 18:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 18:09:02 --> Controller Class Initialized
INFO - 2017-03-04 18:09:02 --> Helper loaded: url_helper
DEBUG - 2017-03-04 18:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 18:09:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 18:09:02 --> Final output sent to browser
DEBUG - 2017-03-04 18:09:02 --> Total execution time: 0.0596
INFO - 2017-03-04 19:19:01 --> Config Class Initialized
INFO - 2017-03-04 19:19:01 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:19:01 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:19:01 --> Utf8 Class Initialized
INFO - 2017-03-04 19:19:01 --> URI Class Initialized
DEBUG - 2017-03-04 19:19:02 --> No URI present. Default controller set.
INFO - 2017-03-04 19:19:02 --> Router Class Initialized
INFO - 2017-03-04 19:19:02 --> Output Class Initialized
INFO - 2017-03-04 19:19:02 --> Security Class Initialized
DEBUG - 2017-03-04 19:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:19:02 --> Input Class Initialized
INFO - 2017-03-04 19:19:02 --> Language Class Initialized
INFO - 2017-03-04 19:19:02 --> Loader Class Initialized
INFO - 2017-03-04 19:19:02 --> Database Driver Class Initialized
INFO - 2017-03-04 19:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:19:02 --> Controller Class Initialized
INFO - 2017-03-04 19:19:02 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 19:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 19:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:19:03 --> Final output sent to browser
DEBUG - 2017-03-04 19:19:03 --> Total execution time: 1.5966
INFO - 2017-03-04 19:19:09 --> Config Class Initialized
INFO - 2017-03-04 19:19:09 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:19:09 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:19:09 --> Utf8 Class Initialized
INFO - 2017-03-04 19:19:09 --> URI Class Initialized
INFO - 2017-03-04 19:19:10 --> Router Class Initialized
INFO - 2017-03-04 19:19:10 --> Output Class Initialized
INFO - 2017-03-04 19:19:10 --> Security Class Initialized
DEBUG - 2017-03-04 19:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:19:10 --> Input Class Initialized
INFO - 2017-03-04 19:19:10 --> Language Class Initialized
INFO - 2017-03-04 19:19:10 --> Loader Class Initialized
INFO - 2017-03-04 19:19:10 --> Database Driver Class Initialized
INFO - 2017-03-04 19:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:19:10 --> Controller Class Initialized
INFO - 2017-03-04 19:19:10 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:19:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:19:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 19:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 19:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:19:11 --> Final output sent to browser
DEBUG - 2017-03-04 19:19:11 --> Total execution time: 1.2462
INFO - 2017-03-04 19:19:39 --> Config Class Initialized
INFO - 2017-03-04 19:19:39 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:19:39 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:19:39 --> Utf8 Class Initialized
INFO - 2017-03-04 19:19:39 --> URI Class Initialized
INFO - 2017-03-04 19:19:39 --> Router Class Initialized
INFO - 2017-03-04 19:19:39 --> Output Class Initialized
INFO - 2017-03-04 19:19:39 --> Security Class Initialized
DEBUG - 2017-03-04 19:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:19:39 --> Input Class Initialized
INFO - 2017-03-04 19:19:39 --> Language Class Initialized
INFO - 2017-03-04 19:19:39 --> Loader Class Initialized
INFO - 2017-03-04 19:19:39 --> Database Driver Class Initialized
INFO - 2017-03-04 19:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:19:39 --> Controller Class Initialized
INFO - 2017-03-04 19:19:39 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 19:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 19:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:19:40 --> Final output sent to browser
DEBUG - 2017-03-04 19:19:40 --> Total execution time: 1.2651
INFO - 2017-03-04 19:19:42 --> Config Class Initialized
INFO - 2017-03-04 19:19:42 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:19:42 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:19:42 --> Utf8 Class Initialized
INFO - 2017-03-04 19:19:42 --> URI Class Initialized
INFO - 2017-03-04 19:19:42 --> Router Class Initialized
INFO - 2017-03-04 19:19:42 --> Output Class Initialized
INFO - 2017-03-04 19:19:42 --> Security Class Initialized
DEBUG - 2017-03-04 19:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:19:42 --> Input Class Initialized
INFO - 2017-03-04 19:19:42 --> Language Class Initialized
INFO - 2017-03-04 19:19:42 --> Loader Class Initialized
INFO - 2017-03-04 19:19:42 --> Database Driver Class Initialized
INFO - 2017-03-04 19:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:19:42 --> Controller Class Initialized
INFO - 2017-03-04 19:19:42 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 19:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 19:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:19:43 --> Final output sent to browser
DEBUG - 2017-03-04 19:19:43 --> Total execution time: 1.2431
INFO - 2017-03-04 19:20:00 --> Config Class Initialized
INFO - 2017-03-04 19:20:00 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:20:00 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:20:00 --> Utf8 Class Initialized
INFO - 2017-03-04 19:20:00 --> URI Class Initialized
INFO - 2017-03-04 19:20:00 --> Router Class Initialized
INFO - 2017-03-04 19:20:00 --> Output Class Initialized
INFO - 2017-03-04 19:20:00 --> Security Class Initialized
DEBUG - 2017-03-04 19:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:20:00 --> Input Class Initialized
INFO - 2017-03-04 19:20:00 --> Language Class Initialized
INFO - 2017-03-04 19:20:00 --> Loader Class Initialized
INFO - 2017-03-04 19:20:00 --> Database Driver Class Initialized
INFO - 2017-03-04 19:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:20:01 --> Controller Class Initialized
INFO - 2017-03-04 19:20:01 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:20:01 --> Config Class Initialized
INFO - 2017-03-04 19:20:01 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:20:01 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:20:01 --> Utf8 Class Initialized
INFO - 2017-03-04 19:20:01 --> URI Class Initialized
INFO - 2017-03-04 19:20:01 --> Router Class Initialized
INFO - 2017-03-04 19:20:01 --> Output Class Initialized
INFO - 2017-03-04 19:20:01 --> Security Class Initialized
DEBUG - 2017-03-04 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:20:01 --> Input Class Initialized
INFO - 2017-03-04 19:20:01 --> Language Class Initialized
INFO - 2017-03-04 19:20:01 --> Loader Class Initialized
INFO - 2017-03-04 19:20:01 --> Database Driver Class Initialized
INFO - 2017-03-04 19:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:20:01 --> Controller Class Initialized
INFO - 2017-03-04 19:20:01 --> Helper loaded: date_helper
DEBUG - 2017-03-04 19:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:20:01 --> Helper loaded: url_helper
INFO - 2017-03-04 19:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-04 19:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-04 19:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-04 19:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:20:01 --> Final output sent to browser
DEBUG - 2017-03-04 19:20:01 --> Total execution time: 0.3425
INFO - 2017-03-04 19:20:02 --> Config Class Initialized
INFO - 2017-03-04 19:20:02 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:20:02 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:20:02 --> Utf8 Class Initialized
INFO - 2017-03-04 19:20:02 --> URI Class Initialized
INFO - 2017-03-04 19:20:02 --> Router Class Initialized
INFO - 2017-03-04 19:20:02 --> Output Class Initialized
INFO - 2017-03-04 19:20:02 --> Security Class Initialized
DEBUG - 2017-03-04 19:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:20:02 --> Input Class Initialized
INFO - 2017-03-04 19:20:02 --> Language Class Initialized
INFO - 2017-03-04 19:20:02 --> Loader Class Initialized
INFO - 2017-03-04 19:20:02 --> Database Driver Class Initialized
INFO - 2017-03-04 19:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:20:02 --> Controller Class Initialized
INFO - 2017-03-04 19:20:02 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 19:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 19:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:20:02 --> Final output sent to browser
DEBUG - 2017-03-04 19:20:02 --> Total execution time: 0.0338
INFO - 2017-03-04 19:20:05 --> Config Class Initialized
INFO - 2017-03-04 19:20:05 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:20:05 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:20:05 --> Utf8 Class Initialized
INFO - 2017-03-04 19:20:05 --> URI Class Initialized
DEBUG - 2017-03-04 19:20:05 --> No URI present. Default controller set.
INFO - 2017-03-04 19:20:05 --> Router Class Initialized
INFO - 2017-03-04 19:20:05 --> Output Class Initialized
INFO - 2017-03-04 19:20:05 --> Security Class Initialized
DEBUG - 2017-03-04 19:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:20:05 --> Input Class Initialized
INFO - 2017-03-04 19:20:05 --> Language Class Initialized
INFO - 2017-03-04 19:20:05 --> Loader Class Initialized
INFO - 2017-03-04 19:20:05 --> Database Driver Class Initialized
INFO - 2017-03-04 19:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:20:05 --> Controller Class Initialized
INFO - 2017-03-04 19:20:05 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 19:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 19:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:20:05 --> Final output sent to browser
DEBUG - 2017-03-04 19:20:05 --> Total execution time: 0.0460
INFO - 2017-03-04 19:20:06 --> Config Class Initialized
INFO - 2017-03-04 19:20:06 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:20:06 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:20:06 --> Utf8 Class Initialized
INFO - 2017-03-04 19:20:06 --> URI Class Initialized
INFO - 2017-03-04 19:20:06 --> Router Class Initialized
INFO - 2017-03-04 19:20:06 --> Output Class Initialized
INFO - 2017-03-04 19:20:06 --> Security Class Initialized
DEBUG - 2017-03-04 19:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:20:06 --> Input Class Initialized
INFO - 2017-03-04 19:20:06 --> Language Class Initialized
INFO - 2017-03-04 19:20:06 --> Loader Class Initialized
INFO - 2017-03-04 19:20:06 --> Database Driver Class Initialized
INFO - 2017-03-04 19:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:20:06 --> Controller Class Initialized
INFO - 2017-03-04 19:20:06 --> Helper loaded: url_helper
DEBUG - 2017-03-04 19:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 19:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 19:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 19:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 19:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 19:20:06 --> Final output sent to browser
DEBUG - 2017-03-04 19:20:06 --> Total execution time: 0.0137
INFO - 2017-03-04 20:53:16 --> Config Class Initialized
INFO - 2017-03-04 20:53:16 --> Hooks Class Initialized
DEBUG - 2017-03-04 20:53:16 --> UTF-8 Support Enabled
INFO - 2017-03-04 20:53:16 --> Utf8 Class Initialized
INFO - 2017-03-04 20:53:16 --> URI Class Initialized
INFO - 2017-03-04 20:53:16 --> Router Class Initialized
INFO - 2017-03-04 20:53:16 --> Output Class Initialized
INFO - 2017-03-04 20:53:16 --> Security Class Initialized
DEBUG - 2017-03-04 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 20:53:16 --> Input Class Initialized
INFO - 2017-03-04 20:53:16 --> Language Class Initialized
INFO - 2017-03-04 20:53:16 --> Loader Class Initialized
INFO - 2017-03-04 20:53:17 --> Database Driver Class Initialized
INFO - 2017-03-04 20:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 20:53:17 --> Controller Class Initialized
INFO - 2017-03-04 20:53:17 --> Helper loaded: url_helper
DEBUG - 2017-03-04 20:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 20:53:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-04 20:53:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-04 20:53:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-04 20:53:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-04 20:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 20:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 20:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 20:53:18 --> Final output sent to browser
DEBUG - 2017-03-04 20:53:18 --> Total execution time: 2.0292
INFO - 2017-03-04 21:29:51 --> Config Class Initialized
INFO - 2017-03-04 21:29:51 --> Hooks Class Initialized
DEBUG - 2017-03-04 21:29:51 --> UTF-8 Support Enabled
INFO - 2017-03-04 21:29:51 --> Utf8 Class Initialized
INFO - 2017-03-04 21:29:51 --> URI Class Initialized
INFO - 2017-03-04 21:29:52 --> Router Class Initialized
INFO - 2017-03-04 21:29:52 --> Output Class Initialized
INFO - 2017-03-04 21:29:52 --> Security Class Initialized
DEBUG - 2017-03-04 21:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 21:29:52 --> Input Class Initialized
INFO - 2017-03-04 21:29:52 --> Language Class Initialized
INFO - 2017-03-04 21:29:52 --> Loader Class Initialized
INFO - 2017-03-04 21:29:52 --> Database Driver Class Initialized
INFO - 2017-03-04 21:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 21:29:52 --> Controller Class Initialized
INFO - 2017-03-04 21:29:52 --> Helper loaded: url_helper
DEBUG - 2017-03-04 21:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 21:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 21:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 21:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 21:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 21:29:53 --> Final output sent to browser
DEBUG - 2017-03-04 21:29:53 --> Total execution time: 1.7343
INFO - 2017-03-04 21:30:27 --> Config Class Initialized
INFO - 2017-03-04 21:30:27 --> Hooks Class Initialized
DEBUG - 2017-03-04 21:30:27 --> UTF-8 Support Enabled
INFO - 2017-03-04 21:30:27 --> Utf8 Class Initialized
INFO - 2017-03-04 21:30:27 --> URI Class Initialized
DEBUG - 2017-03-04 21:30:27 --> No URI present. Default controller set.
INFO - 2017-03-04 21:30:27 --> Router Class Initialized
INFO - 2017-03-04 21:30:27 --> Output Class Initialized
INFO - 2017-03-04 21:30:27 --> Security Class Initialized
DEBUG - 2017-03-04 21:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 21:30:27 --> Input Class Initialized
INFO - 2017-03-04 21:30:27 --> Language Class Initialized
INFO - 2017-03-04 21:30:27 --> Loader Class Initialized
INFO - 2017-03-04 21:30:27 --> Database Driver Class Initialized
INFO - 2017-03-04 21:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 21:30:28 --> Controller Class Initialized
INFO - 2017-03-04 21:30:28 --> Helper loaded: url_helper
DEBUG - 2017-03-04 21:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 21:30:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 21:30:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 21:30:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 21:30:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 21:30:28 --> Final output sent to browser
DEBUG - 2017-03-04 21:30:28 --> Total execution time: 1.6604
INFO - 2017-03-04 22:00:30 --> Config Class Initialized
INFO - 2017-03-04 22:00:30 --> Hooks Class Initialized
DEBUG - 2017-03-04 22:00:30 --> UTF-8 Support Enabled
INFO - 2017-03-04 22:00:30 --> Utf8 Class Initialized
INFO - 2017-03-04 22:00:30 --> URI Class Initialized
DEBUG - 2017-03-04 22:00:30 --> No URI present. Default controller set.
INFO - 2017-03-04 22:00:30 --> Router Class Initialized
INFO - 2017-03-04 22:00:30 --> Output Class Initialized
INFO - 2017-03-04 22:00:30 --> Security Class Initialized
DEBUG - 2017-03-04 22:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 22:00:30 --> Input Class Initialized
INFO - 2017-03-04 22:00:30 --> Language Class Initialized
INFO - 2017-03-04 22:00:30 --> Loader Class Initialized
INFO - 2017-03-04 22:00:31 --> Database Driver Class Initialized
INFO - 2017-03-04 22:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 22:00:31 --> Controller Class Initialized
INFO - 2017-03-04 22:00:31 --> Helper loaded: url_helper
DEBUG - 2017-03-04 22:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 22:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 22:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 22:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 22:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 22:00:31 --> Final output sent to browser
DEBUG - 2017-03-04 22:00:31 --> Total execution time: 1.2709
INFO - 2017-03-04 22:00:52 --> Config Class Initialized
INFO - 2017-03-04 22:00:52 --> Hooks Class Initialized
DEBUG - 2017-03-04 22:00:52 --> UTF-8 Support Enabled
INFO - 2017-03-04 22:00:52 --> Utf8 Class Initialized
INFO - 2017-03-04 22:00:52 --> URI Class Initialized
INFO - 2017-03-04 22:00:52 --> Router Class Initialized
INFO - 2017-03-04 22:00:52 --> Output Class Initialized
INFO - 2017-03-04 22:00:52 --> Security Class Initialized
DEBUG - 2017-03-04 22:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 22:00:52 --> Input Class Initialized
INFO - 2017-03-04 22:00:52 --> Language Class Initialized
INFO - 2017-03-04 22:00:52 --> Loader Class Initialized
INFO - 2017-03-04 22:00:52 --> Database Driver Class Initialized
INFO - 2017-03-04 22:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 22:00:52 --> Controller Class Initialized
INFO - 2017-03-04 22:00:52 --> Helper loaded: url_helper
DEBUG - 2017-03-04 22:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 22:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 22:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 22:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 22:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 22:00:52 --> Final output sent to browser
DEBUG - 2017-03-04 22:00:52 --> Total execution time: 0.0149
INFO - 2017-03-04 22:40:36 --> Config Class Initialized
INFO - 2017-03-04 22:40:36 --> Hooks Class Initialized
DEBUG - 2017-03-04 22:40:36 --> UTF-8 Support Enabled
INFO - 2017-03-04 22:40:36 --> Utf8 Class Initialized
INFO - 2017-03-04 22:40:36 --> URI Class Initialized
DEBUG - 2017-03-04 22:40:36 --> No URI present. Default controller set.
INFO - 2017-03-04 22:40:36 --> Router Class Initialized
INFO - 2017-03-04 22:40:37 --> Output Class Initialized
INFO - 2017-03-04 22:40:37 --> Security Class Initialized
DEBUG - 2017-03-04 22:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 22:40:37 --> Input Class Initialized
INFO - 2017-03-04 22:40:37 --> Language Class Initialized
INFO - 2017-03-04 22:40:37 --> Loader Class Initialized
INFO - 2017-03-04 22:40:37 --> Database Driver Class Initialized
INFO - 2017-03-04 22:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 22:40:37 --> Controller Class Initialized
INFO - 2017-03-04 22:40:37 --> Helper loaded: url_helper
DEBUG - 2017-03-04 22:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 22:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 22:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 22:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 22:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 22:40:37 --> Final output sent to browser
DEBUG - 2017-03-04 22:40:37 --> Total execution time: 1.2520
INFO - 2017-03-04 23:01:34 --> Config Class Initialized
INFO - 2017-03-04 23:01:34 --> Hooks Class Initialized
DEBUG - 2017-03-04 23:01:34 --> UTF-8 Support Enabled
INFO - 2017-03-04 23:01:34 --> Utf8 Class Initialized
INFO - 2017-03-04 23:01:34 --> URI Class Initialized
DEBUG - 2017-03-04 23:01:34 --> No URI present. Default controller set.
INFO - 2017-03-04 23:01:34 --> Router Class Initialized
INFO - 2017-03-04 23:01:34 --> Output Class Initialized
INFO - 2017-03-04 23:01:34 --> Security Class Initialized
DEBUG - 2017-03-04 23:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 23:01:34 --> Input Class Initialized
INFO - 2017-03-04 23:01:34 --> Language Class Initialized
INFO - 2017-03-04 23:01:34 --> Loader Class Initialized
INFO - 2017-03-04 23:01:35 --> Database Driver Class Initialized
INFO - 2017-03-04 23:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 23:01:35 --> Controller Class Initialized
INFO - 2017-03-04 23:01:35 --> Helper loaded: url_helper
DEBUG - 2017-03-04 23:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 23:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 23:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 23:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 23:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 23:01:35 --> Final output sent to browser
DEBUG - 2017-03-04 23:01:36 --> Total execution time: 1.2846
INFO - 2017-03-04 23:01:41 --> Config Class Initialized
INFO - 2017-03-04 23:01:41 --> Hooks Class Initialized
DEBUG - 2017-03-04 23:01:41 --> UTF-8 Support Enabled
INFO - 2017-03-04 23:01:41 --> Utf8 Class Initialized
INFO - 2017-03-04 23:01:41 --> URI Class Initialized
DEBUG - 2017-03-04 23:01:41 --> No URI present. Default controller set.
INFO - 2017-03-04 23:01:41 --> Router Class Initialized
INFO - 2017-03-04 23:01:41 --> Output Class Initialized
INFO - 2017-03-04 23:01:41 --> Security Class Initialized
DEBUG - 2017-03-04 23:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 23:01:41 --> Input Class Initialized
INFO - 2017-03-04 23:01:41 --> Language Class Initialized
INFO - 2017-03-04 23:01:41 --> Loader Class Initialized
INFO - 2017-03-04 23:01:42 --> Database Driver Class Initialized
INFO - 2017-03-04 23:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 23:01:42 --> Controller Class Initialized
INFO - 2017-03-04 23:01:42 --> Helper loaded: url_helper
DEBUG - 2017-03-04 23:01:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 23:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 23:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 23:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 23:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 23:01:42 --> Final output sent to browser
DEBUG - 2017-03-04 23:01:42 --> Total execution time: 1.2891
INFO - 2017-03-04 23:01:44 --> Config Class Initialized
INFO - 2017-03-04 23:01:44 --> Hooks Class Initialized
DEBUG - 2017-03-04 23:01:44 --> UTF-8 Support Enabled
INFO - 2017-03-04 23:01:44 --> Utf8 Class Initialized
INFO - 2017-03-04 23:01:44 --> URI Class Initialized
INFO - 2017-03-04 23:01:45 --> Router Class Initialized
INFO - 2017-03-04 23:01:45 --> Output Class Initialized
INFO - 2017-03-04 23:01:45 --> Security Class Initialized
DEBUG - 2017-03-04 23:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 23:01:45 --> Input Class Initialized
INFO - 2017-03-04 23:01:45 --> Language Class Initialized
INFO - 2017-03-04 23:01:45 --> Loader Class Initialized
INFO - 2017-03-04 23:01:45 --> Database Driver Class Initialized
INFO - 2017-03-04 23:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 23:01:45 --> Controller Class Initialized
INFO - 2017-03-04 23:01:45 --> Helper loaded: url_helper
DEBUG - 2017-03-04 23:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-04 23:01:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-04 23:01:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-04 23:01:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-04 23:01:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-04 23:01:46 --> Final output sent to browser
DEBUG - 2017-03-04 23:01:46 --> Total execution time: 1.2189

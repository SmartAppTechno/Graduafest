<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-03 00:48:44 --> Config Class Initialized
INFO - 2017-02-03 00:48:44 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:48:44 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:48:44 --> Utf8 Class Initialized
INFO - 2017-02-03 00:48:44 --> URI Class Initialized
DEBUG - 2017-02-03 00:48:44 --> No URI present. Default controller set.
INFO - 2017-02-03 00:48:44 --> Router Class Initialized
INFO - 2017-02-03 00:48:44 --> Output Class Initialized
INFO - 2017-02-03 00:48:44 --> Security Class Initialized
DEBUG - 2017-02-03 00:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:48:44 --> Input Class Initialized
INFO - 2017-02-03 00:48:44 --> Language Class Initialized
INFO - 2017-02-03 00:48:44 --> Loader Class Initialized
INFO - 2017-02-03 00:48:45 --> Database Driver Class Initialized
INFO - 2017-02-03 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:48:45 --> Controller Class Initialized
INFO - 2017-02-03 00:48:45 --> Helper loaded: url_helper
DEBUG - 2017-02-03 00:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:48:45 --> Final output sent to browser
DEBUG - 2017-02-03 00:48:45 --> Total execution time: 1.8625
INFO - 2017-02-03 00:49:33 --> Config Class Initialized
INFO - 2017-02-03 00:49:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:49:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:49:34 --> Utf8 Class Initialized
INFO - 2017-02-03 00:49:34 --> URI Class Initialized
INFO - 2017-02-03 00:49:34 --> Router Class Initialized
INFO - 2017-02-03 00:49:34 --> Output Class Initialized
INFO - 2017-02-03 00:49:34 --> Security Class Initialized
DEBUG - 2017-02-03 00:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:49:34 --> Input Class Initialized
INFO - 2017-02-03 00:49:34 --> Language Class Initialized
INFO - 2017-02-03 00:49:34 --> Loader Class Initialized
INFO - 2017-02-03 00:49:34 --> Database Driver Class Initialized
INFO - 2017-02-03 00:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:49:34 --> Controller Class Initialized
INFO - 2017-02-03 00:49:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 00:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 00:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 00:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:49:35 --> Final output sent to browser
DEBUG - 2017-02-03 00:49:35 --> Total execution time: 1.4766
INFO - 2017-02-03 00:49:42 --> Config Class Initialized
INFO - 2017-02-03 00:49:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:49:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:49:42 --> Utf8 Class Initialized
INFO - 2017-02-03 00:49:42 --> URI Class Initialized
INFO - 2017-02-03 00:49:42 --> Router Class Initialized
INFO - 2017-02-03 00:49:42 --> Output Class Initialized
INFO - 2017-02-03 00:49:42 --> Security Class Initialized
DEBUG - 2017-02-03 00:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:49:42 --> Input Class Initialized
INFO - 2017-02-03 00:49:42 --> Language Class Initialized
INFO - 2017-02-03 00:49:42 --> Loader Class Initialized
INFO - 2017-02-03 00:49:42 --> Database Driver Class Initialized
INFO - 2017-02-03 00:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:49:43 --> Controller Class Initialized
INFO - 2017-02-03 00:49:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 00:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:49:45 --> Config Class Initialized
INFO - 2017-02-03 00:49:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:49:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:49:45 --> Utf8 Class Initialized
INFO - 2017-02-03 00:49:45 --> URI Class Initialized
INFO - 2017-02-03 00:49:45 --> Router Class Initialized
INFO - 2017-02-03 00:49:45 --> Output Class Initialized
INFO - 2017-02-03 00:49:45 --> Security Class Initialized
DEBUG - 2017-02-03 00:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:49:45 --> Input Class Initialized
INFO - 2017-02-03 00:49:45 --> Language Class Initialized
INFO - 2017-02-03 00:49:45 --> Loader Class Initialized
INFO - 2017-02-03 00:49:45 --> Database Driver Class Initialized
INFO - 2017-02-03 00:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:49:45 --> Controller Class Initialized
INFO - 2017-02-03 00:49:45 --> Helper loaded: date_helper
DEBUG - 2017-02-03 00:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:49:45 --> Helper loaded: url_helper
INFO - 2017-02-03 00:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 00:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 00:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 00:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:49:45 --> Final output sent to browser
DEBUG - 2017-02-03 00:49:45 --> Total execution time: 0.4768
INFO - 2017-02-03 00:50:01 --> Config Class Initialized
INFO - 2017-02-03 00:50:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:50:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:50:01 --> Utf8 Class Initialized
INFO - 2017-02-03 00:50:01 --> URI Class Initialized
INFO - 2017-02-03 00:50:01 --> Router Class Initialized
INFO - 2017-02-03 00:50:01 --> Output Class Initialized
INFO - 2017-02-03 00:50:01 --> Security Class Initialized
DEBUG - 2017-02-03 00:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:50:01 --> Input Class Initialized
INFO - 2017-02-03 00:50:01 --> Language Class Initialized
INFO - 2017-02-03 00:50:01 --> Loader Class Initialized
INFO - 2017-02-03 00:50:01 --> Database Driver Class Initialized
INFO - 2017-02-03 00:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:50:01 --> Controller Class Initialized
INFO - 2017-02-03 00:50:01 --> Helper loaded: url_helper
DEBUG - 2017-02-03 00:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:50:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:50:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 00:50:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 00:50:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:50:01 --> Final output sent to browser
DEBUG - 2017-02-03 00:50:01 --> Total execution time: 0.0224
INFO - 2017-02-03 00:53:53 --> Config Class Initialized
INFO - 2017-02-03 00:53:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:53:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:53:53 --> Utf8 Class Initialized
INFO - 2017-02-03 00:53:53 --> URI Class Initialized
INFO - 2017-02-03 00:53:53 --> Router Class Initialized
INFO - 2017-02-03 00:53:53 --> Output Class Initialized
INFO - 2017-02-03 00:53:53 --> Security Class Initialized
DEBUG - 2017-02-03 00:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:53:53 --> Input Class Initialized
INFO - 2017-02-03 00:53:53 --> Language Class Initialized
INFO - 2017-02-03 00:53:54 --> Loader Class Initialized
INFO - 2017-02-03 00:53:54 --> Database Driver Class Initialized
INFO - 2017-02-03 00:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:53:54 --> Controller Class Initialized
INFO - 2017-02-03 00:53:55 --> Helper loaded: date_helper
DEBUG - 2017-02-03 00:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:53:55 --> Helper loaded: url_helper
INFO - 2017-02-03 00:53:55 --> Helper loaded: download_helper
INFO - 2017-02-03 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:53:55 --> Final output sent to browser
DEBUG - 2017-02-03 00:53:55 --> Total execution time: 2.2289
INFO - 2017-02-03 00:53:58 --> Config Class Initialized
INFO - 2017-02-03 00:53:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:53:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:53:58 --> Utf8 Class Initialized
INFO - 2017-02-03 00:53:58 --> URI Class Initialized
INFO - 2017-02-03 00:53:58 --> Router Class Initialized
INFO - 2017-02-03 00:53:58 --> Output Class Initialized
INFO - 2017-02-03 00:53:58 --> Security Class Initialized
DEBUG - 2017-02-03 00:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:53:58 --> Input Class Initialized
INFO - 2017-02-03 00:53:58 --> Language Class Initialized
INFO - 2017-02-03 00:53:58 --> Loader Class Initialized
INFO - 2017-02-03 00:53:58 --> Database Driver Class Initialized
INFO - 2017-02-03 00:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:53:58 --> Controller Class Initialized
INFO - 2017-02-03 00:53:58 --> Helper loaded: url_helper
DEBUG - 2017-02-03 00:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 00:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 00:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:53:58 --> Final output sent to browser
DEBUG - 2017-02-03 00:53:58 --> Total execution time: 0.2642
INFO - 2017-02-03 00:54:31 --> Config Class Initialized
INFO - 2017-02-03 00:54:31 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:54:31 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:54:31 --> Utf8 Class Initialized
INFO - 2017-02-03 00:54:31 --> URI Class Initialized
INFO - 2017-02-03 00:54:32 --> Router Class Initialized
INFO - 2017-02-03 00:54:32 --> Output Class Initialized
INFO - 2017-02-03 00:54:32 --> Security Class Initialized
DEBUG - 2017-02-03 00:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:54:32 --> Input Class Initialized
INFO - 2017-02-03 00:54:32 --> Language Class Initialized
INFO - 2017-02-03 00:54:32 --> Loader Class Initialized
INFO - 2017-02-03 00:54:32 --> Database Driver Class Initialized
INFO - 2017-02-03 00:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:54:32 --> Controller Class Initialized
INFO - 2017-02-03 00:54:32 --> Helper loaded: date_helper
DEBUG - 2017-02-03 00:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:54:32 --> Helper loaded: url_helper
INFO - 2017-02-03 00:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 00:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 00:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 00:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:54:33 --> Final output sent to browser
DEBUG - 2017-02-03 00:54:33 --> Total execution time: 1.6231
INFO - 2017-02-03 00:55:37 --> Config Class Initialized
INFO - 2017-02-03 00:55:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 00:55:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 00:55:37 --> Utf8 Class Initialized
INFO - 2017-02-03 00:55:37 --> URI Class Initialized
DEBUG - 2017-02-03 00:55:37 --> No URI present. Default controller set.
INFO - 2017-02-03 00:55:37 --> Router Class Initialized
INFO - 2017-02-03 00:55:37 --> Output Class Initialized
INFO - 2017-02-03 00:55:37 --> Security Class Initialized
DEBUG - 2017-02-03 00:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 00:55:37 --> Input Class Initialized
INFO - 2017-02-03 00:55:37 --> Language Class Initialized
INFO - 2017-02-03 00:55:37 --> Loader Class Initialized
INFO - 2017-02-03 00:55:38 --> Database Driver Class Initialized
INFO - 2017-02-03 00:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 00:55:38 --> Controller Class Initialized
INFO - 2017-02-03 00:55:38 --> Helper loaded: url_helper
DEBUG - 2017-02-03 00:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 00:55:38 --> Final output sent to browser
DEBUG - 2017-02-03 00:55:38 --> Total execution time: 1.8037
INFO - 2017-02-03 02:25:28 --> Config Class Initialized
INFO - 2017-02-03 02:25:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:25:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:25:28 --> Utf8 Class Initialized
INFO - 2017-02-03 02:25:28 --> URI Class Initialized
DEBUG - 2017-02-03 02:25:28 --> No URI present. Default controller set.
INFO - 2017-02-03 02:25:28 --> Router Class Initialized
INFO - 2017-02-03 02:25:28 --> Output Class Initialized
INFO - 2017-02-03 02:25:28 --> Security Class Initialized
DEBUG - 2017-02-03 02:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:25:29 --> Input Class Initialized
INFO - 2017-02-03 02:25:29 --> Language Class Initialized
INFO - 2017-02-03 02:25:29 --> Loader Class Initialized
INFO - 2017-02-03 02:25:29 --> Database Driver Class Initialized
INFO - 2017-02-03 02:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:25:30 --> Controller Class Initialized
INFO - 2017-02-03 02:25:30 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:25:30 --> Final output sent to browser
DEBUG - 2017-02-03 02:25:30 --> Total execution time: 2.0457
INFO - 2017-02-03 02:46:50 --> Config Class Initialized
INFO - 2017-02-03 02:46:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:46:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:46:50 --> Utf8 Class Initialized
INFO - 2017-02-03 02:46:50 --> URI Class Initialized
DEBUG - 2017-02-03 02:46:50 --> No URI present. Default controller set.
INFO - 2017-02-03 02:46:50 --> Router Class Initialized
INFO - 2017-02-03 02:46:50 --> Output Class Initialized
INFO - 2017-02-03 02:46:50 --> Security Class Initialized
DEBUG - 2017-02-03 02:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:46:50 --> Input Class Initialized
INFO - 2017-02-03 02:46:50 --> Language Class Initialized
INFO - 2017-02-03 02:46:50 --> Loader Class Initialized
INFO - 2017-02-03 02:46:51 --> Database Driver Class Initialized
INFO - 2017-02-03 02:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:46:51 --> Controller Class Initialized
INFO - 2017-02-03 02:46:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:46:52 --> Final output sent to browser
DEBUG - 2017-02-03 02:46:52 --> Total execution time: 1.7427
INFO - 2017-02-03 02:46:54 --> Config Class Initialized
INFO - 2017-02-03 02:46:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:46:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:46:54 --> Utf8 Class Initialized
INFO - 2017-02-03 02:46:54 --> URI Class Initialized
INFO - 2017-02-03 02:46:54 --> Router Class Initialized
INFO - 2017-02-03 02:46:54 --> Output Class Initialized
INFO - 2017-02-03 02:46:54 --> Security Class Initialized
DEBUG - 2017-02-03 02:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:46:54 --> Input Class Initialized
INFO - 2017-02-03 02:46:54 --> Language Class Initialized
INFO - 2017-02-03 02:46:54 --> Loader Class Initialized
INFO - 2017-02-03 02:46:54 --> Database Driver Class Initialized
INFO - 2017-02-03 02:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:46:54 --> Controller Class Initialized
INFO - 2017-02-03 02:46:54 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:46:54 --> Final output sent to browser
DEBUG - 2017-02-03 02:46:54 --> Total execution time: 0.0134
INFO - 2017-02-03 02:52:30 --> Config Class Initialized
INFO - 2017-02-03 02:52:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:52:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:52:30 --> Utf8 Class Initialized
INFO - 2017-02-03 02:52:30 --> URI Class Initialized
DEBUG - 2017-02-03 02:52:30 --> No URI present. Default controller set.
INFO - 2017-02-03 02:52:30 --> Router Class Initialized
INFO - 2017-02-03 02:52:30 --> Output Class Initialized
INFO - 2017-02-03 02:52:30 --> Security Class Initialized
DEBUG - 2017-02-03 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:52:31 --> Input Class Initialized
INFO - 2017-02-03 02:52:31 --> Language Class Initialized
INFO - 2017-02-03 02:52:31 --> Loader Class Initialized
INFO - 2017-02-03 02:52:31 --> Database Driver Class Initialized
INFO - 2017-02-03 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:52:31 --> Controller Class Initialized
INFO - 2017-02-03 02:52:31 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:52:32 --> Final output sent to browser
DEBUG - 2017-02-03 02:52:32 --> Total execution time: 1.7459
INFO - 2017-02-03 02:52:40 --> Config Class Initialized
INFO - 2017-02-03 02:52:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:52:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:52:40 --> Utf8 Class Initialized
INFO - 2017-02-03 02:52:40 --> URI Class Initialized
INFO - 2017-02-03 02:52:41 --> Router Class Initialized
INFO - 2017-02-03 02:52:41 --> Output Class Initialized
INFO - 2017-02-03 02:52:41 --> Security Class Initialized
DEBUG - 2017-02-03 02:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:52:41 --> Input Class Initialized
INFO - 2017-02-03 02:52:41 --> Language Class Initialized
INFO - 2017-02-03 02:52:41 --> Loader Class Initialized
INFO - 2017-02-03 02:52:41 --> Database Driver Class Initialized
INFO - 2017-02-03 02:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:52:41 --> Controller Class Initialized
INFO - 2017-02-03 02:52:41 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:52:42 --> Final output sent to browser
DEBUG - 2017-02-03 02:52:42 --> Total execution time: 1.2352
INFO - 2017-02-03 02:53:12 --> Config Class Initialized
INFO - 2017-02-03 02:53:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:12 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:12 --> URI Class Initialized
INFO - 2017-02-03 02:53:12 --> Router Class Initialized
INFO - 2017-02-03 02:53:12 --> Output Class Initialized
INFO - 2017-02-03 02:53:12 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:12 --> Input Class Initialized
INFO - 2017-02-03 02:53:12 --> Language Class Initialized
INFO - 2017-02-03 02:53:13 --> Loader Class Initialized
INFO - 2017-02-03 02:53:13 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:13 --> Controller Class Initialized
INFO - 2017-02-03 02:53:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:15 --> Config Class Initialized
INFO - 2017-02-03 02:53:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:15 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:15 --> URI Class Initialized
INFO - 2017-02-03 02:53:15 --> Router Class Initialized
INFO - 2017-02-03 02:53:15 --> Output Class Initialized
INFO - 2017-02-03 02:53:15 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:15 --> Input Class Initialized
INFO - 2017-02-03 02:53:15 --> Language Class Initialized
INFO - 2017-02-03 02:53:15 --> Loader Class Initialized
INFO - 2017-02-03 02:53:15 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:15 --> Controller Class Initialized
INFO - 2017-02-03 02:53:15 --> Helper loaded: date_helper
DEBUG - 2017-02-03 02:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:15 --> Helper loaded: url_helper
INFO - 2017-02-03 02:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 02:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 02:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 02:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:53:15 --> Final output sent to browser
DEBUG - 2017-02-03 02:53:15 --> Total execution time: 0.1128
INFO - 2017-02-03 02:53:18 --> Config Class Initialized
INFO - 2017-02-03 02:53:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:18 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:18 --> URI Class Initialized
INFO - 2017-02-03 02:53:18 --> Router Class Initialized
INFO - 2017-02-03 02:53:18 --> Output Class Initialized
INFO - 2017-02-03 02:53:18 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:18 --> Input Class Initialized
INFO - 2017-02-03 02:53:18 --> Language Class Initialized
INFO - 2017-02-03 02:53:18 --> Loader Class Initialized
INFO - 2017-02-03 02:53:18 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:18 --> Controller Class Initialized
INFO - 2017-02-03 02:53:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:53:18 --> Final output sent to browser
DEBUG - 2017-02-03 02:53:18 --> Total execution time: 0.0448
INFO - 2017-02-03 02:53:27 --> Config Class Initialized
INFO - 2017-02-03 02:53:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:27 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:27 --> URI Class Initialized
INFO - 2017-02-03 02:53:27 --> Router Class Initialized
INFO - 2017-02-03 02:53:27 --> Output Class Initialized
INFO - 2017-02-03 02:53:27 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:27 --> Input Class Initialized
INFO - 2017-02-03 02:53:27 --> Language Class Initialized
INFO - 2017-02-03 02:53:27 --> Loader Class Initialized
INFO - 2017-02-03 02:53:27 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:27 --> Controller Class Initialized
INFO - 2017-02-03 02:53:27 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:28 --> Config Class Initialized
INFO - 2017-02-03 02:53:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:28 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:28 --> URI Class Initialized
INFO - 2017-02-03 02:53:28 --> Router Class Initialized
INFO - 2017-02-03 02:53:28 --> Output Class Initialized
INFO - 2017-02-03 02:53:28 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:28 --> Input Class Initialized
INFO - 2017-02-03 02:53:28 --> Language Class Initialized
INFO - 2017-02-03 02:53:28 --> Loader Class Initialized
INFO - 2017-02-03 02:53:28 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:28 --> Controller Class Initialized
INFO - 2017-02-03 02:53:28 --> Helper loaded: date_helper
DEBUG - 2017-02-03 02:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:28 --> Helper loaded: url_helper
INFO - 2017-02-03 02:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 02:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 02:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 02:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:53:28 --> Final output sent to browser
DEBUG - 2017-02-03 02:53:28 --> Total execution time: 0.0143
INFO - 2017-02-03 02:53:29 --> Config Class Initialized
INFO - 2017-02-03 02:53:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:29 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:29 --> URI Class Initialized
INFO - 2017-02-03 02:53:29 --> Router Class Initialized
INFO - 2017-02-03 02:53:29 --> Output Class Initialized
INFO - 2017-02-03 02:53:29 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:29 --> Input Class Initialized
INFO - 2017-02-03 02:53:29 --> Language Class Initialized
INFO - 2017-02-03 02:53:29 --> Loader Class Initialized
INFO - 2017-02-03 02:53:29 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:29 --> Controller Class Initialized
INFO - 2017-02-03 02:53:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:53:29 --> Final output sent to browser
DEBUG - 2017-02-03 02:53:29 --> Total execution time: 0.0143
INFO - 2017-02-03 02:53:51 --> Config Class Initialized
INFO - 2017-02-03 02:53:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:51 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:51 --> URI Class Initialized
DEBUG - 2017-02-03 02:53:51 --> No URI present. Default controller set.
INFO - 2017-02-03 02:53:51 --> Router Class Initialized
INFO - 2017-02-03 02:53:51 --> Output Class Initialized
INFO - 2017-02-03 02:53:52 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:52 --> Input Class Initialized
INFO - 2017-02-03 02:53:52 --> Language Class Initialized
INFO - 2017-02-03 02:53:52 --> Loader Class Initialized
INFO - 2017-02-03 02:53:52 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:52 --> Controller Class Initialized
INFO - 2017-02-03 02:53:52 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:53:53 --> Final output sent to browser
DEBUG - 2017-02-03 02:53:53 --> Total execution time: 1.5168
INFO - 2017-02-03 02:53:59 --> Config Class Initialized
INFO - 2017-02-03 02:53:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:53:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:53:59 --> Utf8 Class Initialized
INFO - 2017-02-03 02:53:59 --> URI Class Initialized
INFO - 2017-02-03 02:53:59 --> Router Class Initialized
INFO - 2017-02-03 02:53:59 --> Output Class Initialized
INFO - 2017-02-03 02:53:59 --> Security Class Initialized
DEBUG - 2017-02-03 02:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:53:59 --> Input Class Initialized
INFO - 2017-02-03 02:53:59 --> Language Class Initialized
INFO - 2017-02-03 02:53:59 --> Loader Class Initialized
INFO - 2017-02-03 02:53:59 --> Database Driver Class Initialized
INFO - 2017-02-03 02:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:53:59 --> Controller Class Initialized
INFO - 2017-02-03 02:53:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:53:59 --> Final output sent to browser
DEBUG - 2017-02-03 02:53:59 --> Total execution time: 0.0330
INFO - 2017-02-03 02:54:24 --> Config Class Initialized
INFO - 2017-02-03 02:54:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:54:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:54:24 --> Utf8 Class Initialized
INFO - 2017-02-03 02:54:24 --> URI Class Initialized
INFO - 2017-02-03 02:54:24 --> Router Class Initialized
INFO - 2017-02-03 02:54:24 --> Output Class Initialized
INFO - 2017-02-03 02:54:24 --> Security Class Initialized
DEBUG - 2017-02-03 02:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:54:24 --> Input Class Initialized
INFO - 2017-02-03 02:54:24 --> Language Class Initialized
INFO - 2017-02-03 02:54:24 --> Loader Class Initialized
INFO - 2017-02-03 02:54:24 --> Database Driver Class Initialized
INFO - 2017-02-03 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:54:24 --> Controller Class Initialized
INFO - 2017-02-03 02:54:24 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-03 02:54:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-03 02:54:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-03 02:54:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-03 02:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:54:24 --> Final output sent to browser
DEBUG - 2017-02-03 02:54:24 --> Total execution time: 0.0449
INFO - 2017-02-03 02:54:28 --> Config Class Initialized
INFO - 2017-02-03 02:54:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:54:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:54:28 --> Utf8 Class Initialized
INFO - 2017-02-03 02:54:28 --> URI Class Initialized
INFO - 2017-02-03 02:54:28 --> Router Class Initialized
INFO - 2017-02-03 02:54:28 --> Output Class Initialized
INFO - 2017-02-03 02:54:28 --> Security Class Initialized
DEBUG - 2017-02-03 02:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:54:28 --> Input Class Initialized
INFO - 2017-02-03 02:54:28 --> Language Class Initialized
INFO - 2017-02-03 02:54:28 --> Loader Class Initialized
INFO - 2017-02-03 02:54:28 --> Database Driver Class Initialized
INFO - 2017-02-03 02:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:54:28 --> Controller Class Initialized
INFO - 2017-02-03 02:54:28 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:54:28 --> Final output sent to browser
DEBUG - 2017-02-03 02:54:28 --> Total execution time: 0.0135
INFO - 2017-02-03 02:54:47 --> Config Class Initialized
INFO - 2017-02-03 02:54:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:54:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:54:47 --> Utf8 Class Initialized
INFO - 2017-02-03 02:54:47 --> URI Class Initialized
INFO - 2017-02-03 02:54:47 --> Router Class Initialized
INFO - 2017-02-03 02:54:47 --> Output Class Initialized
INFO - 2017-02-03 02:54:47 --> Security Class Initialized
DEBUG - 2017-02-03 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:54:47 --> Input Class Initialized
INFO - 2017-02-03 02:54:47 --> Language Class Initialized
INFO - 2017-02-03 02:54:47 --> Loader Class Initialized
INFO - 2017-02-03 02:54:47 --> Database Driver Class Initialized
INFO - 2017-02-03 02:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:54:47 --> Controller Class Initialized
INFO - 2017-02-03 02:54:47 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:54:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:54:49 --> Config Class Initialized
INFO - 2017-02-03 02:54:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:54:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:54:49 --> Utf8 Class Initialized
INFO - 2017-02-03 02:54:49 --> URI Class Initialized
INFO - 2017-02-03 02:54:49 --> Router Class Initialized
INFO - 2017-02-03 02:54:49 --> Output Class Initialized
INFO - 2017-02-03 02:54:49 --> Security Class Initialized
DEBUG - 2017-02-03 02:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:54:49 --> Input Class Initialized
INFO - 2017-02-03 02:54:49 --> Language Class Initialized
INFO - 2017-02-03 02:54:49 --> Loader Class Initialized
INFO - 2017-02-03 02:54:49 --> Database Driver Class Initialized
INFO - 2017-02-03 02:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:54:49 --> Controller Class Initialized
INFO - 2017-02-03 02:54:49 --> Helper loaded: date_helper
DEBUG - 2017-02-03 02:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:54:49 --> Helper loaded: url_helper
INFO - 2017-02-03 02:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 02:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 02:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 02:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:54:49 --> Final output sent to browser
DEBUG - 2017-02-03 02:54:49 --> Total execution time: 0.0550
INFO - 2017-02-03 02:54:50 --> Config Class Initialized
INFO - 2017-02-03 02:54:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:54:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:54:50 --> Utf8 Class Initialized
INFO - 2017-02-03 02:54:50 --> URI Class Initialized
INFO - 2017-02-03 02:54:50 --> Router Class Initialized
INFO - 2017-02-03 02:54:50 --> Output Class Initialized
INFO - 2017-02-03 02:54:50 --> Security Class Initialized
DEBUG - 2017-02-03 02:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:54:50 --> Input Class Initialized
INFO - 2017-02-03 02:54:50 --> Language Class Initialized
INFO - 2017-02-03 02:54:50 --> Loader Class Initialized
INFO - 2017-02-03 02:54:50 --> Database Driver Class Initialized
INFO - 2017-02-03 02:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:54:50 --> Controller Class Initialized
INFO - 2017-02-03 02:54:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:54:50 --> Final output sent to browser
DEBUG - 2017-02-03 02:54:50 --> Total execution time: 0.0137
INFO - 2017-02-03 02:55:04 --> Config Class Initialized
INFO - 2017-02-03 02:55:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:55:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:55:04 --> Utf8 Class Initialized
INFO - 2017-02-03 02:55:04 --> URI Class Initialized
INFO - 2017-02-03 02:55:04 --> Router Class Initialized
INFO - 2017-02-03 02:55:04 --> Output Class Initialized
INFO - 2017-02-03 02:55:04 --> Security Class Initialized
DEBUG - 2017-02-03 02:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:55:04 --> Input Class Initialized
INFO - 2017-02-03 02:55:04 --> Language Class Initialized
INFO - 2017-02-03 02:55:04 --> Loader Class Initialized
INFO - 2017-02-03 02:55:04 --> Database Driver Class Initialized
INFO - 2017-02-03 02:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:55:04 --> Controller Class Initialized
INFO - 2017-02-03 02:55:04 --> Helper loaded: date_helper
DEBUG - 2017-02-03 02:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:55:04 --> Helper loaded: url_helper
INFO - 2017-02-03 02:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 02:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 02:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 02:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:55:04 --> Final output sent to browser
DEBUG - 2017-02-03 02:55:04 --> Total execution time: 0.2287
INFO - 2017-02-03 02:55:06 --> Config Class Initialized
INFO - 2017-02-03 02:55:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:55:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:55:06 --> Utf8 Class Initialized
INFO - 2017-02-03 02:55:06 --> URI Class Initialized
INFO - 2017-02-03 02:55:06 --> Router Class Initialized
INFO - 2017-02-03 02:55:06 --> Output Class Initialized
INFO - 2017-02-03 02:55:06 --> Security Class Initialized
DEBUG - 2017-02-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:55:06 --> Input Class Initialized
INFO - 2017-02-03 02:55:06 --> Language Class Initialized
INFO - 2017-02-03 02:55:06 --> Loader Class Initialized
INFO - 2017-02-03 02:55:06 --> Database Driver Class Initialized
INFO - 2017-02-03 02:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:55:06 --> Controller Class Initialized
INFO - 2017-02-03 02:55:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:55:06 --> Final output sent to browser
DEBUG - 2017-02-03 02:55:06 --> Total execution time: 0.0144
INFO - 2017-02-03 02:55:13 --> Config Class Initialized
INFO - 2017-02-03 02:55:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:55:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:55:13 --> Utf8 Class Initialized
INFO - 2017-02-03 02:55:13 --> URI Class Initialized
INFO - 2017-02-03 02:55:13 --> Router Class Initialized
INFO - 2017-02-03 02:55:13 --> Output Class Initialized
INFO - 2017-02-03 02:55:13 --> Security Class Initialized
DEBUG - 2017-02-03 02:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:55:13 --> Input Class Initialized
INFO - 2017-02-03 02:55:13 --> Language Class Initialized
INFO - 2017-02-03 02:55:13 --> Loader Class Initialized
INFO - 2017-02-03 02:55:13 --> Database Driver Class Initialized
INFO - 2017-02-03 02:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:55:13 --> Controller Class Initialized
INFO - 2017-02-03 02:55:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:55:13 --> Config Class Initialized
INFO - 2017-02-03 02:55:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:55:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:55:13 --> Utf8 Class Initialized
INFO - 2017-02-03 02:55:13 --> URI Class Initialized
DEBUG - 2017-02-03 02:55:13 --> No URI present. Default controller set.
INFO - 2017-02-03 02:55:13 --> Router Class Initialized
INFO - 2017-02-03 02:55:13 --> Output Class Initialized
INFO - 2017-02-03 02:55:13 --> Security Class Initialized
DEBUG - 2017-02-03 02:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:55:13 --> Input Class Initialized
INFO - 2017-02-03 02:55:13 --> Language Class Initialized
INFO - 2017-02-03 02:55:13 --> Loader Class Initialized
INFO - 2017-02-03 02:55:13 --> Database Driver Class Initialized
INFO - 2017-02-03 02:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:55:13 --> Controller Class Initialized
INFO - 2017-02-03 02:55:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:55:13 --> Final output sent to browser
DEBUG - 2017-02-03 02:55:13 --> Total execution time: 0.0209
INFO - 2017-02-03 02:55:15 --> Config Class Initialized
INFO - 2017-02-03 02:55:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 02:55:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 02:55:15 --> Utf8 Class Initialized
INFO - 2017-02-03 02:55:15 --> URI Class Initialized
INFO - 2017-02-03 02:55:15 --> Router Class Initialized
INFO - 2017-02-03 02:55:15 --> Output Class Initialized
INFO - 2017-02-03 02:55:15 --> Security Class Initialized
DEBUG - 2017-02-03 02:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 02:55:15 --> Input Class Initialized
INFO - 2017-02-03 02:55:15 --> Language Class Initialized
INFO - 2017-02-03 02:55:15 --> Loader Class Initialized
INFO - 2017-02-03 02:55:15 --> Database Driver Class Initialized
INFO - 2017-02-03 02:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 02:55:15 --> Controller Class Initialized
INFO - 2017-02-03 02:55:15 --> Helper loaded: url_helper
DEBUG - 2017-02-03 02:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 02:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 02:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 02:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 02:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 02:55:15 --> Final output sent to browser
DEBUG - 2017-02-03 02:55:15 --> Total execution time: 0.0149
INFO - 2017-02-03 03:07:24 --> Config Class Initialized
INFO - 2017-02-03 03:07:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:07:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:07:24 --> Utf8 Class Initialized
INFO - 2017-02-03 03:07:24 --> URI Class Initialized
DEBUG - 2017-02-03 03:07:24 --> No URI present. Default controller set.
INFO - 2017-02-03 03:07:24 --> Router Class Initialized
INFO - 2017-02-03 03:07:24 --> Output Class Initialized
INFO - 2017-02-03 03:07:25 --> Security Class Initialized
DEBUG - 2017-02-03 03:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:07:25 --> Input Class Initialized
INFO - 2017-02-03 03:07:25 --> Language Class Initialized
INFO - 2017-02-03 03:07:25 --> Loader Class Initialized
INFO - 2017-02-03 03:07:25 --> Database Driver Class Initialized
INFO - 2017-02-03 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:07:26 --> Controller Class Initialized
INFO - 2017-02-03 03:07:26 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:07:30 --> Final output sent to browser
DEBUG - 2017-02-03 03:07:30 --> Total execution time: 6.0200
INFO - 2017-02-03 03:08:29 --> Config Class Initialized
INFO - 2017-02-03 03:08:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:08:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:08:29 --> Utf8 Class Initialized
INFO - 2017-02-03 03:08:29 --> URI Class Initialized
DEBUG - 2017-02-03 03:08:29 --> No URI present. Default controller set.
INFO - 2017-02-03 03:08:29 --> Router Class Initialized
INFO - 2017-02-03 03:08:29 --> Output Class Initialized
INFO - 2017-02-03 03:08:29 --> Security Class Initialized
DEBUG - 2017-02-03 03:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:08:29 --> Input Class Initialized
INFO - 2017-02-03 03:08:29 --> Language Class Initialized
INFO - 2017-02-03 03:08:29 --> Loader Class Initialized
INFO - 2017-02-03 03:08:31 --> Database Driver Class Initialized
INFO - 2017-02-03 03:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:08:31 --> Controller Class Initialized
INFO - 2017-02-03 03:08:31 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:08:31 --> Final output sent to browser
DEBUG - 2017-02-03 03:08:32 --> Total execution time: 2.5401
INFO - 2017-02-03 03:33:11 --> Config Class Initialized
INFO - 2017-02-03 03:33:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:33:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:33:11 --> Utf8 Class Initialized
INFO - 2017-02-03 03:33:11 --> URI Class Initialized
DEBUG - 2017-02-03 03:33:12 --> No URI present. Default controller set.
INFO - 2017-02-03 03:33:12 --> Router Class Initialized
INFO - 2017-02-03 03:33:12 --> Output Class Initialized
INFO - 2017-02-03 03:33:12 --> Security Class Initialized
DEBUG - 2017-02-03 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:33:12 --> Input Class Initialized
INFO - 2017-02-03 03:33:12 --> Language Class Initialized
INFO - 2017-02-03 03:33:12 --> Loader Class Initialized
INFO - 2017-02-03 03:33:12 --> Database Driver Class Initialized
INFO - 2017-02-03 03:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:33:13 --> Controller Class Initialized
INFO - 2017-02-03 03:33:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:33:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:33:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:33:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:33:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:33:13 --> Final output sent to browser
DEBUG - 2017-02-03 03:33:13 --> Total execution time: 1.7342
INFO - 2017-02-03 03:55:38 --> Config Class Initialized
INFO - 2017-02-03 03:55:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:55:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:55:39 --> Utf8 Class Initialized
INFO - 2017-02-03 03:55:39 --> URI Class Initialized
DEBUG - 2017-02-03 03:55:39 --> No URI present. Default controller set.
INFO - 2017-02-03 03:55:39 --> Router Class Initialized
INFO - 2017-02-03 03:55:39 --> Output Class Initialized
INFO - 2017-02-03 03:55:39 --> Security Class Initialized
DEBUG - 2017-02-03 03:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:55:39 --> Input Class Initialized
INFO - 2017-02-03 03:55:39 --> Language Class Initialized
INFO - 2017-02-03 03:55:39 --> Loader Class Initialized
INFO - 2017-02-03 03:55:39 --> Database Driver Class Initialized
INFO - 2017-02-03 03:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:55:40 --> Controller Class Initialized
INFO - 2017-02-03 03:55:40 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:55:40 --> Final output sent to browser
DEBUG - 2017-02-03 03:55:40 --> Total execution time: 1.8208
INFO - 2017-02-03 03:55:49 --> Config Class Initialized
INFO - 2017-02-03 03:55:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:55:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:55:49 --> Utf8 Class Initialized
INFO - 2017-02-03 03:55:49 --> URI Class Initialized
INFO - 2017-02-03 03:55:49 --> Router Class Initialized
INFO - 2017-02-03 03:55:49 --> Output Class Initialized
INFO - 2017-02-03 03:55:49 --> Security Class Initialized
DEBUG - 2017-02-03 03:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:55:49 --> Input Class Initialized
INFO - 2017-02-03 03:55:49 --> Language Class Initialized
INFO - 2017-02-03 03:55:49 --> Loader Class Initialized
INFO - 2017-02-03 03:55:49 --> Database Driver Class Initialized
INFO - 2017-02-03 03:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:55:49 --> Controller Class Initialized
INFO - 2017-02-03 03:55:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:55:49 --> Final output sent to browser
DEBUG - 2017-02-03 03:55:49 --> Total execution time: 0.0146
INFO - 2017-02-03 03:58:10 --> Config Class Initialized
INFO - 2017-02-03 03:58:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:58:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:58:10 --> Utf8 Class Initialized
INFO - 2017-02-03 03:58:10 --> URI Class Initialized
INFO - 2017-02-03 03:58:10 --> Router Class Initialized
INFO - 2017-02-03 03:58:10 --> Output Class Initialized
INFO - 2017-02-03 03:58:10 --> Security Class Initialized
DEBUG - 2017-02-03 03:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:58:10 --> Input Class Initialized
INFO - 2017-02-03 03:58:10 --> Language Class Initialized
INFO - 2017-02-03 03:58:10 --> Loader Class Initialized
INFO - 2017-02-03 03:58:11 --> Database Driver Class Initialized
INFO - 2017-02-03 03:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:58:12 --> Controller Class Initialized
INFO - 2017-02-03 03:58:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:58:18 --> Config Class Initialized
INFO - 2017-02-03 03:58:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:58:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:58:18 --> Utf8 Class Initialized
INFO - 2017-02-03 03:58:18 --> URI Class Initialized
INFO - 2017-02-03 03:58:18 --> Router Class Initialized
INFO - 2017-02-03 03:58:18 --> Output Class Initialized
INFO - 2017-02-03 03:58:18 --> Security Class Initialized
DEBUG - 2017-02-03 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:58:18 --> Input Class Initialized
INFO - 2017-02-03 03:58:18 --> Language Class Initialized
INFO - 2017-02-03 03:58:18 --> Loader Class Initialized
INFO - 2017-02-03 03:58:18 --> Database Driver Class Initialized
INFO - 2017-02-03 03:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:58:18 --> Controller Class Initialized
INFO - 2017-02-03 03:58:18 --> Helper loaded: date_helper
DEBUG - 2017-02-03 03:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:58:18 --> Helper loaded: url_helper
INFO - 2017-02-03 03:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:58:19 --> Final output sent to browser
DEBUG - 2017-02-03 03:58:19 --> Total execution time: 1.0709
INFO - 2017-02-03 03:58:21 --> Config Class Initialized
INFO - 2017-02-03 03:58:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:58:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:58:21 --> Utf8 Class Initialized
INFO - 2017-02-03 03:58:21 --> URI Class Initialized
INFO - 2017-02-03 03:58:21 --> Router Class Initialized
INFO - 2017-02-03 03:58:21 --> Output Class Initialized
INFO - 2017-02-03 03:58:21 --> Security Class Initialized
DEBUG - 2017-02-03 03:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:58:21 --> Input Class Initialized
INFO - 2017-02-03 03:58:21 --> Language Class Initialized
INFO - 2017-02-03 03:58:21 --> Loader Class Initialized
INFO - 2017-02-03 03:58:21 --> Database Driver Class Initialized
INFO - 2017-02-03 03:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:58:21 --> Controller Class Initialized
INFO - 2017-02-03 03:58:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:58:21 --> Final output sent to browser
DEBUG - 2017-02-03 03:58:21 --> Total execution time: 0.4008
INFO - 2017-02-03 03:58:33 --> Config Class Initialized
INFO - 2017-02-03 03:58:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:58:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:58:33 --> Utf8 Class Initialized
INFO - 2017-02-03 03:58:33 --> URI Class Initialized
DEBUG - 2017-02-03 03:58:33 --> No URI present. Default controller set.
INFO - 2017-02-03 03:58:33 --> Router Class Initialized
INFO - 2017-02-03 03:58:33 --> Output Class Initialized
INFO - 2017-02-03 03:58:33 --> Security Class Initialized
DEBUG - 2017-02-03 03:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:58:34 --> Input Class Initialized
INFO - 2017-02-03 03:58:34 --> Language Class Initialized
INFO - 2017-02-03 03:58:34 --> Loader Class Initialized
INFO - 2017-02-03 03:58:34 --> Database Driver Class Initialized
INFO - 2017-02-03 03:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:58:34 --> Controller Class Initialized
INFO - 2017-02-03 03:58:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:58:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:58:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:58:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:58:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:58:34 --> Final output sent to browser
DEBUG - 2017-02-03 03:58:34 --> Total execution time: 1.2287
INFO - 2017-02-03 03:58:40 --> Config Class Initialized
INFO - 2017-02-03 03:58:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 03:58:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 03:58:40 --> Utf8 Class Initialized
INFO - 2017-02-03 03:58:40 --> URI Class Initialized
INFO - 2017-02-03 03:58:40 --> Router Class Initialized
INFO - 2017-02-03 03:58:40 --> Output Class Initialized
INFO - 2017-02-03 03:58:40 --> Security Class Initialized
DEBUG - 2017-02-03 03:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 03:58:40 --> Input Class Initialized
INFO - 2017-02-03 03:58:41 --> Language Class Initialized
INFO - 2017-02-03 03:58:41 --> Loader Class Initialized
INFO - 2017-02-03 03:58:41 --> Database Driver Class Initialized
INFO - 2017-02-03 03:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 03:58:41 --> Controller Class Initialized
INFO - 2017-02-03 03:58:41 --> Helper loaded: url_helper
DEBUG - 2017-02-03 03:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 03:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 03:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 03:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 03:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 03:58:41 --> Final output sent to browser
DEBUG - 2017-02-03 03:58:41 --> Total execution time: 1.1615
INFO - 2017-02-03 04:00:14 --> Config Class Initialized
INFO - 2017-02-03 04:00:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:00:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:00:14 --> Utf8 Class Initialized
INFO - 2017-02-03 04:00:14 --> URI Class Initialized
INFO - 2017-02-03 04:00:14 --> Router Class Initialized
INFO - 2017-02-03 04:00:14 --> Output Class Initialized
INFO - 2017-02-03 04:00:14 --> Security Class Initialized
DEBUG - 2017-02-03 04:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:00:14 --> Input Class Initialized
INFO - 2017-02-03 04:00:14 --> Language Class Initialized
INFO - 2017-02-03 04:00:14 --> Loader Class Initialized
INFO - 2017-02-03 04:00:15 --> Database Driver Class Initialized
INFO - 2017-02-03 04:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:00:15 --> Controller Class Initialized
INFO - 2017-02-03 04:00:15 --> Helper loaded: date_helper
DEBUG - 2017-02-03 04:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:00:15 --> Helper loaded: url_helper
INFO - 2017-02-03 04:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 04:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 04:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 04:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:00:15 --> Final output sent to browser
DEBUG - 2017-02-03 04:00:15 --> Total execution time: 1.3593
INFO - 2017-02-03 04:00:18 --> Config Class Initialized
INFO - 2017-02-03 04:00:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:00:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:00:18 --> Utf8 Class Initialized
INFO - 2017-02-03 04:00:18 --> URI Class Initialized
INFO - 2017-02-03 04:00:18 --> Router Class Initialized
INFO - 2017-02-03 04:00:18 --> Output Class Initialized
INFO - 2017-02-03 04:00:18 --> Security Class Initialized
DEBUG - 2017-02-03 04:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:00:18 --> Input Class Initialized
INFO - 2017-02-03 04:00:18 --> Language Class Initialized
INFO - 2017-02-03 04:00:18 --> Loader Class Initialized
INFO - 2017-02-03 04:00:18 --> Database Driver Class Initialized
INFO - 2017-02-03 04:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:00:18 --> Controller Class Initialized
INFO - 2017-02-03 04:00:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:00:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:00:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:00:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:00:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:00:18 --> Final output sent to browser
DEBUG - 2017-02-03 04:00:18 --> Total execution time: 0.2531
INFO - 2017-02-03 04:00:29 --> Config Class Initialized
INFO - 2017-02-03 04:00:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:00:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:00:29 --> Utf8 Class Initialized
INFO - 2017-02-03 04:00:29 --> URI Class Initialized
INFO - 2017-02-03 04:00:29 --> Router Class Initialized
INFO - 2017-02-03 04:00:29 --> Output Class Initialized
INFO - 2017-02-03 04:00:29 --> Security Class Initialized
DEBUG - 2017-02-03 04:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:00:29 --> Input Class Initialized
INFO - 2017-02-03 04:00:29 --> Language Class Initialized
INFO - 2017-02-03 04:00:29 --> Loader Class Initialized
INFO - 2017-02-03 04:00:29 --> Database Driver Class Initialized
INFO - 2017-02-03 04:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:00:29 --> Controller Class Initialized
INFO - 2017-02-03 04:00:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:00:30 --> Config Class Initialized
INFO - 2017-02-03 04:00:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:00:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:00:30 --> Utf8 Class Initialized
INFO - 2017-02-03 04:00:30 --> URI Class Initialized
INFO - 2017-02-03 04:00:30 --> Router Class Initialized
INFO - 2017-02-03 04:00:30 --> Output Class Initialized
INFO - 2017-02-03 04:00:30 --> Security Class Initialized
DEBUG - 2017-02-03 04:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:00:30 --> Input Class Initialized
INFO - 2017-02-03 04:00:30 --> Language Class Initialized
INFO - 2017-02-03 04:00:30 --> Loader Class Initialized
INFO - 2017-02-03 04:00:30 --> Database Driver Class Initialized
INFO - 2017-02-03 04:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:00:30 --> Controller Class Initialized
INFO - 2017-02-03 04:00:30 --> Helper loaded: date_helper
DEBUG - 2017-02-03 04:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:00:30 --> Helper loaded: url_helper
INFO - 2017-02-03 04:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 04:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 04:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 04:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:00:30 --> Final output sent to browser
DEBUG - 2017-02-03 04:00:30 --> Total execution time: 0.0139
INFO - 2017-02-03 04:00:32 --> Config Class Initialized
INFO - 2017-02-03 04:00:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:00:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:00:32 --> Utf8 Class Initialized
INFO - 2017-02-03 04:00:32 --> URI Class Initialized
DEBUG - 2017-02-03 04:00:32 --> No URI present. Default controller set.
INFO - 2017-02-03 04:00:32 --> Router Class Initialized
INFO - 2017-02-03 04:00:32 --> Output Class Initialized
INFO - 2017-02-03 04:00:32 --> Security Class Initialized
DEBUG - 2017-02-03 04:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:00:32 --> Input Class Initialized
INFO - 2017-02-03 04:00:32 --> Language Class Initialized
INFO - 2017-02-03 04:00:32 --> Loader Class Initialized
INFO - 2017-02-03 04:00:32 --> Database Driver Class Initialized
INFO - 2017-02-03 04:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:00:32 --> Controller Class Initialized
INFO - 2017-02-03 04:00:32 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:00:32 --> Final output sent to browser
DEBUG - 2017-02-03 04:00:32 --> Total execution time: 0.0139
INFO - 2017-02-03 04:00:32 --> Config Class Initialized
INFO - 2017-02-03 04:00:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:00:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:00:32 --> Utf8 Class Initialized
INFO - 2017-02-03 04:00:32 --> URI Class Initialized
INFO - 2017-02-03 04:00:32 --> Router Class Initialized
INFO - 2017-02-03 04:00:32 --> Output Class Initialized
INFO - 2017-02-03 04:00:32 --> Security Class Initialized
DEBUG - 2017-02-03 04:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:00:32 --> Input Class Initialized
INFO - 2017-02-03 04:00:32 --> Language Class Initialized
INFO - 2017-02-03 04:00:32 --> Loader Class Initialized
INFO - 2017-02-03 04:00:32 --> Database Driver Class Initialized
INFO - 2017-02-03 04:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:00:32 --> Controller Class Initialized
INFO - 2017-02-03 04:00:32 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:00:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:00:32 --> Final output sent to browser
DEBUG - 2017-02-03 04:00:32 --> Total execution time: 0.0324
INFO - 2017-02-03 04:00:34 --> Config Class Initialized
INFO - 2017-02-03 04:00:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:00:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:00:34 --> Utf8 Class Initialized
INFO - 2017-02-03 04:00:34 --> URI Class Initialized
INFO - 2017-02-03 04:00:34 --> Router Class Initialized
INFO - 2017-02-03 04:00:34 --> Output Class Initialized
INFO - 2017-02-03 04:00:34 --> Security Class Initialized
DEBUG - 2017-02-03 04:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:00:34 --> Input Class Initialized
INFO - 2017-02-03 04:00:34 --> Language Class Initialized
INFO - 2017-02-03 04:00:34 --> Loader Class Initialized
INFO - 2017-02-03 04:00:34 --> Database Driver Class Initialized
INFO - 2017-02-03 04:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:00:34 --> Controller Class Initialized
INFO - 2017-02-03 04:00:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:00:34 --> Final output sent to browser
DEBUG - 2017-02-03 04:00:34 --> Total execution time: 0.0145
INFO - 2017-02-03 04:17:36 --> Config Class Initialized
INFO - 2017-02-03 04:17:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:17:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:17:36 --> Utf8 Class Initialized
INFO - 2017-02-03 04:17:36 --> URI Class Initialized
DEBUG - 2017-02-03 04:17:36 --> No URI present. Default controller set.
INFO - 2017-02-03 04:17:36 --> Router Class Initialized
INFO - 2017-02-03 04:17:36 --> Output Class Initialized
INFO - 2017-02-03 04:17:36 --> Security Class Initialized
DEBUG - 2017-02-03 04:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:17:36 --> Input Class Initialized
INFO - 2017-02-03 04:17:36 --> Language Class Initialized
INFO - 2017-02-03 04:17:36 --> Loader Class Initialized
INFO - 2017-02-03 04:17:36 --> Database Driver Class Initialized
INFO - 2017-02-03 04:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:17:37 --> Controller Class Initialized
INFO - 2017-02-03 04:17:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:17:37 --> Final output sent to browser
DEBUG - 2017-02-03 04:17:37 --> Total execution time: 1.7180
INFO - 2017-02-03 04:18:05 --> Config Class Initialized
INFO - 2017-02-03 04:18:05 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:18:05 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:18:05 --> Utf8 Class Initialized
INFO - 2017-02-03 04:18:05 --> URI Class Initialized
INFO - 2017-02-03 04:18:05 --> Router Class Initialized
INFO - 2017-02-03 04:18:05 --> Output Class Initialized
INFO - 2017-02-03 04:18:05 --> Security Class Initialized
DEBUG - 2017-02-03 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:18:05 --> Input Class Initialized
INFO - 2017-02-03 04:18:05 --> Language Class Initialized
INFO - 2017-02-03 04:18:05 --> Loader Class Initialized
INFO - 2017-02-03 04:18:05 --> Database Driver Class Initialized
INFO - 2017-02-03 04:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:18:06 --> Controller Class Initialized
INFO - 2017-02-03 04:18:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:18:06 --> Final output sent to browser
DEBUG - 2017-02-03 04:18:06 --> Total execution time: 1.4691
INFO - 2017-02-03 04:18:21 --> Config Class Initialized
INFO - 2017-02-03 04:18:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:18:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:18:21 --> Utf8 Class Initialized
INFO - 2017-02-03 04:18:21 --> URI Class Initialized
INFO - 2017-02-03 04:18:21 --> Router Class Initialized
INFO - 2017-02-03 04:18:21 --> Output Class Initialized
INFO - 2017-02-03 04:18:21 --> Security Class Initialized
DEBUG - 2017-02-03 04:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:18:21 --> Input Class Initialized
INFO - 2017-02-03 04:18:21 --> Language Class Initialized
INFO - 2017-02-03 04:18:21 --> Loader Class Initialized
INFO - 2017-02-03 04:18:21 --> Database Driver Class Initialized
INFO - 2017-02-03 04:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:18:22 --> Controller Class Initialized
INFO - 2017-02-03 04:18:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:18:22 --> Final output sent to browser
DEBUG - 2017-02-03 04:18:22 --> Total execution time: 1.4918
INFO - 2017-02-03 04:18:23 --> Config Class Initialized
INFO - 2017-02-03 04:18:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:18:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:18:23 --> Utf8 Class Initialized
INFO - 2017-02-03 04:18:23 --> URI Class Initialized
INFO - 2017-02-03 04:18:23 --> Router Class Initialized
INFO - 2017-02-03 04:18:23 --> Output Class Initialized
INFO - 2017-02-03 04:18:23 --> Security Class Initialized
DEBUG - 2017-02-03 04:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:18:23 --> Input Class Initialized
INFO - 2017-02-03 04:18:23 --> Language Class Initialized
INFO - 2017-02-03 04:18:23 --> Loader Class Initialized
INFO - 2017-02-03 04:18:24 --> Database Driver Class Initialized
INFO - 2017-02-03 04:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:18:24 --> Controller Class Initialized
INFO - 2017-02-03 04:18:24 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:18:25 --> Final output sent to browser
DEBUG - 2017-02-03 04:18:25 --> Total execution time: 1.4161
INFO - 2017-02-03 04:18:29 --> Config Class Initialized
INFO - 2017-02-03 04:18:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:18:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:18:29 --> Utf8 Class Initialized
INFO - 2017-02-03 04:18:29 --> URI Class Initialized
INFO - 2017-02-03 04:18:29 --> Router Class Initialized
INFO - 2017-02-03 04:18:29 --> Output Class Initialized
INFO - 2017-02-03 04:18:29 --> Security Class Initialized
DEBUG - 2017-02-03 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:18:29 --> Input Class Initialized
INFO - 2017-02-03 04:18:29 --> Language Class Initialized
INFO - 2017-02-03 04:18:30 --> Loader Class Initialized
INFO - 2017-02-03 04:18:30 --> Database Driver Class Initialized
INFO - 2017-02-03 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:18:30 --> Controller Class Initialized
INFO - 2017-02-03 04:18:30 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:18:31 --> Final output sent to browser
DEBUG - 2017-02-03 04:18:31 --> Total execution time: 1.5494
INFO - 2017-02-03 04:19:02 --> Config Class Initialized
INFO - 2017-02-03 04:19:02 --> Hooks Class Initialized
INFO - 2017-02-03 04:19:02 --> Config Class Initialized
INFO - 2017-02-03 04:19:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:19:02 --> UTF-8 Support Enabled
DEBUG - 2017-02-03 04:19:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:19:02 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:02 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:02 --> URI Class Initialized
INFO - 2017-02-03 04:19:03 --> URI Class Initialized
INFO - 2017-02-03 04:19:03 --> Router Class Initialized
INFO - 2017-02-03 04:19:03 --> Router Class Initialized
INFO - 2017-02-03 04:19:03 --> Output Class Initialized
INFO - 2017-02-03 04:19:03 --> Output Class Initialized
INFO - 2017-02-03 04:19:03 --> Security Class Initialized
DEBUG - 2017-02-03 04:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:03 --> Security Class Initialized
INFO - 2017-02-03 04:19:03 --> Input Class Initialized
INFO - 2017-02-03 04:19:03 --> Language Class Initialized
DEBUG - 2017-02-03 04:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:03 --> Input Class Initialized
INFO - 2017-02-03 04:19:03 --> Language Class Initialized
INFO - 2017-02-03 04:19:03 --> Loader Class Initialized
INFO - 2017-02-03 04:19:03 --> Loader Class Initialized
INFO - 2017-02-03 04:19:03 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:03 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:04 --> Controller Class Initialized
INFO - 2017-02-03 04:19:04 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:19:04 --> Final output sent to browser
DEBUG - 2017-02-03 04:19:04 --> Total execution time: 1.5754
INFO - 2017-02-03 04:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:04 --> Controller Class Initialized
INFO - 2017-02-03 04:19:04 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:19:04 --> Final output sent to browser
DEBUG - 2017-02-03 04:19:04 --> Total execution time: 1.5690
INFO - 2017-02-03 04:19:10 --> Config Class Initialized
INFO - 2017-02-03 04:19:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:19:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:19:10 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:10 --> URI Class Initialized
INFO - 2017-02-03 04:19:10 --> Router Class Initialized
INFO - 2017-02-03 04:19:10 --> Output Class Initialized
INFO - 2017-02-03 04:19:10 --> Security Class Initialized
DEBUG - 2017-02-03 04:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:10 --> Input Class Initialized
INFO - 2017-02-03 04:19:10 --> Language Class Initialized
INFO - 2017-02-03 04:19:10 --> Loader Class Initialized
INFO - 2017-02-03 04:19:11 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:11 --> Controller Class Initialized
INFO - 2017-02-03 04:19:11 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:19:11 --> Final output sent to browser
DEBUG - 2017-02-03 04:19:11 --> Total execution time: 1.4701
INFO - 2017-02-03 04:19:27 --> Config Class Initialized
INFO - 2017-02-03 04:19:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:19:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:19:27 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:27 --> URI Class Initialized
INFO - 2017-02-03 04:19:27 --> Router Class Initialized
INFO - 2017-02-03 04:19:27 --> Output Class Initialized
INFO - 2017-02-03 04:19:27 --> Security Class Initialized
DEBUG - 2017-02-03 04:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:27 --> Input Class Initialized
INFO - 2017-02-03 04:19:27 --> Language Class Initialized
INFO - 2017-02-03 04:19:27 --> Loader Class Initialized
INFO - 2017-02-03 04:19:27 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:27 --> Controller Class Initialized
INFO - 2017-02-03 04:19:27 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:28 --> Config Class Initialized
INFO - 2017-02-03 04:19:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:19:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:19:28 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:28 --> URI Class Initialized
INFO - 2017-02-03 04:19:28 --> Router Class Initialized
INFO - 2017-02-03 04:19:28 --> Output Class Initialized
INFO - 2017-02-03 04:19:28 --> Security Class Initialized
DEBUG - 2017-02-03 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:28 --> Input Class Initialized
INFO - 2017-02-03 04:19:28 --> Language Class Initialized
INFO - 2017-02-03 04:19:28 --> Loader Class Initialized
INFO - 2017-02-03 04:19:29 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:29 --> Controller Class Initialized
INFO - 2017-02-03 04:19:29 --> Helper loaded: date_helper
DEBUG - 2017-02-03 04:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:29 --> Helper loaded: url_helper
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:19:29 --> Final output sent to browser
DEBUG - 2017-02-03 04:19:29 --> Total execution time: 0.1069
INFO - 2017-02-03 04:19:29 --> Config Class Initialized
INFO - 2017-02-03 04:19:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:19:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:19:29 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:29 --> URI Class Initialized
INFO - 2017-02-03 04:19:29 --> Router Class Initialized
INFO - 2017-02-03 04:19:29 --> Output Class Initialized
INFO - 2017-02-03 04:19:29 --> Security Class Initialized
DEBUG - 2017-02-03 04:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:29 --> Input Class Initialized
INFO - 2017-02-03 04:19:29 --> Language Class Initialized
INFO - 2017-02-03 04:19:29 --> Loader Class Initialized
INFO - 2017-02-03 04:19:29 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:29 --> Controller Class Initialized
INFO - 2017-02-03 04:19:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:19:29 --> Final output sent to browser
DEBUG - 2017-02-03 04:19:29 --> Total execution time: 0.0141
INFO - 2017-02-03 04:19:40 --> Config Class Initialized
INFO - 2017-02-03 04:19:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:19:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:19:40 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:40 --> URI Class Initialized
DEBUG - 2017-02-03 04:19:40 --> No URI present. Default controller set.
INFO - 2017-02-03 04:19:40 --> Router Class Initialized
INFO - 2017-02-03 04:19:40 --> Output Class Initialized
INFO - 2017-02-03 04:19:40 --> Security Class Initialized
DEBUG - 2017-02-03 04:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:40 --> Input Class Initialized
INFO - 2017-02-03 04:19:40 --> Language Class Initialized
INFO - 2017-02-03 04:19:40 --> Loader Class Initialized
INFO - 2017-02-03 04:19:40 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:40 --> Controller Class Initialized
INFO - 2017-02-03 04:19:40 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:19:40 --> Final output sent to browser
DEBUG - 2017-02-03 04:19:40 --> Total execution time: 0.0133
INFO - 2017-02-03 04:19:41 --> Config Class Initialized
INFO - 2017-02-03 04:19:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:19:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:19:41 --> Utf8 Class Initialized
INFO - 2017-02-03 04:19:41 --> URI Class Initialized
INFO - 2017-02-03 04:19:41 --> Router Class Initialized
INFO - 2017-02-03 04:19:41 --> Output Class Initialized
INFO - 2017-02-03 04:19:41 --> Security Class Initialized
DEBUG - 2017-02-03 04:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:19:41 --> Input Class Initialized
INFO - 2017-02-03 04:19:41 --> Language Class Initialized
INFO - 2017-02-03 04:19:41 --> Loader Class Initialized
INFO - 2017-02-03 04:19:41 --> Database Driver Class Initialized
INFO - 2017-02-03 04:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:19:41 --> Controller Class Initialized
INFO - 2017-02-03 04:19:41 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:19:41 --> Final output sent to browser
DEBUG - 2017-02-03 04:19:41 --> Total execution time: 0.0143
INFO - 2017-02-03 04:20:18 --> Config Class Initialized
INFO - 2017-02-03 04:20:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:20:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:20:18 --> Utf8 Class Initialized
INFO - 2017-02-03 04:20:18 --> URI Class Initialized
INFO - 2017-02-03 04:20:18 --> Router Class Initialized
INFO - 2017-02-03 04:20:18 --> Output Class Initialized
INFO - 2017-02-03 04:20:18 --> Security Class Initialized
DEBUG - 2017-02-03 04:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:20:18 --> Input Class Initialized
INFO - 2017-02-03 04:20:18 --> Language Class Initialized
INFO - 2017-02-03 04:20:18 --> Loader Class Initialized
INFO - 2017-02-03 04:20:18 --> Database Driver Class Initialized
INFO - 2017-02-03 04:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:20:19 --> Controller Class Initialized
INFO - 2017-02-03 04:20:19 --> Helper loaded: date_helper
DEBUG - 2017-02-03 04:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:20:19 --> Helper loaded: url_helper
INFO - 2017-02-03 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:20:19 --> Final output sent to browser
DEBUG - 2017-02-03 04:20:19 --> Total execution time: 1.3261
INFO - 2017-02-03 04:20:20 --> Config Class Initialized
INFO - 2017-02-03 04:20:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:20:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:20:20 --> Utf8 Class Initialized
INFO - 2017-02-03 04:20:20 --> URI Class Initialized
INFO - 2017-02-03 04:20:20 --> Router Class Initialized
INFO - 2017-02-03 04:20:20 --> Output Class Initialized
INFO - 2017-02-03 04:20:20 --> Security Class Initialized
DEBUG - 2017-02-03 04:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:20:20 --> Input Class Initialized
INFO - 2017-02-03 04:20:20 --> Language Class Initialized
INFO - 2017-02-03 04:20:20 --> Loader Class Initialized
INFO - 2017-02-03 04:20:21 --> Database Driver Class Initialized
INFO - 2017-02-03 04:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:20:21 --> Controller Class Initialized
INFO - 2017-02-03 04:20:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:20:21 --> Final output sent to browser
DEBUG - 2017-02-03 04:20:21 --> Total execution time: 1.1580
INFO - 2017-02-03 04:21:05 --> Config Class Initialized
INFO - 2017-02-03 04:21:05 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:21:05 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:21:05 --> Utf8 Class Initialized
INFO - 2017-02-03 04:21:05 --> URI Class Initialized
DEBUG - 2017-02-03 04:21:05 --> No URI present. Default controller set.
INFO - 2017-02-03 04:21:05 --> Router Class Initialized
INFO - 2017-02-03 04:21:05 --> Output Class Initialized
INFO - 2017-02-03 04:21:05 --> Security Class Initialized
DEBUG - 2017-02-03 04:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:21:05 --> Input Class Initialized
INFO - 2017-02-03 04:21:06 --> Language Class Initialized
INFO - 2017-02-03 04:21:06 --> Loader Class Initialized
INFO - 2017-02-03 04:21:06 --> Database Driver Class Initialized
INFO - 2017-02-03 04:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:21:06 --> Controller Class Initialized
INFO - 2017-02-03 04:21:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:21:06 --> Final output sent to browser
DEBUG - 2017-02-03 04:21:06 --> Total execution time: 1.2358
INFO - 2017-02-03 04:21:08 --> Config Class Initialized
INFO - 2017-02-03 04:21:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:21:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:21:08 --> Utf8 Class Initialized
INFO - 2017-02-03 04:21:08 --> URI Class Initialized
INFO - 2017-02-03 04:21:08 --> Router Class Initialized
INFO - 2017-02-03 04:21:08 --> Output Class Initialized
INFO - 2017-02-03 04:21:08 --> Security Class Initialized
DEBUG - 2017-02-03 04:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:21:08 --> Input Class Initialized
INFO - 2017-02-03 04:21:08 --> Language Class Initialized
INFO - 2017-02-03 04:21:08 --> Loader Class Initialized
INFO - 2017-02-03 04:21:08 --> Database Driver Class Initialized
INFO - 2017-02-03 04:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:21:08 --> Controller Class Initialized
INFO - 2017-02-03 04:21:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:21:08 --> Final output sent to browser
DEBUG - 2017-02-03 04:21:08 --> Total execution time: 0.0423
INFO - 2017-02-03 04:21:16 --> Config Class Initialized
INFO - 2017-02-03 04:21:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:21:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:21:16 --> Utf8 Class Initialized
INFO - 2017-02-03 04:21:16 --> URI Class Initialized
INFO - 2017-02-03 04:21:16 --> Router Class Initialized
INFO - 2017-02-03 04:21:16 --> Output Class Initialized
INFO - 2017-02-03 04:21:16 --> Security Class Initialized
DEBUG - 2017-02-03 04:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:21:16 --> Input Class Initialized
INFO - 2017-02-03 04:21:16 --> Language Class Initialized
INFO - 2017-02-03 04:21:16 --> Loader Class Initialized
INFO - 2017-02-03 04:21:17 --> Database Driver Class Initialized
INFO - 2017-02-03 04:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:21:17 --> Controller Class Initialized
INFO - 2017-02-03 04:21:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:21:19 --> Config Class Initialized
INFO - 2017-02-03 04:21:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:21:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:21:19 --> Utf8 Class Initialized
INFO - 2017-02-03 04:21:19 --> URI Class Initialized
INFO - 2017-02-03 04:21:19 --> Router Class Initialized
INFO - 2017-02-03 04:21:19 --> Output Class Initialized
INFO - 2017-02-03 04:21:19 --> Security Class Initialized
DEBUG - 2017-02-03 04:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:21:19 --> Input Class Initialized
INFO - 2017-02-03 04:21:19 --> Language Class Initialized
INFO - 2017-02-03 04:21:19 --> Loader Class Initialized
INFO - 2017-02-03 04:21:19 --> Database Driver Class Initialized
INFO - 2017-02-03 04:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:21:19 --> Controller Class Initialized
INFO - 2017-02-03 04:21:19 --> Helper loaded: date_helper
DEBUG - 2017-02-03 04:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:21:19 --> Helper loaded: url_helper
INFO - 2017-02-03 04:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 04:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 04:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 04:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:21:19 --> Final output sent to browser
DEBUG - 2017-02-03 04:21:19 --> Total execution time: 0.1191
INFO - 2017-02-03 04:21:20 --> Config Class Initialized
INFO - 2017-02-03 04:21:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:21:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:21:20 --> Utf8 Class Initialized
INFO - 2017-02-03 04:21:20 --> URI Class Initialized
INFO - 2017-02-03 04:21:20 --> Router Class Initialized
INFO - 2017-02-03 04:21:20 --> Output Class Initialized
INFO - 2017-02-03 04:21:20 --> Security Class Initialized
DEBUG - 2017-02-03 04:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:21:20 --> Input Class Initialized
INFO - 2017-02-03 04:21:20 --> Language Class Initialized
INFO - 2017-02-03 04:21:20 --> Loader Class Initialized
INFO - 2017-02-03 04:21:20 --> Database Driver Class Initialized
INFO - 2017-02-03 04:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:21:20 --> Controller Class Initialized
INFO - 2017-02-03 04:21:20 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:21:20 --> Final output sent to browser
DEBUG - 2017-02-03 04:21:20 --> Total execution time: 0.0470
INFO - 2017-02-03 04:34:46 --> Config Class Initialized
INFO - 2017-02-03 04:34:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:34:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:34:46 --> Utf8 Class Initialized
INFO - 2017-02-03 04:34:46 --> URI Class Initialized
INFO - 2017-02-03 04:34:46 --> Router Class Initialized
INFO - 2017-02-03 04:34:46 --> Output Class Initialized
INFO - 2017-02-03 04:34:46 --> Security Class Initialized
DEBUG - 2017-02-03 04:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:34:46 --> Input Class Initialized
INFO - 2017-02-03 04:34:46 --> Language Class Initialized
INFO - 2017-02-03 04:34:46 --> Loader Class Initialized
INFO - 2017-02-03 04:34:47 --> Database Driver Class Initialized
INFO - 2017-02-03 04:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:34:47 --> Controller Class Initialized
INFO - 2017-02-03 04:34:47 --> Helper loaded: date_helper
DEBUG - 2017-02-03 04:34:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:34:47 --> Helper loaded: url_helper
INFO - 2017-02-03 04:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 04:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 04:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 04:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:34:47 --> Final output sent to browser
DEBUG - 2017-02-03 04:34:47 --> Total execution time: 1.5928
INFO - 2017-02-03 04:34:51 --> Config Class Initialized
INFO - 2017-02-03 04:34:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:34:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:34:51 --> Utf8 Class Initialized
INFO - 2017-02-03 04:34:51 --> URI Class Initialized
INFO - 2017-02-03 04:34:51 --> Router Class Initialized
INFO - 2017-02-03 04:34:51 --> Output Class Initialized
INFO - 2017-02-03 04:34:51 --> Security Class Initialized
DEBUG - 2017-02-03 04:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:34:51 --> Input Class Initialized
INFO - 2017-02-03 04:34:51 --> Language Class Initialized
INFO - 2017-02-03 04:34:51 --> Loader Class Initialized
INFO - 2017-02-03 04:34:51 --> Database Driver Class Initialized
INFO - 2017-02-03 04:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:34:51 --> Controller Class Initialized
INFO - 2017-02-03 04:34:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:34:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:34:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:34:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:34:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:34:51 --> Final output sent to browser
DEBUG - 2017-02-03 04:34:51 --> Total execution time: 0.2484
INFO - 2017-02-03 04:38:22 --> Config Class Initialized
INFO - 2017-02-03 04:38:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:38:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:38:22 --> Utf8 Class Initialized
INFO - 2017-02-03 04:38:22 --> URI Class Initialized
DEBUG - 2017-02-03 04:38:22 --> No URI present. Default controller set.
INFO - 2017-02-03 04:38:22 --> Router Class Initialized
INFO - 2017-02-03 04:38:22 --> Output Class Initialized
INFO - 2017-02-03 04:38:22 --> Security Class Initialized
DEBUG - 2017-02-03 04:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:38:22 --> Input Class Initialized
INFO - 2017-02-03 04:38:22 --> Language Class Initialized
INFO - 2017-02-03 04:38:22 --> Loader Class Initialized
INFO - 2017-02-03 04:38:22 --> Database Driver Class Initialized
INFO - 2017-02-03 04:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:38:23 --> Controller Class Initialized
INFO - 2017-02-03 04:38:23 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:38:23 --> Final output sent to browser
DEBUG - 2017-02-03 04:38:23 --> Total execution time: 1.4427
INFO - 2017-02-03 04:38:29 --> Config Class Initialized
INFO - 2017-02-03 04:38:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 04:38:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 04:38:30 --> Utf8 Class Initialized
INFO - 2017-02-03 04:38:30 --> URI Class Initialized
INFO - 2017-02-03 04:38:30 --> Router Class Initialized
INFO - 2017-02-03 04:38:30 --> Output Class Initialized
INFO - 2017-02-03 04:38:30 --> Security Class Initialized
DEBUG - 2017-02-03 04:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 04:38:30 --> Input Class Initialized
INFO - 2017-02-03 04:38:30 --> Language Class Initialized
INFO - 2017-02-03 04:38:30 --> Loader Class Initialized
INFO - 2017-02-03 04:38:30 --> Database Driver Class Initialized
INFO - 2017-02-03 04:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 04:38:30 --> Controller Class Initialized
INFO - 2017-02-03 04:38:30 --> Helper loaded: url_helper
DEBUG - 2017-02-03 04:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 04:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 04:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 04:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 04:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 04:38:31 --> Final output sent to browser
DEBUG - 2017-02-03 04:38:31 --> Total execution time: 1.2549
INFO - 2017-02-03 05:25:32 --> Config Class Initialized
INFO - 2017-02-03 05:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 05:25:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 05:25:33 --> Utf8 Class Initialized
INFO - 2017-02-03 05:25:33 --> URI Class Initialized
DEBUG - 2017-02-03 05:25:33 --> No URI present. Default controller set.
INFO - 2017-02-03 05:25:33 --> Router Class Initialized
INFO - 2017-02-03 05:25:33 --> Output Class Initialized
INFO - 2017-02-03 05:25:33 --> Security Class Initialized
DEBUG - 2017-02-03 05:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 05:25:33 --> Input Class Initialized
INFO - 2017-02-03 05:25:33 --> Language Class Initialized
INFO - 2017-02-03 05:25:33 --> Loader Class Initialized
INFO - 2017-02-03 05:25:33 --> Database Driver Class Initialized
INFO - 2017-02-03 05:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 05:25:34 --> Controller Class Initialized
INFO - 2017-02-03 05:25:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 05:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 05:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 05:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 05:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 05:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 05:25:35 --> Final output sent to browser
DEBUG - 2017-02-03 05:25:35 --> Total execution time: 4.7640
INFO - 2017-02-03 05:25:49 --> Config Class Initialized
INFO - 2017-02-03 05:25:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 05:25:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 05:25:49 --> Utf8 Class Initialized
INFO - 2017-02-03 05:25:49 --> URI Class Initialized
INFO - 2017-02-03 05:25:49 --> Router Class Initialized
INFO - 2017-02-03 05:25:50 --> Output Class Initialized
INFO - 2017-02-03 05:25:50 --> Security Class Initialized
DEBUG - 2017-02-03 05:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 05:25:50 --> Input Class Initialized
INFO - 2017-02-03 05:25:50 --> Language Class Initialized
INFO - 2017-02-03 05:25:50 --> Loader Class Initialized
INFO - 2017-02-03 05:25:50 --> Database Driver Class Initialized
INFO - 2017-02-03 05:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 05:25:50 --> Controller Class Initialized
INFO - 2017-02-03 05:25:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 05:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 05:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 05:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 05:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 05:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 05:25:51 --> Final output sent to browser
DEBUG - 2017-02-03 05:25:51 --> Total execution time: 1.5155
INFO - 2017-02-03 05:26:55 --> Config Class Initialized
INFO - 2017-02-03 05:26:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 05:26:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 05:26:55 --> Utf8 Class Initialized
INFO - 2017-02-03 05:26:55 --> URI Class Initialized
INFO - 2017-02-03 05:26:55 --> Router Class Initialized
INFO - 2017-02-03 05:26:55 --> Output Class Initialized
INFO - 2017-02-03 05:26:55 --> Security Class Initialized
DEBUG - 2017-02-03 05:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 05:26:55 --> Input Class Initialized
INFO - 2017-02-03 05:26:55 --> Language Class Initialized
INFO - 2017-02-03 05:26:55 --> Loader Class Initialized
INFO - 2017-02-03 05:26:56 --> Database Driver Class Initialized
INFO - 2017-02-03 05:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 05:26:56 --> Controller Class Initialized
INFO - 2017-02-03 05:26:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 05:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 05:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 05:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 05:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 05:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 05:26:56 --> Final output sent to browser
DEBUG - 2017-02-03 05:26:56 --> Total execution time: 1.2552
INFO - 2017-02-03 05:26:59 --> Config Class Initialized
INFO - 2017-02-03 05:26:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 05:26:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 05:26:59 --> Utf8 Class Initialized
INFO - 2017-02-03 05:26:59 --> URI Class Initialized
INFO - 2017-02-03 05:26:59 --> Router Class Initialized
INFO - 2017-02-03 05:27:00 --> Output Class Initialized
INFO - 2017-02-03 05:27:00 --> Security Class Initialized
DEBUG - 2017-02-03 05:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 05:27:00 --> Input Class Initialized
INFO - 2017-02-03 05:27:00 --> Language Class Initialized
INFO - 2017-02-03 05:27:00 --> Loader Class Initialized
INFO - 2017-02-03 05:27:00 --> Database Driver Class Initialized
INFO - 2017-02-03 05:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 05:27:00 --> Controller Class Initialized
INFO - 2017-02-03 05:27:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 05:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 05:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 05:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 05:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 05:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 05:27:00 --> Final output sent to browser
DEBUG - 2017-02-03 05:27:00 --> Total execution time: 1.2189
INFO - 2017-02-03 05:27:37 --> Config Class Initialized
INFO - 2017-02-03 05:27:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 05:27:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 05:27:37 --> Utf8 Class Initialized
INFO - 2017-02-03 05:27:37 --> URI Class Initialized
INFO - 2017-02-03 05:27:37 --> Router Class Initialized
INFO - 2017-02-03 05:27:37 --> Output Class Initialized
INFO - 2017-02-03 05:27:37 --> Security Class Initialized
DEBUG - 2017-02-03 05:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 05:27:37 --> Input Class Initialized
INFO - 2017-02-03 05:27:37 --> Language Class Initialized
INFO - 2017-02-03 05:27:37 --> Loader Class Initialized
INFO - 2017-02-03 05:27:37 --> Database Driver Class Initialized
INFO - 2017-02-03 05:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 05:27:37 --> Controller Class Initialized
INFO - 2017-02-03 05:27:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 05:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 05:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 05:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 05:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 05:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 05:27:37 --> Final output sent to browser
DEBUG - 2017-02-03 05:27:37 --> Total execution time: 0.0339
INFO - 2017-02-03 05:27:39 --> Config Class Initialized
INFO - 2017-02-03 05:27:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 05:27:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 05:27:39 --> Utf8 Class Initialized
INFO - 2017-02-03 05:27:39 --> URI Class Initialized
INFO - 2017-02-03 05:27:39 --> Router Class Initialized
INFO - 2017-02-03 05:27:39 --> Output Class Initialized
INFO - 2017-02-03 05:27:39 --> Security Class Initialized
DEBUG - 2017-02-03 05:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 05:27:39 --> Input Class Initialized
INFO - 2017-02-03 05:27:39 --> Language Class Initialized
INFO - 2017-02-03 05:27:39 --> Loader Class Initialized
INFO - 2017-02-03 05:27:39 --> Database Driver Class Initialized
INFO - 2017-02-03 05:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 05:27:39 --> Controller Class Initialized
INFO - 2017-02-03 05:27:39 --> Helper loaded: url_helper
DEBUG - 2017-02-03 05:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 05:27:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 05:27:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 05:27:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 05:27:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 05:27:39 --> Final output sent to browser
DEBUG - 2017-02-03 05:27:39 --> Total execution time: 0.0141
INFO - 2017-02-03 06:01:07 --> Config Class Initialized
INFO - 2017-02-03 06:01:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 06:01:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 06:01:07 --> Utf8 Class Initialized
INFO - 2017-02-03 06:01:07 --> URI Class Initialized
DEBUG - 2017-02-03 06:01:07 --> No URI present. Default controller set.
INFO - 2017-02-03 06:01:07 --> Router Class Initialized
INFO - 2017-02-03 06:01:08 --> Output Class Initialized
INFO - 2017-02-03 06:01:08 --> Security Class Initialized
DEBUG - 2017-02-03 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 06:01:08 --> Input Class Initialized
INFO - 2017-02-03 06:01:08 --> Language Class Initialized
INFO - 2017-02-03 06:01:08 --> Loader Class Initialized
INFO - 2017-02-03 06:01:08 --> Database Driver Class Initialized
INFO - 2017-02-03 06:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 06:01:09 --> Controller Class Initialized
INFO - 2017-02-03 06:01:09 --> Helper loaded: url_helper
DEBUG - 2017-02-03 06:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 06:01:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 06:01:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 06:01:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 06:01:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 06:01:09 --> Final output sent to browser
DEBUG - 2017-02-03 06:01:09 --> Total execution time: 1.7211
INFO - 2017-02-03 06:01:29 --> Config Class Initialized
INFO - 2017-02-03 06:01:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 06:01:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 06:01:29 --> Utf8 Class Initialized
INFO - 2017-02-03 06:01:29 --> URI Class Initialized
INFO - 2017-02-03 06:01:29 --> Router Class Initialized
INFO - 2017-02-03 06:01:29 --> Output Class Initialized
INFO - 2017-02-03 06:01:29 --> Security Class Initialized
DEBUG - 2017-02-03 06:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 06:01:30 --> Input Class Initialized
INFO - 2017-02-03 06:01:30 --> Language Class Initialized
INFO - 2017-02-03 06:01:30 --> Loader Class Initialized
INFO - 2017-02-03 06:01:30 --> Database Driver Class Initialized
INFO - 2017-02-03 06:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 06:01:30 --> Controller Class Initialized
INFO - 2017-02-03 06:01:30 --> Helper loaded: url_helper
DEBUG - 2017-02-03 06:01:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 06:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 06:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 06:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 06:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 06:01:31 --> Final output sent to browser
DEBUG - 2017-02-03 06:01:31 --> Total execution time: 1.2592
INFO - 2017-02-03 16:49:51 --> Config Class Initialized
INFO - 2017-02-03 16:49:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 16:49:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 16:49:51 --> Utf8 Class Initialized
INFO - 2017-02-03 16:49:51 --> URI Class Initialized
DEBUG - 2017-02-03 16:49:51 --> No URI present. Default controller set.
INFO - 2017-02-03 16:49:51 --> Router Class Initialized
INFO - 2017-02-03 16:49:51 --> Output Class Initialized
INFO - 2017-02-03 16:49:51 --> Security Class Initialized
DEBUG - 2017-02-03 16:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 16:49:51 --> Input Class Initialized
INFO - 2017-02-03 16:49:51 --> Language Class Initialized
INFO - 2017-02-03 16:49:51 --> Loader Class Initialized
INFO - 2017-02-03 16:49:52 --> Database Driver Class Initialized
INFO - 2017-02-03 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 16:49:52 --> Controller Class Initialized
INFO - 2017-02-03 16:49:52 --> Helper loaded: url_helper
DEBUG - 2017-02-03 16:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 16:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 16:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 16:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 16:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 16:49:53 --> Final output sent to browser
DEBUG - 2017-02-03 16:49:53 --> Total execution time: 1.8000
INFO - 2017-02-03 16:50:00 --> Config Class Initialized
INFO - 2017-02-03 16:50:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 16:50:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 16:50:00 --> Utf8 Class Initialized
INFO - 2017-02-03 16:50:00 --> URI Class Initialized
INFO - 2017-02-03 16:50:00 --> Router Class Initialized
INFO - 2017-02-03 16:50:00 --> Output Class Initialized
INFO - 2017-02-03 16:50:00 --> Security Class Initialized
DEBUG - 2017-02-03 16:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 16:50:00 --> Input Class Initialized
INFO - 2017-02-03 16:50:00 --> Language Class Initialized
INFO - 2017-02-03 16:50:00 --> Loader Class Initialized
INFO - 2017-02-03 16:50:00 --> Database Driver Class Initialized
INFO - 2017-02-03 16:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 16:50:00 --> Controller Class Initialized
INFO - 2017-02-03 16:50:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 16:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 16:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 16:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 16:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 16:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 16:50:00 --> Final output sent to browser
DEBUG - 2017-02-03 16:50:00 --> Total execution time: 0.0155
INFO - 2017-02-03 16:50:56 --> Config Class Initialized
INFO - 2017-02-03 16:50:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 16:50:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 16:50:56 --> Utf8 Class Initialized
INFO - 2017-02-03 16:50:56 --> URI Class Initialized
INFO - 2017-02-03 16:50:56 --> Router Class Initialized
INFO - 2017-02-03 16:50:56 --> Output Class Initialized
INFO - 2017-02-03 16:50:56 --> Security Class Initialized
DEBUG - 2017-02-03 16:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 16:50:56 --> Input Class Initialized
INFO - 2017-02-03 16:50:56 --> Language Class Initialized
INFO - 2017-02-03 16:50:56 --> Loader Class Initialized
INFO - 2017-02-03 16:50:56 --> Database Driver Class Initialized
INFO - 2017-02-03 16:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 16:50:56 --> Controller Class Initialized
INFO - 2017-02-03 16:50:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 16:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 16:50:58 --> Config Class Initialized
INFO - 2017-02-03 16:50:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 16:50:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 16:50:58 --> Utf8 Class Initialized
INFO - 2017-02-03 16:50:58 --> URI Class Initialized
INFO - 2017-02-03 16:50:58 --> Router Class Initialized
INFO - 2017-02-03 16:50:58 --> Output Class Initialized
INFO - 2017-02-03 16:50:58 --> Security Class Initialized
DEBUG - 2017-02-03 16:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 16:50:58 --> Input Class Initialized
INFO - 2017-02-03 16:50:58 --> Language Class Initialized
INFO - 2017-02-03 16:50:58 --> Loader Class Initialized
INFO - 2017-02-03 16:50:58 --> Database Driver Class Initialized
INFO - 2017-02-03 16:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 16:50:58 --> Controller Class Initialized
INFO - 2017-02-03 16:50:58 --> Helper loaded: date_helper
DEBUG - 2017-02-03 16:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 16:50:58 --> Helper loaded: url_helper
INFO - 2017-02-03 16:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 16:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 16:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 16:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 16:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 16:50:58 --> Final output sent to browser
DEBUG - 2017-02-03 16:50:58 --> Total execution time: 0.1095
INFO - 2017-02-03 16:50:59 --> Config Class Initialized
INFO - 2017-02-03 16:50:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 16:50:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 16:50:59 --> Utf8 Class Initialized
INFO - 2017-02-03 16:50:59 --> URI Class Initialized
INFO - 2017-02-03 16:50:59 --> Router Class Initialized
INFO - 2017-02-03 16:50:59 --> Output Class Initialized
INFO - 2017-02-03 16:50:59 --> Security Class Initialized
DEBUG - 2017-02-03 16:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 16:50:59 --> Input Class Initialized
INFO - 2017-02-03 16:50:59 --> Language Class Initialized
INFO - 2017-02-03 16:50:59 --> Loader Class Initialized
INFO - 2017-02-03 16:50:59 --> Database Driver Class Initialized
INFO - 2017-02-03 16:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 16:50:59 --> Controller Class Initialized
INFO - 2017-02-03 16:50:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 16:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 16:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 16:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 16:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 16:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 16:50:59 --> Final output sent to browser
DEBUG - 2017-02-03 16:50:59 --> Total execution time: 0.0139
INFO - 2017-02-03 16:51:10 --> Config Class Initialized
INFO - 2017-02-03 16:51:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 16:51:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 16:51:10 --> Utf8 Class Initialized
INFO - 2017-02-03 16:51:10 --> URI Class Initialized
DEBUG - 2017-02-03 16:51:10 --> No URI present. Default controller set.
INFO - 2017-02-03 16:51:10 --> Router Class Initialized
INFO - 2017-02-03 16:51:10 --> Output Class Initialized
INFO - 2017-02-03 16:51:10 --> Security Class Initialized
DEBUG - 2017-02-03 16:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 16:51:10 --> Input Class Initialized
INFO - 2017-02-03 16:51:10 --> Language Class Initialized
INFO - 2017-02-03 16:51:10 --> Loader Class Initialized
INFO - 2017-02-03 16:51:10 --> Database Driver Class Initialized
INFO - 2017-02-03 16:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 16:51:10 --> Controller Class Initialized
INFO - 2017-02-03 16:51:10 --> Helper loaded: url_helper
DEBUG - 2017-02-03 16:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 16:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 16:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 16:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 16:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 16:51:10 --> Final output sent to browser
DEBUG - 2017-02-03 16:51:10 --> Total execution time: 0.0142
INFO - 2017-02-03 16:51:13 --> Config Class Initialized
INFO - 2017-02-03 16:51:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 16:51:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 16:51:13 --> Utf8 Class Initialized
INFO - 2017-02-03 16:51:13 --> URI Class Initialized
INFO - 2017-02-03 16:51:13 --> Router Class Initialized
INFO - 2017-02-03 16:51:13 --> Output Class Initialized
INFO - 2017-02-03 16:51:13 --> Security Class Initialized
DEBUG - 2017-02-03 16:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 16:51:13 --> Input Class Initialized
INFO - 2017-02-03 16:51:13 --> Language Class Initialized
INFO - 2017-02-03 16:51:13 --> Loader Class Initialized
INFO - 2017-02-03 16:51:13 --> Database Driver Class Initialized
INFO - 2017-02-03 16:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 16:51:13 --> Controller Class Initialized
INFO - 2017-02-03 16:51:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 16:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 16:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 16:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 16:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 16:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 16:51:13 --> Final output sent to browser
DEBUG - 2017-02-03 16:51:13 --> Total execution time: 0.0139
INFO - 2017-02-03 17:14:00 --> Config Class Initialized
INFO - 2017-02-03 17:14:00 --> Hooks Class Initialized
INFO - 2017-02-03 17:14:01 --> Config Class Initialized
INFO - 2017-02-03 17:14:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:14:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:14:01 --> Utf8 Class Initialized
DEBUG - 2017-02-03 17:14:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:14:01 --> Utf8 Class Initialized
INFO - 2017-02-03 17:14:01 --> URI Class Initialized
INFO - 2017-02-03 17:14:01 --> URI Class Initialized
INFO - 2017-02-03 17:14:01 --> Router Class Initialized
DEBUG - 2017-02-03 17:14:01 --> No URI present. Default controller set.
INFO - 2017-02-03 17:14:01 --> Router Class Initialized
INFO - 2017-02-03 17:14:01 --> Output Class Initialized
INFO - 2017-02-03 17:14:01 --> Output Class Initialized
INFO - 2017-02-03 17:14:01 --> Security Class Initialized
INFO - 2017-02-03 17:14:01 --> Security Class Initialized
DEBUG - 2017-02-03 17:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:14:01 --> Input Class Initialized
DEBUG - 2017-02-03 17:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:14:01 --> Input Class Initialized
INFO - 2017-02-03 17:14:01 --> Language Class Initialized
INFO - 2017-02-03 17:14:01 --> Language Class Initialized
INFO - 2017-02-03 17:14:01 --> Loader Class Initialized
INFO - 2017-02-03 17:14:01 --> Loader Class Initialized
INFO - 2017-02-03 17:14:01 --> Database Driver Class Initialized
INFO - 2017-02-03 17:14:01 --> Database Driver Class Initialized
INFO - 2017-02-03 17:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:14:02 --> Controller Class Initialized
INFO - 2017-02-03 17:14:02 --> Controller Class Initialized
INFO - 2017-02-03 17:14:02 --> Helper loaded: url_helper
INFO - 2017-02-03 17:14:02 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-02-03 17:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:14:03 --> Final output sent to browser
DEBUG - 2017-02-03 17:14:03 --> Total execution time: 2.1492
INFO - 2017-02-03 17:14:03 --> Final output sent to browser
DEBUG - 2017-02-03 17:14:03 --> Total execution time: 2.1496
INFO - 2017-02-03 17:31:01 --> Config Class Initialized
INFO - 2017-02-03 17:31:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:31:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:31:01 --> Utf8 Class Initialized
INFO - 2017-02-03 17:31:01 --> URI Class Initialized
DEBUG - 2017-02-03 17:31:01 --> No URI present. Default controller set.
INFO - 2017-02-03 17:31:01 --> Router Class Initialized
INFO - 2017-02-03 17:31:01 --> Output Class Initialized
INFO - 2017-02-03 17:31:01 --> Security Class Initialized
DEBUG - 2017-02-03 17:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:31:02 --> Input Class Initialized
INFO - 2017-02-03 17:31:02 --> Language Class Initialized
INFO - 2017-02-03 17:31:02 --> Loader Class Initialized
INFO - 2017-02-03 17:31:02 --> Database Driver Class Initialized
INFO - 2017-02-03 17:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:31:03 --> Controller Class Initialized
INFO - 2017-02-03 17:31:03 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:31:03 --> Final output sent to browser
DEBUG - 2017-02-03 17:31:03 --> Total execution time: 1.9926
INFO - 2017-02-03 17:31:06 --> Config Class Initialized
INFO - 2017-02-03 17:31:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:31:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:31:06 --> Utf8 Class Initialized
INFO - 2017-02-03 17:31:06 --> URI Class Initialized
INFO - 2017-02-03 17:31:06 --> Router Class Initialized
INFO - 2017-02-03 17:31:06 --> Output Class Initialized
INFO - 2017-02-03 17:31:06 --> Security Class Initialized
DEBUG - 2017-02-03 17:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:31:06 --> Input Class Initialized
INFO - 2017-02-03 17:31:06 --> Language Class Initialized
INFO - 2017-02-03 17:31:06 --> Loader Class Initialized
INFO - 2017-02-03 17:31:06 --> Database Driver Class Initialized
INFO - 2017-02-03 17:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:31:06 --> Controller Class Initialized
INFO - 2017-02-03 17:31:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:31:06 --> Final output sent to browser
DEBUG - 2017-02-03 17:31:06 --> Total execution time: 0.0139
INFO - 2017-02-03 17:35:16 --> Config Class Initialized
INFO - 2017-02-03 17:35:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:35:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:35:16 --> Utf8 Class Initialized
INFO - 2017-02-03 17:35:16 --> URI Class Initialized
INFO - 2017-02-03 17:35:16 --> Router Class Initialized
INFO - 2017-02-03 17:35:16 --> Output Class Initialized
INFO - 2017-02-03 17:35:16 --> Security Class Initialized
DEBUG - 2017-02-03 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:35:16 --> Input Class Initialized
INFO - 2017-02-03 17:35:16 --> Language Class Initialized
INFO - 2017-02-03 17:35:16 --> Loader Class Initialized
INFO - 2017-02-03 17:35:16 --> Database Driver Class Initialized
INFO - 2017-02-03 17:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:35:16 --> Controller Class Initialized
INFO - 2017-02-03 17:35:16 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:35:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:35:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:35:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:35:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:35:16 --> Final output sent to browser
DEBUG - 2017-02-03 17:35:16 --> Total execution time: 0.0236
INFO - 2017-02-03 17:35:18 --> Config Class Initialized
INFO - 2017-02-03 17:35:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:35:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:35:18 --> Utf8 Class Initialized
INFO - 2017-02-03 17:35:18 --> URI Class Initialized
DEBUG - 2017-02-03 17:35:18 --> No URI present. Default controller set.
INFO - 2017-02-03 17:35:18 --> Router Class Initialized
INFO - 2017-02-03 17:35:18 --> Output Class Initialized
INFO - 2017-02-03 17:35:18 --> Security Class Initialized
DEBUG - 2017-02-03 17:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:35:18 --> Input Class Initialized
INFO - 2017-02-03 17:35:18 --> Language Class Initialized
INFO - 2017-02-03 17:35:18 --> Loader Class Initialized
INFO - 2017-02-03 17:35:18 --> Database Driver Class Initialized
INFO - 2017-02-03 17:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:35:18 --> Controller Class Initialized
INFO - 2017-02-03 17:35:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:35:18 --> Final output sent to browser
DEBUG - 2017-02-03 17:35:18 --> Total execution time: 0.0139
INFO - 2017-02-03 17:42:35 --> Config Class Initialized
INFO - 2017-02-03 17:42:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:42:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:42:35 --> Utf8 Class Initialized
INFO - 2017-02-03 17:42:35 --> URI Class Initialized
DEBUG - 2017-02-03 17:42:35 --> No URI present. Default controller set.
INFO - 2017-02-03 17:42:35 --> Router Class Initialized
INFO - 2017-02-03 17:42:35 --> Output Class Initialized
INFO - 2017-02-03 17:42:35 --> Security Class Initialized
DEBUG - 2017-02-03 17:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:42:35 --> Input Class Initialized
INFO - 2017-02-03 17:42:35 --> Language Class Initialized
INFO - 2017-02-03 17:42:35 --> Loader Class Initialized
INFO - 2017-02-03 17:42:36 --> Database Driver Class Initialized
INFO - 2017-02-03 17:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:42:36 --> Controller Class Initialized
INFO - 2017-02-03 17:42:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:42:37 --> Final output sent to browser
DEBUG - 2017-02-03 17:42:37 --> Total execution time: 2.2564
INFO - 2017-02-03 17:42:44 --> Config Class Initialized
INFO - 2017-02-03 17:42:44 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:42:44 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:42:44 --> Utf8 Class Initialized
INFO - 2017-02-03 17:42:44 --> URI Class Initialized
INFO - 2017-02-03 17:42:44 --> Router Class Initialized
INFO - 2017-02-03 17:42:44 --> Output Class Initialized
INFO - 2017-02-03 17:42:44 --> Security Class Initialized
DEBUG - 2017-02-03 17:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:42:44 --> Input Class Initialized
INFO - 2017-02-03 17:42:44 --> Language Class Initialized
INFO - 2017-02-03 17:42:44 --> Loader Class Initialized
INFO - 2017-02-03 17:42:44 --> Database Driver Class Initialized
INFO - 2017-02-03 17:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:42:44 --> Controller Class Initialized
INFO - 2017-02-03 17:42:44 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:42:44 --> Final output sent to browser
DEBUG - 2017-02-03 17:42:44 --> Total execution time: 0.0155
INFO - 2017-02-03 17:43:04 --> Config Class Initialized
INFO - 2017-02-03 17:43:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:43:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:43:04 --> Utf8 Class Initialized
INFO - 2017-02-03 17:43:04 --> URI Class Initialized
INFO - 2017-02-03 17:43:04 --> Router Class Initialized
INFO - 2017-02-03 17:43:04 --> Output Class Initialized
INFO - 2017-02-03 17:43:04 --> Security Class Initialized
DEBUG - 2017-02-03 17:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:43:04 --> Input Class Initialized
INFO - 2017-02-03 17:43:04 --> Language Class Initialized
INFO - 2017-02-03 17:43:04 --> Loader Class Initialized
INFO - 2017-02-03 17:43:04 --> Database Driver Class Initialized
INFO - 2017-02-03 17:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:43:04 --> Controller Class Initialized
INFO - 2017-02-03 17:43:04 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:43:06 --> Config Class Initialized
INFO - 2017-02-03 17:43:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:43:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:43:06 --> Utf8 Class Initialized
INFO - 2017-02-03 17:43:06 --> URI Class Initialized
INFO - 2017-02-03 17:43:06 --> Router Class Initialized
INFO - 2017-02-03 17:43:06 --> Output Class Initialized
INFO - 2017-02-03 17:43:06 --> Security Class Initialized
DEBUG - 2017-02-03 17:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:43:06 --> Input Class Initialized
INFO - 2017-02-03 17:43:06 --> Language Class Initialized
INFO - 2017-02-03 17:43:06 --> Loader Class Initialized
INFO - 2017-02-03 17:43:06 --> Database Driver Class Initialized
INFO - 2017-02-03 17:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:43:06 --> Controller Class Initialized
INFO - 2017-02-03 17:43:06 --> Helper loaded: date_helper
DEBUG - 2017-02-03 17:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:43:06 --> Helper loaded: url_helper
INFO - 2017-02-03 17:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 17:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 17:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 17:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:43:06 --> Final output sent to browser
DEBUG - 2017-02-03 17:43:06 --> Total execution time: 0.0971
INFO - 2017-02-03 17:43:08 --> Config Class Initialized
INFO - 2017-02-03 17:43:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:43:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:43:08 --> Utf8 Class Initialized
INFO - 2017-02-03 17:43:08 --> URI Class Initialized
INFO - 2017-02-03 17:43:08 --> Router Class Initialized
INFO - 2017-02-03 17:43:08 --> Output Class Initialized
INFO - 2017-02-03 17:43:08 --> Security Class Initialized
DEBUG - 2017-02-03 17:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:43:08 --> Input Class Initialized
INFO - 2017-02-03 17:43:08 --> Language Class Initialized
INFO - 2017-02-03 17:43:08 --> Loader Class Initialized
INFO - 2017-02-03 17:43:08 --> Database Driver Class Initialized
INFO - 2017-02-03 17:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:43:08 --> Controller Class Initialized
INFO - 2017-02-03 17:43:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:43:08 --> Final output sent to browser
DEBUG - 2017-02-03 17:43:08 --> Total execution time: 0.0304
INFO - 2017-02-03 17:43:13 --> Config Class Initialized
INFO - 2017-02-03 17:43:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:43:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:43:13 --> Utf8 Class Initialized
INFO - 2017-02-03 17:43:13 --> URI Class Initialized
INFO - 2017-02-03 17:43:13 --> Router Class Initialized
INFO - 2017-02-03 17:43:13 --> Output Class Initialized
INFO - 2017-02-03 17:43:13 --> Security Class Initialized
DEBUG - 2017-02-03 17:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:43:13 --> Input Class Initialized
INFO - 2017-02-03 17:43:13 --> Language Class Initialized
INFO - 2017-02-03 17:43:13 --> Loader Class Initialized
INFO - 2017-02-03 17:43:13 --> Database Driver Class Initialized
INFO - 2017-02-03 17:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:43:13 --> Controller Class Initialized
INFO - 2017-02-03 17:43:13 --> Helper loaded: date_helper
DEBUG - 2017-02-03 17:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:43:13 --> Helper loaded: url_helper
INFO - 2017-02-03 17:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 17:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 17:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 17:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:43:13 --> Final output sent to browser
DEBUG - 2017-02-03 17:43:13 --> Total execution time: 0.0155
INFO - 2017-02-03 17:43:15 --> Config Class Initialized
INFO - 2017-02-03 17:43:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:43:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:43:15 --> Utf8 Class Initialized
INFO - 2017-02-03 17:43:15 --> URI Class Initialized
INFO - 2017-02-03 17:43:15 --> Router Class Initialized
INFO - 2017-02-03 17:43:15 --> Output Class Initialized
INFO - 2017-02-03 17:43:15 --> Security Class Initialized
DEBUG - 2017-02-03 17:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:43:15 --> Input Class Initialized
INFO - 2017-02-03 17:43:15 --> Language Class Initialized
INFO - 2017-02-03 17:43:15 --> Loader Class Initialized
INFO - 2017-02-03 17:43:15 --> Database Driver Class Initialized
INFO - 2017-02-03 17:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:43:15 --> Controller Class Initialized
INFO - 2017-02-03 17:43:15 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:43:15 --> Final output sent to browser
DEBUG - 2017-02-03 17:43:15 --> Total execution time: 0.0225
INFO - 2017-02-03 17:46:52 --> Config Class Initialized
INFO - 2017-02-03 17:46:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:46:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:46:52 --> Utf8 Class Initialized
INFO - 2017-02-03 17:46:52 --> URI Class Initialized
DEBUG - 2017-02-03 17:46:53 --> No URI present. Default controller set.
INFO - 2017-02-03 17:46:53 --> Router Class Initialized
INFO - 2017-02-03 17:46:53 --> Output Class Initialized
INFO - 2017-02-03 17:46:53 --> Security Class Initialized
DEBUG - 2017-02-03 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:46:53 --> Input Class Initialized
INFO - 2017-02-03 17:46:53 --> Language Class Initialized
INFO - 2017-02-03 17:46:53 --> Loader Class Initialized
INFO - 2017-02-03 17:46:53 --> Database Driver Class Initialized
INFO - 2017-02-03 17:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:46:54 --> Controller Class Initialized
INFO - 2017-02-03 17:46:54 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:46:54 --> Final output sent to browser
DEBUG - 2017-02-03 17:46:54 --> Total execution time: 2.0288
INFO - 2017-02-03 17:47:13 --> Config Class Initialized
INFO - 2017-02-03 17:47:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:47:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:47:13 --> Utf8 Class Initialized
INFO - 2017-02-03 17:47:13 --> URI Class Initialized
DEBUG - 2017-02-03 17:47:13 --> No URI present. Default controller set.
INFO - 2017-02-03 17:47:13 --> Router Class Initialized
INFO - 2017-02-03 17:47:13 --> Output Class Initialized
INFO - 2017-02-03 17:47:13 --> Security Class Initialized
DEBUG - 2017-02-03 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:47:13 --> Input Class Initialized
INFO - 2017-02-03 17:47:13 --> Language Class Initialized
INFO - 2017-02-03 17:47:13 --> Loader Class Initialized
INFO - 2017-02-03 17:47:13 --> Database Driver Class Initialized
INFO - 2017-02-03 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:47:13 --> Controller Class Initialized
INFO - 2017-02-03 17:47:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:47:13 --> Final output sent to browser
DEBUG - 2017-02-03 17:47:13 --> Total execution time: 0.0551
INFO - 2017-02-03 17:47:15 --> Config Class Initialized
INFO - 2017-02-03 17:47:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:47:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:47:15 --> Utf8 Class Initialized
INFO - 2017-02-03 17:47:15 --> URI Class Initialized
DEBUG - 2017-02-03 17:47:15 --> No URI present. Default controller set.
INFO - 2017-02-03 17:47:15 --> Router Class Initialized
INFO - 2017-02-03 17:47:15 --> Output Class Initialized
INFO - 2017-02-03 17:47:15 --> Security Class Initialized
DEBUG - 2017-02-03 17:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:47:15 --> Input Class Initialized
INFO - 2017-02-03 17:47:15 --> Language Class Initialized
INFO - 2017-02-03 17:47:15 --> Loader Class Initialized
INFO - 2017-02-03 17:47:15 --> Database Driver Class Initialized
INFO - 2017-02-03 17:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:47:15 --> Controller Class Initialized
INFO - 2017-02-03 17:47:15 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:47:15 --> Final output sent to browser
DEBUG - 2017-02-03 17:47:15 --> Total execution time: 0.0583
INFO - 2017-02-03 17:47:38 --> Config Class Initialized
INFO - 2017-02-03 17:47:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:47:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:47:38 --> Utf8 Class Initialized
INFO - 2017-02-03 17:47:38 --> URI Class Initialized
INFO - 2017-02-03 17:47:38 --> Router Class Initialized
INFO - 2017-02-03 17:47:38 --> Output Class Initialized
INFO - 2017-02-03 17:47:38 --> Security Class Initialized
DEBUG - 2017-02-03 17:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:47:38 --> Input Class Initialized
INFO - 2017-02-03 17:47:38 --> Language Class Initialized
INFO - 2017-02-03 17:47:38 --> Loader Class Initialized
INFO - 2017-02-03 17:47:38 --> Database Driver Class Initialized
INFO - 2017-02-03 17:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:47:39 --> Controller Class Initialized
INFO - 2017-02-03 17:47:39 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:47:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:47:39 --> Final output sent to browser
DEBUG - 2017-02-03 17:47:39 --> Total execution time: 0.0311
INFO - 2017-02-03 17:48:38 --> Config Class Initialized
INFO - 2017-02-03 17:48:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:48:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:48:38 --> Utf8 Class Initialized
INFO - 2017-02-03 17:48:38 --> URI Class Initialized
INFO - 2017-02-03 17:48:38 --> Router Class Initialized
INFO - 2017-02-03 17:48:38 --> Output Class Initialized
INFO - 2017-02-03 17:48:38 --> Security Class Initialized
DEBUG - 2017-02-03 17:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:48:38 --> Input Class Initialized
INFO - 2017-02-03 17:48:38 --> Language Class Initialized
INFO - 2017-02-03 17:48:38 --> Loader Class Initialized
INFO - 2017-02-03 17:48:38 --> Database Driver Class Initialized
INFO - 2017-02-03 17:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:48:38 --> Controller Class Initialized
INFO - 2017-02-03 17:48:38 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:48:39 --> Config Class Initialized
INFO - 2017-02-03 17:48:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:48:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:48:39 --> Utf8 Class Initialized
INFO - 2017-02-03 17:48:39 --> URI Class Initialized
INFO - 2017-02-03 17:48:39 --> Router Class Initialized
INFO - 2017-02-03 17:48:39 --> Output Class Initialized
INFO - 2017-02-03 17:48:39 --> Security Class Initialized
DEBUG - 2017-02-03 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:48:39 --> Input Class Initialized
INFO - 2017-02-03 17:48:39 --> Language Class Initialized
INFO - 2017-02-03 17:48:39 --> Loader Class Initialized
INFO - 2017-02-03 17:48:39 --> Database Driver Class Initialized
INFO - 2017-02-03 17:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:48:39 --> Controller Class Initialized
INFO - 2017-02-03 17:48:40 --> Helper loaded: date_helper
DEBUG - 2017-02-03 17:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:48:40 --> Helper loaded: url_helper
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:48:40 --> Final output sent to browser
DEBUG - 2017-02-03 17:48:40 --> Total execution time: 0.0803
INFO - 2017-02-03 17:48:40 --> Config Class Initialized
INFO - 2017-02-03 17:48:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:48:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:48:40 --> Utf8 Class Initialized
INFO - 2017-02-03 17:48:40 --> URI Class Initialized
INFO - 2017-02-03 17:48:40 --> Router Class Initialized
INFO - 2017-02-03 17:48:40 --> Output Class Initialized
INFO - 2017-02-03 17:48:40 --> Security Class Initialized
DEBUG - 2017-02-03 17:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:48:40 --> Input Class Initialized
INFO - 2017-02-03 17:48:40 --> Language Class Initialized
INFO - 2017-02-03 17:48:40 --> Loader Class Initialized
INFO - 2017-02-03 17:48:40 --> Database Driver Class Initialized
INFO - 2017-02-03 17:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:48:40 --> Controller Class Initialized
INFO - 2017-02-03 17:48:40 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:48:40 --> Final output sent to browser
DEBUG - 2017-02-03 17:48:40 --> Total execution time: 0.0145
INFO - 2017-02-03 17:49:22 --> Config Class Initialized
INFO - 2017-02-03 17:49:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:49:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:49:22 --> Utf8 Class Initialized
INFO - 2017-02-03 17:49:22 --> URI Class Initialized
DEBUG - 2017-02-03 17:49:22 --> No URI present. Default controller set.
INFO - 2017-02-03 17:49:22 --> Router Class Initialized
INFO - 2017-02-03 17:49:22 --> Output Class Initialized
INFO - 2017-02-03 17:49:22 --> Security Class Initialized
DEBUG - 2017-02-03 17:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:49:22 --> Input Class Initialized
INFO - 2017-02-03 17:49:22 --> Language Class Initialized
INFO - 2017-02-03 17:49:22 --> Loader Class Initialized
INFO - 2017-02-03 17:49:22 --> Database Driver Class Initialized
INFO - 2017-02-03 17:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:49:22 --> Controller Class Initialized
INFO - 2017-02-03 17:49:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:49:22 --> Final output sent to browser
DEBUG - 2017-02-03 17:49:22 --> Total execution time: 0.0218
INFO - 2017-02-03 17:49:23 --> Config Class Initialized
INFO - 2017-02-03 17:49:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:49:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:49:23 --> Utf8 Class Initialized
INFO - 2017-02-03 17:49:23 --> URI Class Initialized
INFO - 2017-02-03 17:49:23 --> Router Class Initialized
INFO - 2017-02-03 17:49:23 --> Output Class Initialized
INFO - 2017-02-03 17:49:23 --> Security Class Initialized
DEBUG - 2017-02-03 17:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:49:23 --> Input Class Initialized
INFO - 2017-02-03 17:49:23 --> Language Class Initialized
INFO - 2017-02-03 17:49:23 --> Loader Class Initialized
INFO - 2017-02-03 17:49:23 --> Database Driver Class Initialized
INFO - 2017-02-03 17:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:49:23 --> Controller Class Initialized
INFO - 2017-02-03 17:49:23 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:49:23 --> Final output sent to browser
DEBUG - 2017-02-03 17:49:23 --> Total execution time: 0.0712
INFO - 2017-02-03 17:49:29 --> Config Class Initialized
INFO - 2017-02-03 17:49:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:49:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:49:29 --> Utf8 Class Initialized
INFO - 2017-02-03 17:49:29 --> URI Class Initialized
INFO - 2017-02-03 17:49:29 --> Router Class Initialized
INFO - 2017-02-03 17:49:29 --> Output Class Initialized
INFO - 2017-02-03 17:49:29 --> Security Class Initialized
DEBUG - 2017-02-03 17:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:49:29 --> Input Class Initialized
INFO - 2017-02-03 17:49:29 --> Language Class Initialized
INFO - 2017-02-03 17:49:29 --> Loader Class Initialized
INFO - 2017-02-03 17:49:29 --> Database Driver Class Initialized
INFO - 2017-02-03 17:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:49:29 --> Controller Class Initialized
INFO - 2017-02-03 17:49:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:49:30 --> Config Class Initialized
INFO - 2017-02-03 17:49:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:49:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:49:30 --> Utf8 Class Initialized
INFO - 2017-02-03 17:49:30 --> URI Class Initialized
INFO - 2017-02-03 17:49:30 --> Router Class Initialized
INFO - 2017-02-03 17:49:30 --> Output Class Initialized
INFO - 2017-02-03 17:49:30 --> Security Class Initialized
DEBUG - 2017-02-03 17:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:49:30 --> Input Class Initialized
INFO - 2017-02-03 17:49:30 --> Language Class Initialized
INFO - 2017-02-03 17:49:30 --> Loader Class Initialized
INFO - 2017-02-03 17:49:30 --> Database Driver Class Initialized
INFO - 2017-02-03 17:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:49:30 --> Controller Class Initialized
INFO - 2017-02-03 17:49:30 --> Helper loaded: date_helper
DEBUG - 2017-02-03 17:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:49:30 --> Helper loaded: url_helper
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:49:30 --> Final output sent to browser
DEBUG - 2017-02-03 17:49:30 --> Total execution time: 0.0139
INFO - 2017-02-03 17:49:30 --> Config Class Initialized
INFO - 2017-02-03 17:49:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 17:49:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 17:49:30 --> Utf8 Class Initialized
INFO - 2017-02-03 17:49:30 --> URI Class Initialized
INFO - 2017-02-03 17:49:30 --> Router Class Initialized
INFO - 2017-02-03 17:49:30 --> Output Class Initialized
INFO - 2017-02-03 17:49:30 --> Security Class Initialized
DEBUG - 2017-02-03 17:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 17:49:30 --> Input Class Initialized
INFO - 2017-02-03 17:49:30 --> Language Class Initialized
INFO - 2017-02-03 17:49:30 --> Loader Class Initialized
INFO - 2017-02-03 17:49:30 --> Database Driver Class Initialized
INFO - 2017-02-03 17:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 17:49:30 --> Controller Class Initialized
INFO - 2017-02-03 17:49:30 --> Helper loaded: url_helper
DEBUG - 2017-02-03 17:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 17:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 17:49:30 --> Final output sent to browser
DEBUG - 2017-02-03 17:49:30 --> Total execution time: 0.0527
INFO - 2017-02-03 18:12:16 --> Config Class Initialized
INFO - 2017-02-03 18:12:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:12:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:12:16 --> Utf8 Class Initialized
INFO - 2017-02-03 18:12:16 --> URI Class Initialized
INFO - 2017-02-03 18:12:16 --> Router Class Initialized
INFO - 2017-02-03 18:12:16 --> Output Class Initialized
INFO - 2017-02-03 18:12:16 --> Security Class Initialized
DEBUG - 2017-02-03 18:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:12:16 --> Input Class Initialized
INFO - 2017-02-03 18:12:16 --> Language Class Initialized
INFO - 2017-02-03 18:12:16 --> Loader Class Initialized
INFO - 2017-02-03 18:12:17 --> Database Driver Class Initialized
INFO - 2017-02-03 18:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:12:17 --> Controller Class Initialized
INFO - 2017-02-03 18:12:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:12:18 --> Final output sent to browser
DEBUG - 2017-02-03 18:12:18 --> Total execution time: 1.9876
INFO - 2017-02-03 18:12:25 --> Config Class Initialized
INFO - 2017-02-03 18:12:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:12:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:12:25 --> Utf8 Class Initialized
INFO - 2017-02-03 18:12:25 --> URI Class Initialized
DEBUG - 2017-02-03 18:12:25 --> No URI present. Default controller set.
INFO - 2017-02-03 18:12:25 --> Router Class Initialized
INFO - 2017-02-03 18:12:25 --> Output Class Initialized
INFO - 2017-02-03 18:12:25 --> Security Class Initialized
DEBUG - 2017-02-03 18:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:12:25 --> Input Class Initialized
INFO - 2017-02-03 18:12:25 --> Language Class Initialized
INFO - 2017-02-03 18:12:25 --> Loader Class Initialized
INFO - 2017-02-03 18:12:25 --> Database Driver Class Initialized
INFO - 2017-02-03 18:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:12:25 --> Controller Class Initialized
INFO - 2017-02-03 18:12:25 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:12:25 --> Final output sent to browser
DEBUG - 2017-02-03 18:12:25 --> Total execution time: 0.2647
INFO - 2017-02-03 18:35:53 --> Config Class Initialized
INFO - 2017-02-03 18:35:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:35:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:35:53 --> Utf8 Class Initialized
INFO - 2017-02-03 18:35:53 --> URI Class Initialized
DEBUG - 2017-02-03 18:35:53 --> No URI present. Default controller set.
INFO - 2017-02-03 18:35:53 --> Router Class Initialized
INFO - 2017-02-03 18:35:53 --> Output Class Initialized
INFO - 2017-02-03 18:35:53 --> Security Class Initialized
DEBUG - 2017-02-03 18:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:35:53 --> Input Class Initialized
INFO - 2017-02-03 18:35:53 --> Language Class Initialized
INFO - 2017-02-03 18:35:53 --> Loader Class Initialized
INFO - 2017-02-03 18:35:54 --> Database Driver Class Initialized
INFO - 2017-02-03 18:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:35:54 --> Controller Class Initialized
INFO - 2017-02-03 18:35:54 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:35:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:35:55 --> Final output sent to browser
DEBUG - 2017-02-03 18:35:55 --> Total execution time: 1.9860
INFO - 2017-02-03 18:35:56 --> Config Class Initialized
INFO - 2017-02-03 18:35:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:35:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:35:56 --> Utf8 Class Initialized
INFO - 2017-02-03 18:35:56 --> URI Class Initialized
INFO - 2017-02-03 18:35:56 --> Router Class Initialized
INFO - 2017-02-03 18:35:56 --> Output Class Initialized
INFO - 2017-02-03 18:35:56 --> Security Class Initialized
DEBUG - 2017-02-03 18:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:35:56 --> Input Class Initialized
INFO - 2017-02-03 18:35:56 --> Language Class Initialized
INFO - 2017-02-03 18:35:56 --> Loader Class Initialized
INFO - 2017-02-03 18:35:56 --> Database Driver Class Initialized
INFO - 2017-02-03 18:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:35:56 --> Controller Class Initialized
INFO - 2017-02-03 18:35:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:35:56 --> Final output sent to browser
DEBUG - 2017-02-03 18:35:56 --> Total execution time: 0.0153
INFO - 2017-02-03 18:36:04 --> Config Class Initialized
INFO - 2017-02-03 18:36:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:04 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:04 --> URI Class Initialized
INFO - 2017-02-03 18:36:04 --> Router Class Initialized
INFO - 2017-02-03 18:36:04 --> Output Class Initialized
INFO - 2017-02-03 18:36:04 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:04 --> Input Class Initialized
INFO - 2017-02-03 18:36:04 --> Language Class Initialized
INFO - 2017-02-03 18:36:04 --> Loader Class Initialized
INFO - 2017-02-03 18:36:04 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:04 --> Controller Class Initialized
INFO - 2017-02-03 18:36:04 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 18:36:06 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 18:36:06 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-03 18:36:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 18:36:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 18:36:06 --> Config Class Initialized
INFO - 2017-02-03 18:36:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:06 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:06 --> URI Class Initialized
INFO - 2017-02-03 18:36:06 --> Router Class Initialized
INFO - 2017-02-03 18:36:06 --> Output Class Initialized
INFO - 2017-02-03 18:36:06 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:06 --> Input Class Initialized
INFO - 2017-02-03 18:36:06 --> Language Class Initialized
INFO - 2017-02-03 18:36:06 --> Loader Class Initialized
INFO - 2017-02-03 18:36:06 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:06 --> Controller Class Initialized
INFO - 2017-02-03 18:36:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:36:06 --> Final output sent to browser
DEBUG - 2017-02-03 18:36:06 --> Total execution time: 0.0142
INFO - 2017-02-03 18:36:13 --> Config Class Initialized
INFO - 2017-02-03 18:36:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:13 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:13 --> URI Class Initialized
INFO - 2017-02-03 18:36:13 --> Router Class Initialized
INFO - 2017-02-03 18:36:13 --> Output Class Initialized
INFO - 2017-02-03 18:36:13 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:13 --> Input Class Initialized
INFO - 2017-02-03 18:36:13 --> Language Class Initialized
INFO - 2017-02-03 18:36:13 --> Loader Class Initialized
INFO - 2017-02-03 18:36:13 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:13 --> Controller Class Initialized
INFO - 2017-02-03 18:36:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 18:36:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 18:36:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-03 18:36:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 18:36:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 18:36:14 --> Config Class Initialized
INFO - 2017-02-03 18:36:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:14 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:14 --> URI Class Initialized
INFO - 2017-02-03 18:36:14 --> Router Class Initialized
INFO - 2017-02-03 18:36:14 --> Output Class Initialized
INFO - 2017-02-03 18:36:14 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:14 --> Input Class Initialized
INFO - 2017-02-03 18:36:14 --> Language Class Initialized
INFO - 2017-02-03 18:36:14 --> Loader Class Initialized
INFO - 2017-02-03 18:36:14 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:14 --> Controller Class Initialized
INFO - 2017-02-03 18:36:14 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:36:14 --> Final output sent to browser
DEBUG - 2017-02-03 18:36:14 --> Total execution time: 0.0134
INFO - 2017-02-03 18:36:16 --> Config Class Initialized
INFO - 2017-02-03 18:36:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:16 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:16 --> URI Class Initialized
INFO - 2017-02-03 18:36:16 --> Router Class Initialized
INFO - 2017-02-03 18:36:16 --> Output Class Initialized
INFO - 2017-02-03 18:36:16 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:16 --> Input Class Initialized
INFO - 2017-02-03 18:36:16 --> Language Class Initialized
INFO - 2017-02-03 18:36:16 --> Loader Class Initialized
INFO - 2017-02-03 18:36:16 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:16 --> Controller Class Initialized
INFO - 2017-02-03 18:36:16 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 18:36:16 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 18:36:16 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-03 18:36:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 18:36:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 18:36:16 --> Config Class Initialized
INFO - 2017-02-03 18:36:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:16 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:16 --> URI Class Initialized
INFO - 2017-02-03 18:36:16 --> Router Class Initialized
INFO - 2017-02-03 18:36:16 --> Output Class Initialized
INFO - 2017-02-03 18:36:16 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:16 --> Input Class Initialized
INFO - 2017-02-03 18:36:16 --> Language Class Initialized
INFO - 2017-02-03 18:36:16 --> Loader Class Initialized
INFO - 2017-02-03 18:36:16 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:16 --> Controller Class Initialized
INFO - 2017-02-03 18:36:16 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:36:16 --> Final output sent to browser
DEBUG - 2017-02-03 18:36:16 --> Total execution time: 0.0157
INFO - 2017-02-03 18:36:18 --> Config Class Initialized
INFO - 2017-02-03 18:36:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:18 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:18 --> URI Class Initialized
INFO - 2017-02-03 18:36:18 --> Router Class Initialized
INFO - 2017-02-03 18:36:18 --> Output Class Initialized
INFO - 2017-02-03 18:36:18 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:18 --> Input Class Initialized
INFO - 2017-02-03 18:36:18 --> Language Class Initialized
INFO - 2017-02-03 18:36:18 --> Loader Class Initialized
INFO - 2017-02-03 18:36:18 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:18 --> Controller Class Initialized
INFO - 2017-02-03 18:36:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 18:36:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 18:36:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-03 18:36:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 18:36:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 18:36:19 --> Config Class Initialized
INFO - 2017-02-03 18:36:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:19 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:19 --> URI Class Initialized
INFO - 2017-02-03 18:36:19 --> Router Class Initialized
INFO - 2017-02-03 18:36:19 --> Output Class Initialized
INFO - 2017-02-03 18:36:19 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:19 --> Input Class Initialized
INFO - 2017-02-03 18:36:19 --> Language Class Initialized
INFO - 2017-02-03 18:36:19 --> Loader Class Initialized
INFO - 2017-02-03 18:36:19 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:19 --> Controller Class Initialized
INFO - 2017-02-03 18:36:19 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:36:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:36:19 --> Final output sent to browser
DEBUG - 2017-02-03 18:36:19 --> Total execution time: 0.0133
INFO - 2017-02-03 18:36:20 --> Config Class Initialized
INFO - 2017-02-03 18:36:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:20 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:20 --> URI Class Initialized
DEBUG - 2017-02-03 18:36:20 --> No URI present. Default controller set.
INFO - 2017-02-03 18:36:20 --> Router Class Initialized
INFO - 2017-02-03 18:36:20 --> Output Class Initialized
INFO - 2017-02-03 18:36:20 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:20 --> Input Class Initialized
INFO - 2017-02-03 18:36:20 --> Language Class Initialized
INFO - 2017-02-03 18:36:20 --> Loader Class Initialized
INFO - 2017-02-03 18:36:20 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:20 --> Controller Class Initialized
INFO - 2017-02-03 18:36:20 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:36:20 --> Final output sent to browser
DEBUG - 2017-02-03 18:36:20 --> Total execution time: 0.0133
INFO - 2017-02-03 18:36:21 --> Config Class Initialized
INFO - 2017-02-03 18:36:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:21 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:21 --> URI Class Initialized
INFO - 2017-02-03 18:36:21 --> Router Class Initialized
INFO - 2017-02-03 18:36:21 --> Output Class Initialized
INFO - 2017-02-03 18:36:21 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:21 --> Input Class Initialized
INFO - 2017-02-03 18:36:21 --> Language Class Initialized
INFO - 2017-02-03 18:36:21 --> Loader Class Initialized
INFO - 2017-02-03 18:36:21 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:21 --> Controller Class Initialized
INFO - 2017-02-03 18:36:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:36:21 --> Final output sent to browser
DEBUG - 2017-02-03 18:36:21 --> Total execution time: 0.0179
INFO - 2017-02-03 18:36:25 --> Config Class Initialized
INFO - 2017-02-03 18:36:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:25 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:25 --> URI Class Initialized
INFO - 2017-02-03 18:36:25 --> Router Class Initialized
INFO - 2017-02-03 18:36:25 --> Output Class Initialized
INFO - 2017-02-03 18:36:25 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:25 --> Input Class Initialized
INFO - 2017-02-03 18:36:25 --> Language Class Initialized
INFO - 2017-02-03 18:36:25 --> Loader Class Initialized
INFO - 2017-02-03 18:36:25 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:25 --> Controller Class Initialized
INFO - 2017-02-03 18:36:25 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 18:36:26 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 18:36:26 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-03 18:36:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 18:36:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 18:36:26 --> Config Class Initialized
INFO - 2017-02-03 18:36:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:36:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:36:26 --> Utf8 Class Initialized
INFO - 2017-02-03 18:36:26 --> URI Class Initialized
INFO - 2017-02-03 18:36:26 --> Router Class Initialized
INFO - 2017-02-03 18:36:26 --> Output Class Initialized
INFO - 2017-02-03 18:36:26 --> Security Class Initialized
DEBUG - 2017-02-03 18:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:36:26 --> Input Class Initialized
INFO - 2017-02-03 18:36:26 --> Language Class Initialized
INFO - 2017-02-03 18:36:26 --> Loader Class Initialized
INFO - 2017-02-03 18:36:26 --> Database Driver Class Initialized
INFO - 2017-02-03 18:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:36:26 --> Controller Class Initialized
INFO - 2017-02-03 18:36:26 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:36:26 --> Final output sent to browser
DEBUG - 2017-02-03 18:36:26 --> Total execution time: 0.0146
INFO - 2017-02-03 18:37:41 --> Config Class Initialized
INFO - 2017-02-03 18:37:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:37:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:37:41 --> Utf8 Class Initialized
INFO - 2017-02-03 18:37:41 --> URI Class Initialized
DEBUG - 2017-02-03 18:37:41 --> No URI present. Default controller set.
INFO - 2017-02-03 18:37:41 --> Router Class Initialized
INFO - 2017-02-03 18:37:41 --> Output Class Initialized
INFO - 2017-02-03 18:37:41 --> Security Class Initialized
DEBUG - 2017-02-03 18:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:37:41 --> Input Class Initialized
INFO - 2017-02-03 18:37:41 --> Language Class Initialized
INFO - 2017-02-03 18:37:41 --> Loader Class Initialized
INFO - 2017-02-03 18:37:41 --> Database Driver Class Initialized
INFO - 2017-02-03 18:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:37:41 --> Controller Class Initialized
INFO - 2017-02-03 18:37:41 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:37:41 --> Final output sent to browser
DEBUG - 2017-02-03 18:37:41 --> Total execution time: 0.0132
INFO - 2017-02-03 18:37:42 --> Config Class Initialized
INFO - 2017-02-03 18:37:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:37:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:37:42 --> Utf8 Class Initialized
INFO - 2017-02-03 18:37:42 --> URI Class Initialized
INFO - 2017-02-03 18:37:42 --> Router Class Initialized
INFO - 2017-02-03 18:37:42 --> Output Class Initialized
INFO - 2017-02-03 18:37:42 --> Security Class Initialized
DEBUG - 2017-02-03 18:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:37:42 --> Input Class Initialized
INFO - 2017-02-03 18:37:42 --> Language Class Initialized
INFO - 2017-02-03 18:37:42 --> Loader Class Initialized
INFO - 2017-02-03 18:37:42 --> Database Driver Class Initialized
INFO - 2017-02-03 18:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:37:42 --> Controller Class Initialized
INFO - 2017-02-03 18:37:42 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:37:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:37:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:37:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:37:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:37:42 --> Final output sent to browser
DEBUG - 2017-02-03 18:37:42 --> Total execution time: 0.0134
INFO - 2017-02-03 18:37:45 --> Config Class Initialized
INFO - 2017-02-03 18:37:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:37:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:37:45 --> Utf8 Class Initialized
INFO - 2017-02-03 18:37:45 --> URI Class Initialized
INFO - 2017-02-03 18:37:45 --> Router Class Initialized
INFO - 2017-02-03 18:37:45 --> Output Class Initialized
INFO - 2017-02-03 18:37:45 --> Security Class Initialized
DEBUG - 2017-02-03 18:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:37:45 --> Input Class Initialized
INFO - 2017-02-03 18:37:45 --> Language Class Initialized
INFO - 2017-02-03 18:37:45 --> Loader Class Initialized
INFO - 2017-02-03 18:37:45 --> Database Driver Class Initialized
INFO - 2017-02-03 18:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:37:45 --> Controller Class Initialized
INFO - 2017-02-03 18:37:45 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:37:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 18:37:46 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 18:37:46 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-03 18:37:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 18:37:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 18:37:46 --> Config Class Initialized
INFO - 2017-02-03 18:37:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:37:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:37:46 --> Utf8 Class Initialized
INFO - 2017-02-03 18:37:46 --> URI Class Initialized
INFO - 2017-02-03 18:37:46 --> Router Class Initialized
INFO - 2017-02-03 18:37:46 --> Output Class Initialized
INFO - 2017-02-03 18:37:46 --> Security Class Initialized
DEBUG - 2017-02-03 18:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:37:46 --> Input Class Initialized
INFO - 2017-02-03 18:37:46 --> Language Class Initialized
INFO - 2017-02-03 18:37:46 --> Loader Class Initialized
INFO - 2017-02-03 18:37:46 --> Database Driver Class Initialized
INFO - 2017-02-03 18:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:37:46 --> Controller Class Initialized
INFO - 2017-02-03 18:37:46 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:37:46 --> Final output sent to browser
DEBUG - 2017-02-03 18:37:46 --> Total execution time: 0.0139
INFO - 2017-02-03 18:53:18 --> Config Class Initialized
INFO - 2017-02-03 18:53:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:53:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:53:18 --> Utf8 Class Initialized
INFO - 2017-02-03 18:53:18 --> URI Class Initialized
DEBUG - 2017-02-03 18:53:18 --> No URI present. Default controller set.
INFO - 2017-02-03 18:53:18 --> Router Class Initialized
INFO - 2017-02-03 18:53:18 --> Output Class Initialized
INFO - 2017-02-03 18:53:18 --> Security Class Initialized
DEBUG - 2017-02-03 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:53:18 --> Input Class Initialized
INFO - 2017-02-03 18:53:18 --> Language Class Initialized
INFO - 2017-02-03 18:53:18 --> Loader Class Initialized
INFO - 2017-02-03 18:53:18 --> Database Driver Class Initialized
INFO - 2017-02-03 18:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:53:19 --> Controller Class Initialized
INFO - 2017-02-03 18:53:19 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:53:19 --> Final output sent to browser
DEBUG - 2017-02-03 18:53:19 --> Total execution time: 0.0137
INFO - 2017-02-03 18:53:26 --> Config Class Initialized
INFO - 2017-02-03 18:53:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:53:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:53:26 --> Utf8 Class Initialized
INFO - 2017-02-03 18:53:26 --> URI Class Initialized
INFO - 2017-02-03 18:53:26 --> Router Class Initialized
INFO - 2017-02-03 18:53:26 --> Output Class Initialized
INFO - 2017-02-03 18:53:26 --> Security Class Initialized
DEBUG - 2017-02-03 18:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:53:26 --> Input Class Initialized
INFO - 2017-02-03 18:53:26 --> Language Class Initialized
INFO - 2017-02-03 18:53:26 --> Loader Class Initialized
INFO - 2017-02-03 18:53:26 --> Database Driver Class Initialized
INFO - 2017-02-03 18:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:53:26 --> Controller Class Initialized
INFO - 2017-02-03 18:53:26 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:53:26 --> Final output sent to browser
DEBUG - 2017-02-03 18:53:26 --> Total execution time: 0.0138
INFO - 2017-02-03 18:54:40 --> Config Class Initialized
INFO - 2017-02-03 18:54:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:54:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:54:40 --> Utf8 Class Initialized
INFO - 2017-02-03 18:54:40 --> URI Class Initialized
INFO - 2017-02-03 18:54:40 --> Router Class Initialized
INFO - 2017-02-03 18:54:40 --> Output Class Initialized
INFO - 2017-02-03 18:54:40 --> Security Class Initialized
DEBUG - 2017-02-03 18:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:54:40 --> Input Class Initialized
INFO - 2017-02-03 18:54:40 --> Language Class Initialized
INFO - 2017-02-03 18:54:40 --> Loader Class Initialized
INFO - 2017-02-03 18:54:40 --> Database Driver Class Initialized
INFO - 2017-02-03 18:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:54:40 --> Controller Class Initialized
INFO - 2017-02-03 18:54:40 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:54:41 --> Config Class Initialized
INFO - 2017-02-03 18:54:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:54:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:54:41 --> Utf8 Class Initialized
INFO - 2017-02-03 18:54:41 --> URI Class Initialized
INFO - 2017-02-03 18:54:41 --> Router Class Initialized
INFO - 2017-02-03 18:54:41 --> Output Class Initialized
INFO - 2017-02-03 18:54:41 --> Security Class Initialized
DEBUG - 2017-02-03 18:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:54:41 --> Input Class Initialized
INFO - 2017-02-03 18:54:41 --> Language Class Initialized
INFO - 2017-02-03 18:54:41 --> Loader Class Initialized
INFO - 2017-02-03 18:54:41 --> Database Driver Class Initialized
INFO - 2017-02-03 18:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:54:41 --> Controller Class Initialized
INFO - 2017-02-03 18:54:41 --> Helper loaded: date_helper
DEBUG - 2017-02-03 18:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:54:41 --> Helper loaded: url_helper
INFO - 2017-02-03 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:54:41 --> Final output sent to browser
DEBUG - 2017-02-03 18:54:41 --> Total execution time: 0.1351
INFO - 2017-02-03 18:54:42 --> Config Class Initialized
INFO - 2017-02-03 18:54:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:54:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:54:42 --> Utf8 Class Initialized
INFO - 2017-02-03 18:54:42 --> URI Class Initialized
INFO - 2017-02-03 18:54:42 --> Router Class Initialized
INFO - 2017-02-03 18:54:42 --> Output Class Initialized
INFO - 2017-02-03 18:54:42 --> Security Class Initialized
DEBUG - 2017-02-03 18:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:54:42 --> Input Class Initialized
INFO - 2017-02-03 18:54:42 --> Language Class Initialized
INFO - 2017-02-03 18:54:42 --> Loader Class Initialized
INFO - 2017-02-03 18:54:42 --> Database Driver Class Initialized
INFO - 2017-02-03 18:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:54:42 --> Controller Class Initialized
INFO - 2017-02-03 18:54:42 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:54:42 --> Final output sent to browser
DEBUG - 2017-02-03 18:54:42 --> Total execution time: 0.0138
INFO - 2017-02-03 18:55:08 --> Config Class Initialized
INFO - 2017-02-03 18:55:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:08 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:08 --> URI Class Initialized
DEBUG - 2017-02-03 18:55:08 --> No URI present. Default controller set.
INFO - 2017-02-03 18:55:08 --> Router Class Initialized
INFO - 2017-02-03 18:55:08 --> Output Class Initialized
INFO - 2017-02-03 18:55:08 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:08 --> Input Class Initialized
INFO - 2017-02-03 18:55:08 --> Language Class Initialized
INFO - 2017-02-03 18:55:08 --> Loader Class Initialized
INFO - 2017-02-03 18:55:08 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:08 --> Controller Class Initialized
INFO - 2017-02-03 18:55:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:08 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:08 --> Total execution time: 0.0130
INFO - 2017-02-03 18:55:11 --> Config Class Initialized
INFO - 2017-02-03 18:55:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:11 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:11 --> URI Class Initialized
INFO - 2017-02-03 18:55:11 --> Router Class Initialized
INFO - 2017-02-03 18:55:11 --> Output Class Initialized
INFO - 2017-02-03 18:55:11 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:11 --> Input Class Initialized
INFO - 2017-02-03 18:55:11 --> Language Class Initialized
INFO - 2017-02-03 18:55:11 --> Loader Class Initialized
INFO - 2017-02-03 18:55:11 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:11 --> Controller Class Initialized
INFO - 2017-02-03 18:55:11 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:11 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:11 --> Total execution time: 0.0140
INFO - 2017-02-03 18:55:39 --> Config Class Initialized
INFO - 2017-02-03 18:55:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:39 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:39 --> URI Class Initialized
INFO - 2017-02-03 18:55:39 --> Router Class Initialized
INFO - 2017-02-03 18:55:39 --> Output Class Initialized
INFO - 2017-02-03 18:55:39 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:39 --> Input Class Initialized
INFO - 2017-02-03 18:55:39 --> Language Class Initialized
INFO - 2017-02-03 18:55:39 --> Loader Class Initialized
INFO - 2017-02-03 18:55:39 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:39 --> Controller Class Initialized
INFO - 2017-02-03 18:55:39 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:41 --> Config Class Initialized
INFO - 2017-02-03 18:55:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:41 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:41 --> URI Class Initialized
INFO - 2017-02-03 18:55:41 --> Router Class Initialized
INFO - 2017-02-03 18:55:41 --> Output Class Initialized
INFO - 2017-02-03 18:55:41 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:41 --> Input Class Initialized
INFO - 2017-02-03 18:55:41 --> Language Class Initialized
INFO - 2017-02-03 18:55:41 --> Loader Class Initialized
INFO - 2017-02-03 18:55:41 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:41 --> Controller Class Initialized
INFO - 2017-02-03 18:55:41 --> Helper loaded: date_helper
DEBUG - 2017-02-03 18:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:41 --> Helper loaded: url_helper
INFO - 2017-02-03 18:55:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 18:55:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 18:55:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 18:55:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:41 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:41 --> Total execution time: 0.0138
INFO - 2017-02-03 18:55:42 --> Config Class Initialized
INFO - 2017-02-03 18:55:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:42 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:42 --> URI Class Initialized
INFO - 2017-02-03 18:55:42 --> Router Class Initialized
INFO - 2017-02-03 18:55:42 --> Output Class Initialized
INFO - 2017-02-03 18:55:42 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:42 --> Input Class Initialized
INFO - 2017-02-03 18:55:42 --> Language Class Initialized
INFO - 2017-02-03 18:55:42 --> Loader Class Initialized
INFO - 2017-02-03 18:55:42 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:42 --> Controller Class Initialized
INFO - 2017-02-03 18:55:42 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:42 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:42 --> Total execution time: 0.0140
INFO - 2017-02-03 18:55:58 --> Config Class Initialized
INFO - 2017-02-03 18:55:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:58 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:58 --> URI Class Initialized
DEBUG - 2017-02-03 18:55:58 --> No URI present. Default controller set.
INFO - 2017-02-03 18:55:58 --> Router Class Initialized
INFO - 2017-02-03 18:55:58 --> Output Class Initialized
INFO - 2017-02-03 18:55:58 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:58 --> Input Class Initialized
INFO - 2017-02-03 18:55:58 --> Language Class Initialized
INFO - 2017-02-03 18:55:58 --> Loader Class Initialized
INFO - 2017-02-03 18:55:58 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:58 --> Controller Class Initialized
INFO - 2017-02-03 18:55:58 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:58 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:58 --> Total execution time: 0.0132
INFO - 2017-02-03 18:55:59 --> Config Class Initialized
INFO - 2017-02-03 18:55:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:59 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:59 --> URI Class Initialized
INFO - 2017-02-03 18:55:59 --> Router Class Initialized
INFO - 2017-02-03 18:55:59 --> Output Class Initialized
INFO - 2017-02-03 18:55:59 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:59 --> Input Class Initialized
INFO - 2017-02-03 18:55:59 --> Language Class Initialized
INFO - 2017-02-03 18:55:59 --> Loader Class Initialized
INFO - 2017-02-03 18:55:59 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:59 --> Controller Class Initialized
INFO - 2017-02-03 18:55:59 --> Helper loaded: date_helper
DEBUG - 2017-02-03 18:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:59 --> Helper loaded: url_helper
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:59 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:59 --> Total execution time: 0.0144
INFO - 2017-02-03 18:55:59 --> Config Class Initialized
INFO - 2017-02-03 18:55:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:59 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:59 --> URI Class Initialized
INFO - 2017-02-03 18:55:59 --> Router Class Initialized
INFO - 2017-02-03 18:55:59 --> Output Class Initialized
INFO - 2017-02-03 18:55:59 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:59 --> Input Class Initialized
INFO - 2017-02-03 18:55:59 --> Language Class Initialized
INFO - 2017-02-03 18:55:59 --> Loader Class Initialized
INFO - 2017-02-03 18:55:59 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:59 --> Controller Class Initialized
INFO - 2017-02-03 18:55:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:59 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:59 --> Total execution time: 0.0159
INFO - 2017-02-03 18:55:59 --> Config Class Initialized
INFO - 2017-02-03 18:55:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:55:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:55:59 --> Utf8 Class Initialized
INFO - 2017-02-03 18:55:59 --> URI Class Initialized
DEBUG - 2017-02-03 18:55:59 --> No URI present. Default controller set.
INFO - 2017-02-03 18:55:59 --> Router Class Initialized
INFO - 2017-02-03 18:55:59 --> Output Class Initialized
INFO - 2017-02-03 18:55:59 --> Security Class Initialized
DEBUG - 2017-02-03 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:55:59 --> Input Class Initialized
INFO - 2017-02-03 18:55:59 --> Language Class Initialized
INFO - 2017-02-03 18:55:59 --> Loader Class Initialized
INFO - 2017-02-03 18:55:59 --> Database Driver Class Initialized
INFO - 2017-02-03 18:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:55:59 --> Controller Class Initialized
INFO - 2017-02-03 18:55:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:55:59 --> Final output sent to browser
DEBUG - 2017-02-03 18:55:59 --> Total execution time: 0.0139
INFO - 2017-02-03 18:57:17 --> Config Class Initialized
INFO - 2017-02-03 18:57:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:57:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:57:17 --> Utf8 Class Initialized
INFO - 2017-02-03 18:57:17 --> URI Class Initialized
DEBUG - 2017-02-03 18:57:17 --> No URI present. Default controller set.
INFO - 2017-02-03 18:57:17 --> Router Class Initialized
INFO - 2017-02-03 18:57:17 --> Output Class Initialized
INFO - 2017-02-03 18:57:17 --> Security Class Initialized
DEBUG - 2017-02-03 18:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:57:17 --> Input Class Initialized
INFO - 2017-02-03 18:57:17 --> Language Class Initialized
INFO - 2017-02-03 18:57:17 --> Loader Class Initialized
INFO - 2017-02-03 18:57:17 --> Database Driver Class Initialized
INFO - 2017-02-03 18:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:57:17 --> Controller Class Initialized
INFO - 2017-02-03 18:57:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:57:17 --> Final output sent to browser
DEBUG - 2017-02-03 18:57:17 --> Total execution time: 0.0132
INFO - 2017-02-03 18:58:41 --> Config Class Initialized
INFO - 2017-02-03 18:58:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:58:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:58:41 --> Utf8 Class Initialized
INFO - 2017-02-03 18:58:41 --> URI Class Initialized
INFO - 2017-02-03 18:58:41 --> Router Class Initialized
INFO - 2017-02-03 18:58:41 --> Output Class Initialized
INFO - 2017-02-03 18:58:41 --> Security Class Initialized
DEBUG - 2017-02-03 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:58:41 --> Input Class Initialized
INFO - 2017-02-03 18:58:41 --> Language Class Initialized
INFO - 2017-02-03 18:58:41 --> Loader Class Initialized
INFO - 2017-02-03 18:58:41 --> Database Driver Class Initialized
INFO - 2017-02-03 18:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:58:41 --> Controller Class Initialized
INFO - 2017-02-03 18:58:41 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:58:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 18:58:42 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 18:58:42 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Susana Casas')
INFO - 2017-02-03 18:58:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 18:58:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 18:58:43 --> Config Class Initialized
INFO - 2017-02-03 18:58:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:58:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:58:43 --> Utf8 Class Initialized
INFO - 2017-02-03 18:58:43 --> URI Class Initialized
INFO - 2017-02-03 18:58:43 --> Router Class Initialized
INFO - 2017-02-03 18:58:43 --> Output Class Initialized
INFO - 2017-02-03 18:58:43 --> Security Class Initialized
DEBUG - 2017-02-03 18:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:58:43 --> Input Class Initialized
INFO - 2017-02-03 18:58:43 --> Language Class Initialized
INFO - 2017-02-03 18:58:43 --> Loader Class Initialized
INFO - 2017-02-03 18:58:43 --> Database Driver Class Initialized
INFO - 2017-02-03 18:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:58:43 --> Controller Class Initialized
INFO - 2017-02-03 18:58:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:58:43 --> Final output sent to browser
DEBUG - 2017-02-03 18:58:43 --> Total execution time: 0.0293
INFO - 2017-02-03 18:58:54 --> Config Class Initialized
INFO - 2017-02-03 18:58:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:58:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:58:54 --> Utf8 Class Initialized
INFO - 2017-02-03 18:58:54 --> URI Class Initialized
DEBUG - 2017-02-03 18:58:54 --> No URI present. Default controller set.
INFO - 2017-02-03 18:58:54 --> Router Class Initialized
INFO - 2017-02-03 18:58:54 --> Output Class Initialized
INFO - 2017-02-03 18:58:54 --> Security Class Initialized
DEBUG - 2017-02-03 18:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:58:54 --> Input Class Initialized
INFO - 2017-02-03 18:58:54 --> Language Class Initialized
INFO - 2017-02-03 18:58:54 --> Loader Class Initialized
INFO - 2017-02-03 18:58:54 --> Database Driver Class Initialized
INFO - 2017-02-03 18:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:58:54 --> Controller Class Initialized
INFO - 2017-02-03 18:58:54 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:58:54 --> Final output sent to browser
DEBUG - 2017-02-03 18:58:54 --> Total execution time: 0.0143
INFO - 2017-02-03 18:59:18 --> Config Class Initialized
INFO - 2017-02-03 18:59:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:59:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:59:18 --> Utf8 Class Initialized
INFO - 2017-02-03 18:59:18 --> URI Class Initialized
DEBUG - 2017-02-03 18:59:18 --> No URI present. Default controller set.
INFO - 2017-02-03 18:59:18 --> Router Class Initialized
INFO - 2017-02-03 18:59:18 --> Output Class Initialized
INFO - 2017-02-03 18:59:18 --> Security Class Initialized
DEBUG - 2017-02-03 18:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:59:18 --> Input Class Initialized
INFO - 2017-02-03 18:59:18 --> Language Class Initialized
INFO - 2017-02-03 18:59:18 --> Loader Class Initialized
INFO - 2017-02-03 18:59:18 --> Database Driver Class Initialized
INFO - 2017-02-03 18:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:59:18 --> Controller Class Initialized
INFO - 2017-02-03 18:59:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:59:18 --> Final output sent to browser
DEBUG - 2017-02-03 18:59:18 --> Total execution time: 0.0130
INFO - 2017-02-03 18:59:21 --> Config Class Initialized
INFO - 2017-02-03 18:59:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:59:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:59:21 --> Utf8 Class Initialized
INFO - 2017-02-03 18:59:21 --> URI Class Initialized
INFO - 2017-02-03 18:59:21 --> Router Class Initialized
INFO - 2017-02-03 18:59:21 --> Output Class Initialized
INFO - 2017-02-03 18:59:21 --> Security Class Initialized
DEBUG - 2017-02-03 18:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:59:21 --> Input Class Initialized
INFO - 2017-02-03 18:59:21 --> Language Class Initialized
INFO - 2017-02-03 18:59:21 --> Loader Class Initialized
INFO - 2017-02-03 18:59:21 --> Database Driver Class Initialized
INFO - 2017-02-03 18:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:59:21 --> Controller Class Initialized
INFO - 2017-02-03 18:59:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:59:21 --> Final output sent to browser
DEBUG - 2017-02-03 18:59:21 --> Total execution time: 0.0132
INFO - 2017-02-03 18:59:36 --> Config Class Initialized
INFO - 2017-02-03 18:59:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:59:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:59:36 --> Utf8 Class Initialized
INFO - 2017-02-03 18:59:36 --> URI Class Initialized
INFO - 2017-02-03 18:59:36 --> Router Class Initialized
INFO - 2017-02-03 18:59:36 --> Output Class Initialized
INFO - 2017-02-03 18:59:36 --> Security Class Initialized
DEBUG - 2017-02-03 18:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:59:36 --> Input Class Initialized
INFO - 2017-02-03 18:59:36 --> Language Class Initialized
INFO - 2017-02-03 18:59:36 --> Loader Class Initialized
INFO - 2017-02-03 18:59:36 --> Database Driver Class Initialized
INFO - 2017-02-03 18:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:59:36 --> Controller Class Initialized
INFO - 2017-02-03 18:59:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:59:37 --> Config Class Initialized
INFO - 2017-02-03 18:59:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:59:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:59:37 --> Utf8 Class Initialized
INFO - 2017-02-03 18:59:37 --> URI Class Initialized
INFO - 2017-02-03 18:59:37 --> Router Class Initialized
INFO - 2017-02-03 18:59:37 --> Output Class Initialized
INFO - 2017-02-03 18:59:37 --> Security Class Initialized
DEBUG - 2017-02-03 18:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:59:37 --> Input Class Initialized
INFO - 2017-02-03 18:59:37 --> Language Class Initialized
INFO - 2017-02-03 18:59:37 --> Loader Class Initialized
INFO - 2017-02-03 18:59:37 --> Database Driver Class Initialized
INFO - 2017-02-03 18:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:59:37 --> Controller Class Initialized
INFO - 2017-02-03 18:59:37 --> Helper loaded: date_helper
DEBUG - 2017-02-03 18:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:59:37 --> Helper loaded: url_helper
INFO - 2017-02-03 18:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 18:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 18:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 18:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:59:37 --> Final output sent to browser
DEBUG - 2017-02-03 18:59:37 --> Total execution time: 0.0155
INFO - 2017-02-03 18:59:37 --> Config Class Initialized
INFO - 2017-02-03 18:59:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:59:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:59:37 --> Utf8 Class Initialized
INFO - 2017-02-03 18:59:37 --> URI Class Initialized
INFO - 2017-02-03 18:59:37 --> Router Class Initialized
INFO - 2017-02-03 18:59:37 --> Output Class Initialized
INFO - 2017-02-03 18:59:37 --> Security Class Initialized
DEBUG - 2017-02-03 18:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:59:38 --> Input Class Initialized
INFO - 2017-02-03 18:59:38 --> Language Class Initialized
INFO - 2017-02-03 18:59:38 --> Loader Class Initialized
INFO - 2017-02-03 18:59:38 --> Database Driver Class Initialized
INFO - 2017-02-03 18:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:59:38 --> Controller Class Initialized
INFO - 2017-02-03 18:59:38 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:59:38 --> Final output sent to browser
DEBUG - 2017-02-03 18:59:38 --> Total execution time: 0.0147
INFO - 2017-02-03 18:59:56 --> Config Class Initialized
INFO - 2017-02-03 18:59:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:59:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:59:56 --> Utf8 Class Initialized
INFO - 2017-02-03 18:59:56 --> URI Class Initialized
DEBUG - 2017-02-03 18:59:56 --> No URI present. Default controller set.
INFO - 2017-02-03 18:59:56 --> Router Class Initialized
INFO - 2017-02-03 18:59:56 --> Output Class Initialized
INFO - 2017-02-03 18:59:56 --> Security Class Initialized
DEBUG - 2017-02-03 18:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:59:56 --> Input Class Initialized
INFO - 2017-02-03 18:59:56 --> Language Class Initialized
INFO - 2017-02-03 18:59:56 --> Loader Class Initialized
INFO - 2017-02-03 18:59:56 --> Database Driver Class Initialized
INFO - 2017-02-03 18:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:59:56 --> Controller Class Initialized
INFO - 2017-02-03 18:59:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:59:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:59:56 --> Final output sent to browser
DEBUG - 2017-02-03 18:59:56 --> Total execution time: 0.0636
INFO - 2017-02-03 18:59:57 --> Config Class Initialized
INFO - 2017-02-03 18:59:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 18:59:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 18:59:57 --> Utf8 Class Initialized
INFO - 2017-02-03 18:59:57 --> URI Class Initialized
INFO - 2017-02-03 18:59:57 --> Router Class Initialized
INFO - 2017-02-03 18:59:57 --> Output Class Initialized
INFO - 2017-02-03 18:59:57 --> Security Class Initialized
DEBUG - 2017-02-03 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 18:59:57 --> Input Class Initialized
INFO - 2017-02-03 18:59:57 --> Language Class Initialized
INFO - 2017-02-03 18:59:57 --> Loader Class Initialized
INFO - 2017-02-03 18:59:57 --> Database Driver Class Initialized
INFO - 2017-02-03 18:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 18:59:57 --> Controller Class Initialized
INFO - 2017-02-03 18:59:57 --> Helper loaded: url_helper
DEBUG - 2017-02-03 18:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 18:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 18:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 18:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 18:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 18:59:57 --> Final output sent to browser
DEBUG - 2017-02-03 18:59:57 --> Total execution time: 0.0141
INFO - 2017-02-03 19:00:47 --> Config Class Initialized
INFO - 2017-02-03 19:00:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:00:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:00:47 --> Utf8 Class Initialized
INFO - 2017-02-03 19:00:47 --> URI Class Initialized
INFO - 2017-02-03 19:00:47 --> Router Class Initialized
INFO - 2017-02-03 19:00:47 --> Output Class Initialized
INFO - 2017-02-03 19:00:47 --> Security Class Initialized
DEBUG - 2017-02-03 19:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:00:47 --> Input Class Initialized
INFO - 2017-02-03 19:00:47 --> Language Class Initialized
INFO - 2017-02-03 19:00:47 --> Loader Class Initialized
INFO - 2017-02-03 19:00:47 --> Database Driver Class Initialized
INFO - 2017-02-03 19:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:00:47 --> Controller Class Initialized
INFO - 2017-02-03 19:00:47 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:00:47 --> Final output sent to browser
DEBUG - 2017-02-03 19:00:47 --> Total execution time: 0.0220
INFO - 2017-02-03 19:00:49 --> Config Class Initialized
INFO - 2017-02-03 19:00:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:00:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:00:49 --> Utf8 Class Initialized
INFO - 2017-02-03 19:00:49 --> URI Class Initialized
INFO - 2017-02-03 19:00:49 --> Router Class Initialized
INFO - 2017-02-03 19:00:49 --> Output Class Initialized
INFO - 2017-02-03 19:00:49 --> Security Class Initialized
DEBUG - 2017-02-03 19:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:00:49 --> Input Class Initialized
INFO - 2017-02-03 19:00:49 --> Language Class Initialized
INFO - 2017-02-03 19:00:49 --> Loader Class Initialized
INFO - 2017-02-03 19:00:49 --> Database Driver Class Initialized
INFO - 2017-02-03 19:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:00:49 --> Controller Class Initialized
INFO - 2017-02-03 19:00:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:00:49 --> Final output sent to browser
DEBUG - 2017-02-03 19:00:49 --> Total execution time: 0.0139
INFO - 2017-02-03 19:01:06 --> Config Class Initialized
INFO - 2017-02-03 19:01:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:01:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:01:06 --> Utf8 Class Initialized
INFO - 2017-02-03 19:01:06 --> URI Class Initialized
INFO - 2017-02-03 19:01:06 --> Router Class Initialized
INFO - 2017-02-03 19:01:06 --> Output Class Initialized
INFO - 2017-02-03 19:01:06 --> Security Class Initialized
DEBUG - 2017-02-03 19:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:01:06 --> Input Class Initialized
INFO - 2017-02-03 19:01:06 --> Language Class Initialized
INFO - 2017-02-03 19:01:06 --> Loader Class Initialized
INFO - 2017-02-03 19:01:06 --> Database Driver Class Initialized
INFO - 2017-02-03 19:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:01:06 --> Controller Class Initialized
INFO - 2017-02-03 19:01:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:01:06 --> Final output sent to browser
DEBUG - 2017-02-03 19:01:06 --> Total execution time: 0.0144
INFO - 2017-02-03 19:01:08 --> Config Class Initialized
INFO - 2017-02-03 19:01:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:01:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:01:08 --> Utf8 Class Initialized
INFO - 2017-02-03 19:01:08 --> URI Class Initialized
INFO - 2017-02-03 19:01:08 --> Router Class Initialized
INFO - 2017-02-03 19:01:08 --> Output Class Initialized
INFO - 2017-02-03 19:01:08 --> Security Class Initialized
DEBUG - 2017-02-03 19:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:01:08 --> Input Class Initialized
INFO - 2017-02-03 19:01:08 --> Language Class Initialized
INFO - 2017-02-03 19:01:08 --> Loader Class Initialized
INFO - 2017-02-03 19:01:08 --> Database Driver Class Initialized
INFO - 2017-02-03 19:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:01:08 --> Controller Class Initialized
INFO - 2017-02-03 19:01:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:01:08 --> Final output sent to browser
DEBUG - 2017-02-03 19:01:08 --> Total execution time: 0.0136
INFO - 2017-02-03 19:01:35 --> Config Class Initialized
INFO - 2017-02-03 19:01:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:01:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:01:35 --> Utf8 Class Initialized
INFO - 2017-02-03 19:01:35 --> URI Class Initialized
INFO - 2017-02-03 19:01:35 --> Router Class Initialized
INFO - 2017-02-03 19:01:35 --> Output Class Initialized
INFO - 2017-02-03 19:01:35 --> Security Class Initialized
DEBUG - 2017-02-03 19:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:01:35 --> Input Class Initialized
INFO - 2017-02-03 19:01:35 --> Language Class Initialized
INFO - 2017-02-03 19:01:35 --> Loader Class Initialized
INFO - 2017-02-03 19:01:35 --> Database Driver Class Initialized
INFO - 2017-02-03 19:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:01:35 --> Controller Class Initialized
INFO - 2017-02-03 19:01:35 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:01:35 --> Final output sent to browser
DEBUG - 2017-02-03 19:01:35 --> Total execution time: 0.0144
INFO - 2017-02-03 19:01:36 --> Config Class Initialized
INFO - 2017-02-03 19:01:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:01:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:01:36 --> Utf8 Class Initialized
INFO - 2017-02-03 19:01:36 --> URI Class Initialized
INFO - 2017-02-03 19:01:36 --> Router Class Initialized
INFO - 2017-02-03 19:01:36 --> Output Class Initialized
INFO - 2017-02-03 19:01:36 --> Security Class Initialized
DEBUG - 2017-02-03 19:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:01:36 --> Input Class Initialized
INFO - 2017-02-03 19:01:36 --> Language Class Initialized
INFO - 2017-02-03 19:01:36 --> Loader Class Initialized
INFO - 2017-02-03 19:01:36 --> Database Driver Class Initialized
INFO - 2017-02-03 19:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:01:36 --> Controller Class Initialized
INFO - 2017-02-03 19:01:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:01:36 --> Final output sent to browser
DEBUG - 2017-02-03 19:01:36 --> Total execution time: 0.0137
INFO - 2017-02-03 19:01:54 --> Config Class Initialized
INFO - 2017-02-03 19:01:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:01:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:01:54 --> Utf8 Class Initialized
INFO - 2017-02-03 19:01:54 --> URI Class Initialized
INFO - 2017-02-03 19:01:54 --> Router Class Initialized
INFO - 2017-02-03 19:01:54 --> Output Class Initialized
INFO - 2017-02-03 19:01:54 --> Security Class Initialized
DEBUG - 2017-02-03 19:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:01:54 --> Input Class Initialized
INFO - 2017-02-03 19:01:54 --> Language Class Initialized
INFO - 2017-02-03 19:01:54 --> Loader Class Initialized
INFO - 2017-02-03 19:01:54 --> Database Driver Class Initialized
INFO - 2017-02-03 19:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:01:54 --> Controller Class Initialized
INFO - 2017-02-03 19:01:54 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:01:55 --> Config Class Initialized
INFO - 2017-02-03 19:01:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:01:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:01:55 --> Utf8 Class Initialized
INFO - 2017-02-03 19:01:55 --> URI Class Initialized
INFO - 2017-02-03 19:01:55 --> Router Class Initialized
INFO - 2017-02-03 19:01:55 --> Output Class Initialized
INFO - 2017-02-03 19:01:55 --> Security Class Initialized
DEBUG - 2017-02-03 19:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:01:55 --> Input Class Initialized
INFO - 2017-02-03 19:01:55 --> Language Class Initialized
INFO - 2017-02-03 19:01:55 --> Loader Class Initialized
INFO - 2017-02-03 19:01:55 --> Database Driver Class Initialized
INFO - 2017-02-03 19:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:01:55 --> Controller Class Initialized
INFO - 2017-02-03 19:01:55 --> Helper loaded: date_helper
DEBUG - 2017-02-03 19:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:01:55 --> Helper loaded: url_helper
INFO - 2017-02-03 19:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 19:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 19:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 19:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:01:55 --> Final output sent to browser
DEBUG - 2017-02-03 19:01:55 --> Total execution time: 0.0142
INFO - 2017-02-03 19:01:56 --> Config Class Initialized
INFO - 2017-02-03 19:01:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:01:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:01:56 --> Utf8 Class Initialized
INFO - 2017-02-03 19:01:56 --> URI Class Initialized
INFO - 2017-02-03 19:01:56 --> Router Class Initialized
INFO - 2017-02-03 19:01:56 --> Output Class Initialized
INFO - 2017-02-03 19:01:56 --> Security Class Initialized
DEBUG - 2017-02-03 19:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:01:56 --> Input Class Initialized
INFO - 2017-02-03 19:01:56 --> Language Class Initialized
INFO - 2017-02-03 19:01:56 --> Loader Class Initialized
INFO - 2017-02-03 19:01:56 --> Database Driver Class Initialized
INFO - 2017-02-03 19:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:01:56 --> Controller Class Initialized
INFO - 2017-02-03 19:01:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:01:56 --> Final output sent to browser
DEBUG - 2017-02-03 19:01:56 --> Total execution time: 0.0140
INFO - 2017-02-03 19:02:01 --> Config Class Initialized
INFO - 2017-02-03 19:02:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:02:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:02:01 --> Utf8 Class Initialized
INFO - 2017-02-03 19:02:01 --> URI Class Initialized
DEBUG - 2017-02-03 19:02:01 --> No URI present. Default controller set.
INFO - 2017-02-03 19:02:01 --> Router Class Initialized
INFO - 2017-02-03 19:02:01 --> Output Class Initialized
INFO - 2017-02-03 19:02:01 --> Security Class Initialized
DEBUG - 2017-02-03 19:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:02:01 --> Input Class Initialized
INFO - 2017-02-03 19:02:01 --> Language Class Initialized
INFO - 2017-02-03 19:02:01 --> Loader Class Initialized
INFO - 2017-02-03 19:02:01 --> Database Driver Class Initialized
INFO - 2017-02-03 19:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:02:01 --> Controller Class Initialized
INFO - 2017-02-03 19:02:01 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:02:01 --> Final output sent to browser
DEBUG - 2017-02-03 19:02:01 --> Total execution time: 0.0146
INFO - 2017-02-03 19:02:51 --> Config Class Initialized
INFO - 2017-02-03 19:02:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:02:51 --> Utf8 Class Initialized
INFO - 2017-02-03 19:02:51 --> URI Class Initialized
DEBUG - 2017-02-03 19:02:51 --> No URI present. Default controller set.
INFO - 2017-02-03 19:02:51 --> Router Class Initialized
INFO - 2017-02-03 19:02:51 --> Output Class Initialized
INFO - 2017-02-03 19:02:51 --> Security Class Initialized
DEBUG - 2017-02-03 19:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:02:51 --> Input Class Initialized
INFO - 2017-02-03 19:02:51 --> Language Class Initialized
INFO - 2017-02-03 19:02:51 --> Loader Class Initialized
INFO - 2017-02-03 19:02:51 --> Database Driver Class Initialized
INFO - 2017-02-03 19:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:02:51 --> Controller Class Initialized
INFO - 2017-02-03 19:02:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:02:51 --> Final output sent to browser
DEBUG - 2017-02-03 19:02:51 --> Total execution time: 0.0131
INFO - 2017-02-03 19:02:58 --> Config Class Initialized
INFO - 2017-02-03 19:02:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:02:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:02:58 --> Utf8 Class Initialized
INFO - 2017-02-03 19:02:58 --> URI Class Initialized
INFO - 2017-02-03 19:02:58 --> Router Class Initialized
INFO - 2017-02-03 19:02:58 --> Output Class Initialized
INFO - 2017-02-03 19:02:58 --> Security Class Initialized
DEBUG - 2017-02-03 19:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:02:58 --> Input Class Initialized
INFO - 2017-02-03 19:02:58 --> Language Class Initialized
INFO - 2017-02-03 19:02:58 --> Loader Class Initialized
INFO - 2017-02-03 19:02:58 --> Database Driver Class Initialized
INFO - 2017-02-03 19:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:02:58 --> Controller Class Initialized
INFO - 2017-02-03 19:02:58 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:02:58 --> Final output sent to browser
DEBUG - 2017-02-03 19:02:58 --> Total execution time: 0.0137
INFO - 2017-02-03 19:03:58 --> Config Class Initialized
INFO - 2017-02-03 19:03:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:03:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:03:58 --> Utf8 Class Initialized
INFO - 2017-02-03 19:03:58 --> URI Class Initialized
DEBUG - 2017-02-03 19:03:58 --> No URI present. Default controller set.
INFO - 2017-02-03 19:03:58 --> Router Class Initialized
INFO - 2017-02-03 19:03:58 --> Output Class Initialized
INFO - 2017-02-03 19:03:58 --> Security Class Initialized
DEBUG - 2017-02-03 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:03:58 --> Input Class Initialized
INFO - 2017-02-03 19:03:58 --> Language Class Initialized
INFO - 2017-02-03 19:03:58 --> Loader Class Initialized
INFO - 2017-02-03 19:03:58 --> Database Driver Class Initialized
INFO - 2017-02-03 19:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:03:58 --> Controller Class Initialized
INFO - 2017-02-03 19:03:58 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:03:58 --> Final output sent to browser
DEBUG - 2017-02-03 19:03:58 --> Total execution time: 0.0154
INFO - 2017-02-03 19:04:29 --> Config Class Initialized
INFO - 2017-02-03 19:04:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:29 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:29 --> URI Class Initialized
DEBUG - 2017-02-03 19:04:29 --> No URI present. Default controller set.
INFO - 2017-02-03 19:04:29 --> Router Class Initialized
INFO - 2017-02-03 19:04:29 --> Output Class Initialized
INFO - 2017-02-03 19:04:29 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:29 --> Input Class Initialized
INFO - 2017-02-03 19:04:29 --> Language Class Initialized
INFO - 2017-02-03 19:04:29 --> Loader Class Initialized
INFO - 2017-02-03 19:04:29 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:29 --> Controller Class Initialized
INFO - 2017-02-03 19:04:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:04:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:04:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:04:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:04:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:04:29 --> Final output sent to browser
DEBUG - 2017-02-03 19:04:29 --> Total execution time: 0.0132
INFO - 2017-02-03 19:04:35 --> Config Class Initialized
INFO - 2017-02-03 19:04:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:35 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:35 --> URI Class Initialized
INFO - 2017-02-03 19:04:35 --> Router Class Initialized
INFO - 2017-02-03 19:04:35 --> Output Class Initialized
INFO - 2017-02-03 19:04:35 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:35 --> Input Class Initialized
INFO - 2017-02-03 19:04:35 --> Language Class Initialized
INFO - 2017-02-03 19:04:35 --> Loader Class Initialized
INFO - 2017-02-03 19:04:35 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:35 --> Controller Class Initialized
INFO - 2017-02-03 19:04:35 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-03 19:04:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-03 19:04:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-03 19:04:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-03 19:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:04:35 --> Final output sent to browser
DEBUG - 2017-02-03 19:04:35 --> Total execution time: 0.0146
INFO - 2017-02-03 19:04:36 --> Config Class Initialized
INFO - 2017-02-03 19:04:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:36 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:36 --> URI Class Initialized
INFO - 2017-02-03 19:04:36 --> Router Class Initialized
INFO - 2017-02-03 19:04:36 --> Output Class Initialized
INFO - 2017-02-03 19:04:36 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:36 --> Input Class Initialized
INFO - 2017-02-03 19:04:36 --> Language Class Initialized
INFO - 2017-02-03 19:04:36 --> Loader Class Initialized
INFO - 2017-02-03 19:04:36 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:36 --> Controller Class Initialized
INFO - 2017-02-03 19:04:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:04:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:04:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:04:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:04:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:04:36 --> Final output sent to browser
DEBUG - 2017-02-03 19:04:36 --> Total execution time: 0.0135
INFO - 2017-02-03 19:04:44 --> Config Class Initialized
INFO - 2017-02-03 19:04:44 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:44 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:44 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:44 --> URI Class Initialized
INFO - 2017-02-03 19:04:44 --> Router Class Initialized
INFO - 2017-02-03 19:04:44 --> Output Class Initialized
INFO - 2017-02-03 19:04:44 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:44 --> Input Class Initialized
INFO - 2017-02-03 19:04:44 --> Language Class Initialized
INFO - 2017-02-03 19:04:44 --> Loader Class Initialized
INFO - 2017-02-03 19:04:44 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:44 --> Controller Class Initialized
INFO - 2017-02-03 19:04:44 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:04:45 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:04:45 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jessica Erzebeth Mendozza')
INFO - 2017-02-03 19:04:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:04:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:04:46 --> Config Class Initialized
INFO - 2017-02-03 19:04:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:46 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:46 --> URI Class Initialized
INFO - 2017-02-03 19:04:46 --> Router Class Initialized
INFO - 2017-02-03 19:04:46 --> Output Class Initialized
INFO - 2017-02-03 19:04:46 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:46 --> Input Class Initialized
INFO - 2017-02-03 19:04:46 --> Language Class Initialized
INFO - 2017-02-03 19:04:46 --> Loader Class Initialized
INFO - 2017-02-03 19:04:46 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:46 --> Controller Class Initialized
INFO - 2017-02-03 19:04:46 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:04:46 --> Final output sent to browser
DEBUG - 2017-02-03 19:04:46 --> Total execution time: 0.0698
INFO - 2017-02-03 19:04:49 --> Config Class Initialized
INFO - 2017-02-03 19:04:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:49 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:49 --> URI Class Initialized
INFO - 2017-02-03 19:04:49 --> Router Class Initialized
INFO - 2017-02-03 19:04:49 --> Output Class Initialized
INFO - 2017-02-03 19:04:49 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:49 --> Input Class Initialized
INFO - 2017-02-03 19:04:49 --> Language Class Initialized
INFO - 2017-02-03 19:04:49 --> Loader Class Initialized
INFO - 2017-02-03 19:04:49 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:49 --> Controller Class Initialized
INFO - 2017-02-03 19:04:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:04:49 --> Config Class Initialized
INFO - 2017-02-03 19:04:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:49 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:49 --> URI Class Initialized
INFO - 2017-02-03 19:04:49 --> Router Class Initialized
INFO - 2017-02-03 19:04:49 --> Output Class Initialized
INFO - 2017-02-03 19:04:49 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:49 --> Input Class Initialized
INFO - 2017-02-03 19:04:49 --> Language Class Initialized
INFO - 2017-02-03 19:04:49 --> Loader Class Initialized
INFO - 2017-02-03 19:04:49 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:49 --> Controller Class Initialized
INFO - 2017-02-03 19:04:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:04:50 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:04:50 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jessica Erzebeth Mendozza')
INFO - 2017-02-03 19:04:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:04:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:04:50 --> Config Class Initialized
INFO - 2017-02-03 19:04:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:50 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:50 --> URI Class Initialized
INFO - 2017-02-03 19:04:50 --> Router Class Initialized
INFO - 2017-02-03 19:04:50 --> Output Class Initialized
INFO - 2017-02-03 19:04:50 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:50 --> Input Class Initialized
INFO - 2017-02-03 19:04:50 --> Language Class Initialized
INFO - 2017-02-03 19:04:50 --> Loader Class Initialized
INFO - 2017-02-03 19:04:50 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:50 --> Controller Class Initialized
INFO - 2017-02-03 19:04:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:04:50 --> Final output sent to browser
DEBUG - 2017-02-03 19:04:50 --> Total execution time: 0.0136
INFO - 2017-02-03 19:04:50 --> Config Class Initialized
INFO - 2017-02-03 19:04:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:04:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:04:50 --> Utf8 Class Initialized
INFO - 2017-02-03 19:04:50 --> URI Class Initialized
INFO - 2017-02-03 19:04:50 --> Router Class Initialized
INFO - 2017-02-03 19:04:50 --> Output Class Initialized
INFO - 2017-02-03 19:04:50 --> Security Class Initialized
DEBUG - 2017-02-03 19:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:04:50 --> Input Class Initialized
INFO - 2017-02-03 19:04:50 --> Language Class Initialized
INFO - 2017-02-03 19:04:50 --> Loader Class Initialized
INFO - 2017-02-03 19:04:50 --> Database Driver Class Initialized
INFO - 2017-02-03 19:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:04:50 --> Controller Class Initialized
INFO - 2017-02-03 19:04:50 --> Helper loaded: date_helper
DEBUG - 2017-02-03 19:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:04:50 --> Helper loaded: url_helper
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 19:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:04:50 --> Final output sent to browser
DEBUG - 2017-02-03 19:04:50 --> Total execution time: 0.0149
INFO - 2017-02-03 19:05:16 --> Config Class Initialized
INFO - 2017-02-03 19:05:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:16 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:16 --> URI Class Initialized
INFO - 2017-02-03 19:05:16 --> Router Class Initialized
INFO - 2017-02-03 19:05:16 --> Output Class Initialized
INFO - 2017-02-03 19:05:16 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:16 --> Input Class Initialized
INFO - 2017-02-03 19:05:16 --> Language Class Initialized
INFO - 2017-02-03 19:05:16 --> Loader Class Initialized
INFO - 2017-02-03 19:05:16 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:16 --> Controller Class Initialized
INFO - 2017-02-03 19:05:16 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:05:16 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:05:16 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jessica Erzebeth Mendozza')
INFO - 2017-02-03 19:05:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:05:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:05:16 --> Config Class Initialized
INFO - 2017-02-03 19:05:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:16 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:16 --> URI Class Initialized
INFO - 2017-02-03 19:05:16 --> Router Class Initialized
INFO - 2017-02-03 19:05:16 --> Output Class Initialized
INFO - 2017-02-03 19:05:16 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:16 --> Input Class Initialized
INFO - 2017-02-03 19:05:16 --> Language Class Initialized
INFO - 2017-02-03 19:05:16 --> Loader Class Initialized
INFO - 2017-02-03 19:05:16 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:16 --> Controller Class Initialized
INFO - 2017-02-03 19:05:16 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:16 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:16 --> Total execution time: 0.0137
INFO - 2017-02-03 19:05:17 --> Config Class Initialized
INFO - 2017-02-03 19:05:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:17 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:17 --> URI Class Initialized
DEBUG - 2017-02-03 19:05:17 --> No URI present. Default controller set.
INFO - 2017-02-03 19:05:17 --> Router Class Initialized
INFO - 2017-02-03 19:05:17 --> Output Class Initialized
INFO - 2017-02-03 19:05:17 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:17 --> Input Class Initialized
INFO - 2017-02-03 19:05:17 --> Language Class Initialized
INFO - 2017-02-03 19:05:17 --> Loader Class Initialized
INFO - 2017-02-03 19:05:17 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:17 --> Controller Class Initialized
INFO - 2017-02-03 19:05:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:17 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:17 --> Total execution time: 0.0133
INFO - 2017-02-03 19:05:18 --> Config Class Initialized
INFO - 2017-02-03 19:05:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:18 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:18 --> URI Class Initialized
INFO - 2017-02-03 19:05:18 --> Router Class Initialized
INFO - 2017-02-03 19:05:18 --> Output Class Initialized
INFO - 2017-02-03 19:05:18 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:18 --> Input Class Initialized
INFO - 2017-02-03 19:05:18 --> Language Class Initialized
INFO - 2017-02-03 19:05:18 --> Loader Class Initialized
INFO - 2017-02-03 19:05:18 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:18 --> Controller Class Initialized
INFO - 2017-02-03 19:05:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:18 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:18 --> Total execution time: 0.0144
INFO - 2017-02-03 19:05:35 --> Config Class Initialized
INFO - 2017-02-03 19:05:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:35 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:35 --> URI Class Initialized
INFO - 2017-02-03 19:05:35 --> Router Class Initialized
INFO - 2017-02-03 19:05:35 --> Output Class Initialized
INFO - 2017-02-03 19:05:35 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:35 --> Input Class Initialized
INFO - 2017-02-03 19:05:35 --> Language Class Initialized
INFO - 2017-02-03 19:05:35 --> Loader Class Initialized
INFO - 2017-02-03 19:05:35 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:35 --> Controller Class Initialized
INFO - 2017-02-03 19:05:35 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:35 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:35 --> Total execution time: 0.0152
INFO - 2017-02-03 19:05:36 --> Config Class Initialized
INFO - 2017-02-03 19:05:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:36 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:36 --> URI Class Initialized
INFO - 2017-02-03 19:05:36 --> Router Class Initialized
INFO - 2017-02-03 19:05:36 --> Output Class Initialized
INFO - 2017-02-03 19:05:36 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:36 --> Input Class Initialized
INFO - 2017-02-03 19:05:36 --> Language Class Initialized
INFO - 2017-02-03 19:05:36 --> Loader Class Initialized
INFO - 2017-02-03 19:05:36 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:36 --> Controller Class Initialized
INFO - 2017-02-03 19:05:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:36 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:36 --> Total execution time: 0.0131
INFO - 2017-02-03 19:05:43 --> Config Class Initialized
INFO - 2017-02-03 19:05:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:43 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:43 --> URI Class Initialized
INFO - 2017-02-03 19:05:43 --> Router Class Initialized
INFO - 2017-02-03 19:05:43 --> Output Class Initialized
INFO - 2017-02-03 19:05:43 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:43 --> Input Class Initialized
INFO - 2017-02-03 19:05:43 --> Language Class Initialized
INFO - 2017-02-03 19:05:43 --> Loader Class Initialized
INFO - 2017-02-03 19:05:43 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:43 --> Controller Class Initialized
INFO - 2017-02-03 19:05:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:05:44 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:05:44 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jessica Erzebeth Mendozza')
INFO - 2017-02-03 19:05:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:05:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:05:44 --> Config Class Initialized
INFO - 2017-02-03 19:05:44 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:44 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:44 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:44 --> URI Class Initialized
INFO - 2017-02-03 19:05:44 --> Router Class Initialized
INFO - 2017-02-03 19:05:44 --> Output Class Initialized
INFO - 2017-02-03 19:05:44 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:44 --> Input Class Initialized
INFO - 2017-02-03 19:05:44 --> Language Class Initialized
INFO - 2017-02-03 19:05:44 --> Loader Class Initialized
INFO - 2017-02-03 19:05:44 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:44 --> Controller Class Initialized
INFO - 2017-02-03 19:05:44 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:44 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:44 --> Total execution time: 0.0148
INFO - 2017-02-03 19:05:48 --> Config Class Initialized
INFO - 2017-02-03 19:05:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:48 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:48 --> URI Class Initialized
DEBUG - 2017-02-03 19:05:48 --> No URI present. Default controller set.
INFO - 2017-02-03 19:05:48 --> Router Class Initialized
INFO - 2017-02-03 19:05:48 --> Output Class Initialized
INFO - 2017-02-03 19:05:48 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:48 --> Input Class Initialized
INFO - 2017-02-03 19:05:48 --> Language Class Initialized
INFO - 2017-02-03 19:05:48 --> Loader Class Initialized
INFO - 2017-02-03 19:05:48 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:48 --> Controller Class Initialized
INFO - 2017-02-03 19:05:48 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:48 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:48 --> Total execution time: 0.0142
INFO - 2017-02-03 19:05:49 --> Config Class Initialized
INFO - 2017-02-03 19:05:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:49 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:49 --> URI Class Initialized
INFO - 2017-02-03 19:05:49 --> Router Class Initialized
INFO - 2017-02-03 19:05:49 --> Output Class Initialized
INFO - 2017-02-03 19:05:49 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:49 --> Input Class Initialized
INFO - 2017-02-03 19:05:49 --> Language Class Initialized
INFO - 2017-02-03 19:05:49 --> Loader Class Initialized
INFO - 2017-02-03 19:05:49 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:49 --> Controller Class Initialized
INFO - 2017-02-03 19:05:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:49 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:49 --> Total execution time: 0.0138
INFO - 2017-02-03 19:05:55 --> Config Class Initialized
INFO - 2017-02-03 19:05:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:55 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:55 --> URI Class Initialized
INFO - 2017-02-03 19:05:55 --> Router Class Initialized
INFO - 2017-02-03 19:05:55 --> Output Class Initialized
INFO - 2017-02-03 19:05:55 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:55 --> Input Class Initialized
INFO - 2017-02-03 19:05:55 --> Language Class Initialized
INFO - 2017-02-03 19:05:55 --> Loader Class Initialized
INFO - 2017-02-03 19:05:55 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:55 --> Controller Class Initialized
INFO - 2017-02-03 19:05:55 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:05:55 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:05:55 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jessica Erzebeth Mendozza')
INFO - 2017-02-03 19:05:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:05:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:05:55 --> Config Class Initialized
INFO - 2017-02-03 19:05:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:05:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:05:55 --> Utf8 Class Initialized
INFO - 2017-02-03 19:05:55 --> URI Class Initialized
INFO - 2017-02-03 19:05:55 --> Router Class Initialized
INFO - 2017-02-03 19:05:55 --> Output Class Initialized
INFO - 2017-02-03 19:05:55 --> Security Class Initialized
DEBUG - 2017-02-03 19:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:05:55 --> Input Class Initialized
INFO - 2017-02-03 19:05:55 --> Language Class Initialized
INFO - 2017-02-03 19:05:55 --> Loader Class Initialized
INFO - 2017-02-03 19:05:55 --> Database Driver Class Initialized
INFO - 2017-02-03 19:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:05:55 --> Controller Class Initialized
INFO - 2017-02-03 19:05:55 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:05:55 --> Final output sent to browser
DEBUG - 2017-02-03 19:05:55 --> Total execution time: 0.0167
INFO - 2017-02-03 19:06:02 --> Config Class Initialized
INFO - 2017-02-03 19:06:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:06:02 --> Utf8 Class Initialized
INFO - 2017-02-03 19:06:02 --> URI Class Initialized
DEBUG - 2017-02-03 19:06:02 --> No URI present. Default controller set.
INFO - 2017-02-03 19:06:02 --> Router Class Initialized
INFO - 2017-02-03 19:06:02 --> Output Class Initialized
INFO - 2017-02-03 19:06:02 --> Security Class Initialized
DEBUG - 2017-02-03 19:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:06:02 --> Input Class Initialized
INFO - 2017-02-03 19:06:02 --> Language Class Initialized
INFO - 2017-02-03 19:06:02 --> Loader Class Initialized
INFO - 2017-02-03 19:06:02 --> Database Driver Class Initialized
INFO - 2017-02-03 19:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:06:02 --> Controller Class Initialized
INFO - 2017-02-03 19:06:02 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:06:02 --> Final output sent to browser
DEBUG - 2017-02-03 19:06:02 --> Total execution time: 0.0131
INFO - 2017-02-03 19:06:03 --> Config Class Initialized
INFO - 2017-02-03 19:06:03 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:06:03 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:06:03 --> Utf8 Class Initialized
INFO - 2017-02-03 19:06:03 --> URI Class Initialized
INFO - 2017-02-03 19:06:03 --> Router Class Initialized
INFO - 2017-02-03 19:06:03 --> Output Class Initialized
INFO - 2017-02-03 19:06:03 --> Security Class Initialized
DEBUG - 2017-02-03 19:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:06:03 --> Input Class Initialized
INFO - 2017-02-03 19:06:03 --> Language Class Initialized
INFO - 2017-02-03 19:06:03 --> Loader Class Initialized
INFO - 2017-02-03 19:06:03 --> Database Driver Class Initialized
INFO - 2017-02-03 19:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:06:03 --> Controller Class Initialized
INFO - 2017-02-03 19:06:03 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:06:03 --> Final output sent to browser
DEBUG - 2017-02-03 19:06:03 --> Total execution time: 0.0137
INFO - 2017-02-03 19:06:05 --> Config Class Initialized
INFO - 2017-02-03 19:06:05 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:06:05 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:06:05 --> Utf8 Class Initialized
INFO - 2017-02-03 19:06:05 --> URI Class Initialized
INFO - 2017-02-03 19:06:05 --> Router Class Initialized
INFO - 2017-02-03 19:06:05 --> Output Class Initialized
INFO - 2017-02-03 19:06:05 --> Security Class Initialized
DEBUG - 2017-02-03 19:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:06:05 --> Input Class Initialized
INFO - 2017-02-03 19:06:05 --> Language Class Initialized
INFO - 2017-02-03 19:06:05 --> Loader Class Initialized
INFO - 2017-02-03 19:06:05 --> Database Driver Class Initialized
INFO - 2017-02-03 19:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:06:05 --> Controller Class Initialized
INFO - 2017-02-03 19:06:05 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:06:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:06:06 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:06:06 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jessica Erzebeth Mendozza')
INFO - 2017-02-03 19:06:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:06:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:06:06 --> Config Class Initialized
INFO - 2017-02-03 19:06:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:06:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:06:06 --> Utf8 Class Initialized
INFO - 2017-02-03 19:06:06 --> URI Class Initialized
INFO - 2017-02-03 19:06:06 --> Router Class Initialized
INFO - 2017-02-03 19:06:06 --> Output Class Initialized
INFO - 2017-02-03 19:06:06 --> Security Class Initialized
DEBUG - 2017-02-03 19:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:06:06 --> Input Class Initialized
INFO - 2017-02-03 19:06:06 --> Language Class Initialized
INFO - 2017-02-03 19:06:06 --> Loader Class Initialized
INFO - 2017-02-03 19:06:06 --> Database Driver Class Initialized
INFO - 2017-02-03 19:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:06:06 --> Controller Class Initialized
INFO - 2017-02-03 19:06:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:06:06 --> Final output sent to browser
DEBUG - 2017-02-03 19:06:06 --> Total execution time: 0.0134
INFO - 2017-02-03 19:06:28 --> Config Class Initialized
INFO - 2017-02-03 19:06:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:06:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:06:28 --> Utf8 Class Initialized
INFO - 2017-02-03 19:06:28 --> URI Class Initialized
INFO - 2017-02-03 19:06:28 --> Router Class Initialized
INFO - 2017-02-03 19:06:28 --> Output Class Initialized
INFO - 2017-02-03 19:06:28 --> Security Class Initialized
DEBUG - 2017-02-03 19:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:06:28 --> Input Class Initialized
INFO - 2017-02-03 19:06:28 --> Language Class Initialized
INFO - 2017-02-03 19:06:28 --> Loader Class Initialized
INFO - 2017-02-03 19:06:28 --> Database Driver Class Initialized
INFO - 2017-02-03 19:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:06:28 --> Controller Class Initialized
INFO - 2017-02-03 19:06:28 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:06:28 --> Final output sent to browser
DEBUG - 2017-02-03 19:06:28 --> Total execution time: 0.0140
INFO - 2017-02-03 19:11:13 --> Config Class Initialized
INFO - 2017-02-03 19:11:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:13 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:13 --> URI Class Initialized
DEBUG - 2017-02-03 19:11:13 --> No URI present. Default controller set.
INFO - 2017-02-03 19:11:13 --> Router Class Initialized
INFO - 2017-02-03 19:11:13 --> Output Class Initialized
INFO - 2017-02-03 19:11:13 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:13 --> Input Class Initialized
INFO - 2017-02-03 19:11:13 --> Language Class Initialized
INFO - 2017-02-03 19:11:13 --> Loader Class Initialized
INFO - 2017-02-03 19:11:13 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:13 --> Controller Class Initialized
INFO - 2017-02-03 19:11:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:13 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:13 --> Total execution time: 0.0139
INFO - 2017-02-03 19:11:16 --> Config Class Initialized
INFO - 2017-02-03 19:11:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:16 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:16 --> URI Class Initialized
DEBUG - 2017-02-03 19:11:16 --> No URI present. Default controller set.
INFO - 2017-02-03 19:11:16 --> Router Class Initialized
INFO - 2017-02-03 19:11:16 --> Output Class Initialized
INFO - 2017-02-03 19:11:16 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:16 --> Input Class Initialized
INFO - 2017-02-03 19:11:16 --> Language Class Initialized
INFO - 2017-02-03 19:11:16 --> Loader Class Initialized
INFO - 2017-02-03 19:11:16 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:16 --> Controller Class Initialized
INFO - 2017-02-03 19:11:16 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:16 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:16 --> Total execution time: 0.0131
INFO - 2017-02-03 19:11:18 --> Config Class Initialized
INFO - 2017-02-03 19:11:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:18 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:18 --> URI Class Initialized
INFO - 2017-02-03 19:11:18 --> Router Class Initialized
INFO - 2017-02-03 19:11:18 --> Output Class Initialized
INFO - 2017-02-03 19:11:18 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:18 --> Input Class Initialized
INFO - 2017-02-03 19:11:18 --> Language Class Initialized
INFO - 2017-02-03 19:11:18 --> Loader Class Initialized
INFO - 2017-02-03 19:11:18 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:18 --> Controller Class Initialized
INFO - 2017-02-03 19:11:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:18 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:18 --> Total execution time: 0.0136
INFO - 2017-02-03 19:11:20 --> Config Class Initialized
INFO - 2017-02-03 19:11:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:20 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:20 --> URI Class Initialized
INFO - 2017-02-03 19:11:20 --> Router Class Initialized
INFO - 2017-02-03 19:11:20 --> Output Class Initialized
INFO - 2017-02-03 19:11:20 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:20 --> Input Class Initialized
INFO - 2017-02-03 19:11:20 --> Language Class Initialized
INFO - 2017-02-03 19:11:20 --> Loader Class Initialized
INFO - 2017-02-03 19:11:20 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:20 --> Controller Class Initialized
INFO - 2017-02-03 19:11:20 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:11:20 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:11:20 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jessica Erzebeth Mendozza')
INFO - 2017-02-03 19:11:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:11:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:11:21 --> Config Class Initialized
INFO - 2017-02-03 19:11:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:21 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:21 --> URI Class Initialized
INFO - 2017-02-03 19:11:21 --> Router Class Initialized
INFO - 2017-02-03 19:11:21 --> Output Class Initialized
INFO - 2017-02-03 19:11:21 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:21 --> Input Class Initialized
INFO - 2017-02-03 19:11:21 --> Language Class Initialized
INFO - 2017-02-03 19:11:21 --> Loader Class Initialized
INFO - 2017-02-03 19:11:21 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:21 --> Controller Class Initialized
INFO - 2017-02-03 19:11:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:21 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:21 --> Total execution time: 0.0135
INFO - 2017-02-03 19:11:22 --> Config Class Initialized
INFO - 2017-02-03 19:11:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:22 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:22 --> URI Class Initialized
DEBUG - 2017-02-03 19:11:22 --> No URI present. Default controller set.
INFO - 2017-02-03 19:11:22 --> Router Class Initialized
INFO - 2017-02-03 19:11:22 --> Output Class Initialized
INFO - 2017-02-03 19:11:22 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:22 --> Input Class Initialized
INFO - 2017-02-03 19:11:22 --> Language Class Initialized
INFO - 2017-02-03 19:11:22 --> Loader Class Initialized
INFO - 2017-02-03 19:11:22 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:22 --> Controller Class Initialized
INFO - 2017-02-03 19:11:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:22 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:22 --> Total execution time: 0.0138
INFO - 2017-02-03 19:11:23 --> Config Class Initialized
INFO - 2017-02-03 19:11:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:23 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:23 --> URI Class Initialized
INFO - 2017-02-03 19:11:23 --> Router Class Initialized
INFO - 2017-02-03 19:11:23 --> Output Class Initialized
INFO - 2017-02-03 19:11:23 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:23 --> Input Class Initialized
INFO - 2017-02-03 19:11:23 --> Language Class Initialized
INFO - 2017-02-03 19:11:23 --> Loader Class Initialized
INFO - 2017-02-03 19:11:23 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:23 --> Controller Class Initialized
INFO - 2017-02-03 19:11:23 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:23 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:23 --> Total execution time: 0.0157
INFO - 2017-02-03 19:11:28 --> Config Class Initialized
INFO - 2017-02-03 19:11:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:28 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:28 --> URI Class Initialized
INFO - 2017-02-03 19:11:28 --> Router Class Initialized
INFO - 2017-02-03 19:11:28 --> Output Class Initialized
INFO - 2017-02-03 19:11:28 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:28 --> Input Class Initialized
INFO - 2017-02-03 19:11:28 --> Language Class Initialized
INFO - 2017-02-03 19:11:28 --> Loader Class Initialized
INFO - 2017-02-03 19:11:28 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:28 --> Controller Class Initialized
INFO - 2017-02-03 19:11:28 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:28 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:28 --> Total execution time: 0.0144
INFO - 2017-02-03 19:11:29 --> Config Class Initialized
INFO - 2017-02-03 19:11:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:29 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:29 --> URI Class Initialized
INFO - 2017-02-03 19:11:29 --> Router Class Initialized
INFO - 2017-02-03 19:11:29 --> Output Class Initialized
INFO - 2017-02-03 19:11:29 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:29 --> Input Class Initialized
INFO - 2017-02-03 19:11:29 --> Language Class Initialized
INFO - 2017-02-03 19:11:29 --> Loader Class Initialized
INFO - 2017-02-03 19:11:29 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:29 --> Controller Class Initialized
INFO - 2017-02-03 19:11:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:29 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:29 --> Total execution time: 0.0138
INFO - 2017-02-03 19:11:39 --> Config Class Initialized
INFO - 2017-02-03 19:11:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:39 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:39 --> URI Class Initialized
INFO - 2017-02-03 19:11:39 --> Router Class Initialized
INFO - 2017-02-03 19:11:39 --> Output Class Initialized
INFO - 2017-02-03 19:11:39 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:39 --> Input Class Initialized
INFO - 2017-02-03 19:11:39 --> Language Class Initialized
INFO - 2017-02-03 19:11:39 --> Loader Class Initialized
INFO - 2017-02-03 19:11:39 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:39 --> Controller Class Initialized
INFO - 2017-02-03 19:11:39 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:39 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:39 --> Total execution time: 0.0155
INFO - 2017-02-03 19:11:40 --> Config Class Initialized
INFO - 2017-02-03 19:11:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:40 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:40 --> URI Class Initialized
INFO - 2017-02-03 19:11:40 --> Router Class Initialized
INFO - 2017-02-03 19:11:40 --> Output Class Initialized
INFO - 2017-02-03 19:11:40 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:40 --> Input Class Initialized
INFO - 2017-02-03 19:11:40 --> Language Class Initialized
INFO - 2017-02-03 19:11:40 --> Loader Class Initialized
INFO - 2017-02-03 19:11:40 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:40 --> Controller Class Initialized
INFO - 2017-02-03 19:11:40 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:40 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:40 --> Total execution time: 0.0137
INFO - 2017-02-03 19:11:48 --> Config Class Initialized
INFO - 2017-02-03 19:11:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:48 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:48 --> URI Class Initialized
INFO - 2017-02-03 19:11:48 --> Router Class Initialized
INFO - 2017-02-03 19:11:48 --> Output Class Initialized
INFO - 2017-02-03 19:11:48 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:48 --> Input Class Initialized
INFO - 2017-02-03 19:11:48 --> Language Class Initialized
INFO - 2017-02-03 19:11:48 --> Loader Class Initialized
INFO - 2017-02-03 19:11:48 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:48 --> Controller Class Initialized
INFO - 2017-02-03 19:11:48 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:48 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:48 --> Total execution time: 0.0145
INFO - 2017-02-03 19:11:49 --> Config Class Initialized
INFO - 2017-02-03 19:11:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:11:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:11:49 --> Utf8 Class Initialized
INFO - 2017-02-03 19:11:49 --> URI Class Initialized
INFO - 2017-02-03 19:11:49 --> Router Class Initialized
INFO - 2017-02-03 19:11:49 --> Output Class Initialized
INFO - 2017-02-03 19:11:49 --> Security Class Initialized
DEBUG - 2017-02-03 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:11:49 --> Input Class Initialized
INFO - 2017-02-03 19:11:49 --> Language Class Initialized
INFO - 2017-02-03 19:11:49 --> Loader Class Initialized
INFO - 2017-02-03 19:11:49 --> Database Driver Class Initialized
INFO - 2017-02-03 19:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:11:49 --> Controller Class Initialized
INFO - 2017-02-03 19:11:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:11:49 --> Final output sent to browser
DEBUG - 2017-02-03 19:11:49 --> Total execution time: 0.0136
INFO - 2017-02-03 19:12:08 --> Config Class Initialized
INFO - 2017-02-03 19:12:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:08 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:08 --> URI Class Initialized
INFO - 2017-02-03 19:12:08 --> Router Class Initialized
INFO - 2017-02-03 19:12:08 --> Output Class Initialized
INFO - 2017-02-03 19:12:08 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:08 --> Input Class Initialized
INFO - 2017-02-03 19:12:08 --> Language Class Initialized
INFO - 2017-02-03 19:12:08 --> Loader Class Initialized
INFO - 2017-02-03 19:12:08 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:08 --> Controller Class Initialized
INFO - 2017-02-03 19:12:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:09 --> Config Class Initialized
INFO - 2017-02-03 19:12:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:09 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:09 --> URI Class Initialized
INFO - 2017-02-03 19:12:09 --> Router Class Initialized
INFO - 2017-02-03 19:12:09 --> Output Class Initialized
INFO - 2017-02-03 19:12:09 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:09 --> Input Class Initialized
INFO - 2017-02-03 19:12:09 --> Language Class Initialized
INFO - 2017-02-03 19:12:09 --> Loader Class Initialized
INFO - 2017-02-03 19:12:09 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:09 --> Controller Class Initialized
INFO - 2017-02-03 19:12:09 --> Helper loaded: date_helper
DEBUG - 2017-02-03 19:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:09 --> Helper loaded: url_helper
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:09 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:09 --> Total execution time: 0.0155
INFO - 2017-02-03 19:12:09 --> Config Class Initialized
INFO - 2017-02-03 19:12:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:09 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:09 --> URI Class Initialized
INFO - 2017-02-03 19:12:09 --> Router Class Initialized
INFO - 2017-02-03 19:12:09 --> Output Class Initialized
INFO - 2017-02-03 19:12:09 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:09 --> Input Class Initialized
INFO - 2017-02-03 19:12:09 --> Language Class Initialized
INFO - 2017-02-03 19:12:09 --> Loader Class Initialized
INFO - 2017-02-03 19:12:09 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:09 --> Controller Class Initialized
INFO - 2017-02-03 19:12:09 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:09 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:09 --> Total execution time: 0.0140
INFO - 2017-02-03 19:12:14 --> Config Class Initialized
INFO - 2017-02-03 19:12:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:14 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:14 --> URI Class Initialized
DEBUG - 2017-02-03 19:12:14 --> No URI present. Default controller set.
INFO - 2017-02-03 19:12:14 --> Router Class Initialized
INFO - 2017-02-03 19:12:14 --> Output Class Initialized
INFO - 2017-02-03 19:12:14 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:14 --> Input Class Initialized
INFO - 2017-02-03 19:12:14 --> Language Class Initialized
INFO - 2017-02-03 19:12:14 --> Loader Class Initialized
INFO - 2017-02-03 19:12:14 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:14 --> Controller Class Initialized
INFO - 2017-02-03 19:12:14 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:12:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:14 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:14 --> Total execution time: 0.0157
INFO - 2017-02-03 19:12:15 --> Config Class Initialized
INFO - 2017-02-03 19:12:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:15 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:15 --> URI Class Initialized
INFO - 2017-02-03 19:12:15 --> Router Class Initialized
INFO - 2017-02-03 19:12:15 --> Output Class Initialized
INFO - 2017-02-03 19:12:15 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:15 --> Input Class Initialized
INFO - 2017-02-03 19:12:15 --> Language Class Initialized
INFO - 2017-02-03 19:12:15 --> Loader Class Initialized
INFO - 2017-02-03 19:12:15 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:15 --> Controller Class Initialized
INFO - 2017-02-03 19:12:15 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:15 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:15 --> Total execution time: 0.0132
INFO - 2017-02-03 19:12:21 --> Config Class Initialized
INFO - 2017-02-03 19:12:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:21 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:21 --> URI Class Initialized
INFO - 2017-02-03 19:12:21 --> Router Class Initialized
INFO - 2017-02-03 19:12:21 --> Output Class Initialized
INFO - 2017-02-03 19:12:21 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:21 --> Input Class Initialized
INFO - 2017-02-03 19:12:21 --> Language Class Initialized
INFO - 2017-02-03 19:12:21 --> Loader Class Initialized
INFO - 2017-02-03 19:12:21 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:21 --> Controller Class Initialized
INFO - 2017-02-03 19:12:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:21 --> Config Class Initialized
INFO - 2017-02-03 19:12:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:21 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:21 --> URI Class Initialized
INFO - 2017-02-03 19:12:21 --> Router Class Initialized
INFO - 2017-02-03 19:12:21 --> Output Class Initialized
INFO - 2017-02-03 19:12:21 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:21 --> Input Class Initialized
INFO - 2017-02-03 19:12:21 --> Language Class Initialized
INFO - 2017-02-03 19:12:21 --> Loader Class Initialized
INFO - 2017-02-03 19:12:21 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:21 --> Controller Class Initialized
INFO - 2017-02-03 19:12:21 --> Helper loaded: date_helper
DEBUG - 2017-02-03 19:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:21 --> Helper loaded: url_helper
INFO - 2017-02-03 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:21 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:21 --> Total execution time: 0.0140
INFO - 2017-02-03 19:12:22 --> Config Class Initialized
INFO - 2017-02-03 19:12:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:22 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:22 --> URI Class Initialized
INFO - 2017-02-03 19:12:22 --> Router Class Initialized
INFO - 2017-02-03 19:12:22 --> Output Class Initialized
INFO - 2017-02-03 19:12:22 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:22 --> Input Class Initialized
INFO - 2017-02-03 19:12:22 --> Language Class Initialized
INFO - 2017-02-03 19:12:22 --> Loader Class Initialized
INFO - 2017-02-03 19:12:22 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:22 --> Controller Class Initialized
INFO - 2017-02-03 19:12:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:22 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:22 --> Total execution time: 0.0149
INFO - 2017-02-03 19:12:26 --> Config Class Initialized
INFO - 2017-02-03 19:12:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:26 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:26 --> URI Class Initialized
DEBUG - 2017-02-03 19:12:26 --> No URI present. Default controller set.
INFO - 2017-02-03 19:12:26 --> Router Class Initialized
INFO - 2017-02-03 19:12:26 --> Output Class Initialized
INFO - 2017-02-03 19:12:26 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:26 --> Input Class Initialized
INFO - 2017-02-03 19:12:26 --> Language Class Initialized
INFO - 2017-02-03 19:12:26 --> Loader Class Initialized
INFO - 2017-02-03 19:12:26 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:26 --> Controller Class Initialized
INFO - 2017-02-03 19:12:26 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:12:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:12:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:26 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:26 --> Total execution time: 0.0146
INFO - 2017-02-03 19:12:27 --> Config Class Initialized
INFO - 2017-02-03 19:12:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:12:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:12:27 --> Utf8 Class Initialized
INFO - 2017-02-03 19:12:27 --> URI Class Initialized
INFO - 2017-02-03 19:12:27 --> Router Class Initialized
INFO - 2017-02-03 19:12:27 --> Output Class Initialized
INFO - 2017-02-03 19:12:27 --> Security Class Initialized
DEBUG - 2017-02-03 19:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:12:27 --> Input Class Initialized
INFO - 2017-02-03 19:12:27 --> Language Class Initialized
INFO - 2017-02-03 19:12:27 --> Loader Class Initialized
INFO - 2017-02-03 19:12:27 --> Database Driver Class Initialized
INFO - 2017-02-03 19:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:12:27 --> Controller Class Initialized
INFO - 2017-02-03 19:12:27 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:12:27 --> Final output sent to browser
DEBUG - 2017-02-03 19:12:27 --> Total execution time: 0.0149
INFO - 2017-02-03 19:19:34 --> Config Class Initialized
INFO - 2017-02-03 19:19:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:19:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:19:34 --> Utf8 Class Initialized
INFO - 2017-02-03 19:19:34 --> URI Class Initialized
DEBUG - 2017-02-03 19:19:34 --> No URI present. Default controller set.
INFO - 2017-02-03 19:19:34 --> Router Class Initialized
INFO - 2017-02-03 19:19:34 --> Output Class Initialized
INFO - 2017-02-03 19:19:34 --> Security Class Initialized
DEBUG - 2017-02-03 19:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:19:34 --> Input Class Initialized
INFO - 2017-02-03 19:19:34 --> Language Class Initialized
INFO - 2017-02-03 19:19:34 --> Loader Class Initialized
INFO - 2017-02-03 19:19:34 --> Database Driver Class Initialized
INFO - 2017-02-03 19:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:19:34 --> Controller Class Initialized
INFO - 2017-02-03 19:19:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:19:34 --> Final output sent to browser
DEBUG - 2017-02-03 19:19:34 --> Total execution time: 0.0293
INFO - 2017-02-03 19:19:36 --> Config Class Initialized
INFO - 2017-02-03 19:19:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:19:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:19:36 --> Utf8 Class Initialized
INFO - 2017-02-03 19:19:36 --> URI Class Initialized
INFO - 2017-02-03 19:19:36 --> Router Class Initialized
INFO - 2017-02-03 19:19:36 --> Output Class Initialized
INFO - 2017-02-03 19:19:36 --> Security Class Initialized
DEBUG - 2017-02-03 19:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:19:36 --> Input Class Initialized
INFO - 2017-02-03 19:19:36 --> Language Class Initialized
INFO - 2017-02-03 19:19:36 --> Loader Class Initialized
INFO - 2017-02-03 19:19:36 --> Database Driver Class Initialized
INFO - 2017-02-03 19:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:19:36 --> Controller Class Initialized
INFO - 2017-02-03 19:19:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:19:36 --> Final output sent to browser
DEBUG - 2017-02-03 19:19:36 --> Total execution time: 0.0132
INFO - 2017-02-03 19:20:28 --> Config Class Initialized
INFO - 2017-02-03 19:20:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:28 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:28 --> URI Class Initialized
INFO - 2017-02-03 19:20:28 --> Router Class Initialized
INFO - 2017-02-03 19:20:28 --> Output Class Initialized
INFO - 2017-02-03 19:20:28 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:28 --> Input Class Initialized
INFO - 2017-02-03 19:20:28 --> Language Class Initialized
INFO - 2017-02-03 19:20:28 --> Loader Class Initialized
INFO - 2017-02-03 19:20:28 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:28 --> Controller Class Initialized
INFO - 2017-02-03 19:20:28 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:20:29 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:20:29 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:20:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:20:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:20:29 --> Config Class Initialized
INFO - 2017-02-03 19:20:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:29 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:29 --> URI Class Initialized
INFO - 2017-02-03 19:20:29 --> Router Class Initialized
INFO - 2017-02-03 19:20:29 --> Output Class Initialized
INFO - 2017-02-03 19:20:29 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:29 --> Input Class Initialized
INFO - 2017-02-03 19:20:29 --> Language Class Initialized
INFO - 2017-02-03 19:20:29 --> Loader Class Initialized
INFO - 2017-02-03 19:20:29 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:29 --> Controller Class Initialized
INFO - 2017-02-03 19:20:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:20:29 --> Final output sent to browser
DEBUG - 2017-02-03 19:20:29 --> Total execution time: 0.0142
INFO - 2017-02-03 19:20:34 --> Config Class Initialized
INFO - 2017-02-03 19:20:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:34 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:34 --> URI Class Initialized
INFO - 2017-02-03 19:20:34 --> Router Class Initialized
INFO - 2017-02-03 19:20:34 --> Output Class Initialized
INFO - 2017-02-03 19:20:34 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:34 --> Input Class Initialized
INFO - 2017-02-03 19:20:34 --> Language Class Initialized
INFO - 2017-02-03 19:20:34 --> Loader Class Initialized
INFO - 2017-02-03 19:20:34 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:34 --> Controller Class Initialized
INFO - 2017-02-03 19:20:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:20:34 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:20:34 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:20:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:20:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:20:35 --> Config Class Initialized
INFO - 2017-02-03 19:20:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:35 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:35 --> URI Class Initialized
INFO - 2017-02-03 19:20:35 --> Router Class Initialized
INFO - 2017-02-03 19:20:35 --> Output Class Initialized
INFO - 2017-02-03 19:20:35 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:35 --> Input Class Initialized
INFO - 2017-02-03 19:20:35 --> Language Class Initialized
INFO - 2017-02-03 19:20:35 --> Loader Class Initialized
INFO - 2017-02-03 19:20:35 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:35 --> Controller Class Initialized
INFO - 2017-02-03 19:20:35 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:20:35 --> Final output sent to browser
DEBUG - 2017-02-03 19:20:35 --> Total execution time: 0.0153
INFO - 2017-02-03 19:20:38 --> Config Class Initialized
INFO - 2017-02-03 19:20:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:38 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:38 --> URI Class Initialized
DEBUG - 2017-02-03 19:20:38 --> No URI present. Default controller set.
INFO - 2017-02-03 19:20:38 --> Router Class Initialized
INFO - 2017-02-03 19:20:38 --> Output Class Initialized
INFO - 2017-02-03 19:20:38 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:38 --> Input Class Initialized
INFO - 2017-02-03 19:20:38 --> Language Class Initialized
INFO - 2017-02-03 19:20:38 --> Loader Class Initialized
INFO - 2017-02-03 19:20:38 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:38 --> Controller Class Initialized
INFO - 2017-02-03 19:20:38 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:20:38 --> Final output sent to browser
DEBUG - 2017-02-03 19:20:38 --> Total execution time: 0.0135
INFO - 2017-02-03 19:20:39 --> Config Class Initialized
INFO - 2017-02-03 19:20:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:39 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:39 --> URI Class Initialized
INFO - 2017-02-03 19:20:39 --> Router Class Initialized
INFO - 2017-02-03 19:20:39 --> Output Class Initialized
INFO - 2017-02-03 19:20:39 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:39 --> Input Class Initialized
INFO - 2017-02-03 19:20:39 --> Language Class Initialized
INFO - 2017-02-03 19:20:39 --> Loader Class Initialized
INFO - 2017-02-03 19:20:39 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:39 --> Controller Class Initialized
INFO - 2017-02-03 19:20:39 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:20:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:20:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:20:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:20:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:20:39 --> Final output sent to browser
DEBUG - 2017-02-03 19:20:39 --> Total execution time: 0.0144
INFO - 2017-02-03 19:20:43 --> Config Class Initialized
INFO - 2017-02-03 19:20:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:43 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:43 --> URI Class Initialized
INFO - 2017-02-03 19:20:43 --> Router Class Initialized
INFO - 2017-02-03 19:20:43 --> Output Class Initialized
INFO - 2017-02-03 19:20:43 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:43 --> Input Class Initialized
INFO - 2017-02-03 19:20:43 --> Language Class Initialized
INFO - 2017-02-03 19:20:43 --> Loader Class Initialized
INFO - 2017-02-03 19:20:43 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:43 --> Controller Class Initialized
INFO - 2017-02-03 19:20:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:20:44 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:20:44 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:20:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:20:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:20:44 --> Config Class Initialized
INFO - 2017-02-03 19:20:44 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:44 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:44 --> URI Class Initialized
INFO - 2017-02-03 19:20:44 --> Router Class Initialized
INFO - 2017-02-03 19:20:44 --> Output Class Initialized
INFO - 2017-02-03 19:20:44 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:44 --> Input Class Initialized
INFO - 2017-02-03 19:20:44 --> Language Class Initialized
INFO - 2017-02-03 19:20:44 --> Loader Class Initialized
INFO - 2017-02-03 19:20:44 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:44 --> Controller Class Initialized
INFO - 2017-02-03 19:20:44 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:20:44 --> Final output sent to browser
DEBUG - 2017-02-03 19:20:44 --> Total execution time: 0.0141
INFO - 2017-02-03 19:20:47 --> Config Class Initialized
INFO - 2017-02-03 19:20:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:47 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:47 --> URI Class Initialized
DEBUG - 2017-02-03 19:20:47 --> No URI present. Default controller set.
INFO - 2017-02-03 19:20:47 --> Router Class Initialized
INFO - 2017-02-03 19:20:47 --> Output Class Initialized
INFO - 2017-02-03 19:20:47 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:47 --> Input Class Initialized
INFO - 2017-02-03 19:20:47 --> Language Class Initialized
INFO - 2017-02-03 19:20:47 --> Loader Class Initialized
INFO - 2017-02-03 19:20:47 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:47 --> Controller Class Initialized
INFO - 2017-02-03 19:20:47 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:20:48 --> Final output sent to browser
DEBUG - 2017-02-03 19:20:48 --> Total execution time: 0.0146
INFO - 2017-02-03 19:20:49 --> Config Class Initialized
INFO - 2017-02-03 19:20:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:20:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:20:49 --> Utf8 Class Initialized
INFO - 2017-02-03 19:20:49 --> URI Class Initialized
INFO - 2017-02-03 19:20:49 --> Router Class Initialized
INFO - 2017-02-03 19:20:49 --> Output Class Initialized
INFO - 2017-02-03 19:20:49 --> Security Class Initialized
DEBUG - 2017-02-03 19:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:20:49 --> Input Class Initialized
INFO - 2017-02-03 19:20:49 --> Language Class Initialized
INFO - 2017-02-03 19:20:49 --> Loader Class Initialized
INFO - 2017-02-03 19:20:49 --> Database Driver Class Initialized
INFO - 2017-02-03 19:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:20:49 --> Controller Class Initialized
INFO - 2017-02-03 19:20:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:20:49 --> Final output sent to browser
DEBUG - 2017-02-03 19:20:49 --> Total execution time: 0.0156
INFO - 2017-02-03 19:21:10 --> Config Class Initialized
INFO - 2017-02-03 19:21:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:21:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:21:10 --> Utf8 Class Initialized
INFO - 2017-02-03 19:21:10 --> URI Class Initialized
DEBUG - 2017-02-03 19:21:10 --> No URI present. Default controller set.
INFO - 2017-02-03 19:21:10 --> Router Class Initialized
INFO - 2017-02-03 19:21:10 --> Output Class Initialized
INFO - 2017-02-03 19:21:10 --> Security Class Initialized
DEBUG - 2017-02-03 19:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:21:10 --> Input Class Initialized
INFO - 2017-02-03 19:21:10 --> Language Class Initialized
INFO - 2017-02-03 19:21:10 --> Loader Class Initialized
INFO - 2017-02-03 19:21:10 --> Database Driver Class Initialized
INFO - 2017-02-03 19:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:21:10 --> Controller Class Initialized
INFO - 2017-02-03 19:21:10 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:21:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:21:10 --> Final output sent to browser
DEBUG - 2017-02-03 19:21:10 --> Total execution time: 0.0127
INFO - 2017-02-03 19:21:13 --> Config Class Initialized
INFO - 2017-02-03 19:21:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:21:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:21:13 --> Utf8 Class Initialized
INFO - 2017-02-03 19:21:13 --> URI Class Initialized
INFO - 2017-02-03 19:21:13 --> Router Class Initialized
INFO - 2017-02-03 19:21:13 --> Output Class Initialized
INFO - 2017-02-03 19:21:13 --> Security Class Initialized
DEBUG - 2017-02-03 19:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:21:13 --> Input Class Initialized
INFO - 2017-02-03 19:21:13 --> Language Class Initialized
INFO - 2017-02-03 19:21:13 --> Loader Class Initialized
INFO - 2017-02-03 19:21:13 --> Database Driver Class Initialized
INFO - 2017-02-03 19:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:21:13 --> Controller Class Initialized
INFO - 2017-02-03 19:21:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:21:13 --> Final output sent to browser
DEBUG - 2017-02-03 19:21:13 --> Total execution time: 0.0133
INFO - 2017-02-03 19:22:00 --> Config Class Initialized
INFO - 2017-02-03 19:22:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:22:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:22:00 --> Utf8 Class Initialized
INFO - 2017-02-03 19:22:00 --> URI Class Initialized
INFO - 2017-02-03 19:22:00 --> Router Class Initialized
INFO - 2017-02-03 19:22:00 --> Output Class Initialized
INFO - 2017-02-03 19:22:00 --> Security Class Initialized
DEBUG - 2017-02-03 19:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:22:00 --> Input Class Initialized
INFO - 2017-02-03 19:22:00 --> Language Class Initialized
INFO - 2017-02-03 19:22:00 --> Loader Class Initialized
INFO - 2017-02-03 19:22:00 --> Database Driver Class Initialized
INFO - 2017-02-03 19:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:22:00 --> Controller Class Initialized
INFO - 2017-02-03 19:22:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:22:00 --> Final output sent to browser
DEBUG - 2017-02-03 19:22:00 --> Total execution time: 0.0153
INFO - 2017-02-03 19:22:02 --> Config Class Initialized
INFO - 2017-02-03 19:22:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:22:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:22:02 --> Utf8 Class Initialized
INFO - 2017-02-03 19:22:02 --> URI Class Initialized
INFO - 2017-02-03 19:22:02 --> Router Class Initialized
INFO - 2017-02-03 19:22:02 --> Output Class Initialized
INFO - 2017-02-03 19:22:02 --> Security Class Initialized
DEBUG - 2017-02-03 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:22:02 --> Input Class Initialized
INFO - 2017-02-03 19:22:02 --> Language Class Initialized
INFO - 2017-02-03 19:22:02 --> Loader Class Initialized
INFO - 2017-02-03 19:22:02 --> Database Driver Class Initialized
INFO - 2017-02-03 19:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:22:02 --> Controller Class Initialized
INFO - 2017-02-03 19:22:02 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:22:02 --> Final output sent to browser
DEBUG - 2017-02-03 19:22:02 --> Total execution time: 0.0250
INFO - 2017-02-03 19:22:24 --> Config Class Initialized
INFO - 2017-02-03 19:22:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:22:24 --> Utf8 Class Initialized
INFO - 2017-02-03 19:22:24 --> URI Class Initialized
DEBUG - 2017-02-03 19:22:24 --> No URI present. Default controller set.
INFO - 2017-02-03 19:22:24 --> Router Class Initialized
INFO - 2017-02-03 19:22:24 --> Output Class Initialized
INFO - 2017-02-03 19:22:24 --> Security Class Initialized
DEBUG - 2017-02-03 19:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:22:24 --> Input Class Initialized
INFO - 2017-02-03 19:22:24 --> Language Class Initialized
INFO - 2017-02-03 19:22:24 --> Loader Class Initialized
INFO - 2017-02-03 19:22:24 --> Database Driver Class Initialized
INFO - 2017-02-03 19:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:22:24 --> Controller Class Initialized
INFO - 2017-02-03 19:22:24 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:22:24 --> Final output sent to browser
DEBUG - 2017-02-03 19:22:24 --> Total execution time: 0.0133
INFO - 2017-02-03 19:22:25 --> Config Class Initialized
INFO - 2017-02-03 19:22:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:22:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:22:25 --> Utf8 Class Initialized
INFO - 2017-02-03 19:22:25 --> URI Class Initialized
INFO - 2017-02-03 19:22:25 --> Router Class Initialized
INFO - 2017-02-03 19:22:25 --> Output Class Initialized
INFO - 2017-02-03 19:22:25 --> Security Class Initialized
DEBUG - 2017-02-03 19:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:22:25 --> Input Class Initialized
INFO - 2017-02-03 19:22:25 --> Language Class Initialized
INFO - 2017-02-03 19:22:25 --> Loader Class Initialized
INFO - 2017-02-03 19:22:25 --> Database Driver Class Initialized
INFO - 2017-02-03 19:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:22:25 --> Controller Class Initialized
INFO - 2017-02-03 19:22:25 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:22:25 --> Final output sent to browser
DEBUG - 2017-02-03 19:22:25 --> Total execution time: 0.0140
INFO - 2017-02-03 19:23:30 --> Config Class Initialized
INFO - 2017-02-03 19:23:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:30 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:30 --> URI Class Initialized
DEBUG - 2017-02-03 19:23:30 --> No URI present. Default controller set.
INFO - 2017-02-03 19:23:30 --> Router Class Initialized
INFO - 2017-02-03 19:23:30 --> Output Class Initialized
INFO - 2017-02-03 19:23:30 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:30 --> Input Class Initialized
INFO - 2017-02-03 19:23:30 --> Language Class Initialized
INFO - 2017-02-03 19:23:30 --> Loader Class Initialized
INFO - 2017-02-03 19:23:30 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:30 --> Controller Class Initialized
INFO - 2017-02-03 19:23:30 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:23:30 --> Final output sent to browser
DEBUG - 2017-02-03 19:23:30 --> Total execution time: 0.0154
INFO - 2017-02-03 19:23:32 --> Config Class Initialized
INFO - 2017-02-03 19:23:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:32 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:32 --> URI Class Initialized
INFO - 2017-02-03 19:23:32 --> Router Class Initialized
INFO - 2017-02-03 19:23:32 --> Output Class Initialized
INFO - 2017-02-03 19:23:32 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:32 --> Input Class Initialized
INFO - 2017-02-03 19:23:32 --> Language Class Initialized
INFO - 2017-02-03 19:23:32 --> Loader Class Initialized
INFO - 2017-02-03 19:23:32 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:32 --> Controller Class Initialized
INFO - 2017-02-03 19:23:32 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:23:32 --> Final output sent to browser
DEBUG - 2017-02-03 19:23:32 --> Total execution time: 0.0133
INFO - 2017-02-03 19:23:42 --> Config Class Initialized
INFO - 2017-02-03 19:23:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:42 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:42 --> URI Class Initialized
INFO - 2017-02-03 19:23:42 --> Router Class Initialized
INFO - 2017-02-03 19:23:42 --> Output Class Initialized
INFO - 2017-02-03 19:23:42 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:42 --> Input Class Initialized
INFO - 2017-02-03 19:23:42 --> Language Class Initialized
INFO - 2017-02-03 19:23:42 --> Loader Class Initialized
INFO - 2017-02-03 19:23:42 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:42 --> Controller Class Initialized
INFO - 2017-02-03 19:23:42 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:23:42 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:23:42 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:23:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:23:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:23:43 --> Config Class Initialized
INFO - 2017-02-03 19:23:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:43 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:43 --> URI Class Initialized
INFO - 2017-02-03 19:23:43 --> Router Class Initialized
INFO - 2017-02-03 19:23:43 --> Output Class Initialized
INFO - 2017-02-03 19:23:43 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:43 --> Input Class Initialized
INFO - 2017-02-03 19:23:43 --> Language Class Initialized
INFO - 2017-02-03 19:23:43 --> Loader Class Initialized
INFO - 2017-02-03 19:23:43 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:43 --> Controller Class Initialized
INFO - 2017-02-03 19:23:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:23:43 --> Final output sent to browser
DEBUG - 2017-02-03 19:23:43 --> Total execution time: 0.0149
INFO - 2017-02-03 19:23:52 --> Config Class Initialized
INFO - 2017-02-03 19:23:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:52 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:52 --> URI Class Initialized
DEBUG - 2017-02-03 19:23:52 --> No URI present. Default controller set.
INFO - 2017-02-03 19:23:52 --> Router Class Initialized
INFO - 2017-02-03 19:23:52 --> Output Class Initialized
INFO - 2017-02-03 19:23:52 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:52 --> Input Class Initialized
INFO - 2017-02-03 19:23:52 --> Language Class Initialized
INFO - 2017-02-03 19:23:52 --> Loader Class Initialized
INFO - 2017-02-03 19:23:52 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:52 --> Controller Class Initialized
INFO - 2017-02-03 19:23:52 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:23:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:23:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:23:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:23:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:23:52 --> Final output sent to browser
DEBUG - 2017-02-03 19:23:52 --> Total execution time: 0.0128
INFO - 2017-02-03 19:23:53 --> Config Class Initialized
INFO - 2017-02-03 19:23:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:53 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:53 --> URI Class Initialized
INFO - 2017-02-03 19:23:53 --> Router Class Initialized
INFO - 2017-02-03 19:23:53 --> Output Class Initialized
INFO - 2017-02-03 19:23:53 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:53 --> Input Class Initialized
INFO - 2017-02-03 19:23:53 --> Language Class Initialized
INFO - 2017-02-03 19:23:53 --> Loader Class Initialized
INFO - 2017-02-03 19:23:53 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:53 --> Controller Class Initialized
INFO - 2017-02-03 19:23:53 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:23:53 --> Final output sent to browser
DEBUG - 2017-02-03 19:23:53 --> Total execution time: 0.0135
INFO - 2017-02-03 19:23:55 --> Config Class Initialized
INFO - 2017-02-03 19:23:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:55 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:55 --> URI Class Initialized
INFO - 2017-02-03 19:23:55 --> Router Class Initialized
INFO - 2017-02-03 19:23:55 --> Output Class Initialized
INFO - 2017-02-03 19:23:55 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:55 --> Input Class Initialized
INFO - 2017-02-03 19:23:55 --> Language Class Initialized
INFO - 2017-02-03 19:23:55 --> Loader Class Initialized
INFO - 2017-02-03 19:23:55 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:55 --> Controller Class Initialized
INFO - 2017-02-03 19:23:55 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:23:56 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:23:56 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:23:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:23:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:23:57 --> Config Class Initialized
INFO - 2017-02-03 19:23:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:23:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:23:57 --> Utf8 Class Initialized
INFO - 2017-02-03 19:23:57 --> URI Class Initialized
INFO - 2017-02-03 19:23:57 --> Router Class Initialized
INFO - 2017-02-03 19:23:57 --> Output Class Initialized
INFO - 2017-02-03 19:23:57 --> Security Class Initialized
DEBUG - 2017-02-03 19:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:23:57 --> Input Class Initialized
INFO - 2017-02-03 19:23:57 --> Language Class Initialized
INFO - 2017-02-03 19:23:57 --> Loader Class Initialized
INFO - 2017-02-03 19:23:57 --> Database Driver Class Initialized
INFO - 2017-02-03 19:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:23:57 --> Controller Class Initialized
INFO - 2017-02-03 19:23:57 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:23:57 --> Final output sent to browser
DEBUG - 2017-02-03 19:23:57 --> Total execution time: 0.0139
INFO - 2017-02-03 19:24:06 --> Config Class Initialized
INFO - 2017-02-03 19:24:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:24:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:24:06 --> Utf8 Class Initialized
INFO - 2017-02-03 19:24:06 --> URI Class Initialized
DEBUG - 2017-02-03 19:24:06 --> No URI present. Default controller set.
INFO - 2017-02-03 19:24:06 --> Router Class Initialized
INFO - 2017-02-03 19:24:06 --> Output Class Initialized
INFO - 2017-02-03 19:24:06 --> Security Class Initialized
DEBUG - 2017-02-03 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:24:06 --> Input Class Initialized
INFO - 2017-02-03 19:24:06 --> Language Class Initialized
INFO - 2017-02-03 19:24:06 --> Loader Class Initialized
INFO - 2017-02-03 19:24:06 --> Database Driver Class Initialized
INFO - 2017-02-03 19:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:24:06 --> Controller Class Initialized
INFO - 2017-02-03 19:24:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:24:06 --> Final output sent to browser
DEBUG - 2017-02-03 19:24:06 --> Total execution time: 0.0130
INFO - 2017-02-03 19:24:07 --> Config Class Initialized
INFO - 2017-02-03 19:24:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:24:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:24:07 --> Utf8 Class Initialized
INFO - 2017-02-03 19:24:07 --> URI Class Initialized
INFO - 2017-02-03 19:24:07 --> Router Class Initialized
INFO - 2017-02-03 19:24:07 --> Output Class Initialized
INFO - 2017-02-03 19:24:07 --> Security Class Initialized
DEBUG - 2017-02-03 19:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:24:07 --> Input Class Initialized
INFO - 2017-02-03 19:24:07 --> Language Class Initialized
INFO - 2017-02-03 19:24:07 --> Loader Class Initialized
INFO - 2017-02-03 19:24:07 --> Database Driver Class Initialized
INFO - 2017-02-03 19:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:24:07 --> Controller Class Initialized
INFO - 2017-02-03 19:24:07 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:24:07 --> Final output sent to browser
DEBUG - 2017-02-03 19:24:07 --> Total execution time: 0.0135
INFO - 2017-02-03 19:37:35 --> Config Class Initialized
INFO - 2017-02-03 19:37:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:37:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:37:35 --> Utf8 Class Initialized
INFO - 2017-02-03 19:37:35 --> URI Class Initialized
DEBUG - 2017-02-03 19:37:35 --> No URI present. Default controller set.
INFO - 2017-02-03 19:37:35 --> Router Class Initialized
INFO - 2017-02-03 19:37:35 --> Output Class Initialized
INFO - 2017-02-03 19:37:35 --> Security Class Initialized
DEBUG - 2017-02-03 19:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:37:35 --> Input Class Initialized
INFO - 2017-02-03 19:37:35 --> Language Class Initialized
INFO - 2017-02-03 19:37:35 --> Loader Class Initialized
INFO - 2017-02-03 19:37:35 --> Database Driver Class Initialized
INFO - 2017-02-03 19:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:37:35 --> Controller Class Initialized
INFO - 2017-02-03 19:37:35 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:37:35 --> Final output sent to browser
DEBUG - 2017-02-03 19:37:35 --> Total execution time: 0.0132
INFO - 2017-02-03 19:38:04 --> Config Class Initialized
INFO - 2017-02-03 19:38:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:04 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:04 --> URI Class Initialized
INFO - 2017-02-03 19:38:04 --> Router Class Initialized
INFO - 2017-02-03 19:38:04 --> Output Class Initialized
INFO - 2017-02-03 19:38:04 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:04 --> Input Class Initialized
INFO - 2017-02-03 19:38:04 --> Language Class Initialized
INFO - 2017-02-03 19:38:04 --> Loader Class Initialized
INFO - 2017-02-03 19:38:04 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:04 --> Controller Class Initialized
INFO - 2017-02-03 19:38:04 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:38:05 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:38:05 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:38:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:38:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:38:06 --> Config Class Initialized
INFO - 2017-02-03 19:38:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:06 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:06 --> URI Class Initialized
INFO - 2017-02-03 19:38:06 --> Router Class Initialized
INFO - 2017-02-03 19:38:06 --> Output Class Initialized
INFO - 2017-02-03 19:38:06 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:06 --> Input Class Initialized
INFO - 2017-02-03 19:38:06 --> Language Class Initialized
INFO - 2017-02-03 19:38:06 --> Loader Class Initialized
INFO - 2017-02-03 19:38:06 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:06 --> Controller Class Initialized
INFO - 2017-02-03 19:38:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:38:06 --> Final output sent to browser
DEBUG - 2017-02-03 19:38:06 --> Total execution time: 0.0143
INFO - 2017-02-03 19:38:06 --> Config Class Initialized
INFO - 2017-02-03 19:38:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:06 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:06 --> URI Class Initialized
INFO - 2017-02-03 19:38:06 --> Router Class Initialized
INFO - 2017-02-03 19:38:06 --> Output Class Initialized
INFO - 2017-02-03 19:38:06 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:06 --> Input Class Initialized
INFO - 2017-02-03 19:38:06 --> Language Class Initialized
INFO - 2017-02-03 19:38:06 --> Loader Class Initialized
INFO - 2017-02-03 19:38:06 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:06 --> Controller Class Initialized
INFO - 2017-02-03 19:38:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:38:06 --> Final output sent to browser
DEBUG - 2017-02-03 19:38:06 --> Total execution time: 0.0138
INFO - 2017-02-03 19:38:26 --> Config Class Initialized
INFO - 2017-02-03 19:38:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:26 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:26 --> URI Class Initialized
INFO - 2017-02-03 19:38:26 --> Router Class Initialized
INFO - 2017-02-03 19:38:26 --> Output Class Initialized
INFO - 2017-02-03 19:38:26 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:26 --> Input Class Initialized
INFO - 2017-02-03 19:38:26 --> Language Class Initialized
INFO - 2017-02-03 19:38:26 --> Loader Class Initialized
INFO - 2017-02-03 19:38:26 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:26 --> Controller Class Initialized
INFO - 2017-02-03 19:38:26 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:38:27 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:38:27 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:38:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:38:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:38:32 --> Config Class Initialized
INFO - 2017-02-03 19:38:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:32 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:32 --> URI Class Initialized
INFO - 2017-02-03 19:38:32 --> Router Class Initialized
INFO - 2017-02-03 19:38:32 --> Output Class Initialized
INFO - 2017-02-03 19:38:32 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:32 --> Input Class Initialized
INFO - 2017-02-03 19:38:32 --> Language Class Initialized
INFO - 2017-02-03 19:38:32 --> Loader Class Initialized
INFO - 2017-02-03 19:38:32 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:32 --> Controller Class Initialized
INFO - 2017-02-03 19:38:32 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:38:33 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:38:33 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:38:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:38:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:38:36 --> Config Class Initialized
INFO - 2017-02-03 19:38:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:36 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:36 --> URI Class Initialized
INFO - 2017-02-03 19:38:36 --> Router Class Initialized
INFO - 2017-02-03 19:38:36 --> Output Class Initialized
INFO - 2017-02-03 19:38:36 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:36 --> Input Class Initialized
INFO - 2017-02-03 19:38:36 --> Language Class Initialized
INFO - 2017-02-03 19:38:36 --> Loader Class Initialized
INFO - 2017-02-03 19:38:36 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:36 --> Controller Class Initialized
INFO - 2017-02-03 19:38:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:38:36 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:38:36 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:38:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:38:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:38:38 --> Config Class Initialized
INFO - 2017-02-03 19:38:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:38 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:38 --> URI Class Initialized
INFO - 2017-02-03 19:38:38 --> Router Class Initialized
INFO - 2017-02-03 19:38:38 --> Output Class Initialized
INFO - 2017-02-03 19:38:38 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:38 --> Input Class Initialized
INFO - 2017-02-03 19:38:38 --> Language Class Initialized
INFO - 2017-02-03 19:38:38 --> Loader Class Initialized
INFO - 2017-02-03 19:38:38 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:38 --> Controller Class Initialized
INFO - 2017-02-03 19:38:38 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:38:38 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:38:38 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:38:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:38:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:38:40 --> Config Class Initialized
INFO - 2017-02-03 19:38:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:40 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:40 --> URI Class Initialized
INFO - 2017-02-03 19:38:40 --> Router Class Initialized
INFO - 2017-02-03 19:38:40 --> Output Class Initialized
INFO - 2017-02-03 19:38:40 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:40 --> Input Class Initialized
INFO - 2017-02-03 19:38:40 --> Language Class Initialized
INFO - 2017-02-03 19:38:40 --> Loader Class Initialized
INFO - 2017-02-03 19:38:40 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:40 --> Controller Class Initialized
INFO - 2017-02-03 19:38:40 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:38:40 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:38:40 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:38:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:38:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:38:50 --> Config Class Initialized
INFO - 2017-02-03 19:38:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:38:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:38:50 --> Utf8 Class Initialized
INFO - 2017-02-03 19:38:50 --> URI Class Initialized
DEBUG - 2017-02-03 19:38:50 --> No URI present. Default controller set.
INFO - 2017-02-03 19:38:50 --> Router Class Initialized
INFO - 2017-02-03 19:38:50 --> Output Class Initialized
INFO - 2017-02-03 19:38:50 --> Security Class Initialized
DEBUG - 2017-02-03 19:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:38:50 --> Input Class Initialized
INFO - 2017-02-03 19:38:50 --> Language Class Initialized
INFO - 2017-02-03 19:38:50 --> Loader Class Initialized
INFO - 2017-02-03 19:38:50 --> Database Driver Class Initialized
INFO - 2017-02-03 19:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:38:50 --> Controller Class Initialized
INFO - 2017-02-03 19:38:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:38:50 --> Final output sent to browser
DEBUG - 2017-02-03 19:38:50 --> Total execution time: 0.0143
INFO - 2017-02-03 19:39:12 --> Config Class Initialized
INFO - 2017-02-03 19:39:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:39:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:39:12 --> Utf8 Class Initialized
INFO - 2017-02-03 19:39:12 --> URI Class Initialized
INFO - 2017-02-03 19:39:12 --> Router Class Initialized
INFO - 2017-02-03 19:39:12 --> Output Class Initialized
INFO - 2017-02-03 19:39:12 --> Security Class Initialized
DEBUG - 2017-02-03 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:39:12 --> Input Class Initialized
INFO - 2017-02-03 19:39:12 --> Language Class Initialized
INFO - 2017-02-03 19:39:12 --> Loader Class Initialized
INFO - 2017-02-03 19:39:12 --> Database Driver Class Initialized
INFO - 2017-02-03 19:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:39:12 --> Controller Class Initialized
INFO - 2017-02-03 19:39:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:39:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:39:13 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:39:13 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:39:13 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:39:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:41:49 --> Config Class Initialized
INFO - 2017-02-03 19:41:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:41:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:41:49 --> Utf8 Class Initialized
INFO - 2017-02-03 19:41:49 --> URI Class Initialized
DEBUG - 2017-02-03 19:41:49 --> No URI present. Default controller set.
INFO - 2017-02-03 19:41:49 --> Router Class Initialized
INFO - 2017-02-03 19:41:49 --> Output Class Initialized
INFO - 2017-02-03 19:41:49 --> Security Class Initialized
DEBUG - 2017-02-03 19:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:41:49 --> Input Class Initialized
INFO - 2017-02-03 19:41:49 --> Language Class Initialized
INFO - 2017-02-03 19:41:49 --> Loader Class Initialized
INFO - 2017-02-03 19:41:49 --> Database Driver Class Initialized
INFO - 2017-02-03 19:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:41:49 --> Controller Class Initialized
INFO - 2017-02-03 19:41:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:41:49 --> Final output sent to browser
DEBUG - 2017-02-03 19:41:49 --> Total execution time: 0.0149
INFO - 2017-02-03 19:42:06 --> Config Class Initialized
INFO - 2017-02-03 19:42:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:42:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:42:06 --> Utf8 Class Initialized
INFO - 2017-02-03 19:42:06 --> URI Class Initialized
INFO - 2017-02-03 19:42:06 --> Router Class Initialized
INFO - 2017-02-03 19:42:06 --> Output Class Initialized
INFO - 2017-02-03 19:42:06 --> Security Class Initialized
DEBUG - 2017-02-03 19:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:42:06 --> Input Class Initialized
INFO - 2017-02-03 19:42:06 --> Language Class Initialized
INFO - 2017-02-03 19:42:06 --> Loader Class Initialized
INFO - 2017-02-03 19:42:06 --> Database Driver Class Initialized
INFO - 2017-02-03 19:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:42:06 --> Controller Class Initialized
INFO - 2017-02-03 19:42:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:42:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:42:07 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:42:07 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:42:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:42:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:42:19 --> Config Class Initialized
INFO - 2017-02-03 19:42:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:42:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:42:19 --> Utf8 Class Initialized
INFO - 2017-02-03 19:42:19 --> URI Class Initialized
DEBUG - 2017-02-03 19:42:19 --> No URI present. Default controller set.
INFO - 2017-02-03 19:42:19 --> Router Class Initialized
INFO - 2017-02-03 19:42:19 --> Output Class Initialized
INFO - 2017-02-03 19:42:19 --> Security Class Initialized
DEBUG - 2017-02-03 19:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:42:19 --> Input Class Initialized
INFO - 2017-02-03 19:42:19 --> Language Class Initialized
INFO - 2017-02-03 19:42:19 --> Loader Class Initialized
INFO - 2017-02-03 19:42:19 --> Database Driver Class Initialized
INFO - 2017-02-03 19:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:42:19 --> Controller Class Initialized
INFO - 2017-02-03 19:42:19 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:42:19 --> Final output sent to browser
DEBUG - 2017-02-03 19:42:19 --> Total execution time: 0.0135
INFO - 2017-02-03 19:42:27 --> Config Class Initialized
INFO - 2017-02-03 19:42:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:42:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:42:27 --> Utf8 Class Initialized
INFO - 2017-02-03 19:42:27 --> URI Class Initialized
DEBUG - 2017-02-03 19:42:27 --> No URI present. Default controller set.
INFO - 2017-02-03 19:42:27 --> Router Class Initialized
INFO - 2017-02-03 19:42:27 --> Output Class Initialized
INFO - 2017-02-03 19:42:27 --> Security Class Initialized
DEBUG - 2017-02-03 19:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:42:27 --> Input Class Initialized
INFO - 2017-02-03 19:42:27 --> Language Class Initialized
INFO - 2017-02-03 19:42:27 --> Loader Class Initialized
INFO - 2017-02-03 19:42:27 --> Database Driver Class Initialized
INFO - 2017-02-03 19:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:42:27 --> Controller Class Initialized
INFO - 2017-02-03 19:42:27 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:42:27 --> Final output sent to browser
DEBUG - 2017-02-03 19:42:27 --> Total execution time: 0.0131
INFO - 2017-02-03 19:46:19 --> Config Class Initialized
INFO - 2017-02-03 19:46:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:46:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:46:19 --> Utf8 Class Initialized
INFO - 2017-02-03 19:46:19 --> URI Class Initialized
DEBUG - 2017-02-03 19:46:19 --> No URI present. Default controller set.
INFO - 2017-02-03 19:46:19 --> Router Class Initialized
INFO - 2017-02-03 19:46:19 --> Output Class Initialized
INFO - 2017-02-03 19:46:19 --> Security Class Initialized
DEBUG - 2017-02-03 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:46:19 --> Input Class Initialized
INFO - 2017-02-03 19:46:19 --> Language Class Initialized
INFO - 2017-02-03 19:46:19 --> Loader Class Initialized
INFO - 2017-02-03 19:46:19 --> Database Driver Class Initialized
INFO - 2017-02-03 19:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:46:19 --> Controller Class Initialized
INFO - 2017-02-03 19:46:19 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:46:19 --> Final output sent to browser
DEBUG - 2017-02-03 19:46:19 --> Total execution time: 0.0136
INFO - 2017-02-03 19:48:15 --> Config Class Initialized
INFO - 2017-02-03 19:48:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:48:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:48:15 --> Utf8 Class Initialized
INFO - 2017-02-03 19:48:15 --> URI Class Initialized
INFO - 2017-02-03 19:48:15 --> Router Class Initialized
INFO - 2017-02-03 19:48:15 --> Output Class Initialized
INFO - 2017-02-03 19:48:15 --> Security Class Initialized
DEBUG - 2017-02-03 19:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:48:15 --> Input Class Initialized
INFO - 2017-02-03 19:48:15 --> Language Class Initialized
INFO - 2017-02-03 19:48:15 --> Loader Class Initialized
INFO - 2017-02-03 19:48:15 --> Database Driver Class Initialized
INFO - 2017-02-03 19:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:48:15 --> Controller Class Initialized
INFO - 2017-02-03 19:48:15 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:48:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:48:16 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:48:16 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:48:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:48:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:48:17 --> Config Class Initialized
INFO - 2017-02-03 19:48:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:48:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:48:17 --> Utf8 Class Initialized
INFO - 2017-02-03 19:48:17 --> URI Class Initialized
INFO - 2017-02-03 19:48:17 --> Router Class Initialized
INFO - 2017-02-03 19:48:17 --> Output Class Initialized
INFO - 2017-02-03 19:48:17 --> Security Class Initialized
DEBUG - 2017-02-03 19:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:48:17 --> Input Class Initialized
INFO - 2017-02-03 19:48:17 --> Language Class Initialized
INFO - 2017-02-03 19:48:17 --> Loader Class Initialized
INFO - 2017-02-03 19:48:17 --> Database Driver Class Initialized
INFO - 2017-02-03 19:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:48:17 --> Controller Class Initialized
INFO - 2017-02-03 19:48:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:48:17 --> Final output sent to browser
DEBUG - 2017-02-03 19:48:17 --> Total execution time: 0.0137
INFO - 2017-02-03 19:48:37 --> Config Class Initialized
INFO - 2017-02-03 19:48:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:48:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:48:37 --> Utf8 Class Initialized
INFO - 2017-02-03 19:48:37 --> URI Class Initialized
INFO - 2017-02-03 19:48:37 --> Router Class Initialized
INFO - 2017-02-03 19:48:37 --> Output Class Initialized
INFO - 2017-02-03 19:48:37 --> Security Class Initialized
DEBUG - 2017-02-03 19:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:48:37 --> Input Class Initialized
INFO - 2017-02-03 19:48:37 --> Language Class Initialized
INFO - 2017-02-03 19:48:37 --> Loader Class Initialized
INFO - 2017-02-03 19:48:37 --> Database Driver Class Initialized
INFO - 2017-02-03 19:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:48:37 --> Controller Class Initialized
INFO - 2017-02-03 19:48:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:48:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:48:37 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:48:37 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:48:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:48:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:48:41 --> Config Class Initialized
INFO - 2017-02-03 19:48:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:48:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:48:41 --> Utf8 Class Initialized
INFO - 2017-02-03 19:48:41 --> URI Class Initialized
INFO - 2017-02-03 19:48:41 --> Router Class Initialized
INFO - 2017-02-03 19:48:41 --> Output Class Initialized
INFO - 2017-02-03 19:48:41 --> Security Class Initialized
DEBUG - 2017-02-03 19:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:48:41 --> Input Class Initialized
INFO - 2017-02-03 19:48:41 --> Language Class Initialized
INFO - 2017-02-03 19:48:41 --> Loader Class Initialized
INFO - 2017-02-03 19:48:41 --> Database Driver Class Initialized
INFO - 2017-02-03 19:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:48:41 --> Controller Class Initialized
INFO - 2017-02-03 19:48:41 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:48:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:48:42 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:48:42 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:48:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:48:43 --> Config Class Initialized
INFO - 2017-02-03 19:48:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:48:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:48:43 --> Utf8 Class Initialized
INFO - 2017-02-03 19:48:43 --> URI Class Initialized
INFO - 2017-02-03 19:48:43 --> Router Class Initialized
INFO - 2017-02-03 19:48:43 --> Output Class Initialized
INFO - 2017-02-03 19:48:43 --> Security Class Initialized
DEBUG - 2017-02-03 19:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:48:43 --> Input Class Initialized
INFO - 2017-02-03 19:48:43 --> Language Class Initialized
INFO - 2017-02-03 19:48:43 --> Loader Class Initialized
INFO - 2017-02-03 19:48:43 --> Database Driver Class Initialized
INFO - 2017-02-03 19:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:48:43 --> Controller Class Initialized
INFO - 2017-02-03 19:48:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:48:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:48:44 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:48:44 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:48:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:48:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:48:45 --> Config Class Initialized
INFO - 2017-02-03 19:48:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:48:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:48:45 --> Utf8 Class Initialized
INFO - 2017-02-03 19:48:45 --> URI Class Initialized
INFO - 2017-02-03 19:48:45 --> Router Class Initialized
INFO - 2017-02-03 19:48:45 --> Output Class Initialized
INFO - 2017-02-03 19:48:45 --> Security Class Initialized
DEBUG - 2017-02-03 19:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:48:45 --> Input Class Initialized
INFO - 2017-02-03 19:48:45 --> Language Class Initialized
INFO - 2017-02-03 19:48:45 --> Loader Class Initialized
INFO - 2017-02-03 19:48:45 --> Database Driver Class Initialized
INFO - 2017-02-03 19:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:48:45 --> Controller Class Initialized
INFO - 2017-02-03 19:48:45 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:48:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:48:45 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:48:45 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:48:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:48:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:48:47 --> Config Class Initialized
INFO - 2017-02-03 19:48:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:48:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:48:47 --> Utf8 Class Initialized
INFO - 2017-02-03 19:48:47 --> URI Class Initialized
INFO - 2017-02-03 19:48:47 --> Router Class Initialized
INFO - 2017-02-03 19:48:47 --> Output Class Initialized
INFO - 2017-02-03 19:48:47 --> Security Class Initialized
DEBUG - 2017-02-03 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:48:47 --> Input Class Initialized
INFO - 2017-02-03 19:48:47 --> Language Class Initialized
INFO - 2017-02-03 19:48:47 --> Loader Class Initialized
INFO - 2017-02-03 19:48:47 --> Database Driver Class Initialized
INFO - 2017-02-03 19:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:48:47 --> Controller Class Initialized
INFO - 2017-02-03 19:48:47 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:48:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:48:47 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:48:47 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:48:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:48:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:50:53 --> Config Class Initialized
INFO - 2017-02-03 19:50:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:50:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:50:53 --> Utf8 Class Initialized
INFO - 2017-02-03 19:50:53 --> URI Class Initialized
INFO - 2017-02-03 19:50:53 --> Router Class Initialized
INFO - 2017-02-03 19:50:53 --> Output Class Initialized
INFO - 2017-02-03 19:50:53 --> Security Class Initialized
DEBUG - 2017-02-03 19:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:50:53 --> Input Class Initialized
INFO - 2017-02-03 19:50:53 --> Language Class Initialized
INFO - 2017-02-03 19:50:53 --> Loader Class Initialized
INFO - 2017-02-03 19:50:53 --> Database Driver Class Initialized
INFO - 2017-02-03 19:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:50:53 --> Controller Class Initialized
INFO - 2017-02-03 19:50:53 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:50:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:50:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:50:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:50:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:50:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:51:07 --> Config Class Initialized
INFO - 2017-02-03 19:51:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:51:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:51:07 --> Utf8 Class Initialized
INFO - 2017-02-03 19:51:07 --> URI Class Initialized
DEBUG - 2017-02-03 19:51:07 --> No URI present. Default controller set.
INFO - 2017-02-03 19:51:07 --> Router Class Initialized
INFO - 2017-02-03 19:51:07 --> Output Class Initialized
INFO - 2017-02-03 19:51:07 --> Security Class Initialized
DEBUG - 2017-02-03 19:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:51:07 --> Input Class Initialized
INFO - 2017-02-03 19:51:07 --> Language Class Initialized
INFO - 2017-02-03 19:51:07 --> Loader Class Initialized
INFO - 2017-02-03 19:51:07 --> Database Driver Class Initialized
INFO - 2017-02-03 19:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:51:07 --> Controller Class Initialized
INFO - 2017-02-03 19:51:07 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:51:07 --> Final output sent to browser
DEBUG - 2017-02-03 19:51:07 --> Total execution time: 0.0138
INFO - 2017-02-03 19:51:22 --> Config Class Initialized
INFO - 2017-02-03 19:51:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:51:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:51:22 --> Utf8 Class Initialized
INFO - 2017-02-03 19:51:22 --> URI Class Initialized
INFO - 2017-02-03 19:51:22 --> Router Class Initialized
INFO - 2017-02-03 19:51:22 --> Output Class Initialized
INFO - 2017-02-03 19:51:22 --> Security Class Initialized
DEBUG - 2017-02-03 19:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:51:22 --> Input Class Initialized
INFO - 2017-02-03 19:51:22 --> Language Class Initialized
INFO - 2017-02-03 19:51:22 --> Loader Class Initialized
INFO - 2017-02-03 19:51:22 --> Database Driver Class Initialized
INFO - 2017-02-03 19:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:51:22 --> Controller Class Initialized
INFO - 2017-02-03 19:51:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:51:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:51:23 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:51:23 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:51:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:51:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:55:01 --> Config Class Initialized
INFO - 2017-02-03 19:55:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:55:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:55:01 --> Utf8 Class Initialized
INFO - 2017-02-03 19:55:01 --> URI Class Initialized
DEBUG - 2017-02-03 19:55:01 --> No URI present. Default controller set.
INFO - 2017-02-03 19:55:01 --> Router Class Initialized
INFO - 2017-02-03 19:55:01 --> Output Class Initialized
INFO - 2017-02-03 19:55:01 --> Security Class Initialized
DEBUG - 2017-02-03 19:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:55:01 --> Input Class Initialized
INFO - 2017-02-03 19:55:01 --> Language Class Initialized
INFO - 2017-02-03 19:55:01 --> Loader Class Initialized
INFO - 2017-02-03 19:55:01 --> Database Driver Class Initialized
INFO - 2017-02-03 19:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:55:01 --> Controller Class Initialized
INFO - 2017-02-03 19:55:01 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:55:01 --> Final output sent to browser
DEBUG - 2017-02-03 19:55:01 --> Total execution time: 0.0132
INFO - 2017-02-03 19:55:40 --> Config Class Initialized
INFO - 2017-02-03 19:55:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:55:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:55:40 --> Utf8 Class Initialized
INFO - 2017-02-03 19:55:40 --> URI Class Initialized
DEBUG - 2017-02-03 19:55:40 --> No URI present. Default controller set.
INFO - 2017-02-03 19:55:40 --> Router Class Initialized
INFO - 2017-02-03 19:55:40 --> Output Class Initialized
INFO - 2017-02-03 19:55:40 --> Security Class Initialized
DEBUG - 2017-02-03 19:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:55:40 --> Input Class Initialized
INFO - 2017-02-03 19:55:40 --> Language Class Initialized
INFO - 2017-02-03 19:55:40 --> Loader Class Initialized
INFO - 2017-02-03 19:55:40 --> Database Driver Class Initialized
INFO - 2017-02-03 19:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:55:40 --> Controller Class Initialized
INFO - 2017-02-03 19:55:40 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:55:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:55:40 --> Final output sent to browser
DEBUG - 2017-02-03 19:55:40 --> Total execution time: 0.0146
INFO - 2017-02-03 19:55:50 --> Config Class Initialized
INFO - 2017-02-03 19:55:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:55:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:55:50 --> Utf8 Class Initialized
INFO - 2017-02-03 19:55:50 --> URI Class Initialized
INFO - 2017-02-03 19:55:50 --> Router Class Initialized
INFO - 2017-02-03 19:55:50 --> Output Class Initialized
INFO - 2017-02-03 19:55:50 --> Security Class Initialized
DEBUG - 2017-02-03 19:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:55:50 --> Input Class Initialized
INFO - 2017-02-03 19:55:50 --> Language Class Initialized
INFO - 2017-02-03 19:55:50 --> Loader Class Initialized
INFO - 2017-02-03 19:55:50 --> Database Driver Class Initialized
INFO - 2017-02-03 19:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:55:50 --> Controller Class Initialized
INFO - 2017-02-03 19:55:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:55:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:55:51 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:55:51 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:55:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:56:56 --> Config Class Initialized
INFO - 2017-02-03 19:56:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:56:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:56:56 --> Utf8 Class Initialized
INFO - 2017-02-03 19:56:56 --> URI Class Initialized
DEBUG - 2017-02-03 19:56:56 --> No URI present. Default controller set.
INFO - 2017-02-03 19:56:56 --> Router Class Initialized
INFO - 2017-02-03 19:56:56 --> Output Class Initialized
INFO - 2017-02-03 19:56:56 --> Security Class Initialized
DEBUG - 2017-02-03 19:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:56:56 --> Input Class Initialized
INFO - 2017-02-03 19:56:56 --> Language Class Initialized
INFO - 2017-02-03 19:56:56 --> Loader Class Initialized
INFO - 2017-02-03 19:56:56 --> Database Driver Class Initialized
INFO - 2017-02-03 19:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:56:56 --> Controller Class Initialized
INFO - 2017-02-03 19:56:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:56:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:56:56 --> Final output sent to browser
DEBUG - 2017-02-03 19:56:56 --> Total execution time: 0.0138
INFO - 2017-02-03 19:57:00 --> Config Class Initialized
INFO - 2017-02-03 19:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:57:00 --> Utf8 Class Initialized
INFO - 2017-02-03 19:57:00 --> URI Class Initialized
INFO - 2017-02-03 19:57:00 --> Router Class Initialized
INFO - 2017-02-03 19:57:00 --> Output Class Initialized
INFO - 2017-02-03 19:57:00 --> Security Class Initialized
DEBUG - 2017-02-03 19:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:57:00 --> Input Class Initialized
INFO - 2017-02-03 19:57:00 --> Language Class Initialized
INFO - 2017-02-03 19:57:00 --> Loader Class Initialized
INFO - 2017-02-03 19:57:00 --> Database Driver Class Initialized
INFO - 2017-02-03 19:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:57:00 --> Controller Class Initialized
INFO - 2017-02-03 19:57:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:57:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:57:01 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:57:01 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:57:01 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:57:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:57:37 --> Config Class Initialized
INFO - 2017-02-03 19:57:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:57:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:57:37 --> Utf8 Class Initialized
INFO - 2017-02-03 19:57:37 --> URI Class Initialized
DEBUG - 2017-02-03 19:57:37 --> No URI present. Default controller set.
INFO - 2017-02-03 19:57:37 --> Router Class Initialized
INFO - 2017-02-03 19:57:37 --> Output Class Initialized
INFO - 2017-02-03 19:57:37 --> Security Class Initialized
DEBUG - 2017-02-03 19:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:57:37 --> Input Class Initialized
INFO - 2017-02-03 19:57:37 --> Language Class Initialized
INFO - 2017-02-03 19:57:37 --> Loader Class Initialized
INFO - 2017-02-03 19:57:37 --> Database Driver Class Initialized
INFO - 2017-02-03 19:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:57:37 --> Controller Class Initialized
INFO - 2017-02-03 19:57:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:57:37 --> Final output sent to browser
DEBUG - 2017-02-03 19:57:37 --> Total execution time: 0.0131
INFO - 2017-02-03 19:57:53 --> Config Class Initialized
INFO - 2017-02-03 19:57:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:57:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:57:53 --> Utf8 Class Initialized
INFO - 2017-02-03 19:57:53 --> URI Class Initialized
INFO - 2017-02-03 19:57:53 --> Router Class Initialized
INFO - 2017-02-03 19:57:53 --> Output Class Initialized
INFO - 2017-02-03 19:57:53 --> Security Class Initialized
DEBUG - 2017-02-03 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:57:53 --> Input Class Initialized
INFO - 2017-02-03 19:57:53 --> Language Class Initialized
INFO - 2017-02-03 19:57:53 --> Loader Class Initialized
INFO - 2017-02-03 19:57:53 --> Database Driver Class Initialized
INFO - 2017-02-03 19:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:57:53 --> Controller Class Initialized
INFO - 2017-02-03 19:57:53 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:57:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:57:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:57:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:57:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:57:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:57:59 --> Config Class Initialized
INFO - 2017-02-03 19:57:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:57:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:57:59 --> Utf8 Class Initialized
INFO - 2017-02-03 19:57:59 --> URI Class Initialized
DEBUG - 2017-02-03 19:57:59 --> No URI present. Default controller set.
INFO - 2017-02-03 19:57:59 --> Router Class Initialized
INFO - 2017-02-03 19:57:59 --> Output Class Initialized
INFO - 2017-02-03 19:57:59 --> Security Class Initialized
DEBUG - 2017-02-03 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:57:59 --> Input Class Initialized
INFO - 2017-02-03 19:57:59 --> Language Class Initialized
INFO - 2017-02-03 19:57:59 --> Loader Class Initialized
INFO - 2017-02-03 19:57:59 --> Database Driver Class Initialized
INFO - 2017-02-03 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:57:59 --> Controller Class Initialized
INFO - 2017-02-03 19:57:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:57:59 --> Final output sent to browser
DEBUG - 2017-02-03 19:57:59 --> Total execution time: 0.0145
INFO - 2017-02-03 19:58:10 --> Config Class Initialized
INFO - 2017-02-03 19:58:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:58:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:58:10 --> Utf8 Class Initialized
INFO - 2017-02-03 19:58:10 --> URI Class Initialized
INFO - 2017-02-03 19:58:10 --> Router Class Initialized
INFO - 2017-02-03 19:58:10 --> Output Class Initialized
INFO - 2017-02-03 19:58:10 --> Security Class Initialized
DEBUG - 2017-02-03 19:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:58:10 --> Input Class Initialized
INFO - 2017-02-03 19:58:10 --> Language Class Initialized
INFO - 2017-02-03 19:58:10 --> Loader Class Initialized
INFO - 2017-02-03 19:58:10 --> Database Driver Class Initialized
INFO - 2017-02-03 19:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:58:10 --> Controller Class Initialized
INFO - 2017-02-03 19:58:10 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:58:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:58:11 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:58:11 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:58:11 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:58:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 19:59:13 --> Config Class Initialized
INFO - 2017-02-03 19:59:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:59:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:59:13 --> Utf8 Class Initialized
INFO - 2017-02-03 19:59:13 --> URI Class Initialized
DEBUG - 2017-02-03 19:59:13 --> No URI present. Default controller set.
INFO - 2017-02-03 19:59:13 --> Router Class Initialized
INFO - 2017-02-03 19:59:13 --> Output Class Initialized
INFO - 2017-02-03 19:59:13 --> Security Class Initialized
DEBUG - 2017-02-03 19:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:59:13 --> Input Class Initialized
INFO - 2017-02-03 19:59:13 --> Language Class Initialized
INFO - 2017-02-03 19:59:13 --> Loader Class Initialized
INFO - 2017-02-03 19:59:13 --> Database Driver Class Initialized
INFO - 2017-02-03 19:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:59:13 --> Controller Class Initialized
INFO - 2017-02-03 19:59:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 19:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 19:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 19:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 19:59:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 19:59:13 --> Final output sent to browser
DEBUG - 2017-02-03 19:59:13 --> Total execution time: 0.0130
INFO - 2017-02-03 19:59:19 --> Config Class Initialized
INFO - 2017-02-03 19:59:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 19:59:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 19:59:19 --> Utf8 Class Initialized
INFO - 2017-02-03 19:59:19 --> URI Class Initialized
INFO - 2017-02-03 19:59:19 --> Router Class Initialized
INFO - 2017-02-03 19:59:19 --> Output Class Initialized
INFO - 2017-02-03 19:59:19 --> Security Class Initialized
DEBUG - 2017-02-03 19:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 19:59:19 --> Input Class Initialized
INFO - 2017-02-03 19:59:19 --> Language Class Initialized
INFO - 2017-02-03 19:59:19 --> Loader Class Initialized
INFO - 2017-02-03 19:59:19 --> Database Driver Class Initialized
INFO - 2017-02-03 19:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 19:59:19 --> Controller Class Initialized
INFO - 2017-02-03 19:59:19 --> Helper loaded: url_helper
DEBUG - 2017-02-03 19:59:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 19:59:20 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 19:59:20 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 19:59:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 19:59:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 20:00:21 --> Config Class Initialized
INFO - 2017-02-03 20:00:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:00:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:00:21 --> Utf8 Class Initialized
INFO - 2017-02-03 20:00:21 --> URI Class Initialized
DEBUG - 2017-02-03 20:00:21 --> No URI present. Default controller set.
INFO - 2017-02-03 20:00:21 --> Router Class Initialized
INFO - 2017-02-03 20:00:21 --> Output Class Initialized
INFO - 2017-02-03 20:00:21 --> Security Class Initialized
DEBUG - 2017-02-03 20:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:00:21 --> Input Class Initialized
INFO - 2017-02-03 20:00:21 --> Language Class Initialized
INFO - 2017-02-03 20:00:21 --> Loader Class Initialized
INFO - 2017-02-03 20:00:21 --> Database Driver Class Initialized
INFO - 2017-02-03 20:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:00:21 --> Controller Class Initialized
INFO - 2017-02-03 20:00:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:00:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:00:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:00:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:00:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:00:21 --> Final output sent to browser
DEBUG - 2017-02-03 20:00:21 --> Total execution time: 0.0134
INFO - 2017-02-03 20:01:09 --> Config Class Initialized
INFO - 2017-02-03 20:01:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:01:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:01:09 --> Utf8 Class Initialized
INFO - 2017-02-03 20:01:09 --> URI Class Initialized
INFO - 2017-02-03 20:01:09 --> Router Class Initialized
INFO - 2017-02-03 20:01:09 --> Output Class Initialized
INFO - 2017-02-03 20:01:09 --> Security Class Initialized
DEBUG - 2017-02-03 20:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:01:09 --> Input Class Initialized
INFO - 2017-02-03 20:01:09 --> Language Class Initialized
INFO - 2017-02-03 20:01:09 --> Loader Class Initialized
INFO - 2017-02-03 20:01:09 --> Database Driver Class Initialized
INFO - 2017-02-03 20:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:01:09 --> Controller Class Initialized
INFO - 2017-02-03 20:01:09 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:01:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 20:01:10 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 20:01:10 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Lilí Fajardo')
INFO - 2017-02-03 20:01:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 20:01:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 20:01:13 --> Config Class Initialized
INFO - 2017-02-03 20:01:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:01:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:01:13 --> Utf8 Class Initialized
INFO - 2017-02-03 20:01:13 --> URI Class Initialized
DEBUG - 2017-02-03 20:01:13 --> No URI present. Default controller set.
INFO - 2017-02-03 20:01:13 --> Router Class Initialized
INFO - 2017-02-03 20:01:13 --> Output Class Initialized
INFO - 2017-02-03 20:01:13 --> Security Class Initialized
DEBUG - 2017-02-03 20:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:01:13 --> Input Class Initialized
INFO - 2017-02-03 20:01:13 --> Language Class Initialized
INFO - 2017-02-03 20:01:13 --> Loader Class Initialized
INFO - 2017-02-03 20:01:13 --> Database Driver Class Initialized
INFO - 2017-02-03 20:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:01:13 --> Controller Class Initialized
INFO - 2017-02-03 20:01:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:01:13 --> Final output sent to browser
DEBUG - 2017-02-03 20:01:13 --> Total execution time: 0.0145
INFO - 2017-02-03 20:10:00 --> Config Class Initialized
INFO - 2017-02-03 20:10:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:10:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:10:00 --> Utf8 Class Initialized
INFO - 2017-02-03 20:10:00 --> URI Class Initialized
INFO - 2017-02-03 20:10:00 --> Router Class Initialized
INFO - 2017-02-03 20:10:00 --> Output Class Initialized
INFO - 2017-02-03 20:10:00 --> Security Class Initialized
DEBUG - 2017-02-03 20:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:10:00 --> Input Class Initialized
INFO - 2017-02-03 20:10:00 --> Language Class Initialized
INFO - 2017-02-03 20:10:00 --> Loader Class Initialized
INFO - 2017-02-03 20:10:00 --> Database Driver Class Initialized
INFO - 2017-02-03 20:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:10:00 --> Controller Class Initialized
INFO - 2017-02-03 20:10:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:10:00 --> Final output sent to browser
DEBUG - 2017-02-03 20:10:00 --> Total execution time: 0.0151
INFO - 2017-02-03 20:10:00 --> Config Class Initialized
INFO - 2017-02-03 20:10:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:10:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:10:00 --> Utf8 Class Initialized
INFO - 2017-02-03 20:10:00 --> URI Class Initialized
DEBUG - 2017-02-03 20:10:00 --> No URI present. Default controller set.
INFO - 2017-02-03 20:10:00 --> Router Class Initialized
INFO - 2017-02-03 20:10:00 --> Output Class Initialized
INFO - 2017-02-03 20:10:00 --> Security Class Initialized
DEBUG - 2017-02-03 20:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:10:00 --> Input Class Initialized
INFO - 2017-02-03 20:10:00 --> Language Class Initialized
INFO - 2017-02-03 20:10:00 --> Loader Class Initialized
INFO - 2017-02-03 20:10:00 --> Database Driver Class Initialized
INFO - 2017-02-03 20:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:10:00 --> Controller Class Initialized
INFO - 2017-02-03 20:10:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:10:00 --> Final output sent to browser
DEBUG - 2017-02-03 20:10:00 --> Total execution time: 0.0137
INFO - 2017-02-03 20:10:42 --> Config Class Initialized
INFO - 2017-02-03 20:10:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:10:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:10:42 --> Utf8 Class Initialized
INFO - 2017-02-03 20:10:42 --> URI Class Initialized
DEBUG - 2017-02-03 20:10:42 --> No URI present. Default controller set.
INFO - 2017-02-03 20:10:42 --> Router Class Initialized
INFO - 2017-02-03 20:10:42 --> Output Class Initialized
INFO - 2017-02-03 20:10:42 --> Security Class Initialized
DEBUG - 2017-02-03 20:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:10:42 --> Input Class Initialized
INFO - 2017-02-03 20:10:42 --> Language Class Initialized
INFO - 2017-02-03 20:10:42 --> Loader Class Initialized
INFO - 2017-02-03 20:10:42 --> Database Driver Class Initialized
INFO - 2017-02-03 20:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:10:42 --> Controller Class Initialized
INFO - 2017-02-03 20:10:42 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:10:42 --> Final output sent to browser
DEBUG - 2017-02-03 20:10:42 --> Total execution time: 0.0283
INFO - 2017-02-03 20:10:45 --> Config Class Initialized
INFO - 2017-02-03 20:10:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:10:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:10:45 --> Utf8 Class Initialized
INFO - 2017-02-03 20:10:45 --> URI Class Initialized
INFO - 2017-02-03 20:10:45 --> Router Class Initialized
INFO - 2017-02-03 20:10:45 --> Output Class Initialized
INFO - 2017-02-03 20:10:45 --> Security Class Initialized
DEBUG - 2017-02-03 20:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:10:45 --> Input Class Initialized
INFO - 2017-02-03 20:10:45 --> Language Class Initialized
INFO - 2017-02-03 20:10:45 --> Loader Class Initialized
INFO - 2017-02-03 20:10:45 --> Database Driver Class Initialized
INFO - 2017-02-03 20:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:10:45 --> Controller Class Initialized
INFO - 2017-02-03 20:10:45 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:10:45 --> Final output sent to browser
DEBUG - 2017-02-03 20:10:45 --> Total execution time: 0.0133
INFO - 2017-02-03 20:11:11 --> Config Class Initialized
INFO - 2017-02-03 20:11:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:11:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:11:11 --> Utf8 Class Initialized
INFO - 2017-02-03 20:11:11 --> URI Class Initialized
INFO - 2017-02-03 20:11:11 --> Router Class Initialized
INFO - 2017-02-03 20:11:11 --> Output Class Initialized
INFO - 2017-02-03 20:11:11 --> Security Class Initialized
DEBUG - 2017-02-03 20:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:11:11 --> Input Class Initialized
INFO - 2017-02-03 20:11:11 --> Language Class Initialized
INFO - 2017-02-03 20:11:11 --> Loader Class Initialized
INFO - 2017-02-03 20:11:11 --> Database Driver Class Initialized
INFO - 2017-02-03 20:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:11:11 --> Controller Class Initialized
INFO - 2017-02-03 20:11:11 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:11:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 20:11:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 20:11:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Myroslava Rodriguez')
INFO - 2017-02-03 20:11:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 20:11:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 20:11:13 --> Config Class Initialized
INFO - 2017-02-03 20:11:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:11:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:11:13 --> Utf8 Class Initialized
INFO - 2017-02-03 20:11:13 --> URI Class Initialized
INFO - 2017-02-03 20:11:13 --> Router Class Initialized
INFO - 2017-02-03 20:11:13 --> Output Class Initialized
INFO - 2017-02-03 20:11:13 --> Security Class Initialized
DEBUG - 2017-02-03 20:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:11:13 --> Input Class Initialized
INFO - 2017-02-03 20:11:13 --> Language Class Initialized
INFO - 2017-02-03 20:11:13 --> Loader Class Initialized
INFO - 2017-02-03 20:11:13 --> Database Driver Class Initialized
INFO - 2017-02-03 20:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:11:13 --> Controller Class Initialized
INFO - 2017-02-03 20:11:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:11:13 --> Final output sent to browser
DEBUG - 2017-02-03 20:11:13 --> Total execution time: 0.0129
INFO - 2017-02-03 20:11:18 --> Config Class Initialized
INFO - 2017-02-03 20:11:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:11:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:11:18 --> Utf8 Class Initialized
INFO - 2017-02-03 20:11:18 --> URI Class Initialized
INFO - 2017-02-03 20:11:18 --> Router Class Initialized
INFO - 2017-02-03 20:11:18 --> Output Class Initialized
INFO - 2017-02-03 20:11:18 --> Security Class Initialized
DEBUG - 2017-02-03 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:11:18 --> Input Class Initialized
INFO - 2017-02-03 20:11:18 --> Language Class Initialized
INFO - 2017-02-03 20:11:18 --> Loader Class Initialized
INFO - 2017-02-03 20:11:18 --> Database Driver Class Initialized
INFO - 2017-02-03 20:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:11:18 --> Controller Class Initialized
INFO - 2017-02-03 20:11:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:11:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 20:11:18 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 20:11:18 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Myroslava Rodriguez')
INFO - 2017-02-03 20:11:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 20:11:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 20:11:18 --> Config Class Initialized
INFO - 2017-02-03 20:11:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:11:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:11:18 --> Utf8 Class Initialized
INFO - 2017-02-03 20:11:18 --> URI Class Initialized
INFO - 2017-02-03 20:11:18 --> Router Class Initialized
INFO - 2017-02-03 20:11:18 --> Output Class Initialized
INFO - 2017-02-03 20:11:18 --> Security Class Initialized
DEBUG - 2017-02-03 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:11:18 --> Input Class Initialized
INFO - 2017-02-03 20:11:18 --> Language Class Initialized
INFO - 2017-02-03 20:11:18 --> Loader Class Initialized
INFO - 2017-02-03 20:11:18 --> Database Driver Class Initialized
INFO - 2017-02-03 20:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:11:18 --> Controller Class Initialized
INFO - 2017-02-03 20:11:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:11:18 --> Final output sent to browser
DEBUG - 2017-02-03 20:11:18 --> Total execution time: 0.0133
INFO - 2017-02-03 20:11:21 --> Config Class Initialized
INFO - 2017-02-03 20:11:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:11:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:11:21 --> Utf8 Class Initialized
INFO - 2017-02-03 20:11:21 --> URI Class Initialized
DEBUG - 2017-02-03 20:11:21 --> No URI present. Default controller set.
INFO - 2017-02-03 20:11:21 --> Router Class Initialized
INFO - 2017-02-03 20:11:21 --> Output Class Initialized
INFO - 2017-02-03 20:11:21 --> Security Class Initialized
DEBUG - 2017-02-03 20:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:11:21 --> Input Class Initialized
INFO - 2017-02-03 20:11:21 --> Language Class Initialized
INFO - 2017-02-03 20:11:21 --> Loader Class Initialized
INFO - 2017-02-03 20:11:22 --> Database Driver Class Initialized
INFO - 2017-02-03 20:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:11:22 --> Controller Class Initialized
INFO - 2017-02-03 20:11:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:11:22 --> Final output sent to browser
DEBUG - 2017-02-03 20:11:22 --> Total execution time: 0.0144
INFO - 2017-02-03 20:11:23 --> Config Class Initialized
INFO - 2017-02-03 20:11:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:11:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:11:23 --> Utf8 Class Initialized
INFO - 2017-02-03 20:11:23 --> URI Class Initialized
INFO - 2017-02-03 20:11:23 --> Router Class Initialized
INFO - 2017-02-03 20:11:23 --> Output Class Initialized
INFO - 2017-02-03 20:11:23 --> Security Class Initialized
DEBUG - 2017-02-03 20:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:11:23 --> Input Class Initialized
INFO - 2017-02-03 20:11:23 --> Language Class Initialized
INFO - 2017-02-03 20:11:23 --> Loader Class Initialized
INFO - 2017-02-03 20:11:23 --> Database Driver Class Initialized
INFO - 2017-02-03 20:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:11:23 --> Controller Class Initialized
INFO - 2017-02-03 20:11:23 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:11:23 --> Final output sent to browser
DEBUG - 2017-02-03 20:11:23 --> Total execution time: 0.0139
INFO - 2017-02-03 20:12:03 --> Config Class Initialized
INFO - 2017-02-03 20:12:03 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:03 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:03 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:03 --> URI Class Initialized
INFO - 2017-02-03 20:12:03 --> Router Class Initialized
INFO - 2017-02-03 20:12:03 --> Output Class Initialized
INFO - 2017-02-03 20:12:03 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:03 --> Input Class Initialized
INFO - 2017-02-03 20:12:03 --> Language Class Initialized
INFO - 2017-02-03 20:12:03 --> Loader Class Initialized
INFO - 2017-02-03 20:12:03 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:03 --> Controller Class Initialized
INFO - 2017-02-03 20:12:03 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:03 --> Config Class Initialized
INFO - 2017-02-03 20:12:03 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:03 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:03 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:03 --> URI Class Initialized
INFO - 2017-02-03 20:12:03 --> Router Class Initialized
INFO - 2017-02-03 20:12:03 --> Output Class Initialized
INFO - 2017-02-03 20:12:03 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:03 --> Input Class Initialized
INFO - 2017-02-03 20:12:03 --> Language Class Initialized
INFO - 2017-02-03 20:12:03 --> Loader Class Initialized
INFO - 2017-02-03 20:12:03 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:03 --> Controller Class Initialized
INFO - 2017-02-03 20:12:03 --> Helper loaded: date_helper
DEBUG - 2017-02-03 20:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:03 --> Helper loaded: url_helper
INFO - 2017-02-03 20:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 20:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 20:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 20:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:12:03 --> Final output sent to browser
DEBUG - 2017-02-03 20:12:03 --> Total execution time: 0.0140
INFO - 2017-02-03 20:12:04 --> Config Class Initialized
INFO - 2017-02-03 20:12:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:04 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:04 --> URI Class Initialized
INFO - 2017-02-03 20:12:04 --> Router Class Initialized
INFO - 2017-02-03 20:12:04 --> Output Class Initialized
INFO - 2017-02-03 20:12:04 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:04 --> Input Class Initialized
INFO - 2017-02-03 20:12:04 --> Language Class Initialized
INFO - 2017-02-03 20:12:04 --> Loader Class Initialized
INFO - 2017-02-03 20:12:04 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:04 --> Controller Class Initialized
INFO - 2017-02-03 20:12:04 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:12:04 --> Final output sent to browser
DEBUG - 2017-02-03 20:12:04 --> Total execution time: 0.0137
INFO - 2017-02-03 20:12:10 --> Config Class Initialized
INFO - 2017-02-03 20:12:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:10 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:10 --> URI Class Initialized
DEBUG - 2017-02-03 20:12:10 --> No URI present. Default controller set.
INFO - 2017-02-03 20:12:10 --> Router Class Initialized
INFO - 2017-02-03 20:12:10 --> Output Class Initialized
INFO - 2017-02-03 20:12:10 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:10 --> Input Class Initialized
INFO - 2017-02-03 20:12:10 --> Language Class Initialized
INFO - 2017-02-03 20:12:10 --> Loader Class Initialized
INFO - 2017-02-03 20:12:10 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:10 --> Controller Class Initialized
INFO - 2017-02-03 20:12:10 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:12:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:12:10 --> Final output sent to browser
DEBUG - 2017-02-03 20:12:10 --> Total execution time: 0.0132
INFO - 2017-02-03 20:12:11 --> Config Class Initialized
INFO - 2017-02-03 20:12:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:11 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:11 --> URI Class Initialized
INFO - 2017-02-03 20:12:11 --> Router Class Initialized
INFO - 2017-02-03 20:12:11 --> Output Class Initialized
INFO - 2017-02-03 20:12:11 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:11 --> Input Class Initialized
INFO - 2017-02-03 20:12:11 --> Language Class Initialized
INFO - 2017-02-03 20:12:11 --> Loader Class Initialized
INFO - 2017-02-03 20:12:11 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:11 --> Controller Class Initialized
INFO - 2017-02-03 20:12:11 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:12:11 --> Final output sent to browser
DEBUG - 2017-02-03 20:12:11 --> Total execution time: 0.0129
INFO - 2017-02-03 20:12:17 --> Config Class Initialized
INFO - 2017-02-03 20:12:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:17 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:17 --> URI Class Initialized
INFO - 2017-02-03 20:12:17 --> Router Class Initialized
INFO - 2017-02-03 20:12:17 --> Output Class Initialized
INFO - 2017-02-03 20:12:17 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:17 --> Input Class Initialized
INFO - 2017-02-03 20:12:17 --> Language Class Initialized
INFO - 2017-02-03 20:12:17 --> Loader Class Initialized
INFO - 2017-02-03 20:12:17 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:17 --> Controller Class Initialized
INFO - 2017-02-03 20:12:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 20:12:18 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 20:12:18 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Myroslava Rodriguez')
INFO - 2017-02-03 20:12:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 20:12:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 20:12:18 --> Config Class Initialized
INFO - 2017-02-03 20:12:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:18 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:18 --> URI Class Initialized
INFO - 2017-02-03 20:12:18 --> Router Class Initialized
INFO - 2017-02-03 20:12:18 --> Output Class Initialized
INFO - 2017-02-03 20:12:18 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:18 --> Input Class Initialized
INFO - 2017-02-03 20:12:18 --> Language Class Initialized
INFO - 2017-02-03 20:12:18 --> Loader Class Initialized
INFO - 2017-02-03 20:12:18 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:18 --> Controller Class Initialized
INFO - 2017-02-03 20:12:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:12:18 --> Final output sent to browser
DEBUG - 2017-02-03 20:12:18 --> Total execution time: 0.0140
INFO - 2017-02-03 20:12:21 --> Config Class Initialized
INFO - 2017-02-03 20:12:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:21 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:21 --> URI Class Initialized
DEBUG - 2017-02-03 20:12:21 --> No URI present. Default controller set.
INFO - 2017-02-03 20:12:21 --> Router Class Initialized
INFO - 2017-02-03 20:12:21 --> Output Class Initialized
INFO - 2017-02-03 20:12:21 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:21 --> Input Class Initialized
INFO - 2017-02-03 20:12:21 --> Language Class Initialized
INFO - 2017-02-03 20:12:21 --> Loader Class Initialized
INFO - 2017-02-03 20:12:21 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:21 --> Controller Class Initialized
INFO - 2017-02-03 20:12:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:12:21 --> Final output sent to browser
DEBUG - 2017-02-03 20:12:21 --> Total execution time: 0.0133
INFO - 2017-02-03 20:12:22 --> Config Class Initialized
INFO - 2017-02-03 20:12:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:12:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:12:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:12:22 --> URI Class Initialized
INFO - 2017-02-03 20:12:22 --> Router Class Initialized
INFO - 2017-02-03 20:12:22 --> Output Class Initialized
INFO - 2017-02-03 20:12:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:12:22 --> Input Class Initialized
INFO - 2017-02-03 20:12:22 --> Language Class Initialized
INFO - 2017-02-03 20:12:22 --> Loader Class Initialized
INFO - 2017-02-03 20:12:22 --> Database Driver Class Initialized
INFO - 2017-02-03 20:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:12:22 --> Controller Class Initialized
INFO - 2017-02-03 20:12:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:12:22 --> Final output sent to browser
DEBUG - 2017-02-03 20:12:22 --> Total execution time: 0.0149
INFO - 2017-02-03 20:32:56 --> Config Class Initialized
INFO - 2017-02-03 20:32:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:56 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:56 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:56 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:56 --> Router Class Initialized
INFO - 2017-02-03 20:32:56 --> Output Class Initialized
INFO - 2017-02-03 20:32:56 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:56 --> Input Class Initialized
INFO - 2017-02-03 20:32:56 --> Language Class Initialized
INFO - 2017-02-03 20:32:56 --> Loader Class Initialized
INFO - 2017-02-03 20:32:56 --> Database Driver Class Initialized
INFO - 2017-02-03 20:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:32:56 --> Controller Class Initialized
INFO - 2017-02-03 20:32:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:32:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:32:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:32:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:32:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:32:56 --> Final output sent to browser
DEBUG - 2017-02-03 20:32:56 --> Total execution time: 0.0614
INFO - 2017-02-03 20:32:59 --> Config Class Initialized
INFO - 2017-02-03 20:32:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:59 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:59 --> URI Class Initialized
INFO - 2017-02-03 20:32:59 --> Router Class Initialized
INFO - 2017-02-03 20:32:59 --> Output Class Initialized
INFO - 2017-02-03 20:32:59 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:59 --> Input Class Initialized
INFO - 2017-02-03 20:32:59 --> Language Class Initialized
INFO - 2017-02-03 20:32:59 --> Loader Class Initialized
INFO - 2017-02-03 20:32:59 --> Database Driver Class Initialized
INFO - 2017-02-03 20:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:32:59 --> Controller Class Initialized
INFO - 2017-02-03 20:32:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:32:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:32:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:32:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:32:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:32:59 --> Final output sent to browser
DEBUG - 2017-02-03 20:32:59 --> Total execution time: 0.0133
INFO - 2017-02-03 20:33:10 --> Config Class Initialized
INFO - 2017-02-03 20:33:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:10 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:10 --> URI Class Initialized
INFO - 2017-02-03 20:33:10 --> Router Class Initialized
INFO - 2017-02-03 20:33:10 --> Output Class Initialized
INFO - 2017-02-03 20:33:10 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:10 --> Input Class Initialized
INFO - 2017-02-03 20:33:10 --> Language Class Initialized
INFO - 2017-02-03 20:33:10 --> Loader Class Initialized
INFO - 2017-02-03 20:33:10 --> Database Driver Class Initialized
INFO - 2017-02-03 20:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:33:10 --> Controller Class Initialized
INFO - 2017-02-03 20:33:10 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:33:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:33:11 --> Config Class Initialized
INFO - 2017-02-03 20:33:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:11 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:11 --> URI Class Initialized
INFO - 2017-02-03 20:33:11 --> Router Class Initialized
INFO - 2017-02-03 20:33:11 --> Output Class Initialized
INFO - 2017-02-03 20:33:11 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:11 --> Input Class Initialized
INFO - 2017-02-03 20:33:11 --> Language Class Initialized
INFO - 2017-02-03 20:33:11 --> Loader Class Initialized
INFO - 2017-02-03 20:33:11 --> Database Driver Class Initialized
INFO - 2017-02-03 20:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:33:11 --> Controller Class Initialized
INFO - 2017-02-03 20:33:11 --> Helper loaded: date_helper
DEBUG - 2017-02-03 20:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:33:11 --> Helper loaded: url_helper
INFO - 2017-02-03 20:33:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:33:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 20:33:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 20:33:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 20:33:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:33:11 --> Final output sent to browser
DEBUG - 2017-02-03 20:33:11 --> Total execution time: 0.0143
INFO - 2017-02-03 20:33:11 --> Config Class Initialized
INFO - 2017-02-03 20:33:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:11 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:11 --> URI Class Initialized
INFO - 2017-02-03 20:33:11 --> Router Class Initialized
INFO - 2017-02-03 20:33:11 --> Output Class Initialized
INFO - 2017-02-03 20:33:11 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:11 --> Input Class Initialized
INFO - 2017-02-03 20:33:12 --> Language Class Initialized
INFO - 2017-02-03 20:33:12 --> Loader Class Initialized
INFO - 2017-02-03 20:33:12 --> Database Driver Class Initialized
INFO - 2017-02-03 20:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:33:12 --> Controller Class Initialized
INFO - 2017-02-03 20:33:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:33:12 --> Final output sent to browser
DEBUG - 2017-02-03 20:33:12 --> Total execution time: 0.0133
INFO - 2017-02-03 20:33:24 --> Config Class Initialized
INFO - 2017-02-03 20:33:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:24 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:24 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:24 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:24 --> Router Class Initialized
INFO - 2017-02-03 20:33:24 --> Output Class Initialized
INFO - 2017-02-03 20:33:24 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:24 --> Input Class Initialized
INFO - 2017-02-03 20:33:24 --> Language Class Initialized
INFO - 2017-02-03 20:33:24 --> Loader Class Initialized
INFO - 2017-02-03 20:33:24 --> Database Driver Class Initialized
INFO - 2017-02-03 20:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:33:24 --> Controller Class Initialized
INFO - 2017-02-03 20:33:24 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:33:24 --> Final output sent to browser
DEBUG - 2017-02-03 20:33:24 --> Total execution time: 0.0135
INFO - 2017-02-03 20:33:25 --> Config Class Initialized
INFO - 2017-02-03 20:33:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:25 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:25 --> URI Class Initialized
INFO - 2017-02-03 20:33:25 --> Router Class Initialized
INFO - 2017-02-03 20:33:25 --> Output Class Initialized
INFO - 2017-02-03 20:33:25 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:25 --> Input Class Initialized
INFO - 2017-02-03 20:33:25 --> Language Class Initialized
INFO - 2017-02-03 20:33:25 --> Loader Class Initialized
INFO - 2017-02-03 20:33:25 --> Database Driver Class Initialized
INFO - 2017-02-03 20:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:33:25 --> Controller Class Initialized
INFO - 2017-02-03 20:33:25 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:33:25 --> Final output sent to browser
DEBUG - 2017-02-03 20:33:25 --> Total execution time: 0.0133
INFO - 2017-02-03 20:38:56 --> Config Class Initialized
INFO - 2017-02-03 20:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 20:38:56 --> URI Class Initialized
INFO - 2017-02-03 20:38:56 --> Router Class Initialized
INFO - 2017-02-03 20:38:56 --> Output Class Initialized
INFO - 2017-02-03 20:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 20:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:38:56 --> Input Class Initialized
INFO - 2017-02-03 20:38:56 --> Language Class Initialized
ERROR - 2017-02-03 20:38:56 --> 404 Page Not Found: Tablet/hoteles-sede.html
INFO - 2017-02-03 20:39:02 --> Config Class Initialized
INFO - 2017-02-03 20:39:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:39:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:39:02 --> Utf8 Class Initialized
INFO - 2017-02-03 20:39:02 --> URI Class Initialized
INFO - 2017-02-03 20:39:02 --> Router Class Initialized
INFO - 2017-02-03 20:39:02 --> Output Class Initialized
INFO - 2017-02-03 20:39:02 --> Security Class Initialized
DEBUG - 2017-02-03 20:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:39:02 --> Input Class Initialized
INFO - 2017-02-03 20:39:02 --> Language Class Initialized
ERROR - 2017-02-03 20:39:02 --> 404 Page Not Found: Tablet/hoteles-sede.html
INFO - 2017-02-03 20:39:39 --> Config Class Initialized
INFO - 2017-02-03 20:39:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:39:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:39:39 --> Utf8 Class Initialized
INFO - 2017-02-03 20:39:39 --> URI Class Initialized
DEBUG - 2017-02-03 20:39:39 --> No URI present. Default controller set.
INFO - 2017-02-03 20:39:39 --> Router Class Initialized
INFO - 2017-02-03 20:39:39 --> Output Class Initialized
INFO - 2017-02-03 20:39:39 --> Security Class Initialized
DEBUG - 2017-02-03 20:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:39:39 --> Input Class Initialized
INFO - 2017-02-03 20:39:39 --> Language Class Initialized
INFO - 2017-02-03 20:39:39 --> Loader Class Initialized
INFO - 2017-02-03 20:39:39 --> Database Driver Class Initialized
INFO - 2017-02-03 20:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:39:39 --> Controller Class Initialized
INFO - 2017-02-03 20:39:39 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:39:39 --> Final output sent to browser
DEBUG - 2017-02-03 20:39:39 --> Total execution time: 0.0133
INFO - 2017-02-03 20:40:06 --> Config Class Initialized
INFO - 2017-02-03 20:40:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:06 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:06 --> URI Class Initialized
INFO - 2017-02-03 20:40:06 --> Router Class Initialized
INFO - 2017-02-03 20:40:06 --> Output Class Initialized
INFO - 2017-02-03 20:40:06 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:06 --> Input Class Initialized
INFO - 2017-02-03 20:40:06 --> Language Class Initialized
INFO - 2017-02-03 20:40:06 --> Loader Class Initialized
INFO - 2017-02-03 20:40:06 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:40:06 --> Controller Class Initialized
INFO - 2017-02-03 20:40:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:40:07 --> Config Class Initialized
INFO - 2017-02-03 20:40:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:07 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:07 --> URI Class Initialized
INFO - 2017-02-03 20:40:07 --> Router Class Initialized
INFO - 2017-02-03 20:40:07 --> Output Class Initialized
INFO - 2017-02-03 20:40:07 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:07 --> Input Class Initialized
INFO - 2017-02-03 20:40:07 --> Language Class Initialized
INFO - 2017-02-03 20:40:07 --> Loader Class Initialized
INFO - 2017-02-03 20:40:07 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:40:07 --> Controller Class Initialized
INFO - 2017-02-03 20:40:07 --> Helper loaded: date_helper
DEBUG - 2017-02-03 20:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:40:07 --> Helper loaded: url_helper
INFO - 2017-02-03 20:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 20:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 20:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 20:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:40:07 --> Final output sent to browser
DEBUG - 2017-02-03 20:40:07 --> Total execution time: 0.0136
INFO - 2017-02-03 20:40:12 --> Config Class Initialized
INFO - 2017-02-03 20:40:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:12 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:12 --> URI Class Initialized
DEBUG - 2017-02-03 20:40:12 --> No URI present. Default controller set.
INFO - 2017-02-03 20:40:12 --> Router Class Initialized
INFO - 2017-02-03 20:40:12 --> Output Class Initialized
INFO - 2017-02-03 20:40:12 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:12 --> Input Class Initialized
INFO - 2017-02-03 20:40:12 --> Language Class Initialized
INFO - 2017-02-03 20:40:12 --> Loader Class Initialized
INFO - 2017-02-03 20:40:12 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:40:12 --> Controller Class Initialized
INFO - 2017-02-03 20:40:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:40:12 --> Final output sent to browser
DEBUG - 2017-02-03 20:40:12 --> Total execution time: 0.0132
INFO - 2017-02-03 20:40:47 --> Config Class Initialized
INFO - 2017-02-03 20:40:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:47 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:47 --> URI Class Initialized
INFO - 2017-02-03 20:40:47 --> Router Class Initialized
INFO - 2017-02-03 20:40:47 --> Output Class Initialized
INFO - 2017-02-03 20:40:47 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:47 --> Input Class Initialized
INFO - 2017-02-03 20:40:47 --> Language Class Initialized
INFO - 2017-02-03 20:40:47 --> Loader Class Initialized
INFO - 2017-02-03 20:40:47 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:40:47 --> Controller Class Initialized
INFO - 2017-02-03 20:40:47 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:40:47 --> Final output sent to browser
DEBUG - 2017-02-03 20:40:47 --> Total execution time: 0.0137
INFO - 2017-02-03 20:40:51 --> Config Class Initialized
INFO - 2017-02-03 20:40:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:51 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:51 --> URI Class Initialized
INFO - 2017-02-03 20:40:51 --> Router Class Initialized
INFO - 2017-02-03 20:40:51 --> Output Class Initialized
INFO - 2017-02-03 20:40:51 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:51 --> Input Class Initialized
INFO - 2017-02-03 20:40:51 --> Language Class Initialized
INFO - 2017-02-03 20:40:51 --> Loader Class Initialized
INFO - 2017-02-03 20:40:51 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:40:51 --> Controller Class Initialized
INFO - 2017-02-03 20:40:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:40:51 --> Final output sent to browser
DEBUG - 2017-02-03 20:40:51 --> Total execution time: 0.0130
INFO - 2017-02-03 20:40:55 --> Config Class Initialized
INFO - 2017-02-03 20:40:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:55 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:55 --> URI Class Initialized
INFO - 2017-02-03 20:40:55 --> Router Class Initialized
INFO - 2017-02-03 20:40:55 --> Output Class Initialized
INFO - 2017-02-03 20:40:55 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:55 --> Input Class Initialized
INFO - 2017-02-03 20:40:55 --> Language Class Initialized
INFO - 2017-02-03 20:40:55 --> Loader Class Initialized
INFO - 2017-02-03 20:40:55 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:40:55 --> Controller Class Initialized
INFO - 2017-02-03 20:40:55 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:40:55 --> Final output sent to browser
DEBUG - 2017-02-03 20:40:55 --> Total execution time: 0.0344
INFO - 2017-02-03 20:40:58 --> Config Class Initialized
INFO - 2017-02-03 20:40:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:58 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:58 --> URI Class Initialized
INFO - 2017-02-03 20:40:58 --> Router Class Initialized
INFO - 2017-02-03 20:40:58 --> Output Class Initialized
INFO - 2017-02-03 20:40:58 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:58 --> Input Class Initialized
INFO - 2017-02-03 20:40:58 --> Language Class Initialized
INFO - 2017-02-03 20:40:58 --> Loader Class Initialized
INFO - 2017-02-03 20:40:58 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:40:58 --> Controller Class Initialized
INFO - 2017-02-03 20:40:58 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:40:58 --> Final output sent to browser
DEBUG - 2017-02-03 20:40:58 --> Total execution time: 0.0148
INFO - 2017-02-03 20:41:00 --> Config Class Initialized
INFO - 2017-02-03 20:41:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:41:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:41:00 --> Utf8 Class Initialized
INFO - 2017-02-03 20:41:00 --> URI Class Initialized
INFO - 2017-02-03 20:41:00 --> Router Class Initialized
INFO - 2017-02-03 20:41:00 --> Output Class Initialized
INFO - 2017-02-03 20:41:00 --> Security Class Initialized
DEBUG - 2017-02-03 20:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:41:00 --> Input Class Initialized
INFO - 2017-02-03 20:41:00 --> Language Class Initialized
INFO - 2017-02-03 20:41:00 --> Loader Class Initialized
INFO - 2017-02-03 20:41:00 --> Database Driver Class Initialized
INFO - 2017-02-03 20:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:41:00 --> Controller Class Initialized
INFO - 2017-02-03 20:41:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:41:00 --> Final output sent to browser
DEBUG - 2017-02-03 20:41:00 --> Total execution time: 0.0138
INFO - 2017-02-03 20:41:05 --> Config Class Initialized
INFO - 2017-02-03 20:41:05 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:41:05 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:41:05 --> Utf8 Class Initialized
INFO - 2017-02-03 20:41:05 --> URI Class Initialized
INFO - 2017-02-03 20:41:05 --> Router Class Initialized
INFO - 2017-02-03 20:41:05 --> Output Class Initialized
INFO - 2017-02-03 20:41:05 --> Security Class Initialized
DEBUG - 2017-02-03 20:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:41:05 --> Input Class Initialized
INFO - 2017-02-03 20:41:05 --> Language Class Initialized
INFO - 2017-02-03 20:41:05 --> Loader Class Initialized
INFO - 2017-02-03 20:41:05 --> Database Driver Class Initialized
INFO - 2017-02-03 20:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:41:05 --> Controller Class Initialized
INFO - 2017-02-03 20:41:05 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:41:05 --> Final output sent to browser
DEBUG - 2017-02-03 20:41:05 --> Total execution time: 0.0136
INFO - 2017-02-03 20:41:06 --> Config Class Initialized
INFO - 2017-02-03 20:41:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:41:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:41:06 --> Utf8 Class Initialized
INFO - 2017-02-03 20:41:06 --> URI Class Initialized
INFO - 2017-02-03 20:41:06 --> Router Class Initialized
INFO - 2017-02-03 20:41:06 --> Output Class Initialized
INFO - 2017-02-03 20:41:06 --> Security Class Initialized
DEBUG - 2017-02-03 20:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:41:06 --> Input Class Initialized
INFO - 2017-02-03 20:41:06 --> Language Class Initialized
INFO - 2017-02-03 20:41:06 --> Loader Class Initialized
INFO - 2017-02-03 20:41:06 --> Database Driver Class Initialized
INFO - 2017-02-03 20:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 20:41:06 --> Controller Class Initialized
INFO - 2017-02-03 20:41:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 20:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 20:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 20:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 20:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 20:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 20:41:06 --> Final output sent to browser
DEBUG - 2017-02-03 20:41:06 --> Total execution time: 0.0221
INFO - 2017-02-03 21:14:33 --> Config Class Initialized
INFO - 2017-02-03 21:14:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:14:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:14:33 --> Utf8 Class Initialized
INFO - 2017-02-03 21:14:33 --> URI Class Initialized
DEBUG - 2017-02-03 21:14:33 --> No URI present. Default controller set.
INFO - 2017-02-03 21:14:33 --> Router Class Initialized
INFO - 2017-02-03 21:14:33 --> Output Class Initialized
INFO - 2017-02-03 21:14:33 --> Security Class Initialized
DEBUG - 2017-02-03 21:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:14:33 --> Input Class Initialized
INFO - 2017-02-03 21:14:33 --> Language Class Initialized
INFO - 2017-02-03 21:14:33 --> Loader Class Initialized
INFO - 2017-02-03 21:14:33 --> Database Driver Class Initialized
INFO - 2017-02-03 21:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:14:33 --> Controller Class Initialized
INFO - 2017-02-03 21:14:33 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:14:33 --> Final output sent to browser
DEBUG - 2017-02-03 21:14:33 --> Total execution time: 0.0136
INFO - 2017-02-03 21:14:39 --> Config Class Initialized
INFO - 2017-02-03 21:14:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:14:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:14:39 --> Utf8 Class Initialized
INFO - 2017-02-03 21:14:39 --> URI Class Initialized
INFO - 2017-02-03 21:14:39 --> Router Class Initialized
INFO - 2017-02-03 21:14:39 --> Output Class Initialized
INFO - 2017-02-03 21:14:39 --> Security Class Initialized
DEBUG - 2017-02-03 21:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:14:39 --> Input Class Initialized
INFO - 2017-02-03 21:14:39 --> Language Class Initialized
INFO - 2017-02-03 21:14:39 --> Loader Class Initialized
INFO - 2017-02-03 21:14:39 --> Database Driver Class Initialized
INFO - 2017-02-03 21:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:14:39 --> Controller Class Initialized
INFO - 2017-02-03 21:14:39 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:14:39 --> Final output sent to browser
DEBUG - 2017-02-03 21:14:39 --> Total execution time: 0.0137
INFO - 2017-02-03 21:15:12 --> Config Class Initialized
INFO - 2017-02-03 21:15:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:15:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:15:12 --> Utf8 Class Initialized
INFO - 2017-02-03 21:15:12 --> URI Class Initialized
INFO - 2017-02-03 21:15:12 --> Router Class Initialized
INFO - 2017-02-03 21:15:12 --> Output Class Initialized
INFO - 2017-02-03 21:15:12 --> Security Class Initialized
DEBUG - 2017-02-03 21:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:15:12 --> Input Class Initialized
INFO - 2017-02-03 21:15:12 --> Language Class Initialized
INFO - 2017-02-03 21:15:12 --> Loader Class Initialized
INFO - 2017-02-03 21:15:12 --> Database Driver Class Initialized
INFO - 2017-02-03 21:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:15:12 --> Controller Class Initialized
INFO - 2017-02-03 21:15:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:15:12 --> Config Class Initialized
INFO - 2017-02-03 21:15:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:15:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:15:12 --> Utf8 Class Initialized
INFO - 2017-02-03 21:15:12 --> URI Class Initialized
INFO - 2017-02-03 21:15:12 --> Router Class Initialized
INFO - 2017-02-03 21:15:12 --> Output Class Initialized
INFO - 2017-02-03 21:15:12 --> Security Class Initialized
DEBUG - 2017-02-03 21:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:15:12 --> Input Class Initialized
INFO - 2017-02-03 21:15:12 --> Language Class Initialized
INFO - 2017-02-03 21:15:12 --> Loader Class Initialized
INFO - 2017-02-03 21:15:12 --> Database Driver Class Initialized
INFO - 2017-02-03 21:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:15:12 --> Controller Class Initialized
INFO - 2017-02-03 21:15:12 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:15:12 --> Helper loaded: url_helper
INFO - 2017-02-03 21:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 21:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 21:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:15:12 --> Final output sent to browser
DEBUG - 2017-02-03 21:15:12 --> Total execution time: 0.0139
INFO - 2017-02-03 21:15:13 --> Config Class Initialized
INFO - 2017-02-03 21:15:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:15:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:15:13 --> Utf8 Class Initialized
INFO - 2017-02-03 21:15:13 --> URI Class Initialized
INFO - 2017-02-03 21:15:13 --> Router Class Initialized
INFO - 2017-02-03 21:15:13 --> Output Class Initialized
INFO - 2017-02-03 21:15:13 --> Security Class Initialized
DEBUG - 2017-02-03 21:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:15:13 --> Input Class Initialized
INFO - 2017-02-03 21:15:13 --> Language Class Initialized
INFO - 2017-02-03 21:15:13 --> Loader Class Initialized
INFO - 2017-02-03 21:15:13 --> Database Driver Class Initialized
INFO - 2017-02-03 21:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:15:13 --> Controller Class Initialized
INFO - 2017-02-03 21:15:13 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:15:13 --> Final output sent to browser
DEBUG - 2017-02-03 21:15:13 --> Total execution time: 0.0133
INFO - 2017-02-03 21:15:14 --> Config Class Initialized
INFO - 2017-02-03 21:15:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:15:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:15:14 --> Utf8 Class Initialized
INFO - 2017-02-03 21:15:14 --> URI Class Initialized
INFO - 2017-02-03 21:15:14 --> Router Class Initialized
INFO - 2017-02-03 21:15:14 --> Output Class Initialized
INFO - 2017-02-03 21:15:14 --> Security Class Initialized
DEBUG - 2017-02-03 21:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:15:14 --> Input Class Initialized
INFO - 2017-02-03 21:15:14 --> Language Class Initialized
INFO - 2017-02-03 21:15:14 --> Loader Class Initialized
INFO - 2017-02-03 21:15:14 --> Database Driver Class Initialized
INFO - 2017-02-03 21:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:15:14 --> Controller Class Initialized
INFO - 2017-02-03 21:15:14 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:15:14 --> Helper loaded: url_helper
INFO - 2017-02-03 21:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 21:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 21:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:15:14 --> Final output sent to browser
DEBUG - 2017-02-03 21:15:14 --> Total execution time: 0.0131
INFO - 2017-02-03 21:15:22 --> Config Class Initialized
INFO - 2017-02-03 21:15:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:15:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:15:22 --> Utf8 Class Initialized
INFO - 2017-02-03 21:15:22 --> URI Class Initialized
DEBUG - 2017-02-03 21:15:22 --> No URI present. Default controller set.
INFO - 2017-02-03 21:15:22 --> Router Class Initialized
INFO - 2017-02-03 21:15:22 --> Output Class Initialized
INFO - 2017-02-03 21:15:22 --> Security Class Initialized
DEBUG - 2017-02-03 21:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:15:22 --> Input Class Initialized
INFO - 2017-02-03 21:15:22 --> Language Class Initialized
INFO - 2017-02-03 21:15:22 --> Loader Class Initialized
INFO - 2017-02-03 21:15:22 --> Database Driver Class Initialized
INFO - 2017-02-03 21:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:15:22 --> Controller Class Initialized
INFO - 2017-02-03 21:15:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:15:22 --> Final output sent to browser
DEBUG - 2017-02-03 21:15:22 --> Total execution time: 0.0147
INFO - 2017-02-03 21:15:23 --> Config Class Initialized
INFO - 2017-02-03 21:15:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:15:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:15:23 --> Utf8 Class Initialized
INFO - 2017-02-03 21:15:23 --> URI Class Initialized
INFO - 2017-02-03 21:15:23 --> Router Class Initialized
INFO - 2017-02-03 21:15:23 --> Output Class Initialized
INFO - 2017-02-03 21:15:23 --> Security Class Initialized
DEBUG - 2017-02-03 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:15:23 --> Input Class Initialized
INFO - 2017-02-03 21:15:23 --> Language Class Initialized
INFO - 2017-02-03 21:15:23 --> Loader Class Initialized
INFO - 2017-02-03 21:15:23 --> Database Driver Class Initialized
INFO - 2017-02-03 21:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:15:23 --> Controller Class Initialized
INFO - 2017-02-03 21:15:23 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:15:23 --> Final output sent to browser
DEBUG - 2017-02-03 21:15:23 --> Total execution time: 0.0164
INFO - 2017-02-03 21:23:23 --> Config Class Initialized
INFO - 2017-02-03 21:23:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:23:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:23:23 --> Utf8 Class Initialized
INFO - 2017-02-03 21:23:23 --> URI Class Initialized
DEBUG - 2017-02-03 21:23:23 --> No URI present. Default controller set.
INFO - 2017-02-03 21:23:23 --> Router Class Initialized
INFO - 2017-02-03 21:23:23 --> Output Class Initialized
INFO - 2017-02-03 21:23:23 --> Security Class Initialized
DEBUG - 2017-02-03 21:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:23:23 --> Input Class Initialized
INFO - 2017-02-03 21:23:23 --> Language Class Initialized
INFO - 2017-02-03 21:23:23 --> Loader Class Initialized
INFO - 2017-02-03 21:23:23 --> Database Driver Class Initialized
INFO - 2017-02-03 21:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:23:23 --> Controller Class Initialized
INFO - 2017-02-03 21:23:23 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:23:23 --> Final output sent to browser
DEBUG - 2017-02-03 21:23:23 --> Total execution time: 0.0280
INFO - 2017-02-03 21:23:29 --> Config Class Initialized
INFO - 2017-02-03 21:23:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:23:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:23:29 --> Utf8 Class Initialized
INFO - 2017-02-03 21:23:29 --> URI Class Initialized
INFO - 2017-02-03 21:23:29 --> Router Class Initialized
INFO - 2017-02-03 21:23:29 --> Output Class Initialized
INFO - 2017-02-03 21:23:29 --> Security Class Initialized
DEBUG - 2017-02-03 21:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:23:29 --> Input Class Initialized
INFO - 2017-02-03 21:23:29 --> Language Class Initialized
INFO - 2017-02-03 21:23:29 --> Loader Class Initialized
INFO - 2017-02-03 21:23:29 --> Database Driver Class Initialized
INFO - 2017-02-03 21:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:23:29 --> Controller Class Initialized
INFO - 2017-02-03 21:23:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:23:29 --> Final output sent to browser
DEBUG - 2017-02-03 21:23:29 --> Total execution time: 0.0136
INFO - 2017-02-03 21:27:57 --> Config Class Initialized
INFO - 2017-02-03 21:27:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:27:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:27:57 --> Utf8 Class Initialized
INFO - 2017-02-03 21:27:57 --> URI Class Initialized
DEBUG - 2017-02-03 21:27:57 --> No URI present. Default controller set.
INFO - 2017-02-03 21:27:57 --> Router Class Initialized
INFO - 2017-02-03 21:27:57 --> Output Class Initialized
INFO - 2017-02-03 21:27:57 --> Security Class Initialized
DEBUG - 2017-02-03 21:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:27:57 --> Input Class Initialized
INFO - 2017-02-03 21:27:57 --> Language Class Initialized
INFO - 2017-02-03 21:27:57 --> Loader Class Initialized
INFO - 2017-02-03 21:27:57 --> Database Driver Class Initialized
INFO - 2017-02-03 21:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:27:57 --> Controller Class Initialized
INFO - 2017-02-03 21:27:57 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:27:57 --> Final output sent to browser
DEBUG - 2017-02-03 21:27:57 --> Total execution time: 0.0633
INFO - 2017-02-03 21:28:04 --> Config Class Initialized
INFO - 2017-02-03 21:28:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:28:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:28:04 --> Utf8 Class Initialized
INFO - 2017-02-03 21:28:04 --> URI Class Initialized
INFO - 2017-02-03 21:28:04 --> Router Class Initialized
INFO - 2017-02-03 21:28:04 --> Output Class Initialized
INFO - 2017-02-03 21:28:04 --> Security Class Initialized
DEBUG - 2017-02-03 21:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:28:04 --> Input Class Initialized
INFO - 2017-02-03 21:28:04 --> Language Class Initialized
INFO - 2017-02-03 21:28:04 --> Loader Class Initialized
INFO - 2017-02-03 21:28:04 --> Database Driver Class Initialized
INFO - 2017-02-03 21:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:28:04 --> Controller Class Initialized
INFO - 2017-02-03 21:28:04 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:28:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:28:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:28:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:28:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:28:04 --> Final output sent to browser
DEBUG - 2017-02-03 21:28:04 --> Total execution time: 0.0134
INFO - 2017-02-03 21:37:52 --> Config Class Initialized
INFO - 2017-02-03 21:37:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:37:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:37:52 --> Utf8 Class Initialized
INFO - 2017-02-03 21:37:52 --> URI Class Initialized
INFO - 2017-02-03 21:37:52 --> Router Class Initialized
INFO - 2017-02-03 21:37:52 --> Output Class Initialized
INFO - 2017-02-03 21:37:52 --> Security Class Initialized
DEBUG - 2017-02-03 21:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:37:52 --> Input Class Initialized
INFO - 2017-02-03 21:37:52 --> Language Class Initialized
INFO - 2017-02-03 21:37:52 --> Loader Class Initialized
INFO - 2017-02-03 21:37:52 --> Database Driver Class Initialized
INFO - 2017-02-03 21:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:37:52 --> Controller Class Initialized
INFO - 2017-02-03 21:37:52 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:37:52 --> Helper loaded: form_helper
INFO - 2017-02-03 21:37:52 --> Form Validation Class Initialized
INFO - 2017-02-03 21:37:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:37:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-03 21:37:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:37:52 --> Final output sent to browser
DEBUG - 2017-02-03 21:37:52 --> Total execution time: 0.1779
INFO - 2017-02-03 21:37:53 --> Config Class Initialized
INFO - 2017-02-03 21:37:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:37:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:37:53 --> Utf8 Class Initialized
INFO - 2017-02-03 21:37:53 --> URI Class Initialized
INFO - 2017-02-03 21:37:53 --> Router Class Initialized
INFO - 2017-02-03 21:37:53 --> Output Class Initialized
INFO - 2017-02-03 21:37:53 --> Security Class Initialized
DEBUG - 2017-02-03 21:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:37:53 --> Input Class Initialized
INFO - 2017-02-03 21:37:53 --> Language Class Initialized
INFO - 2017-02-03 21:37:53 --> Loader Class Initialized
INFO - 2017-02-03 21:37:53 --> Database Driver Class Initialized
INFO - 2017-02-03 21:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:37:53 --> Controller Class Initialized
INFO - 2017-02-03 21:37:53 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:37:53 --> Final output sent to browser
DEBUG - 2017-02-03 21:37:53 --> Total execution time: 0.0134
INFO - 2017-02-03 21:37:57 --> Config Class Initialized
INFO - 2017-02-03 21:37:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:37:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:37:57 --> Utf8 Class Initialized
INFO - 2017-02-03 21:37:57 --> URI Class Initialized
DEBUG - 2017-02-03 21:37:57 --> No URI present. Default controller set.
INFO - 2017-02-03 21:37:57 --> Router Class Initialized
INFO - 2017-02-03 21:37:57 --> Output Class Initialized
INFO - 2017-02-03 21:37:57 --> Security Class Initialized
DEBUG - 2017-02-03 21:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:37:57 --> Input Class Initialized
INFO - 2017-02-03 21:37:57 --> Language Class Initialized
INFO - 2017-02-03 21:37:57 --> Loader Class Initialized
INFO - 2017-02-03 21:37:57 --> Database Driver Class Initialized
INFO - 2017-02-03 21:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:37:57 --> Controller Class Initialized
INFO - 2017-02-03 21:37:57 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:37:57 --> Final output sent to browser
DEBUG - 2017-02-03 21:37:57 --> Total execution time: 0.0136
INFO - 2017-02-03 21:37:59 --> Config Class Initialized
INFO - 2017-02-03 21:37:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:37:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:37:59 --> Utf8 Class Initialized
INFO - 2017-02-03 21:37:59 --> URI Class Initialized
INFO - 2017-02-03 21:37:59 --> Router Class Initialized
INFO - 2017-02-03 21:37:59 --> Output Class Initialized
INFO - 2017-02-03 21:37:59 --> Security Class Initialized
DEBUG - 2017-02-03 21:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:37:59 --> Input Class Initialized
INFO - 2017-02-03 21:37:59 --> Language Class Initialized
INFO - 2017-02-03 21:37:59 --> Loader Class Initialized
INFO - 2017-02-03 21:37:59 --> Database Driver Class Initialized
INFO - 2017-02-03 21:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:37:59 --> Controller Class Initialized
INFO - 2017-02-03 21:37:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:37:59 --> Final output sent to browser
DEBUG - 2017-02-03 21:37:59 --> Total execution time: 0.0181
INFO - 2017-02-03 21:40:03 --> Config Class Initialized
INFO - 2017-02-03 21:40:03 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:03 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:03 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:03 --> URI Class Initialized
INFO - 2017-02-03 21:40:03 --> Router Class Initialized
INFO - 2017-02-03 21:40:03 --> Output Class Initialized
INFO - 2017-02-03 21:40:03 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:03 --> Input Class Initialized
INFO - 2017-02-03 21:40:03 --> Language Class Initialized
INFO - 2017-02-03 21:40:03 --> Loader Class Initialized
INFO - 2017-02-03 21:40:03 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:03 --> Controller Class Initialized
INFO - 2017-02-03 21:40:03 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:03 --> Config Class Initialized
INFO - 2017-02-03 21:40:03 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:03 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:03 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:03 --> URI Class Initialized
INFO - 2017-02-03 21:40:03 --> Router Class Initialized
INFO - 2017-02-03 21:40:03 --> Output Class Initialized
INFO - 2017-02-03 21:40:03 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:03 --> Input Class Initialized
INFO - 2017-02-03 21:40:03 --> Language Class Initialized
INFO - 2017-02-03 21:40:03 --> Loader Class Initialized
INFO - 2017-02-03 21:40:03 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:03 --> Controller Class Initialized
INFO - 2017-02-03 21:40:03 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:03 --> Helper loaded: url_helper
INFO - 2017-02-03 21:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 21:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:03 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:03 --> Total execution time: 0.2645
INFO - 2017-02-03 21:40:05 --> Config Class Initialized
INFO - 2017-02-03 21:40:05 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:05 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:05 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:05 --> URI Class Initialized
INFO - 2017-02-03 21:40:05 --> Router Class Initialized
INFO - 2017-02-03 21:40:05 --> Output Class Initialized
INFO - 2017-02-03 21:40:05 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:05 --> Input Class Initialized
INFO - 2017-02-03 21:40:05 --> Language Class Initialized
INFO - 2017-02-03 21:40:05 --> Loader Class Initialized
INFO - 2017-02-03 21:40:05 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:05 --> Controller Class Initialized
INFO - 2017-02-03 21:40:05 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:05 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:05 --> Total execution time: 0.0133
INFO - 2017-02-03 21:40:07 --> Config Class Initialized
INFO - 2017-02-03 21:40:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:07 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:07 --> URI Class Initialized
INFO - 2017-02-03 21:40:07 --> Router Class Initialized
INFO - 2017-02-03 21:40:08 --> Output Class Initialized
INFO - 2017-02-03 21:40:08 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:08 --> Input Class Initialized
INFO - 2017-02-03 21:40:08 --> Language Class Initialized
INFO - 2017-02-03 21:40:08 --> Loader Class Initialized
INFO - 2017-02-03 21:40:08 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:08 --> Controller Class Initialized
INFO - 2017-02-03 21:40:08 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:08 --> Helper loaded: url_helper
INFO - 2017-02-03 21:40:08 --> Helper loaded: download_helper
INFO - 2017-02-03 21:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:08 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:08 --> Total execution time: 0.3652
INFO - 2017-02-03 21:40:09 --> Config Class Initialized
INFO - 2017-02-03 21:40:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:09 --> URI Class Initialized
INFO - 2017-02-03 21:40:09 --> Router Class Initialized
INFO - 2017-02-03 21:40:09 --> Output Class Initialized
INFO - 2017-02-03 21:40:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:09 --> Input Class Initialized
INFO - 2017-02-03 21:40:09 --> Language Class Initialized
INFO - 2017-02-03 21:40:09 --> Loader Class Initialized
INFO - 2017-02-03 21:40:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:09 --> Controller Class Initialized
INFO - 2017-02-03 21:40:09 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:09 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:09 --> Total execution time: 0.0129
INFO - 2017-02-03 21:40:18 --> Config Class Initialized
INFO - 2017-02-03 21:40:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:18 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:18 --> URI Class Initialized
INFO - 2017-02-03 21:40:18 --> Router Class Initialized
INFO - 2017-02-03 21:40:18 --> Output Class Initialized
INFO - 2017-02-03 21:40:18 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:18 --> Input Class Initialized
INFO - 2017-02-03 21:40:18 --> Language Class Initialized
INFO - 2017-02-03 21:40:18 --> Loader Class Initialized
INFO - 2017-02-03 21:40:18 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:18 --> Controller Class Initialized
INFO - 2017-02-03 21:40:18 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:18 --> Helper loaded: url_helper
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:18 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:18 --> Total execution time: 0.0146
INFO - 2017-02-03 21:40:18 --> Config Class Initialized
INFO - 2017-02-03 21:40:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:18 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:18 --> URI Class Initialized
INFO - 2017-02-03 21:40:18 --> Router Class Initialized
INFO - 2017-02-03 21:40:18 --> Output Class Initialized
INFO - 2017-02-03 21:40:18 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:18 --> Input Class Initialized
INFO - 2017-02-03 21:40:18 --> Language Class Initialized
INFO - 2017-02-03 21:40:18 --> Loader Class Initialized
INFO - 2017-02-03 21:40:18 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:18 --> Controller Class Initialized
INFO - 2017-02-03 21:40:18 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:18 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:18 --> Total execution time: 0.0133
INFO - 2017-02-03 21:40:21 --> Config Class Initialized
INFO - 2017-02-03 21:40:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:21 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:21 --> URI Class Initialized
INFO - 2017-02-03 21:40:21 --> Router Class Initialized
INFO - 2017-02-03 21:40:21 --> Output Class Initialized
INFO - 2017-02-03 21:40:21 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:21 --> Input Class Initialized
INFO - 2017-02-03 21:40:21 --> Language Class Initialized
INFO - 2017-02-03 21:40:21 --> Loader Class Initialized
INFO - 2017-02-03 21:40:21 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:21 --> Controller Class Initialized
INFO - 2017-02-03 21:40:21 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:21 --> Helper loaded: url_helper
INFO - 2017-02-03 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-03 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-03 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-03 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:21 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:21 --> Total execution time: 0.0909
INFO - 2017-02-03 21:40:22 --> Config Class Initialized
INFO - 2017-02-03 21:40:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:22 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:22 --> URI Class Initialized
INFO - 2017-02-03 21:40:22 --> Router Class Initialized
INFO - 2017-02-03 21:40:22 --> Output Class Initialized
INFO - 2017-02-03 21:40:22 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:22 --> Input Class Initialized
INFO - 2017-02-03 21:40:22 --> Language Class Initialized
INFO - 2017-02-03 21:40:22 --> Loader Class Initialized
INFO - 2017-02-03 21:40:22 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:22 --> Controller Class Initialized
INFO - 2017-02-03 21:40:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:22 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:22 --> Total execution time: 0.0134
INFO - 2017-02-03 21:40:23 --> Config Class Initialized
INFO - 2017-02-03 21:40:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:23 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:23 --> URI Class Initialized
INFO - 2017-02-03 21:40:23 --> Router Class Initialized
INFO - 2017-02-03 21:40:23 --> Output Class Initialized
INFO - 2017-02-03 21:40:23 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:23 --> Input Class Initialized
INFO - 2017-02-03 21:40:23 --> Language Class Initialized
INFO - 2017-02-03 21:40:23 --> Loader Class Initialized
INFO - 2017-02-03 21:40:23 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:23 --> Controller Class Initialized
INFO - 2017-02-03 21:40:23 --> Upload Class Initialized
INFO - 2017-02-03 21:40:24 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:24 --> Helper loaded: url_helper
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:24 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:24 --> Total execution time: 0.4006
INFO - 2017-02-03 21:40:24 --> Config Class Initialized
INFO - 2017-02-03 21:40:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:24 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:24 --> URI Class Initialized
INFO - 2017-02-03 21:40:24 --> Router Class Initialized
INFO - 2017-02-03 21:40:24 --> Output Class Initialized
INFO - 2017-02-03 21:40:24 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:24 --> Input Class Initialized
INFO - 2017-02-03 21:40:24 --> Language Class Initialized
INFO - 2017-02-03 21:40:24 --> Loader Class Initialized
INFO - 2017-02-03 21:40:24 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:24 --> Controller Class Initialized
INFO - 2017-02-03 21:40:24 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:24 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:24 --> Total execution time: 0.0129
INFO - 2017-02-03 21:40:26 --> Config Class Initialized
INFO - 2017-02-03 21:40:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:26 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:26 --> URI Class Initialized
INFO - 2017-02-03 21:40:26 --> Router Class Initialized
INFO - 2017-02-03 21:40:26 --> Output Class Initialized
INFO - 2017-02-03 21:40:26 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:26 --> Input Class Initialized
INFO - 2017-02-03 21:40:26 --> Language Class Initialized
INFO - 2017-02-03 21:40:26 --> Loader Class Initialized
INFO - 2017-02-03 21:40:26 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:26 --> Controller Class Initialized
INFO - 2017-02-03 21:40:26 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:40:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:26 --> Helper loaded: url_helper
INFO - 2017-02-03 21:40:26 --> Helper loaded: download_helper
INFO - 2017-02-03 21:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:26 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:26 --> Total execution time: 0.0208
INFO - 2017-02-03 21:40:27 --> Config Class Initialized
INFO - 2017-02-03 21:40:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:40:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:40:27 --> Utf8 Class Initialized
INFO - 2017-02-03 21:40:27 --> URI Class Initialized
INFO - 2017-02-03 21:40:27 --> Router Class Initialized
INFO - 2017-02-03 21:40:27 --> Output Class Initialized
INFO - 2017-02-03 21:40:27 --> Security Class Initialized
DEBUG - 2017-02-03 21:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:40:27 --> Input Class Initialized
INFO - 2017-02-03 21:40:27 --> Language Class Initialized
INFO - 2017-02-03 21:40:27 --> Loader Class Initialized
INFO - 2017-02-03 21:40:27 --> Database Driver Class Initialized
INFO - 2017-02-03 21:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:40:27 --> Controller Class Initialized
INFO - 2017-02-03 21:40:27 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:40:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:40:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:40:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:40:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:40:27 --> Final output sent to browser
DEBUG - 2017-02-03 21:40:27 --> Total execution time: 0.0383
INFO - 2017-02-03 21:41:08 --> Config Class Initialized
INFO - 2017-02-03 21:41:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:08 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:08 --> URI Class Initialized
INFO - 2017-02-03 21:41:08 --> Router Class Initialized
INFO - 2017-02-03 21:41:08 --> Output Class Initialized
INFO - 2017-02-03 21:41:08 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:08 --> Input Class Initialized
INFO - 2017-02-03 21:41:08 --> Language Class Initialized
INFO - 2017-02-03 21:41:08 --> Loader Class Initialized
INFO - 2017-02-03 21:41:08 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:08 --> Controller Class Initialized
INFO - 2017-02-03 21:41:08 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:08 --> Helper loaded: url_helper
INFO - 2017-02-03 21:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 21:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:08 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:08 --> Total execution time: 0.0143
INFO - 2017-02-03 21:41:09 --> Config Class Initialized
INFO - 2017-02-03 21:41:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:09 --> URI Class Initialized
INFO - 2017-02-03 21:41:09 --> Router Class Initialized
INFO - 2017-02-03 21:41:09 --> Output Class Initialized
INFO - 2017-02-03 21:41:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:09 --> Input Class Initialized
INFO - 2017-02-03 21:41:09 --> Language Class Initialized
INFO - 2017-02-03 21:41:09 --> Loader Class Initialized
INFO - 2017-02-03 21:41:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:09 --> Controller Class Initialized
INFO - 2017-02-03 21:41:09 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:41:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:41:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:09 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:09 --> Total execution time: 0.0149
INFO - 2017-02-03 21:41:14 --> Config Class Initialized
INFO - 2017-02-03 21:41:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:14 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:14 --> URI Class Initialized
INFO - 2017-02-03 21:41:14 --> Router Class Initialized
INFO - 2017-02-03 21:41:14 --> Output Class Initialized
INFO - 2017-02-03 21:41:14 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:14 --> Input Class Initialized
INFO - 2017-02-03 21:41:14 --> Language Class Initialized
INFO - 2017-02-03 21:41:14 --> Loader Class Initialized
INFO - 2017-02-03 21:41:14 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:14 --> Controller Class Initialized
INFO - 2017-02-03 21:41:14 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:14 --> Config Class Initialized
INFO - 2017-02-03 21:41:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:14 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:14 --> URI Class Initialized
DEBUG - 2017-02-03 21:41:14 --> No URI present. Default controller set.
INFO - 2017-02-03 21:41:14 --> Router Class Initialized
INFO - 2017-02-03 21:41:14 --> Output Class Initialized
INFO - 2017-02-03 21:41:14 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:14 --> Input Class Initialized
INFO - 2017-02-03 21:41:14 --> Language Class Initialized
INFO - 2017-02-03 21:41:14 --> Loader Class Initialized
INFO - 2017-02-03 21:41:14 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:14 --> Controller Class Initialized
INFO - 2017-02-03 21:41:14 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:14 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:14 --> Total execution time: 0.0143
INFO - 2017-02-03 21:41:14 --> Config Class Initialized
INFO - 2017-02-03 21:41:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:14 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:14 --> URI Class Initialized
INFO - 2017-02-03 21:41:14 --> Router Class Initialized
INFO - 2017-02-03 21:41:14 --> Output Class Initialized
INFO - 2017-02-03 21:41:14 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:14 --> Input Class Initialized
INFO - 2017-02-03 21:41:14 --> Language Class Initialized
INFO - 2017-02-03 21:41:14 --> Loader Class Initialized
INFO - 2017-02-03 21:41:14 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:14 --> Controller Class Initialized
INFO - 2017-02-03 21:41:14 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:14 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:14 --> Total execution time: 0.0142
INFO - 2017-02-03 21:41:15 --> Config Class Initialized
INFO - 2017-02-03 21:41:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:15 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:15 --> URI Class Initialized
INFO - 2017-02-03 21:41:15 --> Router Class Initialized
INFO - 2017-02-03 21:41:15 --> Output Class Initialized
INFO - 2017-02-03 21:41:15 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:15 --> Input Class Initialized
INFO - 2017-02-03 21:41:15 --> Language Class Initialized
INFO - 2017-02-03 21:41:15 --> Loader Class Initialized
INFO - 2017-02-03 21:41:15 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:15 --> Controller Class Initialized
INFO - 2017-02-03 21:41:15 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:15 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:15 --> Total execution time: 0.0137
INFO - 2017-02-03 21:41:21 --> Config Class Initialized
INFO - 2017-02-03 21:41:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:21 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:21 --> URI Class Initialized
INFO - 2017-02-03 21:41:21 --> Router Class Initialized
INFO - 2017-02-03 21:41:21 --> Output Class Initialized
INFO - 2017-02-03 21:41:21 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:21 --> Input Class Initialized
INFO - 2017-02-03 21:41:21 --> Language Class Initialized
INFO - 2017-02-03 21:41:21 --> Loader Class Initialized
INFO - 2017-02-03 21:41:21 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:21 --> Controller Class Initialized
INFO - 2017-02-03 21:41:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:21 --> Helper loaded: form_helper
INFO - 2017-02-03 21:41:21 --> Form Validation Class Initialized
INFO - 2017-02-03 21:41:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:41:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-03 21:41:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:41:21 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:21 --> Total execution time: 0.0125
INFO - 2017-02-03 21:41:21 --> Config Class Initialized
INFO - 2017-02-03 21:41:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:21 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:21 --> URI Class Initialized
INFO - 2017-02-03 21:41:21 --> Router Class Initialized
INFO - 2017-02-03 21:41:21 --> Output Class Initialized
INFO - 2017-02-03 21:41:21 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:21 --> Input Class Initialized
INFO - 2017-02-03 21:41:21 --> Language Class Initialized
INFO - 2017-02-03 21:41:21 --> Loader Class Initialized
INFO - 2017-02-03 21:41:21 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:21 --> Controller Class Initialized
INFO - 2017-02-03 21:41:21 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:41:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:21 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:21 --> Total execution time: 0.0141
INFO - 2017-02-03 21:41:56 --> Config Class Initialized
INFO - 2017-02-03 21:41:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:56 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:56 --> URI Class Initialized
DEBUG - 2017-02-03 21:41:56 --> No URI present. Default controller set.
INFO - 2017-02-03 21:41:56 --> Router Class Initialized
INFO - 2017-02-03 21:41:56 --> Output Class Initialized
INFO - 2017-02-03 21:41:56 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:56 --> Input Class Initialized
INFO - 2017-02-03 21:41:56 --> Language Class Initialized
INFO - 2017-02-03 21:41:56 --> Loader Class Initialized
INFO - 2017-02-03 21:41:56 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:56 --> Controller Class Initialized
INFO - 2017-02-03 21:41:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:56 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:56 --> Total execution time: 0.0214
INFO - 2017-02-03 21:41:57 --> Config Class Initialized
INFO - 2017-02-03 21:41:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:41:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:41:57 --> Utf8 Class Initialized
INFO - 2017-02-03 21:41:57 --> URI Class Initialized
INFO - 2017-02-03 21:41:57 --> Router Class Initialized
INFO - 2017-02-03 21:41:57 --> Output Class Initialized
INFO - 2017-02-03 21:41:57 --> Security Class Initialized
DEBUG - 2017-02-03 21:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:41:57 --> Input Class Initialized
INFO - 2017-02-03 21:41:57 --> Language Class Initialized
INFO - 2017-02-03 21:41:57 --> Loader Class Initialized
INFO - 2017-02-03 21:41:57 --> Database Driver Class Initialized
INFO - 2017-02-03 21:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:41:57 --> Controller Class Initialized
INFO - 2017-02-03 21:41:57 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:41:57 --> Final output sent to browser
DEBUG - 2017-02-03 21:41:57 --> Total execution time: 0.0145
INFO - 2017-02-03 21:42:06 --> Config Class Initialized
INFO - 2017-02-03 21:42:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:06 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:06 --> URI Class Initialized
INFO - 2017-02-03 21:42:06 --> Router Class Initialized
INFO - 2017-02-03 21:42:06 --> Output Class Initialized
INFO - 2017-02-03 21:42:06 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:06 --> Input Class Initialized
INFO - 2017-02-03 21:42:06 --> Language Class Initialized
INFO - 2017-02-03 21:42:06 --> Loader Class Initialized
INFO - 2017-02-03 21:42:06 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:06 --> Controller Class Initialized
INFO - 2017-02-03 21:42:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:07 --> Config Class Initialized
INFO - 2017-02-03 21:42:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:07 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:07 --> URI Class Initialized
INFO - 2017-02-03 21:42:07 --> Router Class Initialized
INFO - 2017-02-03 21:42:07 --> Output Class Initialized
INFO - 2017-02-03 21:42:07 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:07 --> Input Class Initialized
INFO - 2017-02-03 21:42:07 --> Language Class Initialized
INFO - 2017-02-03 21:42:07 --> Loader Class Initialized
INFO - 2017-02-03 21:42:07 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:07 --> Controller Class Initialized
INFO - 2017-02-03 21:42:07 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:07 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 21:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:07 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:07 --> Total execution time: 0.0163
INFO - 2017-02-03 21:42:08 --> Config Class Initialized
INFO - 2017-02-03 21:42:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:08 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:08 --> URI Class Initialized
INFO - 2017-02-03 21:42:08 --> Router Class Initialized
INFO - 2017-02-03 21:42:08 --> Output Class Initialized
INFO - 2017-02-03 21:42:08 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:08 --> Input Class Initialized
INFO - 2017-02-03 21:42:08 --> Language Class Initialized
INFO - 2017-02-03 21:42:08 --> Loader Class Initialized
INFO - 2017-02-03 21:42:08 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:08 --> Controller Class Initialized
INFO - 2017-02-03 21:42:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:08 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:08 --> Total execution time: 0.0135
INFO - 2017-02-03 21:42:09 --> Config Class Initialized
INFO - 2017-02-03 21:42:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:09 --> URI Class Initialized
INFO - 2017-02-03 21:42:09 --> Router Class Initialized
INFO - 2017-02-03 21:42:09 --> Output Class Initialized
INFO - 2017-02-03 21:42:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:09 --> Input Class Initialized
INFO - 2017-02-03 21:42:09 --> Language Class Initialized
INFO - 2017-02-03 21:42:09 --> Loader Class Initialized
INFO - 2017-02-03 21:42:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:09 --> Controller Class Initialized
INFO - 2017-02-03 21:42:09 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:09 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:09 --> Helper loaded: download_helper
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:09 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:09 --> Total execution time: 0.0201
INFO - 2017-02-03 21:42:09 --> Config Class Initialized
INFO - 2017-02-03 21:42:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:09 --> URI Class Initialized
INFO - 2017-02-03 21:42:09 --> Router Class Initialized
INFO - 2017-02-03 21:42:09 --> Output Class Initialized
INFO - 2017-02-03 21:42:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:09 --> Input Class Initialized
INFO - 2017-02-03 21:42:09 --> Language Class Initialized
INFO - 2017-02-03 21:42:09 --> Loader Class Initialized
INFO - 2017-02-03 21:42:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:09 --> Controller Class Initialized
INFO - 2017-02-03 21:42:09 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:09 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:09 --> Total execution time: 0.0134
INFO - 2017-02-03 21:42:12 --> Config Class Initialized
INFO - 2017-02-03 21:42:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:12 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:12 --> URI Class Initialized
INFO - 2017-02-03 21:42:12 --> Router Class Initialized
INFO - 2017-02-03 21:42:12 --> Output Class Initialized
INFO - 2017-02-03 21:42:12 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:12 --> Input Class Initialized
INFO - 2017-02-03 21:42:12 --> Language Class Initialized
INFO - 2017-02-03 21:42:12 --> Loader Class Initialized
INFO - 2017-02-03 21:42:12 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:12 --> Controller Class Initialized
INFO - 2017-02-03 21:42:12 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:12 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:12 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:12 --> Total execution time: 0.0138
INFO - 2017-02-03 21:42:12 --> Config Class Initialized
INFO - 2017-02-03 21:42:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:12 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:12 --> URI Class Initialized
INFO - 2017-02-03 21:42:12 --> Router Class Initialized
INFO - 2017-02-03 21:42:12 --> Output Class Initialized
INFO - 2017-02-03 21:42:12 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:12 --> Input Class Initialized
INFO - 2017-02-03 21:42:12 --> Language Class Initialized
INFO - 2017-02-03 21:42:12 --> Loader Class Initialized
INFO - 2017-02-03 21:42:12 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:12 --> Controller Class Initialized
INFO - 2017-02-03 21:42:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:12 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:12 --> Total execution time: 0.0135
INFO - 2017-02-03 21:42:28 --> Config Class Initialized
INFO - 2017-02-03 21:42:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:28 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:28 --> URI Class Initialized
INFO - 2017-02-03 21:42:28 --> Router Class Initialized
INFO - 2017-02-03 21:42:28 --> Output Class Initialized
INFO - 2017-02-03 21:42:28 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:28 --> Input Class Initialized
INFO - 2017-02-03 21:42:28 --> Language Class Initialized
INFO - 2017-02-03 21:42:28 --> Loader Class Initialized
INFO - 2017-02-03 21:42:28 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:28 --> Controller Class Initialized
INFO - 2017-02-03 21:42:28 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:28 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:28 --> Helper loaded: download_helper
INFO - 2017-02-03 21:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:28 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:28 --> Total execution time: 0.0341
INFO - 2017-02-03 21:42:29 --> Config Class Initialized
INFO - 2017-02-03 21:42:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:29 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:29 --> URI Class Initialized
INFO - 2017-02-03 21:42:29 --> Router Class Initialized
INFO - 2017-02-03 21:42:29 --> Output Class Initialized
INFO - 2017-02-03 21:42:29 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:29 --> Input Class Initialized
INFO - 2017-02-03 21:42:29 --> Language Class Initialized
INFO - 2017-02-03 21:42:29 --> Loader Class Initialized
INFO - 2017-02-03 21:42:29 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:29 --> Controller Class Initialized
INFO - 2017-02-03 21:42:29 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:29 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:29 --> Total execution time: 0.0134
INFO - 2017-02-03 21:42:40 --> Config Class Initialized
INFO - 2017-02-03 21:42:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:40 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:40 --> URI Class Initialized
INFO - 2017-02-03 21:42:40 --> Router Class Initialized
INFO - 2017-02-03 21:42:40 --> Output Class Initialized
INFO - 2017-02-03 21:42:40 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:40 --> Input Class Initialized
INFO - 2017-02-03 21:42:40 --> Language Class Initialized
INFO - 2017-02-03 21:42:40 --> Loader Class Initialized
INFO - 2017-02-03 21:42:40 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:40 --> Controller Class Initialized
INFO - 2017-02-03 21:42:40 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:40 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:40 --> Helper loaded: download_helper
INFO - 2017-02-03 21:42:40 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:40 --> Total execution time: 0.0141
INFO - 2017-02-03 21:42:42 --> Config Class Initialized
INFO - 2017-02-03 21:42:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:42 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:42 --> URI Class Initialized
INFO - 2017-02-03 21:42:42 --> Router Class Initialized
INFO - 2017-02-03 21:42:42 --> Output Class Initialized
INFO - 2017-02-03 21:42:42 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:42 --> Input Class Initialized
INFO - 2017-02-03 21:42:42 --> Language Class Initialized
INFO - 2017-02-03 21:42:42 --> Loader Class Initialized
INFO - 2017-02-03 21:42:42 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:42 --> Controller Class Initialized
INFO - 2017-02-03 21:42:42 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:42 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:42 --> Helper loaded: download_helper
INFO - 2017-02-03 21:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:42 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:42 --> Total execution time: 0.0192
INFO - 2017-02-03 21:42:43 --> Config Class Initialized
INFO - 2017-02-03 21:42:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:43 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:43 --> URI Class Initialized
INFO - 2017-02-03 21:42:43 --> Router Class Initialized
INFO - 2017-02-03 21:42:43 --> Output Class Initialized
INFO - 2017-02-03 21:42:43 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:43 --> Input Class Initialized
INFO - 2017-02-03 21:42:43 --> Language Class Initialized
INFO - 2017-02-03 21:42:43 --> Loader Class Initialized
INFO - 2017-02-03 21:42:43 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:43 --> Controller Class Initialized
INFO - 2017-02-03 21:42:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:43 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:43 --> Total execution time: 0.0141
INFO - 2017-02-03 21:42:47 --> Config Class Initialized
INFO - 2017-02-03 21:42:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:47 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:47 --> URI Class Initialized
INFO - 2017-02-03 21:42:47 --> Router Class Initialized
INFO - 2017-02-03 21:42:47 --> Output Class Initialized
INFO - 2017-02-03 21:42:47 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:47 --> Input Class Initialized
INFO - 2017-02-03 21:42:47 --> Language Class Initialized
INFO - 2017-02-03 21:42:47 --> Loader Class Initialized
INFO - 2017-02-03 21:42:47 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:47 --> Controller Class Initialized
INFO - 2017-02-03 21:42:47 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:47 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:47 --> Helper loaded: download_helper
INFO - 2017-02-03 21:42:47 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:47 --> Total execution time: 0.0137
INFO - 2017-02-03 21:42:48 --> Config Class Initialized
INFO - 2017-02-03 21:42:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:48 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:48 --> URI Class Initialized
INFO - 2017-02-03 21:42:48 --> Router Class Initialized
INFO - 2017-02-03 21:42:48 --> Output Class Initialized
INFO - 2017-02-03 21:42:48 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:48 --> Input Class Initialized
INFO - 2017-02-03 21:42:48 --> Language Class Initialized
INFO - 2017-02-03 21:42:48 --> Loader Class Initialized
INFO - 2017-02-03 21:42:48 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:48 --> Controller Class Initialized
INFO - 2017-02-03 21:42:48 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:48 --> Helper loaded: url_helper
INFO - 2017-02-03 21:42:48 --> Helper loaded: download_helper
INFO - 2017-02-03 21:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:48 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:48 --> Total execution time: 0.0273
INFO - 2017-02-03 21:42:49 --> Config Class Initialized
INFO - 2017-02-03 21:42:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:49 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:49 --> URI Class Initialized
INFO - 2017-02-03 21:42:49 --> Router Class Initialized
INFO - 2017-02-03 21:42:49 --> Output Class Initialized
INFO - 2017-02-03 21:42:49 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:49 --> Input Class Initialized
INFO - 2017-02-03 21:42:49 --> Language Class Initialized
INFO - 2017-02-03 21:42:49 --> Loader Class Initialized
INFO - 2017-02-03 21:42:49 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:49 --> Controller Class Initialized
INFO - 2017-02-03 21:42:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:49 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:49 --> Total execution time: 0.0161
INFO - 2017-02-03 21:42:56 --> Config Class Initialized
INFO - 2017-02-03 21:42:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:56 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:56 --> URI Class Initialized
INFO - 2017-02-03 21:42:56 --> Router Class Initialized
INFO - 2017-02-03 21:42:56 --> Output Class Initialized
INFO - 2017-02-03 21:42:56 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:56 --> Input Class Initialized
INFO - 2017-02-03 21:42:56 --> Language Class Initialized
INFO - 2017-02-03 21:42:56 --> Loader Class Initialized
INFO - 2017-02-03 21:42:56 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:56 --> Controller Class Initialized
INFO - 2017-02-03 21:42:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:56 --> Config Class Initialized
INFO - 2017-02-03 21:42:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:56 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:56 --> URI Class Initialized
DEBUG - 2017-02-03 21:42:56 --> No URI present. Default controller set.
INFO - 2017-02-03 21:42:56 --> Router Class Initialized
INFO - 2017-02-03 21:42:56 --> Output Class Initialized
INFO - 2017-02-03 21:42:56 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:56 --> Input Class Initialized
INFO - 2017-02-03 21:42:56 --> Language Class Initialized
INFO - 2017-02-03 21:42:56 --> Loader Class Initialized
INFO - 2017-02-03 21:42:56 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:56 --> Controller Class Initialized
INFO - 2017-02-03 21:42:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:56 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:56 --> Total execution time: 0.0144
INFO - 2017-02-03 21:42:56 --> Config Class Initialized
INFO - 2017-02-03 21:42:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:56 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:56 --> URI Class Initialized
INFO - 2017-02-03 21:42:56 --> Router Class Initialized
INFO - 2017-02-03 21:42:56 --> Output Class Initialized
INFO - 2017-02-03 21:42:56 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:56 --> Input Class Initialized
INFO - 2017-02-03 21:42:56 --> Language Class Initialized
INFO - 2017-02-03 21:42:56 --> Loader Class Initialized
INFO - 2017-02-03 21:42:56 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:56 --> Controller Class Initialized
INFO - 2017-02-03 21:42:56 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:56 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:56 --> Total execution time: 0.0686
INFO - 2017-02-03 21:42:57 --> Config Class Initialized
INFO - 2017-02-03 21:42:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:42:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:42:57 --> Utf8 Class Initialized
INFO - 2017-02-03 21:42:57 --> URI Class Initialized
INFO - 2017-02-03 21:42:57 --> Router Class Initialized
INFO - 2017-02-03 21:42:57 --> Output Class Initialized
INFO - 2017-02-03 21:42:57 --> Security Class Initialized
DEBUG - 2017-02-03 21:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:42:57 --> Input Class Initialized
INFO - 2017-02-03 21:42:57 --> Language Class Initialized
INFO - 2017-02-03 21:42:57 --> Loader Class Initialized
INFO - 2017-02-03 21:42:57 --> Database Driver Class Initialized
INFO - 2017-02-03 21:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:42:57 --> Controller Class Initialized
INFO - 2017-02-03 21:42:57 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:42:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:42:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:42:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:42:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:42:57 --> Final output sent to browser
DEBUG - 2017-02-03 21:42:57 --> Total execution time: 0.0143
INFO - 2017-02-03 21:43:08 --> Config Class Initialized
INFO - 2017-02-03 21:43:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:08 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:08 --> URI Class Initialized
INFO - 2017-02-03 21:43:08 --> Router Class Initialized
INFO - 2017-02-03 21:43:08 --> Output Class Initialized
INFO - 2017-02-03 21:43:08 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:08 --> Input Class Initialized
INFO - 2017-02-03 21:43:08 --> Language Class Initialized
INFO - 2017-02-03 21:43:08 --> Loader Class Initialized
INFO - 2017-02-03 21:43:08 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:08 --> Controller Class Initialized
INFO - 2017-02-03 21:43:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:09 --> Config Class Initialized
INFO - 2017-02-03 21:43:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:09 --> URI Class Initialized
INFO - 2017-02-03 21:43:09 --> Router Class Initialized
INFO - 2017-02-03 21:43:09 --> Output Class Initialized
INFO - 2017-02-03 21:43:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:09 --> Input Class Initialized
INFO - 2017-02-03 21:43:09 --> Language Class Initialized
INFO - 2017-02-03 21:43:09 --> Loader Class Initialized
INFO - 2017-02-03 21:43:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:09 --> Controller Class Initialized
INFO - 2017-02-03 21:43:09 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:09 --> Helper loaded: url_helper
INFO - 2017-02-03 21:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 21:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:43:09 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:09 --> Total execution time: 0.0172
INFO - 2017-02-03 21:43:09 --> Config Class Initialized
INFO - 2017-02-03 21:43:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:09 --> URI Class Initialized
INFO - 2017-02-03 21:43:09 --> Router Class Initialized
INFO - 2017-02-03 21:43:09 --> Output Class Initialized
INFO - 2017-02-03 21:43:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:09 --> Input Class Initialized
INFO - 2017-02-03 21:43:09 --> Language Class Initialized
INFO - 2017-02-03 21:43:10 --> Loader Class Initialized
INFO - 2017-02-03 21:43:10 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:10 --> Controller Class Initialized
INFO - 2017-02-03 21:43:10 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:43:10 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:10 --> Total execution time: 0.0131
INFO - 2017-02-03 21:43:11 --> Config Class Initialized
INFO - 2017-02-03 21:43:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:11 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:11 --> URI Class Initialized
INFO - 2017-02-03 21:43:11 --> Router Class Initialized
INFO - 2017-02-03 21:43:11 --> Output Class Initialized
INFO - 2017-02-03 21:43:11 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:11 --> Input Class Initialized
INFO - 2017-02-03 21:43:11 --> Language Class Initialized
INFO - 2017-02-03 21:43:11 --> Loader Class Initialized
INFO - 2017-02-03 21:43:11 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:11 --> Controller Class Initialized
INFO - 2017-02-03 21:43:11 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:11 --> Helper loaded: url_helper
INFO - 2017-02-03 21:43:11 --> Helper loaded: download_helper
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:43:11 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:11 --> Total execution time: 0.0188
INFO - 2017-02-03 21:43:11 --> Config Class Initialized
INFO - 2017-02-03 21:43:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:11 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:11 --> URI Class Initialized
INFO - 2017-02-03 21:43:11 --> Router Class Initialized
INFO - 2017-02-03 21:43:11 --> Output Class Initialized
INFO - 2017-02-03 21:43:11 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:11 --> Input Class Initialized
INFO - 2017-02-03 21:43:11 --> Language Class Initialized
INFO - 2017-02-03 21:43:11 --> Loader Class Initialized
INFO - 2017-02-03 21:43:11 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:11 --> Controller Class Initialized
INFO - 2017-02-03 21:43:11 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:43:11 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:11 --> Total execution time: 0.0133
INFO - 2017-02-03 21:43:35 --> Config Class Initialized
INFO - 2017-02-03 21:43:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:35 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:35 --> URI Class Initialized
INFO - 2017-02-03 21:43:35 --> Router Class Initialized
INFO - 2017-02-03 21:43:35 --> Output Class Initialized
INFO - 2017-02-03 21:43:35 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:35 --> Input Class Initialized
INFO - 2017-02-03 21:43:35 --> Language Class Initialized
INFO - 2017-02-03 21:43:35 --> Loader Class Initialized
INFO - 2017-02-03 21:43:35 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:35 --> Controller Class Initialized
INFO - 2017-02-03 21:43:35 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:35 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:35 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-03 21:43:36 --> Config Class Initialized
INFO - 2017-02-03 21:43:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:36 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:36 --> URI Class Initialized
INFO - 2017-02-03 21:43:36 --> Router Class Initialized
INFO - 2017-02-03 21:43:36 --> Output Class Initialized
INFO - 2017-02-03 21:43:36 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:36 --> Input Class Initialized
INFO - 2017-02-03 21:43:36 --> Language Class Initialized
INFO - 2017-02-03 21:43:36 --> Loader Class Initialized
INFO - 2017-02-03 21:43:36 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:36 --> Controller Class Initialized
INFO - 2017-02-03 21:43:36 --> Helper loaded: date_helper
INFO - 2017-02-03 21:43:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:36 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:36 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:43:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-03 21:43:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-02-03 21:43:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-02-03 21:43:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:43:36 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:36 --> Total execution time: 0.1568
INFO - 2017-02-03 21:43:36 --> Config Class Initialized
INFO - 2017-02-03 21:43:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:36 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:36 --> URI Class Initialized
INFO - 2017-02-03 21:43:36 --> Router Class Initialized
INFO - 2017-02-03 21:43:36 --> Output Class Initialized
INFO - 2017-02-03 21:43:36 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:36 --> Input Class Initialized
INFO - 2017-02-03 21:43:36 --> Language Class Initialized
INFO - 2017-02-03 21:43:36 --> Loader Class Initialized
INFO - 2017-02-03 21:43:36 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:36 --> Controller Class Initialized
INFO - 2017-02-03 21:43:36 --> Helper loaded: date_helper
INFO - 2017-02-03 21:43:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:36 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:36 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:36 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:36 --> Total execution time: 0.0152
INFO - 2017-02-03 21:43:37 --> Config Class Initialized
INFO - 2017-02-03 21:43:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:37 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:37 --> URI Class Initialized
INFO - 2017-02-03 21:43:37 --> Router Class Initialized
INFO - 2017-02-03 21:43:37 --> Output Class Initialized
INFO - 2017-02-03 21:43:37 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:37 --> Input Class Initialized
INFO - 2017-02-03 21:43:37 --> Language Class Initialized
INFO - 2017-02-03 21:43:37 --> Loader Class Initialized
INFO - 2017-02-03 21:43:37 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:37 --> Controller Class Initialized
INFO - 2017-02-03 21:43:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:43:37 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:37 --> Total execution time: 0.0138
INFO - 2017-02-03 21:43:41 --> Config Class Initialized
INFO - 2017-02-03 21:43:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:41 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:41 --> URI Class Initialized
INFO - 2017-02-03 21:43:41 --> Router Class Initialized
INFO - 2017-02-03 21:43:41 --> Output Class Initialized
INFO - 2017-02-03 21:43:41 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:41 --> Input Class Initialized
INFO - 2017-02-03 21:43:41 --> Language Class Initialized
INFO - 2017-02-03 21:43:41 --> Loader Class Initialized
INFO - 2017-02-03 21:43:41 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:41 --> Controller Class Initialized
INFO - 2017-02-03 21:43:41 --> Upload Class Initialized
INFO - 2017-02-03 21:43:41 --> Helper loaded: date_helper
INFO - 2017-02-03 21:43:41 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:41 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:41 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-03 21:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-02-03 21:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-02-03 21:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-03 21:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:43:41 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:41 --> Total execution time: 0.0607
INFO - 2017-02-03 21:43:41 --> Config Class Initialized
INFO - 2017-02-03 21:43:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:41 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:41 --> URI Class Initialized
INFO - 2017-02-03 21:43:41 --> Router Class Initialized
INFO - 2017-02-03 21:43:42 --> Output Class Initialized
INFO - 2017-02-03 21:43:42 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:42 --> Input Class Initialized
INFO - 2017-02-03 21:43:42 --> Language Class Initialized
INFO - 2017-02-03 21:43:42 --> Loader Class Initialized
INFO - 2017-02-03 21:43:42 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:42 --> Controller Class Initialized
INFO - 2017-02-03 21:43:42 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:43:42 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:42 --> Total execution time: 0.0130
INFO - 2017-02-03 21:43:45 --> Config Class Initialized
INFO - 2017-02-03 21:43:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:45 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:45 --> URI Class Initialized
INFO - 2017-02-03 21:43:45 --> Router Class Initialized
INFO - 2017-02-03 21:43:45 --> Output Class Initialized
INFO - 2017-02-03 21:43:45 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:45 --> Input Class Initialized
INFO - 2017-02-03 21:43:45 --> Language Class Initialized
INFO - 2017-02-03 21:43:45 --> Loader Class Initialized
INFO - 2017-02-03 21:43:45 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:45 --> Controller Class Initialized
INFO - 2017-02-03 21:43:45 --> Helper loaded: date_helper
INFO - 2017-02-03 21:43:45 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:45 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:45 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:43:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-03 21:43:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-02-03 21:43:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-02-03 21:43:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:43:45 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:45 --> Total execution time: 0.0156
INFO - 2017-02-03 21:43:46 --> Config Class Initialized
INFO - 2017-02-03 21:43:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:46 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:46 --> URI Class Initialized
INFO - 2017-02-03 21:43:46 --> Router Class Initialized
INFO - 2017-02-03 21:43:46 --> Output Class Initialized
INFO - 2017-02-03 21:43:46 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:46 --> Input Class Initialized
INFO - 2017-02-03 21:43:46 --> Language Class Initialized
INFO - 2017-02-03 21:43:46 --> Loader Class Initialized
INFO - 2017-02-03 21:43:46 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:46 --> Controller Class Initialized
INFO - 2017-02-03 21:43:46 --> Helper loaded: date_helper
INFO - 2017-02-03 21:43:46 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:46 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:46 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:46 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:46 --> Total execution time: 0.0152
INFO - 2017-02-03 21:43:46 --> Config Class Initialized
INFO - 2017-02-03 21:43:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:46 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:46 --> URI Class Initialized
INFO - 2017-02-03 21:43:46 --> Router Class Initialized
INFO - 2017-02-03 21:43:46 --> Output Class Initialized
INFO - 2017-02-03 21:43:46 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:46 --> Input Class Initialized
INFO - 2017-02-03 21:43:46 --> Language Class Initialized
INFO - 2017-02-03 21:43:46 --> Loader Class Initialized
INFO - 2017-02-03 21:43:46 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:46 --> Controller Class Initialized
INFO - 2017-02-03 21:43:46 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:43:46 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:46 --> Total execution time: 0.0133
INFO - 2017-02-03 21:43:50 --> Config Class Initialized
INFO - 2017-02-03 21:43:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:50 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:50 --> URI Class Initialized
INFO - 2017-02-03 21:43:50 --> Router Class Initialized
INFO - 2017-02-03 21:43:50 --> Output Class Initialized
INFO - 2017-02-03 21:43:50 --> Security Class Initialized
DEBUG - 2017-02-03 21:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:50 --> Input Class Initialized
INFO - 2017-02-03 21:43:50 --> Language Class Initialized
INFO - 2017-02-03 21:43:50 --> Loader Class Initialized
INFO - 2017-02-03 21:43:50 --> Config Class Initialized
INFO - 2017-02-03 21:43:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:43:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:43:50 --> Utf8 Class Initialized
INFO - 2017-02-03 21:43:50 --> URI Class Initialized
INFO - 2017-02-03 21:43:50 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:50 --> Router Class Initialized
INFO - 2017-02-03 21:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:50 --> Controller Class Initialized
INFO - 2017-02-03 21:43:50 --> Output Class Initialized
INFO - 2017-02-03 21:43:50 --> Helper loaded: date_helper
INFO - 2017-02-03 21:43:50 --> Security Class Initialized
INFO - 2017-02-03 21:43:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-02-03 21:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:43:50 --> Input Class Initialized
INFO - 2017-02-03 21:43:50 --> Language Class Initialized
INFO - 2017-02-03 21:43:50 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:50 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:50 --> Loader Class Initialized
INFO - 2017-02-03 21:43:50 --> Database Driver Class Initialized
INFO - 2017-02-03 21:43:50 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:50 --> Total execution time: 0.0247
INFO - 2017-02-03 21:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:43:50 --> Controller Class Initialized
INFO - 2017-02-03 21:43:50 --> Helper loaded: date_helper
INFO - 2017-02-03 21:43:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:43:50 --> Helper loaded: form_helper
INFO - 2017-02-03 21:43:50 --> Form Validation Class Initialized
INFO - 2017-02-03 21:43:50 --> Final output sent to browser
DEBUG - 2017-02-03 21:43:50 --> Total execution time: 0.0877
INFO - 2017-02-03 21:44:06 --> Config Class Initialized
INFO - 2017-02-03 21:44:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:44:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:44:06 --> Utf8 Class Initialized
INFO - 2017-02-03 21:44:06 --> URI Class Initialized
INFO - 2017-02-03 21:44:06 --> Router Class Initialized
INFO - 2017-02-03 21:44:06 --> Output Class Initialized
INFO - 2017-02-03 21:44:06 --> Security Class Initialized
DEBUG - 2017-02-03 21:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:44:06 --> Input Class Initialized
INFO - 2017-02-03 21:44:06 --> Language Class Initialized
INFO - 2017-02-03 21:44:06 --> Loader Class Initialized
INFO - 2017-02-03 21:44:06 --> Database Driver Class Initialized
INFO - 2017-02-03 21:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:44:06 --> Controller Class Initialized
INFO - 2017-02-03 21:44:06 --> Helper loaded: date_helper
INFO - 2017-02-03 21:44:06 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:44:06 --> Helper loaded: form_helper
INFO - 2017-02-03 21:44:06 --> Form Validation Class Initialized
INFO - 2017-02-03 21:44:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:44:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-03 21:44:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-02-03 21:44:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-02-03 21:44:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:44:06 --> Final output sent to browser
DEBUG - 2017-02-03 21:44:06 --> Total execution time: 0.0454
INFO - 2017-02-03 21:44:07 --> Config Class Initialized
INFO - 2017-02-03 21:44:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:44:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:44:07 --> Utf8 Class Initialized
INFO - 2017-02-03 21:44:07 --> URI Class Initialized
INFO - 2017-02-03 21:44:07 --> Router Class Initialized
INFO - 2017-02-03 21:44:07 --> Output Class Initialized
INFO - 2017-02-03 21:44:07 --> Security Class Initialized
DEBUG - 2017-02-03 21:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:44:07 --> Input Class Initialized
INFO - 2017-02-03 21:44:07 --> Language Class Initialized
INFO - 2017-02-03 21:44:07 --> Loader Class Initialized
INFO - 2017-02-03 21:44:07 --> Database Driver Class Initialized
INFO - 2017-02-03 21:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:44:07 --> Controller Class Initialized
INFO - 2017-02-03 21:44:07 --> Helper loaded: date_helper
INFO - 2017-02-03 21:44:07 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:44:07 --> Helper loaded: form_helper
INFO - 2017-02-03 21:44:07 --> Form Validation Class Initialized
INFO - 2017-02-03 21:44:07 --> Final output sent to browser
DEBUG - 2017-02-03 21:44:07 --> Total execution time: 0.0154
INFO - 2017-02-03 21:44:07 --> Config Class Initialized
INFO - 2017-02-03 21:44:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:44:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:44:07 --> Utf8 Class Initialized
INFO - 2017-02-03 21:44:07 --> URI Class Initialized
INFO - 2017-02-03 21:44:07 --> Router Class Initialized
INFO - 2017-02-03 21:44:07 --> Output Class Initialized
INFO - 2017-02-03 21:44:07 --> Security Class Initialized
DEBUG - 2017-02-03 21:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:44:07 --> Input Class Initialized
INFO - 2017-02-03 21:44:07 --> Language Class Initialized
INFO - 2017-02-03 21:44:07 --> Loader Class Initialized
INFO - 2017-02-03 21:44:07 --> Database Driver Class Initialized
INFO - 2017-02-03 21:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:44:07 --> Controller Class Initialized
INFO - 2017-02-03 21:44:07 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:44:07 --> Final output sent to browser
DEBUG - 2017-02-03 21:44:07 --> Total execution time: 0.0128
INFO - 2017-02-03 21:44:09 --> Config Class Initialized
INFO - 2017-02-03 21:44:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:44:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:44:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:44:09 --> URI Class Initialized
INFO - 2017-02-03 21:44:09 --> Router Class Initialized
INFO - 2017-02-03 21:44:09 --> Output Class Initialized
INFO - 2017-02-03 21:44:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:44:09 --> Input Class Initialized
INFO - 2017-02-03 21:44:09 --> Language Class Initialized
INFO - 2017-02-03 21:44:09 --> Loader Class Initialized
INFO - 2017-02-03 21:44:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:44:09 --> Controller Class Initialized
INFO - 2017-02-03 21:44:09 --> Helper loaded: date_helper
INFO - 2017-02-03 21:44:09 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:44:09 --> Helper loaded: form_helper
INFO - 2017-02-03 21:44:09 --> Form Validation Class Initialized
INFO - 2017-02-03 21:44:09 --> Final output sent to browser
DEBUG - 2017-02-03 21:44:09 --> Total execution time: 0.0146
INFO - 2017-02-03 21:45:05 --> Config Class Initialized
INFO - 2017-02-03 21:45:05 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:45:05 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:45:05 --> Utf8 Class Initialized
INFO - 2017-02-03 21:45:05 --> URI Class Initialized
INFO - 2017-02-03 21:45:05 --> Router Class Initialized
INFO - 2017-02-03 21:45:05 --> Output Class Initialized
INFO - 2017-02-03 21:45:05 --> Security Class Initialized
DEBUG - 2017-02-03 21:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:45:05 --> Input Class Initialized
INFO - 2017-02-03 21:45:05 --> Language Class Initialized
INFO - 2017-02-03 21:45:05 --> Loader Class Initialized
INFO - 2017-02-03 21:45:05 --> Database Driver Class Initialized
INFO - 2017-02-03 21:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:45:05 --> Controller Class Initialized
INFO - 2017-02-03 21:45:05 --> Helper loaded: date_helper
INFO - 2017-02-03 21:45:05 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:45:05 --> Helper loaded: form_helper
INFO - 2017-02-03 21:45:05 --> Form Validation Class Initialized
INFO - 2017-02-03 21:45:05 --> Final output sent to browser
DEBUG - 2017-02-03 21:45:05 --> Total execution time: 0.0144
INFO - 2017-02-03 21:49:34 --> Config Class Initialized
INFO - 2017-02-03 21:49:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:49:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:49:34 --> Utf8 Class Initialized
INFO - 2017-02-03 21:49:34 --> URI Class Initialized
INFO - 2017-02-03 21:49:34 --> Router Class Initialized
INFO - 2017-02-03 21:49:34 --> Output Class Initialized
INFO - 2017-02-03 21:49:34 --> Security Class Initialized
DEBUG - 2017-02-03 21:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:49:34 --> Input Class Initialized
INFO - 2017-02-03 21:49:34 --> Language Class Initialized
INFO - 2017-02-03 21:49:34 --> Loader Class Initialized
INFO - 2017-02-03 21:49:34 --> Database Driver Class Initialized
INFO - 2017-02-03 21:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:49:34 --> Controller Class Initialized
INFO - 2017-02-03 21:49:34 --> Helper loaded: date_helper
INFO - 2017-02-03 21:49:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:49:34 --> Helper loaded: form_helper
INFO - 2017-02-03 21:49:34 --> Form Validation Class Initialized
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:49:34 --> Final output sent to browser
DEBUG - 2017-02-03 21:49:34 --> Total execution time: 0.0166
INFO - 2017-02-03 21:49:34 --> Config Class Initialized
INFO - 2017-02-03 21:49:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:49:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:49:34 --> Utf8 Class Initialized
INFO - 2017-02-03 21:49:34 --> URI Class Initialized
INFO - 2017-02-03 21:49:34 --> Router Class Initialized
INFO - 2017-02-03 21:49:34 --> Output Class Initialized
INFO - 2017-02-03 21:49:34 --> Security Class Initialized
DEBUG - 2017-02-03 21:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:49:34 --> Input Class Initialized
INFO - 2017-02-03 21:49:34 --> Language Class Initialized
INFO - 2017-02-03 21:49:34 --> Loader Class Initialized
INFO - 2017-02-03 21:49:34 --> Database Driver Class Initialized
INFO - 2017-02-03 21:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:49:34 --> Controller Class Initialized
INFO - 2017-02-03 21:49:34 --> Helper loaded: date_helper
INFO - 2017-02-03 21:49:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:49:34 --> Helper loaded: form_helper
INFO - 2017-02-03 21:49:34 --> Form Validation Class Initialized
INFO - 2017-02-03 21:49:34 --> Final output sent to browser
DEBUG - 2017-02-03 21:49:34 --> Total execution time: 0.0142
INFO - 2017-02-03 21:49:34 --> Config Class Initialized
INFO - 2017-02-03 21:49:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:49:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:49:34 --> Utf8 Class Initialized
INFO - 2017-02-03 21:49:34 --> URI Class Initialized
INFO - 2017-02-03 21:49:34 --> Router Class Initialized
INFO - 2017-02-03 21:49:34 --> Output Class Initialized
INFO - 2017-02-03 21:49:34 --> Security Class Initialized
DEBUG - 2017-02-03 21:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:49:34 --> Input Class Initialized
INFO - 2017-02-03 21:49:34 --> Language Class Initialized
INFO - 2017-02-03 21:49:34 --> Loader Class Initialized
INFO - 2017-02-03 21:49:34 --> Database Driver Class Initialized
INFO - 2017-02-03 21:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:49:34 --> Controller Class Initialized
INFO - 2017-02-03 21:49:34 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:49:34 --> Final output sent to browser
DEBUG - 2017-02-03 21:49:34 --> Total execution time: 0.0132
INFO - 2017-02-03 21:49:43 --> Config Class Initialized
INFO - 2017-02-03 21:49:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:49:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:49:43 --> Utf8 Class Initialized
INFO - 2017-02-03 21:49:43 --> URI Class Initialized
INFO - 2017-02-03 21:49:43 --> Router Class Initialized
INFO - 2017-02-03 21:49:43 --> Output Class Initialized
INFO - 2017-02-03 21:49:43 --> Security Class Initialized
DEBUG - 2017-02-03 21:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:49:43 --> Input Class Initialized
INFO - 2017-02-03 21:49:43 --> Language Class Initialized
INFO - 2017-02-03 21:49:43 --> Loader Class Initialized
INFO - 2017-02-03 21:49:43 --> Database Driver Class Initialized
INFO - 2017-02-03 21:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:49:43 --> Controller Class Initialized
INFO - 2017-02-03 21:49:43 --> Helper loaded: date_helper
INFO - 2017-02-03 21:49:43 --> Config Class Initialized
INFO - 2017-02-03 21:49:43 --> Hooks Class Initialized
INFO - 2017-02-03 21:49:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:49:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-02-03 21:49:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:49:43 --> Utf8 Class Initialized
INFO - 2017-02-03 21:49:43 --> URI Class Initialized
INFO - 2017-02-03 21:49:43 --> Router Class Initialized
INFO - 2017-02-03 21:49:43 --> Helper loaded: form_helper
INFO - 2017-02-03 21:49:43 --> Form Validation Class Initialized
INFO - 2017-02-03 21:49:43 --> Output Class Initialized
INFO - 2017-02-03 21:49:43 --> Security Class Initialized
DEBUG - 2017-02-03 21:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:49:43 --> Input Class Initialized
INFO - 2017-02-03 21:49:43 --> Language Class Initialized
INFO - 2017-02-03 21:49:43 --> Loader Class Initialized
INFO - 2017-02-03 21:49:43 --> Database Driver Class Initialized
INFO - 2017-02-03 21:49:43 --> Final output sent to browser
DEBUG - 2017-02-03 21:49:43 --> Total execution time: 0.0812
INFO - 2017-02-03 21:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:49:43 --> Controller Class Initialized
INFO - 2017-02-03 21:49:43 --> Helper loaded: date_helper
INFO - 2017-02-03 21:49:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:49:43 --> Helper loaded: form_helper
INFO - 2017-02-03 21:49:43 --> Form Validation Class Initialized
INFO - 2017-02-03 21:49:43 --> Final output sent to browser
DEBUG - 2017-02-03 21:49:43 --> Total execution time: 0.0210
INFO - 2017-02-03 21:49:49 --> Config Class Initialized
INFO - 2017-02-03 21:49:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:49:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:49:49 --> Utf8 Class Initialized
INFO - 2017-02-03 21:49:49 --> URI Class Initialized
INFO - 2017-02-03 21:49:49 --> Router Class Initialized
INFO - 2017-02-03 21:49:49 --> Output Class Initialized
INFO - 2017-02-03 21:49:49 --> Security Class Initialized
DEBUG - 2017-02-03 21:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:49:49 --> Input Class Initialized
INFO - 2017-02-03 21:49:49 --> Language Class Initialized
INFO - 2017-02-03 21:49:49 --> Loader Class Initialized
INFO - 2017-02-03 21:49:49 --> Database Driver Class Initialized
INFO - 2017-02-03 21:49:49 --> Config Class Initialized
INFO - 2017-02-03 21:49:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:49:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:49:49 --> Utf8 Class Initialized
INFO - 2017-02-03 21:49:49 --> URI Class Initialized
INFO - 2017-02-03 21:49:49 --> Router Class Initialized
INFO - 2017-02-03 21:49:49 --> Output Class Initialized
INFO - 2017-02-03 21:49:49 --> Security Class Initialized
DEBUG - 2017-02-03 21:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:49:49 --> Input Class Initialized
INFO - 2017-02-03 21:49:49 --> Language Class Initialized
INFO - 2017-02-03 21:49:49 --> Loader Class Initialized
INFO - 2017-02-03 21:49:49 --> Database Driver Class Initialized
INFO - 2017-02-03 21:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:49:49 --> Controller Class Initialized
INFO - 2017-02-03 21:49:49 --> Helper loaded: date_helper
INFO - 2017-02-03 21:49:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:49:49 --> Helper loaded: form_helper
INFO - 2017-02-03 21:49:49 --> Form Validation Class Initialized
INFO - 2017-02-03 21:49:49 --> Final output sent to browser
DEBUG - 2017-02-03 21:49:49 --> Total execution time: 0.0402
INFO - 2017-02-03 21:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:49:49 --> Controller Class Initialized
INFO - 2017-02-03 21:49:49 --> Helper loaded: date_helper
INFO - 2017-02-03 21:49:49 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:49:49 --> Helper loaded: form_helper
INFO - 2017-02-03 21:49:49 --> Form Validation Class Initialized
INFO - 2017-02-03 21:49:49 --> Final output sent to browser
DEBUG - 2017-02-03 21:49:49 --> Total execution time: 0.0758
INFO - 2017-02-03 21:50:22 --> Config Class Initialized
INFO - 2017-02-03 21:50:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:50:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:50:22 --> Utf8 Class Initialized
INFO - 2017-02-03 21:50:22 --> URI Class Initialized
DEBUG - 2017-02-03 21:50:22 --> No URI present. Default controller set.
INFO - 2017-02-03 21:50:22 --> Router Class Initialized
INFO - 2017-02-03 21:50:22 --> Output Class Initialized
INFO - 2017-02-03 21:50:22 --> Security Class Initialized
DEBUG - 2017-02-03 21:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:50:22 --> Input Class Initialized
INFO - 2017-02-03 21:50:22 --> Language Class Initialized
INFO - 2017-02-03 21:50:22 --> Loader Class Initialized
INFO - 2017-02-03 21:50:22 --> Database Driver Class Initialized
INFO - 2017-02-03 21:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:50:22 --> Controller Class Initialized
INFO - 2017-02-03 21:50:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:50:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:50:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:50:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:50:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:50:22 --> Final output sent to browser
DEBUG - 2017-02-03 21:50:22 --> Total execution time: 0.0165
INFO - 2017-02-03 21:50:23 --> Config Class Initialized
INFO - 2017-02-03 21:50:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:50:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:50:23 --> Utf8 Class Initialized
INFO - 2017-02-03 21:50:23 --> URI Class Initialized
INFO - 2017-02-03 21:50:23 --> Router Class Initialized
INFO - 2017-02-03 21:50:23 --> Output Class Initialized
INFO - 2017-02-03 21:50:23 --> Security Class Initialized
DEBUG - 2017-02-03 21:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:50:23 --> Input Class Initialized
INFO - 2017-02-03 21:50:23 --> Language Class Initialized
INFO - 2017-02-03 21:50:23 --> Loader Class Initialized
INFO - 2017-02-03 21:50:23 --> Database Driver Class Initialized
INFO - 2017-02-03 21:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:50:23 --> Controller Class Initialized
INFO - 2017-02-03 21:50:23 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:50:23 --> Final output sent to browser
DEBUG - 2017-02-03 21:50:23 --> Total execution time: 0.0166
INFO - 2017-02-03 21:50:51 --> Config Class Initialized
INFO - 2017-02-03 21:50:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:50:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:50:51 --> Utf8 Class Initialized
INFO - 2017-02-03 21:50:51 --> URI Class Initialized
INFO - 2017-02-03 21:50:51 --> Router Class Initialized
INFO - 2017-02-03 21:50:51 --> Output Class Initialized
INFO - 2017-02-03 21:50:51 --> Security Class Initialized
DEBUG - 2017-02-03 21:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:50:51 --> Input Class Initialized
INFO - 2017-02-03 21:50:51 --> Language Class Initialized
INFO - 2017-02-03 21:50:51 --> Loader Class Initialized
INFO - 2017-02-03 21:50:51 --> Database Driver Class Initialized
INFO - 2017-02-03 21:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:50:51 --> Controller Class Initialized
INFO - 2017-02-03 21:50:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:50:51 --> Config Class Initialized
INFO - 2017-02-03 21:50:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:50:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:50:51 --> Utf8 Class Initialized
INFO - 2017-02-03 21:50:51 --> URI Class Initialized
INFO - 2017-02-03 21:50:51 --> Router Class Initialized
INFO - 2017-02-03 21:50:51 --> Output Class Initialized
INFO - 2017-02-03 21:50:51 --> Security Class Initialized
DEBUG - 2017-02-03 21:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:50:51 --> Input Class Initialized
INFO - 2017-02-03 21:50:51 --> Language Class Initialized
INFO - 2017-02-03 21:50:51 --> Loader Class Initialized
INFO - 2017-02-03 21:50:51 --> Database Driver Class Initialized
INFO - 2017-02-03 21:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:50:51 --> Controller Class Initialized
INFO - 2017-02-03 21:50:51 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:50:51 --> Helper loaded: url_helper
INFO - 2017-02-03 21:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-03 21:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 21:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:50:51 --> Final output sent to browser
DEBUG - 2017-02-03 21:50:51 --> Total execution time: 0.0144
INFO - 2017-02-03 21:50:52 --> Config Class Initialized
INFO - 2017-02-03 21:50:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:50:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:50:52 --> Utf8 Class Initialized
INFO - 2017-02-03 21:50:52 --> URI Class Initialized
INFO - 2017-02-03 21:50:52 --> Router Class Initialized
INFO - 2017-02-03 21:50:52 --> Output Class Initialized
INFO - 2017-02-03 21:50:52 --> Security Class Initialized
DEBUG - 2017-02-03 21:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:50:52 --> Input Class Initialized
INFO - 2017-02-03 21:50:52 --> Language Class Initialized
INFO - 2017-02-03 21:50:52 --> Loader Class Initialized
INFO - 2017-02-03 21:50:52 --> Database Driver Class Initialized
INFO - 2017-02-03 21:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:50:52 --> Controller Class Initialized
INFO - 2017-02-03 21:50:52 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:50:52 --> Final output sent to browser
DEBUG - 2017-02-03 21:50:52 --> Total execution time: 0.0137
INFO - 2017-02-03 21:50:54 --> Config Class Initialized
INFO - 2017-02-03 21:50:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:50:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:50:54 --> Utf8 Class Initialized
INFO - 2017-02-03 21:50:54 --> URI Class Initialized
INFO - 2017-02-03 21:50:54 --> Router Class Initialized
INFO - 2017-02-03 21:50:54 --> Output Class Initialized
INFO - 2017-02-03 21:50:54 --> Security Class Initialized
DEBUG - 2017-02-03 21:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:50:54 --> Input Class Initialized
INFO - 2017-02-03 21:50:54 --> Language Class Initialized
INFO - 2017-02-03 21:50:54 --> Loader Class Initialized
INFO - 2017-02-03 21:50:54 --> Database Driver Class Initialized
INFO - 2017-02-03 21:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:50:54 --> Controller Class Initialized
INFO - 2017-02-03 21:50:54 --> Helper loaded: date_helper
DEBUG - 2017-02-03 21:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:50:54 --> Helper loaded: url_helper
INFO - 2017-02-03 21:50:54 --> Helper loaded: download_helper
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:50:54 --> Final output sent to browser
DEBUG - 2017-02-03 21:50:54 --> Total execution time: 0.0190
INFO - 2017-02-03 21:50:54 --> Config Class Initialized
INFO - 2017-02-03 21:50:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:50:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:50:54 --> Utf8 Class Initialized
INFO - 2017-02-03 21:50:54 --> URI Class Initialized
INFO - 2017-02-03 21:50:54 --> Router Class Initialized
INFO - 2017-02-03 21:50:54 --> Output Class Initialized
INFO - 2017-02-03 21:50:54 --> Security Class Initialized
DEBUG - 2017-02-03 21:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:50:54 --> Input Class Initialized
INFO - 2017-02-03 21:50:54 --> Language Class Initialized
INFO - 2017-02-03 21:50:54 --> Loader Class Initialized
INFO - 2017-02-03 21:50:54 --> Database Driver Class Initialized
INFO - 2017-02-03 21:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:50:54 --> Controller Class Initialized
INFO - 2017-02-03 21:50:54 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:50:54 --> Final output sent to browser
DEBUG - 2017-02-03 21:50:54 --> Total execution time: 0.0137
INFO - 2017-02-03 21:51:12 --> Config Class Initialized
INFO - 2017-02-03 21:51:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:51:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:51:12 --> Utf8 Class Initialized
INFO - 2017-02-03 21:51:12 --> URI Class Initialized
INFO - 2017-02-03 21:51:12 --> Router Class Initialized
INFO - 2017-02-03 21:51:12 --> Output Class Initialized
INFO - 2017-02-03 21:51:12 --> Security Class Initialized
DEBUG - 2017-02-03 21:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:51:12 --> Input Class Initialized
INFO - 2017-02-03 21:51:12 --> Language Class Initialized
INFO - 2017-02-03 21:51:12 --> Loader Class Initialized
INFO - 2017-02-03 21:51:12 --> Database Driver Class Initialized
INFO - 2017-02-03 21:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:51:12 --> Controller Class Initialized
INFO - 2017-02-03 21:51:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:51:12 --> Config Class Initialized
INFO - 2017-02-03 21:51:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:51:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:51:12 --> Utf8 Class Initialized
INFO - 2017-02-03 21:51:12 --> URI Class Initialized
DEBUG - 2017-02-03 21:51:12 --> No URI present. Default controller set.
INFO - 2017-02-03 21:51:12 --> Router Class Initialized
INFO - 2017-02-03 21:51:12 --> Output Class Initialized
INFO - 2017-02-03 21:51:12 --> Security Class Initialized
DEBUG - 2017-02-03 21:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:51:12 --> Input Class Initialized
INFO - 2017-02-03 21:51:12 --> Language Class Initialized
INFO - 2017-02-03 21:51:12 --> Loader Class Initialized
INFO - 2017-02-03 21:51:12 --> Database Driver Class Initialized
INFO - 2017-02-03 21:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:51:12 --> Controller Class Initialized
INFO - 2017-02-03 21:51:12 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:51:12 --> Final output sent to browser
DEBUG - 2017-02-03 21:51:12 --> Total execution time: 0.0324
INFO - 2017-02-03 21:51:36 --> Config Class Initialized
INFO - 2017-02-03 21:51:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:51:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:51:36 --> Utf8 Class Initialized
INFO - 2017-02-03 21:51:36 --> URI Class Initialized
INFO - 2017-02-03 21:51:36 --> Router Class Initialized
INFO - 2017-02-03 21:51:36 --> Output Class Initialized
INFO - 2017-02-03 21:51:36 --> Security Class Initialized
DEBUG - 2017-02-03 21:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:51:36 --> Input Class Initialized
INFO - 2017-02-03 21:51:36 --> Language Class Initialized
INFO - 2017-02-03 21:51:36 --> Loader Class Initialized
INFO - 2017-02-03 21:51:36 --> Database Driver Class Initialized
INFO - 2017-02-03 21:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:51:36 --> Controller Class Initialized
INFO - 2017-02-03 21:51:36 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:51:37 --> Config Class Initialized
INFO - 2017-02-03 21:51:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:51:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:51:37 --> Utf8 Class Initialized
INFO - 2017-02-03 21:51:37 --> URI Class Initialized
INFO - 2017-02-03 21:51:37 --> Router Class Initialized
INFO - 2017-02-03 21:51:37 --> Output Class Initialized
INFO - 2017-02-03 21:51:37 --> Security Class Initialized
DEBUG - 2017-02-03 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:51:37 --> Input Class Initialized
INFO - 2017-02-03 21:51:37 --> Language Class Initialized
INFO - 2017-02-03 21:51:37 --> Loader Class Initialized
INFO - 2017-02-03 21:51:37 --> Database Driver Class Initialized
INFO - 2017-02-03 21:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:51:37 --> Controller Class Initialized
INFO - 2017-02-03 21:51:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:51:37 --> Helper loaded: form_helper
INFO - 2017-02-03 21:51:37 --> Form Validation Class Initialized
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-03 21:51:37 --> Final output sent to browser
DEBUG - 2017-02-03 21:51:37 --> Total execution time: 0.0127
INFO - 2017-02-03 21:51:37 --> Config Class Initialized
INFO - 2017-02-03 21:51:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:51:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:51:37 --> Utf8 Class Initialized
INFO - 2017-02-03 21:51:37 --> URI Class Initialized
INFO - 2017-02-03 21:51:37 --> Router Class Initialized
INFO - 2017-02-03 21:51:37 --> Output Class Initialized
INFO - 2017-02-03 21:51:37 --> Security Class Initialized
DEBUG - 2017-02-03 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:51:37 --> Input Class Initialized
INFO - 2017-02-03 21:51:37 --> Language Class Initialized
INFO - 2017-02-03 21:51:37 --> Loader Class Initialized
INFO - 2017-02-03 21:51:37 --> Database Driver Class Initialized
INFO - 2017-02-03 21:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:51:37 --> Controller Class Initialized
INFO - 2017-02-03 21:51:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:51:37 --> Final output sent to browser
DEBUG - 2017-02-03 21:51:37 --> Total execution time: 0.0132
INFO - 2017-02-03 21:51:37 --> Config Class Initialized
INFO - 2017-02-03 21:51:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:51:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:51:37 --> Utf8 Class Initialized
INFO - 2017-02-03 21:51:37 --> URI Class Initialized
INFO - 2017-02-03 21:51:37 --> Router Class Initialized
INFO - 2017-02-03 21:51:37 --> Output Class Initialized
INFO - 2017-02-03 21:51:37 --> Security Class Initialized
DEBUG - 2017-02-03 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:51:37 --> Input Class Initialized
INFO - 2017-02-03 21:51:37 --> Language Class Initialized
INFO - 2017-02-03 21:51:37 --> Loader Class Initialized
INFO - 2017-02-03 21:51:37 --> Database Driver Class Initialized
INFO - 2017-02-03 21:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 21:51:37 --> Controller Class Initialized
INFO - 2017-02-03 21:51:37 --> Helper loaded: url_helper
DEBUG - 2017-02-03 21:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 21:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 21:51:37 --> Final output sent to browser
DEBUG - 2017-02-03 21:51:37 --> Total execution time: 0.0137
INFO - 2017-02-03 22:48:17 --> Config Class Initialized
INFO - 2017-02-03 22:48:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:17 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:17 --> URI Class Initialized
DEBUG - 2017-02-03 22:48:17 --> No URI present. Default controller set.
INFO - 2017-02-03 22:48:17 --> Router Class Initialized
INFO - 2017-02-03 22:48:17 --> Output Class Initialized
INFO - 2017-02-03 22:48:17 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:17 --> Input Class Initialized
INFO - 2017-02-03 22:48:17 --> Language Class Initialized
INFO - 2017-02-03 22:48:17 --> Loader Class Initialized
INFO - 2017-02-03 22:48:17 --> Database Driver Class Initialized
INFO - 2017-02-03 22:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:48:17 --> Controller Class Initialized
INFO - 2017-02-03 22:48:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:48:17 --> Final output sent to browser
DEBUG - 2017-02-03 22:48:17 --> Total execution time: 0.0136
INFO - 2017-02-03 22:48:50 --> Config Class Initialized
INFO - 2017-02-03 22:48:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:50 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:50 --> URI Class Initialized
INFO - 2017-02-03 22:48:50 --> Router Class Initialized
INFO - 2017-02-03 22:48:50 --> Output Class Initialized
INFO - 2017-02-03 22:48:50 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:50 --> Input Class Initialized
INFO - 2017-02-03 22:48:50 --> Language Class Initialized
INFO - 2017-02-03 22:48:50 --> Loader Class Initialized
INFO - 2017-02-03 22:48:50 --> Database Driver Class Initialized
INFO - 2017-02-03 22:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:48:50 --> Controller Class Initialized
INFO - 2017-02-03 22:48:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:48:50 --> Final output sent to browser
DEBUG - 2017-02-03 22:48:50 --> Total execution time: 0.0133
INFO - 2017-02-03 22:53:50 --> Config Class Initialized
INFO - 2017-02-03 22:53:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:53:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:53:50 --> Utf8 Class Initialized
INFO - 2017-02-03 22:53:50 --> URI Class Initialized
DEBUG - 2017-02-03 22:53:50 --> No URI present. Default controller set.
INFO - 2017-02-03 22:53:50 --> Router Class Initialized
INFO - 2017-02-03 22:53:50 --> Output Class Initialized
INFO - 2017-02-03 22:53:50 --> Security Class Initialized
DEBUG - 2017-02-03 22:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:53:50 --> Input Class Initialized
INFO - 2017-02-03 22:53:50 --> Language Class Initialized
INFO - 2017-02-03 22:53:50 --> Loader Class Initialized
INFO - 2017-02-03 22:53:50 --> Database Driver Class Initialized
INFO - 2017-02-03 22:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:53:50 --> Controller Class Initialized
INFO - 2017-02-03 22:53:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:53:50 --> Final output sent to browser
DEBUG - 2017-02-03 22:53:50 --> Total execution time: 0.0133
INFO - 2017-02-03 22:53:53 --> Config Class Initialized
INFO - 2017-02-03 22:53:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:53:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:53:53 --> Utf8 Class Initialized
INFO - 2017-02-03 22:53:53 --> URI Class Initialized
INFO - 2017-02-03 22:53:53 --> Router Class Initialized
INFO - 2017-02-03 22:53:53 --> Output Class Initialized
INFO - 2017-02-03 22:53:53 --> Security Class Initialized
DEBUG - 2017-02-03 22:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:53:53 --> Input Class Initialized
INFO - 2017-02-03 22:53:53 --> Language Class Initialized
INFO - 2017-02-03 22:53:53 --> Loader Class Initialized
INFO - 2017-02-03 22:53:53 --> Database Driver Class Initialized
INFO - 2017-02-03 22:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:53:53 --> Controller Class Initialized
INFO - 2017-02-03 22:53:53 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:53:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:53:53 --> Final output sent to browser
DEBUG - 2017-02-03 22:53:53 --> Total execution time: 0.0136
INFO - 2017-02-03 22:54:51 --> Config Class Initialized
INFO - 2017-02-03 22:54:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:54:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:54:51 --> Utf8 Class Initialized
INFO - 2017-02-03 22:54:51 --> URI Class Initialized
INFO - 2017-02-03 22:54:51 --> Router Class Initialized
INFO - 2017-02-03 22:54:51 --> Output Class Initialized
INFO - 2017-02-03 22:54:51 --> Security Class Initialized
DEBUG - 2017-02-03 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:54:51 --> Input Class Initialized
INFO - 2017-02-03 22:54:51 --> Language Class Initialized
INFO - 2017-02-03 22:54:51 --> Loader Class Initialized
INFO - 2017-02-03 22:54:51 --> Database Driver Class Initialized
INFO - 2017-02-03 22:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:54:51 --> Controller Class Initialized
INFO - 2017-02-03 22:54:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:54:51 --> Final output sent to browser
DEBUG - 2017-02-03 22:54:51 --> Total execution time: 0.0146
INFO - 2017-02-03 22:54:54 --> Config Class Initialized
INFO - 2017-02-03 22:54:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:54:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:54:54 --> Utf8 Class Initialized
INFO - 2017-02-03 22:54:54 --> URI Class Initialized
INFO - 2017-02-03 22:54:54 --> Router Class Initialized
INFO - 2017-02-03 22:54:54 --> Output Class Initialized
INFO - 2017-02-03 22:54:54 --> Security Class Initialized
DEBUG - 2017-02-03 22:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:54:54 --> Input Class Initialized
INFO - 2017-02-03 22:54:54 --> Language Class Initialized
INFO - 2017-02-03 22:54:54 --> Loader Class Initialized
INFO - 2017-02-03 22:54:54 --> Database Driver Class Initialized
INFO - 2017-02-03 22:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:54:54 --> Controller Class Initialized
INFO - 2017-02-03 22:54:54 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:54:54 --> Final output sent to browser
DEBUG - 2017-02-03 22:54:54 --> Total execution time: 0.0135
INFO - 2017-02-03 22:55:28 --> Config Class Initialized
INFO - 2017-02-03 22:55:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:55:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:55:28 --> Utf8 Class Initialized
INFO - 2017-02-03 22:55:28 --> URI Class Initialized
INFO - 2017-02-03 22:55:28 --> Router Class Initialized
INFO - 2017-02-03 22:55:28 --> Output Class Initialized
INFO - 2017-02-03 22:55:28 --> Security Class Initialized
DEBUG - 2017-02-03 22:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:55:28 --> Input Class Initialized
INFO - 2017-02-03 22:55:28 --> Language Class Initialized
INFO - 2017-02-03 22:55:28 --> Loader Class Initialized
INFO - 2017-02-03 22:55:28 --> Database Driver Class Initialized
INFO - 2017-02-03 22:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:55:28 --> Controller Class Initialized
INFO - 2017-02-03 22:55:28 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:55:28 --> Final output sent to browser
DEBUG - 2017-02-03 22:55:28 --> Total execution time: 0.0156
INFO - 2017-02-03 22:55:30 --> Config Class Initialized
INFO - 2017-02-03 22:55:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:55:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:55:30 --> Utf8 Class Initialized
INFO - 2017-02-03 22:55:30 --> URI Class Initialized
INFO - 2017-02-03 22:55:30 --> Router Class Initialized
INFO - 2017-02-03 22:55:30 --> Output Class Initialized
INFO - 2017-02-03 22:55:30 --> Security Class Initialized
DEBUG - 2017-02-03 22:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:55:30 --> Input Class Initialized
INFO - 2017-02-03 22:55:30 --> Language Class Initialized
INFO - 2017-02-03 22:55:30 --> Loader Class Initialized
INFO - 2017-02-03 22:55:30 --> Database Driver Class Initialized
INFO - 2017-02-03 22:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:55:30 --> Controller Class Initialized
INFO - 2017-02-03 22:55:30 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:55:30 --> Final output sent to browser
DEBUG - 2017-02-03 22:55:30 --> Total execution time: 0.0141
INFO - 2017-02-03 22:56:00 --> Config Class Initialized
INFO - 2017-02-03 22:56:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:56:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:56:00 --> Utf8 Class Initialized
INFO - 2017-02-03 22:56:00 --> URI Class Initialized
INFO - 2017-02-03 22:56:00 --> Router Class Initialized
INFO - 2017-02-03 22:56:00 --> Output Class Initialized
INFO - 2017-02-03 22:56:00 --> Security Class Initialized
DEBUG - 2017-02-03 22:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:56:00 --> Input Class Initialized
INFO - 2017-02-03 22:56:00 --> Language Class Initialized
INFO - 2017-02-03 22:56:00 --> Loader Class Initialized
INFO - 2017-02-03 22:56:00 --> Database Driver Class Initialized
INFO - 2017-02-03 22:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:56:00 --> Controller Class Initialized
INFO - 2017-02-03 22:56:00 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:56:00 --> Final output sent to browser
DEBUG - 2017-02-03 22:56:00 --> Total execution time: 0.0139
INFO - 2017-02-03 22:56:02 --> Config Class Initialized
INFO - 2017-02-03 22:56:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:56:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:56:02 --> Utf8 Class Initialized
INFO - 2017-02-03 22:56:02 --> URI Class Initialized
INFO - 2017-02-03 22:56:02 --> Router Class Initialized
INFO - 2017-02-03 22:56:02 --> Output Class Initialized
INFO - 2017-02-03 22:56:02 --> Security Class Initialized
DEBUG - 2017-02-03 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:56:02 --> Input Class Initialized
INFO - 2017-02-03 22:56:02 --> Language Class Initialized
INFO - 2017-02-03 22:56:02 --> Loader Class Initialized
INFO - 2017-02-03 22:56:02 --> Database Driver Class Initialized
INFO - 2017-02-03 22:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:56:02 --> Controller Class Initialized
INFO - 2017-02-03 22:56:02 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:56:02 --> Final output sent to browser
DEBUG - 2017-02-03 22:56:02 --> Total execution time: 0.0128
INFO - 2017-02-03 22:56:17 --> Config Class Initialized
INFO - 2017-02-03 22:56:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:56:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:56:17 --> Utf8 Class Initialized
INFO - 2017-02-03 22:56:17 --> URI Class Initialized
DEBUG - 2017-02-03 22:56:17 --> No URI present. Default controller set.
INFO - 2017-02-03 22:56:17 --> Router Class Initialized
INFO - 2017-02-03 22:56:17 --> Output Class Initialized
INFO - 2017-02-03 22:56:17 --> Security Class Initialized
DEBUG - 2017-02-03 22:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:56:17 --> Input Class Initialized
INFO - 2017-02-03 22:56:17 --> Language Class Initialized
INFO - 2017-02-03 22:56:17 --> Loader Class Initialized
INFO - 2017-02-03 22:56:17 --> Database Driver Class Initialized
INFO - 2017-02-03 22:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:56:17 --> Controller Class Initialized
INFO - 2017-02-03 22:56:17 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:56:17 --> Final output sent to browser
DEBUG - 2017-02-03 22:56:17 --> Total execution time: 0.0132
INFO - 2017-02-03 22:56:51 --> Config Class Initialized
INFO - 2017-02-03 22:56:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:56:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:56:51 --> Utf8 Class Initialized
INFO - 2017-02-03 22:56:51 --> URI Class Initialized
INFO - 2017-02-03 22:56:51 --> Router Class Initialized
INFO - 2017-02-03 22:56:51 --> Output Class Initialized
INFO - 2017-02-03 22:56:51 --> Security Class Initialized
DEBUG - 2017-02-03 22:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:56:51 --> Input Class Initialized
INFO - 2017-02-03 22:56:51 --> Language Class Initialized
INFO - 2017-02-03 22:56:51 --> Loader Class Initialized
INFO - 2017-02-03 22:56:51 --> Database Driver Class Initialized
INFO - 2017-02-03 22:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:56:51 --> Controller Class Initialized
INFO - 2017-02-03 22:56:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:56:51 --> Final output sent to browser
DEBUG - 2017-02-03 22:56:51 --> Total execution time: 0.0162
INFO - 2017-02-03 22:56:53 --> Config Class Initialized
INFO - 2017-02-03 22:56:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:56:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:56:53 --> Utf8 Class Initialized
INFO - 2017-02-03 22:56:53 --> URI Class Initialized
INFO - 2017-02-03 22:56:53 --> Router Class Initialized
INFO - 2017-02-03 22:56:53 --> Output Class Initialized
INFO - 2017-02-03 22:56:53 --> Security Class Initialized
DEBUG - 2017-02-03 22:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:56:53 --> Input Class Initialized
INFO - 2017-02-03 22:56:53 --> Language Class Initialized
INFO - 2017-02-03 22:56:53 --> Loader Class Initialized
INFO - 2017-02-03 22:56:53 --> Database Driver Class Initialized
INFO - 2017-02-03 22:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:56:53 --> Controller Class Initialized
INFO - 2017-02-03 22:56:53 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:56:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:56:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:56:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:56:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:56:53 --> Final output sent to browser
DEBUG - 2017-02-03 22:56:53 --> Total execution time: 0.0135
INFO - 2017-02-03 22:58:15 --> Config Class Initialized
INFO - 2017-02-03 22:58:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:58:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:58:15 --> Utf8 Class Initialized
INFO - 2017-02-03 22:58:15 --> URI Class Initialized
DEBUG - 2017-02-03 22:58:15 --> No URI present. Default controller set.
INFO - 2017-02-03 22:58:15 --> Router Class Initialized
INFO - 2017-02-03 22:58:15 --> Output Class Initialized
INFO - 2017-02-03 22:58:15 --> Security Class Initialized
DEBUG - 2017-02-03 22:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:58:15 --> Input Class Initialized
INFO - 2017-02-03 22:58:15 --> Language Class Initialized
INFO - 2017-02-03 22:58:15 --> Loader Class Initialized
INFO - 2017-02-03 22:58:15 --> Database Driver Class Initialized
INFO - 2017-02-03 22:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:58:15 --> Controller Class Initialized
INFO - 2017-02-03 22:58:15 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:58:15 --> Final output sent to browser
DEBUG - 2017-02-03 22:58:15 --> Total execution time: 0.0146
INFO - 2017-02-03 22:58:58 --> Config Class Initialized
INFO - 2017-02-03 22:58:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:58:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:58:58 --> Utf8 Class Initialized
INFO - 2017-02-03 22:58:58 --> URI Class Initialized
INFO - 2017-02-03 22:58:58 --> Router Class Initialized
INFO - 2017-02-03 22:58:58 --> Output Class Initialized
INFO - 2017-02-03 22:58:58 --> Security Class Initialized
DEBUG - 2017-02-03 22:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:58:58 --> Input Class Initialized
INFO - 2017-02-03 22:58:58 --> Language Class Initialized
INFO - 2017-02-03 22:58:58 --> Loader Class Initialized
INFO - 2017-02-03 22:58:58 --> Database Driver Class Initialized
INFO - 2017-02-03 22:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:58:58 --> Controller Class Initialized
INFO - 2017-02-03 22:58:58 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:58:58 --> Final output sent to browser
DEBUG - 2017-02-03 22:58:58 --> Total execution time: 0.0129
INFO - 2017-02-03 22:58:59 --> Config Class Initialized
INFO - 2017-02-03 22:58:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:58:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:58:59 --> Utf8 Class Initialized
INFO - 2017-02-03 22:58:59 --> URI Class Initialized
INFO - 2017-02-03 22:58:59 --> Router Class Initialized
INFO - 2017-02-03 22:58:59 --> Output Class Initialized
INFO - 2017-02-03 22:58:59 --> Security Class Initialized
DEBUG - 2017-02-03 22:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:58:59 --> Input Class Initialized
INFO - 2017-02-03 22:58:59 --> Language Class Initialized
INFO - 2017-02-03 22:58:59 --> Loader Class Initialized
INFO - 2017-02-03 22:58:59 --> Database Driver Class Initialized
INFO - 2017-02-03 22:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:58:59 --> Controller Class Initialized
INFO - 2017-02-03 22:58:59 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:58:59 --> Final output sent to browser
DEBUG - 2017-02-03 22:58:59 --> Total execution time: 0.0156
INFO - 2017-02-03 22:59:08 --> Config Class Initialized
INFO - 2017-02-03 22:59:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:08 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:08 --> URI Class Initialized
INFO - 2017-02-03 22:59:08 --> Router Class Initialized
INFO - 2017-02-03 22:59:08 --> Output Class Initialized
INFO - 2017-02-03 22:59:08 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:08 --> Input Class Initialized
INFO - 2017-02-03 22:59:08 --> Language Class Initialized
INFO - 2017-02-03 22:59:08 --> Loader Class Initialized
INFO - 2017-02-03 22:59:08 --> Database Driver Class Initialized
INFO - 2017-02-03 22:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:59:08 --> Controller Class Initialized
INFO - 2017-02-03 22:59:08 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:59:10 --> Config Class Initialized
INFO - 2017-02-03 22:59:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:10 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:10 --> URI Class Initialized
INFO - 2017-02-03 22:59:10 --> Router Class Initialized
INFO - 2017-02-03 22:59:10 --> Output Class Initialized
INFO - 2017-02-03 22:59:10 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:10 --> Input Class Initialized
INFO - 2017-02-03 22:59:10 --> Language Class Initialized
INFO - 2017-02-03 22:59:10 --> Loader Class Initialized
INFO - 2017-02-03 22:59:10 --> Database Driver Class Initialized
INFO - 2017-02-03 22:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:59:10 --> Controller Class Initialized
INFO - 2017-02-03 22:59:10 --> Helper loaded: date_helper
DEBUG - 2017-02-03 22:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:59:10 --> Helper loaded: url_helper
INFO - 2017-02-03 22:59:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:59:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 22:59:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 22:59:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 22:59:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:59:10 --> Final output sent to browser
DEBUG - 2017-02-03 22:59:10 --> Total execution time: 0.0152
INFO - 2017-02-03 22:59:11 --> Config Class Initialized
INFO - 2017-02-03 22:59:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:11 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:11 --> URI Class Initialized
INFO - 2017-02-03 22:59:11 --> Router Class Initialized
INFO - 2017-02-03 22:59:11 --> Output Class Initialized
INFO - 2017-02-03 22:59:11 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:11 --> Input Class Initialized
INFO - 2017-02-03 22:59:11 --> Language Class Initialized
INFO - 2017-02-03 22:59:11 --> Loader Class Initialized
INFO - 2017-02-03 22:59:11 --> Database Driver Class Initialized
INFO - 2017-02-03 22:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:59:11 --> Controller Class Initialized
INFO - 2017-02-03 22:59:11 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:59:11 --> Final output sent to browser
DEBUG - 2017-02-03 22:59:11 --> Total execution time: 0.0371
INFO - 2017-02-03 22:59:22 --> Config Class Initialized
INFO - 2017-02-03 22:59:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:22 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:22 --> URI Class Initialized
DEBUG - 2017-02-03 22:59:22 --> No URI present. Default controller set.
INFO - 2017-02-03 22:59:22 --> Router Class Initialized
INFO - 2017-02-03 22:59:22 --> Output Class Initialized
INFO - 2017-02-03 22:59:22 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:22 --> Input Class Initialized
INFO - 2017-02-03 22:59:22 --> Language Class Initialized
INFO - 2017-02-03 22:59:22 --> Loader Class Initialized
INFO - 2017-02-03 22:59:22 --> Database Driver Class Initialized
INFO - 2017-02-03 22:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 22:59:22 --> Controller Class Initialized
INFO - 2017-02-03 22:59:22 --> Helper loaded: url_helper
DEBUG - 2017-02-03 22:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 22:59:22 --> Final output sent to browser
DEBUG - 2017-02-03 22:59:22 --> Total execution time: 0.0131
INFO - 2017-02-03 23:00:26 --> Config Class Initialized
INFO - 2017-02-03 23:00:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:26 --> URI Class Initialized
INFO - 2017-02-03 23:00:26 --> Router Class Initialized
INFO - 2017-02-03 23:00:26 --> Output Class Initialized
INFO - 2017-02-03 23:00:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:26 --> Input Class Initialized
INFO - 2017-02-03 23:00:26 --> Language Class Initialized
INFO - 2017-02-03 23:00:26 --> Loader Class Initialized
INFO - 2017-02-03 23:00:26 --> Database Driver Class Initialized
INFO - 2017-02-03 23:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:00:26 --> Controller Class Initialized
INFO - 2017-02-03 23:00:26 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 23:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 23:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 23:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 23:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 23:00:26 --> Final output sent to browser
DEBUG - 2017-02-03 23:00:26 --> Total execution time: 0.0137
INFO - 2017-02-03 23:00:51 --> Config Class Initialized
INFO - 2017-02-03 23:00:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:51 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:51 --> URI Class Initialized
INFO - 2017-02-03 23:00:51 --> Router Class Initialized
INFO - 2017-02-03 23:00:51 --> Output Class Initialized
INFO - 2017-02-03 23:00:51 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:51 --> Input Class Initialized
INFO - 2017-02-03 23:00:51 --> Language Class Initialized
INFO - 2017-02-03 23:00:51 --> Loader Class Initialized
INFO - 2017-02-03 23:00:51 --> Database Driver Class Initialized
INFO - 2017-02-03 23:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:00:51 --> Controller Class Initialized
INFO - 2017-02-03 23:00:51 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 23:00:51 --> Config Class Initialized
INFO - 2017-02-03 23:00:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:51 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:51 --> URI Class Initialized
INFO - 2017-02-03 23:00:51 --> Router Class Initialized
INFO - 2017-02-03 23:00:51 --> Output Class Initialized
INFO - 2017-02-03 23:00:51 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:51 --> Input Class Initialized
INFO - 2017-02-03 23:00:51 --> Language Class Initialized
INFO - 2017-02-03 23:00:51 --> Loader Class Initialized
INFO - 2017-02-03 23:00:51 --> Database Driver Class Initialized
INFO - 2017-02-03 23:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:00:51 --> Controller Class Initialized
INFO - 2017-02-03 23:00:51 --> Helper loaded: date_helper
DEBUG - 2017-02-03 23:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 23:00:51 --> Helper loaded: url_helper
INFO - 2017-02-03 23:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 23:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-03 23:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-03 23:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-03 23:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 23:00:51 --> Final output sent to browser
DEBUG - 2017-02-03 23:00:51 --> Total execution time: 0.0136
INFO - 2017-02-03 23:00:52 --> Config Class Initialized
INFO - 2017-02-03 23:00:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:52 --> URI Class Initialized
INFO - 2017-02-03 23:00:52 --> Router Class Initialized
INFO - 2017-02-03 23:00:52 --> Output Class Initialized
INFO - 2017-02-03 23:00:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:52 --> Input Class Initialized
INFO - 2017-02-03 23:00:52 --> Language Class Initialized
INFO - 2017-02-03 23:00:52 --> Loader Class Initialized
INFO - 2017-02-03 23:00:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:00:52 --> Controller Class Initialized
INFO - 2017-02-03 23:00:52 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 23:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 23:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 23:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 23:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 23:00:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:00:52 --> Total execution time: 0.0139
INFO - 2017-02-03 23:02:10 --> Config Class Initialized
INFO - 2017-02-03 23:02:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:02:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:02:10 --> Utf8 Class Initialized
INFO - 2017-02-03 23:02:10 --> URI Class Initialized
INFO - 2017-02-03 23:02:10 --> Router Class Initialized
INFO - 2017-02-03 23:02:10 --> Output Class Initialized
INFO - 2017-02-03 23:02:10 --> Security Class Initialized
DEBUG - 2017-02-03 23:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:02:10 --> Input Class Initialized
INFO - 2017-02-03 23:02:10 --> Language Class Initialized
INFO - 2017-02-03 23:02:10 --> Loader Class Initialized
INFO - 2017-02-03 23:02:10 --> Database Driver Class Initialized
INFO - 2017-02-03 23:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:02:10 --> Controller Class Initialized
INFO - 2017-02-03 23:02:10 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:02:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 23:02:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 23:02:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liz Venegas')
INFO - 2017-02-03 23:02:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 23:02:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 23:02:25 --> Config Class Initialized
INFO - 2017-02-03 23:02:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:02:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:02:25 --> Utf8 Class Initialized
INFO - 2017-02-03 23:02:25 --> URI Class Initialized
INFO - 2017-02-03 23:02:25 --> Router Class Initialized
INFO - 2017-02-03 23:02:25 --> Output Class Initialized
INFO - 2017-02-03 23:02:25 --> Security Class Initialized
DEBUG - 2017-02-03 23:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:02:25 --> Input Class Initialized
INFO - 2017-02-03 23:02:25 --> Language Class Initialized
INFO - 2017-02-03 23:02:25 --> Loader Class Initialized
INFO - 2017-02-03 23:02:25 --> Database Driver Class Initialized
INFO - 2017-02-03 23:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:02:25 --> Controller Class Initialized
INFO - 2017-02-03 23:02:25 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:02:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-03 23:02:25 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-03 23:02:25 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liz Venegas')
INFO - 2017-02-03 23:02:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-03 23:02:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-03 23:04:50 --> Config Class Initialized
INFO - 2017-02-03 23:04:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:04:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:04:50 --> Utf8 Class Initialized
INFO - 2017-02-03 23:04:50 --> URI Class Initialized
DEBUG - 2017-02-03 23:04:50 --> No URI present. Default controller set.
INFO - 2017-02-03 23:04:50 --> Router Class Initialized
INFO - 2017-02-03 23:04:50 --> Output Class Initialized
INFO - 2017-02-03 23:04:50 --> Security Class Initialized
DEBUG - 2017-02-03 23:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:04:50 --> Input Class Initialized
INFO - 2017-02-03 23:04:50 --> Language Class Initialized
INFO - 2017-02-03 23:04:50 --> Loader Class Initialized
INFO - 2017-02-03 23:04:50 --> Database Driver Class Initialized
INFO - 2017-02-03 23:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:04:50 --> Controller Class Initialized
INFO - 2017-02-03 23:04:50 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 23:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 23:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 23:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 23:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 23:04:50 --> Final output sent to browser
DEBUG - 2017-02-03 23:04:50 --> Total execution time: 0.0135
INFO - 2017-02-03 23:30:43 --> Config Class Initialized
INFO - 2017-02-03 23:30:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:43 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:43 --> URI Class Initialized
INFO - 2017-02-03 23:30:43 --> Router Class Initialized
INFO - 2017-02-03 23:30:43 --> Output Class Initialized
INFO - 2017-02-03 23:30:43 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:43 --> Input Class Initialized
INFO - 2017-02-03 23:30:43 --> Language Class Initialized
INFO - 2017-02-03 23:30:43 --> Loader Class Initialized
INFO - 2017-02-03 23:30:43 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:30:43 --> Controller Class Initialized
INFO - 2017-02-03 23:30:43 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 23:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 23:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 23:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 23:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 23:30:43 --> Final output sent to browser
DEBUG - 2017-02-03 23:30:43 --> Total execution time: 0.0135
INFO - 2017-02-03 23:30:44 --> Config Class Initialized
INFO - 2017-02-03 23:30:44 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:44 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:44 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:44 --> URI Class Initialized
DEBUG - 2017-02-03 23:30:44 --> No URI present. Default controller set.
INFO - 2017-02-03 23:30:44 --> Router Class Initialized
INFO - 2017-02-03 23:30:44 --> Output Class Initialized
INFO - 2017-02-03 23:30:44 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:44 --> Input Class Initialized
INFO - 2017-02-03 23:30:44 --> Language Class Initialized
INFO - 2017-02-03 23:30:44 --> Loader Class Initialized
INFO - 2017-02-03 23:30:44 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-03 23:30:44 --> Controller Class Initialized
INFO - 2017-02-03 23:30:44 --> Helper loaded: url_helper
DEBUG - 2017-02-03 23:30:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-03 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-03 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-03 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-03 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-03 23:30:44 --> Final output sent to browser
DEBUG - 2017-02-03 23:30:44 --> Total execution time: 0.0151

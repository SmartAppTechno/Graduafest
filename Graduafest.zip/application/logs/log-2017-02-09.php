<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-09 04:01:31 --> Config Class Initialized
INFO - 2017-02-09 04:01:31 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:01:31 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:01:31 --> Utf8 Class Initialized
INFO - 2017-02-09 04:01:31 --> URI Class Initialized
INFO - 2017-02-09 04:01:31 --> Router Class Initialized
INFO - 2017-02-09 04:01:31 --> Output Class Initialized
INFO - 2017-02-09 04:01:31 --> Security Class Initialized
DEBUG - 2017-02-09 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:01:31 --> Input Class Initialized
INFO - 2017-02-09 04:01:31 --> Language Class Initialized
INFO - 2017-02-09 04:01:31 --> Loader Class Initialized
INFO - 2017-02-09 04:01:32 --> Database Driver Class Initialized
INFO - 2017-02-09 04:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:01:32 --> Controller Class Initialized
INFO - 2017-02-09 04:01:32 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:01:32 --> Helper loaded: url_helper
INFO - 2017-02-09 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-09 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-09 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-09 04:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:01:32 --> Final output sent to browser
DEBUG - 2017-02-09 04:01:32 --> Total execution time: 1.5959
INFO - 2017-02-09 04:01:35 --> Config Class Initialized
INFO - 2017-02-09 04:01:35 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:01:35 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:01:35 --> Utf8 Class Initialized
INFO - 2017-02-09 04:01:35 --> URI Class Initialized
INFO - 2017-02-09 04:01:35 --> Router Class Initialized
INFO - 2017-02-09 04:01:35 --> Output Class Initialized
INFO - 2017-02-09 04:01:35 --> Security Class Initialized
DEBUG - 2017-02-09 04:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:01:35 --> Input Class Initialized
INFO - 2017-02-09 04:01:35 --> Language Class Initialized
INFO - 2017-02-09 04:01:35 --> Loader Class Initialized
INFO - 2017-02-09 04:01:36 --> Database Driver Class Initialized
INFO - 2017-02-09 04:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:01:36 --> Controller Class Initialized
INFO - 2017-02-09 04:01:36 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:01:36 --> Final output sent to browser
DEBUG - 2017-02-09 04:01:36 --> Total execution time: 1.2429
INFO - 2017-02-09 04:13:41 --> Config Class Initialized
INFO - 2017-02-09 04:13:41 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:13:41 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:13:41 --> Utf8 Class Initialized
INFO - 2017-02-09 04:13:41 --> URI Class Initialized
DEBUG - 2017-02-09 04:13:41 --> No URI present. Default controller set.
INFO - 2017-02-09 04:13:41 --> Router Class Initialized
INFO - 2017-02-09 04:13:41 --> Output Class Initialized
INFO - 2017-02-09 04:13:41 --> Security Class Initialized
DEBUG - 2017-02-09 04:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:13:41 --> Input Class Initialized
INFO - 2017-02-09 04:13:41 --> Language Class Initialized
INFO - 2017-02-09 04:13:41 --> Loader Class Initialized
INFO - 2017-02-09 04:13:42 --> Database Driver Class Initialized
INFO - 2017-02-09 04:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:13:42 --> Controller Class Initialized
INFO - 2017-02-09 04:13:42 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:13:43 --> Final output sent to browser
DEBUG - 2017-02-09 04:13:43 --> Total execution time: 1.4742
INFO - 2017-02-09 04:13:45 --> Config Class Initialized
INFO - 2017-02-09 04:13:45 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:13:45 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:13:45 --> Utf8 Class Initialized
INFO - 2017-02-09 04:13:45 --> URI Class Initialized
INFO - 2017-02-09 04:13:45 --> Router Class Initialized
INFO - 2017-02-09 04:13:45 --> Output Class Initialized
INFO - 2017-02-09 04:13:45 --> Security Class Initialized
DEBUG - 2017-02-09 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:13:45 --> Input Class Initialized
INFO - 2017-02-09 04:13:45 --> Language Class Initialized
INFO - 2017-02-09 04:13:45 --> Loader Class Initialized
INFO - 2017-02-09 04:13:45 --> Database Driver Class Initialized
INFO - 2017-02-09 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:13:45 --> Controller Class Initialized
INFO - 2017-02-09 04:13:45 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:13:45 --> Final output sent to browser
DEBUG - 2017-02-09 04:13:45 --> Total execution time: 0.0132
INFO - 2017-02-09 04:15:00 --> Config Class Initialized
INFO - 2017-02-09 04:15:00 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:15:00 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:15:00 --> Utf8 Class Initialized
INFO - 2017-02-09 04:15:00 --> URI Class Initialized
INFO - 2017-02-09 04:15:00 --> Router Class Initialized
INFO - 2017-02-09 04:15:00 --> Output Class Initialized
INFO - 2017-02-09 04:15:00 --> Security Class Initialized
DEBUG - 2017-02-09 04:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:15:00 --> Input Class Initialized
INFO - 2017-02-09 04:15:00 --> Language Class Initialized
INFO - 2017-02-09 04:15:00 --> Loader Class Initialized
INFO - 2017-02-09 04:15:00 --> Database Driver Class Initialized
INFO - 2017-02-09 04:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:15:00 --> Controller Class Initialized
INFO - 2017-02-09 04:15:00 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:15:01 --> Config Class Initialized
INFO - 2017-02-09 04:15:01 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:15:01 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:15:01 --> Utf8 Class Initialized
INFO - 2017-02-09 04:15:01 --> URI Class Initialized
INFO - 2017-02-09 04:15:01 --> Router Class Initialized
INFO - 2017-02-09 04:15:01 --> Output Class Initialized
INFO - 2017-02-09 04:15:01 --> Security Class Initialized
DEBUG - 2017-02-09 04:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:15:01 --> Input Class Initialized
INFO - 2017-02-09 04:15:01 --> Language Class Initialized
INFO - 2017-02-09 04:15:01 --> Loader Class Initialized
INFO - 2017-02-09 04:15:01 --> Database Driver Class Initialized
INFO - 2017-02-09 04:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:15:01 --> Controller Class Initialized
INFO - 2017-02-09 04:15:01 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:15:01 --> Helper loaded: url_helper
INFO - 2017-02-09 04:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-09 04:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-09 04:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-09 04:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:15:01 --> Final output sent to browser
DEBUG - 2017-02-09 04:15:01 --> Total execution time: 0.3271
INFO - 2017-02-09 04:15:06 --> Config Class Initialized
INFO - 2017-02-09 04:15:06 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:15:06 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:15:06 --> Utf8 Class Initialized
INFO - 2017-02-09 04:15:06 --> URI Class Initialized
INFO - 2017-02-09 04:15:06 --> Router Class Initialized
INFO - 2017-02-09 04:15:06 --> Output Class Initialized
INFO - 2017-02-09 04:15:06 --> Security Class Initialized
DEBUG - 2017-02-09 04:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:15:06 --> Input Class Initialized
INFO - 2017-02-09 04:15:06 --> Language Class Initialized
INFO - 2017-02-09 04:15:06 --> Loader Class Initialized
INFO - 2017-02-09 04:15:06 --> Database Driver Class Initialized
INFO - 2017-02-09 04:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:15:06 --> Controller Class Initialized
INFO - 2017-02-09 04:15:06 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:15:06 --> Final output sent to browser
DEBUG - 2017-02-09 04:15:06 --> Total execution time: 0.0150
INFO - 2017-02-09 04:18:45 --> Config Class Initialized
INFO - 2017-02-09 04:18:45 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:18:45 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:18:45 --> Utf8 Class Initialized
INFO - 2017-02-09 04:18:45 --> URI Class Initialized
INFO - 2017-02-09 04:18:45 --> Router Class Initialized
INFO - 2017-02-09 04:18:45 --> Output Class Initialized
INFO - 2017-02-09 04:18:45 --> Security Class Initialized
DEBUG - 2017-02-09 04:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:18:45 --> Input Class Initialized
INFO - 2017-02-09 04:18:45 --> Language Class Initialized
INFO - 2017-02-09 04:18:45 --> Loader Class Initialized
INFO - 2017-02-09 04:18:46 --> Database Driver Class Initialized
INFO - 2017-02-09 04:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:18:46 --> Controller Class Initialized
INFO - 2017-02-09 04:18:46 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:18:46 --> Helper loaded: url_helper
INFO - 2017-02-09 04:18:46 --> Final output sent to browser
DEBUG - 2017-02-09 04:18:46 --> Total execution time: 0.4769
INFO - 2017-02-09 04:19:52 --> Config Class Initialized
INFO - 2017-02-09 04:19:52 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:19:52 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:19:52 --> Utf8 Class Initialized
INFO - 2017-02-09 04:19:52 --> URI Class Initialized
INFO - 2017-02-09 04:19:52 --> Router Class Initialized
INFO - 2017-02-09 04:19:52 --> Output Class Initialized
INFO - 2017-02-09 04:19:52 --> Security Class Initialized
DEBUG - 2017-02-09 04:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:19:52 --> Input Class Initialized
INFO - 2017-02-09 04:19:52 --> Language Class Initialized
INFO - 2017-02-09 04:19:52 --> Loader Class Initialized
INFO - 2017-02-09 04:19:52 --> Database Driver Class Initialized
INFO - 2017-02-09 04:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:19:52 --> Controller Class Initialized
INFO - 2017-02-09 04:19:52 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:19:52 --> Helper loaded: url_helper
INFO - 2017-02-09 04:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-09 04:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-09 04:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-09 04:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-09 04:19:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:19:52 --> Final output sent to browser
DEBUG - 2017-02-09 04:19:52 --> Total execution time: 0.5210
INFO - 2017-02-09 04:19:56 --> Config Class Initialized
INFO - 2017-02-09 04:19:56 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:19:56 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:19:56 --> Utf8 Class Initialized
INFO - 2017-02-09 04:19:56 --> URI Class Initialized
INFO - 2017-02-09 04:19:56 --> Router Class Initialized
INFO - 2017-02-09 04:19:56 --> Output Class Initialized
INFO - 2017-02-09 04:19:56 --> Security Class Initialized
DEBUG - 2017-02-09 04:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:19:56 --> Input Class Initialized
INFO - 2017-02-09 04:19:56 --> Language Class Initialized
INFO - 2017-02-09 04:19:56 --> Loader Class Initialized
INFO - 2017-02-09 04:19:56 --> Database Driver Class Initialized
INFO - 2017-02-09 04:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:19:56 --> Controller Class Initialized
INFO - 2017-02-09 04:19:56 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:19:56 --> Final output sent to browser
DEBUG - 2017-02-09 04:19:56 --> Total execution time: 0.0482
INFO - 2017-02-09 04:20:10 --> Config Class Initialized
INFO - 2017-02-09 04:20:10 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:10 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:10 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:10 --> URI Class Initialized
INFO - 2017-02-09 04:20:10 --> Router Class Initialized
INFO - 2017-02-09 04:20:10 --> Output Class Initialized
INFO - 2017-02-09 04:20:10 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:10 --> Input Class Initialized
INFO - 2017-02-09 04:20:10 --> Language Class Initialized
INFO - 2017-02-09 04:20:10 --> Loader Class Initialized
INFO - 2017-02-09 04:20:10 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:11 --> Controller Class Initialized
INFO - 2017-02-09 04:20:11 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:11 --> Helper loaded: url_helper
INFO - 2017-02-09 04:20:11 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:11 --> Total execution time: 0.3065
INFO - 2017-02-09 04:20:11 --> Config Class Initialized
INFO - 2017-02-09 04:20:11 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:11 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:11 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:11 --> URI Class Initialized
INFO - 2017-02-09 04:20:11 --> Router Class Initialized
INFO - 2017-02-09 04:20:11 --> Output Class Initialized
INFO - 2017-02-09 04:20:11 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:11 --> Input Class Initialized
INFO - 2017-02-09 04:20:11 --> Language Class Initialized
INFO - 2017-02-09 04:20:11 --> Loader Class Initialized
INFO - 2017-02-09 04:20:11 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:11 --> Controller Class Initialized
INFO - 2017-02-09 04:20:11 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:11 --> Helper loaded: url_helper
INFO - 2017-02-09 04:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-09 04:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-09 04:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-09 04:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-09 04:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:11 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:11 --> Total execution time: 0.0543
INFO - 2017-02-09 04:20:12 --> Config Class Initialized
INFO - 2017-02-09 04:20:12 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:12 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:12 --> URI Class Initialized
INFO - 2017-02-09 04:20:12 --> Router Class Initialized
INFO - 2017-02-09 04:20:12 --> Output Class Initialized
INFO - 2017-02-09 04:20:12 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:12 --> Input Class Initialized
INFO - 2017-02-09 04:20:12 --> Language Class Initialized
INFO - 2017-02-09 04:20:12 --> Loader Class Initialized
INFO - 2017-02-09 04:20:12 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:12 --> Controller Class Initialized
INFO - 2017-02-09 04:20:12 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:12 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:12 --> Total execution time: 0.0137
INFO - 2017-02-09 04:20:17 --> Config Class Initialized
INFO - 2017-02-09 04:20:17 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:17 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:17 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:17 --> URI Class Initialized
INFO - 2017-02-09 04:20:17 --> Router Class Initialized
INFO - 2017-02-09 04:20:17 --> Output Class Initialized
INFO - 2017-02-09 04:20:17 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:17 --> Input Class Initialized
INFO - 2017-02-09 04:20:17 --> Language Class Initialized
INFO - 2017-02-09 04:20:17 --> Loader Class Initialized
INFO - 2017-02-09 04:20:17 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:17 --> Controller Class Initialized
INFO - 2017-02-09 04:20:17 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:17 --> Helper loaded: url_helper
INFO - 2017-02-09 04:20:17 --> Helper loaded: download_helper
INFO - 2017-02-09 04:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-09 04:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-09 04:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-09 04:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:17 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:17 --> Total execution time: 0.1281
INFO - 2017-02-09 04:20:19 --> Config Class Initialized
INFO - 2017-02-09 04:20:19 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:19 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:19 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:19 --> URI Class Initialized
INFO - 2017-02-09 04:20:19 --> Router Class Initialized
INFO - 2017-02-09 04:20:19 --> Output Class Initialized
INFO - 2017-02-09 04:20:19 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:19 --> Input Class Initialized
INFO - 2017-02-09 04:20:19 --> Language Class Initialized
INFO - 2017-02-09 04:20:19 --> Loader Class Initialized
INFO - 2017-02-09 04:20:19 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:19 --> Controller Class Initialized
INFO - 2017-02-09 04:20:19 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:20:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:19 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:19 --> Total execution time: 0.0136
INFO - 2017-02-09 04:20:29 --> Config Class Initialized
INFO - 2017-02-09 04:20:29 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:29 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:29 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:29 --> URI Class Initialized
INFO - 2017-02-09 04:20:29 --> Router Class Initialized
INFO - 2017-02-09 04:20:29 --> Output Class Initialized
INFO - 2017-02-09 04:20:29 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:29 --> Input Class Initialized
INFO - 2017-02-09 04:20:29 --> Language Class Initialized
INFO - 2017-02-09 04:20:29 --> Loader Class Initialized
INFO - 2017-02-09 04:20:29 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:29 --> Controller Class Initialized
INFO - 2017-02-09 04:20:29 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:29 --> Helper loaded: url_helper
INFO - 2017-02-09 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-09 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-09 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-09 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:29 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:29 --> Total execution time: 0.0152
INFO - 2017-02-09 04:20:30 --> Config Class Initialized
INFO - 2017-02-09 04:20:30 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:30 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:30 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:30 --> URI Class Initialized
INFO - 2017-02-09 04:20:30 --> Router Class Initialized
INFO - 2017-02-09 04:20:30 --> Output Class Initialized
INFO - 2017-02-09 04:20:30 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:30 --> Input Class Initialized
INFO - 2017-02-09 04:20:30 --> Language Class Initialized
INFO - 2017-02-09 04:20:30 --> Loader Class Initialized
INFO - 2017-02-09 04:20:30 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:30 --> Controller Class Initialized
INFO - 2017-02-09 04:20:30 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:30 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:30 --> Total execution time: 0.0140
INFO - 2017-02-09 04:20:34 --> Config Class Initialized
INFO - 2017-02-09 04:20:34 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:34 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:34 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:34 --> URI Class Initialized
INFO - 2017-02-09 04:20:34 --> Router Class Initialized
INFO - 2017-02-09 04:20:34 --> Output Class Initialized
INFO - 2017-02-09 04:20:34 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:34 --> Input Class Initialized
INFO - 2017-02-09 04:20:34 --> Language Class Initialized
INFO - 2017-02-09 04:20:34 --> Loader Class Initialized
INFO - 2017-02-09 04:20:34 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:34 --> Controller Class Initialized
INFO - 2017-02-09 04:20:34 --> Helper loaded: date_helper
DEBUG - 2017-02-09 04:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:34 --> Helper loaded: url_helper
INFO - 2017-02-09 04:20:34 --> Helper loaded: download_helper
INFO - 2017-02-09 04:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-09 04:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-09 04:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-09 04:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:34 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:34 --> Total execution time: 0.0188
INFO - 2017-02-09 04:20:35 --> Config Class Initialized
INFO - 2017-02-09 04:20:35 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:20:35 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:20:35 --> Utf8 Class Initialized
INFO - 2017-02-09 04:20:35 --> URI Class Initialized
INFO - 2017-02-09 04:20:35 --> Router Class Initialized
INFO - 2017-02-09 04:20:35 --> Output Class Initialized
INFO - 2017-02-09 04:20:35 --> Security Class Initialized
DEBUG - 2017-02-09 04:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:20:35 --> Input Class Initialized
INFO - 2017-02-09 04:20:35 --> Language Class Initialized
INFO - 2017-02-09 04:20:35 --> Loader Class Initialized
INFO - 2017-02-09 04:20:35 --> Database Driver Class Initialized
INFO - 2017-02-09 04:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:20:35 --> Controller Class Initialized
INFO - 2017-02-09 04:20:35 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:20:35 --> Final output sent to browser
DEBUG - 2017-02-09 04:20:35 --> Total execution time: 0.0135
INFO - 2017-02-09 04:38:07 --> Config Class Initialized
INFO - 2017-02-09 04:38:07 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:38:07 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:38:07 --> Utf8 Class Initialized
INFO - 2017-02-09 04:38:07 --> URI Class Initialized
DEBUG - 2017-02-09 04:38:07 --> No URI present. Default controller set.
INFO - 2017-02-09 04:38:07 --> Router Class Initialized
INFO - 2017-02-09 04:38:07 --> Output Class Initialized
INFO - 2017-02-09 04:38:07 --> Security Class Initialized
DEBUG - 2017-02-09 04:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:38:07 --> Input Class Initialized
INFO - 2017-02-09 04:38:07 --> Language Class Initialized
INFO - 2017-02-09 04:38:07 --> Loader Class Initialized
INFO - 2017-02-09 04:38:08 --> Database Driver Class Initialized
INFO - 2017-02-09 04:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:38:08 --> Controller Class Initialized
INFO - 2017-02-09 04:38:08 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:38:08 --> Final output sent to browser
DEBUG - 2017-02-09 04:38:08 --> Total execution time: 1.4843
INFO - 2017-02-09 04:39:13 --> Config Class Initialized
INFO - 2017-02-09 04:39:13 --> Hooks Class Initialized
DEBUG - 2017-02-09 04:39:13 --> UTF-8 Support Enabled
INFO - 2017-02-09 04:39:13 --> Utf8 Class Initialized
INFO - 2017-02-09 04:39:13 --> URI Class Initialized
DEBUG - 2017-02-09 04:39:13 --> No URI present. Default controller set.
INFO - 2017-02-09 04:39:13 --> Router Class Initialized
INFO - 2017-02-09 04:39:13 --> Output Class Initialized
INFO - 2017-02-09 04:39:13 --> Security Class Initialized
DEBUG - 2017-02-09 04:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 04:39:13 --> Input Class Initialized
INFO - 2017-02-09 04:39:13 --> Language Class Initialized
INFO - 2017-02-09 04:39:13 --> Loader Class Initialized
INFO - 2017-02-09 04:39:13 --> Database Driver Class Initialized
INFO - 2017-02-09 04:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 04:39:13 --> Controller Class Initialized
INFO - 2017-02-09 04:39:13 --> Helper loaded: url_helper
DEBUG - 2017-02-09 04:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 04:39:13 --> Final output sent to browser
DEBUG - 2017-02-09 04:39:13 --> Total execution time: 0.0137
INFO - 2017-02-09 06:44:34 --> Config Class Initialized
INFO - 2017-02-09 06:44:34 --> Hooks Class Initialized
DEBUG - 2017-02-09 06:44:34 --> UTF-8 Support Enabled
INFO - 2017-02-09 06:44:34 --> Utf8 Class Initialized
INFO - 2017-02-09 06:44:34 --> URI Class Initialized
INFO - 2017-02-09 06:44:34 --> Router Class Initialized
INFO - 2017-02-09 06:44:34 --> Output Class Initialized
INFO - 2017-02-09 06:44:34 --> Security Class Initialized
DEBUG - 2017-02-09 06:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 06:44:34 --> Input Class Initialized
INFO - 2017-02-09 06:44:34 --> Language Class Initialized
INFO - 2017-02-09 06:44:34 --> Loader Class Initialized
INFO - 2017-02-09 06:44:34 --> Database Driver Class Initialized
INFO - 2017-02-09 06:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 06:44:35 --> Controller Class Initialized
INFO - 2017-02-09 06:44:35 --> Helper loaded: url_helper
DEBUG - 2017-02-09 06:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 06:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 06:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 06:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 06:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 06:44:35 --> Final output sent to browser
DEBUG - 2017-02-09 06:44:35 --> Total execution time: 1.5709
INFO - 2017-02-09 07:07:01 --> Config Class Initialized
INFO - 2017-02-09 07:07:01 --> Hooks Class Initialized
DEBUG - 2017-02-09 07:07:01 --> UTF-8 Support Enabled
INFO - 2017-02-09 07:07:01 --> Utf8 Class Initialized
INFO - 2017-02-09 07:07:01 --> URI Class Initialized
DEBUG - 2017-02-09 07:07:01 --> No URI present. Default controller set.
INFO - 2017-02-09 07:07:01 --> Router Class Initialized
INFO - 2017-02-09 07:07:01 --> Output Class Initialized
INFO - 2017-02-09 07:07:01 --> Security Class Initialized
DEBUG - 2017-02-09 07:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 07:07:01 --> Input Class Initialized
INFO - 2017-02-09 07:07:01 --> Language Class Initialized
INFO - 2017-02-09 07:07:01 --> Loader Class Initialized
INFO - 2017-02-09 07:07:02 --> Database Driver Class Initialized
INFO - 2017-02-09 07:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 07:07:02 --> Controller Class Initialized
INFO - 2017-02-09 07:07:02 --> Helper loaded: url_helper
DEBUG - 2017-02-09 07:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 07:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 07:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 07:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 07:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 07:07:02 --> Final output sent to browser
DEBUG - 2017-02-09 07:07:02 --> Total execution time: 1.4898
INFO - 2017-02-09 07:07:16 --> Config Class Initialized
INFO - 2017-02-09 07:07:16 --> Hooks Class Initialized
DEBUG - 2017-02-09 07:07:16 --> UTF-8 Support Enabled
INFO - 2017-02-09 07:07:16 --> Utf8 Class Initialized
INFO - 2017-02-09 07:07:16 --> URI Class Initialized
INFO - 2017-02-09 07:07:16 --> Router Class Initialized
INFO - 2017-02-09 07:07:16 --> Output Class Initialized
INFO - 2017-02-09 07:07:16 --> Security Class Initialized
DEBUG - 2017-02-09 07:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 07:07:16 --> Input Class Initialized
INFO - 2017-02-09 07:07:16 --> Language Class Initialized
INFO - 2017-02-09 07:07:16 --> Loader Class Initialized
INFO - 2017-02-09 07:07:16 --> Database Driver Class Initialized
INFO - 2017-02-09 07:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 07:07:16 --> Controller Class Initialized
INFO - 2017-02-09 07:07:16 --> Helper loaded: url_helper
DEBUG - 2017-02-09 07:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 07:07:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 07:07:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 07:07:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 07:07:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 07:07:16 --> Final output sent to browser
DEBUG - 2017-02-09 07:07:16 --> Total execution time: 0.0149
INFO - 2017-02-09 07:21:28 --> Config Class Initialized
INFO - 2017-02-09 07:21:28 --> Hooks Class Initialized
DEBUG - 2017-02-09 07:21:29 --> UTF-8 Support Enabled
INFO - 2017-02-09 07:21:29 --> Utf8 Class Initialized
INFO - 2017-02-09 07:21:29 --> URI Class Initialized
DEBUG - 2017-02-09 07:21:29 --> No URI present. Default controller set.
INFO - 2017-02-09 07:21:29 --> Router Class Initialized
INFO - 2017-02-09 07:21:29 --> Output Class Initialized
INFO - 2017-02-09 07:21:29 --> Security Class Initialized
DEBUG - 2017-02-09 07:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 07:21:29 --> Input Class Initialized
INFO - 2017-02-09 07:21:29 --> Language Class Initialized
INFO - 2017-02-09 07:21:29 --> Loader Class Initialized
INFO - 2017-02-09 07:21:29 --> Database Driver Class Initialized
INFO - 2017-02-09 07:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 07:21:29 --> Controller Class Initialized
INFO - 2017-02-09 07:21:29 --> Helper loaded: url_helper
DEBUG - 2017-02-09 07:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 07:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 07:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 07:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 07:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 07:21:30 --> Final output sent to browser
DEBUG - 2017-02-09 07:21:30 --> Total execution time: 1.4710
INFO - 2017-02-09 10:21:49 --> Config Class Initialized
INFO - 2017-02-09 10:22:02 --> Hooks Class Initialized
DEBUG - 2017-02-09 10:22:25 --> UTF-8 Support Enabled
INFO - 2017-02-09 10:22:32 --> Utf8 Class Initialized
INFO - 2017-02-09 10:22:40 --> URI Class Initialized
DEBUG - 2017-02-09 10:22:41 --> No URI present. Default controller set.
INFO - 2017-02-09 10:22:41 --> Router Class Initialized
INFO - 2017-02-09 10:22:42 --> Output Class Initialized
INFO - 2017-02-09 10:22:43 --> Security Class Initialized
DEBUG - 2017-02-09 10:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 10:22:43 --> Input Class Initialized
INFO - 2017-02-09 10:22:43 --> Language Class Initialized
INFO - 2017-02-09 10:22:45 --> Loader Class Initialized
INFO - 2017-02-09 10:22:50 --> Database Driver Class Initialized
INFO - 2017-02-09 10:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 10:25:24 --> Controller Class Initialized
INFO - 2017-02-09 10:26:32 --> Helper loaded: url_helper
DEBUG - 2017-02-09 10:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 10:28:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 10:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 10:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 11:01:52 --> Config Class Initialized
INFO - 2017-02-09 11:01:53 --> Hooks Class Initialized
DEBUG - 2017-02-09 11:01:53 --> UTF-8 Support Enabled
INFO - 2017-02-09 11:01:53 --> Utf8 Class Initialized
INFO - 2017-02-09 11:01:53 --> URI Class Initialized
INFO - 2017-02-09 11:01:53 --> Router Class Initialized
INFO - 2017-02-09 11:01:53 --> Output Class Initialized
INFO - 2017-02-09 11:01:53 --> Security Class Initialized
DEBUG - 2017-02-09 11:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 11:01:53 --> Input Class Initialized
INFO - 2017-02-09 11:01:53 --> Language Class Initialized
INFO - 2017-02-09 11:01:53 --> Loader Class Initialized
INFO - 2017-02-09 11:01:53 --> Database Driver Class Initialized
INFO - 2017-02-09 11:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 11:01:54 --> Controller Class Initialized
INFO - 2017-02-09 11:01:54 --> Helper loaded: url_helper
DEBUG - 2017-02-09 11:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 11:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 11:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 11:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 11:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 11:01:54 --> Final output sent to browser
DEBUG - 2017-02-09 11:01:54 --> Total execution time: 1.5677
INFO - 2017-02-09 11:03:12 --> Config Class Initialized
INFO - 2017-02-09 11:03:12 --> Hooks Class Initialized
DEBUG - 2017-02-09 11:03:12 --> UTF-8 Support Enabled
INFO - 2017-02-09 11:03:12 --> Utf8 Class Initialized
INFO - 2017-02-09 11:03:12 --> URI Class Initialized
DEBUG - 2017-02-09 11:03:12 --> No URI present. Default controller set.
INFO - 2017-02-09 11:03:12 --> Router Class Initialized
INFO - 2017-02-09 11:03:12 --> Output Class Initialized
INFO - 2017-02-09 11:03:12 --> Security Class Initialized
DEBUG - 2017-02-09 11:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 11:03:12 --> Input Class Initialized
INFO - 2017-02-09 11:03:12 --> Language Class Initialized
INFO - 2017-02-09 11:03:12 --> Loader Class Initialized
INFO - 2017-02-09 11:03:13 --> Database Driver Class Initialized
INFO - 2017-02-09 11:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 11:03:13 --> Controller Class Initialized
INFO - 2017-02-09 11:03:13 --> Helper loaded: url_helper
DEBUG - 2017-02-09 11:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 11:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 11:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 11:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 11:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 11:03:13 --> Final output sent to browser
DEBUG - 2017-02-09 11:03:13 --> Total execution time: 1.7676
INFO - 2017-02-09 11:44:02 --> Config Class Initialized
INFO - 2017-02-09 11:44:02 --> Hooks Class Initialized
DEBUG - 2017-02-09 11:44:03 --> UTF-8 Support Enabled
INFO - 2017-02-09 11:44:03 --> Utf8 Class Initialized
INFO - 2017-02-09 11:44:03 --> URI Class Initialized
DEBUG - 2017-02-09 11:44:03 --> No URI present. Default controller set.
INFO - 2017-02-09 11:44:03 --> Router Class Initialized
INFO - 2017-02-09 11:44:03 --> Output Class Initialized
INFO - 2017-02-09 11:44:03 --> Security Class Initialized
DEBUG - 2017-02-09 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 11:44:03 --> Input Class Initialized
INFO - 2017-02-09 11:44:03 --> Language Class Initialized
INFO - 2017-02-09 11:44:03 --> Loader Class Initialized
INFO - 2017-02-09 11:44:03 --> Database Driver Class Initialized
INFO - 2017-02-09 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 11:44:04 --> Controller Class Initialized
INFO - 2017-02-09 11:44:04 --> Helper loaded: url_helper
DEBUG - 2017-02-09 11:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 11:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 11:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 11:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 11:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 11:44:04 --> Final output sent to browser
DEBUG - 2017-02-09 11:44:04 --> Total execution time: 1.8472
INFO - 2017-02-09 13:26:23 --> Config Class Initialized
INFO - 2017-02-09 13:26:23 --> Hooks Class Initialized
DEBUG - 2017-02-09 13:26:23 --> UTF-8 Support Enabled
INFO - 2017-02-09 13:26:23 --> Utf8 Class Initialized
INFO - 2017-02-09 13:26:23 --> URI Class Initialized
INFO - 2017-02-09 13:26:23 --> Router Class Initialized
INFO - 2017-02-09 13:26:23 --> Output Class Initialized
INFO - 2017-02-09 13:26:23 --> Security Class Initialized
DEBUG - 2017-02-09 13:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 13:26:23 --> Input Class Initialized
INFO - 2017-02-09 13:26:23 --> Language Class Initialized
INFO - 2017-02-09 13:26:23 --> Loader Class Initialized
INFO - 2017-02-09 13:26:24 --> Database Driver Class Initialized
INFO - 2017-02-09 13:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 13:26:24 --> Controller Class Initialized
INFO - 2017-02-09 13:26:24 --> Helper loaded: url_helper
DEBUG - 2017-02-09 13:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 13:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 13:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 13:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 13:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 13:26:24 --> Final output sent to browser
DEBUG - 2017-02-09 13:26:24 --> Total execution time: 1.7480
INFO - 2017-02-09 13:26:28 --> Config Class Initialized
INFO - 2017-02-09 13:26:28 --> Hooks Class Initialized
DEBUG - 2017-02-09 13:26:28 --> UTF-8 Support Enabled
INFO - 2017-02-09 13:26:28 --> Utf8 Class Initialized
INFO - 2017-02-09 13:26:28 --> URI Class Initialized
DEBUG - 2017-02-09 13:26:28 --> No URI present. Default controller set.
INFO - 2017-02-09 13:26:28 --> Router Class Initialized
INFO - 2017-02-09 13:26:28 --> Output Class Initialized
INFO - 2017-02-09 13:26:28 --> Security Class Initialized
DEBUG - 2017-02-09 13:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 13:26:28 --> Input Class Initialized
INFO - 2017-02-09 13:26:28 --> Language Class Initialized
INFO - 2017-02-09 13:26:28 --> Loader Class Initialized
INFO - 2017-02-09 13:26:28 --> Database Driver Class Initialized
INFO - 2017-02-09 13:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 13:26:28 --> Controller Class Initialized
INFO - 2017-02-09 13:26:28 --> Helper loaded: url_helper
DEBUG - 2017-02-09 13:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 13:26:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 13:26:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 13:26:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 13:26:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 13:26:28 --> Final output sent to browser
DEBUG - 2017-02-09 13:26:28 --> Total execution time: 0.0135
INFO - 2017-02-09 17:15:49 --> Config Class Initialized
INFO - 2017-02-09 17:15:49 --> Hooks Class Initialized
DEBUG - 2017-02-09 17:15:49 --> UTF-8 Support Enabled
INFO - 2017-02-09 17:15:49 --> Utf8 Class Initialized
INFO - 2017-02-09 17:15:49 --> URI Class Initialized
DEBUG - 2017-02-09 17:15:49 --> No URI present. Default controller set.
INFO - 2017-02-09 17:15:49 --> Router Class Initialized
INFO - 2017-02-09 17:15:50 --> Output Class Initialized
INFO - 2017-02-09 17:15:50 --> Security Class Initialized
DEBUG - 2017-02-09 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 17:15:50 --> Input Class Initialized
INFO - 2017-02-09 17:15:50 --> Language Class Initialized
INFO - 2017-02-09 17:15:50 --> Loader Class Initialized
INFO - 2017-02-09 17:15:50 --> Database Driver Class Initialized
INFO - 2017-02-09 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 17:15:50 --> Controller Class Initialized
INFO - 2017-02-09 17:15:50 --> Helper loaded: url_helper
DEBUG - 2017-02-09 17:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 17:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 17:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 17:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 17:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 17:15:51 --> Final output sent to browser
DEBUG - 2017-02-09 17:15:51 --> Total execution time: 1.4101
INFO - 2017-02-09 17:16:11 --> Config Class Initialized
INFO - 2017-02-09 17:16:11 --> Hooks Class Initialized
DEBUG - 2017-02-09 17:16:11 --> UTF-8 Support Enabled
INFO - 2017-02-09 17:16:11 --> Utf8 Class Initialized
INFO - 2017-02-09 17:16:11 --> URI Class Initialized
INFO - 2017-02-09 17:16:11 --> Router Class Initialized
INFO - 2017-02-09 17:16:11 --> Output Class Initialized
INFO - 2017-02-09 17:16:11 --> Security Class Initialized
DEBUG - 2017-02-09 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 17:16:11 --> Input Class Initialized
INFO - 2017-02-09 17:16:11 --> Language Class Initialized
INFO - 2017-02-09 17:16:11 --> Loader Class Initialized
INFO - 2017-02-09 17:16:11 --> Database Driver Class Initialized
INFO - 2017-02-09 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 17:16:11 --> Controller Class Initialized
INFO - 2017-02-09 17:16:11 --> Helper loaded: url_helper
DEBUG - 2017-02-09 17:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 17:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 17:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 17:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 17:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 17:16:11 --> Final output sent to browser
DEBUG - 2017-02-09 17:16:11 --> Total execution time: 0.0480
INFO - 2017-02-09 19:23:09 --> Config Class Initialized
INFO - 2017-02-09 19:23:09 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:09 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:09 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:09 --> URI Class Initialized
DEBUG - 2017-02-09 19:23:09 --> No URI present. Default controller set.
INFO - 2017-02-09 19:23:09 --> Router Class Initialized
INFO - 2017-02-09 19:23:09 --> Output Class Initialized
INFO - 2017-02-09 19:23:09 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:09 --> Input Class Initialized
INFO - 2017-02-09 19:23:09 --> Language Class Initialized
INFO - 2017-02-09 19:23:09 --> Loader Class Initialized
INFO - 2017-02-09 19:23:09 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:09 --> Controller Class Initialized
INFO - 2017-02-09 19:23:09 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:09 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:09 --> Total execution time: 0.0139
INFO - 2017-02-09 19:23:12 --> Config Class Initialized
INFO - 2017-02-09 19:23:12 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:12 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:12 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:12 --> URI Class Initialized
DEBUG - 2017-02-09 19:23:12 --> No URI present. Default controller set.
INFO - 2017-02-09 19:23:12 --> Router Class Initialized
INFO - 2017-02-09 19:23:12 --> Output Class Initialized
INFO - 2017-02-09 19:23:12 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:12 --> Input Class Initialized
INFO - 2017-02-09 19:23:12 --> Language Class Initialized
INFO - 2017-02-09 19:23:12 --> Loader Class Initialized
INFO - 2017-02-09 19:23:12 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:12 --> Controller Class Initialized
INFO - 2017-02-09 19:23:12 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:12 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:12 --> Total execution time: 0.0565
INFO - 2017-02-09 19:23:14 --> Config Class Initialized
INFO - 2017-02-09 19:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:14 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:14 --> URI Class Initialized
INFO - 2017-02-09 19:23:14 --> Router Class Initialized
INFO - 2017-02-09 19:23:14 --> Output Class Initialized
INFO - 2017-02-09 19:23:14 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:14 --> Input Class Initialized
INFO - 2017-02-09 19:23:14 --> Language Class Initialized
INFO - 2017-02-09 19:23:14 --> Loader Class Initialized
INFO - 2017-02-09 19:23:14 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:14 --> Controller Class Initialized
INFO - 2017-02-09 19:23:14 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:14 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:14 --> Total execution time: 0.0141
INFO - 2017-02-09 19:23:14 --> Config Class Initialized
INFO - 2017-02-09 19:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:14 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:14 --> URI Class Initialized
INFO - 2017-02-09 19:23:14 --> Router Class Initialized
INFO - 2017-02-09 19:23:14 --> Output Class Initialized
INFO - 2017-02-09 19:23:14 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:14 --> Input Class Initialized
INFO - 2017-02-09 19:23:14 --> Language Class Initialized
INFO - 2017-02-09 19:23:14 --> Loader Class Initialized
INFO - 2017-02-09 19:23:14 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:14 --> Controller Class Initialized
INFO - 2017-02-09 19:23:14 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:14 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:14 --> Total execution time: 0.0139
INFO - 2017-02-09 19:23:31 --> Config Class Initialized
INFO - 2017-02-09 19:23:31 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:31 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:31 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:31 --> URI Class Initialized
INFO - 2017-02-09 19:23:31 --> Router Class Initialized
INFO - 2017-02-09 19:23:31 --> Output Class Initialized
INFO - 2017-02-09 19:23:31 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:31 --> Input Class Initialized
INFO - 2017-02-09 19:23:31 --> Language Class Initialized
INFO - 2017-02-09 19:23:31 --> Loader Class Initialized
INFO - 2017-02-09 19:23:31 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:31 --> Controller Class Initialized
INFO - 2017-02-09 19:23:31 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:33 --> Config Class Initialized
INFO - 2017-02-09 19:23:33 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:33 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:33 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:33 --> URI Class Initialized
INFO - 2017-02-09 19:23:33 --> Router Class Initialized
INFO - 2017-02-09 19:23:33 --> Output Class Initialized
INFO - 2017-02-09 19:23:33 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:33 --> Input Class Initialized
INFO - 2017-02-09 19:23:33 --> Language Class Initialized
INFO - 2017-02-09 19:23:33 --> Loader Class Initialized
INFO - 2017-02-09 19:23:33 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:33 --> Controller Class Initialized
INFO - 2017-02-09 19:23:33 --> Helper loaded: date_helper
DEBUG - 2017-02-09 19:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:33 --> Helper loaded: url_helper
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:33 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:33 --> Total execution time: 0.1047
INFO - 2017-02-09 19:23:33 --> Config Class Initialized
INFO - 2017-02-09 19:23:33 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:33 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:33 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:33 --> URI Class Initialized
INFO - 2017-02-09 19:23:33 --> Router Class Initialized
INFO - 2017-02-09 19:23:33 --> Output Class Initialized
INFO - 2017-02-09 19:23:33 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:33 --> Input Class Initialized
INFO - 2017-02-09 19:23:33 --> Language Class Initialized
INFO - 2017-02-09 19:23:33 --> Loader Class Initialized
INFO - 2017-02-09 19:23:33 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:33 --> Controller Class Initialized
INFO - 2017-02-09 19:23:33 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:33 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:33 --> Total execution time: 0.0140
INFO - 2017-02-09 19:23:42 --> Config Class Initialized
INFO - 2017-02-09 19:23:42 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:42 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:42 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:42 --> URI Class Initialized
DEBUG - 2017-02-09 19:23:42 --> No URI present. Default controller set.
INFO - 2017-02-09 19:23:42 --> Router Class Initialized
INFO - 2017-02-09 19:23:42 --> Output Class Initialized
INFO - 2017-02-09 19:23:42 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:42 --> Input Class Initialized
INFO - 2017-02-09 19:23:42 --> Language Class Initialized
INFO - 2017-02-09 19:23:42 --> Loader Class Initialized
INFO - 2017-02-09 19:23:42 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:42 --> Controller Class Initialized
INFO - 2017-02-09 19:23:42 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:42 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:42 --> Total execution time: 0.0140
INFO - 2017-02-09 19:23:43 --> Config Class Initialized
INFO - 2017-02-09 19:23:43 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:23:43 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:23:43 --> Utf8 Class Initialized
INFO - 2017-02-09 19:23:43 --> URI Class Initialized
INFO - 2017-02-09 19:23:43 --> Router Class Initialized
INFO - 2017-02-09 19:23:43 --> Output Class Initialized
INFO - 2017-02-09 19:23:43 --> Security Class Initialized
DEBUG - 2017-02-09 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:23:43 --> Input Class Initialized
INFO - 2017-02-09 19:23:43 --> Language Class Initialized
INFO - 2017-02-09 19:23:43 --> Loader Class Initialized
INFO - 2017-02-09 19:23:43 --> Database Driver Class Initialized
INFO - 2017-02-09 19:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:23:43 --> Controller Class Initialized
INFO - 2017-02-09 19:23:43 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:23:43 --> Final output sent to browser
DEBUG - 2017-02-09 19:23:43 --> Total execution time: 0.0140
INFO - 2017-02-09 19:28:24 --> Config Class Initialized
INFO - 2017-02-09 19:28:24 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:28:24 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:28:24 --> Utf8 Class Initialized
INFO - 2017-02-09 19:28:24 --> URI Class Initialized
INFO - 2017-02-09 19:28:24 --> Router Class Initialized
INFO - 2017-02-09 19:28:24 --> Output Class Initialized
INFO - 2017-02-09 19:28:24 --> Security Class Initialized
DEBUG - 2017-02-09 19:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:28:24 --> Input Class Initialized
INFO - 2017-02-09 19:28:24 --> Language Class Initialized
INFO - 2017-02-09 19:28:24 --> Loader Class Initialized
INFO - 2017-02-09 19:28:24 --> Database Driver Class Initialized
INFO - 2017-02-09 19:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:28:24 --> Controller Class Initialized
INFO - 2017-02-09 19:28:24 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:28:24 --> Helper loaded: form_helper
INFO - 2017-02-09 19:28:24 --> Form Validation Class Initialized
INFO - 2017-02-09 19:28:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-09 19:28:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-09 19:28:24 --> Config Class Initialized
INFO - 2017-02-09 19:28:24 --> Hooks Class Initialized
DEBUG - 2017-02-09 19:28:24 --> UTF-8 Support Enabled
INFO - 2017-02-09 19:28:24 --> Utf8 Class Initialized
INFO - 2017-02-09 19:28:24 --> URI Class Initialized
INFO - 2017-02-09 19:28:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
DEBUG - 2017-02-09 19:28:24 --> No URI present. Default controller set.
INFO - 2017-02-09 19:28:24 --> Router Class Initialized
INFO - 2017-02-09 19:28:24 --> Output Class Initialized
INFO - 2017-02-09 19:28:24 --> Security Class Initialized
DEBUG - 2017-02-09 19:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 19:28:24 --> Input Class Initialized
INFO - 2017-02-09 19:28:24 --> Language Class Initialized
INFO - 2017-02-09 19:28:24 --> Loader Class Initialized
INFO - 2017-02-09 19:28:24 --> Database Driver Class Initialized
INFO - 2017-02-09 19:28:24 --> Final output sent to browser
DEBUG - 2017-02-09 19:28:24 --> Total execution time: 0.1775
INFO - 2017-02-09 19:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 19:28:24 --> Controller Class Initialized
INFO - 2017-02-09 19:28:24 --> Helper loaded: url_helper
DEBUG - 2017-02-09 19:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 19:28:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 19:28:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 19:28:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 19:28:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 19:28:24 --> Final output sent to browser
DEBUG - 2017-02-09 19:28:24 --> Total execution time: 0.0286
INFO - 2017-02-09 20:41:52 --> Config Class Initialized
INFO - 2017-02-09 20:41:52 --> Hooks Class Initialized
DEBUG - 2017-02-09 20:41:52 --> UTF-8 Support Enabled
INFO - 2017-02-09 20:41:52 --> Utf8 Class Initialized
INFO - 2017-02-09 20:41:52 --> URI Class Initialized
DEBUG - 2017-02-09 20:41:52 --> No URI present. Default controller set.
INFO - 2017-02-09 20:41:52 --> Router Class Initialized
INFO - 2017-02-09 20:41:52 --> Output Class Initialized
INFO - 2017-02-09 20:41:52 --> Security Class Initialized
DEBUG - 2017-02-09 20:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 20:41:52 --> Input Class Initialized
INFO - 2017-02-09 20:41:52 --> Language Class Initialized
INFO - 2017-02-09 20:41:52 --> Loader Class Initialized
INFO - 2017-02-09 20:41:52 --> Database Driver Class Initialized
INFO - 2017-02-09 20:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 20:41:52 --> Controller Class Initialized
INFO - 2017-02-09 20:41:52 --> Helper loaded: url_helper
DEBUG - 2017-02-09 20:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 20:41:52 --> Final output sent to browser
DEBUG - 2017-02-09 20:41:52 --> Total execution time: 0.0154
INFO - 2017-02-09 20:42:36 --> Config Class Initialized
INFO - 2017-02-09 20:42:36 --> Hooks Class Initialized
DEBUG - 2017-02-09 20:42:36 --> UTF-8 Support Enabled
INFO - 2017-02-09 20:42:36 --> Utf8 Class Initialized
INFO - 2017-02-09 20:42:36 --> URI Class Initialized
INFO - 2017-02-09 20:42:36 --> Router Class Initialized
INFO - 2017-02-09 20:42:36 --> Output Class Initialized
INFO - 2017-02-09 20:42:36 --> Security Class Initialized
DEBUG - 2017-02-09 20:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 20:42:36 --> Input Class Initialized
INFO - 2017-02-09 20:42:36 --> Language Class Initialized
INFO - 2017-02-09 20:42:36 --> Loader Class Initialized
INFO - 2017-02-09 20:42:36 --> Database Driver Class Initialized
INFO - 2017-02-09 20:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 20:42:36 --> Controller Class Initialized
INFO - 2017-02-09 20:42:36 --> Helper loaded: url_helper
DEBUG - 2017-02-09 20:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 20:42:36 --> Final output sent to browser
DEBUG - 2017-02-09 20:42:36 --> Total execution time: 0.0132
INFO - 2017-02-09 20:43:03 --> Config Class Initialized
INFO - 2017-02-09 20:43:03 --> Hooks Class Initialized
DEBUG - 2017-02-09 20:43:03 --> UTF-8 Support Enabled
INFO - 2017-02-09 20:43:03 --> Utf8 Class Initialized
INFO - 2017-02-09 20:43:03 --> URI Class Initialized
INFO - 2017-02-09 20:43:03 --> Router Class Initialized
INFO - 2017-02-09 20:43:03 --> Output Class Initialized
INFO - 2017-02-09 20:43:03 --> Security Class Initialized
DEBUG - 2017-02-09 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 20:43:03 --> Input Class Initialized
INFO - 2017-02-09 20:43:03 --> Language Class Initialized
INFO - 2017-02-09 20:43:03 --> Loader Class Initialized
INFO - 2017-02-09 20:43:03 --> Database Driver Class Initialized
INFO - 2017-02-09 20:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 20:43:03 --> Controller Class Initialized
INFO - 2017-02-09 20:43:03 --> Helper loaded: url_helper
DEBUG - 2017-02-09 20:43:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 20:43:04 --> Config Class Initialized
INFO - 2017-02-09 20:43:04 --> Hooks Class Initialized
DEBUG - 2017-02-09 20:43:04 --> UTF-8 Support Enabled
INFO - 2017-02-09 20:43:04 --> Utf8 Class Initialized
INFO - 2017-02-09 20:43:04 --> URI Class Initialized
INFO - 2017-02-09 20:43:04 --> Router Class Initialized
INFO - 2017-02-09 20:43:04 --> Output Class Initialized
INFO - 2017-02-09 20:43:04 --> Security Class Initialized
DEBUG - 2017-02-09 20:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 20:43:04 --> Input Class Initialized
INFO - 2017-02-09 20:43:04 --> Language Class Initialized
INFO - 2017-02-09 20:43:04 --> Loader Class Initialized
INFO - 2017-02-09 20:43:04 --> Database Driver Class Initialized
INFO - 2017-02-09 20:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 20:43:04 --> Controller Class Initialized
INFO - 2017-02-09 20:43:04 --> Helper loaded: date_helper
DEBUG - 2017-02-09 20:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 20:43:04 --> Helper loaded: url_helper
INFO - 2017-02-09 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-09 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-09 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-09 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 20:43:04 --> Final output sent to browser
DEBUG - 2017-02-09 20:43:04 --> Total execution time: 0.0159
INFO - 2017-02-09 20:43:05 --> Config Class Initialized
INFO - 2017-02-09 20:43:05 --> Hooks Class Initialized
DEBUG - 2017-02-09 20:43:05 --> UTF-8 Support Enabled
INFO - 2017-02-09 20:43:05 --> Utf8 Class Initialized
INFO - 2017-02-09 20:43:05 --> URI Class Initialized
INFO - 2017-02-09 20:43:05 --> Router Class Initialized
INFO - 2017-02-09 20:43:05 --> Output Class Initialized
INFO - 2017-02-09 20:43:05 --> Security Class Initialized
DEBUG - 2017-02-09 20:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 20:43:05 --> Input Class Initialized
INFO - 2017-02-09 20:43:05 --> Language Class Initialized
INFO - 2017-02-09 20:43:05 --> Loader Class Initialized
INFO - 2017-02-09 20:43:05 --> Database Driver Class Initialized
INFO - 2017-02-09 20:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 20:43:05 --> Controller Class Initialized
INFO - 2017-02-09 20:43:05 --> Helper loaded: url_helper
DEBUG - 2017-02-09 20:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 20:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 20:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 20:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 20:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 20:43:05 --> Final output sent to browser
DEBUG - 2017-02-09 20:43:05 --> Total execution time: 0.0137
INFO - 2017-02-09 22:10:28 --> Config Class Initialized
INFO - 2017-02-09 22:10:28 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:10:28 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:10:28 --> Utf8 Class Initialized
INFO - 2017-02-09 22:10:28 --> URI Class Initialized
DEBUG - 2017-02-09 22:10:28 --> No URI present. Default controller set.
INFO - 2017-02-09 22:10:28 --> Router Class Initialized
INFO - 2017-02-09 22:10:28 --> Output Class Initialized
INFO - 2017-02-09 22:10:28 --> Security Class Initialized
DEBUG - 2017-02-09 22:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:10:28 --> Input Class Initialized
INFO - 2017-02-09 22:10:28 --> Language Class Initialized
INFO - 2017-02-09 22:10:28 --> Loader Class Initialized
INFO - 2017-02-09 22:10:28 --> Database Driver Class Initialized
INFO - 2017-02-09 22:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:10:28 --> Controller Class Initialized
INFO - 2017-02-09 22:10:28 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:10:28 --> Final output sent to browser
DEBUG - 2017-02-09 22:10:28 --> Total execution time: 0.6500
INFO - 2017-02-09 22:10:33 --> Config Class Initialized
INFO - 2017-02-09 22:10:33 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:10:33 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:10:33 --> Utf8 Class Initialized
INFO - 2017-02-09 22:10:33 --> URI Class Initialized
INFO - 2017-02-09 22:10:33 --> Router Class Initialized
INFO - 2017-02-09 22:10:33 --> Output Class Initialized
INFO - 2017-02-09 22:10:33 --> Security Class Initialized
DEBUG - 2017-02-09 22:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:10:33 --> Input Class Initialized
INFO - 2017-02-09 22:10:33 --> Language Class Initialized
INFO - 2017-02-09 22:10:33 --> Loader Class Initialized
INFO - 2017-02-09 22:10:33 --> Database Driver Class Initialized
INFO - 2017-02-09 22:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:10:33 --> Controller Class Initialized
INFO - 2017-02-09 22:10:33 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:10:33 --> Final output sent to browser
DEBUG - 2017-02-09 22:10:33 --> Total execution time: 0.0421
INFO - 2017-02-09 22:11:50 --> Config Class Initialized
INFO - 2017-02-09 22:11:50 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:11:50 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:11:50 --> Utf8 Class Initialized
INFO - 2017-02-09 22:11:50 --> URI Class Initialized
INFO - 2017-02-09 22:11:50 --> Router Class Initialized
INFO - 2017-02-09 22:11:50 --> Output Class Initialized
INFO - 2017-02-09 22:11:50 --> Security Class Initialized
DEBUG - 2017-02-09 22:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:11:50 --> Input Class Initialized
INFO - 2017-02-09 22:11:50 --> Language Class Initialized
INFO - 2017-02-09 22:11:50 --> Loader Class Initialized
INFO - 2017-02-09 22:11:50 --> Database Driver Class Initialized
INFO - 2017-02-09 22:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:11:50 --> Controller Class Initialized
INFO - 2017-02-09 22:11:50 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:11:50 --> Final output sent to browser
DEBUG - 2017-02-09 22:11:50 --> Total execution time: 0.0212
INFO - 2017-02-09 22:11:51 --> Config Class Initialized
INFO - 2017-02-09 22:11:51 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:11:51 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:11:51 --> Utf8 Class Initialized
INFO - 2017-02-09 22:11:51 --> URI Class Initialized
INFO - 2017-02-09 22:11:51 --> Router Class Initialized
INFO - 2017-02-09 22:11:51 --> Output Class Initialized
INFO - 2017-02-09 22:11:51 --> Security Class Initialized
DEBUG - 2017-02-09 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:11:51 --> Input Class Initialized
INFO - 2017-02-09 22:11:51 --> Language Class Initialized
INFO - 2017-02-09 22:11:51 --> Loader Class Initialized
INFO - 2017-02-09 22:11:51 --> Database Driver Class Initialized
INFO - 2017-02-09 22:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:11:51 --> Controller Class Initialized
INFO - 2017-02-09 22:11:51 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:11:51 --> Final output sent to browser
DEBUG - 2017-02-09 22:11:51 --> Total execution time: 0.0134
INFO - 2017-02-09 22:12:42 --> Config Class Initialized
INFO - 2017-02-09 22:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:12:42 --> Utf8 Class Initialized
INFO - 2017-02-09 22:12:42 --> URI Class Initialized
INFO - 2017-02-09 22:12:42 --> Router Class Initialized
INFO - 2017-02-09 22:12:42 --> Output Class Initialized
INFO - 2017-02-09 22:12:42 --> Security Class Initialized
DEBUG - 2017-02-09 22:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:12:42 --> Input Class Initialized
INFO - 2017-02-09 22:12:42 --> Language Class Initialized
INFO - 2017-02-09 22:12:42 --> Loader Class Initialized
INFO - 2017-02-09 22:12:42 --> Database Driver Class Initialized
INFO - 2017-02-09 22:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:12:42 --> Controller Class Initialized
INFO - 2017-02-09 22:12:42 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:12:42 --> Config Class Initialized
INFO - 2017-02-09 22:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:12:42 --> Utf8 Class Initialized
INFO - 2017-02-09 22:12:42 --> URI Class Initialized
INFO - 2017-02-09 22:12:42 --> Router Class Initialized
INFO - 2017-02-09 22:12:42 --> Output Class Initialized
INFO - 2017-02-09 22:12:42 --> Security Class Initialized
DEBUG - 2017-02-09 22:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:12:42 --> Input Class Initialized
INFO - 2017-02-09 22:12:42 --> Language Class Initialized
INFO - 2017-02-09 22:12:42 --> Loader Class Initialized
INFO - 2017-02-09 22:12:42 --> Database Driver Class Initialized
INFO - 2017-02-09 22:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:12:42 --> Controller Class Initialized
INFO - 2017-02-09 22:12:42 --> Helper loaded: date_helper
DEBUG - 2017-02-09 22:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:12:42 --> Helper loaded: url_helper
INFO - 2017-02-09 22:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-09 22:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-09 22:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-09 22:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:12:42 --> Final output sent to browser
DEBUG - 2017-02-09 22:12:42 --> Total execution time: 0.0142
INFO - 2017-02-09 22:12:43 --> Config Class Initialized
INFO - 2017-02-09 22:12:43 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:12:43 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:12:43 --> Utf8 Class Initialized
INFO - 2017-02-09 22:12:43 --> URI Class Initialized
INFO - 2017-02-09 22:12:43 --> Router Class Initialized
INFO - 2017-02-09 22:12:43 --> Output Class Initialized
INFO - 2017-02-09 22:12:43 --> Security Class Initialized
DEBUG - 2017-02-09 22:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:12:43 --> Input Class Initialized
INFO - 2017-02-09 22:12:43 --> Language Class Initialized
INFO - 2017-02-09 22:12:43 --> Loader Class Initialized
INFO - 2017-02-09 22:12:43 --> Database Driver Class Initialized
INFO - 2017-02-09 22:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:12:43 --> Controller Class Initialized
INFO - 2017-02-09 22:12:43 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:12:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:12:43 --> Final output sent to browser
DEBUG - 2017-02-09 22:12:43 --> Total execution time: 0.0139
INFO - 2017-02-09 22:12:48 --> Config Class Initialized
INFO - 2017-02-09 22:12:48 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:12:48 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:12:48 --> Utf8 Class Initialized
INFO - 2017-02-09 22:12:48 --> URI Class Initialized
DEBUG - 2017-02-09 22:12:48 --> No URI present. Default controller set.
INFO - 2017-02-09 22:12:48 --> Router Class Initialized
INFO - 2017-02-09 22:12:48 --> Output Class Initialized
INFO - 2017-02-09 22:12:48 --> Security Class Initialized
DEBUG - 2017-02-09 22:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:12:48 --> Input Class Initialized
INFO - 2017-02-09 22:12:48 --> Language Class Initialized
INFO - 2017-02-09 22:12:48 --> Loader Class Initialized
INFO - 2017-02-09 22:12:48 --> Database Driver Class Initialized
INFO - 2017-02-09 22:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:12:48 --> Controller Class Initialized
INFO - 2017-02-09 22:12:48 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:12:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:12:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:12:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:12:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:12:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:12:48 --> Final output sent to browser
DEBUG - 2017-02-09 22:12:48 --> Total execution time: 0.0143
INFO - 2017-02-09 22:12:49 --> Config Class Initialized
INFO - 2017-02-09 22:12:49 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:12:49 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:12:49 --> Utf8 Class Initialized
INFO - 2017-02-09 22:12:49 --> URI Class Initialized
INFO - 2017-02-09 22:12:49 --> Router Class Initialized
INFO - 2017-02-09 22:12:49 --> Output Class Initialized
INFO - 2017-02-09 22:12:49 --> Security Class Initialized
DEBUG - 2017-02-09 22:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:12:49 --> Input Class Initialized
INFO - 2017-02-09 22:12:49 --> Language Class Initialized
INFO - 2017-02-09 22:12:49 --> Loader Class Initialized
INFO - 2017-02-09 22:12:49 --> Database Driver Class Initialized
INFO - 2017-02-09 22:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:12:49 --> Controller Class Initialized
INFO - 2017-02-09 22:12:49 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:12:49 --> Final output sent to browser
DEBUG - 2017-02-09 22:12:49 --> Total execution time: 0.0135
INFO - 2017-02-09 22:12:57 --> Config Class Initialized
INFO - 2017-02-09 22:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:12:57 --> Utf8 Class Initialized
INFO - 2017-02-09 22:12:57 --> URI Class Initialized
DEBUG - 2017-02-09 22:12:57 --> No URI present. Default controller set.
INFO - 2017-02-09 22:12:57 --> Router Class Initialized
INFO - 2017-02-09 22:12:57 --> Output Class Initialized
INFO - 2017-02-09 22:12:57 --> Security Class Initialized
DEBUG - 2017-02-09 22:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:12:57 --> Input Class Initialized
INFO - 2017-02-09 22:12:57 --> Language Class Initialized
INFO - 2017-02-09 22:12:57 --> Loader Class Initialized
INFO - 2017-02-09 22:12:57 --> Database Driver Class Initialized
INFO - 2017-02-09 22:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:12:57 --> Controller Class Initialized
INFO - 2017-02-09 22:12:57 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:12:57 --> Final output sent to browser
DEBUG - 2017-02-09 22:12:57 --> Total execution time: 0.0138
INFO - 2017-02-09 22:12:58 --> Config Class Initialized
INFO - 2017-02-09 22:12:58 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:12:58 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:12:58 --> Utf8 Class Initialized
INFO - 2017-02-09 22:12:58 --> URI Class Initialized
INFO - 2017-02-09 22:12:58 --> Router Class Initialized
INFO - 2017-02-09 22:12:58 --> Output Class Initialized
INFO - 2017-02-09 22:12:58 --> Security Class Initialized
DEBUG - 2017-02-09 22:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:12:58 --> Input Class Initialized
INFO - 2017-02-09 22:12:58 --> Language Class Initialized
INFO - 2017-02-09 22:12:58 --> Loader Class Initialized
INFO - 2017-02-09 22:12:58 --> Database Driver Class Initialized
INFO - 2017-02-09 22:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:12:58 --> Controller Class Initialized
INFO - 2017-02-09 22:12:58 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:12:58 --> Final output sent to browser
DEBUG - 2017-02-09 22:12:58 --> Total execution time: 0.0148
INFO - 2017-02-09 22:13:06 --> Config Class Initialized
INFO - 2017-02-09 22:13:06 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:13:06 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:13:06 --> Utf8 Class Initialized
INFO - 2017-02-09 22:13:06 --> URI Class Initialized
INFO - 2017-02-09 22:13:06 --> Router Class Initialized
INFO - 2017-02-09 22:13:06 --> Output Class Initialized
INFO - 2017-02-09 22:13:06 --> Security Class Initialized
DEBUG - 2017-02-09 22:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:13:06 --> Input Class Initialized
INFO - 2017-02-09 22:13:06 --> Language Class Initialized
INFO - 2017-02-09 22:13:06 --> Loader Class Initialized
INFO - 2017-02-09 22:13:06 --> Database Driver Class Initialized
INFO - 2017-02-09 22:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:13:06 --> Controller Class Initialized
INFO - 2017-02-09 22:13:06 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:13:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:13:07 --> Config Class Initialized
INFO - 2017-02-09 22:13:07 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:13:07 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:13:07 --> Utf8 Class Initialized
INFO - 2017-02-09 22:13:07 --> URI Class Initialized
INFO - 2017-02-09 22:13:07 --> Router Class Initialized
INFO - 2017-02-09 22:13:07 --> Output Class Initialized
INFO - 2017-02-09 22:13:07 --> Security Class Initialized
DEBUG - 2017-02-09 22:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:13:07 --> Input Class Initialized
INFO - 2017-02-09 22:13:07 --> Language Class Initialized
INFO - 2017-02-09 22:13:07 --> Loader Class Initialized
INFO - 2017-02-09 22:13:07 --> Database Driver Class Initialized
INFO - 2017-02-09 22:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:13:07 --> Controller Class Initialized
INFO - 2017-02-09 22:13:07 --> Helper loaded: date_helper
DEBUG - 2017-02-09 22:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:13:07 --> Helper loaded: url_helper
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:13:07 --> Final output sent to browser
DEBUG - 2017-02-09 22:13:07 --> Total execution time: 0.0139
INFO - 2017-02-09 22:13:07 --> Config Class Initialized
INFO - 2017-02-09 22:13:07 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:13:07 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:13:07 --> Utf8 Class Initialized
INFO - 2017-02-09 22:13:07 --> URI Class Initialized
INFO - 2017-02-09 22:13:07 --> Router Class Initialized
INFO - 2017-02-09 22:13:07 --> Output Class Initialized
INFO - 2017-02-09 22:13:07 --> Security Class Initialized
DEBUG - 2017-02-09 22:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:13:07 --> Input Class Initialized
INFO - 2017-02-09 22:13:07 --> Language Class Initialized
INFO - 2017-02-09 22:13:07 --> Loader Class Initialized
INFO - 2017-02-09 22:13:07 --> Database Driver Class Initialized
INFO - 2017-02-09 22:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:13:07 --> Controller Class Initialized
INFO - 2017-02-09 22:13:07 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:13:07 --> Final output sent to browser
DEBUG - 2017-02-09 22:13:07 --> Total execution time: 0.0201
INFO - 2017-02-09 22:13:33 --> Config Class Initialized
INFO - 2017-02-09 22:13:33 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:13:33 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:13:33 --> Utf8 Class Initialized
INFO - 2017-02-09 22:13:33 --> URI Class Initialized
DEBUG - 2017-02-09 22:13:33 --> No URI present. Default controller set.
INFO - 2017-02-09 22:13:33 --> Router Class Initialized
INFO - 2017-02-09 22:13:33 --> Output Class Initialized
INFO - 2017-02-09 22:13:33 --> Security Class Initialized
DEBUG - 2017-02-09 22:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:13:33 --> Input Class Initialized
INFO - 2017-02-09 22:13:33 --> Language Class Initialized
INFO - 2017-02-09 22:13:33 --> Loader Class Initialized
INFO - 2017-02-09 22:13:33 --> Database Driver Class Initialized
INFO - 2017-02-09 22:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:13:33 --> Controller Class Initialized
INFO - 2017-02-09 22:13:33 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:13:33 --> Final output sent to browser
DEBUG - 2017-02-09 22:13:33 --> Total execution time: 0.0145
INFO - 2017-02-09 22:13:34 --> Config Class Initialized
INFO - 2017-02-09 22:13:34 --> Hooks Class Initialized
DEBUG - 2017-02-09 22:13:34 --> UTF-8 Support Enabled
INFO - 2017-02-09 22:13:34 --> Utf8 Class Initialized
INFO - 2017-02-09 22:13:34 --> URI Class Initialized
INFO - 2017-02-09 22:13:34 --> Router Class Initialized
INFO - 2017-02-09 22:13:34 --> Output Class Initialized
INFO - 2017-02-09 22:13:34 --> Security Class Initialized
DEBUG - 2017-02-09 22:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-09 22:13:34 --> Input Class Initialized
INFO - 2017-02-09 22:13:34 --> Language Class Initialized
INFO - 2017-02-09 22:13:34 --> Loader Class Initialized
INFO - 2017-02-09 22:13:34 --> Database Driver Class Initialized
INFO - 2017-02-09 22:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-09 22:13:34 --> Controller Class Initialized
INFO - 2017-02-09 22:13:34 --> Helper loaded: url_helper
DEBUG - 2017-02-09 22:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-09 22:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-09 22:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-09 22:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-09 22:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-09 22:13:34 --> Final output sent to browser
DEBUG - 2017-02-09 22:13:34 --> Total execution time: 0.0146

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-15 20:51:41 --> Config Class Initialized
INFO - 2017-01-15 20:51:41 --> Hooks Class Initialized
DEBUG - 2017-01-15 20:51:41 --> UTF-8 Support Enabled
INFO - 2017-01-15 20:51:41 --> Utf8 Class Initialized
INFO - 2017-01-15 20:51:41 --> URI Class Initialized
INFO - 2017-01-15 20:51:41 --> Router Class Initialized
INFO - 2017-01-15 20:51:41 --> Output Class Initialized
INFO - 2017-01-15 20:51:41 --> Security Class Initialized
DEBUG - 2017-01-15 20:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-15 20:51:41 --> Input Class Initialized
INFO - 2017-01-15 20:51:41 --> Language Class Initialized
INFO - 2017-01-15 20:51:41 --> Loader Class Initialized
INFO - 2017-01-15 20:51:41 --> Database Driver Class Initialized
INFO - 2017-01-15 20:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-15 20:51:41 --> Controller Class Initialized
INFO - 2017-01-15 20:51:41 --> Helper loaded: url_helper
DEBUG - 2017-01-15 20:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-15 20:51:41 --> Final output sent to browser
DEBUG - 2017-01-15 20:51:41 --> Total execution time: 0.0941
INFO - 2017-01-15 20:51:41 --> Config Class Initialized
INFO - 2017-01-15 20:51:41 --> Hooks Class Initialized
DEBUG - 2017-01-15 20:51:41 --> UTF-8 Support Enabled
INFO - 2017-01-15 20:51:41 --> Utf8 Class Initialized
INFO - 2017-01-15 20:51:41 --> URI Class Initialized
INFO - 2017-01-15 20:51:41 --> Router Class Initialized
INFO - 2017-01-15 20:51:41 --> Output Class Initialized
INFO - 2017-01-15 20:51:41 --> Security Class Initialized
DEBUG - 2017-01-15 20:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-15 20:51:41 --> Input Class Initialized
INFO - 2017-01-15 20:51:41 --> Language Class Initialized
INFO - 2017-01-15 20:51:41 --> Loader Class Initialized
INFO - 2017-01-15 20:51:41 --> Database Driver Class Initialized
INFO - 2017-01-15 20:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-15 20:51:41 --> Controller Class Initialized
INFO - 2017-01-15 20:51:41 --> Helper loaded: url_helper
DEBUG - 2017-01-15 20:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-15 20:51:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-15 20:51:41 --> Final output sent to browser
DEBUG - 2017-01-15 20:51:41 --> Total execution time: 0.0220
INFO - 2017-01-15 22:07:06 --> Config Class Initialized
INFO - 2017-01-15 22:07:06 --> Hooks Class Initialized
DEBUG - 2017-01-15 22:07:06 --> UTF-8 Support Enabled
INFO - 2017-01-15 22:07:06 --> Utf8 Class Initialized
INFO - 2017-01-15 22:07:06 --> URI Class Initialized
DEBUG - 2017-01-15 22:07:06 --> No URI present. Default controller set.
INFO - 2017-01-15 22:07:06 --> Router Class Initialized
INFO - 2017-01-15 22:07:06 --> Output Class Initialized
INFO - 2017-01-15 22:07:06 --> Security Class Initialized
DEBUG - 2017-01-15 22:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-15 22:07:06 --> Input Class Initialized
INFO - 2017-01-15 22:07:06 --> Language Class Initialized
INFO - 2017-01-15 22:07:06 --> Loader Class Initialized
INFO - 2017-01-15 22:07:06 --> Database Driver Class Initialized
INFO - 2017-01-15 22:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-15 22:07:06 --> Controller Class Initialized
INFO - 2017-01-15 22:07:06 --> Helper loaded: url_helper
DEBUG - 2017-01-15 22:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-15 22:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-15 22:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-15 22:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-15 22:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-15 22:07:06 --> Final output sent to browser
DEBUG - 2017-01-15 22:07:06 --> Total execution time: 0.0192
INFO - 2017-01-15 22:18:29 --> Config Class Initialized
INFO - 2017-01-15 22:18:29 --> Hooks Class Initialized
DEBUG - 2017-01-15 22:18:29 --> UTF-8 Support Enabled
INFO - 2017-01-15 22:18:29 --> Utf8 Class Initialized
INFO - 2017-01-15 22:18:29 --> URI Class Initialized
DEBUG - 2017-01-15 22:18:29 --> No URI present. Default controller set.
INFO - 2017-01-15 22:18:29 --> Router Class Initialized
INFO - 2017-01-15 22:18:29 --> Output Class Initialized
INFO - 2017-01-15 22:18:29 --> Security Class Initialized
DEBUG - 2017-01-15 22:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-15 22:18:29 --> Input Class Initialized
INFO - 2017-01-15 22:18:29 --> Language Class Initialized
INFO - 2017-01-15 22:18:29 --> Loader Class Initialized
INFO - 2017-01-15 22:18:29 --> Database Driver Class Initialized
INFO - 2017-01-15 22:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-15 22:18:29 --> Controller Class Initialized
INFO - 2017-01-15 22:18:29 --> Helper loaded: url_helper
DEBUG - 2017-01-15 22:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-15 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-15 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-15 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-15 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-15 22:18:29 --> Final output sent to browser
DEBUG - 2017-01-15 22:18:29 --> Total execution time: 0.0139
INFO - 2017-01-15 23:12:22 --> Config Class Initialized
INFO - 2017-01-15 23:12:22 --> Hooks Class Initialized
DEBUG - 2017-01-15 23:12:22 --> UTF-8 Support Enabled
INFO - 2017-01-15 23:12:22 --> Utf8 Class Initialized
INFO - 2017-01-15 23:12:22 --> URI Class Initialized
INFO - 2017-01-15 23:12:22 --> Router Class Initialized
INFO - 2017-01-15 23:12:22 --> Output Class Initialized
INFO - 2017-01-15 23:12:22 --> Security Class Initialized
DEBUG - 2017-01-15 23:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-15 23:12:22 --> Input Class Initialized
INFO - 2017-01-15 23:12:22 --> Language Class Initialized
INFO - 2017-01-15 23:12:22 --> Loader Class Initialized
INFO - 2017-01-15 23:12:22 --> Database Driver Class Initialized
INFO - 2017-01-15 23:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-15 23:12:22 --> Controller Class Initialized
INFO - 2017-01-15 23:12:22 --> Helper loaded: url_helper
DEBUG - 2017-01-15 23:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-15 23:12:22 --> Final output sent to browser
DEBUG - 2017-01-15 23:12:22 --> Total execution time: 0.0141
INFO - 2017-01-15 23:12:22 --> Config Class Initialized
INFO - 2017-01-15 23:12:22 --> Hooks Class Initialized
DEBUG - 2017-01-15 23:12:22 --> UTF-8 Support Enabled
INFO - 2017-01-15 23:12:22 --> Utf8 Class Initialized
INFO - 2017-01-15 23:12:22 --> URI Class Initialized
DEBUG - 2017-01-15 23:12:22 --> No URI present. Default controller set.
INFO - 2017-01-15 23:12:22 --> Router Class Initialized
INFO - 2017-01-15 23:12:22 --> Output Class Initialized
INFO - 2017-01-15 23:12:22 --> Security Class Initialized
DEBUG - 2017-01-15 23:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-15 23:12:22 --> Input Class Initialized
INFO - 2017-01-15 23:12:22 --> Language Class Initialized
INFO - 2017-01-15 23:12:22 --> Loader Class Initialized
INFO - 2017-01-15 23:12:22 --> Database Driver Class Initialized
INFO - 2017-01-15 23:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-15 23:12:22 --> Controller Class Initialized
INFO - 2017-01-15 23:12:22 --> Helper loaded: url_helper
DEBUG - 2017-01-15 23:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-15 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-15 23:12:22 --> Final output sent to browser
DEBUG - 2017-01-15 23:12:22 --> Total execution time: 0.0141

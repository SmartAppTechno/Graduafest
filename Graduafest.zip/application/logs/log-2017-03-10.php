<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-10 01:16:19 --> Config Class Initialized
INFO - 2017-03-10 01:16:20 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:16:20 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:16:20 --> Utf8 Class Initialized
INFO - 2017-03-10 01:16:20 --> URI Class Initialized
DEBUG - 2017-03-10 01:16:20 --> No URI present. Default controller set.
INFO - 2017-03-10 01:16:20 --> Router Class Initialized
INFO - 2017-03-10 01:16:20 --> Output Class Initialized
INFO - 2017-03-10 01:16:20 --> Security Class Initialized
DEBUG - 2017-03-10 01:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:16:20 --> Input Class Initialized
INFO - 2017-03-10 01:16:20 --> Language Class Initialized
INFO - 2017-03-10 01:16:20 --> Loader Class Initialized
INFO - 2017-03-10 01:16:20 --> Database Driver Class Initialized
INFO - 2017-03-10 01:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:16:21 --> Controller Class Initialized
INFO - 2017-03-10 01:16:21 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:16:21 --> Final output sent to browser
DEBUG - 2017-03-10 01:16:21 --> Total execution time: 2.0492
INFO - 2017-03-10 01:16:24 --> Config Class Initialized
INFO - 2017-03-10 01:16:24 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:16:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:16:24 --> Utf8 Class Initialized
INFO - 2017-03-10 01:16:24 --> URI Class Initialized
INFO - 2017-03-10 01:16:25 --> Router Class Initialized
INFO - 2017-03-10 01:16:25 --> Output Class Initialized
INFO - 2017-03-10 01:16:25 --> Security Class Initialized
DEBUG - 2017-03-10 01:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:16:25 --> Input Class Initialized
INFO - 2017-03-10 01:16:25 --> Language Class Initialized
INFO - 2017-03-10 01:16:25 --> Loader Class Initialized
INFO - 2017-03-10 01:16:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:16:25 --> Controller Class Initialized
INFO - 2017-03-10 01:16:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:16:26 --> Final output sent to browser
DEBUG - 2017-03-10 01:16:26 --> Total execution time: 1.3539
INFO - 2017-03-10 01:16:34 --> Config Class Initialized
INFO - 2017-03-10 01:16:34 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:16:34 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:16:34 --> Utf8 Class Initialized
INFO - 2017-03-10 01:16:34 --> URI Class Initialized
INFO - 2017-03-10 01:16:34 --> Router Class Initialized
INFO - 2017-03-10 01:16:35 --> Output Class Initialized
INFO - 2017-03-10 01:16:35 --> Security Class Initialized
DEBUG - 2017-03-10 01:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:16:35 --> Input Class Initialized
INFO - 2017-03-10 01:16:35 --> Language Class Initialized
INFO - 2017-03-10 01:16:35 --> Loader Class Initialized
INFO - 2017-03-10 01:16:35 --> Database Driver Class Initialized
INFO - 2017-03-10 01:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:16:35 --> Controller Class Initialized
INFO - 2017-03-10 01:16:35 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:16:38 --> Config Class Initialized
INFO - 2017-03-10 01:16:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:16:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:16:38 --> Utf8 Class Initialized
INFO - 2017-03-10 01:16:38 --> URI Class Initialized
INFO - 2017-03-10 01:16:38 --> Router Class Initialized
INFO - 2017-03-10 01:16:38 --> Output Class Initialized
INFO - 2017-03-10 01:16:38 --> Security Class Initialized
DEBUG - 2017-03-10 01:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:16:38 --> Input Class Initialized
INFO - 2017-03-10 01:16:38 --> Language Class Initialized
INFO - 2017-03-10 01:16:38 --> Loader Class Initialized
INFO - 2017-03-10 01:16:38 --> Database Driver Class Initialized
INFO - 2017-03-10 01:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:16:38 --> Controller Class Initialized
INFO - 2017-03-10 01:16:38 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:16:38 --> Helper loaded: url_helper
INFO - 2017-03-10 01:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:16:38 --> Final output sent to browser
DEBUG - 2017-03-10 01:16:38 --> Total execution time: 0.1454
INFO - 2017-03-10 01:16:44 --> Config Class Initialized
INFO - 2017-03-10 01:16:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:16:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:16:44 --> Utf8 Class Initialized
INFO - 2017-03-10 01:16:44 --> URI Class Initialized
INFO - 2017-03-10 01:16:45 --> Router Class Initialized
INFO - 2017-03-10 01:16:45 --> Output Class Initialized
INFO - 2017-03-10 01:16:45 --> Security Class Initialized
DEBUG - 2017-03-10 01:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:16:45 --> Input Class Initialized
INFO - 2017-03-10 01:16:45 --> Language Class Initialized
INFO - 2017-03-10 01:16:45 --> Loader Class Initialized
INFO - 2017-03-10 01:16:45 --> Database Driver Class Initialized
INFO - 2017-03-10 01:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:16:45 --> Controller Class Initialized
INFO - 2017-03-10 01:16:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:16:46 --> Final output sent to browser
DEBUG - 2017-03-10 01:16:46 --> Total execution time: 1.2669
INFO - 2017-03-10 01:17:20 --> Config Class Initialized
INFO - 2017-03-10 01:17:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:21 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:21 --> URI Class Initialized
INFO - 2017-03-10 01:17:21 --> Router Class Initialized
INFO - 2017-03-10 01:17:21 --> Output Class Initialized
INFO - 2017-03-10 01:17:21 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:21 --> Input Class Initialized
INFO - 2017-03-10 01:17:21 --> Language Class Initialized
INFO - 2017-03-10 01:17:21 --> Loader Class Initialized
INFO - 2017-03-10 01:17:21 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:21 --> Controller Class Initialized
INFO - 2017-03-10 01:17:21 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:21 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:22 --> Helper loaded: download_helper
INFO - 2017-03-10 01:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:22 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:22 --> Total execution time: 1.2118
INFO - 2017-03-10 01:17:24 --> Config Class Initialized
INFO - 2017-03-10 01:17:24 --> Config Class Initialized
INFO - 2017-03-10 01:17:24 --> Hooks Class Initialized
INFO - 2017-03-10 01:17:24 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:24 --> Utf8 Class Initialized
DEBUG - 2017-03-10 01:17:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:24 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:24 --> URI Class Initialized
INFO - 2017-03-10 01:17:24 --> URI Class Initialized
INFO - 2017-03-10 01:17:24 --> Router Class Initialized
INFO - 2017-03-10 01:17:24 --> Router Class Initialized
INFO - 2017-03-10 01:17:24 --> Output Class Initialized
INFO - 2017-03-10 01:17:24 --> Output Class Initialized
INFO - 2017-03-10 01:17:24 --> Security Class Initialized
INFO - 2017-03-10 01:17:24 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:24 --> Input Class Initialized
INFO - 2017-03-10 01:17:24 --> Language Class Initialized
DEBUG - 2017-03-10 01:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:24 --> Input Class Initialized
INFO - 2017-03-10 01:17:24 --> Language Class Initialized
INFO - 2017-03-10 01:17:24 --> Loader Class Initialized
INFO - 2017-03-10 01:17:24 --> Loader Class Initialized
INFO - 2017-03-10 01:17:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:25 --> Controller Class Initialized
INFO - 2017-03-10 01:17:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:25 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:25 --> Total execution time: 1.2739
INFO - 2017-03-10 01:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:25 --> Controller Class Initialized
INFO - 2017-03-10 01:17:25 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:25 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-10 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:25 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:25 --> Total execution time: 1.4155
INFO - 2017-03-10 01:17:26 --> Config Class Initialized
INFO - 2017-03-10 01:17:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:26 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:26 --> URI Class Initialized
INFO - 2017-03-10 01:17:26 --> Router Class Initialized
INFO - 2017-03-10 01:17:26 --> Output Class Initialized
INFO - 2017-03-10 01:17:26 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:26 --> Input Class Initialized
INFO - 2017-03-10 01:17:26 --> Language Class Initialized
INFO - 2017-03-10 01:17:26 --> Loader Class Initialized
INFO - 2017-03-10 01:17:26 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:26 --> Controller Class Initialized
INFO - 2017-03-10 01:17:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:26 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:26 --> Total execution time: 0.0291
INFO - 2017-03-10 01:17:30 --> Config Class Initialized
INFO - 2017-03-10 01:17:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:30 --> URI Class Initialized
INFO - 2017-03-10 01:17:30 --> Router Class Initialized
INFO - 2017-03-10 01:17:30 --> Output Class Initialized
INFO - 2017-03-10 01:17:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:30 --> Input Class Initialized
INFO - 2017-03-10 01:17:30 --> Language Class Initialized
INFO - 2017-03-10 01:17:30 --> Loader Class Initialized
INFO - 2017-03-10 01:17:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:31 --> Controller Class Initialized
INFO - 2017-03-10 01:17:31 --> Upload Class Initialized
INFO - 2017-03-10 01:17:31 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:31 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-10 01:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-10 01:17:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:31 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:31 --> Total execution time: 1.2487
INFO - 2017-03-10 01:17:32 --> Config Class Initialized
INFO - 2017-03-10 01:17:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:32 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:32 --> URI Class Initialized
INFO - 2017-03-10 01:17:32 --> Router Class Initialized
INFO - 2017-03-10 01:17:32 --> Output Class Initialized
INFO - 2017-03-10 01:17:32 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:32 --> Input Class Initialized
INFO - 2017-03-10 01:17:32 --> Language Class Initialized
INFO - 2017-03-10 01:17:32 --> Loader Class Initialized
INFO - 2017-03-10 01:17:33 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:33 --> Controller Class Initialized
INFO - 2017-03-10 01:17:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:33 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:33 --> Total execution time: 1.2569
INFO - 2017-03-10 01:17:36 --> Config Class Initialized
INFO - 2017-03-10 01:17:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:36 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:36 --> URI Class Initialized
INFO - 2017-03-10 01:17:36 --> Router Class Initialized
INFO - 2017-03-10 01:17:36 --> Output Class Initialized
INFO - 2017-03-10 01:17:36 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:36 --> Input Class Initialized
INFO - 2017-03-10 01:17:36 --> Language Class Initialized
INFO - 2017-03-10 01:17:36 --> Loader Class Initialized
INFO - 2017-03-10 01:17:36 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:36 --> Controller Class Initialized
INFO - 2017-03-10 01:17:36 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:36 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:37 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:37 --> Total execution time: 1.1021
INFO - 2017-03-10 01:17:37 --> Config Class Initialized
INFO - 2017-03-10 01:17:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:37 --> URI Class Initialized
INFO - 2017-03-10 01:17:37 --> Router Class Initialized
INFO - 2017-03-10 01:17:37 --> Output Class Initialized
INFO - 2017-03-10 01:17:37 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:37 --> Input Class Initialized
INFO - 2017-03-10 01:17:37 --> Language Class Initialized
INFO - 2017-03-10 01:17:37 --> Loader Class Initialized
INFO - 2017-03-10 01:17:37 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:37 --> Controller Class Initialized
INFO - 2017-03-10 01:17:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:37 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:37 --> Total execution time: 0.2493
INFO - 2017-03-10 01:17:38 --> Config Class Initialized
INFO - 2017-03-10 01:17:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:38 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:38 --> URI Class Initialized
INFO - 2017-03-10 01:17:38 --> Router Class Initialized
INFO - 2017-03-10 01:17:38 --> Output Class Initialized
INFO - 2017-03-10 01:17:38 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:38 --> Input Class Initialized
INFO - 2017-03-10 01:17:38 --> Language Class Initialized
INFO - 2017-03-10 01:17:38 --> Loader Class Initialized
INFO - 2017-03-10 01:17:38 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:38 --> Controller Class Initialized
INFO - 2017-03-10 01:17:38 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:38 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:38 --> Helper loaded: download_helper
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:38 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:38 --> Total execution time: 0.0999
INFO - 2017-03-10 01:17:38 --> Config Class Initialized
INFO - 2017-03-10 01:17:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:38 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:38 --> URI Class Initialized
INFO - 2017-03-10 01:17:38 --> Router Class Initialized
INFO - 2017-03-10 01:17:38 --> Output Class Initialized
INFO - 2017-03-10 01:17:38 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:38 --> Input Class Initialized
INFO - 2017-03-10 01:17:38 --> Language Class Initialized
INFO - 2017-03-10 01:17:38 --> Loader Class Initialized
INFO - 2017-03-10 01:17:38 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:38 --> Controller Class Initialized
INFO - 2017-03-10 01:17:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:38 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:38 --> Total execution time: 0.0143
INFO - 2017-03-10 01:17:43 --> Config Class Initialized
INFO - 2017-03-10 01:17:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:43 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:43 --> URI Class Initialized
INFO - 2017-03-10 01:17:43 --> Router Class Initialized
INFO - 2017-03-10 01:17:43 --> Output Class Initialized
INFO - 2017-03-10 01:17:43 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:43 --> Input Class Initialized
INFO - 2017-03-10 01:17:43 --> Language Class Initialized
INFO - 2017-03-10 01:17:43 --> Loader Class Initialized
INFO - 2017-03-10 01:17:43 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:43 --> Controller Class Initialized
INFO - 2017-03-10 01:17:43 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:43 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:43 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:43 --> Total execution time: 0.0710
INFO - 2017-03-10 01:17:43 --> Config Class Initialized
INFO - 2017-03-10 01:17:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:43 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:43 --> URI Class Initialized
INFO - 2017-03-10 01:17:43 --> Router Class Initialized
INFO - 2017-03-10 01:17:43 --> Output Class Initialized
INFO - 2017-03-10 01:17:43 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:43 --> Input Class Initialized
INFO - 2017-03-10 01:17:43 --> Language Class Initialized
INFO - 2017-03-10 01:17:43 --> Loader Class Initialized
INFO - 2017-03-10 01:17:43 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:43 --> Controller Class Initialized
INFO - 2017-03-10 01:17:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:43 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:43 --> Total execution time: 0.0141
INFO - 2017-03-10 01:17:45 --> Config Class Initialized
INFO - 2017-03-10 01:17:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:45 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:45 --> URI Class Initialized
INFO - 2017-03-10 01:17:45 --> Router Class Initialized
INFO - 2017-03-10 01:17:45 --> Output Class Initialized
INFO - 2017-03-10 01:17:45 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:45 --> Input Class Initialized
INFO - 2017-03-10 01:17:45 --> Language Class Initialized
INFO - 2017-03-10 01:17:45 --> Loader Class Initialized
INFO - 2017-03-10 01:17:45 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:45 --> Controller Class Initialized
INFO - 2017-03-10 01:17:45 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:45 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:45 --> Helper loaded: download_helper
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:45 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:45 --> Total execution time: 0.0203
INFO - 2017-03-10 01:17:45 --> Config Class Initialized
INFO - 2017-03-10 01:17:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:45 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:45 --> URI Class Initialized
INFO - 2017-03-10 01:17:45 --> Router Class Initialized
INFO - 2017-03-10 01:17:45 --> Output Class Initialized
INFO - 2017-03-10 01:17:45 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:45 --> Input Class Initialized
INFO - 2017-03-10 01:17:45 --> Language Class Initialized
INFO - 2017-03-10 01:17:45 --> Loader Class Initialized
INFO - 2017-03-10 01:17:45 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:45 --> Controller Class Initialized
INFO - 2017-03-10 01:17:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:45 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:45 --> Total execution time: 0.0143
INFO - 2017-03-10 01:17:46 --> Config Class Initialized
INFO - 2017-03-10 01:17:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:46 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:46 --> URI Class Initialized
INFO - 2017-03-10 01:17:46 --> Router Class Initialized
INFO - 2017-03-10 01:17:46 --> Output Class Initialized
INFO - 2017-03-10 01:17:46 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:46 --> Input Class Initialized
INFO - 2017-03-10 01:17:46 --> Language Class Initialized
INFO - 2017-03-10 01:17:46 --> Loader Class Initialized
INFO - 2017-03-10 01:17:46 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:46 --> Controller Class Initialized
INFO - 2017-03-10 01:17:46 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:46 --> Helper loaded: url_helper
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:46 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:46 --> Total execution time: 0.0315
INFO - 2017-03-10 01:17:46 --> Config Class Initialized
INFO - 2017-03-10 01:17:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:17:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:17:46 --> Utf8 Class Initialized
INFO - 2017-03-10 01:17:46 --> URI Class Initialized
INFO - 2017-03-10 01:17:46 --> Router Class Initialized
INFO - 2017-03-10 01:17:46 --> Output Class Initialized
INFO - 2017-03-10 01:17:46 --> Security Class Initialized
DEBUG - 2017-03-10 01:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:17:46 --> Input Class Initialized
INFO - 2017-03-10 01:17:46 --> Language Class Initialized
INFO - 2017-03-10 01:17:46 --> Loader Class Initialized
INFO - 2017-03-10 01:17:46 --> Database Driver Class Initialized
INFO - 2017-03-10 01:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:17:46 --> Controller Class Initialized
INFO - 2017-03-10 01:17:46 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:17:46 --> Final output sent to browser
DEBUG - 2017-03-10 01:17:46 --> Total execution time: 0.0223
INFO - 2017-03-10 01:19:15 --> Config Class Initialized
INFO - 2017-03-10 01:19:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:19:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:19:15 --> Utf8 Class Initialized
INFO - 2017-03-10 01:19:15 --> URI Class Initialized
INFO - 2017-03-10 01:19:16 --> Router Class Initialized
INFO - 2017-03-10 01:19:16 --> Output Class Initialized
INFO - 2017-03-10 01:19:16 --> Security Class Initialized
DEBUG - 2017-03-10 01:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:19:16 --> Input Class Initialized
INFO - 2017-03-10 01:19:16 --> Language Class Initialized
INFO - 2017-03-10 01:19:16 --> Loader Class Initialized
INFO - 2017-03-10 01:19:16 --> Database Driver Class Initialized
INFO - 2017-03-10 01:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:19:16 --> Controller Class Initialized
INFO - 2017-03-10 01:19:16 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:19:16 --> Helper loaded: url_helper
INFO - 2017-03-10 01:19:16 --> Final output sent to browser
DEBUG - 2017-03-10 01:19:16 --> Total execution time: 1.0136
INFO - 2017-03-10 01:19:22 --> Config Class Initialized
INFO - 2017-03-10 01:19:22 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:19:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:19:22 --> Utf8 Class Initialized
INFO - 2017-03-10 01:19:22 --> URI Class Initialized
INFO - 2017-03-10 01:19:22 --> Router Class Initialized
INFO - 2017-03-10 01:19:22 --> Output Class Initialized
INFO - 2017-03-10 01:19:22 --> Security Class Initialized
DEBUG - 2017-03-10 01:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:19:22 --> Input Class Initialized
INFO - 2017-03-10 01:19:22 --> Language Class Initialized
INFO - 2017-03-10 01:19:22 --> Loader Class Initialized
INFO - 2017-03-10 01:19:22 --> Database Driver Class Initialized
INFO - 2017-03-10 01:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:19:23 --> Controller Class Initialized
INFO - 2017-03-10 01:19:23 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:19:23 --> Helper loaded: url_helper
INFO - 2017-03-10 01:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-10 01:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-10 01:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-10 01:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:19:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:19:23 --> Total execution time: 1.1127
INFO - 2017-03-10 01:19:23 --> Config Class Initialized
INFO - 2017-03-10 01:19:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:19:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:19:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:19:23 --> URI Class Initialized
INFO - 2017-03-10 01:19:23 --> Router Class Initialized
INFO - 2017-03-10 01:19:23 --> Output Class Initialized
INFO - 2017-03-10 01:19:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:19:23 --> Input Class Initialized
INFO - 2017-03-10 01:19:23 --> Language Class Initialized
INFO - 2017-03-10 01:19:23 --> Loader Class Initialized
INFO - 2017-03-10 01:19:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:19:23 --> Controller Class Initialized
INFO - 2017-03-10 01:19:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:19:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:19:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:19:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:19:24 --> Final output sent to browser
DEBUG - 2017-03-10 01:19:24 --> Total execution time: 0.5736
INFO - 2017-03-10 01:19:29 --> Config Class Initialized
INFO - 2017-03-10 01:19:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:19:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:19:29 --> Utf8 Class Initialized
INFO - 2017-03-10 01:19:29 --> URI Class Initialized
INFO - 2017-03-10 01:19:29 --> Router Class Initialized
INFO - 2017-03-10 01:19:29 --> Output Class Initialized
INFO - 2017-03-10 01:19:29 --> Security Class Initialized
DEBUG - 2017-03-10 01:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:19:29 --> Input Class Initialized
INFO - 2017-03-10 01:19:29 --> Language Class Initialized
INFO - 2017-03-10 01:19:29 --> Loader Class Initialized
INFO - 2017-03-10 01:19:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:19:30 --> Controller Class Initialized
INFO - 2017-03-10 01:19:30 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:19:30 --> Helper loaded: url_helper
INFO - 2017-03-10 01:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:19:30 --> Final output sent to browser
DEBUG - 2017-03-10 01:19:30 --> Total execution time: 1.0935
INFO - 2017-03-10 01:19:31 --> Config Class Initialized
INFO - 2017-03-10 01:19:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:19:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:19:31 --> Utf8 Class Initialized
INFO - 2017-03-10 01:19:31 --> URI Class Initialized
INFO - 2017-03-10 01:19:31 --> Router Class Initialized
INFO - 2017-03-10 01:19:31 --> Output Class Initialized
INFO - 2017-03-10 01:19:31 --> Security Class Initialized
DEBUG - 2017-03-10 01:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:19:32 --> Input Class Initialized
INFO - 2017-03-10 01:19:32 --> Language Class Initialized
INFO - 2017-03-10 01:19:32 --> Loader Class Initialized
INFO - 2017-03-10 01:19:32 --> Database Driver Class Initialized
INFO - 2017-03-10 01:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:19:32 --> Controller Class Initialized
INFO - 2017-03-10 01:19:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:19:32 --> Final output sent to browser
DEBUG - 2017-03-10 01:19:32 --> Total execution time: 1.2309
INFO - 2017-03-10 01:30:13 --> Config Class Initialized
INFO - 2017-03-10 01:30:13 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:30:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:30:13 --> Utf8 Class Initialized
INFO - 2017-03-10 01:30:13 --> URI Class Initialized
INFO - 2017-03-10 01:30:14 --> Router Class Initialized
INFO - 2017-03-10 01:30:14 --> Output Class Initialized
INFO - 2017-03-10 01:30:14 --> Security Class Initialized
DEBUG - 2017-03-10 01:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:30:14 --> Input Class Initialized
INFO - 2017-03-10 01:30:14 --> Language Class Initialized
INFO - 2017-03-10 01:30:14 --> Loader Class Initialized
INFO - 2017-03-10 01:30:14 --> Database Driver Class Initialized
INFO - 2017-03-10 01:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:30:14 --> Controller Class Initialized
INFO - 2017-03-10 01:30:14 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:30:14 --> Helper loaded: url_helper
INFO - 2017-03-10 01:30:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:30:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:30:15 --> Final output sent to browser
DEBUG - 2017-03-10 01:30:15 --> Total execution time: 1.3677
INFO - 2017-03-10 01:30:15 --> Config Class Initialized
INFO - 2017-03-10 01:30:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:30:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:30:15 --> Utf8 Class Initialized
INFO - 2017-03-10 01:30:15 --> URI Class Initialized
INFO - 2017-03-10 01:30:15 --> Router Class Initialized
INFO - 2017-03-10 01:30:15 --> Output Class Initialized
INFO - 2017-03-10 01:30:15 --> Security Class Initialized
DEBUG - 2017-03-10 01:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:30:16 --> Input Class Initialized
INFO - 2017-03-10 01:30:16 --> Language Class Initialized
INFO - 2017-03-10 01:30:16 --> Loader Class Initialized
INFO - 2017-03-10 01:30:16 --> Database Driver Class Initialized
INFO - 2017-03-10 01:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:30:16 --> Controller Class Initialized
INFO - 2017-03-10 01:30:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:30:16 --> Final output sent to browser
DEBUG - 2017-03-10 01:30:16 --> Total execution time: 1.2210
INFO - 2017-03-10 01:30:33 --> Config Class Initialized
INFO - 2017-03-10 01:30:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:30:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:30:33 --> Utf8 Class Initialized
INFO - 2017-03-10 01:30:33 --> URI Class Initialized
INFO - 2017-03-10 01:30:33 --> Router Class Initialized
INFO - 2017-03-10 01:30:33 --> Output Class Initialized
INFO - 2017-03-10 01:30:33 --> Security Class Initialized
DEBUG - 2017-03-10 01:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:30:33 --> Input Class Initialized
INFO - 2017-03-10 01:30:33 --> Language Class Initialized
INFO - 2017-03-10 01:30:33 --> Loader Class Initialized
INFO - 2017-03-10 01:30:34 --> Database Driver Class Initialized
INFO - 2017-03-10 01:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:30:34 --> Controller Class Initialized
INFO - 2017-03-10 01:30:34 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:30:34 --> Helper loaded: url_helper
INFO - 2017-03-10 01:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:30:34 --> Final output sent to browser
DEBUG - 2017-03-10 01:30:34 --> Total execution time: 1.0865
INFO - 2017-03-10 01:30:35 --> Config Class Initialized
INFO - 2017-03-10 01:30:35 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:30:35 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:30:35 --> Utf8 Class Initialized
INFO - 2017-03-10 01:30:35 --> URI Class Initialized
INFO - 2017-03-10 01:30:35 --> Router Class Initialized
INFO - 2017-03-10 01:30:35 --> Output Class Initialized
INFO - 2017-03-10 01:30:35 --> Security Class Initialized
DEBUG - 2017-03-10 01:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:30:35 --> Input Class Initialized
INFO - 2017-03-10 01:30:35 --> Language Class Initialized
INFO - 2017-03-10 01:30:35 --> Loader Class Initialized
INFO - 2017-03-10 01:30:35 --> Database Driver Class Initialized
INFO - 2017-03-10 01:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:30:35 --> Controller Class Initialized
INFO - 2017-03-10 01:30:35 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:30:35 --> Final output sent to browser
DEBUG - 2017-03-10 01:30:35 --> Total execution time: 0.3695
INFO - 2017-03-10 01:30:37 --> Config Class Initialized
INFO - 2017-03-10 01:30:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:30:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:30:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:30:37 --> URI Class Initialized
INFO - 2017-03-10 01:30:37 --> Router Class Initialized
INFO - 2017-03-10 01:30:37 --> Output Class Initialized
INFO - 2017-03-10 01:30:37 --> Security Class Initialized
DEBUG - 2017-03-10 01:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:30:37 --> Input Class Initialized
INFO - 2017-03-10 01:30:37 --> Language Class Initialized
INFO - 2017-03-10 01:30:37 --> Loader Class Initialized
INFO - 2017-03-10 01:30:37 --> Database Driver Class Initialized
INFO - 2017-03-10 01:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:30:37 --> Controller Class Initialized
INFO - 2017-03-10 01:30:37 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:30:37 --> Helper loaded: url_helper
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:30:37 --> Final output sent to browser
DEBUG - 2017-03-10 01:30:37 --> Total execution time: 0.0163
INFO - 2017-03-10 01:30:37 --> Config Class Initialized
INFO - 2017-03-10 01:30:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:30:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:30:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:30:37 --> URI Class Initialized
INFO - 2017-03-10 01:30:37 --> Router Class Initialized
INFO - 2017-03-10 01:30:37 --> Output Class Initialized
INFO - 2017-03-10 01:30:37 --> Security Class Initialized
DEBUG - 2017-03-10 01:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:30:37 --> Input Class Initialized
INFO - 2017-03-10 01:30:37 --> Language Class Initialized
INFO - 2017-03-10 01:30:37 --> Loader Class Initialized
INFO - 2017-03-10 01:30:37 --> Database Driver Class Initialized
INFO - 2017-03-10 01:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:30:37 --> Controller Class Initialized
INFO - 2017-03-10 01:30:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:30:37 --> Final output sent to browser
DEBUG - 2017-03-10 01:30:37 --> Total execution time: 0.0153
INFO - 2017-03-10 01:31:39 --> Config Class Initialized
INFO - 2017-03-10 01:31:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:31:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:31:39 --> Utf8 Class Initialized
INFO - 2017-03-10 01:31:39 --> URI Class Initialized
INFO - 2017-03-10 01:31:39 --> Router Class Initialized
INFO - 2017-03-10 01:31:39 --> Output Class Initialized
INFO - 2017-03-10 01:31:39 --> Security Class Initialized
DEBUG - 2017-03-10 01:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:31:39 --> Input Class Initialized
INFO - 2017-03-10 01:31:39 --> Language Class Initialized
INFO - 2017-03-10 01:31:39 --> Loader Class Initialized
INFO - 2017-03-10 01:31:39 --> Database Driver Class Initialized
INFO - 2017-03-10 01:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:31:39 --> Controller Class Initialized
INFO - 2017-03-10 01:31:39 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:31:39 --> Helper loaded: url_helper
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:31:39 --> Final output sent to browser
DEBUG - 2017-03-10 01:31:39 --> Total execution time: 0.0149
INFO - 2017-03-10 01:31:39 --> Config Class Initialized
INFO - 2017-03-10 01:31:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:31:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:31:39 --> Utf8 Class Initialized
INFO - 2017-03-10 01:31:39 --> URI Class Initialized
INFO - 2017-03-10 01:31:39 --> Router Class Initialized
INFO - 2017-03-10 01:31:39 --> Output Class Initialized
INFO - 2017-03-10 01:31:39 --> Security Class Initialized
DEBUG - 2017-03-10 01:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:31:39 --> Input Class Initialized
INFO - 2017-03-10 01:31:39 --> Language Class Initialized
INFO - 2017-03-10 01:31:39 --> Loader Class Initialized
INFO - 2017-03-10 01:31:39 --> Database Driver Class Initialized
INFO - 2017-03-10 01:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:31:39 --> Controller Class Initialized
INFO - 2017-03-10 01:31:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:31:39 --> Final output sent to browser
DEBUG - 2017-03-10 01:31:39 --> Total execution time: 0.0136
INFO - 2017-03-10 01:32:01 --> Config Class Initialized
INFO - 2017-03-10 01:32:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:32:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:32:01 --> Utf8 Class Initialized
INFO - 2017-03-10 01:32:01 --> URI Class Initialized
INFO - 2017-03-10 01:32:01 --> Router Class Initialized
INFO - 2017-03-10 01:32:01 --> Output Class Initialized
INFO - 2017-03-10 01:32:01 --> Security Class Initialized
DEBUG - 2017-03-10 01:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:32:01 --> Input Class Initialized
INFO - 2017-03-10 01:32:01 --> Language Class Initialized
INFO - 2017-03-10 01:32:01 --> Loader Class Initialized
INFO - 2017-03-10 01:32:01 --> Database Driver Class Initialized
INFO - 2017-03-10 01:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:32:01 --> Controller Class Initialized
INFO - 2017-03-10 01:32:01 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:32:01 --> Helper loaded: url_helper
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:32:01 --> Final output sent to browser
DEBUG - 2017-03-10 01:32:01 --> Total execution time: 0.0341
INFO - 2017-03-10 01:32:01 --> Config Class Initialized
INFO - 2017-03-10 01:32:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:32:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:32:01 --> Utf8 Class Initialized
INFO - 2017-03-10 01:32:01 --> URI Class Initialized
INFO - 2017-03-10 01:32:01 --> Router Class Initialized
INFO - 2017-03-10 01:32:01 --> Output Class Initialized
INFO - 2017-03-10 01:32:01 --> Security Class Initialized
DEBUG - 2017-03-10 01:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:32:01 --> Input Class Initialized
INFO - 2017-03-10 01:32:01 --> Language Class Initialized
INFO - 2017-03-10 01:32:01 --> Loader Class Initialized
INFO - 2017-03-10 01:32:01 --> Database Driver Class Initialized
INFO - 2017-03-10 01:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:32:01 --> Controller Class Initialized
INFO - 2017-03-10 01:32:01 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:32:01 --> Final output sent to browser
DEBUG - 2017-03-10 01:32:01 --> Total execution time: 0.0594
INFO - 2017-03-10 01:32:16 --> Config Class Initialized
INFO - 2017-03-10 01:32:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:32:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:32:16 --> Utf8 Class Initialized
INFO - 2017-03-10 01:32:16 --> URI Class Initialized
INFO - 2017-03-10 01:32:16 --> Router Class Initialized
INFO - 2017-03-10 01:32:16 --> Output Class Initialized
INFO - 2017-03-10 01:32:16 --> Security Class Initialized
DEBUG - 2017-03-10 01:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:32:16 --> Input Class Initialized
INFO - 2017-03-10 01:32:16 --> Language Class Initialized
INFO - 2017-03-10 01:32:16 --> Loader Class Initialized
INFO - 2017-03-10 01:32:16 --> Database Driver Class Initialized
INFO - 2017-03-10 01:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:32:17 --> Controller Class Initialized
INFO - 2017-03-10 01:32:17 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:32:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:32:17 --> Helper loaded: url_helper
INFO - 2017-03-10 01:32:17 --> Helper loaded: download_helper
INFO - 2017-03-10 01:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:32:17 --> Final output sent to browser
DEBUG - 2017-03-10 01:32:17 --> Total execution time: 1.1346
INFO - 2017-03-10 01:32:17 --> Config Class Initialized
INFO - 2017-03-10 01:32:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:32:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:32:18 --> Utf8 Class Initialized
INFO - 2017-03-10 01:32:18 --> URI Class Initialized
INFO - 2017-03-10 01:32:18 --> Router Class Initialized
INFO - 2017-03-10 01:32:18 --> Output Class Initialized
INFO - 2017-03-10 01:32:18 --> Security Class Initialized
DEBUG - 2017-03-10 01:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:32:18 --> Input Class Initialized
INFO - 2017-03-10 01:32:18 --> Language Class Initialized
INFO - 2017-03-10 01:32:18 --> Loader Class Initialized
INFO - 2017-03-10 01:32:18 --> Database Driver Class Initialized
INFO - 2017-03-10 01:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:32:18 --> Controller Class Initialized
INFO - 2017-03-10 01:32:18 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:32:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:32:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:32:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:32:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:32:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:32:19 --> Final output sent to browser
DEBUG - 2017-03-10 01:32:19 --> Total execution time: 1.2536
INFO - 2017-03-10 01:32:43 --> Config Class Initialized
INFO - 2017-03-10 01:32:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:32:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:32:43 --> Utf8 Class Initialized
INFO - 2017-03-10 01:32:43 --> URI Class Initialized
INFO - 2017-03-10 01:32:43 --> Router Class Initialized
INFO - 2017-03-10 01:32:43 --> Output Class Initialized
INFO - 2017-03-10 01:32:43 --> Security Class Initialized
DEBUG - 2017-03-10 01:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:32:43 --> Input Class Initialized
INFO - 2017-03-10 01:32:43 --> Language Class Initialized
INFO - 2017-03-10 01:32:43 --> Loader Class Initialized
INFO - 2017-03-10 01:32:43 --> Database Driver Class Initialized
INFO - 2017-03-10 01:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:32:44 --> Controller Class Initialized
INFO - 2017-03-10 01:32:44 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:32:44 --> Helper loaded: url_helper
INFO - 2017-03-10 01:32:44 --> Helper loaded: download_helper
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:32:44 --> Final output sent to browser
DEBUG - 2017-03-10 01:32:44 --> Total execution time: 1.1312
INFO - 2017-03-10 01:32:44 --> Config Class Initialized
INFO - 2017-03-10 01:32:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:32:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:32:44 --> Utf8 Class Initialized
INFO - 2017-03-10 01:32:44 --> URI Class Initialized
INFO - 2017-03-10 01:32:44 --> Router Class Initialized
INFO - 2017-03-10 01:32:44 --> Output Class Initialized
INFO - 2017-03-10 01:32:44 --> Security Class Initialized
DEBUG - 2017-03-10 01:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:32:44 --> Input Class Initialized
INFO - 2017-03-10 01:32:44 --> Language Class Initialized
INFO - 2017-03-10 01:32:44 --> Loader Class Initialized
INFO - 2017-03-10 01:32:44 --> Database Driver Class Initialized
INFO - 2017-03-10 01:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:32:44 --> Controller Class Initialized
INFO - 2017-03-10 01:32:44 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:32:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:32:44 --> Final output sent to browser
DEBUG - 2017-03-10 01:32:44 --> Total execution time: 0.2450
INFO - 2017-03-10 01:33:08 --> Config Class Initialized
INFO - 2017-03-10 01:33:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:33:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:33:08 --> Utf8 Class Initialized
INFO - 2017-03-10 01:33:08 --> URI Class Initialized
INFO - 2017-03-10 01:33:08 --> Router Class Initialized
INFO - 2017-03-10 01:33:08 --> Output Class Initialized
INFO - 2017-03-10 01:33:08 --> Security Class Initialized
DEBUG - 2017-03-10 01:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:33:08 --> Input Class Initialized
INFO - 2017-03-10 01:33:08 --> Language Class Initialized
INFO - 2017-03-10 01:33:08 --> Loader Class Initialized
INFO - 2017-03-10 01:33:08 --> Database Driver Class Initialized
INFO - 2017-03-10 01:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:33:08 --> Controller Class Initialized
INFO - 2017-03-10 01:33:08 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:33:08 --> Helper loaded: url_helper
INFO - 2017-03-10 01:33:08 --> Helper loaded: download_helper
INFO - 2017-03-10 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:33:08 --> Final output sent to browser
DEBUG - 2017-03-10 01:33:08 --> Total execution time: 0.0202
INFO - 2017-03-10 01:33:09 --> Config Class Initialized
INFO - 2017-03-10 01:33:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:33:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:33:09 --> Utf8 Class Initialized
INFO - 2017-03-10 01:33:09 --> URI Class Initialized
INFO - 2017-03-10 01:33:09 --> Router Class Initialized
INFO - 2017-03-10 01:33:09 --> Output Class Initialized
INFO - 2017-03-10 01:33:09 --> Security Class Initialized
DEBUG - 2017-03-10 01:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:33:09 --> Input Class Initialized
INFO - 2017-03-10 01:33:09 --> Language Class Initialized
INFO - 2017-03-10 01:33:09 --> Loader Class Initialized
INFO - 2017-03-10 01:33:09 --> Database Driver Class Initialized
INFO - 2017-03-10 01:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:33:09 --> Controller Class Initialized
INFO - 2017-03-10 01:33:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:33:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:33:09 --> Final output sent to browser
DEBUG - 2017-03-10 01:33:09 --> Total execution time: 0.0138
INFO - 2017-03-10 01:33:52 --> Config Class Initialized
INFO - 2017-03-10 01:33:52 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:33:52 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:33:52 --> Utf8 Class Initialized
INFO - 2017-03-10 01:33:52 --> URI Class Initialized
INFO - 2017-03-10 01:33:52 --> Router Class Initialized
INFO - 2017-03-10 01:33:52 --> Output Class Initialized
INFO - 2017-03-10 01:33:52 --> Security Class Initialized
DEBUG - 2017-03-10 01:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:33:52 --> Input Class Initialized
INFO - 2017-03-10 01:33:52 --> Language Class Initialized
INFO - 2017-03-10 01:33:52 --> Loader Class Initialized
INFO - 2017-03-10 01:33:52 --> Database Driver Class Initialized
INFO - 2017-03-10 01:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:33:52 --> Controller Class Initialized
INFO - 2017-03-10 01:33:52 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:33:52 --> Helper loaded: url_helper
INFO - 2017-03-10 01:33:52 --> Helper loaded: download_helper
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:33:52 --> Final output sent to browser
DEBUG - 2017-03-10 01:33:52 --> Total execution time: 0.0193
INFO - 2017-03-10 01:33:52 --> Config Class Initialized
INFO - 2017-03-10 01:33:52 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:33:52 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:33:52 --> Utf8 Class Initialized
INFO - 2017-03-10 01:33:52 --> URI Class Initialized
INFO - 2017-03-10 01:33:52 --> Router Class Initialized
INFO - 2017-03-10 01:33:52 --> Output Class Initialized
INFO - 2017-03-10 01:33:52 --> Security Class Initialized
DEBUG - 2017-03-10 01:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:33:52 --> Input Class Initialized
INFO - 2017-03-10 01:33:52 --> Language Class Initialized
INFO - 2017-03-10 01:33:52 --> Loader Class Initialized
INFO - 2017-03-10 01:33:52 --> Database Driver Class Initialized
INFO - 2017-03-10 01:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:33:52 --> Controller Class Initialized
INFO - 2017-03-10 01:33:52 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:33:52 --> Final output sent to browser
DEBUG - 2017-03-10 01:33:52 --> Total execution time: 0.0141
INFO - 2017-03-10 01:33:57 --> Config Class Initialized
INFO - 2017-03-10 01:33:57 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:33:57 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:33:57 --> Utf8 Class Initialized
INFO - 2017-03-10 01:33:57 --> URI Class Initialized
INFO - 2017-03-10 01:33:57 --> Router Class Initialized
INFO - 2017-03-10 01:33:57 --> Output Class Initialized
INFO - 2017-03-10 01:33:57 --> Security Class Initialized
DEBUG - 2017-03-10 01:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:33:57 --> Input Class Initialized
INFO - 2017-03-10 01:33:57 --> Language Class Initialized
ERROR - 2017-03-10 01:33:57 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 01:35:09 --> Config Class Initialized
INFO - 2017-03-10 01:35:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:35:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:09 --> Utf8 Class Initialized
INFO - 2017-03-10 01:35:09 --> URI Class Initialized
INFO - 2017-03-10 01:35:09 --> Router Class Initialized
INFO - 2017-03-10 01:35:09 --> Output Class Initialized
INFO - 2017-03-10 01:35:09 --> Security Class Initialized
DEBUG - 2017-03-10 01:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:09 --> Input Class Initialized
INFO - 2017-03-10 01:35:09 --> Language Class Initialized
INFO - 2017-03-10 01:35:09 --> Loader Class Initialized
INFO - 2017-03-10 01:35:09 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:09 --> Controller Class Initialized
INFO - 2017-03-10 01:35:09 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:10 --> Helper loaded: url_helper
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:10 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:10 --> Total execution time: 1.0798
INFO - 2017-03-10 01:35:10 --> Config Class Initialized
INFO - 2017-03-10 01:35:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:35:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:10 --> Utf8 Class Initialized
INFO - 2017-03-10 01:35:10 --> URI Class Initialized
INFO - 2017-03-10 01:35:10 --> Router Class Initialized
INFO - 2017-03-10 01:35:10 --> Output Class Initialized
INFO - 2017-03-10 01:35:10 --> Security Class Initialized
DEBUG - 2017-03-10 01:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:10 --> Input Class Initialized
INFO - 2017-03-10 01:35:10 --> Language Class Initialized
INFO - 2017-03-10 01:35:10 --> Loader Class Initialized
INFO - 2017-03-10 01:35:10 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:10 --> Controller Class Initialized
INFO - 2017-03-10 01:35:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:10 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:10 --> Total execution time: 0.2735
INFO - 2017-03-10 01:35:24 --> Config Class Initialized
INFO - 2017-03-10 01:35:24 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:35:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:24 --> Utf8 Class Initialized
INFO - 2017-03-10 01:35:24 --> URI Class Initialized
INFO - 2017-03-10 01:35:24 --> Router Class Initialized
INFO - 2017-03-10 01:35:24 --> Output Class Initialized
INFO - 2017-03-10 01:35:24 --> Security Class Initialized
DEBUG - 2017-03-10 01:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:24 --> Input Class Initialized
INFO - 2017-03-10 01:35:24 --> Language Class Initialized
INFO - 2017-03-10 01:35:24 --> Loader Class Initialized
INFO - 2017-03-10 01:35:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:25 --> Controller Class Initialized
INFO - 2017-03-10 01:35:25 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:25 --> Helper loaded: url_helper
INFO - 2017-03-10 01:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:25 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:25 --> Total execution time: 1.2290
INFO - 2017-03-10 01:35:26 --> Config Class Initialized
INFO - 2017-03-10 01:35:26 --> Config Class Initialized
INFO - 2017-03-10 01:35:26 --> Hooks Class Initialized
INFO - 2017-03-10 01:35:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:35:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:26 --> Utf8 Class Initialized
DEBUG - 2017-03-10 01:35:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:26 --> Utf8 Class Initialized
INFO - 2017-03-10 01:35:26 --> URI Class Initialized
INFO - 2017-03-10 01:35:26 --> URI Class Initialized
INFO - 2017-03-10 01:35:26 --> Router Class Initialized
INFO - 2017-03-10 01:35:26 --> Router Class Initialized
INFO - 2017-03-10 01:35:26 --> Output Class Initialized
INFO - 2017-03-10 01:35:26 --> Security Class Initialized
INFO - 2017-03-10 01:35:26 --> Output Class Initialized
DEBUG - 2017-03-10 01:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:26 --> Input Class Initialized
INFO - 2017-03-10 01:35:26 --> Security Class Initialized
INFO - 2017-03-10 01:35:26 --> Language Class Initialized
DEBUG - 2017-03-10 01:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:26 --> Loader Class Initialized
INFO - 2017-03-10 01:35:26 --> Input Class Initialized
INFO - 2017-03-10 01:35:26 --> Language Class Initialized
INFO - 2017-03-10 01:35:26 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:26 --> Controller Class Initialized
INFO - 2017-03-10 01:35:26 --> Helper loaded: url_helper
INFO - 2017-03-10 01:35:26 --> Loader Class Initialized
DEBUG - 2017-03-10 01:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:26 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:35:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:35:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:26 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:26 --> Total execution time: 0.5616
INFO - 2017-03-10 01:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:26 --> Controller Class Initialized
INFO - 2017-03-10 01:35:27 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:35:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:27 --> Helper loaded: url_helper
INFO - 2017-03-10 01:35:27 --> Helper loaded: download_helper
INFO - 2017-03-10 01:35:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:35:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:35:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:35:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:27 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:27 --> Total execution time: 0.8844
INFO - 2017-03-10 01:35:27 --> Config Class Initialized
INFO - 2017-03-10 01:35:27 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:35:27 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:27 --> Utf8 Class Initialized
INFO - 2017-03-10 01:35:27 --> URI Class Initialized
INFO - 2017-03-10 01:35:27 --> Router Class Initialized
INFO - 2017-03-10 01:35:27 --> Output Class Initialized
INFO - 2017-03-10 01:35:27 --> Security Class Initialized
DEBUG - 2017-03-10 01:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:27 --> Input Class Initialized
INFO - 2017-03-10 01:35:27 --> Language Class Initialized
INFO - 2017-03-10 01:35:27 --> Loader Class Initialized
INFO - 2017-03-10 01:35:28 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:28 --> Controller Class Initialized
INFO - 2017-03-10 01:35:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:28 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:28 --> Total execution time: 0.5553
INFO - 2017-03-10 01:35:48 --> Config Class Initialized
INFO - 2017-03-10 01:35:48 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:35:48 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:49 --> Utf8 Class Initialized
INFO - 2017-03-10 01:35:49 --> URI Class Initialized
INFO - 2017-03-10 01:35:49 --> Router Class Initialized
INFO - 2017-03-10 01:35:49 --> Output Class Initialized
INFO - 2017-03-10 01:35:49 --> Security Class Initialized
DEBUG - 2017-03-10 01:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:49 --> Input Class Initialized
INFO - 2017-03-10 01:35:49 --> Language Class Initialized
INFO - 2017-03-10 01:35:49 --> Loader Class Initialized
INFO - 2017-03-10 01:35:49 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:49 --> Controller Class Initialized
INFO - 2017-03-10 01:35:49 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:49 --> Helper loaded: url_helper
INFO - 2017-03-10 01:35:49 --> Helper loaded: download_helper
INFO - 2017-03-10 01:35:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:35:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:35:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:35:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:49 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:49 --> Total execution time: 1.1398
INFO - 2017-03-10 01:35:50 --> Config Class Initialized
INFO - 2017-03-10 01:35:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:35:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:35:50 --> Utf8 Class Initialized
INFO - 2017-03-10 01:35:50 --> URI Class Initialized
INFO - 2017-03-10 01:35:50 --> Router Class Initialized
INFO - 2017-03-10 01:35:50 --> Output Class Initialized
INFO - 2017-03-10 01:35:50 --> Security Class Initialized
DEBUG - 2017-03-10 01:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:35:50 --> Input Class Initialized
INFO - 2017-03-10 01:35:50 --> Language Class Initialized
INFO - 2017-03-10 01:35:50 --> Loader Class Initialized
INFO - 2017-03-10 01:35:50 --> Database Driver Class Initialized
INFO - 2017-03-10 01:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:35:50 --> Controller Class Initialized
INFO - 2017-03-10 01:35:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:35:50 --> Final output sent to browser
DEBUG - 2017-03-10 01:35:50 --> Total execution time: 0.2603
INFO - 2017-03-10 01:36:11 --> Config Class Initialized
INFO - 2017-03-10 01:36:11 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:11 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:11 --> URI Class Initialized
INFO - 2017-03-10 01:36:12 --> Router Class Initialized
INFO - 2017-03-10 01:36:12 --> Output Class Initialized
INFO - 2017-03-10 01:36:12 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:12 --> Input Class Initialized
INFO - 2017-03-10 01:36:12 --> Language Class Initialized
INFO - 2017-03-10 01:36:12 --> Loader Class Initialized
INFO - 2017-03-10 01:36:12 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:12 --> Controller Class Initialized
INFO - 2017-03-10 01:36:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:12 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:12 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:36:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-10 01:36:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:36:13 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:13 --> Total execution time: 1.2506
INFO - 2017-03-10 01:36:14 --> Config Class Initialized
INFO - 2017-03-10 01:36:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:14 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:14 --> URI Class Initialized
INFO - 2017-03-10 01:36:14 --> Router Class Initialized
INFO - 2017-03-10 01:36:14 --> Output Class Initialized
INFO - 2017-03-10 01:36:14 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:14 --> Input Class Initialized
INFO - 2017-03-10 01:36:14 --> Language Class Initialized
INFO - 2017-03-10 01:36:14 --> Loader Class Initialized
INFO - 2017-03-10 01:36:15 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:15 --> Controller Class Initialized
INFO - 2017-03-10 01:36:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:36:15 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:15 --> Total execution time: 1.2158
INFO - 2017-03-10 01:36:22 --> Config Class Initialized
INFO - 2017-03-10 01:36:22 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:22 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:22 --> URI Class Initialized
INFO - 2017-03-10 01:36:22 --> Router Class Initialized
INFO - 2017-03-10 01:36:22 --> Output Class Initialized
INFO - 2017-03-10 01:36:22 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:22 --> Input Class Initialized
INFO - 2017-03-10 01:36:22 --> Language Class Initialized
INFO - 2017-03-10 01:36:22 --> Loader Class Initialized
INFO - 2017-03-10 01:36:22 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:22 --> Controller Class Initialized
INFO - 2017-03-10 01:36:22 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:22 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:22 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-10 01:36:23 --> Config Class Initialized
INFO - 2017-03-10 01:36:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:23 --> URI Class Initialized
INFO - 2017-03-10 01:36:23 --> Router Class Initialized
INFO - 2017-03-10 01:36:23 --> Output Class Initialized
INFO - 2017-03-10 01:36:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:23 --> Input Class Initialized
INFO - 2017-03-10 01:36:23 --> Language Class Initialized
INFO - 2017-03-10 01:36:23 --> Loader Class Initialized
INFO - 2017-03-10 01:36:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:23 --> Controller Class Initialized
INFO - 2017-03-10 01:36:23 --> Helper loaded: date_helper
INFO - 2017-03-10 01:36:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:23 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:23 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:36:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:23 --> Total execution time: 0.1798
INFO - 2017-03-10 01:36:23 --> Config Class Initialized
INFO - 2017-03-10 01:36:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:23 --> URI Class Initialized
INFO - 2017-03-10 01:36:23 --> Router Class Initialized
INFO - 2017-03-10 01:36:23 --> Output Class Initialized
INFO - 2017-03-10 01:36:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:23 --> Input Class Initialized
INFO - 2017-03-10 01:36:23 --> Language Class Initialized
INFO - 2017-03-10 01:36:23 --> Loader Class Initialized
INFO - 2017-03-10 01:36:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:23 --> Controller Class Initialized
INFO - 2017-03-10 01:36:23 --> Helper loaded: date_helper
INFO - 2017-03-10 01:36:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:23 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:23 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:23 --> Total execution time: 0.0154
INFO - 2017-03-10 01:36:26 --> Config Class Initialized
INFO - 2017-03-10 01:36:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:26 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:26 --> URI Class Initialized
INFO - 2017-03-10 01:36:26 --> Router Class Initialized
INFO - 2017-03-10 01:36:26 --> Output Class Initialized
INFO - 2017-03-10 01:36:26 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:26 --> Input Class Initialized
INFO - 2017-03-10 01:36:26 --> Language Class Initialized
INFO - 2017-03-10 01:36:26 --> Loader Class Initialized
INFO - 2017-03-10 01:36:26 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:26 --> Controller Class Initialized
INFO - 2017-03-10 01:36:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:36:26 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:26 --> Total execution time: 0.0140
INFO - 2017-03-10 01:36:27 --> Config Class Initialized
INFO - 2017-03-10 01:36:27 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:27 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:27 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:27 --> URI Class Initialized
INFO - 2017-03-10 01:36:27 --> Router Class Initialized
INFO - 2017-03-10 01:36:27 --> Output Class Initialized
INFO - 2017-03-10 01:36:27 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:27 --> Input Class Initialized
INFO - 2017-03-10 01:36:27 --> Language Class Initialized
INFO - 2017-03-10 01:36:27 --> Loader Class Initialized
INFO - 2017-03-10 01:36:27 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:27 --> Controller Class Initialized
INFO - 2017-03-10 01:36:28 --> Upload Class Initialized
INFO - 2017-03-10 01:36:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:28 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:28 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-03-10 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-03-10 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:36:28 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:28 --> Total execution time: 0.1708
INFO - 2017-03-10 01:36:29 --> Config Class Initialized
INFO - 2017-03-10 01:36:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:29 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:29 --> URI Class Initialized
INFO - 2017-03-10 01:36:29 --> Router Class Initialized
INFO - 2017-03-10 01:36:29 --> Output Class Initialized
INFO - 2017-03-10 01:36:29 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:29 --> Input Class Initialized
INFO - 2017-03-10 01:36:29 --> Language Class Initialized
INFO - 2017-03-10 01:36:29 --> Loader Class Initialized
INFO - 2017-03-10 01:36:29 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:29 --> Controller Class Initialized
INFO - 2017-03-10 01:36:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:36:29 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:29 --> Total execution time: 0.3928
INFO - 2017-03-10 01:36:29 --> Config Class Initialized
INFO - 2017-03-10 01:36:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:29 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:29 --> URI Class Initialized
INFO - 2017-03-10 01:36:29 --> Router Class Initialized
INFO - 2017-03-10 01:36:29 --> Output Class Initialized
INFO - 2017-03-10 01:36:29 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:29 --> Input Class Initialized
INFO - 2017-03-10 01:36:29 --> Language Class Initialized
INFO - 2017-03-10 01:36:29 --> Loader Class Initialized
INFO - 2017-03-10 01:36:29 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:29 --> Controller Class Initialized
INFO - 2017-03-10 01:36:29 --> Upload Class Initialized
INFO - 2017-03-10 01:36:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:29 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:29 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:36:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:36:29 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:29 --> Total execution time: 0.1154
INFO - 2017-03-10 01:36:30 --> Config Class Initialized
INFO - 2017-03-10 01:36:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:30 --> URI Class Initialized
INFO - 2017-03-10 01:36:30 --> Router Class Initialized
INFO - 2017-03-10 01:36:30 --> Output Class Initialized
INFO - 2017-03-10 01:36:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:30 --> Input Class Initialized
INFO - 2017-03-10 01:36:30 --> Language Class Initialized
INFO - 2017-03-10 01:36:30 --> Loader Class Initialized
INFO - 2017-03-10 01:36:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:30 --> Controller Class Initialized
INFO - 2017-03-10 01:36:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:36:30 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:30 --> Total execution time: 0.5180
INFO - 2017-03-10 01:36:36 --> Config Class Initialized
INFO - 2017-03-10 01:36:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:36 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:36 --> URI Class Initialized
INFO - 2017-03-10 01:36:36 --> Router Class Initialized
INFO - 2017-03-10 01:36:36 --> Output Class Initialized
INFO - 2017-03-10 01:36:36 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:36 --> Input Class Initialized
INFO - 2017-03-10 01:36:36 --> Language Class Initialized
INFO - 2017-03-10 01:36:36 --> Loader Class Initialized
INFO - 2017-03-10 01:36:36 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:36 --> Controller Class Initialized
INFO - 2017-03-10 01:36:36 --> Upload Class Initialized
INFO - 2017-03-10 01:36:36 --> Helper loaded: date_helper
INFO - 2017-03-10 01:36:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:36 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:36 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:36:36 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:36 --> Total execution time: 0.0641
INFO - 2017-03-10 01:36:36 --> Config Class Initialized
INFO - 2017-03-10 01:36:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:36 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:36 --> URI Class Initialized
INFO - 2017-03-10 01:36:36 --> Router Class Initialized
INFO - 2017-03-10 01:36:36 --> Output Class Initialized
INFO - 2017-03-10 01:36:36 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:36 --> Input Class Initialized
INFO - 2017-03-10 01:36:36 --> Language Class Initialized
INFO - 2017-03-10 01:36:36 --> Loader Class Initialized
INFO - 2017-03-10 01:36:36 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:36 --> Controller Class Initialized
INFO - 2017-03-10 01:36:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:36:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:36:36 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:36 --> Total execution time: 0.0142
INFO - 2017-03-10 01:36:37 --> Config Class Initialized
INFO - 2017-03-10 01:36:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:37 --> URI Class Initialized
INFO - 2017-03-10 01:36:37 --> Router Class Initialized
INFO - 2017-03-10 01:36:37 --> Output Class Initialized
INFO - 2017-03-10 01:36:37 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:37 --> Input Class Initialized
INFO - 2017-03-10 01:36:37 --> Language Class Initialized
INFO - 2017-03-10 01:36:37 --> Loader Class Initialized
INFO - 2017-03-10 01:36:37 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:37 --> Controller Class Initialized
INFO - 2017-03-10 01:36:37 --> Helper loaded: date_helper
INFO - 2017-03-10 01:36:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:37 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:37 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:36:37 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:37 --> Total execution time: 0.0885
INFO - 2017-03-10 01:36:37 --> Config Class Initialized
INFO - 2017-03-10 01:36:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:37 --> URI Class Initialized
INFO - 2017-03-10 01:36:37 --> Router Class Initialized
INFO - 2017-03-10 01:36:37 --> Output Class Initialized
INFO - 2017-03-10 01:36:37 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:37 --> Input Class Initialized
INFO - 2017-03-10 01:36:37 --> Language Class Initialized
INFO - 2017-03-10 01:36:37 --> Loader Class Initialized
INFO - 2017-03-10 01:36:37 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:37 --> Controller Class Initialized
INFO - 2017-03-10 01:36:37 --> Helper loaded: date_helper
INFO - 2017-03-10 01:36:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:37 --> Helper loaded: form_helper
INFO - 2017-03-10 01:36:37 --> Form Validation Class Initialized
INFO - 2017-03-10 01:36:37 --> Config Class Initialized
INFO - 2017-03-10 01:36:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:36:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:36:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:36:37 --> URI Class Initialized
INFO - 2017-03-10 01:36:37 --> Router Class Initialized
INFO - 2017-03-10 01:36:37 --> Output Class Initialized
INFO - 2017-03-10 01:36:37 --> Security Class Initialized
DEBUG - 2017-03-10 01:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:36:37 --> Input Class Initialized
INFO - 2017-03-10 01:36:37 --> Language Class Initialized
INFO - 2017-03-10 01:36:37 --> Loader Class Initialized
INFO - 2017-03-10 01:36:37 --> Database Driver Class Initialized
INFO - 2017-03-10 01:36:37 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:37 --> Total execution time: 0.0622
INFO - 2017-03-10 01:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:36:37 --> Controller Class Initialized
INFO - 2017-03-10 01:36:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:36:37 --> Final output sent to browser
DEBUG - 2017-03-10 01:36:37 --> Total execution time: 0.0808
INFO - 2017-03-10 01:38:09 --> Config Class Initialized
INFO - 2017-03-10 01:38:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:38:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:38:09 --> Utf8 Class Initialized
INFO - 2017-03-10 01:38:09 --> URI Class Initialized
INFO - 2017-03-10 01:38:09 --> Router Class Initialized
INFO - 2017-03-10 01:38:09 --> Output Class Initialized
INFO - 2017-03-10 01:38:09 --> Security Class Initialized
DEBUG - 2017-03-10 01:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:38:09 --> Input Class Initialized
INFO - 2017-03-10 01:38:09 --> Language Class Initialized
INFO - 2017-03-10 01:38:09 --> Loader Class Initialized
INFO - 2017-03-10 01:38:10 --> Database Driver Class Initialized
INFO - 2017-03-10 01:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:38:10 --> Controller Class Initialized
INFO - 2017-03-10 01:38:10 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:38:10 --> Helper loaded: url_helper
INFO - 2017-03-10 01:38:10 --> Helper loaded: download_helper
INFO - 2017-03-10 01:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:38:10 --> Final output sent to browser
DEBUG - 2017-03-10 01:38:10 --> Total execution time: 1.1681
INFO - 2017-03-10 01:38:10 --> Config Class Initialized
INFO - 2017-03-10 01:38:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:38:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:38:10 --> Utf8 Class Initialized
INFO - 2017-03-10 01:38:10 --> URI Class Initialized
INFO - 2017-03-10 01:38:10 --> Router Class Initialized
INFO - 2017-03-10 01:38:10 --> Output Class Initialized
INFO - 2017-03-10 01:38:10 --> Security Class Initialized
DEBUG - 2017-03-10 01:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:38:10 --> Input Class Initialized
INFO - 2017-03-10 01:38:10 --> Language Class Initialized
INFO - 2017-03-10 01:38:10 --> Loader Class Initialized
INFO - 2017-03-10 01:38:10 --> Database Driver Class Initialized
INFO - 2017-03-10 01:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:38:10 --> Controller Class Initialized
INFO - 2017-03-10 01:38:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:38:11 --> Final output sent to browser
DEBUG - 2017-03-10 01:38:11 --> Total execution time: 0.2523
INFO - 2017-03-10 01:38:14 --> Config Class Initialized
INFO - 2017-03-10 01:38:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:38:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:38:14 --> Utf8 Class Initialized
INFO - 2017-03-10 01:38:14 --> URI Class Initialized
INFO - 2017-03-10 01:38:14 --> Router Class Initialized
INFO - 2017-03-10 01:38:14 --> Output Class Initialized
INFO - 2017-03-10 01:38:14 --> Security Class Initialized
DEBUG - 2017-03-10 01:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:38:14 --> Input Class Initialized
INFO - 2017-03-10 01:38:14 --> Language Class Initialized
INFO - 2017-03-10 01:38:14 --> Loader Class Initialized
INFO - 2017-03-10 01:38:14 --> Database Driver Class Initialized
INFO - 2017-03-10 01:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:38:15 --> Controller Class Initialized
INFO - 2017-03-10 01:38:15 --> Helper loaded: date_helper
INFO - 2017-03-10 01:38:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:38:15 --> Helper loaded: form_helper
INFO - 2017-03-10 01:38:15 --> Form Validation Class Initialized
INFO - 2017-03-10 01:38:15 --> Final output sent to browser
DEBUG - 2017-03-10 01:38:15 --> Total execution time: 1.2643
INFO - 2017-03-10 01:40:12 --> Config Class Initialized
INFO - 2017-03-10 01:40:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:40:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:40:12 --> Utf8 Class Initialized
INFO - 2017-03-10 01:40:12 --> URI Class Initialized
DEBUG - 2017-03-10 01:40:12 --> No URI present. Default controller set.
INFO - 2017-03-10 01:40:12 --> Router Class Initialized
INFO - 2017-03-10 01:40:12 --> Output Class Initialized
INFO - 2017-03-10 01:40:12 --> Security Class Initialized
DEBUG - 2017-03-10 01:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:40:13 --> Input Class Initialized
INFO - 2017-03-10 01:40:13 --> Language Class Initialized
INFO - 2017-03-10 01:40:13 --> Loader Class Initialized
INFO - 2017-03-10 01:40:13 --> Database Driver Class Initialized
INFO - 2017-03-10 01:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:40:13 --> Controller Class Initialized
INFO - 2017-03-10 01:40:13 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:40:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:40:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:40:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:40:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:40:13 --> Final output sent to browser
DEBUG - 2017-03-10 01:40:13 --> Total execution time: 1.2210
INFO - 2017-03-10 01:40:15 --> Config Class Initialized
INFO - 2017-03-10 01:40:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:40:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:40:15 --> Utf8 Class Initialized
INFO - 2017-03-10 01:40:15 --> URI Class Initialized
INFO - 2017-03-10 01:40:15 --> Router Class Initialized
INFO - 2017-03-10 01:40:15 --> Output Class Initialized
INFO - 2017-03-10 01:40:15 --> Security Class Initialized
DEBUG - 2017-03-10 01:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:40:15 --> Input Class Initialized
INFO - 2017-03-10 01:40:15 --> Language Class Initialized
INFO - 2017-03-10 01:40:15 --> Loader Class Initialized
INFO - 2017-03-10 01:40:15 --> Database Driver Class Initialized
INFO - 2017-03-10 01:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:40:15 --> Controller Class Initialized
INFO - 2017-03-10 01:40:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:40:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:40:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:40:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:40:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:40:15 --> Final output sent to browser
DEBUG - 2017-03-10 01:40:15 --> Total execution time: 0.0142
INFO - 2017-03-10 01:40:32 --> Config Class Initialized
INFO - 2017-03-10 01:40:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:40:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:40:32 --> Utf8 Class Initialized
INFO - 2017-03-10 01:40:32 --> URI Class Initialized
INFO - 2017-03-10 01:40:32 --> Router Class Initialized
INFO - 2017-03-10 01:40:32 --> Output Class Initialized
INFO - 2017-03-10 01:40:32 --> Security Class Initialized
DEBUG - 2017-03-10 01:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:40:32 --> Input Class Initialized
INFO - 2017-03-10 01:40:32 --> Language Class Initialized
INFO - 2017-03-10 01:40:32 --> Loader Class Initialized
INFO - 2017-03-10 01:40:32 --> Database Driver Class Initialized
INFO - 2017-03-10 01:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:40:32 --> Controller Class Initialized
INFO - 2017-03-10 01:40:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:40:32 --> Final output sent to browser
DEBUG - 2017-03-10 01:40:32 --> Total execution time: 0.0228
INFO - 2017-03-10 01:48:59 --> Config Class Initialized
INFO - 2017-03-10 01:48:59 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:48:59 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:48:59 --> Utf8 Class Initialized
INFO - 2017-03-10 01:48:59 --> URI Class Initialized
DEBUG - 2017-03-10 01:48:59 --> No URI present. Default controller set.
INFO - 2017-03-10 01:48:59 --> Router Class Initialized
INFO - 2017-03-10 01:48:59 --> Output Class Initialized
INFO - 2017-03-10 01:48:59 --> Security Class Initialized
DEBUG - 2017-03-10 01:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:48:59 --> Input Class Initialized
INFO - 2017-03-10 01:48:59 --> Language Class Initialized
INFO - 2017-03-10 01:48:59 --> Loader Class Initialized
INFO - 2017-03-10 01:49:00 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:00 --> Controller Class Initialized
INFO - 2017-03-10 01:49:00 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:00 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:00 --> Total execution time: 1.2460
INFO - 2017-03-10 01:49:01 --> Config Class Initialized
INFO - 2017-03-10 01:49:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:01 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:01 --> URI Class Initialized
INFO - 2017-03-10 01:49:01 --> Router Class Initialized
INFO - 2017-03-10 01:49:01 --> Output Class Initialized
INFO - 2017-03-10 01:49:01 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:01 --> Input Class Initialized
INFO - 2017-03-10 01:49:01 --> Language Class Initialized
INFO - 2017-03-10 01:49:01 --> Loader Class Initialized
INFO - 2017-03-10 01:49:01 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:01 --> Controller Class Initialized
INFO - 2017-03-10 01:49:01 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:01 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:01 --> Total execution time: 0.0155
INFO - 2017-03-10 01:49:04 --> Config Class Initialized
INFO - 2017-03-10 01:49:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:04 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:04 --> URI Class Initialized
INFO - 2017-03-10 01:49:04 --> Router Class Initialized
INFO - 2017-03-10 01:49:04 --> Output Class Initialized
INFO - 2017-03-10 01:49:04 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:04 --> Input Class Initialized
INFO - 2017-03-10 01:49:04 --> Language Class Initialized
INFO - 2017-03-10 01:49:04 --> Loader Class Initialized
INFO - 2017-03-10 01:49:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:04 --> Controller Class Initialized
INFO - 2017-03-10 01:49:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:05 --> Config Class Initialized
INFO - 2017-03-10 01:49:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:05 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:05 --> URI Class Initialized
INFO - 2017-03-10 01:49:05 --> Router Class Initialized
INFO - 2017-03-10 01:49:05 --> Output Class Initialized
INFO - 2017-03-10 01:49:05 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:05 --> Input Class Initialized
INFO - 2017-03-10 01:49:05 --> Language Class Initialized
INFO - 2017-03-10 01:49:05 --> Loader Class Initialized
INFO - 2017-03-10 01:49:05 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:05 --> Controller Class Initialized
INFO - 2017-03-10 01:49:05 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:05 --> Helper loaded: url_helper
INFO - 2017-03-10 01:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:05 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:05 --> Total execution time: 0.0887
INFO - 2017-03-10 01:49:06 --> Config Class Initialized
INFO - 2017-03-10 01:49:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:06 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:06 --> URI Class Initialized
INFO - 2017-03-10 01:49:06 --> Router Class Initialized
INFO - 2017-03-10 01:49:06 --> Output Class Initialized
INFO - 2017-03-10 01:49:06 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:06 --> Input Class Initialized
INFO - 2017-03-10 01:49:06 --> Language Class Initialized
INFO - 2017-03-10 01:49:06 --> Loader Class Initialized
INFO - 2017-03-10 01:49:06 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:06 --> Controller Class Initialized
INFO - 2017-03-10 01:49:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:06 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:06 --> Total execution time: 0.0141
INFO - 2017-03-10 01:49:13 --> Config Class Initialized
INFO - 2017-03-10 01:49:13 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:13 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:13 --> URI Class Initialized
INFO - 2017-03-10 01:49:13 --> Router Class Initialized
INFO - 2017-03-10 01:49:13 --> Output Class Initialized
INFO - 2017-03-10 01:49:13 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:13 --> Input Class Initialized
INFO - 2017-03-10 01:49:13 --> Language Class Initialized
INFO - 2017-03-10 01:49:13 --> Loader Class Initialized
INFO - 2017-03-10 01:49:13 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:13 --> Controller Class Initialized
INFO - 2017-03-10 01:49:13 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:13 --> Helper loaded: url_helper
INFO - 2017-03-10 01:49:13 --> Helper loaded: download_helper
INFO - 2017-03-10 01:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:13 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:13 --> Total execution time: 0.0639
INFO - 2017-03-10 01:49:14 --> Config Class Initialized
INFO - 2017-03-10 01:49:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:14 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:14 --> URI Class Initialized
INFO - 2017-03-10 01:49:14 --> Router Class Initialized
INFO - 2017-03-10 01:49:14 --> Output Class Initialized
INFO - 2017-03-10 01:49:14 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:14 --> Input Class Initialized
INFO - 2017-03-10 01:49:14 --> Language Class Initialized
INFO - 2017-03-10 01:49:14 --> Loader Class Initialized
INFO - 2017-03-10 01:49:14 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:14 --> Controller Class Initialized
INFO - 2017-03-10 01:49:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:14 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:14 --> Total execution time: 0.0152
INFO - 2017-03-10 01:49:22 --> Config Class Initialized
INFO - 2017-03-10 01:49:22 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:22 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:22 --> URI Class Initialized
INFO - 2017-03-10 01:49:22 --> Router Class Initialized
INFO - 2017-03-10 01:49:22 --> Output Class Initialized
INFO - 2017-03-10 01:49:22 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:22 --> Input Class Initialized
INFO - 2017-03-10 01:49:22 --> Language Class Initialized
INFO - 2017-03-10 01:49:22 --> Loader Class Initialized
INFO - 2017-03-10 01:49:22 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:22 --> Controller Class Initialized
INFO - 2017-03-10 01:49:22 --> Helper loaded: date_helper
INFO - 2017-03-10 01:49:22 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:23 --> Helper loaded: form_helper
INFO - 2017-03-10 01:49:23 --> Form Validation Class Initialized
INFO - 2017-03-10 01:49:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:23 --> Total execution time: 0.2342
INFO - 2017-03-10 01:49:29 --> Config Class Initialized
INFO - 2017-03-10 01:49:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:29 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:29 --> URI Class Initialized
INFO - 2017-03-10 01:49:29 --> Router Class Initialized
INFO - 2017-03-10 01:49:29 --> Output Class Initialized
INFO - 2017-03-10 01:49:29 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:29 --> Input Class Initialized
INFO - 2017-03-10 01:49:29 --> Language Class Initialized
INFO - 2017-03-10 01:49:29 --> Loader Class Initialized
INFO - 2017-03-10 01:49:29 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:30 --> Controller Class Initialized
INFO - 2017-03-10 01:49:30 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:30 --> Helper loaded: url_helper
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:30 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:30 --> Total execution time: 1.7234
INFO - 2017-03-10 01:49:30 --> Config Class Initialized
INFO - 2017-03-10 01:49:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:30 --> URI Class Initialized
INFO - 2017-03-10 01:49:30 --> Router Class Initialized
INFO - 2017-03-10 01:49:30 --> Output Class Initialized
INFO - 2017-03-10 01:49:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:30 --> Input Class Initialized
INFO - 2017-03-10 01:49:30 --> Language Class Initialized
INFO - 2017-03-10 01:49:30 --> Loader Class Initialized
INFO - 2017-03-10 01:49:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:30 --> Controller Class Initialized
INFO - 2017-03-10 01:49:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:31 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:31 --> Total execution time: 0.2776
INFO - 2017-03-10 01:49:32 --> Config Class Initialized
INFO - 2017-03-10 01:49:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:32 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:32 --> URI Class Initialized
INFO - 2017-03-10 01:49:32 --> Router Class Initialized
INFO - 2017-03-10 01:49:32 --> Output Class Initialized
INFO - 2017-03-10 01:49:32 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:33 --> Input Class Initialized
INFO - 2017-03-10 01:49:33 --> Language Class Initialized
INFO - 2017-03-10 01:49:33 --> Loader Class Initialized
INFO - 2017-03-10 01:49:33 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:33 --> Controller Class Initialized
INFO - 2017-03-10 01:49:33 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:33 --> Helper loaded: url_helper
INFO - 2017-03-10 01:49:33 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:33 --> Total execution time: 1.1780
INFO - 2017-03-10 01:49:34 --> Config Class Initialized
INFO - 2017-03-10 01:49:34 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:34 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:34 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:34 --> URI Class Initialized
INFO - 2017-03-10 01:49:34 --> Router Class Initialized
INFO - 2017-03-10 01:49:34 --> Output Class Initialized
INFO - 2017-03-10 01:49:34 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:34 --> Input Class Initialized
INFO - 2017-03-10 01:49:34 --> Language Class Initialized
INFO - 2017-03-10 01:49:34 --> Loader Class Initialized
INFO - 2017-03-10 01:49:35 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:35 --> Controller Class Initialized
INFO - 2017-03-10 01:49:35 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:35 --> Helper loaded: url_helper
INFO - 2017-03-10 01:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-10 01:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-10 01:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-10 01:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:35 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:35 --> Total execution time: 1.3259
INFO - 2017-03-10 01:49:37 --> Config Class Initialized
INFO - 2017-03-10 01:49:37 --> Hooks Class Initialized
INFO - 2017-03-10 01:49:37 --> Config Class Initialized
INFO - 2017-03-10 01:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:37 --> UTF-8 Support Enabled
DEBUG - 2017-03-10 01:49:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:37 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:37 --> URI Class Initialized
INFO - 2017-03-10 01:49:37 --> URI Class Initialized
INFO - 2017-03-10 01:49:37 --> Router Class Initialized
INFO - 2017-03-10 01:49:37 --> Router Class Initialized
INFO - 2017-03-10 01:49:37 --> Output Class Initialized
INFO - 2017-03-10 01:49:37 --> Output Class Initialized
INFO - 2017-03-10 01:49:37 --> Security Class Initialized
INFO - 2017-03-10 01:49:38 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:38 --> Input Class Initialized
DEBUG - 2017-03-10 01:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:38 --> Language Class Initialized
INFO - 2017-03-10 01:49:38 --> Input Class Initialized
INFO - 2017-03-10 01:49:38 --> Language Class Initialized
INFO - 2017-03-10 01:49:38 --> Loader Class Initialized
INFO - 2017-03-10 01:49:38 --> Loader Class Initialized
INFO - 2017-03-10 01:49:38 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:38 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:38 --> Controller Class Initialized
INFO - 2017-03-10 01:49:38 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:38 --> Helper loaded: url_helper
INFO - 2017-03-10 01:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:38 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:38 --> Total execution time: 1.1246
INFO - 2017-03-10 01:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:38 --> Controller Class Initialized
INFO - 2017-03-10 01:49:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:39 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:39 --> Total execution time: 1.8528
INFO - 2017-03-10 01:49:40 --> Config Class Initialized
INFO - 2017-03-10 01:49:40 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:49:40 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:49:40 --> Utf8 Class Initialized
INFO - 2017-03-10 01:49:40 --> URI Class Initialized
INFO - 2017-03-10 01:49:40 --> Router Class Initialized
INFO - 2017-03-10 01:49:40 --> Output Class Initialized
INFO - 2017-03-10 01:49:40 --> Security Class Initialized
DEBUG - 2017-03-10 01:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:49:40 --> Input Class Initialized
INFO - 2017-03-10 01:49:40 --> Language Class Initialized
INFO - 2017-03-10 01:49:40 --> Loader Class Initialized
INFO - 2017-03-10 01:49:41 --> Database Driver Class Initialized
INFO - 2017-03-10 01:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:49:41 --> Controller Class Initialized
INFO - 2017-03-10 01:49:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:49:41 --> Final output sent to browser
DEBUG - 2017-03-10 01:49:41 --> Total execution time: 1.2188
INFO - 2017-03-10 01:50:11 --> Config Class Initialized
INFO - 2017-03-10 01:50:11 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:50:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:50:11 --> Utf8 Class Initialized
INFO - 2017-03-10 01:50:11 --> URI Class Initialized
INFO - 2017-03-10 01:50:11 --> Router Class Initialized
INFO - 2017-03-10 01:50:11 --> Output Class Initialized
INFO - 2017-03-10 01:50:11 --> Security Class Initialized
DEBUG - 2017-03-10 01:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:50:11 --> Input Class Initialized
INFO - 2017-03-10 01:50:11 --> Language Class Initialized
INFO - 2017-03-10 01:50:11 --> Loader Class Initialized
INFO - 2017-03-10 01:50:11 --> Database Driver Class Initialized
INFO - 2017-03-10 01:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:50:12 --> Controller Class Initialized
INFO - 2017-03-10 01:50:12 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:50:12 --> Helper loaded: url_helper
INFO - 2017-03-10 01:50:12 --> Helper loaded: download_helper
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:50:12 --> Final output sent to browser
DEBUG - 2017-03-10 01:50:12 --> Total execution time: 1.1704
INFO - 2017-03-10 01:50:12 --> Config Class Initialized
INFO - 2017-03-10 01:50:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:50:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:50:12 --> Utf8 Class Initialized
INFO - 2017-03-10 01:50:12 --> URI Class Initialized
INFO - 2017-03-10 01:50:12 --> Router Class Initialized
INFO - 2017-03-10 01:50:12 --> Output Class Initialized
INFO - 2017-03-10 01:50:12 --> Security Class Initialized
DEBUG - 2017-03-10 01:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:50:12 --> Input Class Initialized
INFO - 2017-03-10 01:50:12 --> Language Class Initialized
INFO - 2017-03-10 01:50:12 --> Loader Class Initialized
INFO - 2017-03-10 01:50:12 --> Database Driver Class Initialized
INFO - 2017-03-10 01:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:50:12 --> Controller Class Initialized
INFO - 2017-03-10 01:50:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:50:12 --> Final output sent to browser
DEBUG - 2017-03-10 01:50:12 --> Total execution time: 0.2578
INFO - 2017-03-10 01:50:18 --> Config Class Initialized
INFO - 2017-03-10 01:50:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:50:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:50:18 --> Utf8 Class Initialized
INFO - 2017-03-10 01:50:18 --> URI Class Initialized
INFO - 2017-03-10 01:50:18 --> Router Class Initialized
INFO - 2017-03-10 01:50:18 --> Output Class Initialized
INFO - 2017-03-10 01:50:18 --> Security Class Initialized
DEBUG - 2017-03-10 01:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:50:18 --> Input Class Initialized
INFO - 2017-03-10 01:50:18 --> Language Class Initialized
INFO - 2017-03-10 01:50:18 --> Loader Class Initialized
INFO - 2017-03-10 01:50:18 --> Database Driver Class Initialized
INFO - 2017-03-10 01:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:50:18 --> Controller Class Initialized
INFO - 2017-03-10 01:50:18 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:50:18 --> Helper loaded: url_helper
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:50:18 --> Final output sent to browser
DEBUG - 2017-03-10 01:50:18 --> Total execution time: 0.0311
INFO - 2017-03-10 01:50:18 --> Config Class Initialized
INFO - 2017-03-10 01:50:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:50:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:50:18 --> Utf8 Class Initialized
INFO - 2017-03-10 01:50:18 --> URI Class Initialized
INFO - 2017-03-10 01:50:18 --> Router Class Initialized
INFO - 2017-03-10 01:50:18 --> Output Class Initialized
INFO - 2017-03-10 01:50:18 --> Security Class Initialized
DEBUG - 2017-03-10 01:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:50:18 --> Input Class Initialized
INFO - 2017-03-10 01:50:18 --> Language Class Initialized
INFO - 2017-03-10 01:50:18 --> Loader Class Initialized
INFO - 2017-03-10 01:50:18 --> Database Driver Class Initialized
INFO - 2017-03-10 01:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:50:18 --> Controller Class Initialized
INFO - 2017-03-10 01:50:18 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:50:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:50:18 --> Final output sent to browser
DEBUG - 2017-03-10 01:50:18 --> Total execution time: 0.0166
INFO - 2017-03-10 01:51:03 --> Config Class Initialized
INFO - 2017-03-10 01:51:03 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:03 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:03 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:03 --> URI Class Initialized
INFO - 2017-03-10 01:51:03 --> Router Class Initialized
INFO - 2017-03-10 01:51:03 --> Output Class Initialized
INFO - 2017-03-10 01:51:03 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:04 --> Input Class Initialized
INFO - 2017-03-10 01:51:04 --> Language Class Initialized
INFO - 2017-03-10 01:51:04 --> Loader Class Initialized
INFO - 2017-03-10 01:51:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:04 --> Controller Class Initialized
INFO - 2017-03-10 01:51:04 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:04 --> Helper loaded: url_helper
INFO - 2017-03-10 01:51:04 --> Helper loaded: download_helper
INFO - 2017-03-10 01:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:04 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:04 --> Total execution time: 1.1262
INFO - 2017-03-10 01:51:05 --> Config Class Initialized
INFO - 2017-03-10 01:51:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:05 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:05 --> URI Class Initialized
INFO - 2017-03-10 01:51:05 --> Router Class Initialized
INFO - 2017-03-10 01:51:05 --> Output Class Initialized
INFO - 2017-03-10 01:51:05 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:05 --> Input Class Initialized
INFO - 2017-03-10 01:51:05 --> Language Class Initialized
INFO - 2017-03-10 01:51:05 --> Loader Class Initialized
INFO - 2017-03-10 01:51:05 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:05 --> Controller Class Initialized
INFO - 2017-03-10 01:51:05 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:05 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:05 --> Total execution time: 0.2587
INFO - 2017-03-10 01:51:05 --> Config Class Initialized
INFO - 2017-03-10 01:51:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:05 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:05 --> URI Class Initialized
INFO - 2017-03-10 01:51:05 --> Router Class Initialized
INFO - 2017-03-10 01:51:05 --> Output Class Initialized
INFO - 2017-03-10 01:51:05 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:05 --> Input Class Initialized
INFO - 2017-03-10 01:51:05 --> Language Class Initialized
INFO - 2017-03-10 01:51:05 --> Loader Class Initialized
INFO - 2017-03-10 01:51:05 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:05 --> Controller Class Initialized
INFO - 2017-03-10 01:51:05 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:05 --> Helper loaded: form_helper
INFO - 2017-03-10 01:51:05 --> Form Validation Class Initialized
INFO - 2017-03-10 01:51:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:51:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-10 01:51:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:51:05 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:05 --> Total execution time: 0.1968
INFO - 2017-03-10 01:51:06 --> Config Class Initialized
INFO - 2017-03-10 01:51:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:06 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:06 --> URI Class Initialized
INFO - 2017-03-10 01:51:06 --> Router Class Initialized
INFO - 2017-03-10 01:51:06 --> Output Class Initialized
INFO - 2017-03-10 01:51:06 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:06 --> Input Class Initialized
INFO - 2017-03-10 01:51:06 --> Language Class Initialized
INFO - 2017-03-10 01:51:06 --> Loader Class Initialized
INFO - 2017-03-10 01:51:06 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:06 --> Controller Class Initialized
INFO - 2017-03-10 01:51:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:06 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:06 --> Total execution time: 0.0248
INFO - 2017-03-10 01:51:10 --> Config Class Initialized
INFO - 2017-03-10 01:51:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:10 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:10 --> URI Class Initialized
INFO - 2017-03-10 01:51:10 --> Router Class Initialized
INFO - 2017-03-10 01:51:10 --> Output Class Initialized
INFO - 2017-03-10 01:51:10 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:10 --> Input Class Initialized
INFO - 2017-03-10 01:51:10 --> Language Class Initialized
INFO - 2017-03-10 01:51:10 --> Loader Class Initialized
INFO - 2017-03-10 01:51:10 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:10 --> Controller Class Initialized
INFO - 2017-03-10 01:51:10 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:10 --> Helper loaded: url_helper
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:10 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:10 --> Total execution time: 0.0418
INFO - 2017-03-10 01:51:10 --> Config Class Initialized
INFO - 2017-03-10 01:51:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:10 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:10 --> URI Class Initialized
INFO - 2017-03-10 01:51:10 --> Router Class Initialized
INFO - 2017-03-10 01:51:10 --> Output Class Initialized
INFO - 2017-03-10 01:51:10 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:10 --> Input Class Initialized
INFO - 2017-03-10 01:51:10 --> Language Class Initialized
INFO - 2017-03-10 01:51:10 --> Loader Class Initialized
INFO - 2017-03-10 01:51:10 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:10 --> Controller Class Initialized
INFO - 2017-03-10 01:51:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:10 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:10 --> Total execution time: 0.0160
INFO - 2017-03-10 01:51:13 --> Config Class Initialized
INFO - 2017-03-10 01:51:13 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:13 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:13 --> URI Class Initialized
INFO - 2017-03-10 01:51:13 --> Router Class Initialized
INFO - 2017-03-10 01:51:13 --> Output Class Initialized
INFO - 2017-03-10 01:51:13 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:13 --> Input Class Initialized
INFO - 2017-03-10 01:51:13 --> Language Class Initialized
INFO - 2017-03-10 01:51:13 --> Loader Class Initialized
INFO - 2017-03-10 01:51:13 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:13 --> Controller Class Initialized
INFO - 2017-03-10 01:51:14 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:14 --> Helper loaded: url_helper
INFO - 2017-03-10 01:51:14 --> Helper loaded: download_helper
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:14 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:14 --> Total execution time: 0.2808
INFO - 2017-03-10 01:51:14 --> Config Class Initialized
INFO - 2017-03-10 01:51:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:14 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:14 --> URI Class Initialized
INFO - 2017-03-10 01:51:14 --> Router Class Initialized
INFO - 2017-03-10 01:51:14 --> Output Class Initialized
INFO - 2017-03-10 01:51:14 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:14 --> Input Class Initialized
INFO - 2017-03-10 01:51:14 --> Language Class Initialized
INFO - 2017-03-10 01:51:14 --> Loader Class Initialized
INFO - 2017-03-10 01:51:14 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:14 --> Controller Class Initialized
INFO - 2017-03-10 01:51:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:14 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:14 --> Total execution time: 0.2075
INFO - 2017-03-10 01:51:15 --> Config Class Initialized
INFO - 2017-03-10 01:51:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:15 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:15 --> URI Class Initialized
INFO - 2017-03-10 01:51:15 --> Router Class Initialized
INFO - 2017-03-10 01:51:15 --> Output Class Initialized
INFO - 2017-03-10 01:51:15 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:15 --> Input Class Initialized
INFO - 2017-03-10 01:51:15 --> Language Class Initialized
INFO - 2017-03-10 01:51:15 --> Loader Class Initialized
INFO - 2017-03-10 01:51:16 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:16 --> Controller Class Initialized
INFO - 2017-03-10 01:51:16 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:16 --> Helper loaded: url_helper
INFO - 2017-03-10 01:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:16 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:16 --> Total execution time: 1.0778
INFO - 2017-03-10 01:51:17 --> Config Class Initialized
INFO - 2017-03-10 01:51:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:17 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:17 --> URI Class Initialized
INFO - 2017-03-10 01:51:17 --> Router Class Initialized
INFO - 2017-03-10 01:51:17 --> Output Class Initialized
INFO - 2017-03-10 01:51:17 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:18 --> Input Class Initialized
INFO - 2017-03-10 01:51:18 --> Language Class Initialized
INFO - 2017-03-10 01:51:18 --> Loader Class Initialized
INFO - 2017-03-10 01:51:18 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:18 --> Controller Class Initialized
INFO - 2017-03-10 01:51:18 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:18 --> Helper loaded: url_helper
INFO - 2017-03-10 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:18 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:18 --> Total execution time: 1.1018
INFO - 2017-03-10 01:51:20 --> Config Class Initialized
INFO - 2017-03-10 01:51:20 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:20 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:20 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:20 --> URI Class Initialized
INFO - 2017-03-10 01:51:20 --> Router Class Initialized
INFO - 2017-03-10 01:51:20 --> Output Class Initialized
INFO - 2017-03-10 01:51:21 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:21 --> Input Class Initialized
INFO - 2017-03-10 01:51:21 --> Language Class Initialized
INFO - 2017-03-10 01:51:21 --> Loader Class Initialized
INFO - 2017-03-10 01:51:21 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:21 --> Controller Class Initialized
INFO - 2017-03-10 01:51:21 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:22 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:22 --> Total execution time: 1.2109
INFO - 2017-03-10 01:51:35 --> Config Class Initialized
INFO - 2017-03-10 01:51:35 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:35 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:35 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:35 --> URI Class Initialized
INFO - 2017-03-10 01:51:35 --> Router Class Initialized
INFO - 2017-03-10 01:51:35 --> Output Class Initialized
INFO - 2017-03-10 01:51:35 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:35 --> Input Class Initialized
INFO - 2017-03-10 01:51:35 --> Language Class Initialized
INFO - 2017-03-10 01:51:35 --> Loader Class Initialized
INFO - 2017-03-10 01:51:35 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:36 --> Controller Class Initialized
INFO - 2017-03-10 01:51:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:36 --> Helper loaded: form_helper
INFO - 2017-03-10 01:51:36 --> Form Validation Class Initialized
INFO - 2017-03-10 01:51:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-10 01:51:39 --> Config Class Initialized
INFO - 2017-03-10 01:51:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:39 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:40 --> URI Class Initialized
INFO - 2017-03-10 01:51:40 --> Router Class Initialized
INFO - 2017-03-10 01:51:40 --> Output Class Initialized
INFO - 2017-03-10 01:51:40 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:40 --> Input Class Initialized
INFO - 2017-03-10 01:51:40 --> Language Class Initialized
INFO - 2017-03-10 01:51:40 --> Loader Class Initialized
INFO - 2017-03-10 01:51:40 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:41 --> Controller Class Initialized
INFO - 2017-03-10 01:51:41 --> Helper loaded: date_helper
INFO - 2017-03-10 01:51:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:41 --> Config Class Initialized
INFO - 2017-03-10 01:51:41 --> Helper loaded: form_helper
INFO - 2017-03-10 01:51:41 --> Hooks Class Initialized
INFO - 2017-03-10 01:51:41 --> Form Validation Class Initialized
DEBUG - 2017-03-10 01:51:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:51:41 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:41 --> URI Class Initialized
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:51:41 --> Router Class Initialized
INFO - 2017-03-10 01:51:41 --> Output Class Initialized
INFO - 2017-03-10 01:51:41 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:41 --> Input Class Initialized
INFO - 2017-03-10 01:51:41 --> Language Class Initialized
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:51:41 --> Loader Class Initialized
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:51:41 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:41 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:41 --> Total execution time: 2.9306
INFO - 2017-03-10 01:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:41 --> Controller Class Initialized
INFO - 2017-03-10 01:51:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:41 --> Config Class Initialized
INFO - 2017-03-10 01:51:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:41 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:41 --> URI Class Initialized
INFO - 2017-03-10 01:51:41 --> Router Class Initialized
INFO - 2017-03-10 01:51:41 --> Output Class Initialized
INFO - 2017-03-10 01:51:41 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:41 --> Input Class Initialized
INFO - 2017-03-10 01:51:41 --> Language Class Initialized
INFO - 2017-03-10 01:51:41 --> Loader Class Initialized
INFO - 2017-03-10 01:51:41 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:41 --> Controller Class Initialized
INFO - 2017-03-10 01:51:41 --> Helper loaded: date_helper
INFO - 2017-03-10 01:51:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:41 --> Helper loaded: form_helper
INFO - 2017-03-10 01:51:41 --> Form Validation Class Initialized
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:51:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:51:41 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:41 --> Total execution time: 0.0222
INFO - 2017-03-10 01:51:42 --> Config Class Initialized
INFO - 2017-03-10 01:51:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:42 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:42 --> URI Class Initialized
INFO - 2017-03-10 01:51:42 --> Router Class Initialized
INFO - 2017-03-10 01:51:42 --> Output Class Initialized
INFO - 2017-03-10 01:51:42 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:42 --> Input Class Initialized
INFO - 2017-03-10 01:51:42 --> Language Class Initialized
INFO - 2017-03-10 01:51:42 --> Loader Class Initialized
INFO - 2017-03-10 01:51:42 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:42 --> Controller Class Initialized
INFO - 2017-03-10 01:51:42 --> Helper loaded: date_helper
INFO - 2017-03-10 01:51:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:42 --> Helper loaded: form_helper
INFO - 2017-03-10 01:51:42 --> Form Validation Class Initialized
INFO - 2017-03-10 01:51:42 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:42 --> Total execution time: 0.0156
INFO - 2017-03-10 01:51:42 --> Config Class Initialized
INFO - 2017-03-10 01:51:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:42 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:42 --> URI Class Initialized
INFO - 2017-03-10 01:51:42 --> Router Class Initialized
INFO - 2017-03-10 01:51:42 --> Output Class Initialized
INFO - 2017-03-10 01:51:42 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:42 --> Input Class Initialized
INFO - 2017-03-10 01:51:42 --> Language Class Initialized
INFO - 2017-03-10 01:51:42 --> Loader Class Initialized
INFO - 2017-03-10 01:51:42 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:42 --> Controller Class Initialized
INFO - 2017-03-10 01:51:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:43 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:43 --> Total execution time: 0.2970
INFO - 2017-03-10 01:51:54 --> Config Class Initialized
INFO - 2017-03-10 01:51:54 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:54 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:54 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:54 --> URI Class Initialized
DEBUG - 2017-03-10 01:51:54 --> No URI present. Default controller set.
INFO - 2017-03-10 01:51:54 --> Router Class Initialized
INFO - 2017-03-10 01:51:54 --> Output Class Initialized
INFO - 2017-03-10 01:51:54 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:54 --> Input Class Initialized
INFO - 2017-03-10 01:51:54 --> Language Class Initialized
INFO - 2017-03-10 01:51:54 --> Loader Class Initialized
INFO - 2017-03-10 01:51:55 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:55 --> Controller Class Initialized
INFO - 2017-03-10 01:51:55 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:55 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:55 --> Total execution time: 1.2408
INFO - 2017-03-10 01:51:57 --> Config Class Initialized
INFO - 2017-03-10 01:51:57 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:51:57 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:51:57 --> Utf8 Class Initialized
INFO - 2017-03-10 01:51:57 --> URI Class Initialized
INFO - 2017-03-10 01:51:57 --> Router Class Initialized
INFO - 2017-03-10 01:51:57 --> Output Class Initialized
INFO - 2017-03-10 01:51:57 --> Security Class Initialized
DEBUG - 2017-03-10 01:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:51:57 --> Input Class Initialized
INFO - 2017-03-10 01:51:57 --> Language Class Initialized
INFO - 2017-03-10 01:51:57 --> Loader Class Initialized
INFO - 2017-03-10 01:51:57 --> Database Driver Class Initialized
INFO - 2017-03-10 01:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:51:57 --> Controller Class Initialized
INFO - 2017-03-10 01:51:57 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:51:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:51:57 --> Final output sent to browser
DEBUG - 2017-03-10 01:51:57 --> Total execution time: 0.0139
INFO - 2017-03-10 01:52:04 --> Config Class Initialized
INFO - 2017-03-10 01:52:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:04 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:04 --> URI Class Initialized
INFO - 2017-03-10 01:52:04 --> Router Class Initialized
INFO - 2017-03-10 01:52:04 --> Output Class Initialized
INFO - 2017-03-10 01:52:04 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:04 --> Input Class Initialized
INFO - 2017-03-10 01:52:04 --> Language Class Initialized
INFO - 2017-03-10 01:52:04 --> Loader Class Initialized
INFO - 2017-03-10 01:52:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:04 --> Controller Class Initialized
INFO - 2017-03-10 01:52:04 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:04 --> Helper loaded: url_helper
INFO - 2017-03-10 01:52:04 --> Helper loaded: download_helper
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:04 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:04 --> Total execution time: 0.3020
INFO - 2017-03-10 01:52:04 --> Config Class Initialized
INFO - 2017-03-10 01:52:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:04 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:04 --> URI Class Initialized
INFO - 2017-03-10 01:52:04 --> Router Class Initialized
INFO - 2017-03-10 01:52:04 --> Output Class Initialized
INFO - 2017-03-10 01:52:04 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:04 --> Input Class Initialized
INFO - 2017-03-10 01:52:04 --> Language Class Initialized
INFO - 2017-03-10 01:52:04 --> Loader Class Initialized
INFO - 2017-03-10 01:52:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:04 --> Controller Class Initialized
INFO - 2017-03-10 01:52:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:04 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:04 --> Total execution time: 0.0309
INFO - 2017-03-10 01:52:05 --> Config Class Initialized
INFO - 2017-03-10 01:52:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:05 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:05 --> URI Class Initialized
INFO - 2017-03-10 01:52:05 --> Router Class Initialized
INFO - 2017-03-10 01:52:05 --> Output Class Initialized
INFO - 2017-03-10 01:52:05 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:05 --> Input Class Initialized
INFO - 2017-03-10 01:52:05 --> Language Class Initialized
INFO - 2017-03-10 01:52:05 --> Loader Class Initialized
INFO - 2017-03-10 01:52:05 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:05 --> Controller Class Initialized
INFO - 2017-03-10 01:52:05 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:05 --> Helper loaded: url_helper
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:05 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:05 --> Total execution time: 0.0554
INFO - 2017-03-10 01:52:05 --> Config Class Initialized
INFO - 2017-03-10 01:52:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:05 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:05 --> URI Class Initialized
INFO - 2017-03-10 01:52:05 --> Router Class Initialized
INFO - 2017-03-10 01:52:05 --> Output Class Initialized
INFO - 2017-03-10 01:52:05 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:05 --> Input Class Initialized
INFO - 2017-03-10 01:52:05 --> Language Class Initialized
INFO - 2017-03-10 01:52:05 --> Loader Class Initialized
INFO - 2017-03-10 01:52:05 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:05 --> Controller Class Initialized
INFO - 2017-03-10 01:52:05 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:05 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:05 --> Total execution time: 0.0150
INFO - 2017-03-10 01:52:06 --> Config Class Initialized
INFO - 2017-03-10 01:52:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:06 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:06 --> URI Class Initialized
INFO - 2017-03-10 01:52:06 --> Router Class Initialized
INFO - 2017-03-10 01:52:06 --> Output Class Initialized
INFO - 2017-03-10 01:52:06 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:06 --> Input Class Initialized
INFO - 2017-03-10 01:52:06 --> Language Class Initialized
INFO - 2017-03-10 01:52:06 --> Loader Class Initialized
INFO - 2017-03-10 01:52:06 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:06 --> Controller Class Initialized
INFO - 2017-03-10 01:52:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:07 --> Config Class Initialized
INFO - 2017-03-10 01:52:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:07 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:07 --> URI Class Initialized
INFO - 2017-03-10 01:52:07 --> Router Class Initialized
INFO - 2017-03-10 01:52:07 --> Output Class Initialized
INFO - 2017-03-10 01:52:07 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:07 --> Input Class Initialized
INFO - 2017-03-10 01:52:07 --> Language Class Initialized
INFO - 2017-03-10 01:52:07 --> Loader Class Initialized
INFO - 2017-03-10 01:52:07 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:07 --> Controller Class Initialized
INFO - 2017-03-10 01:52:07 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:07 --> Helper loaded: url_helper
INFO - 2017-03-10 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:07 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:07 --> Total execution time: 0.0149
INFO - 2017-03-10 01:52:08 --> Config Class Initialized
INFO - 2017-03-10 01:52:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:08 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:08 --> URI Class Initialized
INFO - 2017-03-10 01:52:08 --> Router Class Initialized
INFO - 2017-03-10 01:52:08 --> Output Class Initialized
INFO - 2017-03-10 01:52:08 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:08 --> Input Class Initialized
INFO - 2017-03-10 01:52:08 --> Language Class Initialized
INFO - 2017-03-10 01:52:08 --> Loader Class Initialized
INFO - 2017-03-10 01:52:08 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:08 --> Controller Class Initialized
INFO - 2017-03-10 01:52:08 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:08 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:08 --> Total execution time: 0.0146
INFO - 2017-03-10 01:52:11 --> Config Class Initialized
INFO - 2017-03-10 01:52:11 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:11 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:11 --> URI Class Initialized
INFO - 2017-03-10 01:52:11 --> Router Class Initialized
INFO - 2017-03-10 01:52:11 --> Output Class Initialized
INFO - 2017-03-10 01:52:11 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:11 --> Input Class Initialized
INFO - 2017-03-10 01:52:11 --> Language Class Initialized
INFO - 2017-03-10 01:52:11 --> Loader Class Initialized
INFO - 2017-03-10 01:52:11 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:11 --> Controller Class Initialized
INFO - 2017-03-10 01:52:11 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:11 --> Helper loaded: url_helper
INFO - 2017-03-10 01:52:11 --> Helper loaded: download_helper
INFO - 2017-03-10 01:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:11 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:11 --> Total execution time: 0.0208
INFO - 2017-03-10 01:52:12 --> Config Class Initialized
INFO - 2017-03-10 01:52:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:12 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:12 --> URI Class Initialized
INFO - 2017-03-10 01:52:12 --> Router Class Initialized
INFO - 2017-03-10 01:52:12 --> Output Class Initialized
INFO - 2017-03-10 01:52:12 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:12 --> Input Class Initialized
INFO - 2017-03-10 01:52:12 --> Language Class Initialized
INFO - 2017-03-10 01:52:12 --> Loader Class Initialized
INFO - 2017-03-10 01:52:12 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:12 --> Controller Class Initialized
INFO - 2017-03-10 01:52:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:52:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:52:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:12 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:12 --> Total execution time: 0.0149
INFO - 2017-03-10 01:52:20 --> Config Class Initialized
INFO - 2017-03-10 01:52:20 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:20 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:20 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:20 --> URI Class Initialized
INFO - 2017-03-10 01:52:20 --> Router Class Initialized
INFO - 2017-03-10 01:52:20 --> Output Class Initialized
INFO - 2017-03-10 01:52:20 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:20 --> Input Class Initialized
INFO - 2017-03-10 01:52:20 --> Language Class Initialized
INFO - 2017-03-10 01:52:20 --> Loader Class Initialized
INFO - 2017-03-10 01:52:20 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:20 --> Controller Class Initialized
INFO - 2017-03-10 01:52:20 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:20 --> Helper loaded: url_helper
INFO - 2017-03-10 01:52:20 --> Helper loaded: download_helper
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:20 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:20 --> Total execution time: 0.0428
INFO - 2017-03-10 01:52:20 --> Config Class Initialized
INFO - 2017-03-10 01:52:20 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:20 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:20 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:20 --> URI Class Initialized
INFO - 2017-03-10 01:52:20 --> Router Class Initialized
INFO - 2017-03-10 01:52:20 --> Output Class Initialized
INFO - 2017-03-10 01:52:20 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:20 --> Input Class Initialized
INFO - 2017-03-10 01:52:20 --> Language Class Initialized
INFO - 2017-03-10 01:52:20 --> Loader Class Initialized
INFO - 2017-03-10 01:52:20 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:20 --> Controller Class Initialized
INFO - 2017-03-10 01:52:20 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:52:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:20 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:20 --> Total execution time: 0.0142
INFO - 2017-03-10 01:52:21 --> Config Class Initialized
INFO - 2017-03-10 01:52:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:21 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:21 --> URI Class Initialized
INFO - 2017-03-10 01:52:21 --> Router Class Initialized
INFO - 2017-03-10 01:52:21 --> Output Class Initialized
INFO - 2017-03-10 01:52:21 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:21 --> Input Class Initialized
INFO - 2017-03-10 01:52:21 --> Language Class Initialized
INFO - 2017-03-10 01:52:21 --> Loader Class Initialized
INFO - 2017-03-10 01:52:21 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:21 --> Controller Class Initialized
INFO - 2017-03-10 01:52:21 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:21 --> Helper loaded: url_helper
INFO - 2017-03-10 01:52:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:52:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:52:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:52:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:21 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:21 --> Total execution time: 0.0154
INFO - 2017-03-10 01:52:21 --> Config Class Initialized
INFO - 2017-03-10 01:52:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:21 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:21 --> URI Class Initialized
INFO - 2017-03-10 01:52:22 --> Router Class Initialized
INFO - 2017-03-10 01:52:22 --> Output Class Initialized
INFO - 2017-03-10 01:52:22 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:22 --> Input Class Initialized
INFO - 2017-03-10 01:52:22 --> Language Class Initialized
INFO - 2017-03-10 01:52:22 --> Loader Class Initialized
INFO - 2017-03-10 01:52:22 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:22 --> Controller Class Initialized
INFO - 2017-03-10 01:52:22 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:52:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:52:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:22 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:22 --> Total execution time: 0.0141
INFO - 2017-03-10 01:52:30 --> Config Class Initialized
INFO - 2017-03-10 01:52:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:30 --> URI Class Initialized
INFO - 2017-03-10 01:52:30 --> Router Class Initialized
INFO - 2017-03-10 01:52:30 --> Output Class Initialized
INFO - 2017-03-10 01:52:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:30 --> Input Class Initialized
INFO - 2017-03-10 01:52:30 --> Language Class Initialized
INFO - 2017-03-10 01:52:30 --> Loader Class Initialized
INFO - 2017-03-10 01:52:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:30 --> Controller Class Initialized
INFO - 2017-03-10 01:52:30 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:30 --> Helper loaded: url_helper
INFO - 2017-03-10 01:52:30 --> Helper loaded: download_helper
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:30 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:30 --> Total execution time: 0.0293
INFO - 2017-03-10 01:52:30 --> Config Class Initialized
INFO - 2017-03-10 01:52:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:30 --> URI Class Initialized
INFO - 2017-03-10 01:52:30 --> Router Class Initialized
INFO - 2017-03-10 01:52:30 --> Output Class Initialized
INFO - 2017-03-10 01:52:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:30 --> Input Class Initialized
INFO - 2017-03-10 01:52:30 --> Language Class Initialized
INFO - 2017-03-10 01:52:30 --> Loader Class Initialized
INFO - 2017-03-10 01:52:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:30 --> Controller Class Initialized
INFO - 2017-03-10 01:52:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:52:30 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:30 --> Total execution time: 0.0146
INFO - 2017-03-10 01:52:41 --> Config Class Initialized
INFO - 2017-03-10 01:52:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:52:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:52:41 --> Utf8 Class Initialized
INFO - 2017-03-10 01:52:41 --> URI Class Initialized
INFO - 2017-03-10 01:52:41 --> Router Class Initialized
INFO - 2017-03-10 01:52:41 --> Output Class Initialized
INFO - 2017-03-10 01:52:41 --> Security Class Initialized
DEBUG - 2017-03-10 01:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:52:41 --> Input Class Initialized
INFO - 2017-03-10 01:52:41 --> Language Class Initialized
INFO - 2017-03-10 01:52:41 --> Loader Class Initialized
INFO - 2017-03-10 01:52:41 --> Database Driver Class Initialized
INFO - 2017-03-10 01:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:52:41 --> Controller Class Initialized
INFO - 2017-03-10 01:52:41 --> Helper loaded: date_helper
INFO - 2017-03-10 01:52:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:52:41 --> Helper loaded: form_helper
INFO - 2017-03-10 01:52:41 --> Form Validation Class Initialized
INFO - 2017-03-10 01:52:41 --> Final output sent to browser
DEBUG - 2017-03-10 01:52:41 --> Total execution time: 0.1574
INFO - 2017-03-10 01:53:49 --> Config Class Initialized
INFO - 2017-03-10 01:53:49 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:53:49 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:53:49 --> Utf8 Class Initialized
INFO - 2017-03-10 01:53:49 --> URI Class Initialized
INFO - 2017-03-10 01:53:49 --> Router Class Initialized
INFO - 2017-03-10 01:53:49 --> Output Class Initialized
INFO - 2017-03-10 01:53:49 --> Security Class Initialized
DEBUG - 2017-03-10 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:53:49 --> Input Class Initialized
INFO - 2017-03-10 01:53:49 --> Language Class Initialized
INFO - 2017-03-10 01:53:49 --> Loader Class Initialized
INFO - 2017-03-10 01:53:49 --> Database Driver Class Initialized
INFO - 2017-03-10 01:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:53:49 --> Controller Class Initialized
INFO - 2017-03-10 01:53:49 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:53:49 --> Config Class Initialized
INFO - 2017-03-10 01:53:49 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:53:49 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:53:49 --> Utf8 Class Initialized
INFO - 2017-03-10 01:53:49 --> URI Class Initialized
INFO - 2017-03-10 01:53:49 --> Router Class Initialized
INFO - 2017-03-10 01:53:49 --> Output Class Initialized
INFO - 2017-03-10 01:53:49 --> Security Class Initialized
DEBUG - 2017-03-10 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:53:49 --> Input Class Initialized
INFO - 2017-03-10 01:53:49 --> Language Class Initialized
INFO - 2017-03-10 01:53:49 --> Loader Class Initialized
INFO - 2017-03-10 01:53:49 --> Database Driver Class Initialized
INFO - 2017-03-10 01:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:53:49 --> Controller Class Initialized
INFO - 2017-03-10 01:53:49 --> Helper loaded: date_helper
INFO - 2017-03-10 01:53:49 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:53:49 --> Helper loaded: form_helper
INFO - 2017-03-10 01:53:49 --> Form Validation Class Initialized
INFO - 2017-03-10 01:53:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:53:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:53:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:53:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:53:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:53:49 --> Final output sent to browser
DEBUG - 2017-03-10 01:53:49 --> Total execution time: 0.1228
INFO - 2017-03-10 01:53:49 --> Config Class Initialized
INFO - 2017-03-10 01:53:49 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:53:49 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:53:49 --> Utf8 Class Initialized
INFO - 2017-03-10 01:53:49 --> URI Class Initialized
INFO - 2017-03-10 01:53:49 --> Router Class Initialized
INFO - 2017-03-10 01:53:49 --> Output Class Initialized
INFO - 2017-03-10 01:53:49 --> Security Class Initialized
DEBUG - 2017-03-10 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:53:49 --> Input Class Initialized
INFO - 2017-03-10 01:53:49 --> Language Class Initialized
INFO - 2017-03-10 01:53:49 --> Loader Class Initialized
INFO - 2017-03-10 01:53:49 --> Database Driver Class Initialized
INFO - 2017-03-10 01:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:53:49 --> Controller Class Initialized
INFO - 2017-03-10 01:53:49 --> Helper loaded: date_helper
INFO - 2017-03-10 01:53:49 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:53:49 --> Helper loaded: form_helper
INFO - 2017-03-10 01:53:49 --> Form Validation Class Initialized
INFO - 2017-03-10 01:53:49 --> Config Class Initialized
INFO - 2017-03-10 01:53:49 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:53:49 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:53:49 --> Utf8 Class Initialized
INFO - 2017-03-10 01:53:49 --> URI Class Initialized
INFO - 2017-03-10 01:53:49 --> Router Class Initialized
INFO - 2017-03-10 01:53:49 --> Output Class Initialized
INFO - 2017-03-10 01:53:49 --> Security Class Initialized
DEBUG - 2017-03-10 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:53:49 --> Input Class Initialized
INFO - 2017-03-10 01:53:49 --> Language Class Initialized
INFO - 2017-03-10 01:53:49 --> Loader Class Initialized
INFO - 2017-03-10 01:53:50 --> Final output sent to browser
DEBUG - 2017-03-10 01:53:50 --> Total execution time: 0.1035
INFO - 2017-03-10 01:53:50 --> Database Driver Class Initialized
INFO - 2017-03-10 01:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:53:50 --> Controller Class Initialized
INFO - 2017-03-10 01:53:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:53:50 --> Final output sent to browser
DEBUG - 2017-03-10 01:53:50 --> Total execution time: 0.0985
INFO - 2017-03-10 01:54:02 --> Config Class Initialized
INFO - 2017-03-10 01:54:02 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:02 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:02 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:02 --> URI Class Initialized
INFO - 2017-03-10 01:54:02 --> Router Class Initialized
INFO - 2017-03-10 01:54:02 --> Output Class Initialized
INFO - 2017-03-10 01:54:02 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:02 --> Input Class Initialized
INFO - 2017-03-10 01:54:02 --> Language Class Initialized
INFO - 2017-03-10 01:54:02 --> Loader Class Initialized
INFO - 2017-03-10 01:54:02 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:02 --> Controller Class Initialized
INFO - 2017-03-10 01:54:02 --> Upload Class Initialized
INFO - 2017-03-10 01:54:02 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:02 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:02 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:02 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:54:02 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:02 --> Total execution time: 0.1521
INFO - 2017-03-10 01:54:02 --> Config Class Initialized
INFO - 2017-03-10 01:54:02 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:02 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:02 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:02 --> URI Class Initialized
INFO - 2017-03-10 01:54:02 --> Router Class Initialized
INFO - 2017-03-10 01:54:02 --> Output Class Initialized
INFO - 2017-03-10 01:54:02 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:02 --> Input Class Initialized
INFO - 2017-03-10 01:54:02 --> Language Class Initialized
INFO - 2017-03-10 01:54:02 --> Loader Class Initialized
INFO - 2017-03-10 01:54:02 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:02 --> Controller Class Initialized
INFO - 2017-03-10 01:54:02 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:54:02 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:02 --> Total execution time: 0.0172
INFO - 2017-03-10 01:54:04 --> Config Class Initialized
INFO - 2017-03-10 01:54:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:04 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:04 --> URI Class Initialized
INFO - 2017-03-10 01:54:04 --> Router Class Initialized
INFO - 2017-03-10 01:54:04 --> Output Class Initialized
INFO - 2017-03-10 01:54:04 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:04 --> Input Class Initialized
INFO - 2017-03-10 01:54:04 --> Language Class Initialized
INFO - 2017-03-10 01:54:04 --> Loader Class Initialized
INFO - 2017-03-10 01:54:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:04 --> Controller Class Initialized
INFO - 2017-03-10 01:54:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:04 --> Config Class Initialized
INFO - 2017-03-10 01:54:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:04 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:04 --> URI Class Initialized
INFO - 2017-03-10 01:54:04 --> Router Class Initialized
INFO - 2017-03-10 01:54:04 --> Output Class Initialized
INFO - 2017-03-10 01:54:04 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:04 --> Input Class Initialized
INFO - 2017-03-10 01:54:04 --> Language Class Initialized
INFO - 2017-03-10 01:54:04 --> Loader Class Initialized
INFO - 2017-03-10 01:54:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:04 --> Controller Class Initialized
INFO - 2017-03-10 01:54:04 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:04 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:04 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:54:04 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:04 --> Total execution time: 0.0156
INFO - 2017-03-10 01:54:04 --> Config Class Initialized
INFO - 2017-03-10 01:54:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:04 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:04 --> URI Class Initialized
INFO - 2017-03-10 01:54:04 --> Router Class Initialized
INFO - 2017-03-10 01:54:04 --> Output Class Initialized
INFO - 2017-03-10 01:54:04 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:04 --> Input Class Initialized
INFO - 2017-03-10 01:54:04 --> Language Class Initialized
INFO - 2017-03-10 01:54:04 --> Loader Class Initialized
INFO - 2017-03-10 01:54:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:04 --> Controller Class Initialized
INFO - 2017-03-10 01:54:04 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:04 --> Config Class Initialized
INFO - 2017-03-10 01:54:04 --> Hooks Class Initialized
INFO - 2017-03-10 01:54:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-10 01:54:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:04 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:04 --> URI Class Initialized
INFO - 2017-03-10 01:54:04 --> Router Class Initialized
INFO - 2017-03-10 01:54:04 --> Output Class Initialized
INFO - 2017-03-10 01:54:04 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:04 --> Input Class Initialized
INFO - 2017-03-10 01:54:04 --> Language Class Initialized
INFO - 2017-03-10 01:54:04 --> Loader Class Initialized
INFO - 2017-03-10 01:54:04 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:04 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:04 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:04 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:04 --> Total execution time: 0.0939
INFO - 2017-03-10 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:04 --> Controller Class Initialized
INFO - 2017-03-10 01:54:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:54:04 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:04 --> Total execution time: 0.0930
INFO - 2017-03-10 01:54:17 --> Config Class Initialized
INFO - 2017-03-10 01:54:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:17 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:17 --> URI Class Initialized
INFO - 2017-03-10 01:54:17 --> Router Class Initialized
INFO - 2017-03-10 01:54:17 --> Output Class Initialized
INFO - 2017-03-10 01:54:17 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:17 --> Input Class Initialized
INFO - 2017-03-10 01:54:17 --> Language Class Initialized
INFO - 2017-03-10 01:54:17 --> Loader Class Initialized
INFO - 2017-03-10 01:54:17 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:17 --> Controller Class Initialized
INFO - 2017-03-10 01:54:17 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:17 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:17 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:54:17 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:17 --> Total execution time: 0.0664
INFO - 2017-03-10 01:54:17 --> Config Class Initialized
INFO - 2017-03-10 01:54:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:17 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:17 --> URI Class Initialized
INFO - 2017-03-10 01:54:17 --> Router Class Initialized
INFO - 2017-03-10 01:54:17 --> Output Class Initialized
INFO - 2017-03-10 01:54:17 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:17 --> Input Class Initialized
INFO - 2017-03-10 01:54:17 --> Language Class Initialized
INFO - 2017-03-10 01:54:17 --> Loader Class Initialized
INFO - 2017-03-10 01:54:17 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:17 --> Controller Class Initialized
INFO - 2017-03-10 01:54:17 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:17 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:17 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:17 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:17 --> Total execution time: 0.0149
INFO - 2017-03-10 01:54:17 --> Config Class Initialized
INFO - 2017-03-10 01:54:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:17 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:17 --> URI Class Initialized
INFO - 2017-03-10 01:54:17 --> Router Class Initialized
INFO - 2017-03-10 01:54:17 --> Output Class Initialized
INFO - 2017-03-10 01:54:17 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:17 --> Input Class Initialized
INFO - 2017-03-10 01:54:17 --> Language Class Initialized
INFO - 2017-03-10 01:54:17 --> Loader Class Initialized
INFO - 2017-03-10 01:54:17 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:17 --> Controller Class Initialized
INFO - 2017-03-10 01:54:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:54:17 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:17 --> Total execution time: 0.0337
INFO - 2017-03-10 01:54:23 --> Config Class Initialized
INFO - 2017-03-10 01:54:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:23 --> URI Class Initialized
INFO - 2017-03-10 01:54:23 --> Router Class Initialized
INFO - 2017-03-10 01:54:23 --> Output Class Initialized
INFO - 2017-03-10 01:54:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:23 --> Input Class Initialized
INFO - 2017-03-10 01:54:23 --> Language Class Initialized
INFO - 2017-03-10 01:54:23 --> Loader Class Initialized
INFO - 2017-03-10 01:54:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:23 --> Controller Class Initialized
INFO - 2017-03-10 01:54:23 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:23 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:23 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:23 --> Total execution time: 0.0148
INFO - 2017-03-10 01:54:23 --> Config Class Initialized
INFO - 2017-03-10 01:54:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:23 --> URI Class Initialized
INFO - 2017-03-10 01:54:23 --> Router Class Initialized
INFO - 2017-03-10 01:54:23 --> Output Class Initialized
INFO - 2017-03-10 01:54:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:23 --> Input Class Initialized
INFO - 2017-03-10 01:54:23 --> Language Class Initialized
INFO - 2017-03-10 01:54:23 --> Loader Class Initialized
INFO - 2017-03-10 01:54:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:23 --> Controller Class Initialized
INFO - 2017-03-10 01:54:23 --> Upload Class Initialized
INFO - 2017-03-10 01:54:23 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:23 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:23 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:23 --> Total execution time: 0.0160
INFO - 2017-03-10 01:54:32 --> Config Class Initialized
INFO - 2017-03-10 01:54:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:32 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:32 --> URI Class Initialized
INFO - 2017-03-10 01:54:32 --> Router Class Initialized
INFO - 2017-03-10 01:54:32 --> Output Class Initialized
INFO - 2017-03-10 01:54:32 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:32 --> Input Class Initialized
INFO - 2017-03-10 01:54:32 --> Language Class Initialized
INFO - 2017-03-10 01:54:32 --> Loader Class Initialized
INFO - 2017-03-10 01:54:32 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:32 --> Controller Class Initialized
INFO - 2017-03-10 01:54:32 --> Upload Class Initialized
INFO - 2017-03-10 01:54:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:32 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:32 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:54:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:54:33 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:33 --> Total execution time: 0.0445
INFO - 2017-03-10 01:54:33 --> Config Class Initialized
INFO - 2017-03-10 01:54:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:33 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:33 --> URI Class Initialized
INFO - 2017-03-10 01:54:33 --> Router Class Initialized
INFO - 2017-03-10 01:54:33 --> Output Class Initialized
INFO - 2017-03-10 01:54:33 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:33 --> Input Class Initialized
INFO - 2017-03-10 01:54:33 --> Language Class Initialized
INFO - 2017-03-10 01:54:33 --> Loader Class Initialized
INFO - 2017-03-10 01:54:33 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:33 --> Controller Class Initialized
INFO - 2017-03-10 01:54:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:54:33 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:33 --> Total execution time: 0.0144
INFO - 2017-03-10 01:54:36 --> Config Class Initialized
INFO - 2017-03-10 01:54:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:36 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:36 --> URI Class Initialized
INFO - 2017-03-10 01:54:36 --> Router Class Initialized
INFO - 2017-03-10 01:54:36 --> Output Class Initialized
INFO - 2017-03-10 01:54:36 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:36 --> Input Class Initialized
INFO - 2017-03-10 01:54:36 --> Language Class Initialized
INFO - 2017-03-10 01:54:36 --> Loader Class Initialized
INFO - 2017-03-10 01:54:36 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:36 --> Controller Class Initialized
INFO - 2017-03-10 01:54:36 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:36 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:36 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:54:36 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:36 --> Total execution time: 0.0175
INFO - 2017-03-10 01:54:36 --> Config Class Initialized
INFO - 2017-03-10 01:54:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:36 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:36 --> URI Class Initialized
INFO - 2017-03-10 01:54:36 --> Router Class Initialized
INFO - 2017-03-10 01:54:36 --> Output Class Initialized
INFO - 2017-03-10 01:54:36 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:36 --> Input Class Initialized
INFO - 2017-03-10 01:54:36 --> Language Class Initialized
INFO - 2017-03-10 01:54:36 --> Loader Class Initialized
INFO - 2017-03-10 01:54:36 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:36 --> Controller Class Initialized
INFO - 2017-03-10 01:54:36 --> Helper loaded: date_helper
INFO - 2017-03-10 01:54:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:36 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:36 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:36 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:36 --> Total execution time: 0.0154
INFO - 2017-03-10 01:54:36 --> Config Class Initialized
INFO - 2017-03-10 01:54:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:36 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:36 --> URI Class Initialized
INFO - 2017-03-10 01:54:36 --> Router Class Initialized
INFO - 2017-03-10 01:54:36 --> Output Class Initialized
INFO - 2017-03-10 01:54:36 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:36 --> Input Class Initialized
INFO - 2017-03-10 01:54:36 --> Language Class Initialized
INFO - 2017-03-10 01:54:36 --> Loader Class Initialized
INFO - 2017-03-10 01:54:36 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:36 --> Controller Class Initialized
INFO - 2017-03-10 01:54:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:54:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:54:36 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:36 --> Total execution time: 0.0144
INFO - 2017-03-10 01:54:42 --> Config Class Initialized
INFO - 2017-03-10 01:54:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:42 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:42 --> URI Class Initialized
INFO - 2017-03-10 01:54:42 --> Router Class Initialized
INFO - 2017-03-10 01:54:42 --> Output Class Initialized
INFO - 2017-03-10 01:54:42 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:42 --> Input Class Initialized
INFO - 2017-03-10 01:54:42 --> Language Class Initialized
INFO - 2017-03-10 01:54:42 --> Loader Class Initialized
INFO - 2017-03-10 01:54:42 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:42 --> Controller Class Initialized
INFO - 2017-03-10 01:54:42 --> Upload Class Initialized
INFO - 2017-03-10 01:54:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:42 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:42 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:54:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:54:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-03-10 01:54:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-03-10 01:54:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:54:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:54:42 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:42 --> Total execution time: 0.0164
INFO - 2017-03-10 01:54:43 --> Config Class Initialized
INFO - 2017-03-10 01:54:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:43 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:43 --> URI Class Initialized
INFO - 2017-03-10 01:54:43 --> Router Class Initialized
INFO - 2017-03-10 01:54:43 --> Output Class Initialized
INFO - 2017-03-10 01:54:43 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:43 --> Input Class Initialized
INFO - 2017-03-10 01:54:43 --> Language Class Initialized
INFO - 2017-03-10 01:54:43 --> Loader Class Initialized
INFO - 2017-03-10 01:54:43 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:43 --> Controller Class Initialized
INFO - 2017-03-10 01:54:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:54:43 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:43 --> Total execution time: 0.0150
INFO - 2017-03-10 01:54:46 --> Config Class Initialized
INFO - 2017-03-10 01:54:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:46 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:46 --> URI Class Initialized
INFO - 2017-03-10 01:54:46 --> Router Class Initialized
INFO - 2017-03-10 01:54:46 --> Output Class Initialized
INFO - 2017-03-10 01:54:46 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:46 --> Input Class Initialized
INFO - 2017-03-10 01:54:46 --> Language Class Initialized
INFO - 2017-03-10 01:54:46 --> Loader Class Initialized
INFO - 2017-03-10 01:54:46 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:46 --> Controller Class Initialized
INFO - 2017-03-10 01:54:46 --> Upload Class Initialized
INFO - 2017-03-10 01:54:46 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:46 --> Helper loaded: form_helper
INFO - 2017-03-10 01:54:46 --> Form Validation Class Initialized
INFO - 2017-03-10 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-03-10 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-03-10 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:54:46 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:46 --> Total execution time: 0.0171
INFO - 2017-03-10 01:54:47 --> Config Class Initialized
INFO - 2017-03-10 01:54:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:54:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:54:47 --> Utf8 Class Initialized
INFO - 2017-03-10 01:54:47 --> URI Class Initialized
INFO - 2017-03-10 01:54:47 --> Router Class Initialized
INFO - 2017-03-10 01:54:47 --> Output Class Initialized
INFO - 2017-03-10 01:54:47 --> Security Class Initialized
DEBUG - 2017-03-10 01:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:54:47 --> Input Class Initialized
INFO - 2017-03-10 01:54:47 --> Language Class Initialized
INFO - 2017-03-10 01:54:47 --> Loader Class Initialized
INFO - 2017-03-10 01:54:47 --> Database Driver Class Initialized
INFO - 2017-03-10 01:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:54:47 --> Controller Class Initialized
INFO - 2017-03-10 01:54:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:54:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:54:47 --> Final output sent to browser
DEBUG - 2017-03-10 01:54:47 --> Total execution time: 0.0149
INFO - 2017-03-10 01:56:18 --> Config Class Initialized
INFO - 2017-03-10 01:56:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:56:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:56:18 --> Utf8 Class Initialized
INFO - 2017-03-10 01:56:18 --> URI Class Initialized
INFO - 2017-03-10 01:56:18 --> Router Class Initialized
INFO - 2017-03-10 01:56:18 --> Output Class Initialized
INFO - 2017-03-10 01:56:18 --> Security Class Initialized
DEBUG - 2017-03-10 01:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:56:18 --> Input Class Initialized
INFO - 2017-03-10 01:56:18 --> Language Class Initialized
INFO - 2017-03-10 01:56:18 --> Loader Class Initialized
INFO - 2017-03-10 01:56:18 --> Database Driver Class Initialized
INFO - 2017-03-10 01:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:56:18 --> Controller Class Initialized
INFO - 2017-03-10 01:56:18 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:56:18 --> Helper loaded: url_helper
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:56:18 --> Final output sent to browser
DEBUG - 2017-03-10 01:56:18 --> Total execution time: 0.0305
INFO - 2017-03-10 01:56:18 --> Config Class Initialized
INFO - 2017-03-10 01:56:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:56:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:56:18 --> Utf8 Class Initialized
INFO - 2017-03-10 01:56:18 --> URI Class Initialized
INFO - 2017-03-10 01:56:18 --> Router Class Initialized
INFO - 2017-03-10 01:56:18 --> Output Class Initialized
INFO - 2017-03-10 01:56:18 --> Security Class Initialized
DEBUG - 2017-03-10 01:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:56:18 --> Input Class Initialized
INFO - 2017-03-10 01:56:18 --> Language Class Initialized
INFO - 2017-03-10 01:56:18 --> Loader Class Initialized
INFO - 2017-03-10 01:56:18 --> Database Driver Class Initialized
INFO - 2017-03-10 01:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:56:18 --> Controller Class Initialized
INFO - 2017-03-10 01:56:18 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:56:18 --> Final output sent to browser
DEBUG - 2017-03-10 01:56:18 --> Total execution time: 0.0138
INFO - 2017-03-10 01:56:43 --> Config Class Initialized
INFO - 2017-03-10 01:56:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:56:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:56:43 --> Utf8 Class Initialized
INFO - 2017-03-10 01:56:43 --> URI Class Initialized
INFO - 2017-03-10 01:56:43 --> Router Class Initialized
INFO - 2017-03-10 01:56:43 --> Output Class Initialized
INFO - 2017-03-10 01:56:43 --> Security Class Initialized
DEBUG - 2017-03-10 01:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:56:43 --> Input Class Initialized
INFO - 2017-03-10 01:56:43 --> Language Class Initialized
INFO - 2017-03-10 01:56:43 --> Loader Class Initialized
INFO - 2017-03-10 01:56:43 --> Database Driver Class Initialized
INFO - 2017-03-10 01:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:56:43 --> Controller Class Initialized
INFO - 2017-03-10 01:56:43 --> Helper loaded: date_helper
INFO - 2017-03-10 01:56:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:56:43 --> Helper loaded: form_helper
INFO - 2017-03-10 01:56:43 --> Form Validation Class Initialized
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:56:43 --> Final output sent to browser
DEBUG - 2017-03-10 01:56:43 --> Total execution time: 0.0229
INFO - 2017-03-10 01:56:43 --> Config Class Initialized
INFO - 2017-03-10 01:56:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:56:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:56:43 --> Utf8 Class Initialized
INFO - 2017-03-10 01:56:43 --> URI Class Initialized
INFO - 2017-03-10 01:56:43 --> Router Class Initialized
INFO - 2017-03-10 01:56:43 --> Output Class Initialized
INFO - 2017-03-10 01:56:43 --> Security Class Initialized
DEBUG - 2017-03-10 01:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:56:43 --> Input Class Initialized
INFO - 2017-03-10 01:56:43 --> Language Class Initialized
INFO - 2017-03-10 01:56:43 --> Loader Class Initialized
INFO - 2017-03-10 01:56:43 --> Database Driver Class Initialized
INFO - 2017-03-10 01:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:56:43 --> Controller Class Initialized
INFO - 2017-03-10 01:56:43 --> Helper loaded: date_helper
INFO - 2017-03-10 01:56:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:56:43 --> Helper loaded: form_helper
INFO - 2017-03-10 01:56:43 --> Form Validation Class Initialized
INFO - 2017-03-10 01:56:43 --> Final output sent to browser
DEBUG - 2017-03-10 01:56:43 --> Total execution time: 0.0173
INFO - 2017-03-10 01:56:43 --> Config Class Initialized
INFO - 2017-03-10 01:56:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:56:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:56:43 --> Utf8 Class Initialized
INFO - 2017-03-10 01:56:43 --> URI Class Initialized
INFO - 2017-03-10 01:56:43 --> Router Class Initialized
INFO - 2017-03-10 01:56:43 --> Output Class Initialized
INFO - 2017-03-10 01:56:43 --> Security Class Initialized
DEBUG - 2017-03-10 01:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:56:43 --> Input Class Initialized
INFO - 2017-03-10 01:56:43 --> Language Class Initialized
INFO - 2017-03-10 01:56:43 --> Loader Class Initialized
INFO - 2017-03-10 01:56:43 --> Database Driver Class Initialized
INFO - 2017-03-10 01:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:56:43 --> Controller Class Initialized
INFO - 2017-03-10 01:56:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:56:43 --> Final output sent to browser
DEBUG - 2017-03-10 01:56:43 --> Total execution time: 0.0148
INFO - 2017-03-10 01:56:56 --> Config Class Initialized
INFO - 2017-03-10 01:56:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:56:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:56:56 --> Utf8 Class Initialized
INFO - 2017-03-10 01:56:56 --> URI Class Initialized
INFO - 2017-03-10 01:56:56 --> Router Class Initialized
INFO - 2017-03-10 01:56:56 --> Output Class Initialized
INFO - 2017-03-10 01:56:56 --> Security Class Initialized
DEBUG - 2017-03-10 01:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:56:56 --> Input Class Initialized
INFO - 2017-03-10 01:56:56 --> Language Class Initialized
INFO - 2017-03-10 01:56:56 --> Config Class Initialized
INFO - 2017-03-10 01:56:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:56:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:56:56 --> Utf8 Class Initialized
INFO - 2017-03-10 01:56:56 --> URI Class Initialized
INFO - 2017-03-10 01:56:56 --> Router Class Initialized
INFO - 2017-03-10 01:56:56 --> Output Class Initialized
INFO - 2017-03-10 01:56:56 --> Security Class Initialized
DEBUG - 2017-03-10 01:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:56:56 --> Input Class Initialized
INFO - 2017-03-10 01:56:56 --> Language Class Initialized
INFO - 2017-03-10 01:56:56 --> Loader Class Initialized
INFO - 2017-03-10 01:56:56 --> Database Driver Class Initialized
INFO - 2017-03-10 01:56:56 --> Loader Class Initialized
INFO - 2017-03-10 01:56:56 --> Database Driver Class Initialized
INFO - 2017-03-10 01:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:56:56 --> Controller Class Initialized
INFO - 2017-03-10 01:56:56 --> Helper loaded: date_helper
INFO - 2017-03-10 01:56:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:56:56 --> Helper loaded: form_helper
INFO - 2017-03-10 01:56:56 --> Form Validation Class Initialized
INFO - 2017-03-10 01:56:56 --> Final output sent to browser
DEBUG - 2017-03-10 01:56:56 --> Total execution time: 0.0258
INFO - 2017-03-10 01:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:56:56 --> Controller Class Initialized
INFO - 2017-03-10 01:56:56 --> Helper loaded: date_helper
INFO - 2017-03-10 01:56:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:56:56 --> Helper loaded: form_helper
INFO - 2017-03-10 01:56:56 --> Form Validation Class Initialized
INFO - 2017-03-10 01:56:56 --> Final output sent to browser
DEBUG - 2017-03-10 01:56:56 --> Total execution time: 0.0970
INFO - 2017-03-10 01:57:11 --> Config Class Initialized
INFO - 2017-03-10 01:57:11 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:11 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:11 --> URI Class Initialized
INFO - 2017-03-10 01:57:11 --> Router Class Initialized
INFO - 2017-03-10 01:57:11 --> Output Class Initialized
INFO - 2017-03-10 01:57:11 --> Config Class Initialized
INFO - 2017-03-10 01:57:11 --> Hooks Class Initialized
INFO - 2017-03-10 01:57:11 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:11 --> Input Class Initialized
INFO - 2017-03-10 01:57:11 --> Language Class Initialized
DEBUG - 2017-03-10 01:57:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:11 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:11 --> URI Class Initialized
INFO - 2017-03-10 01:57:11 --> Loader Class Initialized
INFO - 2017-03-10 01:57:11 --> Router Class Initialized
INFO - 2017-03-10 01:57:11 --> Output Class Initialized
INFO - 2017-03-10 01:57:11 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:11 --> Input Class Initialized
INFO - 2017-03-10 01:57:11 --> Language Class Initialized
INFO - 2017-03-10 01:57:11 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:11 --> Loader Class Initialized
INFO - 2017-03-10 01:57:11 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:11 --> Controller Class Initialized
INFO - 2017-03-10 01:57:11 --> Helper loaded: date_helper
INFO - 2017-03-10 01:57:11 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:11 --> Helper loaded: form_helper
INFO - 2017-03-10 01:57:11 --> Form Validation Class Initialized
INFO - 2017-03-10 01:57:11 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:11 --> Total execution time: 0.0928
INFO - 2017-03-10 01:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:11 --> Controller Class Initialized
INFO - 2017-03-10 01:57:11 --> Helper loaded: date_helper
INFO - 2017-03-10 01:57:11 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:11 --> Helper loaded: form_helper
INFO - 2017-03-10 01:57:11 --> Form Validation Class Initialized
INFO - 2017-03-10 01:57:11 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:11 --> Total execution time: 0.1043
INFO - 2017-03-10 01:57:16 --> Config Class Initialized
INFO - 2017-03-10 01:57:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:16 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:16 --> URI Class Initialized
INFO - 2017-03-10 01:57:16 --> Router Class Initialized
INFO - 2017-03-10 01:57:16 --> Output Class Initialized
INFO - 2017-03-10 01:57:16 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:16 --> Input Class Initialized
INFO - 2017-03-10 01:57:16 --> Language Class Initialized
INFO - 2017-03-10 01:57:16 --> Loader Class Initialized
INFO - 2017-03-10 01:57:16 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:16 --> Controller Class Initialized
INFO - 2017-03-10 01:57:16 --> Helper loaded: date_helper
INFO - 2017-03-10 01:57:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:16 --> Helper loaded: form_helper
INFO - 2017-03-10 01:57:16 --> Form Validation Class Initialized
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:57:16 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:16 --> Total execution time: 0.0157
INFO - 2017-03-10 01:57:16 --> Config Class Initialized
INFO - 2017-03-10 01:57:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:16 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:16 --> URI Class Initialized
INFO - 2017-03-10 01:57:16 --> Router Class Initialized
INFO - 2017-03-10 01:57:16 --> Output Class Initialized
INFO - 2017-03-10 01:57:16 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:16 --> Input Class Initialized
INFO - 2017-03-10 01:57:16 --> Language Class Initialized
INFO - 2017-03-10 01:57:16 --> Loader Class Initialized
INFO - 2017-03-10 01:57:16 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:16 --> Controller Class Initialized
INFO - 2017-03-10 01:57:16 --> Helper loaded: date_helper
INFO - 2017-03-10 01:57:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:16 --> Helper loaded: form_helper
INFO - 2017-03-10 01:57:16 --> Form Validation Class Initialized
INFO - 2017-03-10 01:57:16 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:16 --> Total execution time: 0.0153
INFO - 2017-03-10 01:57:16 --> Config Class Initialized
INFO - 2017-03-10 01:57:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:16 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:16 --> URI Class Initialized
INFO - 2017-03-10 01:57:16 --> Router Class Initialized
INFO - 2017-03-10 01:57:16 --> Output Class Initialized
INFO - 2017-03-10 01:57:16 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:16 --> Input Class Initialized
INFO - 2017-03-10 01:57:16 --> Language Class Initialized
INFO - 2017-03-10 01:57:16 --> Loader Class Initialized
INFO - 2017-03-10 01:57:16 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:16 --> Controller Class Initialized
INFO - 2017-03-10 01:57:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:57:16 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:16 --> Total execution time: 0.0153
INFO - 2017-03-10 01:57:23 --> Config Class Initialized
INFO - 2017-03-10 01:57:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:23 --> URI Class Initialized
INFO - 2017-03-10 01:57:23 --> Router Class Initialized
INFO - 2017-03-10 01:57:23 --> Output Class Initialized
INFO - 2017-03-10 01:57:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:23 --> Input Class Initialized
INFO - 2017-03-10 01:57:23 --> Language Class Initialized
INFO - 2017-03-10 01:57:23 --> Loader Class Initialized
INFO - 2017-03-10 01:57:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:23 --> Controller Class Initialized
INFO - 2017-03-10 01:57:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:23 --> Config Class Initialized
INFO - 2017-03-10 01:57:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:23 --> URI Class Initialized
INFO - 2017-03-10 01:57:23 --> Router Class Initialized
INFO - 2017-03-10 01:57:23 --> Output Class Initialized
INFO - 2017-03-10 01:57:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:23 --> Input Class Initialized
INFO - 2017-03-10 01:57:23 --> Language Class Initialized
INFO - 2017-03-10 01:57:23 --> Loader Class Initialized
INFO - 2017-03-10 01:57:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:23 --> Controller Class Initialized
INFO - 2017-03-10 01:57:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:23 --> Helper loaded: form_helper
INFO - 2017-03-10 01:57:23 --> Form Validation Class Initialized
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:57:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:23 --> Total execution time: 0.0471
INFO - 2017-03-10 01:57:23 --> Config Class Initialized
INFO - 2017-03-10 01:57:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:23 --> URI Class Initialized
INFO - 2017-03-10 01:57:23 --> Router Class Initialized
INFO - 2017-03-10 01:57:23 --> Output Class Initialized
INFO - 2017-03-10 01:57:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:23 --> Input Class Initialized
INFO - 2017-03-10 01:57:23 --> Language Class Initialized
INFO - 2017-03-10 01:57:23 --> Loader Class Initialized
INFO - 2017-03-10 01:57:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:23 --> Controller Class Initialized
INFO - 2017-03-10 01:57:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:57:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:23 --> Total execution time: 0.0702
INFO - 2017-03-10 01:57:23 --> Config Class Initialized
INFO - 2017-03-10 01:57:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:23 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:23 --> URI Class Initialized
INFO - 2017-03-10 01:57:23 --> Router Class Initialized
INFO - 2017-03-10 01:57:23 --> Output Class Initialized
INFO - 2017-03-10 01:57:23 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:23 --> Input Class Initialized
INFO - 2017-03-10 01:57:23 --> Language Class Initialized
INFO - 2017-03-10 01:57:23 --> Loader Class Initialized
INFO - 2017-03-10 01:57:23 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:23 --> Controller Class Initialized
INFO - 2017-03-10 01:57:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:57:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:57:23 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:23 --> Total execution time: 0.0196
INFO - 2017-03-10 01:57:30 --> Config Class Initialized
INFO - 2017-03-10 01:57:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:30 --> URI Class Initialized
INFO - 2017-03-10 01:57:30 --> Router Class Initialized
INFO - 2017-03-10 01:57:30 --> Output Class Initialized
INFO - 2017-03-10 01:57:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:30 --> Input Class Initialized
INFO - 2017-03-10 01:57:30 --> Language Class Initialized
INFO - 2017-03-10 01:57:30 --> Loader Class Initialized
INFO - 2017-03-10 01:57:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:30 --> Controller Class Initialized
INFO - 2017-03-10 01:57:30 --> Helper loaded: date_helper
DEBUG - 2017-03-10 01:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:30 --> Helper loaded: url_helper
INFO - 2017-03-10 01:57:30 --> Helper loaded: download_helper
INFO - 2017-03-10 01:57:30 --> Config Class Initialized
INFO - 2017-03-10 01:57:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:30 --> URI Class Initialized
DEBUG - 2017-03-10 01:57:30 --> No URI present. Default controller set.
INFO - 2017-03-10 01:57:30 --> Router Class Initialized
INFO - 2017-03-10 01:57:30 --> Output Class Initialized
INFO - 2017-03-10 01:57:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:30 --> Input Class Initialized
INFO - 2017-03-10 01:57:30 --> Language Class Initialized
INFO - 2017-03-10 01:57:30 --> Loader Class Initialized
INFO - 2017-03-10 01:57:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:30 --> Controller Class Initialized
INFO - 2017-03-10 01:57:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:57:30 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:30 --> Total execution time: 0.0141
INFO - 2017-03-10 01:57:30 --> Config Class Initialized
INFO - 2017-03-10 01:57:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:57:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:57:30 --> Utf8 Class Initialized
INFO - 2017-03-10 01:57:30 --> URI Class Initialized
INFO - 2017-03-10 01:57:30 --> Router Class Initialized
INFO - 2017-03-10 01:57:30 --> Output Class Initialized
INFO - 2017-03-10 01:57:30 --> Security Class Initialized
DEBUG - 2017-03-10 01:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:57:30 --> Input Class Initialized
INFO - 2017-03-10 01:57:30 --> Language Class Initialized
INFO - 2017-03-10 01:57:30 --> Loader Class Initialized
INFO - 2017-03-10 01:57:30 --> Database Driver Class Initialized
INFO - 2017-03-10 01:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:57:30 --> Controller Class Initialized
INFO - 2017-03-10 01:57:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:57:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:57:30 --> Final output sent to browser
DEBUG - 2017-03-10 01:57:30 --> Total execution time: 0.0140
INFO - 2017-03-10 01:59:16 --> Config Class Initialized
INFO - 2017-03-10 01:59:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:16 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:16 --> URI Class Initialized
INFO - 2017-03-10 01:59:17 --> Router Class Initialized
INFO - 2017-03-10 01:59:17 --> Output Class Initialized
INFO - 2017-03-10 01:59:17 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:17 --> Input Class Initialized
INFO - 2017-03-10 01:59:17 --> Language Class Initialized
INFO - 2017-03-10 01:59:17 --> Loader Class Initialized
INFO - 2017-03-10 01:59:17 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:17 --> Controller Class Initialized
INFO - 2017-03-10 01:59:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:17 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:17 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:59:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-10 01:59:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:59:17 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:17 --> Total execution time: 1.0890
INFO - 2017-03-10 01:59:18 --> Config Class Initialized
INFO - 2017-03-10 01:59:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:18 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:18 --> URI Class Initialized
INFO - 2017-03-10 01:59:18 --> Router Class Initialized
INFO - 2017-03-10 01:59:18 --> Output Class Initialized
INFO - 2017-03-10 01:59:18 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:18 --> Input Class Initialized
INFO - 2017-03-10 01:59:18 --> Language Class Initialized
INFO - 2017-03-10 01:59:18 --> Loader Class Initialized
INFO - 2017-03-10 01:59:18 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:18 --> Controller Class Initialized
INFO - 2017-03-10 01:59:18 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:59:18 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:18 --> Total execution time: 0.2941
INFO - 2017-03-10 01:59:25 --> Config Class Initialized
INFO - 2017-03-10 01:59:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:25 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:25 --> URI Class Initialized
INFO - 2017-03-10 01:59:25 --> Router Class Initialized
INFO - 2017-03-10 01:59:25 --> Output Class Initialized
INFO - 2017-03-10 01:59:25 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:25 --> Input Class Initialized
INFO - 2017-03-10 01:59:25 --> Language Class Initialized
INFO - 2017-03-10 01:59:25 --> Loader Class Initialized
INFO - 2017-03-10 01:59:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:25 --> Controller Class Initialized
INFO - 2017-03-10 01:59:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:25 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:25 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-10 01:59:25 --> Config Class Initialized
INFO - 2017-03-10 01:59:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:25 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:25 --> URI Class Initialized
INFO - 2017-03-10 01:59:25 --> Router Class Initialized
INFO - 2017-03-10 01:59:25 --> Output Class Initialized
INFO - 2017-03-10 01:59:25 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:25 --> Input Class Initialized
INFO - 2017-03-10 01:59:25 --> Language Class Initialized
INFO - 2017-03-10 01:59:25 --> Loader Class Initialized
INFO - 2017-03-10 01:59:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:25 --> Controller Class Initialized
INFO - 2017-03-10 01:59:25 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:25 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:25 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:59:25 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:25 --> Total execution time: 0.1380
INFO - 2017-03-10 01:59:25 --> Config Class Initialized
INFO - 2017-03-10 01:59:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:25 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:25 --> URI Class Initialized
INFO - 2017-03-10 01:59:25 --> Router Class Initialized
INFO - 2017-03-10 01:59:25 --> Output Class Initialized
INFO - 2017-03-10 01:59:25 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:25 --> Input Class Initialized
INFO - 2017-03-10 01:59:25 --> Language Class Initialized
INFO - 2017-03-10 01:59:25 --> Loader Class Initialized
INFO - 2017-03-10 01:59:25 --> Config Class Initialized
INFO - 2017-03-10 01:59:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:25 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:25 --> URI Class Initialized
INFO - 2017-03-10 01:59:25 --> Router Class Initialized
INFO - 2017-03-10 01:59:25 --> Output Class Initialized
INFO - 2017-03-10 01:59:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:25 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:25 --> Input Class Initialized
INFO - 2017-03-10 01:59:25 --> Language Class Initialized
INFO - 2017-03-10 01:59:25 --> Loader Class Initialized
INFO - 2017-03-10 01:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:25 --> Controller Class Initialized
INFO - 2017-03-10 01:59:25 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:25 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:25 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:25 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:25 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:25 --> Total execution time: 0.0189
INFO - 2017-03-10 01:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:25 --> Controller Class Initialized
INFO - 2017-03-10 01:59:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:59:25 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:25 --> Total execution time: 0.0921
INFO - 2017-03-10 01:59:29 --> Config Class Initialized
INFO - 2017-03-10 01:59:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:29 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:29 --> URI Class Initialized
INFO - 2017-03-10 01:59:29 --> Router Class Initialized
INFO - 2017-03-10 01:59:29 --> Output Class Initialized
INFO - 2017-03-10 01:59:29 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:29 --> Input Class Initialized
INFO - 2017-03-10 01:59:29 --> Language Class Initialized
INFO - 2017-03-10 01:59:29 --> Loader Class Initialized
INFO - 2017-03-10 01:59:29 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:29 --> Controller Class Initialized
INFO - 2017-03-10 01:59:29 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:29 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:29 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 01:59:29 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:29 --> Total execution time: 0.0155
INFO - 2017-03-10 01:59:29 --> Config Class Initialized
INFO - 2017-03-10 01:59:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:29 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:29 --> URI Class Initialized
INFO - 2017-03-10 01:59:29 --> Router Class Initialized
INFO - 2017-03-10 01:59:29 --> Output Class Initialized
INFO - 2017-03-10 01:59:29 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:29 --> Input Class Initialized
INFO - 2017-03-10 01:59:29 --> Language Class Initialized
INFO - 2017-03-10 01:59:29 --> Loader Class Initialized
INFO - 2017-03-10 01:59:29 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:29 --> Controller Class Initialized
INFO - 2017-03-10 01:59:29 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:29 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:29 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:29 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:29 --> Total execution time: 0.0188
INFO - 2017-03-10 01:59:29 --> Config Class Initialized
INFO - 2017-03-10 01:59:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:29 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:29 --> URI Class Initialized
INFO - 2017-03-10 01:59:29 --> Router Class Initialized
INFO - 2017-03-10 01:59:29 --> Output Class Initialized
INFO - 2017-03-10 01:59:29 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:29 --> Input Class Initialized
INFO - 2017-03-10 01:59:29 --> Language Class Initialized
INFO - 2017-03-10 01:59:29 --> Loader Class Initialized
INFO - 2017-03-10 01:59:29 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:29 --> Controller Class Initialized
INFO - 2017-03-10 01:59:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 01:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 01:59:29 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:29 --> Total execution time: 0.0667
INFO - 2017-03-10 01:59:31 --> Config Class Initialized
INFO - 2017-03-10 01:59:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:31 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:31 --> URI Class Initialized
INFO - 2017-03-10 01:59:31 --> Router Class Initialized
INFO - 2017-03-10 01:59:31 --> Output Class Initialized
INFO - 2017-03-10 01:59:31 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:31 --> Input Class Initialized
INFO - 2017-03-10 01:59:31 --> Language Class Initialized
INFO - 2017-03-10 01:59:31 --> Loader Class Initialized
INFO - 2017-03-10 01:59:31 --> Config Class Initialized
INFO - 2017-03-10 01:59:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:31 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:31 --> URI Class Initialized
INFO - 2017-03-10 01:59:31 --> Router Class Initialized
INFO - 2017-03-10 01:59:31 --> Output Class Initialized
INFO - 2017-03-10 01:59:31 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:31 --> Input Class Initialized
INFO - 2017-03-10 01:59:31 --> Language Class Initialized
INFO - 2017-03-10 01:59:31 --> Loader Class Initialized
INFO - 2017-03-10 01:59:31 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:31 --> Controller Class Initialized
INFO - 2017-03-10 01:59:31 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:31 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:31 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:31 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:31 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:31 --> Total execution time: 0.0339
INFO - 2017-03-10 01:59:31 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:31 --> Controller Class Initialized
INFO - 2017-03-10 01:59:31 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:31 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:31 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:31 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:31 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:31 --> Total execution time: 0.0901
INFO - 2017-03-10 01:59:35 --> Config Class Initialized
INFO - 2017-03-10 01:59:35 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:35 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:35 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:35 --> URI Class Initialized
INFO - 2017-03-10 01:59:35 --> Router Class Initialized
INFO - 2017-03-10 01:59:35 --> Output Class Initialized
INFO - 2017-03-10 01:59:35 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:35 --> Input Class Initialized
INFO - 2017-03-10 01:59:35 --> Language Class Initialized
INFO - 2017-03-10 01:59:35 --> Loader Class Initialized
INFO - 2017-03-10 01:59:35 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:35 --> Config Class Initialized
INFO - 2017-03-10 01:59:35 --> Hooks Class Initialized
DEBUG - 2017-03-10 01:59:35 --> UTF-8 Support Enabled
INFO - 2017-03-10 01:59:35 --> Utf8 Class Initialized
INFO - 2017-03-10 01:59:35 --> URI Class Initialized
INFO - 2017-03-10 01:59:35 --> Router Class Initialized
INFO - 2017-03-10 01:59:35 --> Output Class Initialized
INFO - 2017-03-10 01:59:35 --> Security Class Initialized
DEBUG - 2017-03-10 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 01:59:35 --> Input Class Initialized
INFO - 2017-03-10 01:59:35 --> Language Class Initialized
INFO - 2017-03-10 01:59:35 --> Loader Class Initialized
INFO - 2017-03-10 01:59:35 --> Database Driver Class Initialized
INFO - 2017-03-10 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:35 --> Controller Class Initialized
INFO - 2017-03-10 01:59:35 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:35 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:35 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:35 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:35 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:35 --> Total execution time: 0.0366
INFO - 2017-03-10 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 01:59:35 --> Controller Class Initialized
INFO - 2017-03-10 01:59:35 --> Helper loaded: date_helper
INFO - 2017-03-10 01:59:35 --> Helper loaded: url_helper
DEBUG - 2017-03-10 01:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 01:59:35 --> Helper loaded: form_helper
INFO - 2017-03-10 01:59:35 --> Form Validation Class Initialized
INFO - 2017-03-10 01:59:35 --> Final output sent to browser
DEBUG - 2017-03-10 01:59:35 --> Total execution time: 0.0347
INFO - 2017-03-10 02:00:01 --> Config Class Initialized
INFO - 2017-03-10 02:00:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:01 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:01 --> URI Class Initialized
INFO - 2017-03-10 02:00:01 --> Router Class Initialized
INFO - 2017-03-10 02:00:01 --> Output Class Initialized
INFO - 2017-03-10 02:00:01 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:02 --> Input Class Initialized
INFO - 2017-03-10 02:00:02 --> Language Class Initialized
INFO - 2017-03-10 02:00:02 --> Loader Class Initialized
INFO - 2017-03-10 02:00:02 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:03 --> Controller Class Initialized
INFO - 2017-03-10 02:00:03 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:03 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:03 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:03 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 02:00:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 02:00:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-03-10 02:00:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-03-10 02:00:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 02:00:04 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:04 --> Total execution time: 2.5598
INFO - 2017-03-10 02:00:04 --> Config Class Initialized
INFO - 2017-03-10 02:00:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:05 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:05 --> URI Class Initialized
INFO - 2017-03-10 02:00:05 --> Router Class Initialized
INFO - 2017-03-10 02:00:05 --> Output Class Initialized
INFO - 2017-03-10 02:00:05 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:05 --> Input Class Initialized
INFO - 2017-03-10 02:00:05 --> Language Class Initialized
INFO - 2017-03-10 02:00:05 --> Loader Class Initialized
INFO - 2017-03-10 02:00:05 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:05 --> Controller Class Initialized
INFO - 2017-03-10 02:00:05 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:05 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:05 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:06 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 02:00:06 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:06 --> Total execution time: 1.2431
INFO - 2017-03-10 02:00:06 --> Config Class Initialized
INFO - 2017-03-10 02:00:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:06 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:06 --> URI Class Initialized
INFO - 2017-03-10 02:00:06 --> Router Class Initialized
INFO - 2017-03-10 02:00:06 --> Config Class Initialized
INFO - 2017-03-10 02:00:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:06 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:06 --> URI Class Initialized
INFO - 2017-03-10 02:00:06 --> Router Class Initialized
INFO - 2017-03-10 02:00:06 --> Output Class Initialized
INFO - 2017-03-10 02:00:06 --> Output Class Initialized
INFO - 2017-03-10 02:00:06 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:06 --> Input Class Initialized
INFO - 2017-03-10 02:00:06 --> Language Class Initialized
INFO - 2017-03-10 02:00:06 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:06 --> Input Class Initialized
INFO - 2017-03-10 02:00:06 --> Language Class Initialized
INFO - 2017-03-10 02:00:06 --> Loader Class Initialized
INFO - 2017-03-10 02:00:06 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:06 --> Loader Class Initialized
INFO - 2017-03-10 02:00:06 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:06 --> Controller Class Initialized
INFO - 2017-03-10 02:00:06 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:06 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:06 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:06 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:06 --> Total execution time: 0.0766
INFO - 2017-03-10 02:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:06 --> Controller Class Initialized
INFO - 2017-03-10 02:00:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:06 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:06 --> Total execution time: 0.3589
INFO - 2017-03-10 02:00:07 --> Config Class Initialized
INFO - 2017-03-10 02:00:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:07 --> URI Class Initialized
INFO - 2017-03-10 02:00:07 --> Router Class Initialized
INFO - 2017-03-10 02:00:07 --> Output Class Initialized
INFO - 2017-03-10 02:00:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:07 --> Input Class Initialized
INFO - 2017-03-10 02:00:07 --> Language Class Initialized
INFO - 2017-03-10 02:00:07 --> Loader Class Initialized
INFO - 2017-03-10 02:00:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:07 --> Controller Class Initialized
INFO - 2017-03-10 02:00:07 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:07 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:07 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 02:00:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:07 --> Total execution time: 0.0160
INFO - 2017-03-10 02:00:07 --> Config Class Initialized
INFO - 2017-03-10 02:00:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:07 --> URI Class Initialized
INFO - 2017-03-10 02:00:07 --> Router Class Initialized
INFO - 2017-03-10 02:00:07 --> Output Class Initialized
INFO - 2017-03-10 02:00:07 --> Security Class Initialized
INFO - 2017-03-10 02:00:07 --> Config Class Initialized
INFO - 2017-03-10 02:00:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:07 --> URI Class Initialized
INFO - 2017-03-10 02:00:07 --> Router Class Initialized
INFO - 2017-03-10 02:00:07 --> Output Class Initialized
INFO - 2017-03-10 02:00:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:07 --> Input Class Initialized
INFO - 2017-03-10 02:00:07 --> Language Class Initialized
DEBUG - 2017-03-10 02:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:07 --> Input Class Initialized
INFO - 2017-03-10 02:00:07 --> Language Class Initialized
INFO - 2017-03-10 02:00:07 --> Loader Class Initialized
INFO - 2017-03-10 02:00:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:07 --> Controller Class Initialized
INFO - 2017-03-10 02:00:07 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:07 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:07 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:07 --> Loader Class Initialized
INFO - 2017-03-10 02:00:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:07 --> Total execution time: 0.0936
INFO - 2017-03-10 02:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:07 --> Controller Class Initialized
INFO - 2017-03-10 02:00:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:07 --> Total execution time: 0.0826
INFO - 2017-03-10 02:00:10 --> Config Class Initialized
INFO - 2017-03-10 02:00:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:10 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:10 --> URI Class Initialized
INFO - 2017-03-10 02:00:10 --> Router Class Initialized
INFO - 2017-03-10 02:00:10 --> Output Class Initialized
INFO - 2017-03-10 02:00:10 --> Security Class Initialized
INFO - 2017-03-10 02:00:10 --> Config Class Initialized
INFO - 2017-03-10 02:00:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:10 --> Input Class Initialized
DEBUG - 2017-03-10 02:00:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:10 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:10 --> Language Class Initialized
INFO - 2017-03-10 02:00:10 --> URI Class Initialized
INFO - 2017-03-10 02:00:10 --> Router Class Initialized
INFO - 2017-03-10 02:00:10 --> Loader Class Initialized
INFO - 2017-03-10 02:00:10 --> Output Class Initialized
INFO - 2017-03-10 02:00:10 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:10 --> Input Class Initialized
INFO - 2017-03-10 02:00:10 --> Language Class Initialized
INFO - 2017-03-10 02:00:10 --> Loader Class Initialized
INFO - 2017-03-10 02:00:10 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:10 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:10 --> Controller Class Initialized
INFO - 2017-03-10 02:00:10 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:10 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:10 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:10 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:10 --> Total execution time: 0.1628
INFO - 2017-03-10 02:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:10 --> Controller Class Initialized
INFO - 2017-03-10 02:00:10 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:10 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:10 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:10 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:10 --> Total execution time: 0.0949
INFO - 2017-03-10 02:00:20 --> Config Class Initialized
INFO - 2017-03-10 02:00:20 --> Hooks Class Initialized
INFO - 2017-03-10 02:00:20 --> Config Class Initialized
INFO - 2017-03-10 02:00:20 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:20 --> UTF-8 Support Enabled
DEBUG - 2017-03-10 02:00:20 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:20 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:20 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:20 --> URI Class Initialized
INFO - 2017-03-10 02:00:20 --> URI Class Initialized
INFO - 2017-03-10 02:00:20 --> Router Class Initialized
INFO - 2017-03-10 02:00:20 --> Router Class Initialized
INFO - 2017-03-10 02:00:20 --> Output Class Initialized
INFO - 2017-03-10 02:00:20 --> Output Class Initialized
INFO - 2017-03-10 02:00:20 --> Security Class Initialized
INFO - 2017-03-10 02:00:20 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:20 --> Input Class Initialized
DEBUG - 2017-03-10 02:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:20 --> Language Class Initialized
INFO - 2017-03-10 02:00:20 --> Input Class Initialized
INFO - 2017-03-10 02:00:20 --> Language Class Initialized
INFO - 2017-03-10 02:00:20 --> Loader Class Initialized
INFO - 2017-03-10 02:00:20 --> Loader Class Initialized
INFO - 2017-03-10 02:00:21 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:21 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:21 --> Controller Class Initialized
INFO - 2017-03-10 02:00:21 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:21 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:21 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:21 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:21 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:21 --> Total execution time: 1.1894
INFO - 2017-03-10 02:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:21 --> Controller Class Initialized
INFO - 2017-03-10 02:00:21 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:21 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:21 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:21 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:21 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:21 --> Total execution time: 1.3444
INFO - 2017-03-10 02:00:23 --> Config Class Initialized
INFO - 2017-03-10 02:00:23 --> Config Class Initialized
INFO - 2017-03-10 02:00:23 --> Hooks Class Initialized
INFO - 2017-03-10 02:00:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:23 --> UTF-8 Support Enabled
DEBUG - 2017-03-10 02:00:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:23 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:23 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:23 --> URI Class Initialized
INFO - 2017-03-10 02:00:23 --> URI Class Initialized
INFO - 2017-03-10 02:00:23 --> Router Class Initialized
INFO - 2017-03-10 02:00:23 --> Router Class Initialized
INFO - 2017-03-10 02:00:23 --> Output Class Initialized
INFO - 2017-03-10 02:00:23 --> Output Class Initialized
INFO - 2017-03-10 02:00:23 --> Security Class Initialized
INFO - 2017-03-10 02:00:23 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:23 --> Input Class Initialized
INFO - 2017-03-10 02:00:23 --> Language Class Initialized
DEBUG - 2017-03-10 02:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:23 --> Input Class Initialized
INFO - 2017-03-10 02:00:23 --> Language Class Initialized
INFO - 2017-03-10 02:00:23 --> Loader Class Initialized
INFO - 2017-03-10 02:00:23 --> Loader Class Initialized
INFO - 2017-03-10 02:00:23 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:23 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:23 --> Controller Class Initialized
INFO - 2017-03-10 02:00:23 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:24 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:24 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:24 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:24 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:24 --> Total execution time: 1.1945
INFO - 2017-03-10 02:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:24 --> Controller Class Initialized
INFO - 2017-03-10 02:00:24 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:24 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:24 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:24 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:24 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:24 --> Total execution time: 1.3907
INFO - 2017-03-10 02:00:28 --> Config Class Initialized
INFO - 2017-03-10 02:00:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:29 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:29 --> URI Class Initialized
INFO - 2017-03-10 02:00:29 --> Router Class Initialized
INFO - 2017-03-10 02:00:29 --> Output Class Initialized
INFO - 2017-03-10 02:00:29 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:29 --> Input Class Initialized
INFO - 2017-03-10 02:00:29 --> Language Class Initialized
INFO - 2017-03-10 02:00:29 --> Loader Class Initialized
INFO - 2017-03-10 02:00:29 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:29 --> Controller Class Initialized
INFO - 2017-03-10 02:00:29 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:29 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:30 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 02:00:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 02:00:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-03-10 02:00:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-03-10 02:00:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 02:00:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:30 --> Total execution time: 1.3222
INFO - 2017-03-10 02:00:30 --> Config Class Initialized
INFO - 2017-03-10 02:00:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:30 --> URI Class Initialized
INFO - 2017-03-10 02:00:30 --> Router Class Initialized
INFO - 2017-03-10 02:00:30 --> Output Class Initialized
INFO - 2017-03-10 02:00:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:30 --> Input Class Initialized
INFO - 2017-03-10 02:00:30 --> Language Class Initialized
INFO - 2017-03-10 02:00:30 --> Loader Class Initialized
INFO - 2017-03-10 02:00:30 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:30 --> Controller Class Initialized
INFO - 2017-03-10 02:00:30 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:30 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:30 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:30 --> Total execution time: 0.0156
INFO - 2017-03-10 02:00:31 --> Config Class Initialized
INFO - 2017-03-10 02:00:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:31 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:31 --> URI Class Initialized
INFO - 2017-03-10 02:00:31 --> Router Class Initialized
INFO - 2017-03-10 02:00:31 --> Output Class Initialized
INFO - 2017-03-10 02:00:31 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:31 --> Input Class Initialized
INFO - 2017-03-10 02:00:31 --> Language Class Initialized
INFO - 2017-03-10 02:00:31 --> Loader Class Initialized
INFO - 2017-03-10 02:00:31 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:31 --> Controller Class Initialized
INFO - 2017-03-10 02:00:31 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:31 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:31 --> Total execution time: 0.8685
INFO - 2017-03-10 02:00:32 --> Config Class Initialized
INFO - 2017-03-10 02:00:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:32 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:32 --> URI Class Initialized
INFO - 2017-03-10 02:00:32 --> Router Class Initialized
INFO - 2017-03-10 02:00:32 --> Output Class Initialized
INFO - 2017-03-10 02:00:32 --> Security Class Initialized
INFO - 2017-03-10 02:00:32 --> Config Class Initialized
INFO - 2017-03-10 02:00:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:32 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:32 --> URI Class Initialized
DEBUG - 2017-03-10 02:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:32 --> Input Class Initialized
INFO - 2017-03-10 02:00:32 --> Language Class Initialized
INFO - 2017-03-10 02:00:32 --> Loader Class Initialized
INFO - 2017-03-10 02:00:32 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:32 --> Router Class Initialized
INFO - 2017-03-10 02:00:32 --> Output Class Initialized
INFO - 2017-03-10 02:00:32 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:32 --> Input Class Initialized
INFO - 2017-03-10 02:00:32 --> Language Class Initialized
INFO - 2017-03-10 02:00:32 --> Loader Class Initialized
INFO - 2017-03-10 02:00:32 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:32 --> Controller Class Initialized
INFO - 2017-03-10 02:00:32 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:32 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:32 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:32 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:32 --> Total execution time: 0.1009
INFO - 2017-03-10 02:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:32 --> Controller Class Initialized
INFO - 2017-03-10 02:00:32 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:32 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:32 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:32 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:32 --> Total execution time: 0.0301
INFO - 2017-03-10 02:00:39 --> Config Class Initialized
INFO - 2017-03-10 02:00:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:39 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:39 --> URI Class Initialized
INFO - 2017-03-10 02:00:39 --> Router Class Initialized
INFO - 2017-03-10 02:00:39 --> Config Class Initialized
INFO - 2017-03-10 02:00:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:39 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:39 --> URI Class Initialized
INFO - 2017-03-10 02:00:39 --> Router Class Initialized
INFO - 2017-03-10 02:00:39 --> Output Class Initialized
INFO - 2017-03-10 02:00:39 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:39 --> Input Class Initialized
INFO - 2017-03-10 02:00:39 --> Language Class Initialized
INFO - 2017-03-10 02:00:39 --> Loader Class Initialized
INFO - 2017-03-10 02:00:39 --> Output Class Initialized
INFO - 2017-03-10 02:00:39 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:39 --> Input Class Initialized
INFO - 2017-03-10 02:00:39 --> Language Class Initialized
INFO - 2017-03-10 02:00:39 --> Loader Class Initialized
INFO - 2017-03-10 02:00:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:39 --> Controller Class Initialized
INFO - 2017-03-10 02:00:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:39 --> Total execution time: 0.0739
INFO - 2017-03-10 02:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:39 --> Controller Class Initialized
INFO - 2017-03-10 02:00:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:40 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:40 --> Total execution time: 0.0941
INFO - 2017-03-10 02:00:42 --> Config Class Initialized
INFO - 2017-03-10 02:00:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:42 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:42 --> URI Class Initialized
INFO - 2017-03-10 02:00:42 --> Router Class Initialized
INFO - 2017-03-10 02:00:42 --> Output Class Initialized
INFO - 2017-03-10 02:00:42 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:42 --> Input Class Initialized
INFO - 2017-03-10 02:00:42 --> Language Class Initialized
INFO - 2017-03-10 02:00:42 --> Loader Class Initialized
INFO - 2017-03-10 02:00:43 --> Config Class Initialized
INFO - 2017-03-10 02:00:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:43 --> URI Class Initialized
INFO - 2017-03-10 02:00:43 --> Router Class Initialized
INFO - 2017-03-10 02:00:43 --> Output Class Initialized
INFO - 2017-03-10 02:00:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:43 --> Input Class Initialized
INFO - 2017-03-10 02:00:43 --> Language Class Initialized
INFO - 2017-03-10 02:00:43 --> Loader Class Initialized
INFO - 2017-03-10 02:00:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:43 --> Controller Class Initialized
INFO - 2017-03-10 02:00:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:43 --> Total execution time: 0.0314
INFO - 2017-03-10 02:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:43 --> Controller Class Initialized
INFO - 2017-03-10 02:00:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:00:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:00:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:00:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:43 --> Total execution time: 0.0260
INFO - 2017-03-10 02:00:43 --> Config Class Initialized
INFO - 2017-03-10 02:00:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:43 --> URI Class Initialized
INFO - 2017-03-10 02:00:43 --> Router Class Initialized
INFO - 2017-03-10 02:00:43 --> Output Class Initialized
INFO - 2017-03-10 02:00:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:43 --> Input Class Initialized
INFO - 2017-03-10 02:00:43 --> Language Class Initialized
INFO - 2017-03-10 02:00:43 --> Loader Class Initialized
INFO - 2017-03-10 02:00:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:43 --> Controller Class Initialized
INFO - 2017-03-10 02:00:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:43 --> Total execution time: 0.0292
INFO - 2017-03-10 02:00:47 --> Config Class Initialized
INFO - 2017-03-10 02:00:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:47 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:47 --> URI Class Initialized
INFO - 2017-03-10 02:00:47 --> Router Class Initialized
INFO - 2017-03-10 02:00:47 --> Output Class Initialized
INFO - 2017-03-10 02:00:47 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:47 --> Input Class Initialized
INFO - 2017-03-10 02:00:47 --> Language Class Initialized
INFO - 2017-03-10 02:00:47 --> Loader Class Initialized
INFO - 2017-03-10 02:00:47 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:47 --> Controller Class Initialized
INFO - 2017-03-10 02:00:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:47 --> Config Class Initialized
INFO - 2017-03-10 02:00:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:47 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:47 --> URI Class Initialized
INFO - 2017-03-10 02:00:47 --> Router Class Initialized
INFO - 2017-03-10 02:00:47 --> Output Class Initialized
INFO - 2017-03-10 02:00:47 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:47 --> Input Class Initialized
INFO - 2017-03-10 02:00:47 --> Language Class Initialized
INFO - 2017-03-10 02:00:47 --> Loader Class Initialized
INFO - 2017-03-10 02:00:47 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:47 --> Controller Class Initialized
INFO - 2017-03-10 02:00:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:47 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:47 --> Total execution time: 0.0145
INFO - 2017-03-10 02:00:47 --> Config Class Initialized
INFO - 2017-03-10 02:00:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:47 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:47 --> URI Class Initialized
DEBUG - 2017-03-10 02:00:47 --> No URI present. Default controller set.
INFO - 2017-03-10 02:00:47 --> Router Class Initialized
INFO - 2017-03-10 02:00:47 --> Output Class Initialized
INFO - 2017-03-10 02:00:47 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:47 --> Input Class Initialized
INFO - 2017-03-10 02:00:47 --> Language Class Initialized
INFO - 2017-03-10 02:00:47 --> Loader Class Initialized
INFO - 2017-03-10 02:00:47 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:47 --> Controller Class Initialized
INFO - 2017-03-10 02:00:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:47 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:47 --> Total execution time: 0.0139
INFO - 2017-03-10 02:00:48 --> Config Class Initialized
INFO - 2017-03-10 02:00:48 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:48 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:48 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:48 --> URI Class Initialized
INFO - 2017-03-10 02:00:48 --> Router Class Initialized
INFO - 2017-03-10 02:00:48 --> Output Class Initialized
INFO - 2017-03-10 02:00:48 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:48 --> Input Class Initialized
INFO - 2017-03-10 02:00:48 --> Language Class Initialized
INFO - 2017-03-10 02:00:48 --> Loader Class Initialized
INFO - 2017-03-10 02:00:48 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:48 --> Controller Class Initialized
INFO - 2017-03-10 02:00:48 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:48 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:48 --> Total execution time: 0.0157
INFO - 2017-03-10 02:00:51 --> Config Class Initialized
INFO - 2017-03-10 02:00:51 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:51 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:51 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:51 --> URI Class Initialized
INFO - 2017-03-10 02:00:51 --> Router Class Initialized
INFO - 2017-03-10 02:00:51 --> Output Class Initialized
INFO - 2017-03-10 02:00:51 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:51 --> Input Class Initialized
INFO - 2017-03-10 02:00:51 --> Language Class Initialized
INFO - 2017-03-10 02:00:51 --> Loader Class Initialized
INFO - 2017-03-10 02:00:51 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:51 --> Controller Class Initialized
INFO - 2017-03-10 02:00:51 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:52 --> Config Class Initialized
INFO - 2017-03-10 02:00:52 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:52 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:52 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:52 --> URI Class Initialized
INFO - 2017-03-10 02:00:52 --> Router Class Initialized
INFO - 2017-03-10 02:00:52 --> Output Class Initialized
INFO - 2017-03-10 02:00:52 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:52 --> Input Class Initialized
INFO - 2017-03-10 02:00:52 --> Language Class Initialized
INFO - 2017-03-10 02:00:52 --> Loader Class Initialized
INFO - 2017-03-10 02:00:52 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:52 --> Controller Class Initialized
INFO - 2017-03-10 02:00:52 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:52 --> Helper loaded: url_helper
INFO - 2017-03-10 02:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 02:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 02:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:52 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:52 --> Total execution time: 0.0476
INFO - 2017-03-10 02:00:53 --> Config Class Initialized
INFO - 2017-03-10 02:00:53 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:00:53 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:00:53 --> Utf8 Class Initialized
INFO - 2017-03-10 02:00:53 --> URI Class Initialized
INFO - 2017-03-10 02:00:53 --> Router Class Initialized
INFO - 2017-03-10 02:00:53 --> Output Class Initialized
INFO - 2017-03-10 02:00:53 --> Security Class Initialized
DEBUG - 2017-03-10 02:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:00:53 --> Input Class Initialized
INFO - 2017-03-10 02:00:53 --> Language Class Initialized
INFO - 2017-03-10 02:00:53 --> Loader Class Initialized
INFO - 2017-03-10 02:00:53 --> Database Driver Class Initialized
INFO - 2017-03-10 02:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:00:53 --> Controller Class Initialized
INFO - 2017-03-10 02:00:53 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:00:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:00:53 --> Final output sent to browser
DEBUG - 2017-03-10 02:00:53 --> Total execution time: 0.0141
INFO - 2017-03-10 02:01:12 --> Config Class Initialized
INFO - 2017-03-10 02:01:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:12 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:12 --> URI Class Initialized
INFO - 2017-03-10 02:01:12 --> Router Class Initialized
INFO - 2017-03-10 02:01:12 --> Output Class Initialized
INFO - 2017-03-10 02:01:12 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:12 --> Input Class Initialized
INFO - 2017-03-10 02:01:12 --> Language Class Initialized
INFO - 2017-03-10 02:01:12 --> Loader Class Initialized
INFO - 2017-03-10 02:01:12 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:12 --> Controller Class Initialized
INFO - 2017-03-10 02:01:12 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:12 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:12 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:12 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:12 --> Total execution time: 0.0157
INFO - 2017-03-10 02:01:12 --> Config Class Initialized
INFO - 2017-03-10 02:01:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:12 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:12 --> URI Class Initialized
INFO - 2017-03-10 02:01:12 --> Router Class Initialized
INFO - 2017-03-10 02:01:12 --> Output Class Initialized
INFO - 2017-03-10 02:01:12 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:12 --> Input Class Initialized
INFO - 2017-03-10 02:01:12 --> Language Class Initialized
INFO - 2017-03-10 02:01:12 --> Loader Class Initialized
INFO - 2017-03-10 02:01:12 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:12 --> Controller Class Initialized
INFO - 2017-03-10 02:01:12 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:12 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:12 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:12 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:12 --> Total execution time: 0.0165
INFO - 2017-03-10 02:01:14 --> Config Class Initialized
INFO - 2017-03-10 02:01:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:14 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:14 --> URI Class Initialized
INFO - 2017-03-10 02:01:14 --> Router Class Initialized
INFO - 2017-03-10 02:01:14 --> Output Class Initialized
INFO - 2017-03-10 02:01:14 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:14 --> Input Class Initialized
INFO - 2017-03-10 02:01:14 --> Language Class Initialized
INFO - 2017-03-10 02:01:14 --> Loader Class Initialized
INFO - 2017-03-10 02:01:14 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:14 --> Controller Class Initialized
INFO - 2017-03-10 02:01:14 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:14 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:14 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:14 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:14 --> Total execution time: 0.0153
INFO - 2017-03-10 02:01:16 --> Config Class Initialized
INFO - 2017-03-10 02:01:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:16 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:16 --> URI Class Initialized
INFO - 2017-03-10 02:01:16 --> Router Class Initialized
INFO - 2017-03-10 02:01:16 --> Output Class Initialized
INFO - 2017-03-10 02:01:16 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:16 --> Input Class Initialized
INFO - 2017-03-10 02:01:16 --> Language Class Initialized
INFO - 2017-03-10 02:01:16 --> Loader Class Initialized
INFO - 2017-03-10 02:01:16 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:16 --> Controller Class Initialized
INFO - 2017-03-10 02:01:16 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:16 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:16 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:16 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:16 --> Total execution time: 0.0157
INFO - 2017-03-10 02:01:18 --> Config Class Initialized
INFO - 2017-03-10 02:01:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:18 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:18 --> URI Class Initialized
INFO - 2017-03-10 02:01:18 --> Router Class Initialized
INFO - 2017-03-10 02:01:18 --> Output Class Initialized
INFO - 2017-03-10 02:01:18 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:18 --> Input Class Initialized
INFO - 2017-03-10 02:01:18 --> Language Class Initialized
INFO - 2017-03-10 02:01:18 --> Loader Class Initialized
INFO - 2017-03-10 02:01:18 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:18 --> Controller Class Initialized
INFO - 2017-03-10 02:01:18 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:18 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:18 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:18 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:18 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:18 --> Total execution time: 0.0160
INFO - 2017-03-10 02:01:19 --> Config Class Initialized
INFO - 2017-03-10 02:01:19 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:19 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:19 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:19 --> URI Class Initialized
INFO - 2017-03-10 02:01:19 --> Router Class Initialized
INFO - 2017-03-10 02:01:19 --> Output Class Initialized
INFO - 2017-03-10 02:01:19 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:19 --> Input Class Initialized
INFO - 2017-03-10 02:01:19 --> Language Class Initialized
INFO - 2017-03-10 02:01:19 --> Loader Class Initialized
INFO - 2017-03-10 02:01:19 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:19 --> Controller Class Initialized
INFO - 2017-03-10 02:01:19 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:19 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:19 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:19 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:19 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:19 --> Total execution time: 0.0168
INFO - 2017-03-10 02:01:22 --> Config Class Initialized
INFO - 2017-03-10 02:01:22 --> Hooks Class Initialized
INFO - 2017-03-10 02:01:22 --> Config Class Initialized
INFO - 2017-03-10 02:01:22 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:22 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:22 --> URI Class Initialized
DEBUG - 2017-03-10 02:01:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:22 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:22 --> Router Class Initialized
INFO - 2017-03-10 02:01:22 --> URI Class Initialized
INFO - 2017-03-10 02:01:22 --> Output Class Initialized
INFO - 2017-03-10 02:01:22 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:22 --> Input Class Initialized
INFO - 2017-03-10 02:01:22 --> Language Class Initialized
INFO - 2017-03-10 02:01:22 --> Router Class Initialized
INFO - 2017-03-10 02:01:22 --> Output Class Initialized
INFO - 2017-03-10 02:01:22 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:22 --> Input Class Initialized
INFO - 2017-03-10 02:01:22 --> Language Class Initialized
INFO - 2017-03-10 02:01:22 --> Loader Class Initialized
INFO - 2017-03-10 02:01:22 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:22 --> Loader Class Initialized
INFO - 2017-03-10 02:01:22 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:22 --> Controller Class Initialized
INFO - 2017-03-10 02:01:22 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:22 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:23 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:23 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:23 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:23 --> Total execution time: 0.0778
INFO - 2017-03-10 02:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:23 --> Controller Class Initialized
INFO - 2017-03-10 02:01:23 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:23 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:23 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:23 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:23 --> Total execution time: 0.0864
INFO - 2017-03-10 02:01:28 --> Config Class Initialized
INFO - 2017-03-10 02:01:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:28 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:28 --> URI Class Initialized
INFO - 2017-03-10 02:01:28 --> Config Class Initialized
INFO - 2017-03-10 02:01:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:28 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:28 --> URI Class Initialized
INFO - 2017-03-10 02:01:28 --> Router Class Initialized
INFO - 2017-03-10 02:01:28 --> Output Class Initialized
INFO - 2017-03-10 02:01:28 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:28 --> Input Class Initialized
INFO - 2017-03-10 02:01:28 --> Language Class Initialized
INFO - 2017-03-10 02:01:28 --> Loader Class Initialized
INFO - 2017-03-10 02:01:28 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:28 --> Router Class Initialized
INFO - 2017-03-10 02:01:28 --> Output Class Initialized
INFO - 2017-03-10 02:01:28 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:28 --> Input Class Initialized
INFO - 2017-03-10 02:01:28 --> Language Class Initialized
INFO - 2017-03-10 02:01:28 --> Loader Class Initialized
INFO - 2017-03-10 02:01:28 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:28 --> Controller Class Initialized
INFO - 2017-03-10 02:01:28 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:28 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:28 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:28 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:28 --> Total execution time: 0.0378
INFO - 2017-03-10 02:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:28 --> Controller Class Initialized
INFO - 2017-03-10 02:01:28 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:28 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:28 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:28 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:28 --> Total execution time: 0.0804
INFO - 2017-03-10 02:01:31 --> Config Class Initialized
INFO - 2017-03-10 02:01:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:31 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:31 --> URI Class Initialized
INFO - 2017-03-10 02:01:31 --> Router Class Initialized
INFO - 2017-03-10 02:01:31 --> Config Class Initialized
INFO - 2017-03-10 02:01:31 --> Hooks Class Initialized
INFO - 2017-03-10 02:01:31 --> Output Class Initialized
DEBUG - 2017-03-10 02:01:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:31 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:31 --> Security Class Initialized
INFO - 2017-03-10 02:01:31 --> URI Class Initialized
DEBUG - 2017-03-10 02:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:31 --> Input Class Initialized
INFO - 2017-03-10 02:01:31 --> Language Class Initialized
INFO - 2017-03-10 02:01:31 --> Router Class Initialized
INFO - 2017-03-10 02:01:31 --> Output Class Initialized
INFO - 2017-03-10 02:01:31 --> Loader Class Initialized
INFO - 2017-03-10 02:01:31 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:31 --> Input Class Initialized
INFO - 2017-03-10 02:01:31 --> Language Class Initialized
INFO - 2017-03-10 02:01:31 --> Loader Class Initialized
INFO - 2017-03-10 02:01:31 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:31 --> Controller Class Initialized
INFO - 2017-03-10 02:01:31 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:31 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:31 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:31 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:31 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:31 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:31 --> Total execution time: 0.0160
INFO - 2017-03-10 02:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:31 --> Controller Class Initialized
INFO - 2017-03-10 02:01:31 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:31 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:31 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:31 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:31 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:31 --> Total execution time: 0.0918
INFO - 2017-03-10 02:01:38 --> Config Class Initialized
INFO - 2017-03-10 02:01:38 --> Config Class Initialized
INFO - 2017-03-10 02:01:38 --> Hooks Class Initialized
INFO - 2017-03-10 02:01:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:38 --> UTF-8 Support Enabled
DEBUG - 2017-03-10 02:01:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:38 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:38 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:38 --> URI Class Initialized
INFO - 2017-03-10 02:01:38 --> URI Class Initialized
INFO - 2017-03-10 02:01:38 --> Router Class Initialized
INFO - 2017-03-10 02:01:38 --> Router Class Initialized
INFO - 2017-03-10 02:01:38 --> Output Class Initialized
INFO - 2017-03-10 02:01:38 --> Output Class Initialized
INFO - 2017-03-10 02:01:38 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:38 --> Security Class Initialized
INFO - 2017-03-10 02:01:38 --> Input Class Initialized
INFO - 2017-03-10 02:01:38 --> Language Class Initialized
DEBUG - 2017-03-10 02:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:38 --> Input Class Initialized
INFO - 2017-03-10 02:01:38 --> Language Class Initialized
INFO - 2017-03-10 02:01:39 --> Loader Class Initialized
INFO - 2017-03-10 02:01:39 --> Loader Class Initialized
INFO - 2017-03-10 02:01:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:39 --> Controller Class Initialized
INFO - 2017-03-10 02:01:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:39 --> Config Class Initialized
INFO - 2017-03-10 02:01:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:39 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:39 --> URI Class Initialized
INFO - 2017-03-10 02:01:39 --> Router Class Initialized
INFO - 2017-03-10 02:01:39 --> Output Class Initialized
INFO - 2017-03-10 02:01:39 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:39 --> Input Class Initialized
INFO - 2017-03-10 02:01:39 --> Language Class Initialized
INFO - 2017-03-10 02:01:39 --> Loader Class Initialized
INFO - 2017-03-10 02:01:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:39 --> Total execution time: 0.8027
INFO - 2017-03-10 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:39 --> Controller Class Initialized
INFO - 2017-03-10 02:01:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:39 --> Total execution time: 0.8175
INFO - 2017-03-10 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:39 --> Controller Class Initialized
INFO - 2017-03-10 02:01:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:39 --> Config Class Initialized
INFO - 2017-03-10 02:01:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:39 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:39 --> URI Class Initialized
INFO - 2017-03-10 02:01:39 --> Router Class Initialized
INFO - 2017-03-10 02:01:39 --> Output Class Initialized
INFO - 2017-03-10 02:01:39 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:39 --> Input Class Initialized
INFO - 2017-03-10 02:01:39 --> Language Class Initialized
INFO - 2017-03-10 02:01:39 --> Loader Class Initialized
INFO - 2017-03-10 02:01:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:39 --> Total execution time: 0.1237
INFO - 2017-03-10 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:39 --> Controller Class Initialized
INFO - 2017-03-10 02:01:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:39 --> Total execution time: 0.0724
INFO - 2017-03-10 02:01:43 --> Config Class Initialized
INFO - 2017-03-10 02:01:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:43 --> URI Class Initialized
INFO - 2017-03-10 02:01:43 --> Router Class Initialized
INFO - 2017-03-10 02:01:43 --> Output Class Initialized
INFO - 2017-03-10 02:01:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:43 --> Input Class Initialized
INFO - 2017-03-10 02:01:43 --> Language Class Initialized
INFO - 2017-03-10 02:01:43 --> Loader Class Initialized
INFO - 2017-03-10 02:01:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:43 --> Controller Class Initialized
INFO - 2017-03-10 02:01:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 02:01:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:43 --> Total execution time: 0.0496
INFO - 2017-03-10 02:01:43 --> Config Class Initialized
INFO - 2017-03-10 02:01:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:43 --> URI Class Initialized
INFO - 2017-03-10 02:01:43 --> Router Class Initialized
INFO - 2017-03-10 02:01:43 --> Output Class Initialized
INFO - 2017-03-10 02:01:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:43 --> Input Class Initialized
INFO - 2017-03-10 02:01:43 --> Language Class Initialized
INFO - 2017-03-10 02:01:43 --> Loader Class Initialized
INFO - 2017-03-10 02:01:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:43 --> Controller Class Initialized
INFO - 2017-03-10 02:01:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:01:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:01:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:01:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:43 --> Total execution time: 0.0154
INFO - 2017-03-10 02:01:43 --> Config Class Initialized
INFO - 2017-03-10 02:01:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:01:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:01:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:01:43 --> URI Class Initialized
INFO - 2017-03-10 02:01:43 --> Router Class Initialized
INFO - 2017-03-10 02:01:43 --> Output Class Initialized
INFO - 2017-03-10 02:01:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:01:43 --> Input Class Initialized
INFO - 2017-03-10 02:01:43 --> Language Class Initialized
INFO - 2017-03-10 02:01:43 --> Loader Class Initialized
INFO - 2017-03-10 02:01:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:01:43 --> Controller Class Initialized
INFO - 2017-03-10 02:01:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:01:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:01:43 --> Total execution time: 0.0538
INFO - 2017-03-10 02:04:01 --> Config Class Initialized
INFO - 2017-03-10 02:04:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:04:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:04:01 --> Utf8 Class Initialized
INFO - 2017-03-10 02:04:01 --> URI Class Initialized
INFO - 2017-03-10 02:04:01 --> Router Class Initialized
INFO - 2017-03-10 02:04:02 --> Output Class Initialized
INFO - 2017-03-10 02:04:02 --> Security Class Initialized
DEBUG - 2017-03-10 02:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:04:02 --> Input Class Initialized
INFO - 2017-03-10 02:04:02 --> Language Class Initialized
INFO - 2017-03-10 02:04:02 --> Loader Class Initialized
INFO - 2017-03-10 02:04:02 --> Database Driver Class Initialized
INFO - 2017-03-10 02:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:04:02 --> Controller Class Initialized
INFO - 2017-03-10 02:04:02 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:04:02 --> Helper loaded: url_helper
INFO - 2017-03-10 02:04:02 --> Helper loaded: download_helper
INFO - 2017-03-10 02:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:04:02 --> Final output sent to browser
DEBUG - 2017-03-10 02:04:02 --> Total execution time: 1.1594
INFO - 2017-03-10 02:04:03 --> Config Class Initialized
INFO - 2017-03-10 02:04:03 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:04:03 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:04:03 --> Utf8 Class Initialized
INFO - 2017-03-10 02:04:03 --> URI Class Initialized
INFO - 2017-03-10 02:04:04 --> Router Class Initialized
INFO - 2017-03-10 02:04:04 --> Output Class Initialized
INFO - 2017-03-10 02:04:04 --> Security Class Initialized
DEBUG - 2017-03-10 02:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:04:04 --> Input Class Initialized
INFO - 2017-03-10 02:04:04 --> Language Class Initialized
INFO - 2017-03-10 02:04:04 --> Loader Class Initialized
INFO - 2017-03-10 02:04:04 --> Database Driver Class Initialized
INFO - 2017-03-10 02:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:04:04 --> Controller Class Initialized
INFO - 2017-03-10 02:04:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:04:05 --> Final output sent to browser
DEBUG - 2017-03-10 02:04:05 --> Total execution time: 1.2459
INFO - 2017-03-10 02:05:16 --> Config Class Initialized
INFO - 2017-03-10 02:05:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:16 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:16 --> URI Class Initialized
INFO - 2017-03-10 02:05:16 --> Router Class Initialized
INFO - 2017-03-10 02:05:16 --> Output Class Initialized
INFO - 2017-03-10 02:05:16 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:16 --> Input Class Initialized
INFO - 2017-03-10 02:05:16 --> Language Class Initialized
INFO - 2017-03-10 02:05:16 --> Loader Class Initialized
INFO - 2017-03-10 02:05:17 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:17 --> Controller Class Initialized
INFO - 2017-03-10 02:05:17 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:17 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:17 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:17 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:17 --> Total execution time: 1.1415
INFO - 2017-03-10 02:05:27 --> Config Class Initialized
INFO - 2017-03-10 02:05:27 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:27 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:27 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:27 --> URI Class Initialized
INFO - 2017-03-10 02:05:27 --> Router Class Initialized
INFO - 2017-03-10 02:05:27 --> Output Class Initialized
INFO - 2017-03-10 02:05:27 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:27 --> Input Class Initialized
INFO - 2017-03-10 02:05:27 --> Language Class Initialized
INFO - 2017-03-10 02:05:27 --> Loader Class Initialized
INFO - 2017-03-10 02:05:27 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:27 --> Controller Class Initialized
INFO - 2017-03-10 02:05:27 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:27 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:27 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:27 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:27 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:27 --> Total execution time: 0.0247
INFO - 2017-03-10 02:05:33 --> Config Class Initialized
INFO - 2017-03-10 02:05:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:33 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:33 --> URI Class Initialized
INFO - 2017-03-10 02:05:33 --> Router Class Initialized
INFO - 2017-03-10 02:05:33 --> Output Class Initialized
INFO - 2017-03-10 02:05:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:33 --> Input Class Initialized
INFO - 2017-03-10 02:05:33 --> Language Class Initialized
INFO - 2017-03-10 02:05:33 --> Loader Class Initialized
INFO - 2017-03-10 02:05:33 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:33 --> Controller Class Initialized
INFO - 2017-03-10 02:05:33 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:33 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:33 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:33 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:33 --> Total execution time: 0.0155
INFO - 2017-03-10 02:05:33 --> Config Class Initialized
INFO - 2017-03-10 02:05:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:33 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:33 --> URI Class Initialized
INFO - 2017-03-10 02:05:33 --> Router Class Initialized
INFO - 2017-03-10 02:05:33 --> Output Class Initialized
INFO - 2017-03-10 02:05:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:33 --> Input Class Initialized
INFO - 2017-03-10 02:05:33 --> Language Class Initialized
INFO - 2017-03-10 02:05:33 --> Loader Class Initialized
INFO - 2017-03-10 02:05:33 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:33 --> Controller Class Initialized
INFO - 2017-03-10 02:05:33 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:33 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:33 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:33 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:33 --> Total execution time: 0.0153
INFO - 2017-03-10 02:05:34 --> Config Class Initialized
INFO - 2017-03-10 02:05:34 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:34 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:34 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:34 --> URI Class Initialized
INFO - 2017-03-10 02:05:34 --> Router Class Initialized
INFO - 2017-03-10 02:05:34 --> Output Class Initialized
INFO - 2017-03-10 02:05:34 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:34 --> Input Class Initialized
INFO - 2017-03-10 02:05:34 --> Language Class Initialized
INFO - 2017-03-10 02:05:34 --> Loader Class Initialized
INFO - 2017-03-10 02:05:34 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:34 --> Controller Class Initialized
INFO - 2017-03-10 02:05:34 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:34 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:34 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:34 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:34 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:34 --> Total execution time: 0.0161
INFO - 2017-03-10 02:05:38 --> Config Class Initialized
INFO - 2017-03-10 02:05:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:38 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:38 --> URI Class Initialized
INFO - 2017-03-10 02:05:38 --> Router Class Initialized
INFO - 2017-03-10 02:05:38 --> Output Class Initialized
INFO - 2017-03-10 02:05:38 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:38 --> Input Class Initialized
INFO - 2017-03-10 02:05:38 --> Language Class Initialized
INFO - 2017-03-10 02:05:38 --> Loader Class Initialized
INFO - 2017-03-10 02:05:38 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:38 --> Controller Class Initialized
INFO - 2017-03-10 02:05:38 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:38 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:38 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:38 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:38 --> Total execution time: 0.0150
INFO - 2017-03-10 02:05:42 --> Config Class Initialized
INFO - 2017-03-10 02:05:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:42 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:42 --> URI Class Initialized
INFO - 2017-03-10 02:05:42 --> Router Class Initialized
INFO - 2017-03-10 02:05:42 --> Output Class Initialized
INFO - 2017-03-10 02:05:42 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:42 --> Input Class Initialized
INFO - 2017-03-10 02:05:42 --> Language Class Initialized
INFO - 2017-03-10 02:05:42 --> Loader Class Initialized
INFO - 2017-03-10 02:05:42 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:42 --> Controller Class Initialized
INFO - 2017-03-10 02:05:42 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:42 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:42 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:42 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:42 --> Total execution time: 0.0164
INFO - 2017-03-10 02:05:43 --> Config Class Initialized
INFO - 2017-03-10 02:05:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:43 --> URI Class Initialized
INFO - 2017-03-10 02:05:43 --> Router Class Initialized
INFO - 2017-03-10 02:05:43 --> Output Class Initialized
INFO - 2017-03-10 02:05:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:43 --> Input Class Initialized
INFO - 2017-03-10 02:05:43 --> Language Class Initialized
INFO - 2017-03-10 02:05:43 --> Loader Class Initialized
INFO - 2017-03-10 02:05:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:43 --> Controller Class Initialized
INFO - 2017-03-10 02:05:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:43 --> Total execution time: 0.0379
INFO - 2017-03-10 02:05:45 --> Config Class Initialized
INFO - 2017-03-10 02:05:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:45 --> URI Class Initialized
INFO - 2017-03-10 02:05:45 --> Router Class Initialized
INFO - 2017-03-10 02:05:45 --> Output Class Initialized
INFO - 2017-03-10 02:05:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:45 --> Input Class Initialized
INFO - 2017-03-10 02:05:45 --> Language Class Initialized
INFO - 2017-03-10 02:05:45 --> Loader Class Initialized
INFO - 2017-03-10 02:05:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:45 --> Controller Class Initialized
INFO - 2017-03-10 02:05:45 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:45 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:45 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:45 --> Total execution time: 0.0157
INFO - 2017-03-10 02:05:46 --> Config Class Initialized
INFO - 2017-03-10 02:05:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:46 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:46 --> URI Class Initialized
INFO - 2017-03-10 02:05:46 --> Router Class Initialized
INFO - 2017-03-10 02:05:46 --> Output Class Initialized
INFO - 2017-03-10 02:05:46 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:46 --> Input Class Initialized
INFO - 2017-03-10 02:05:46 --> Language Class Initialized
INFO - 2017-03-10 02:05:46 --> Loader Class Initialized
INFO - 2017-03-10 02:05:46 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:46 --> Controller Class Initialized
INFO - 2017-03-10 02:05:46 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:46 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:46 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:46 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:46 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:46 --> Total execution time: 0.0152
INFO - 2017-03-10 02:05:48 --> Config Class Initialized
INFO - 2017-03-10 02:05:48 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:48 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:48 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:48 --> URI Class Initialized
INFO - 2017-03-10 02:05:48 --> Router Class Initialized
INFO - 2017-03-10 02:05:48 --> Output Class Initialized
INFO - 2017-03-10 02:05:48 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:48 --> Input Class Initialized
INFO - 2017-03-10 02:05:48 --> Language Class Initialized
INFO - 2017-03-10 02:05:48 --> Loader Class Initialized
INFO - 2017-03-10 02:05:48 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:48 --> Controller Class Initialized
INFO - 2017-03-10 02:05:48 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:05:48 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:48 --> Total execution time: 0.3835
INFO - 2017-03-10 02:05:53 --> Config Class Initialized
INFO - 2017-03-10 02:05:53 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:53 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:53 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:53 --> URI Class Initialized
INFO - 2017-03-10 02:05:53 --> Router Class Initialized
INFO - 2017-03-10 02:05:53 --> Output Class Initialized
INFO - 2017-03-10 02:05:53 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:53 --> Input Class Initialized
INFO - 2017-03-10 02:05:53 --> Language Class Initialized
INFO - 2017-03-10 02:05:53 --> Loader Class Initialized
INFO - 2017-03-10 02:05:53 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:53 --> Controller Class Initialized
INFO - 2017-03-10 02:05:53 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:53 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:53 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:53 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:53 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:53 --> Total execution time: 0.0160
INFO - 2017-03-10 02:05:55 --> Config Class Initialized
INFO - 2017-03-10 02:05:55 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:55 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:55 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:55 --> URI Class Initialized
INFO - 2017-03-10 02:05:55 --> Router Class Initialized
INFO - 2017-03-10 02:05:55 --> Output Class Initialized
INFO - 2017-03-10 02:05:55 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:55 --> Input Class Initialized
INFO - 2017-03-10 02:05:55 --> Language Class Initialized
INFO - 2017-03-10 02:05:55 --> Loader Class Initialized
INFO - 2017-03-10 02:05:55 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:55 --> Controller Class Initialized
INFO - 2017-03-10 02:05:55 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:55 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:55 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:55 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:55 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:55 --> Total execution time: 0.0146
INFO - 2017-03-10 02:05:56 --> Config Class Initialized
INFO - 2017-03-10 02:05:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:56 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:56 --> URI Class Initialized
INFO - 2017-03-10 02:05:56 --> Router Class Initialized
INFO - 2017-03-10 02:05:56 --> Output Class Initialized
INFO - 2017-03-10 02:05:56 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:56 --> Input Class Initialized
INFO - 2017-03-10 02:05:56 --> Language Class Initialized
INFO - 2017-03-10 02:05:56 --> Loader Class Initialized
INFO - 2017-03-10 02:05:56 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:56 --> Controller Class Initialized
INFO - 2017-03-10 02:05:56 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:56 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:56 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:56 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:56 --> Total execution time: 0.0149
INFO - 2017-03-10 02:05:59 --> Config Class Initialized
INFO - 2017-03-10 02:05:59 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:05:59 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:05:59 --> Utf8 Class Initialized
INFO - 2017-03-10 02:05:59 --> URI Class Initialized
INFO - 2017-03-10 02:05:59 --> Router Class Initialized
INFO - 2017-03-10 02:05:59 --> Output Class Initialized
INFO - 2017-03-10 02:05:59 --> Security Class Initialized
DEBUG - 2017-03-10 02:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:05:59 --> Input Class Initialized
INFO - 2017-03-10 02:05:59 --> Language Class Initialized
INFO - 2017-03-10 02:05:59 --> Loader Class Initialized
INFO - 2017-03-10 02:05:59 --> Database Driver Class Initialized
INFO - 2017-03-10 02:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:05:59 --> Controller Class Initialized
INFO - 2017-03-10 02:05:59 --> Helper loaded: date_helper
INFO - 2017-03-10 02:05:59 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:05:59 --> Helper loaded: form_helper
INFO - 2017-03-10 02:05:59 --> Form Validation Class Initialized
INFO - 2017-03-10 02:05:59 --> Final output sent to browser
DEBUG - 2017-03-10 02:05:59 --> Total execution time: 0.0152
INFO - 2017-03-10 02:06:02 --> Config Class Initialized
INFO - 2017-03-10 02:06:02 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:02 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:02 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:02 --> URI Class Initialized
INFO - 2017-03-10 02:06:02 --> Router Class Initialized
INFO - 2017-03-10 02:06:02 --> Output Class Initialized
INFO - 2017-03-10 02:06:02 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:02 --> Input Class Initialized
INFO - 2017-03-10 02:06:02 --> Language Class Initialized
INFO - 2017-03-10 02:06:02 --> Loader Class Initialized
INFO - 2017-03-10 02:06:02 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:02 --> Controller Class Initialized
INFO - 2017-03-10 02:06:02 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:02 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:02 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:02 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:02 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:02 --> Total execution time: 0.0155
INFO - 2017-03-10 02:06:07 --> Config Class Initialized
INFO - 2017-03-10 02:06:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:07 --> URI Class Initialized
INFO - 2017-03-10 02:06:07 --> Router Class Initialized
INFO - 2017-03-10 02:06:07 --> Output Class Initialized
INFO - 2017-03-10 02:06:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:07 --> Input Class Initialized
INFO - 2017-03-10 02:06:07 --> Language Class Initialized
INFO - 2017-03-10 02:06:07 --> Loader Class Initialized
INFO - 2017-03-10 02:06:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:07 --> Controller Class Initialized
INFO - 2017-03-10 02:06:07 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:07 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:07 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:07 --> Total execution time: 0.0161
INFO - 2017-03-10 02:06:07 --> Config Class Initialized
INFO - 2017-03-10 02:06:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:07 --> URI Class Initialized
INFO - 2017-03-10 02:06:07 --> Router Class Initialized
INFO - 2017-03-10 02:06:07 --> Output Class Initialized
INFO - 2017-03-10 02:06:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:07 --> Input Class Initialized
INFO - 2017-03-10 02:06:07 --> Language Class Initialized
INFO - 2017-03-10 02:06:07 --> Loader Class Initialized
INFO - 2017-03-10 02:06:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:07 --> Controller Class Initialized
INFO - 2017-03-10 02:06:07 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:07 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:07 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:07 --> Total execution time: 0.0167
INFO - 2017-03-10 02:06:08 --> Config Class Initialized
INFO - 2017-03-10 02:06:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:08 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:08 --> URI Class Initialized
INFO - 2017-03-10 02:06:08 --> Router Class Initialized
INFO - 2017-03-10 02:06:08 --> Output Class Initialized
INFO - 2017-03-10 02:06:08 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:08 --> Input Class Initialized
INFO - 2017-03-10 02:06:08 --> Language Class Initialized
INFO - 2017-03-10 02:06:08 --> Loader Class Initialized
INFO - 2017-03-10 02:06:08 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:08 --> Controller Class Initialized
INFO - 2017-03-10 02:06:08 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:08 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:08 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:08 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:08 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:08 --> Total execution time: 0.0153
INFO - 2017-03-10 02:06:10 --> Config Class Initialized
INFO - 2017-03-10 02:06:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:10 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:10 --> URI Class Initialized
INFO - 2017-03-10 02:06:10 --> Router Class Initialized
INFO - 2017-03-10 02:06:10 --> Output Class Initialized
INFO - 2017-03-10 02:06:10 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:10 --> Input Class Initialized
INFO - 2017-03-10 02:06:10 --> Language Class Initialized
INFO - 2017-03-10 02:06:10 --> Loader Class Initialized
INFO - 2017-03-10 02:06:10 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:10 --> Controller Class Initialized
INFO - 2017-03-10 02:06:10 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:10 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:10 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:10 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:10 --> Total execution time: 0.0146
INFO - 2017-03-10 02:06:11 --> Config Class Initialized
INFO - 2017-03-10 02:06:11 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:11 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:11 --> URI Class Initialized
INFO - 2017-03-10 02:06:11 --> Router Class Initialized
INFO - 2017-03-10 02:06:11 --> Output Class Initialized
INFO - 2017-03-10 02:06:11 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:11 --> Input Class Initialized
INFO - 2017-03-10 02:06:11 --> Language Class Initialized
INFO - 2017-03-10 02:06:11 --> Loader Class Initialized
INFO - 2017-03-10 02:06:11 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:11 --> Controller Class Initialized
INFO - 2017-03-10 02:06:11 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:11 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:11 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:11 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:11 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:11 --> Total execution time: 0.0148
INFO - 2017-03-10 02:06:16 --> Config Class Initialized
INFO - 2017-03-10 02:06:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:16 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:16 --> URI Class Initialized
INFO - 2017-03-10 02:06:16 --> Router Class Initialized
INFO - 2017-03-10 02:06:16 --> Output Class Initialized
INFO - 2017-03-10 02:06:16 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:16 --> Input Class Initialized
INFO - 2017-03-10 02:06:16 --> Language Class Initialized
INFO - 2017-03-10 02:06:16 --> Loader Class Initialized
INFO - 2017-03-10 02:06:16 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:16 --> Controller Class Initialized
INFO - 2017-03-10 02:06:16 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:16 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:16 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:16 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:16 --> Total execution time: 0.0152
INFO - 2017-03-10 02:06:19 --> Config Class Initialized
INFO - 2017-03-10 02:06:19 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:19 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:19 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:19 --> URI Class Initialized
INFO - 2017-03-10 02:06:19 --> Router Class Initialized
INFO - 2017-03-10 02:06:19 --> Output Class Initialized
INFO - 2017-03-10 02:06:19 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:19 --> Input Class Initialized
INFO - 2017-03-10 02:06:19 --> Language Class Initialized
INFO - 2017-03-10 02:06:19 --> Loader Class Initialized
INFO - 2017-03-10 02:06:19 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:19 --> Controller Class Initialized
INFO - 2017-03-10 02:06:19 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:19 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:19 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:19 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:19 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:19 --> Total execution time: 0.0148
INFO - 2017-03-10 02:06:22 --> Config Class Initialized
INFO - 2017-03-10 02:06:22 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:22 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:22 --> URI Class Initialized
INFO - 2017-03-10 02:06:22 --> Router Class Initialized
INFO - 2017-03-10 02:06:22 --> Output Class Initialized
INFO - 2017-03-10 02:06:22 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:22 --> Input Class Initialized
INFO - 2017-03-10 02:06:22 --> Language Class Initialized
INFO - 2017-03-10 02:06:22 --> Loader Class Initialized
INFO - 2017-03-10 02:06:22 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:22 --> Controller Class Initialized
INFO - 2017-03-10 02:06:22 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:22 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:22 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:22 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:22 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:22 --> Total execution time: 0.0161
INFO - 2017-03-10 02:06:26 --> Config Class Initialized
INFO - 2017-03-10 02:06:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:26 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:26 --> URI Class Initialized
INFO - 2017-03-10 02:06:26 --> Router Class Initialized
INFO - 2017-03-10 02:06:26 --> Output Class Initialized
INFO - 2017-03-10 02:06:26 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:26 --> Input Class Initialized
INFO - 2017-03-10 02:06:26 --> Language Class Initialized
INFO - 2017-03-10 02:06:26 --> Loader Class Initialized
INFO - 2017-03-10 02:06:26 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:26 --> Controller Class Initialized
INFO - 2017-03-10 02:06:26 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:26 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:26 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:26 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:26 --> Total execution time: 0.0151
INFO - 2017-03-10 02:06:28 --> Config Class Initialized
INFO - 2017-03-10 02:06:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:28 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:28 --> URI Class Initialized
INFO - 2017-03-10 02:06:28 --> Router Class Initialized
INFO - 2017-03-10 02:06:28 --> Output Class Initialized
INFO - 2017-03-10 02:06:28 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:28 --> Input Class Initialized
INFO - 2017-03-10 02:06:28 --> Language Class Initialized
INFO - 2017-03-10 02:06:28 --> Loader Class Initialized
INFO - 2017-03-10 02:06:28 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:28 --> Controller Class Initialized
INFO - 2017-03-10 02:06:28 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:28 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:28 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:28 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:28 --> Total execution time: 0.0154
INFO - 2017-03-10 02:06:29 --> Config Class Initialized
INFO - 2017-03-10 02:06:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:29 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:29 --> URI Class Initialized
INFO - 2017-03-10 02:06:29 --> Router Class Initialized
INFO - 2017-03-10 02:06:29 --> Output Class Initialized
INFO - 2017-03-10 02:06:29 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:29 --> Input Class Initialized
INFO - 2017-03-10 02:06:29 --> Language Class Initialized
INFO - 2017-03-10 02:06:29 --> Loader Class Initialized
INFO - 2017-03-10 02:06:29 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:29 --> Controller Class Initialized
INFO - 2017-03-10 02:06:29 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:29 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:29 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:29 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:29 --> Total execution time: 0.0155
INFO - 2017-03-10 02:06:29 --> Config Class Initialized
INFO - 2017-03-10 02:06:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:29 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:29 --> URI Class Initialized
INFO - 2017-03-10 02:06:29 --> Router Class Initialized
INFO - 2017-03-10 02:06:29 --> Output Class Initialized
INFO - 2017-03-10 02:06:29 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:29 --> Input Class Initialized
INFO - 2017-03-10 02:06:29 --> Language Class Initialized
INFO - 2017-03-10 02:06:29 --> Loader Class Initialized
INFO - 2017-03-10 02:06:29 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:29 --> Controller Class Initialized
INFO - 2017-03-10 02:06:29 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:29 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:29 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:29 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:29 --> Total execution time: 0.0148
INFO - 2017-03-10 02:06:33 --> Config Class Initialized
INFO - 2017-03-10 02:06:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:33 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:33 --> URI Class Initialized
INFO - 2017-03-10 02:06:33 --> Router Class Initialized
INFO - 2017-03-10 02:06:33 --> Output Class Initialized
INFO - 2017-03-10 02:06:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:33 --> Input Class Initialized
INFO - 2017-03-10 02:06:33 --> Language Class Initialized
INFO - 2017-03-10 02:06:33 --> Loader Class Initialized
INFO - 2017-03-10 02:06:33 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:33 --> Controller Class Initialized
INFO - 2017-03-10 02:06:33 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:33 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:33 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:33 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:33 --> Total execution time: 0.0170
INFO - 2017-03-10 02:06:36 --> Config Class Initialized
INFO - 2017-03-10 02:06:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:36 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:36 --> URI Class Initialized
INFO - 2017-03-10 02:06:36 --> Router Class Initialized
INFO - 2017-03-10 02:06:36 --> Output Class Initialized
INFO - 2017-03-10 02:06:36 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:36 --> Input Class Initialized
INFO - 2017-03-10 02:06:36 --> Language Class Initialized
INFO - 2017-03-10 02:06:36 --> Loader Class Initialized
INFO - 2017-03-10 02:06:36 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:36 --> Controller Class Initialized
INFO - 2017-03-10 02:06:36 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:36 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:36 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:36 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:36 --> Total execution time: 0.0153
INFO - 2017-03-10 02:06:36 --> Config Class Initialized
INFO - 2017-03-10 02:06:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:36 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:36 --> URI Class Initialized
INFO - 2017-03-10 02:06:36 --> Router Class Initialized
INFO - 2017-03-10 02:06:36 --> Output Class Initialized
INFO - 2017-03-10 02:06:36 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:36 --> Input Class Initialized
INFO - 2017-03-10 02:06:36 --> Language Class Initialized
INFO - 2017-03-10 02:06:36 --> Loader Class Initialized
INFO - 2017-03-10 02:06:36 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:36 --> Controller Class Initialized
INFO - 2017-03-10 02:06:36 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:36 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:36 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:36 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:36 --> Total execution time: 0.0442
INFO - 2017-03-10 02:06:39 --> Config Class Initialized
INFO - 2017-03-10 02:06:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:39 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:39 --> URI Class Initialized
INFO - 2017-03-10 02:06:39 --> Router Class Initialized
INFO - 2017-03-10 02:06:39 --> Output Class Initialized
INFO - 2017-03-10 02:06:39 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:39 --> Input Class Initialized
INFO - 2017-03-10 02:06:39 --> Language Class Initialized
INFO - 2017-03-10 02:06:39 --> Loader Class Initialized
INFO - 2017-03-10 02:06:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:39 --> Controller Class Initialized
INFO - 2017-03-10 02:06:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:39 --> Total execution time: 0.0151
INFO - 2017-03-10 02:06:41 --> Config Class Initialized
INFO - 2017-03-10 02:06:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:41 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:41 --> URI Class Initialized
INFO - 2017-03-10 02:06:41 --> Router Class Initialized
INFO - 2017-03-10 02:06:41 --> Output Class Initialized
INFO - 2017-03-10 02:06:41 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:41 --> Input Class Initialized
INFO - 2017-03-10 02:06:41 --> Language Class Initialized
INFO - 2017-03-10 02:06:41 --> Loader Class Initialized
INFO - 2017-03-10 02:06:41 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:41 --> Controller Class Initialized
INFO - 2017-03-10 02:06:41 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:41 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:41 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:41 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:41 --> Total execution time: 0.0159
INFO - 2017-03-10 02:06:43 --> Config Class Initialized
INFO - 2017-03-10 02:06:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:43 --> URI Class Initialized
INFO - 2017-03-10 02:06:43 --> Router Class Initialized
INFO - 2017-03-10 02:06:43 --> Output Class Initialized
INFO - 2017-03-10 02:06:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:43 --> Input Class Initialized
INFO - 2017-03-10 02:06:43 --> Language Class Initialized
INFO - 2017-03-10 02:06:43 --> Loader Class Initialized
INFO - 2017-03-10 02:06:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:43 --> Controller Class Initialized
INFO - 2017-03-10 02:06:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:43 --> Total execution time: 0.0157
INFO - 2017-03-10 02:06:45 --> Config Class Initialized
INFO - 2017-03-10 02:06:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:45 --> URI Class Initialized
INFO - 2017-03-10 02:06:45 --> Router Class Initialized
INFO - 2017-03-10 02:06:45 --> Output Class Initialized
INFO - 2017-03-10 02:06:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:45 --> Input Class Initialized
INFO - 2017-03-10 02:06:45 --> Language Class Initialized
INFO - 2017-03-10 02:06:45 --> Loader Class Initialized
INFO - 2017-03-10 02:06:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:45 --> Controller Class Initialized
INFO - 2017-03-10 02:06:45 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:45 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:45 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:46 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:46 --> Total execution time: 0.0241
INFO - 2017-03-10 02:06:48 --> Config Class Initialized
INFO - 2017-03-10 02:06:48 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:48 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:48 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:48 --> URI Class Initialized
INFO - 2017-03-10 02:06:48 --> Router Class Initialized
INFO - 2017-03-10 02:06:48 --> Output Class Initialized
INFO - 2017-03-10 02:06:48 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:48 --> Input Class Initialized
INFO - 2017-03-10 02:06:48 --> Language Class Initialized
INFO - 2017-03-10 02:06:48 --> Loader Class Initialized
INFO - 2017-03-10 02:06:48 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:48 --> Controller Class Initialized
INFO - 2017-03-10 02:06:48 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:48 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:48 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:48 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:48 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:48 --> Total execution time: 0.0168
INFO - 2017-03-10 02:06:50 --> Config Class Initialized
INFO - 2017-03-10 02:06:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:50 --> URI Class Initialized
INFO - 2017-03-10 02:06:50 --> Router Class Initialized
INFO - 2017-03-10 02:06:50 --> Output Class Initialized
INFO - 2017-03-10 02:06:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:50 --> Input Class Initialized
INFO - 2017-03-10 02:06:50 --> Language Class Initialized
INFO - 2017-03-10 02:06:50 --> Loader Class Initialized
INFO - 2017-03-10 02:06:50 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:50 --> Controller Class Initialized
INFO - 2017-03-10 02:06:50 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:50 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:50 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:50 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:50 --> Total execution time: 0.0155
INFO - 2017-03-10 02:06:51 --> Config Class Initialized
INFO - 2017-03-10 02:06:51 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:51 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:51 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:51 --> URI Class Initialized
INFO - 2017-03-10 02:06:51 --> Router Class Initialized
INFO - 2017-03-10 02:06:51 --> Output Class Initialized
INFO - 2017-03-10 02:06:51 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:51 --> Input Class Initialized
INFO - 2017-03-10 02:06:51 --> Language Class Initialized
INFO - 2017-03-10 02:06:51 --> Loader Class Initialized
INFO - 2017-03-10 02:06:51 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:51 --> Controller Class Initialized
INFO - 2017-03-10 02:06:51 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:51 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:51 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:51 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:51 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:51 --> Total execution time: 0.0168
INFO - 2017-03-10 02:06:51 --> Config Class Initialized
INFO - 2017-03-10 02:06:51 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:51 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:51 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:51 --> URI Class Initialized
INFO - 2017-03-10 02:06:51 --> Router Class Initialized
INFO - 2017-03-10 02:06:51 --> Output Class Initialized
INFO - 2017-03-10 02:06:51 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:51 --> Input Class Initialized
INFO - 2017-03-10 02:06:51 --> Language Class Initialized
INFO - 2017-03-10 02:06:51 --> Loader Class Initialized
INFO - 2017-03-10 02:06:51 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:51 --> Controller Class Initialized
INFO - 2017-03-10 02:06:51 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:51 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:51 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:51 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:51 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:51 --> Total execution time: 0.0149
INFO - 2017-03-10 02:06:53 --> Config Class Initialized
INFO - 2017-03-10 02:06:53 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:53 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:53 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:53 --> URI Class Initialized
INFO - 2017-03-10 02:06:53 --> Router Class Initialized
INFO - 2017-03-10 02:06:53 --> Output Class Initialized
INFO - 2017-03-10 02:06:53 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:53 --> Input Class Initialized
INFO - 2017-03-10 02:06:53 --> Language Class Initialized
INFO - 2017-03-10 02:06:53 --> Loader Class Initialized
INFO - 2017-03-10 02:06:53 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:53 --> Controller Class Initialized
INFO - 2017-03-10 02:06:53 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:53 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:53 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:53 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:53 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:53 --> Total execution time: 0.0152
INFO - 2017-03-10 02:06:56 --> Config Class Initialized
INFO - 2017-03-10 02:06:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:56 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:56 --> URI Class Initialized
INFO - 2017-03-10 02:06:56 --> Router Class Initialized
INFO - 2017-03-10 02:06:56 --> Output Class Initialized
INFO - 2017-03-10 02:06:56 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:56 --> Input Class Initialized
INFO - 2017-03-10 02:06:56 --> Language Class Initialized
INFO - 2017-03-10 02:06:56 --> Loader Class Initialized
INFO - 2017-03-10 02:06:56 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:56 --> Controller Class Initialized
INFO - 2017-03-10 02:06:56 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:56 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:56 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:56 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:56 --> Total execution time: 0.0161
INFO - 2017-03-10 02:06:57 --> Config Class Initialized
INFO - 2017-03-10 02:06:57 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:06:57 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:06:57 --> Utf8 Class Initialized
INFO - 2017-03-10 02:06:57 --> URI Class Initialized
INFO - 2017-03-10 02:06:57 --> Router Class Initialized
INFO - 2017-03-10 02:06:57 --> Output Class Initialized
INFO - 2017-03-10 02:06:57 --> Security Class Initialized
DEBUG - 2017-03-10 02:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:06:57 --> Input Class Initialized
INFO - 2017-03-10 02:06:57 --> Language Class Initialized
INFO - 2017-03-10 02:06:57 --> Loader Class Initialized
INFO - 2017-03-10 02:06:57 --> Database Driver Class Initialized
INFO - 2017-03-10 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:06:57 --> Controller Class Initialized
INFO - 2017-03-10 02:06:57 --> Helper loaded: date_helper
INFO - 2017-03-10 02:06:57 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:06:57 --> Helper loaded: form_helper
INFO - 2017-03-10 02:06:57 --> Form Validation Class Initialized
INFO - 2017-03-10 02:06:58 --> Final output sent to browser
DEBUG - 2017-03-10 02:06:58 --> Total execution time: 0.0151
INFO - 2017-03-10 02:07:00 --> Config Class Initialized
INFO - 2017-03-10 02:07:00 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:00 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:00 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:00 --> URI Class Initialized
INFO - 2017-03-10 02:07:00 --> Router Class Initialized
INFO - 2017-03-10 02:07:00 --> Output Class Initialized
INFO - 2017-03-10 02:07:00 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:00 --> Input Class Initialized
INFO - 2017-03-10 02:07:00 --> Language Class Initialized
INFO - 2017-03-10 02:07:00 --> Loader Class Initialized
INFO - 2017-03-10 02:07:00 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:00 --> Controller Class Initialized
INFO - 2017-03-10 02:07:00 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:00 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:00 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:00 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:00 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:00 --> Total execution time: 0.0155
INFO - 2017-03-10 02:07:03 --> Config Class Initialized
INFO - 2017-03-10 02:07:03 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:03 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:03 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:03 --> URI Class Initialized
INFO - 2017-03-10 02:07:03 --> Router Class Initialized
INFO - 2017-03-10 02:07:03 --> Output Class Initialized
INFO - 2017-03-10 02:07:03 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:03 --> Input Class Initialized
INFO - 2017-03-10 02:07:03 --> Language Class Initialized
INFO - 2017-03-10 02:07:03 --> Loader Class Initialized
INFO - 2017-03-10 02:07:03 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:03 --> Controller Class Initialized
INFO - 2017-03-10 02:07:03 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:03 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:03 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:03 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:03 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:03 --> Total execution time: 0.0185
INFO - 2017-03-10 02:07:06 --> Config Class Initialized
INFO - 2017-03-10 02:07:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:06 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:06 --> URI Class Initialized
INFO - 2017-03-10 02:07:06 --> Router Class Initialized
INFO - 2017-03-10 02:07:06 --> Output Class Initialized
INFO - 2017-03-10 02:07:06 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:06 --> Input Class Initialized
INFO - 2017-03-10 02:07:06 --> Language Class Initialized
INFO - 2017-03-10 02:07:06 --> Loader Class Initialized
INFO - 2017-03-10 02:07:06 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:06 --> Controller Class Initialized
INFO - 2017-03-10 02:07:06 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:06 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:06 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:06 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:06 --> Total execution time: 0.0153
INFO - 2017-03-10 02:07:09 --> Config Class Initialized
INFO - 2017-03-10 02:07:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:09 --> URI Class Initialized
INFO - 2017-03-10 02:07:09 --> Router Class Initialized
INFO - 2017-03-10 02:07:09 --> Output Class Initialized
INFO - 2017-03-10 02:07:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:09 --> Input Class Initialized
INFO - 2017-03-10 02:07:09 --> Language Class Initialized
INFO - 2017-03-10 02:07:09 --> Loader Class Initialized
INFO - 2017-03-10 02:07:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:09 --> Controller Class Initialized
INFO - 2017-03-10 02:07:09 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:09 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:09 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:09 --> Total execution time: 0.0149
INFO - 2017-03-10 02:07:12 --> Config Class Initialized
INFO - 2017-03-10 02:07:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:12 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:12 --> URI Class Initialized
INFO - 2017-03-10 02:07:12 --> Router Class Initialized
INFO - 2017-03-10 02:07:12 --> Output Class Initialized
INFO - 2017-03-10 02:07:12 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:12 --> Input Class Initialized
INFO - 2017-03-10 02:07:12 --> Language Class Initialized
INFO - 2017-03-10 02:07:12 --> Loader Class Initialized
INFO - 2017-03-10 02:07:12 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:12 --> Controller Class Initialized
INFO - 2017-03-10 02:07:12 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:12 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:12 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:12 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:12 --> Total execution time: 0.0172
INFO - 2017-03-10 02:07:13 --> Config Class Initialized
INFO - 2017-03-10 02:07:13 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:13 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:13 --> URI Class Initialized
INFO - 2017-03-10 02:07:13 --> Router Class Initialized
INFO - 2017-03-10 02:07:13 --> Output Class Initialized
INFO - 2017-03-10 02:07:13 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:13 --> Input Class Initialized
INFO - 2017-03-10 02:07:13 --> Language Class Initialized
INFO - 2017-03-10 02:07:13 --> Loader Class Initialized
INFO - 2017-03-10 02:07:13 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:13 --> Controller Class Initialized
INFO - 2017-03-10 02:07:13 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:13 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:13 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:13 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:13 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:13 --> Total execution time: 0.0150
INFO - 2017-03-10 02:07:14 --> Config Class Initialized
INFO - 2017-03-10 02:07:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:14 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:14 --> URI Class Initialized
INFO - 2017-03-10 02:07:14 --> Router Class Initialized
INFO - 2017-03-10 02:07:14 --> Output Class Initialized
INFO - 2017-03-10 02:07:14 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:14 --> Input Class Initialized
INFO - 2017-03-10 02:07:14 --> Language Class Initialized
INFO - 2017-03-10 02:07:14 --> Loader Class Initialized
INFO - 2017-03-10 02:07:14 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:14 --> Controller Class Initialized
INFO - 2017-03-10 02:07:14 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:14 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:14 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:14 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:14 --> Total execution time: 0.0153
INFO - 2017-03-10 02:07:22 --> Config Class Initialized
INFO - 2017-03-10 02:07:22 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:22 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:22 --> URI Class Initialized
INFO - 2017-03-10 02:07:22 --> Router Class Initialized
INFO - 2017-03-10 02:07:22 --> Output Class Initialized
INFO - 2017-03-10 02:07:22 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:22 --> Input Class Initialized
INFO - 2017-03-10 02:07:22 --> Language Class Initialized
INFO - 2017-03-10 02:07:22 --> Loader Class Initialized
INFO - 2017-03-10 02:07:22 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:22 --> Controller Class Initialized
INFO - 2017-03-10 02:07:22 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:22 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:22 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:22 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:22 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:22 --> Total execution time: 0.0148
INFO - 2017-03-10 02:07:27 --> Config Class Initialized
INFO - 2017-03-10 02:07:27 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:27 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:27 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:27 --> URI Class Initialized
INFO - 2017-03-10 02:07:27 --> Router Class Initialized
INFO - 2017-03-10 02:07:27 --> Output Class Initialized
INFO - 2017-03-10 02:07:27 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:27 --> Input Class Initialized
INFO - 2017-03-10 02:07:27 --> Language Class Initialized
INFO - 2017-03-10 02:07:27 --> Loader Class Initialized
INFO - 2017-03-10 02:07:27 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:27 --> Controller Class Initialized
INFO - 2017-03-10 02:07:27 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:27 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:27 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:27 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:27 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:27 --> Total execution time: 0.0160
INFO - 2017-03-10 02:07:30 --> Config Class Initialized
INFO - 2017-03-10 02:07:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:30 --> URI Class Initialized
INFO - 2017-03-10 02:07:30 --> Router Class Initialized
INFO - 2017-03-10 02:07:30 --> Output Class Initialized
INFO - 2017-03-10 02:07:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:30 --> Input Class Initialized
INFO - 2017-03-10 02:07:30 --> Language Class Initialized
INFO - 2017-03-10 02:07:30 --> Loader Class Initialized
INFO - 2017-03-10 02:07:30 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:30 --> Controller Class Initialized
INFO - 2017-03-10 02:07:30 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:30 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:30 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:30 --> Total execution time: 0.0157
INFO - 2017-03-10 02:07:33 --> Config Class Initialized
INFO - 2017-03-10 02:07:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:33 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:33 --> URI Class Initialized
INFO - 2017-03-10 02:07:33 --> Router Class Initialized
INFO - 2017-03-10 02:07:33 --> Output Class Initialized
INFO - 2017-03-10 02:07:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:33 --> Input Class Initialized
INFO - 2017-03-10 02:07:33 --> Language Class Initialized
INFO - 2017-03-10 02:07:33 --> Loader Class Initialized
INFO - 2017-03-10 02:07:33 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:33 --> Controller Class Initialized
INFO - 2017-03-10 02:07:33 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:33 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:33 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:33 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:33 --> Total execution time: 0.0150
INFO - 2017-03-10 02:07:33 --> Config Class Initialized
INFO - 2017-03-10 02:07:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:33 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:33 --> URI Class Initialized
INFO - 2017-03-10 02:07:33 --> Router Class Initialized
INFO - 2017-03-10 02:07:33 --> Output Class Initialized
INFO - 2017-03-10 02:07:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:33 --> Input Class Initialized
INFO - 2017-03-10 02:07:33 --> Language Class Initialized
INFO - 2017-03-10 02:07:33 --> Loader Class Initialized
INFO - 2017-03-10 02:07:33 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:33 --> Controller Class Initialized
INFO - 2017-03-10 02:07:33 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:33 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:33 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:33 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:33 --> Total execution time: 0.0157
INFO - 2017-03-10 02:07:36 --> Config Class Initialized
INFO - 2017-03-10 02:07:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:36 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:36 --> URI Class Initialized
INFO - 2017-03-10 02:07:36 --> Router Class Initialized
INFO - 2017-03-10 02:07:36 --> Output Class Initialized
INFO - 2017-03-10 02:07:36 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:36 --> Input Class Initialized
INFO - 2017-03-10 02:07:36 --> Language Class Initialized
INFO - 2017-03-10 02:07:36 --> Loader Class Initialized
INFO - 2017-03-10 02:07:36 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:36 --> Controller Class Initialized
INFO - 2017-03-10 02:07:36 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:36 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:36 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:36 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:36 --> Total execution time: 0.0474
INFO - 2017-03-10 02:07:38 --> Config Class Initialized
INFO - 2017-03-10 02:07:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:38 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:38 --> URI Class Initialized
INFO - 2017-03-10 02:07:38 --> Router Class Initialized
INFO - 2017-03-10 02:07:38 --> Output Class Initialized
INFO - 2017-03-10 02:07:38 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:38 --> Input Class Initialized
INFO - 2017-03-10 02:07:38 --> Language Class Initialized
INFO - 2017-03-10 02:07:38 --> Loader Class Initialized
INFO - 2017-03-10 02:07:38 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:38 --> Controller Class Initialized
INFO - 2017-03-10 02:07:38 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:38 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:38 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:38 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:38 --> Total execution time: 0.0166
INFO - 2017-03-10 02:07:39 --> Config Class Initialized
INFO - 2017-03-10 02:07:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:39 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:39 --> URI Class Initialized
INFO - 2017-03-10 02:07:39 --> Router Class Initialized
INFO - 2017-03-10 02:07:39 --> Output Class Initialized
INFO - 2017-03-10 02:07:39 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:39 --> Input Class Initialized
INFO - 2017-03-10 02:07:39 --> Language Class Initialized
INFO - 2017-03-10 02:07:39 --> Loader Class Initialized
INFO - 2017-03-10 02:07:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:39 --> Controller Class Initialized
INFO - 2017-03-10 02:07:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:39 --> Total execution time: 0.0147
INFO - 2017-03-10 02:07:41 --> Config Class Initialized
INFO - 2017-03-10 02:07:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:41 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:41 --> URI Class Initialized
INFO - 2017-03-10 02:07:41 --> Router Class Initialized
INFO - 2017-03-10 02:07:41 --> Output Class Initialized
INFO - 2017-03-10 02:07:41 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:41 --> Input Class Initialized
INFO - 2017-03-10 02:07:41 --> Language Class Initialized
INFO - 2017-03-10 02:07:41 --> Loader Class Initialized
INFO - 2017-03-10 02:07:41 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:41 --> Controller Class Initialized
INFO - 2017-03-10 02:07:41 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:41 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:41 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:41 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:41 --> Total execution time: 0.0151
INFO - 2017-03-10 02:07:43 --> Config Class Initialized
INFO - 2017-03-10 02:07:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:43 --> URI Class Initialized
INFO - 2017-03-10 02:07:43 --> Router Class Initialized
INFO - 2017-03-10 02:07:43 --> Output Class Initialized
INFO - 2017-03-10 02:07:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:43 --> Input Class Initialized
INFO - 2017-03-10 02:07:43 --> Language Class Initialized
INFO - 2017-03-10 02:07:43 --> Loader Class Initialized
INFO - 2017-03-10 02:07:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:43 --> Controller Class Initialized
INFO - 2017-03-10 02:07:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:43 --> Total execution time: 0.0172
INFO - 2017-03-10 02:07:44 --> Config Class Initialized
INFO - 2017-03-10 02:07:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:44 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:44 --> URI Class Initialized
INFO - 2017-03-10 02:07:44 --> Router Class Initialized
INFO - 2017-03-10 02:07:44 --> Output Class Initialized
INFO - 2017-03-10 02:07:44 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:44 --> Input Class Initialized
INFO - 2017-03-10 02:07:44 --> Language Class Initialized
INFO - 2017-03-10 02:07:44 --> Loader Class Initialized
INFO - 2017-03-10 02:07:44 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:44 --> Controller Class Initialized
INFO - 2017-03-10 02:07:44 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:44 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:44 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:44 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:44 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:44 --> Total execution time: 0.0211
INFO - 2017-03-10 02:07:45 --> Config Class Initialized
INFO - 2017-03-10 02:07:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:45 --> URI Class Initialized
INFO - 2017-03-10 02:07:45 --> Router Class Initialized
INFO - 2017-03-10 02:07:45 --> Output Class Initialized
INFO - 2017-03-10 02:07:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:45 --> Input Class Initialized
INFO - 2017-03-10 02:07:45 --> Language Class Initialized
INFO - 2017-03-10 02:07:45 --> Loader Class Initialized
INFO - 2017-03-10 02:07:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:45 --> Controller Class Initialized
INFO - 2017-03-10 02:07:45 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:45 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:45 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:45 --> Total execution time: 0.0154
INFO - 2017-03-10 02:07:47 --> Config Class Initialized
INFO - 2017-03-10 02:07:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:47 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:47 --> URI Class Initialized
INFO - 2017-03-10 02:07:47 --> Router Class Initialized
INFO - 2017-03-10 02:07:47 --> Output Class Initialized
INFO - 2017-03-10 02:07:47 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:47 --> Input Class Initialized
INFO - 2017-03-10 02:07:47 --> Language Class Initialized
INFO - 2017-03-10 02:07:47 --> Loader Class Initialized
INFO - 2017-03-10 02:07:47 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:47 --> Controller Class Initialized
INFO - 2017-03-10 02:07:47 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:47 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:47 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:47 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:47 --> Total execution time: 0.0147
INFO - 2017-03-10 02:07:48 --> Config Class Initialized
INFO - 2017-03-10 02:07:48 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:48 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:48 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:48 --> URI Class Initialized
INFO - 2017-03-10 02:07:48 --> Router Class Initialized
INFO - 2017-03-10 02:07:48 --> Output Class Initialized
INFO - 2017-03-10 02:07:48 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:48 --> Input Class Initialized
INFO - 2017-03-10 02:07:48 --> Language Class Initialized
INFO - 2017-03-10 02:07:48 --> Loader Class Initialized
INFO - 2017-03-10 02:07:48 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:48 --> Controller Class Initialized
INFO - 2017-03-10 02:07:48 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:48 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:48 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:48 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:48 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:48 --> Total execution time: 0.0152
INFO - 2017-03-10 02:07:53 --> Config Class Initialized
INFO - 2017-03-10 02:07:53 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:53 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:53 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:53 --> URI Class Initialized
INFO - 2017-03-10 02:07:53 --> Router Class Initialized
INFO - 2017-03-10 02:07:53 --> Output Class Initialized
INFO - 2017-03-10 02:07:53 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:53 --> Input Class Initialized
INFO - 2017-03-10 02:07:53 --> Language Class Initialized
INFO - 2017-03-10 02:07:53 --> Loader Class Initialized
INFO - 2017-03-10 02:07:53 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:53 --> Controller Class Initialized
INFO - 2017-03-10 02:07:53 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:53 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:53 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:53 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:53 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:53 --> Total execution time: 0.0149
INFO - 2017-03-10 02:07:54 --> Config Class Initialized
INFO - 2017-03-10 02:07:54 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:54 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:54 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:54 --> URI Class Initialized
INFO - 2017-03-10 02:07:54 --> Router Class Initialized
INFO - 2017-03-10 02:07:54 --> Output Class Initialized
INFO - 2017-03-10 02:07:54 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:54 --> Input Class Initialized
INFO - 2017-03-10 02:07:54 --> Language Class Initialized
INFO - 2017-03-10 02:07:54 --> Loader Class Initialized
INFO - 2017-03-10 02:07:54 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:54 --> Controller Class Initialized
INFO - 2017-03-10 02:07:54 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:54 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:54 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:54 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:54 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:54 --> Total execution time: 0.0147
INFO - 2017-03-10 02:07:55 --> Config Class Initialized
INFO - 2017-03-10 02:07:55 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:55 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:55 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:55 --> URI Class Initialized
INFO - 2017-03-10 02:07:55 --> Router Class Initialized
INFO - 2017-03-10 02:07:55 --> Output Class Initialized
INFO - 2017-03-10 02:07:55 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:55 --> Input Class Initialized
INFO - 2017-03-10 02:07:55 --> Language Class Initialized
INFO - 2017-03-10 02:07:55 --> Loader Class Initialized
INFO - 2017-03-10 02:07:55 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:55 --> Controller Class Initialized
INFO - 2017-03-10 02:07:55 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:55 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:55 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:55 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:55 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:55 --> Total execution time: 0.0148
INFO - 2017-03-10 02:07:56 --> Config Class Initialized
INFO - 2017-03-10 02:07:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:56 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:56 --> URI Class Initialized
INFO - 2017-03-10 02:07:56 --> Router Class Initialized
INFO - 2017-03-10 02:07:56 --> Output Class Initialized
INFO - 2017-03-10 02:07:56 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:56 --> Input Class Initialized
INFO - 2017-03-10 02:07:56 --> Language Class Initialized
INFO - 2017-03-10 02:07:56 --> Loader Class Initialized
INFO - 2017-03-10 02:07:56 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:56 --> Controller Class Initialized
INFO - 2017-03-10 02:07:56 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:56 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:56 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:56 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:56 --> Total execution time: 0.0159
INFO - 2017-03-10 02:07:57 --> Config Class Initialized
INFO - 2017-03-10 02:07:57 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:57 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:57 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:57 --> URI Class Initialized
INFO - 2017-03-10 02:07:57 --> Router Class Initialized
INFO - 2017-03-10 02:07:57 --> Output Class Initialized
INFO - 2017-03-10 02:07:57 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:57 --> Input Class Initialized
INFO - 2017-03-10 02:07:57 --> Language Class Initialized
INFO - 2017-03-10 02:07:57 --> Loader Class Initialized
INFO - 2017-03-10 02:07:57 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:57 --> Controller Class Initialized
INFO - 2017-03-10 02:07:57 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:57 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:57 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:57 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:57 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:57 --> Total execution time: 0.0156
INFO - 2017-03-10 02:07:59 --> Config Class Initialized
INFO - 2017-03-10 02:07:59 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:07:59 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:07:59 --> Utf8 Class Initialized
INFO - 2017-03-10 02:07:59 --> URI Class Initialized
INFO - 2017-03-10 02:07:59 --> Router Class Initialized
INFO - 2017-03-10 02:07:59 --> Output Class Initialized
INFO - 2017-03-10 02:07:59 --> Security Class Initialized
DEBUG - 2017-03-10 02:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:07:59 --> Input Class Initialized
INFO - 2017-03-10 02:07:59 --> Language Class Initialized
INFO - 2017-03-10 02:07:59 --> Loader Class Initialized
INFO - 2017-03-10 02:07:59 --> Database Driver Class Initialized
INFO - 2017-03-10 02:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:07:59 --> Controller Class Initialized
INFO - 2017-03-10 02:07:59 --> Helper loaded: date_helper
INFO - 2017-03-10 02:07:59 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:07:59 --> Helper loaded: form_helper
INFO - 2017-03-10 02:07:59 --> Form Validation Class Initialized
INFO - 2017-03-10 02:07:59 --> Final output sent to browser
DEBUG - 2017-03-10 02:07:59 --> Total execution time: 0.0145
INFO - 2017-03-10 02:08:03 --> Config Class Initialized
INFO - 2017-03-10 02:08:03 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:03 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:03 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:03 --> URI Class Initialized
INFO - 2017-03-10 02:08:03 --> Router Class Initialized
INFO - 2017-03-10 02:08:03 --> Output Class Initialized
INFO - 2017-03-10 02:08:03 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:03 --> Input Class Initialized
INFO - 2017-03-10 02:08:03 --> Language Class Initialized
INFO - 2017-03-10 02:08:03 --> Loader Class Initialized
INFO - 2017-03-10 02:08:03 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:03 --> Controller Class Initialized
INFO - 2017-03-10 02:08:03 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:03 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:03 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:03 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:03 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:03 --> Total execution time: 0.0155
INFO - 2017-03-10 02:08:05 --> Config Class Initialized
INFO - 2017-03-10 02:08:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:05 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:05 --> URI Class Initialized
INFO - 2017-03-10 02:08:05 --> Router Class Initialized
INFO - 2017-03-10 02:08:05 --> Output Class Initialized
INFO - 2017-03-10 02:08:05 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:05 --> Input Class Initialized
INFO - 2017-03-10 02:08:05 --> Language Class Initialized
INFO - 2017-03-10 02:08:05 --> Loader Class Initialized
INFO - 2017-03-10 02:08:05 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:05 --> Controller Class Initialized
INFO - 2017-03-10 02:08:05 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:05 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:05 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:05 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:05 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:05 --> Total execution time: 0.0152
INFO - 2017-03-10 02:08:10 --> Config Class Initialized
INFO - 2017-03-10 02:08:10 --> Config Class Initialized
INFO - 2017-03-10 02:08:10 --> Hooks Class Initialized
INFO - 2017-03-10 02:08:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:10 --> UTF-8 Support Enabled
DEBUG - 2017-03-10 02:08:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:10 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:10 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:10 --> URI Class Initialized
INFO - 2017-03-10 02:08:10 --> URI Class Initialized
INFO - 2017-03-10 02:08:10 --> Router Class Initialized
INFO - 2017-03-10 02:08:10 --> Router Class Initialized
INFO - 2017-03-10 02:08:10 --> Output Class Initialized
INFO - 2017-03-10 02:08:10 --> Output Class Initialized
INFO - 2017-03-10 02:08:10 --> Security Class Initialized
INFO - 2017-03-10 02:08:10 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:10 --> Input Class Initialized
DEBUG - 2017-03-10 02:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:10 --> Language Class Initialized
INFO - 2017-03-10 02:08:10 --> Input Class Initialized
INFO - 2017-03-10 02:08:10 --> Language Class Initialized
INFO - 2017-03-10 02:08:10 --> Loader Class Initialized
INFO - 2017-03-10 02:08:10 --> Loader Class Initialized
INFO - 2017-03-10 02:08:11 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:11 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:11 --> Controller Class Initialized
INFO - 2017-03-10 02:08:11 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:11 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:11 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:11 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:11 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:11 --> Total execution time: 1.1686
INFO - 2017-03-10 02:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:11 --> Controller Class Initialized
INFO - 2017-03-10 02:08:11 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:11 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:11 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:11 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:11 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:11 --> Total execution time: 1.1872
INFO - 2017-03-10 02:08:13 --> Config Class Initialized
INFO - 2017-03-10 02:08:13 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:13 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:13 --> URI Class Initialized
INFO - 2017-03-10 02:08:13 --> Router Class Initialized
INFO - 2017-03-10 02:08:13 --> Output Class Initialized
INFO - 2017-03-10 02:08:13 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:13 --> Input Class Initialized
INFO - 2017-03-10 02:08:13 --> Language Class Initialized
INFO - 2017-03-10 02:08:13 --> Loader Class Initialized
INFO - 2017-03-10 02:08:13 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:13 --> Controller Class Initialized
INFO - 2017-03-10 02:08:13 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:13 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:13 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:13 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:13 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:13 --> Total execution time: 0.0150
INFO - 2017-03-10 02:08:14 --> Config Class Initialized
INFO - 2017-03-10 02:08:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:14 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:14 --> URI Class Initialized
INFO - 2017-03-10 02:08:14 --> Router Class Initialized
INFO - 2017-03-10 02:08:14 --> Output Class Initialized
INFO - 2017-03-10 02:08:14 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:14 --> Input Class Initialized
INFO - 2017-03-10 02:08:14 --> Language Class Initialized
INFO - 2017-03-10 02:08:14 --> Loader Class Initialized
INFO - 2017-03-10 02:08:14 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:14 --> Controller Class Initialized
INFO - 2017-03-10 02:08:14 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:14 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:14 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:14 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:14 --> Total execution time: 0.0157
INFO - 2017-03-10 02:08:15 --> Config Class Initialized
INFO - 2017-03-10 02:08:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:15 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:15 --> URI Class Initialized
INFO - 2017-03-10 02:08:15 --> Router Class Initialized
INFO - 2017-03-10 02:08:15 --> Output Class Initialized
INFO - 2017-03-10 02:08:15 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:15 --> Input Class Initialized
INFO - 2017-03-10 02:08:15 --> Language Class Initialized
INFO - 2017-03-10 02:08:15 --> Loader Class Initialized
INFO - 2017-03-10 02:08:15 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:15 --> Controller Class Initialized
INFO - 2017-03-10 02:08:15 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:15 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:15 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:15 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:15 --> Total execution time: 0.0167
INFO - 2017-03-10 02:08:18 --> Config Class Initialized
INFO - 2017-03-10 02:08:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:18 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:18 --> URI Class Initialized
INFO - 2017-03-10 02:08:18 --> Router Class Initialized
INFO - 2017-03-10 02:08:18 --> Output Class Initialized
INFO - 2017-03-10 02:08:18 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:18 --> Input Class Initialized
INFO - 2017-03-10 02:08:18 --> Language Class Initialized
INFO - 2017-03-10 02:08:18 --> Loader Class Initialized
INFO - 2017-03-10 02:08:18 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:18 --> Controller Class Initialized
INFO - 2017-03-10 02:08:18 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:18 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:18 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:18 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:18 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:18 --> Total execution time: 0.0185
INFO - 2017-03-10 02:08:19 --> Config Class Initialized
INFO - 2017-03-10 02:08:19 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:19 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:19 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:19 --> URI Class Initialized
INFO - 2017-03-10 02:08:19 --> Router Class Initialized
INFO - 2017-03-10 02:08:19 --> Output Class Initialized
INFO - 2017-03-10 02:08:19 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:19 --> Input Class Initialized
INFO - 2017-03-10 02:08:19 --> Language Class Initialized
INFO - 2017-03-10 02:08:19 --> Loader Class Initialized
INFO - 2017-03-10 02:08:19 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:19 --> Controller Class Initialized
INFO - 2017-03-10 02:08:19 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:19 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:19 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:19 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:19 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:19 --> Total execution time: 0.0601
INFO - 2017-03-10 02:08:20 --> Config Class Initialized
INFO - 2017-03-10 02:08:20 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:20 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:20 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:20 --> URI Class Initialized
INFO - 2017-03-10 02:08:20 --> Router Class Initialized
INFO - 2017-03-10 02:08:20 --> Output Class Initialized
INFO - 2017-03-10 02:08:20 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:20 --> Input Class Initialized
INFO - 2017-03-10 02:08:20 --> Language Class Initialized
INFO - 2017-03-10 02:08:20 --> Loader Class Initialized
INFO - 2017-03-10 02:08:20 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:20 --> Controller Class Initialized
INFO - 2017-03-10 02:08:20 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:20 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:20 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:20 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:20 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:20 --> Total execution time: 0.0375
INFO - 2017-03-10 02:08:23 --> Config Class Initialized
INFO - 2017-03-10 02:08:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:23 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:23 --> URI Class Initialized
INFO - 2017-03-10 02:08:23 --> Router Class Initialized
INFO - 2017-03-10 02:08:23 --> Output Class Initialized
INFO - 2017-03-10 02:08:23 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:23 --> Input Class Initialized
INFO - 2017-03-10 02:08:23 --> Language Class Initialized
INFO - 2017-03-10 02:08:23 --> Loader Class Initialized
INFO - 2017-03-10 02:08:23 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:23 --> Controller Class Initialized
INFO - 2017-03-10 02:08:23 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:23 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:23 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:23 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:23 --> Total execution time: 0.0160
INFO - 2017-03-10 02:08:23 --> Config Class Initialized
INFO - 2017-03-10 02:08:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:23 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:23 --> URI Class Initialized
INFO - 2017-03-10 02:08:23 --> Router Class Initialized
INFO - 2017-03-10 02:08:23 --> Output Class Initialized
INFO - 2017-03-10 02:08:23 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:23 --> Input Class Initialized
INFO - 2017-03-10 02:08:23 --> Language Class Initialized
INFO - 2017-03-10 02:08:23 --> Loader Class Initialized
INFO - 2017-03-10 02:08:23 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:23 --> Controller Class Initialized
INFO - 2017-03-10 02:08:23 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:23 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:23 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:23 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:23 --> Total execution time: 0.0176
INFO - 2017-03-10 02:08:26 --> Config Class Initialized
INFO - 2017-03-10 02:08:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:26 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:26 --> URI Class Initialized
INFO - 2017-03-10 02:08:26 --> Router Class Initialized
INFO - 2017-03-10 02:08:26 --> Output Class Initialized
INFO - 2017-03-10 02:08:26 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:26 --> Input Class Initialized
INFO - 2017-03-10 02:08:26 --> Language Class Initialized
INFO - 2017-03-10 02:08:26 --> Loader Class Initialized
INFO - 2017-03-10 02:08:26 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:26 --> Controller Class Initialized
INFO - 2017-03-10 02:08:26 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:26 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:26 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:26 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:26 --> Total execution time: 0.0147
INFO - 2017-03-10 02:08:30 --> Config Class Initialized
INFO - 2017-03-10 02:08:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:30 --> URI Class Initialized
INFO - 2017-03-10 02:08:30 --> Router Class Initialized
INFO - 2017-03-10 02:08:30 --> Output Class Initialized
INFO - 2017-03-10 02:08:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:30 --> Input Class Initialized
INFO - 2017-03-10 02:08:30 --> Language Class Initialized
INFO - 2017-03-10 02:08:30 --> Loader Class Initialized
INFO - 2017-03-10 02:08:30 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:30 --> Controller Class Initialized
INFO - 2017-03-10 02:08:30 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:30 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:30 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:30 --> Total execution time: 0.0149
INFO - 2017-03-10 02:08:35 --> Config Class Initialized
INFO - 2017-03-10 02:08:35 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:35 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:35 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:35 --> URI Class Initialized
INFO - 2017-03-10 02:08:35 --> Router Class Initialized
INFO - 2017-03-10 02:08:35 --> Output Class Initialized
INFO - 2017-03-10 02:08:35 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:35 --> Input Class Initialized
INFO - 2017-03-10 02:08:35 --> Language Class Initialized
INFO - 2017-03-10 02:08:35 --> Loader Class Initialized
INFO - 2017-03-10 02:08:35 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:35 --> Controller Class Initialized
INFO - 2017-03-10 02:08:35 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:35 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:35 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:35 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:35 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:35 --> Total execution time: 0.0152
INFO - 2017-03-10 02:08:39 --> Config Class Initialized
INFO - 2017-03-10 02:08:39 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:39 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:39 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:39 --> URI Class Initialized
INFO - 2017-03-10 02:08:39 --> Router Class Initialized
INFO - 2017-03-10 02:08:39 --> Output Class Initialized
INFO - 2017-03-10 02:08:39 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:39 --> Input Class Initialized
INFO - 2017-03-10 02:08:39 --> Language Class Initialized
INFO - 2017-03-10 02:08:39 --> Loader Class Initialized
INFO - 2017-03-10 02:08:39 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:39 --> Controller Class Initialized
INFO - 2017-03-10 02:08:39 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:39 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:39 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:39 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:39 --> Total execution time: 0.0173
INFO - 2017-03-10 02:08:40 --> Config Class Initialized
INFO - 2017-03-10 02:08:40 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:40 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:40 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:40 --> URI Class Initialized
INFO - 2017-03-10 02:08:40 --> Router Class Initialized
INFO - 2017-03-10 02:08:40 --> Output Class Initialized
INFO - 2017-03-10 02:08:40 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:40 --> Input Class Initialized
INFO - 2017-03-10 02:08:40 --> Language Class Initialized
INFO - 2017-03-10 02:08:40 --> Loader Class Initialized
INFO - 2017-03-10 02:08:40 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:40 --> Controller Class Initialized
INFO - 2017-03-10 02:08:40 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:40 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:40 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:40 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:40 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:40 --> Total execution time: 0.0527
INFO - 2017-03-10 02:08:43 --> Config Class Initialized
INFO - 2017-03-10 02:08:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:43 --> URI Class Initialized
INFO - 2017-03-10 02:08:43 --> Router Class Initialized
INFO - 2017-03-10 02:08:43 --> Output Class Initialized
INFO - 2017-03-10 02:08:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:43 --> Input Class Initialized
INFO - 2017-03-10 02:08:43 --> Language Class Initialized
INFO - 2017-03-10 02:08:43 --> Loader Class Initialized
INFO - 2017-03-10 02:08:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:43 --> Controller Class Initialized
INFO - 2017-03-10 02:08:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:43 --> Total execution time: 0.0149
INFO - 2017-03-10 02:08:45 --> Config Class Initialized
INFO - 2017-03-10 02:08:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:45 --> URI Class Initialized
INFO - 2017-03-10 02:08:45 --> Router Class Initialized
INFO - 2017-03-10 02:08:45 --> Output Class Initialized
INFO - 2017-03-10 02:08:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:45 --> Input Class Initialized
INFO - 2017-03-10 02:08:45 --> Language Class Initialized
INFO - 2017-03-10 02:08:45 --> Loader Class Initialized
INFO - 2017-03-10 02:08:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:45 --> Controller Class Initialized
INFO - 2017-03-10 02:08:45 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:45 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:45 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:45 --> Total execution time: 0.8400
INFO - 2017-03-10 02:08:45 --> Config Class Initialized
INFO - 2017-03-10 02:08:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:45 --> URI Class Initialized
INFO - 2017-03-10 02:08:45 --> Router Class Initialized
INFO - 2017-03-10 02:08:45 --> Output Class Initialized
INFO - 2017-03-10 02:08:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:45 --> Input Class Initialized
INFO - 2017-03-10 02:08:45 --> Language Class Initialized
INFO - 2017-03-10 02:08:45 --> Loader Class Initialized
INFO - 2017-03-10 02:08:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:45 --> Controller Class Initialized
INFO - 2017-03-10 02:08:45 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:45 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:45 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:45 --> Total execution time: 0.0152
INFO - 2017-03-10 02:08:50 --> Config Class Initialized
INFO - 2017-03-10 02:08:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:50 --> URI Class Initialized
INFO - 2017-03-10 02:08:50 --> Router Class Initialized
INFO - 2017-03-10 02:08:50 --> Output Class Initialized
INFO - 2017-03-10 02:08:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:50 --> Input Class Initialized
INFO - 2017-03-10 02:08:50 --> Language Class Initialized
INFO - 2017-03-10 02:08:50 --> Loader Class Initialized
INFO - 2017-03-10 02:08:50 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:50 --> Controller Class Initialized
INFO - 2017-03-10 02:08:50 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:50 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:50 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:50 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:50 --> Total execution time: 0.1188
INFO - 2017-03-10 02:08:51 --> Config Class Initialized
INFO - 2017-03-10 02:08:51 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:08:51 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:08:51 --> Utf8 Class Initialized
INFO - 2017-03-10 02:08:51 --> URI Class Initialized
INFO - 2017-03-10 02:08:51 --> Router Class Initialized
INFO - 2017-03-10 02:08:51 --> Output Class Initialized
INFO - 2017-03-10 02:08:51 --> Security Class Initialized
DEBUG - 2017-03-10 02:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:08:51 --> Input Class Initialized
INFO - 2017-03-10 02:08:51 --> Language Class Initialized
INFO - 2017-03-10 02:08:51 --> Loader Class Initialized
INFO - 2017-03-10 02:08:51 --> Database Driver Class Initialized
INFO - 2017-03-10 02:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:08:51 --> Controller Class Initialized
INFO - 2017-03-10 02:08:51 --> Helper loaded: date_helper
INFO - 2017-03-10 02:08:51 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:08:51 --> Helper loaded: form_helper
INFO - 2017-03-10 02:08:51 --> Form Validation Class Initialized
INFO - 2017-03-10 02:08:51 --> Final output sent to browser
DEBUG - 2017-03-10 02:08:51 --> Total execution time: 0.0159
INFO - 2017-03-10 02:10:36 --> Config Class Initialized
INFO - 2017-03-10 02:10:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:36 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:36 --> URI Class Initialized
INFO - 2017-03-10 02:10:36 --> Router Class Initialized
INFO - 2017-03-10 02:10:37 --> Output Class Initialized
INFO - 2017-03-10 02:10:37 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:37 --> Input Class Initialized
INFO - 2017-03-10 02:10:37 --> Language Class Initialized
INFO - 2017-03-10 02:10:37 --> Loader Class Initialized
INFO - 2017-03-10 02:10:37 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:37 --> Controller Class Initialized
INFO - 2017-03-10 02:10:37 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:37 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:37 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:37 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:37 --> Total execution time: 1.1407
INFO - 2017-03-10 02:10:43 --> Config Class Initialized
INFO - 2017-03-10 02:10:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:43 --> URI Class Initialized
INFO - 2017-03-10 02:10:43 --> Router Class Initialized
INFO - 2017-03-10 02:10:43 --> Output Class Initialized
INFO - 2017-03-10 02:10:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:43 --> Input Class Initialized
INFO - 2017-03-10 02:10:43 --> Language Class Initialized
INFO - 2017-03-10 02:10:43 --> Loader Class Initialized
INFO - 2017-03-10 02:10:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:43 --> Controller Class Initialized
INFO - 2017-03-10 02:10:43 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:43 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:43 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:43 --> Total execution time: 0.0149
INFO - 2017-03-10 02:10:45 --> Config Class Initialized
INFO - 2017-03-10 02:10:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:45 --> URI Class Initialized
INFO - 2017-03-10 02:10:45 --> Router Class Initialized
INFO - 2017-03-10 02:10:45 --> Output Class Initialized
INFO - 2017-03-10 02:10:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:45 --> Input Class Initialized
INFO - 2017-03-10 02:10:45 --> Language Class Initialized
INFO - 2017-03-10 02:10:45 --> Loader Class Initialized
INFO - 2017-03-10 02:10:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:45 --> Controller Class Initialized
INFO - 2017-03-10 02:10:45 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:45 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:45 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:45 --> Total execution time: 0.0179
INFO - 2017-03-10 02:10:46 --> Config Class Initialized
INFO - 2017-03-10 02:10:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:46 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:46 --> URI Class Initialized
INFO - 2017-03-10 02:10:46 --> Router Class Initialized
INFO - 2017-03-10 02:10:46 --> Output Class Initialized
INFO - 2017-03-10 02:10:46 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:46 --> Input Class Initialized
INFO - 2017-03-10 02:10:46 --> Language Class Initialized
INFO - 2017-03-10 02:10:46 --> Loader Class Initialized
INFO - 2017-03-10 02:10:46 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:46 --> Controller Class Initialized
INFO - 2017-03-10 02:10:46 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:46 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:46 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:46 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:46 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:46 --> Total execution time: 0.0148
INFO - 2017-03-10 02:10:50 --> Config Class Initialized
INFO - 2017-03-10 02:10:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:50 --> URI Class Initialized
INFO - 2017-03-10 02:10:50 --> Router Class Initialized
INFO - 2017-03-10 02:10:50 --> Output Class Initialized
INFO - 2017-03-10 02:10:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:50 --> Input Class Initialized
INFO - 2017-03-10 02:10:50 --> Language Class Initialized
INFO - 2017-03-10 02:10:50 --> Loader Class Initialized
INFO - 2017-03-10 02:10:50 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:50 --> Controller Class Initialized
INFO - 2017-03-10 02:10:50 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:50 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:50 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:50 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:50 --> Total execution time: 0.0163
INFO - 2017-03-10 02:10:50 --> Config Class Initialized
INFO - 2017-03-10 02:10:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:50 --> URI Class Initialized
INFO - 2017-03-10 02:10:50 --> Router Class Initialized
INFO - 2017-03-10 02:10:50 --> Output Class Initialized
INFO - 2017-03-10 02:10:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:50 --> Input Class Initialized
INFO - 2017-03-10 02:10:50 --> Language Class Initialized
INFO - 2017-03-10 02:10:50 --> Loader Class Initialized
INFO - 2017-03-10 02:10:50 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:50 --> Controller Class Initialized
INFO - 2017-03-10 02:10:50 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:50 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:50 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:50 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:50 --> Total execution time: 0.0154
INFO - 2017-03-10 02:10:50 --> Config Class Initialized
INFO - 2017-03-10 02:10:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:50 --> URI Class Initialized
INFO - 2017-03-10 02:10:50 --> Router Class Initialized
INFO - 2017-03-10 02:10:50 --> Output Class Initialized
INFO - 2017-03-10 02:10:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:50 --> Input Class Initialized
INFO - 2017-03-10 02:10:50 --> Language Class Initialized
INFO - 2017-03-10 02:10:50 --> Loader Class Initialized
INFO - 2017-03-10 02:10:50 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:50 --> Controller Class Initialized
INFO - 2017-03-10 02:10:50 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:50 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:50 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:50 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:50 --> Total execution time: 0.0151
INFO - 2017-03-10 02:10:54 --> Config Class Initialized
INFO - 2017-03-10 02:10:54 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:54 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:54 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:54 --> URI Class Initialized
INFO - 2017-03-10 02:10:54 --> Router Class Initialized
INFO - 2017-03-10 02:10:54 --> Output Class Initialized
INFO - 2017-03-10 02:10:54 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:54 --> Input Class Initialized
INFO - 2017-03-10 02:10:54 --> Language Class Initialized
INFO - 2017-03-10 02:10:54 --> Loader Class Initialized
INFO - 2017-03-10 02:10:54 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:54 --> Controller Class Initialized
INFO - 2017-03-10 02:10:54 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:54 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:54 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:54 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:54 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:54 --> Total execution time: 0.0156
INFO - 2017-03-10 02:10:58 --> Config Class Initialized
INFO - 2017-03-10 02:10:58 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:10:58 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:10:58 --> Utf8 Class Initialized
INFO - 2017-03-10 02:10:58 --> URI Class Initialized
INFO - 2017-03-10 02:10:58 --> Router Class Initialized
INFO - 2017-03-10 02:10:58 --> Output Class Initialized
INFO - 2017-03-10 02:10:58 --> Security Class Initialized
DEBUG - 2017-03-10 02:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:10:58 --> Input Class Initialized
INFO - 2017-03-10 02:10:58 --> Language Class Initialized
INFO - 2017-03-10 02:10:58 --> Loader Class Initialized
INFO - 2017-03-10 02:10:58 --> Database Driver Class Initialized
INFO - 2017-03-10 02:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:10:58 --> Controller Class Initialized
INFO - 2017-03-10 02:10:58 --> Helper loaded: date_helper
INFO - 2017-03-10 02:10:58 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:10:58 --> Helper loaded: form_helper
INFO - 2017-03-10 02:10:58 --> Form Validation Class Initialized
INFO - 2017-03-10 02:10:58 --> Final output sent to browser
DEBUG - 2017-03-10 02:10:58 --> Total execution time: 0.0611
INFO - 2017-03-10 02:11:02 --> Config Class Initialized
INFO - 2017-03-10 02:11:02 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:02 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:02 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:02 --> URI Class Initialized
INFO - 2017-03-10 02:11:02 --> Router Class Initialized
INFO - 2017-03-10 02:11:02 --> Output Class Initialized
INFO - 2017-03-10 02:11:02 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:02 --> Input Class Initialized
INFO - 2017-03-10 02:11:02 --> Language Class Initialized
INFO - 2017-03-10 02:11:02 --> Loader Class Initialized
INFO - 2017-03-10 02:11:02 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:02 --> Controller Class Initialized
INFO - 2017-03-10 02:11:02 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:02 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:02 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:02 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:02 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:02 --> Total execution time: 0.0154
INFO - 2017-03-10 02:11:06 --> Config Class Initialized
INFO - 2017-03-10 02:11:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:06 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:06 --> URI Class Initialized
INFO - 2017-03-10 02:11:06 --> Router Class Initialized
INFO - 2017-03-10 02:11:06 --> Output Class Initialized
INFO - 2017-03-10 02:11:06 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:06 --> Input Class Initialized
INFO - 2017-03-10 02:11:06 --> Language Class Initialized
INFO - 2017-03-10 02:11:06 --> Loader Class Initialized
INFO - 2017-03-10 02:11:06 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:06 --> Controller Class Initialized
INFO - 2017-03-10 02:11:06 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:06 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:06 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:06 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:06 --> Total execution time: 0.0157
INFO - 2017-03-10 02:11:09 --> Config Class Initialized
INFO - 2017-03-10 02:11:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:09 --> URI Class Initialized
INFO - 2017-03-10 02:11:09 --> Router Class Initialized
INFO - 2017-03-10 02:11:09 --> Output Class Initialized
INFO - 2017-03-10 02:11:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:09 --> Input Class Initialized
INFO - 2017-03-10 02:11:09 --> Language Class Initialized
INFO - 2017-03-10 02:11:09 --> Loader Class Initialized
INFO - 2017-03-10 02:11:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:09 --> Controller Class Initialized
INFO - 2017-03-10 02:11:09 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:09 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:09 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:09 --> Total execution time: 0.0150
INFO - 2017-03-10 02:11:14 --> Config Class Initialized
INFO - 2017-03-10 02:11:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:14 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:14 --> URI Class Initialized
INFO - 2017-03-10 02:11:14 --> Router Class Initialized
INFO - 2017-03-10 02:11:14 --> Output Class Initialized
INFO - 2017-03-10 02:11:14 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:14 --> Input Class Initialized
INFO - 2017-03-10 02:11:14 --> Language Class Initialized
INFO - 2017-03-10 02:11:14 --> Loader Class Initialized
INFO - 2017-03-10 02:11:14 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:14 --> Controller Class Initialized
INFO - 2017-03-10 02:11:14 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:14 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:14 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:14 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:14 --> Total execution time: 0.0153
INFO - 2017-03-10 02:11:14 --> Config Class Initialized
INFO - 2017-03-10 02:11:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:14 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:14 --> URI Class Initialized
INFO - 2017-03-10 02:11:14 --> Router Class Initialized
INFO - 2017-03-10 02:11:14 --> Output Class Initialized
INFO - 2017-03-10 02:11:14 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:14 --> Input Class Initialized
INFO - 2017-03-10 02:11:14 --> Language Class Initialized
INFO - 2017-03-10 02:11:14 --> Loader Class Initialized
INFO - 2017-03-10 02:11:14 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:14 --> Controller Class Initialized
INFO - 2017-03-10 02:11:14 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:14 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:14 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:14 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:14 --> Total execution time: 0.0148
INFO - 2017-03-10 02:11:15 --> Config Class Initialized
INFO - 2017-03-10 02:11:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:15 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:15 --> URI Class Initialized
INFO - 2017-03-10 02:11:15 --> Router Class Initialized
INFO - 2017-03-10 02:11:15 --> Output Class Initialized
INFO - 2017-03-10 02:11:15 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:15 --> Input Class Initialized
INFO - 2017-03-10 02:11:15 --> Language Class Initialized
INFO - 2017-03-10 02:11:15 --> Loader Class Initialized
INFO - 2017-03-10 02:11:15 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:15 --> Controller Class Initialized
INFO - 2017-03-10 02:11:15 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:15 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:15 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:15 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:15 --> Total execution time: 0.0148
INFO - 2017-03-10 02:11:16 --> Config Class Initialized
INFO - 2017-03-10 02:11:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:16 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:16 --> URI Class Initialized
INFO - 2017-03-10 02:11:16 --> Router Class Initialized
INFO - 2017-03-10 02:11:16 --> Output Class Initialized
INFO - 2017-03-10 02:11:16 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:16 --> Input Class Initialized
INFO - 2017-03-10 02:11:16 --> Language Class Initialized
INFO - 2017-03-10 02:11:16 --> Loader Class Initialized
INFO - 2017-03-10 02:11:16 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:16 --> Controller Class Initialized
INFO - 2017-03-10 02:11:16 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:16 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:16 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:16 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:16 --> Total execution time: 0.0151
INFO - 2017-03-10 02:11:16 --> Config Class Initialized
INFO - 2017-03-10 02:11:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:16 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:16 --> URI Class Initialized
INFO - 2017-03-10 02:11:16 --> Router Class Initialized
INFO - 2017-03-10 02:11:16 --> Output Class Initialized
INFO - 2017-03-10 02:11:16 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:16 --> Input Class Initialized
INFO - 2017-03-10 02:11:16 --> Language Class Initialized
INFO - 2017-03-10 02:11:16 --> Loader Class Initialized
INFO - 2017-03-10 02:11:16 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:16 --> Controller Class Initialized
INFO - 2017-03-10 02:11:16 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:16 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:16 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:16 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:16 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:16 --> Total execution time: 0.0147
INFO - 2017-03-10 02:11:16 --> Config Class Initialized
INFO - 2017-03-10 02:11:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:16 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:16 --> URI Class Initialized
INFO - 2017-03-10 02:11:16 --> Router Class Initialized
INFO - 2017-03-10 02:11:16 --> Output Class Initialized
INFO - 2017-03-10 02:11:16 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:17 --> Input Class Initialized
INFO - 2017-03-10 02:11:17 --> Language Class Initialized
INFO - 2017-03-10 02:11:17 --> Loader Class Initialized
INFO - 2017-03-10 02:11:17 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:17 --> Controller Class Initialized
INFO - 2017-03-10 02:11:17 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:17 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:17 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:17 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:17 --> Total execution time: 0.0152
INFO - 2017-03-10 02:11:17 --> Config Class Initialized
INFO - 2017-03-10 02:11:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:17 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:17 --> URI Class Initialized
INFO - 2017-03-10 02:11:17 --> Router Class Initialized
INFO - 2017-03-10 02:11:17 --> Output Class Initialized
INFO - 2017-03-10 02:11:17 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:17 --> Input Class Initialized
INFO - 2017-03-10 02:11:17 --> Language Class Initialized
INFO - 2017-03-10 02:11:17 --> Loader Class Initialized
INFO - 2017-03-10 02:11:17 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:17 --> Controller Class Initialized
INFO - 2017-03-10 02:11:17 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:18 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:18 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:18 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:18 --> Total execution time: 0.0156
INFO - 2017-03-10 02:11:20 --> Config Class Initialized
INFO - 2017-03-10 02:11:20 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:20 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:20 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:20 --> URI Class Initialized
INFO - 2017-03-10 02:11:20 --> Router Class Initialized
INFO - 2017-03-10 02:11:20 --> Output Class Initialized
INFO - 2017-03-10 02:11:20 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:20 --> Input Class Initialized
INFO - 2017-03-10 02:11:20 --> Language Class Initialized
INFO - 2017-03-10 02:11:20 --> Loader Class Initialized
INFO - 2017-03-10 02:11:20 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:20 --> Controller Class Initialized
INFO - 2017-03-10 02:11:20 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:20 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:20 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:20 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:20 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:20 --> Total execution time: 0.0147
INFO - 2017-03-10 02:11:21 --> Config Class Initialized
INFO - 2017-03-10 02:11:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:21 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:21 --> URI Class Initialized
INFO - 2017-03-10 02:11:21 --> Router Class Initialized
INFO - 2017-03-10 02:11:21 --> Output Class Initialized
INFO - 2017-03-10 02:11:21 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:21 --> Input Class Initialized
INFO - 2017-03-10 02:11:21 --> Language Class Initialized
INFO - 2017-03-10 02:11:21 --> Loader Class Initialized
INFO - 2017-03-10 02:11:21 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:21 --> Controller Class Initialized
INFO - 2017-03-10 02:11:21 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:21 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:21 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:21 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:21 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:21 --> Total execution time: 0.0150
INFO - 2017-03-10 02:11:26 --> Config Class Initialized
INFO - 2017-03-10 02:11:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:26 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:26 --> URI Class Initialized
INFO - 2017-03-10 02:11:26 --> Router Class Initialized
INFO - 2017-03-10 02:11:26 --> Output Class Initialized
INFO - 2017-03-10 02:11:26 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:26 --> Input Class Initialized
INFO - 2017-03-10 02:11:26 --> Language Class Initialized
INFO - 2017-03-10 02:11:26 --> Loader Class Initialized
INFO - 2017-03-10 02:11:26 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:26 --> Controller Class Initialized
INFO - 2017-03-10 02:11:26 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:26 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:26 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:26 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:26 --> Total execution time: 0.0154
INFO - 2017-03-10 02:11:26 --> Config Class Initialized
INFO - 2017-03-10 02:11:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:26 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:26 --> URI Class Initialized
INFO - 2017-03-10 02:11:26 --> Router Class Initialized
INFO - 2017-03-10 02:11:26 --> Output Class Initialized
INFO - 2017-03-10 02:11:26 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:26 --> Input Class Initialized
INFO - 2017-03-10 02:11:26 --> Language Class Initialized
INFO - 2017-03-10 02:11:26 --> Loader Class Initialized
INFO - 2017-03-10 02:11:26 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:26 --> Controller Class Initialized
INFO - 2017-03-10 02:11:26 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:26 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:26 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:26 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:26 --> Total execution time: 0.0152
INFO - 2017-03-10 02:11:30 --> Config Class Initialized
INFO - 2017-03-10 02:11:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:30 --> URI Class Initialized
INFO - 2017-03-10 02:11:30 --> Router Class Initialized
INFO - 2017-03-10 02:11:30 --> Output Class Initialized
INFO - 2017-03-10 02:11:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:30 --> Input Class Initialized
INFO - 2017-03-10 02:11:30 --> Language Class Initialized
INFO - 2017-03-10 02:11:30 --> Loader Class Initialized
INFO - 2017-03-10 02:11:30 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:30 --> Controller Class Initialized
INFO - 2017-03-10 02:11:30 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:30 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:30 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:30 --> Total execution time: 0.0150
INFO - 2017-03-10 02:11:32 --> Config Class Initialized
INFO - 2017-03-10 02:11:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:32 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:32 --> URI Class Initialized
INFO - 2017-03-10 02:11:32 --> Router Class Initialized
INFO - 2017-03-10 02:11:32 --> Output Class Initialized
INFO - 2017-03-10 02:11:32 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:32 --> Input Class Initialized
INFO - 2017-03-10 02:11:32 --> Language Class Initialized
INFO - 2017-03-10 02:11:32 --> Loader Class Initialized
INFO - 2017-03-10 02:11:32 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:32 --> Controller Class Initialized
INFO - 2017-03-10 02:11:32 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:32 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:32 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:32 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:32 --> Total execution time: 0.0154
INFO - 2017-03-10 02:11:33 --> Config Class Initialized
INFO - 2017-03-10 02:11:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:33 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:33 --> URI Class Initialized
INFO - 2017-03-10 02:11:33 --> Router Class Initialized
INFO - 2017-03-10 02:11:33 --> Output Class Initialized
INFO - 2017-03-10 02:11:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:33 --> Input Class Initialized
INFO - 2017-03-10 02:11:33 --> Language Class Initialized
INFO - 2017-03-10 02:11:33 --> Loader Class Initialized
INFO - 2017-03-10 02:11:33 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:33 --> Controller Class Initialized
INFO - 2017-03-10 02:11:33 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:33 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:33 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:33 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:33 --> Total execution time: 0.0151
INFO - 2017-03-10 02:11:37 --> Config Class Initialized
INFO - 2017-03-10 02:11:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:11:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:11:37 --> Utf8 Class Initialized
INFO - 2017-03-10 02:11:37 --> URI Class Initialized
INFO - 2017-03-10 02:11:37 --> Router Class Initialized
INFO - 2017-03-10 02:11:37 --> Output Class Initialized
INFO - 2017-03-10 02:11:37 --> Security Class Initialized
DEBUG - 2017-03-10 02:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:11:37 --> Input Class Initialized
INFO - 2017-03-10 02:11:37 --> Language Class Initialized
INFO - 2017-03-10 02:11:37 --> Loader Class Initialized
INFO - 2017-03-10 02:11:37 --> Database Driver Class Initialized
INFO - 2017-03-10 02:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:11:37 --> Controller Class Initialized
INFO - 2017-03-10 02:11:37 --> Helper loaded: date_helper
INFO - 2017-03-10 02:11:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:11:37 --> Helper loaded: form_helper
INFO - 2017-03-10 02:11:37 --> Form Validation Class Initialized
INFO - 2017-03-10 02:11:37 --> Final output sent to browser
DEBUG - 2017-03-10 02:11:37 --> Total execution time: 0.0157
INFO - 2017-03-10 02:14:33 --> Config Class Initialized
INFO - 2017-03-10 02:14:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:14:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:14:33 --> Utf8 Class Initialized
INFO - 2017-03-10 02:14:33 --> URI Class Initialized
INFO - 2017-03-10 02:14:33 --> Router Class Initialized
INFO - 2017-03-10 02:14:33 --> Output Class Initialized
INFO - 2017-03-10 02:14:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:14:33 --> Input Class Initialized
INFO - 2017-03-10 02:14:33 --> Language Class Initialized
INFO - 2017-03-10 02:14:33 --> Loader Class Initialized
INFO - 2017-03-10 02:14:33 --> Database Driver Class Initialized
INFO - 2017-03-10 02:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:14:34 --> Controller Class Initialized
INFO - 2017-03-10 02:14:34 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:14:34 --> Helper loaded: url_helper
INFO - 2017-03-10 02:14:34 --> Helper loaded: download_helper
ERROR - 2017-03-10 02:14:34 --> Severity: Notice --> Undefined variable: result /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 30
ERROR - 2017-03-10 02:14:34 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 30
ERROR - 2017-03-10 02:14:34 --> Severity: Notice --> Undefined property: User_mi_graduacion_controller::$fecha /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 31
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:14:34 --> Final output sent to browser
DEBUG - 2017-03-10 02:14:34 --> Total execution time: 0.9775
INFO - 2017-03-10 02:14:34 --> Config Class Initialized
INFO - 2017-03-10 02:14:34 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:14:34 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:14:34 --> Utf8 Class Initialized
INFO - 2017-03-10 02:14:34 --> URI Class Initialized
INFO - 2017-03-10 02:14:34 --> Router Class Initialized
INFO - 2017-03-10 02:14:34 --> Output Class Initialized
INFO - 2017-03-10 02:14:34 --> Security Class Initialized
DEBUG - 2017-03-10 02:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:14:34 --> Input Class Initialized
INFO - 2017-03-10 02:14:34 --> Language Class Initialized
INFO - 2017-03-10 02:14:34 --> Loader Class Initialized
INFO - 2017-03-10 02:14:34 --> Database Driver Class Initialized
INFO - 2017-03-10 02:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:14:34 --> Controller Class Initialized
INFO - 2017-03-10 02:14:34 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:14:34 --> Final output sent to browser
DEBUG - 2017-03-10 02:14:34 --> Total execution time: 0.0616
INFO - 2017-03-10 02:14:42 --> Config Class Initialized
INFO - 2017-03-10 02:14:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:14:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:14:42 --> Utf8 Class Initialized
INFO - 2017-03-10 02:14:42 --> URI Class Initialized
INFO - 2017-03-10 02:14:42 --> Router Class Initialized
INFO - 2017-03-10 02:14:42 --> Output Class Initialized
INFO - 2017-03-10 02:14:42 --> Security Class Initialized
DEBUG - 2017-03-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:14:42 --> Input Class Initialized
INFO - 2017-03-10 02:14:42 --> Language Class Initialized
INFO - 2017-03-10 02:14:42 --> Loader Class Initialized
INFO - 2017-03-10 02:14:42 --> Database Driver Class Initialized
INFO - 2017-03-10 02:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:14:42 --> Controller Class Initialized
INFO - 2017-03-10 02:14:42 --> Helper loaded: date_helper
INFO - 2017-03-10 02:14:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:14:42 --> Helper loaded: form_helper
INFO - 2017-03-10 02:14:42 --> Form Validation Class Initialized
INFO - 2017-03-10 02:14:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 02:14:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 02:14:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-03-10 02:14:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-03-10 02:14:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 02:14:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:14:43 --> Total execution time: 0.2923
INFO - 2017-03-10 02:14:44 --> Config Class Initialized
INFO - 2017-03-10 02:14:44 --> Config Class Initialized
INFO - 2017-03-10 02:14:44 --> Hooks Class Initialized
INFO - 2017-03-10 02:14:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2017-03-10 02:14:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:14:44 --> Utf8 Class Initialized
INFO - 2017-03-10 02:14:44 --> Utf8 Class Initialized
INFO - 2017-03-10 02:14:44 --> URI Class Initialized
INFO - 2017-03-10 02:14:44 --> URI Class Initialized
INFO - 2017-03-10 02:14:44 --> Router Class Initialized
INFO - 2017-03-10 02:14:44 --> Router Class Initialized
INFO - 2017-03-10 02:14:44 --> Output Class Initialized
INFO - 2017-03-10 02:14:44 --> Output Class Initialized
INFO - 2017-03-10 02:14:45 --> Security Class Initialized
INFO - 2017-03-10 02:14:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:14:45 --> Input Class Initialized
INFO - 2017-03-10 02:14:45 --> Language Class Initialized
DEBUG - 2017-03-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:14:45 --> Input Class Initialized
INFO - 2017-03-10 02:14:45 --> Language Class Initialized
INFO - 2017-03-10 02:14:45 --> Loader Class Initialized
INFO - 2017-03-10 02:14:45 --> Loader Class Initialized
INFO - 2017-03-10 02:14:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:14:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:14:45 --> Controller Class Initialized
INFO - 2017-03-10 02:14:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:14:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:14:45 --> Total execution time: 1.2926
INFO - 2017-03-10 02:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:14:45 --> Controller Class Initialized
INFO - 2017-03-10 02:14:45 --> Helper loaded: date_helper
INFO - 2017-03-10 02:14:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:14:46 --> Helper loaded: form_helper
INFO - 2017-03-10 02:14:46 --> Form Validation Class Initialized
INFO - 2017-03-10 02:14:46 --> Final output sent to browser
DEBUG - 2017-03-10 02:14:46 --> Total execution time: 1.4692
INFO - 2017-03-10 02:14:47 --> Config Class Initialized
INFO - 2017-03-10 02:14:47 --> Config Class Initialized
INFO - 2017-03-10 02:14:47 --> Hooks Class Initialized
INFO - 2017-03-10 02:14:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:14:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:14:47 --> Utf8 Class Initialized
DEBUG - 2017-03-10 02:14:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:14:47 --> Utf8 Class Initialized
INFO - 2017-03-10 02:14:47 --> URI Class Initialized
INFO - 2017-03-10 02:14:47 --> Router Class Initialized
INFO - 2017-03-10 02:14:47 --> URI Class Initialized
INFO - 2017-03-10 02:14:47 --> Output Class Initialized
INFO - 2017-03-10 02:14:47 --> Router Class Initialized
INFO - 2017-03-10 02:14:47 --> Security Class Initialized
DEBUG - 2017-03-10 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:14:47 --> Input Class Initialized
INFO - 2017-03-10 02:14:47 --> Output Class Initialized
INFO - 2017-03-10 02:14:47 --> Language Class Initialized
INFO - 2017-03-10 02:14:47 --> Security Class Initialized
DEBUG - 2017-03-10 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:14:47 --> Input Class Initialized
INFO - 2017-03-10 02:14:47 --> Loader Class Initialized
INFO - 2017-03-10 02:14:47 --> Language Class Initialized
INFO - 2017-03-10 02:14:47 --> Loader Class Initialized
INFO - 2017-03-10 02:14:47 --> Database Driver Class Initialized
INFO - 2017-03-10 02:14:47 --> Database Driver Class Initialized
INFO - 2017-03-10 02:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:14:47 --> Controller Class Initialized
INFO - 2017-03-10 02:14:47 --> Helper loaded: date_helper
INFO - 2017-03-10 02:14:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:14:47 --> Helper loaded: form_helper
INFO - 2017-03-10 02:14:47 --> Form Validation Class Initialized
INFO - 2017-03-10 02:14:47 --> Final output sent to browser
DEBUG - 2017-03-10 02:14:47 --> Total execution time: 1.1133
INFO - 2017-03-10 02:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:14:47 --> Controller Class Initialized
INFO - 2017-03-10 02:14:47 --> Helper loaded: date_helper
INFO - 2017-03-10 02:14:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:14:47 --> Helper loaded: form_helper
INFO - 2017-03-10 02:14:47 --> Form Validation Class Initialized
INFO - 2017-03-10 02:14:47 --> Final output sent to browser
DEBUG - 2017-03-10 02:14:47 --> Total execution time: 1.1277
INFO - 2017-03-10 02:15:01 --> Config Class Initialized
INFO - 2017-03-10 02:15:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:01 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:01 --> URI Class Initialized
INFO - 2017-03-10 02:15:01 --> Router Class Initialized
INFO - 2017-03-10 02:15:01 --> Output Class Initialized
INFO - 2017-03-10 02:15:01 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:01 --> Input Class Initialized
INFO - 2017-03-10 02:15:01 --> Language Class Initialized
INFO - 2017-03-10 02:15:01 --> Loader Class Initialized
INFO - 2017-03-10 02:15:01 --> Config Class Initialized
INFO - 2017-03-10 02:15:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:01 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:01 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:01 --> URI Class Initialized
INFO - 2017-03-10 02:15:01 --> Router Class Initialized
INFO - 2017-03-10 02:15:01 --> Output Class Initialized
INFO - 2017-03-10 02:15:01 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:01 --> Input Class Initialized
INFO - 2017-03-10 02:15:01 --> Language Class Initialized
INFO - 2017-03-10 02:15:01 --> Loader Class Initialized
INFO - 2017-03-10 02:15:01 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:01 --> Controller Class Initialized
INFO - 2017-03-10 02:15:01 --> Helper loaded: date_helper
INFO - 2017-03-10 02:15:01 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:01 --> Helper loaded: form_helper
INFO - 2017-03-10 02:15:01 --> Form Validation Class Initialized
INFO - 2017-03-10 02:15:01 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:01 --> Total execution time: 0.0356
INFO - 2017-03-10 02:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:01 --> Controller Class Initialized
INFO - 2017-03-10 02:15:01 --> Helper loaded: date_helper
INFO - 2017-03-10 02:15:01 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:01 --> Helper loaded: form_helper
INFO - 2017-03-10 02:15:01 --> Form Validation Class Initialized
INFO - 2017-03-10 02:15:01 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:01 --> Total execution time: 0.0269
INFO - 2017-03-10 02:15:07 --> Config Class Initialized
INFO - 2017-03-10 02:15:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:07 --> URI Class Initialized
INFO - 2017-03-10 02:15:07 --> Router Class Initialized
INFO - 2017-03-10 02:15:07 --> Output Class Initialized
INFO - 2017-03-10 02:15:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:07 --> Input Class Initialized
INFO - 2017-03-10 02:15:07 --> Language Class Initialized
INFO - 2017-03-10 02:15:07 --> Loader Class Initialized
INFO - 2017-03-10 02:15:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:07 --> Controller Class Initialized
INFO - 2017-03-10 02:15:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:07 --> Config Class Initialized
INFO - 2017-03-10 02:15:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:07 --> URI Class Initialized
INFO - 2017-03-10 02:15:07 --> Router Class Initialized
INFO - 2017-03-10 02:15:07 --> Output Class Initialized
INFO - 2017-03-10 02:15:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:07 --> Input Class Initialized
INFO - 2017-03-10 02:15:07 --> Language Class Initialized
INFO - 2017-03-10 02:15:07 --> Loader Class Initialized
INFO - 2017-03-10 02:15:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:07 --> Controller Class Initialized
INFO - 2017-03-10 02:15:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:07 --> Helper loaded: form_helper
INFO - 2017-03-10 02:15:07 --> Form Validation Class Initialized
INFO - 2017-03-10 02:15:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 02:15:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-10 02:15:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 02:15:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:07 --> Total execution time: 0.0449
INFO - 2017-03-10 02:15:07 --> Config Class Initialized
INFO - 2017-03-10 02:15:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:07 --> URI Class Initialized
INFO - 2017-03-10 02:15:07 --> Router Class Initialized
INFO - 2017-03-10 02:15:07 --> Output Class Initialized
INFO - 2017-03-10 02:15:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:07 --> Input Class Initialized
INFO - 2017-03-10 02:15:07 --> Language Class Initialized
INFO - 2017-03-10 02:15:07 --> Loader Class Initialized
INFO - 2017-03-10 02:15:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:07 --> Controller Class Initialized
INFO - 2017-03-10 02:15:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:15:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:07 --> Total execution time: 0.0413
INFO - 2017-03-10 02:15:08 --> Config Class Initialized
INFO - 2017-03-10 02:15:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:08 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:08 --> URI Class Initialized
INFO - 2017-03-10 02:15:08 --> Router Class Initialized
INFO - 2017-03-10 02:15:08 --> Output Class Initialized
INFO - 2017-03-10 02:15:08 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:08 --> Input Class Initialized
INFO - 2017-03-10 02:15:08 --> Language Class Initialized
INFO - 2017-03-10 02:15:08 --> Loader Class Initialized
INFO - 2017-03-10 02:15:08 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:08 --> Controller Class Initialized
INFO - 2017-03-10 02:15:08 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:15:08 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:08 --> Total execution time: 0.0143
INFO - 2017-03-10 02:15:14 --> Config Class Initialized
INFO - 2017-03-10 02:15:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:14 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:14 --> URI Class Initialized
INFO - 2017-03-10 02:15:14 --> Router Class Initialized
INFO - 2017-03-10 02:15:14 --> Output Class Initialized
INFO - 2017-03-10 02:15:14 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:14 --> Input Class Initialized
INFO - 2017-03-10 02:15:14 --> Language Class Initialized
INFO - 2017-03-10 02:15:14 --> Loader Class Initialized
INFO - 2017-03-10 02:15:14 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:14 --> Controller Class Initialized
INFO - 2017-03-10 02:15:14 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:14 --> Helper loaded: url_helper
INFO - 2017-03-10 02:15:14 --> Helper loaded: download_helper
INFO - 2017-03-10 02:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:15:14 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:14 --> Total execution time: 0.0773
INFO - 2017-03-10 02:15:15 --> Config Class Initialized
INFO - 2017-03-10 02:15:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:15 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:15 --> URI Class Initialized
INFO - 2017-03-10 02:15:15 --> Router Class Initialized
INFO - 2017-03-10 02:15:15 --> Output Class Initialized
INFO - 2017-03-10 02:15:15 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:15 --> Input Class Initialized
INFO - 2017-03-10 02:15:15 --> Language Class Initialized
INFO - 2017-03-10 02:15:15 --> Loader Class Initialized
INFO - 2017-03-10 02:15:15 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:15 --> Controller Class Initialized
INFO - 2017-03-10 02:15:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:15:15 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:15 --> Total execution time: 0.0146
INFO - 2017-03-10 02:15:41 --> Config Class Initialized
INFO - 2017-03-10 02:15:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:41 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:41 --> URI Class Initialized
INFO - 2017-03-10 02:15:41 --> Router Class Initialized
INFO - 2017-03-10 02:15:41 --> Output Class Initialized
INFO - 2017-03-10 02:15:41 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:41 --> Input Class Initialized
INFO - 2017-03-10 02:15:41 --> Language Class Initialized
ERROR - 2017-03-10 02:15:41 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 29
INFO - 2017-03-10 02:15:41 --> Config Class Initialized
INFO - 2017-03-10 02:15:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:41 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:41 --> URI Class Initialized
INFO - 2017-03-10 02:15:41 --> Router Class Initialized
INFO - 2017-03-10 02:15:41 --> Output Class Initialized
INFO - 2017-03-10 02:15:41 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:41 --> Input Class Initialized
INFO - 2017-03-10 02:15:41 --> Language Class Initialized
INFO - 2017-03-10 02:15:41 --> Loader Class Initialized
INFO - 2017-03-10 02:15:41 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:41 --> Controller Class Initialized
INFO - 2017-03-10 02:15:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:15:41 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:41 --> Total execution time: 0.0144
INFO - 2017-03-10 02:15:50 --> Config Class Initialized
INFO - 2017-03-10 02:15:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:50 --> URI Class Initialized
INFO - 2017-03-10 02:15:50 --> Router Class Initialized
INFO - 2017-03-10 02:15:50 --> Output Class Initialized
INFO - 2017-03-10 02:15:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:50 --> Input Class Initialized
INFO - 2017-03-10 02:15:50 --> Language Class Initialized
INFO - 2017-03-10 02:15:50 --> Loader Class Initialized
INFO - 2017-03-10 02:15:50 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:50 --> Controller Class Initialized
INFO - 2017-03-10 02:15:50 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:50 --> Helper loaded: url_helper
INFO - 2017-03-10 02:15:50 --> Helper loaded: download_helper
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:15:50 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:50 --> Total execution time: 0.0210
INFO - 2017-03-10 02:15:50 --> Config Class Initialized
INFO - 2017-03-10 02:15:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:15:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:15:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:15:50 --> URI Class Initialized
INFO - 2017-03-10 02:15:50 --> Router Class Initialized
INFO - 2017-03-10 02:15:50 --> Output Class Initialized
INFO - 2017-03-10 02:15:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:15:50 --> Input Class Initialized
INFO - 2017-03-10 02:15:50 --> Language Class Initialized
INFO - 2017-03-10 02:15:50 --> Loader Class Initialized
INFO - 2017-03-10 02:15:50 --> Database Driver Class Initialized
INFO - 2017-03-10 02:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:15:50 --> Controller Class Initialized
INFO - 2017-03-10 02:15:50 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:15:50 --> Final output sent to browser
DEBUG - 2017-03-10 02:15:50 --> Total execution time: 0.0137
INFO - 2017-03-10 02:16:17 --> Config Class Initialized
INFO - 2017-03-10 02:16:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:16:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:16:17 --> Utf8 Class Initialized
INFO - 2017-03-10 02:16:17 --> URI Class Initialized
INFO - 2017-03-10 02:16:17 --> Router Class Initialized
INFO - 2017-03-10 02:16:17 --> Output Class Initialized
INFO - 2017-03-10 02:16:17 --> Security Class Initialized
DEBUG - 2017-03-10 02:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:16:17 --> Input Class Initialized
INFO - 2017-03-10 02:16:17 --> Language Class Initialized
INFO - 2017-03-10 02:16:17 --> Loader Class Initialized
INFO - 2017-03-10 02:16:17 --> Database Driver Class Initialized
INFO - 2017-03-10 02:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:16:17 --> Controller Class Initialized
INFO - 2017-03-10 02:16:17 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:16:17 --> Helper loaded: url_helper
INFO - 2017-03-10 02:16:17 --> Helper loaded: download_helper
ERROR - 2017-03-10 02:16:17 --> Severity: Notice --> Undefined variable: result /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 32
ERROR - 2017-03-10 02:16:17 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 32
ERROR - 2017-03-10 02:16:17 --> Severity: Notice --> Undefined property: User_mi_graduacion_controller::$fecha /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 33
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:16:17 --> Final output sent to browser
DEBUG - 2017-03-10 02:16:17 --> Total execution time: 0.0417
INFO - 2017-03-10 02:16:17 --> Config Class Initialized
INFO - 2017-03-10 02:16:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:16:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:16:17 --> Utf8 Class Initialized
INFO - 2017-03-10 02:16:17 --> URI Class Initialized
INFO - 2017-03-10 02:16:17 --> Router Class Initialized
INFO - 2017-03-10 02:16:17 --> Output Class Initialized
INFO - 2017-03-10 02:16:17 --> Security Class Initialized
DEBUG - 2017-03-10 02:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:16:17 --> Input Class Initialized
INFO - 2017-03-10 02:16:17 --> Language Class Initialized
INFO - 2017-03-10 02:16:17 --> Loader Class Initialized
INFO - 2017-03-10 02:16:17 --> Database Driver Class Initialized
INFO - 2017-03-10 02:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:16:17 --> Controller Class Initialized
INFO - 2017-03-10 02:16:17 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:16:17 --> Final output sent to browser
DEBUG - 2017-03-10 02:16:17 --> Total execution time: 0.0149
INFO - 2017-03-10 02:16:43 --> Config Class Initialized
INFO - 2017-03-10 02:16:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:16:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:16:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:16:43 --> URI Class Initialized
INFO - 2017-03-10 02:16:43 --> Router Class Initialized
INFO - 2017-03-10 02:16:43 --> Output Class Initialized
INFO - 2017-03-10 02:16:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:16:43 --> Input Class Initialized
INFO - 2017-03-10 02:16:43 --> Language Class Initialized
INFO - 2017-03-10 02:16:43 --> Loader Class Initialized
INFO - 2017-03-10 02:16:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:16:43 --> Controller Class Initialized
INFO - 2017-03-10 02:16:43 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:16:43 --> Helper loaded: url_helper
INFO - 2017-03-10 02:16:43 --> Helper loaded: download_helper
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:16:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:16:43 --> Total execution time: 0.0208
INFO - 2017-03-10 02:16:43 --> Config Class Initialized
INFO - 2017-03-10 02:16:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:16:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:16:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:16:43 --> URI Class Initialized
INFO - 2017-03-10 02:16:43 --> Router Class Initialized
INFO - 2017-03-10 02:16:43 --> Output Class Initialized
INFO - 2017-03-10 02:16:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:16:43 --> Input Class Initialized
INFO - 2017-03-10 02:16:43 --> Language Class Initialized
INFO - 2017-03-10 02:16:43 --> Loader Class Initialized
INFO - 2017-03-10 02:16:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:16:43 --> Controller Class Initialized
INFO - 2017-03-10 02:16:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:16:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:16:43 --> Total execution time: 0.0140
INFO - 2017-03-10 02:16:59 --> Config Class Initialized
INFO - 2017-03-10 02:16:59 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:16:59 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:16:59 --> Utf8 Class Initialized
INFO - 2017-03-10 02:16:59 --> URI Class Initialized
INFO - 2017-03-10 02:16:59 --> Router Class Initialized
INFO - 2017-03-10 02:16:59 --> Output Class Initialized
INFO - 2017-03-10 02:16:59 --> Security Class Initialized
DEBUG - 2017-03-10 02:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:16:59 --> Input Class Initialized
INFO - 2017-03-10 02:16:59 --> Language Class Initialized
INFO - 2017-03-10 02:16:59 --> Loader Class Initialized
INFO - 2017-03-10 02:16:59 --> Database Driver Class Initialized
INFO - 2017-03-10 02:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:17:00 --> Controller Class Initialized
INFO - 2017-03-10 02:17:00 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:17:00 --> Helper loaded: url_helper
INFO - 2017-03-10 02:17:00 --> Helper loaded: download_helper
INFO - 2017-03-10 02:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:17:00 --> Final output sent to browser
DEBUG - 2017-03-10 02:17:00 --> Total execution time: 1.1482
INFO - 2017-03-10 02:17:00 --> Config Class Initialized
INFO - 2017-03-10 02:17:00 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:17:00 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:17:00 --> Utf8 Class Initialized
INFO - 2017-03-10 02:17:00 --> URI Class Initialized
INFO - 2017-03-10 02:17:00 --> Router Class Initialized
INFO - 2017-03-10 02:17:00 --> Output Class Initialized
INFO - 2017-03-10 02:17:00 --> Security Class Initialized
DEBUG - 2017-03-10 02:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:17:00 --> Input Class Initialized
INFO - 2017-03-10 02:17:00 --> Language Class Initialized
INFO - 2017-03-10 02:17:00 --> Loader Class Initialized
INFO - 2017-03-10 02:17:00 --> Database Driver Class Initialized
INFO - 2017-03-10 02:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:17:00 --> Controller Class Initialized
INFO - 2017-03-10 02:17:00 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:17:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:17:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:17:01 --> Final output sent to browser
DEBUG - 2017-03-10 02:17:01 --> Total execution time: 0.2524
INFO - 2017-03-10 02:18:25 --> Config Class Initialized
INFO - 2017-03-10 02:18:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:18:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:18:25 --> Utf8 Class Initialized
INFO - 2017-03-10 02:18:25 --> URI Class Initialized
INFO - 2017-03-10 02:18:25 --> Router Class Initialized
INFO - 2017-03-10 02:18:25 --> Output Class Initialized
INFO - 2017-03-10 02:18:25 --> Security Class Initialized
DEBUG - 2017-03-10 02:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:18:25 --> Input Class Initialized
INFO - 2017-03-10 02:18:25 --> Language Class Initialized
INFO - 2017-03-10 02:18:25 --> Loader Class Initialized
INFO - 2017-03-10 02:18:25 --> Database Driver Class Initialized
INFO - 2017-03-10 02:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:18:25 --> Controller Class Initialized
INFO - 2017-03-10 02:18:25 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:18:25 --> Helper loaded: url_helper
INFO - 2017-03-10 02:18:25 --> Helper loaded: download_helper
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:18:25 --> Final output sent to browser
DEBUG - 2017-03-10 02:18:25 --> Total execution time: 0.0199
INFO - 2017-03-10 02:18:25 --> Config Class Initialized
INFO - 2017-03-10 02:18:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:18:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:18:25 --> Utf8 Class Initialized
INFO - 2017-03-10 02:18:25 --> URI Class Initialized
INFO - 2017-03-10 02:18:25 --> Router Class Initialized
INFO - 2017-03-10 02:18:25 --> Output Class Initialized
INFO - 2017-03-10 02:18:25 --> Security Class Initialized
DEBUG - 2017-03-10 02:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:18:25 --> Input Class Initialized
INFO - 2017-03-10 02:18:25 --> Language Class Initialized
INFO - 2017-03-10 02:18:25 --> Loader Class Initialized
INFO - 2017-03-10 02:18:25 --> Database Driver Class Initialized
INFO - 2017-03-10 02:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:18:25 --> Controller Class Initialized
INFO - 2017-03-10 02:18:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:18:25 --> Final output sent to browser
DEBUG - 2017-03-10 02:18:25 --> Total execution time: 0.0140
INFO - 2017-03-10 02:20:42 --> Config Class Initialized
INFO - 2017-03-10 02:20:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:20:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:20:42 --> Utf8 Class Initialized
INFO - 2017-03-10 02:20:42 --> URI Class Initialized
INFO - 2017-03-10 02:20:42 --> Router Class Initialized
INFO - 2017-03-10 02:20:42 --> Output Class Initialized
INFO - 2017-03-10 02:20:42 --> Security Class Initialized
DEBUG - 2017-03-10 02:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:20:42 --> Input Class Initialized
INFO - 2017-03-10 02:20:42 --> Language Class Initialized
INFO - 2017-03-10 02:20:42 --> Loader Class Initialized
INFO - 2017-03-10 02:20:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:20:43 --> Controller Class Initialized
INFO - 2017-03-10 02:20:43 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:20:43 --> Helper loaded: url_helper
INFO - 2017-03-10 02:20:43 --> Helper loaded: download_helper
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:20:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:20:43 --> Total execution time: 1.0926
INFO - 2017-03-10 02:20:43 --> Config Class Initialized
INFO - 2017-03-10 02:20:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:20:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:20:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:20:43 --> URI Class Initialized
INFO - 2017-03-10 02:20:43 --> Router Class Initialized
INFO - 2017-03-10 02:20:43 --> Output Class Initialized
INFO - 2017-03-10 02:20:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:20:43 --> Input Class Initialized
INFO - 2017-03-10 02:20:43 --> Language Class Initialized
INFO - 2017-03-10 02:20:43 --> Loader Class Initialized
INFO - 2017-03-10 02:20:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:20:43 --> Controller Class Initialized
INFO - 2017-03-10 02:20:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:20:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:20:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:20:43 --> Total execution time: 0.2341
INFO - 2017-03-10 02:21:24 --> Config Class Initialized
INFO - 2017-03-10 02:21:24 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:21:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:21:24 --> Utf8 Class Initialized
INFO - 2017-03-10 02:21:24 --> URI Class Initialized
INFO - 2017-03-10 02:21:24 --> Router Class Initialized
INFO - 2017-03-10 02:21:24 --> Output Class Initialized
INFO - 2017-03-10 02:21:24 --> Security Class Initialized
DEBUG - 2017-03-10 02:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:21:24 --> Input Class Initialized
INFO - 2017-03-10 02:21:24 --> Language Class Initialized
INFO - 2017-03-10 02:21:24 --> Loader Class Initialized
INFO - 2017-03-10 02:21:24 --> Database Driver Class Initialized
INFO - 2017-03-10 02:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:21:25 --> Controller Class Initialized
INFO - 2017-03-10 02:21:25 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:21:25 --> Helper loaded: url_helper
INFO - 2017-03-10 02:21:25 --> Helper loaded: download_helper
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:21:25 --> Final output sent to browser
DEBUG - 2017-03-10 02:21:25 --> Total execution time: 0.2596
INFO - 2017-03-10 02:21:25 --> Config Class Initialized
INFO - 2017-03-10 02:21:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:21:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:21:25 --> Utf8 Class Initialized
INFO - 2017-03-10 02:21:25 --> URI Class Initialized
INFO - 2017-03-10 02:21:25 --> Router Class Initialized
INFO - 2017-03-10 02:21:25 --> Output Class Initialized
INFO - 2017-03-10 02:21:25 --> Security Class Initialized
DEBUG - 2017-03-10 02:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:21:25 --> Input Class Initialized
INFO - 2017-03-10 02:21:25 --> Language Class Initialized
INFO - 2017-03-10 02:21:25 --> Loader Class Initialized
INFO - 2017-03-10 02:21:25 --> Database Driver Class Initialized
INFO - 2017-03-10 02:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:21:25 --> Controller Class Initialized
INFO - 2017-03-10 02:21:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:21:25 --> Final output sent to browser
DEBUG - 2017-03-10 02:21:25 --> Total execution time: 0.0267
INFO - 2017-03-10 02:21:59 --> Config Class Initialized
INFO - 2017-03-10 02:21:59 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:21:59 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:21:59 --> Utf8 Class Initialized
INFO - 2017-03-10 02:21:59 --> URI Class Initialized
INFO - 2017-03-10 02:21:59 --> Router Class Initialized
INFO - 2017-03-10 02:21:59 --> Output Class Initialized
INFO - 2017-03-10 02:21:59 --> Security Class Initialized
DEBUG - 2017-03-10 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:21:59 --> Input Class Initialized
INFO - 2017-03-10 02:21:59 --> Language Class Initialized
INFO - 2017-03-10 02:22:00 --> Loader Class Initialized
INFO - 2017-03-10 02:22:00 --> Database Driver Class Initialized
INFO - 2017-03-10 02:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:22:00 --> Controller Class Initialized
INFO - 2017-03-10 02:22:00 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:22:00 --> Helper loaded: url_helper
INFO - 2017-03-10 02:22:00 --> Helper loaded: download_helper
INFO - 2017-03-10 02:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:22:00 --> Final output sent to browser
DEBUG - 2017-03-10 02:22:00 --> Total execution time: 1.0891
INFO - 2017-03-10 02:22:01 --> Config Class Initialized
INFO - 2017-03-10 02:22:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:22:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:22:01 --> Utf8 Class Initialized
INFO - 2017-03-10 02:22:01 --> URI Class Initialized
INFO - 2017-03-10 02:22:01 --> Router Class Initialized
INFO - 2017-03-10 02:22:01 --> Output Class Initialized
INFO - 2017-03-10 02:22:01 --> Security Class Initialized
DEBUG - 2017-03-10 02:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:22:01 --> Input Class Initialized
INFO - 2017-03-10 02:22:01 --> Language Class Initialized
INFO - 2017-03-10 02:22:01 --> Loader Class Initialized
INFO - 2017-03-10 02:22:01 --> Database Driver Class Initialized
INFO - 2017-03-10 02:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:22:01 --> Controller Class Initialized
INFO - 2017-03-10 02:22:01 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:22:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:22:02 --> Final output sent to browser
DEBUG - 2017-03-10 02:22:02 --> Total execution time: 0.4851
INFO - 2017-03-10 02:22:41 --> Config Class Initialized
INFO - 2017-03-10 02:22:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:22:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:22:41 --> Utf8 Class Initialized
INFO - 2017-03-10 02:22:41 --> URI Class Initialized
INFO - 2017-03-10 02:22:41 --> Router Class Initialized
INFO - 2017-03-10 02:22:41 --> Output Class Initialized
INFO - 2017-03-10 02:22:41 --> Security Class Initialized
DEBUG - 2017-03-10 02:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:22:42 --> Input Class Initialized
INFO - 2017-03-10 02:22:42 --> Language Class Initialized
INFO - 2017-03-10 02:22:42 --> Loader Class Initialized
INFO - 2017-03-10 02:22:42 --> Database Driver Class Initialized
INFO - 2017-03-10 02:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:22:42 --> Controller Class Initialized
INFO - 2017-03-10 02:22:42 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:22:42 --> Helper loaded: url_helper
INFO - 2017-03-10 02:22:42 --> Helper loaded: download_helper
INFO - 2017-03-10 02:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:22:42 --> Final output sent to browser
DEBUG - 2017-03-10 02:22:42 --> Total execution time: 1.0628
INFO - 2017-03-10 02:22:43 --> Config Class Initialized
INFO - 2017-03-10 02:22:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:22:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:22:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:22:43 --> URI Class Initialized
INFO - 2017-03-10 02:22:43 --> Router Class Initialized
INFO - 2017-03-10 02:22:43 --> Output Class Initialized
INFO - 2017-03-10 02:22:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:22:43 --> Input Class Initialized
INFO - 2017-03-10 02:22:43 --> Language Class Initialized
INFO - 2017-03-10 02:22:43 --> Loader Class Initialized
INFO - 2017-03-10 02:22:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:22:43 --> Controller Class Initialized
INFO - 2017-03-10 02:22:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:22:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:22:43 --> Total execution time: 0.2531
INFO - 2017-03-10 02:22:58 --> Config Class Initialized
INFO - 2017-03-10 02:22:58 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:22:58 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:22:58 --> Utf8 Class Initialized
INFO - 2017-03-10 02:22:58 --> URI Class Initialized
INFO - 2017-03-10 02:22:58 --> Router Class Initialized
INFO - 2017-03-10 02:22:58 --> Output Class Initialized
INFO - 2017-03-10 02:22:58 --> Security Class Initialized
DEBUG - 2017-03-10 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:22:58 --> Input Class Initialized
INFO - 2017-03-10 02:22:58 --> Language Class Initialized
INFO - 2017-03-10 02:22:58 --> Loader Class Initialized
INFO - 2017-03-10 02:22:58 --> Database Driver Class Initialized
INFO - 2017-03-10 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:22:58 --> Controller Class Initialized
INFO - 2017-03-10 02:22:58 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:22:58 --> Helper loaded: url_helper
INFO - 2017-03-10 02:22:58 --> Helper loaded: download_helper
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:22:58 --> Final output sent to browser
DEBUG - 2017-03-10 02:22:58 --> Total execution time: 0.0192
INFO - 2017-03-10 02:22:58 --> Config Class Initialized
INFO - 2017-03-10 02:22:58 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:22:58 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:22:58 --> Utf8 Class Initialized
INFO - 2017-03-10 02:22:58 --> URI Class Initialized
INFO - 2017-03-10 02:22:58 --> Router Class Initialized
INFO - 2017-03-10 02:22:58 --> Output Class Initialized
INFO - 2017-03-10 02:22:58 --> Security Class Initialized
DEBUG - 2017-03-10 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:22:58 --> Input Class Initialized
INFO - 2017-03-10 02:22:58 --> Language Class Initialized
INFO - 2017-03-10 02:22:58 --> Loader Class Initialized
INFO - 2017-03-10 02:22:58 --> Database Driver Class Initialized
INFO - 2017-03-10 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:22:58 --> Controller Class Initialized
INFO - 2017-03-10 02:22:58 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:22:58 --> Final output sent to browser
DEBUG - 2017-03-10 02:22:58 --> Total execution time: 0.0517
INFO - 2017-03-10 02:23:03 --> Config Class Initialized
INFO - 2017-03-10 02:23:03 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:03 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:03 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:03 --> URI Class Initialized
INFO - 2017-03-10 02:23:03 --> Router Class Initialized
INFO - 2017-03-10 02:23:03 --> Output Class Initialized
INFO - 2017-03-10 02:23:03 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:03 --> Input Class Initialized
INFO - 2017-03-10 02:23:03 --> Language Class Initialized
ERROR - 2017-03-10 02:23:03 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:23:26 --> Config Class Initialized
INFO - 2017-03-10 02:23:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:26 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:26 --> URI Class Initialized
DEBUG - 2017-03-10 02:23:26 --> No URI present. Default controller set.
INFO - 2017-03-10 02:23:26 --> Router Class Initialized
INFO - 2017-03-10 02:23:27 --> Output Class Initialized
INFO - 2017-03-10 02:23:27 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:27 --> Input Class Initialized
INFO - 2017-03-10 02:23:27 --> Language Class Initialized
INFO - 2017-03-10 02:23:27 --> Loader Class Initialized
INFO - 2017-03-10 02:23:27 --> Database Driver Class Initialized
INFO - 2017-03-10 02:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:23:27 --> Controller Class Initialized
INFO - 2017-03-10 02:23:27 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:23:27 --> Final output sent to browser
DEBUG - 2017-03-10 02:23:27 --> Total execution time: 1.2323
INFO - 2017-03-10 02:23:30 --> Config Class Initialized
INFO - 2017-03-10 02:23:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:30 --> URI Class Initialized
INFO - 2017-03-10 02:23:30 --> Router Class Initialized
INFO - 2017-03-10 02:23:30 --> Output Class Initialized
INFO - 2017-03-10 02:23:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:30 --> Input Class Initialized
INFO - 2017-03-10 02:23:30 --> Language Class Initialized
INFO - 2017-03-10 02:23:30 --> Loader Class Initialized
INFO - 2017-03-10 02:23:30 --> Database Driver Class Initialized
INFO - 2017-03-10 02:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:23:30 --> Controller Class Initialized
INFO - 2017-03-10 02:23:30 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:23:30 --> Helper loaded: url_helper
INFO - 2017-03-10 02:23:30 --> Helper loaded: download_helper
INFO - 2017-03-10 02:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:23:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:23:30 --> Total execution time: 0.1428
INFO - 2017-03-10 02:23:31 --> Config Class Initialized
INFO - 2017-03-10 02:23:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:31 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:31 --> URI Class Initialized
INFO - 2017-03-10 02:23:31 --> Router Class Initialized
INFO - 2017-03-10 02:23:31 --> Output Class Initialized
INFO - 2017-03-10 02:23:31 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:31 --> Input Class Initialized
INFO - 2017-03-10 02:23:31 --> Language Class Initialized
ERROR - 2017-03-10 02:23:31 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:23:31 --> Config Class Initialized
INFO - 2017-03-10 02:23:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:31 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:31 --> URI Class Initialized
INFO - 2017-03-10 02:23:31 --> Router Class Initialized
INFO - 2017-03-10 02:23:31 --> Output Class Initialized
INFO - 2017-03-10 02:23:31 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:31 --> Input Class Initialized
INFO - 2017-03-10 02:23:31 --> Language Class Initialized
INFO - 2017-03-10 02:23:31 --> Loader Class Initialized
INFO - 2017-03-10 02:23:31 --> Database Driver Class Initialized
INFO - 2017-03-10 02:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:23:31 --> Controller Class Initialized
INFO - 2017-03-10 02:23:31 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:23:31 --> Final output sent to browser
DEBUG - 2017-03-10 02:23:31 --> Total execution time: 0.0159
INFO - 2017-03-10 02:23:43 --> Config Class Initialized
INFO - 2017-03-10 02:23:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:43 --> URI Class Initialized
INFO - 2017-03-10 02:23:43 --> Router Class Initialized
INFO - 2017-03-10 02:23:43 --> Output Class Initialized
INFO - 2017-03-10 02:23:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:43 --> Input Class Initialized
INFO - 2017-03-10 02:23:43 --> Language Class Initialized
INFO - 2017-03-10 02:23:43 --> Loader Class Initialized
INFO - 2017-03-10 02:23:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:23:43 --> Controller Class Initialized
INFO - 2017-03-10 02:23:43 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:23:43 --> Helper loaded: url_helper
INFO - 2017-03-10 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:23:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:23:43 --> Total execution time: 0.0392
INFO - 2017-03-10 02:23:44 --> Config Class Initialized
INFO - 2017-03-10 02:23:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:44 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:44 --> URI Class Initialized
INFO - 2017-03-10 02:23:44 --> Router Class Initialized
INFO - 2017-03-10 02:23:44 --> Output Class Initialized
INFO - 2017-03-10 02:23:44 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:44 --> Input Class Initialized
INFO - 2017-03-10 02:23:44 --> Language Class Initialized
ERROR - 2017-03-10 02:23:44 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:23:44 --> Config Class Initialized
INFO - 2017-03-10 02:23:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:44 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:44 --> URI Class Initialized
INFO - 2017-03-10 02:23:44 --> Router Class Initialized
INFO - 2017-03-10 02:23:44 --> Output Class Initialized
INFO - 2017-03-10 02:23:44 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:44 --> Input Class Initialized
INFO - 2017-03-10 02:23:44 --> Language Class Initialized
INFO - 2017-03-10 02:23:44 --> Loader Class Initialized
INFO - 2017-03-10 02:23:44 --> Database Driver Class Initialized
INFO - 2017-03-10 02:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:23:44 --> Controller Class Initialized
INFO - 2017-03-10 02:23:44 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:23:44 --> Final output sent to browser
DEBUG - 2017-03-10 02:23:44 --> Total execution time: 0.0150
INFO - 2017-03-10 02:23:44 --> Config Class Initialized
INFO - 2017-03-10 02:23:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:44 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:44 --> URI Class Initialized
INFO - 2017-03-10 02:23:44 --> Router Class Initialized
INFO - 2017-03-10 02:23:44 --> Output Class Initialized
INFO - 2017-03-10 02:23:44 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:44 --> Input Class Initialized
INFO - 2017-03-10 02:23:44 --> Language Class Initialized
INFO - 2017-03-10 02:23:44 --> Loader Class Initialized
INFO - 2017-03-10 02:23:44 --> Database Driver Class Initialized
INFO - 2017-03-10 02:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:23:44 --> Controller Class Initialized
INFO - 2017-03-10 02:23:44 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:23:44 --> Helper loaded: url_helper
INFO - 2017-03-10 02:23:44 --> Helper loaded: download_helper
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:23:44 --> Final output sent to browser
DEBUG - 2017-03-10 02:23:44 --> Total execution time: 0.0194
INFO - 2017-03-10 02:23:45 --> Config Class Initialized
INFO - 2017-03-10 02:23:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:45 --> URI Class Initialized
INFO - 2017-03-10 02:23:45 --> Router Class Initialized
INFO - 2017-03-10 02:23:45 --> Output Class Initialized
INFO - 2017-03-10 02:23:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:45 --> Input Class Initialized
INFO - 2017-03-10 02:23:45 --> Language Class Initialized
ERROR - 2017-03-10 02:23:45 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:23:45 --> Config Class Initialized
INFO - 2017-03-10 02:23:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:23:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:23:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:23:45 --> URI Class Initialized
INFO - 2017-03-10 02:23:45 --> Router Class Initialized
INFO - 2017-03-10 02:23:45 --> Output Class Initialized
INFO - 2017-03-10 02:23:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:23:45 --> Input Class Initialized
INFO - 2017-03-10 02:23:45 --> Language Class Initialized
INFO - 2017-03-10 02:23:45 --> Loader Class Initialized
INFO - 2017-03-10 02:23:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:23:45 --> Controller Class Initialized
INFO - 2017-03-10 02:23:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:23:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:23:45 --> Total execution time: 0.0141
INFO - 2017-03-10 02:24:02 --> Config Class Initialized
INFO - 2017-03-10 02:24:02 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:24:02 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:24:02 --> Utf8 Class Initialized
INFO - 2017-03-10 02:24:02 --> URI Class Initialized
INFO - 2017-03-10 02:24:02 --> Router Class Initialized
INFO - 2017-03-10 02:24:02 --> Output Class Initialized
INFO - 2017-03-10 02:24:02 --> Security Class Initialized
DEBUG - 2017-03-10 02:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:24:02 --> Input Class Initialized
INFO - 2017-03-10 02:24:02 --> Language Class Initialized
INFO - 2017-03-10 02:24:02 --> Loader Class Initialized
INFO - 2017-03-10 02:24:02 --> Database Driver Class Initialized
INFO - 2017-03-10 02:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:24:02 --> Controller Class Initialized
INFO - 2017-03-10 02:24:02 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:24:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-10 02:24:04 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-10 02:24:04 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liiz Moncada')
INFO - 2017-03-10 02:24:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-10 02:24:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-10 02:24:04 --> Config Class Initialized
INFO - 2017-03-10 02:24:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:24:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:24:04 --> Utf8 Class Initialized
INFO - 2017-03-10 02:24:04 --> URI Class Initialized
INFO - 2017-03-10 02:24:04 --> Router Class Initialized
INFO - 2017-03-10 02:24:04 --> Output Class Initialized
INFO - 2017-03-10 02:24:04 --> Security Class Initialized
DEBUG - 2017-03-10 02:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:24:04 --> Input Class Initialized
INFO - 2017-03-10 02:24:04 --> Language Class Initialized
INFO - 2017-03-10 02:24:04 --> Loader Class Initialized
INFO - 2017-03-10 02:24:04 --> Database Driver Class Initialized
INFO - 2017-03-10 02:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:24:04 --> Controller Class Initialized
INFO - 2017-03-10 02:24:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:24:04 --> Final output sent to browser
DEBUG - 2017-03-10 02:24:04 --> Total execution time: 0.0139
INFO - 2017-03-10 02:24:09 --> Config Class Initialized
INFO - 2017-03-10 02:24:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:24:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:24:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:24:09 --> URI Class Initialized
DEBUG - 2017-03-10 02:24:09 --> No URI present. Default controller set.
INFO - 2017-03-10 02:24:09 --> Router Class Initialized
INFO - 2017-03-10 02:24:09 --> Output Class Initialized
INFO - 2017-03-10 02:24:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:24:09 --> Input Class Initialized
INFO - 2017-03-10 02:24:09 --> Language Class Initialized
INFO - 2017-03-10 02:24:09 --> Loader Class Initialized
INFO - 2017-03-10 02:24:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:24:09 --> Controller Class Initialized
INFO - 2017-03-10 02:24:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:24:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:24:09 --> Total execution time: 0.0142
INFO - 2017-03-10 02:24:12 --> Config Class Initialized
INFO - 2017-03-10 02:24:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:24:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:24:12 --> Utf8 Class Initialized
INFO - 2017-03-10 02:24:12 --> URI Class Initialized
INFO - 2017-03-10 02:24:12 --> Router Class Initialized
INFO - 2017-03-10 02:24:12 --> Output Class Initialized
INFO - 2017-03-10 02:24:12 --> Security Class Initialized
DEBUG - 2017-03-10 02:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:24:12 --> Input Class Initialized
INFO - 2017-03-10 02:24:12 --> Language Class Initialized
INFO - 2017-03-10 02:24:12 --> Loader Class Initialized
INFO - 2017-03-10 02:24:12 --> Database Driver Class Initialized
INFO - 2017-03-10 02:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:24:12 --> Controller Class Initialized
INFO - 2017-03-10 02:24:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:24:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:24:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:24:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:24:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:24:13 --> Final output sent to browser
DEBUG - 2017-03-10 02:24:13 --> Total execution time: 1.1595
INFO - 2017-03-10 02:29:28 --> Config Class Initialized
INFO - 2017-03-10 02:29:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:29:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:29:28 --> Utf8 Class Initialized
INFO - 2017-03-10 02:29:28 --> URI Class Initialized
INFO - 2017-03-10 02:29:28 --> Router Class Initialized
INFO - 2017-03-10 02:29:28 --> Output Class Initialized
INFO - 2017-03-10 02:29:28 --> Security Class Initialized
DEBUG - 2017-03-10 02:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:29:28 --> Input Class Initialized
INFO - 2017-03-10 02:29:28 --> Language Class Initialized
INFO - 2017-03-10 02:29:28 --> Loader Class Initialized
INFO - 2017-03-10 02:29:28 --> Database Driver Class Initialized
INFO - 2017-03-10 02:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:29:29 --> Controller Class Initialized
INFO - 2017-03-10 02:29:29 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:29:29 --> Helper loaded: url_helper
INFO - 2017-03-10 02:29:29 --> Helper loaded: download_helper
INFO - 2017-03-10 02:29:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:29:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:29:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:29:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:29:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:29:29 --> Final output sent to browser
DEBUG - 2017-03-10 02:29:29 --> Total execution time: 1.0893
INFO - 2017-03-10 02:29:29 --> Config Class Initialized
INFO - 2017-03-10 02:29:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:29:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:29:29 --> Utf8 Class Initialized
INFO - 2017-03-10 02:29:29 --> URI Class Initialized
INFO - 2017-03-10 02:29:29 --> Router Class Initialized
INFO - 2017-03-10 02:29:29 --> Output Class Initialized
INFO - 2017-03-10 02:29:29 --> Security Class Initialized
DEBUG - 2017-03-10 02:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:29:29 --> Input Class Initialized
INFO - 2017-03-10 02:29:29 --> Language Class Initialized
ERROR - 2017-03-10 02:29:29 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:29:29 --> Config Class Initialized
INFO - 2017-03-10 02:29:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:29:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:29:29 --> Utf8 Class Initialized
INFO - 2017-03-10 02:29:29 --> URI Class Initialized
INFO - 2017-03-10 02:29:29 --> Router Class Initialized
INFO - 2017-03-10 02:29:29 --> Output Class Initialized
INFO - 2017-03-10 02:29:29 --> Security Class Initialized
DEBUG - 2017-03-10 02:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:29:29 --> Input Class Initialized
INFO - 2017-03-10 02:29:29 --> Language Class Initialized
ERROR - 2017-03-10 02:29:29 --> 404 Page Not Found: Scripts/jquery.countdown.js
INFO - 2017-03-10 02:29:30 --> Config Class Initialized
INFO - 2017-03-10 02:29:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:29:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:29:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:29:30 --> URI Class Initialized
INFO - 2017-03-10 02:29:30 --> Router Class Initialized
INFO - 2017-03-10 02:29:30 --> Output Class Initialized
INFO - 2017-03-10 02:29:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:29:30 --> Input Class Initialized
INFO - 2017-03-10 02:29:30 --> Language Class Initialized
INFO - 2017-03-10 02:29:30 --> Loader Class Initialized
INFO - 2017-03-10 02:29:30 --> Database Driver Class Initialized
INFO - 2017-03-10 02:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:29:30 --> Controller Class Initialized
INFO - 2017-03-10 02:29:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:29:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:29:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:29:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:29:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:29:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:29:30 --> Total execution time: 0.0505
INFO - 2017-03-10 02:31:29 --> Config Class Initialized
INFO - 2017-03-10 02:31:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:31:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:31:29 --> Utf8 Class Initialized
INFO - 2017-03-10 02:31:29 --> URI Class Initialized
DEBUG - 2017-03-10 02:31:29 --> No URI present. Default controller set.
INFO - 2017-03-10 02:31:29 --> Router Class Initialized
INFO - 2017-03-10 02:31:29 --> Output Class Initialized
INFO - 2017-03-10 02:31:29 --> Security Class Initialized
DEBUG - 2017-03-10 02:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:31:29 --> Input Class Initialized
INFO - 2017-03-10 02:31:29 --> Language Class Initialized
INFO - 2017-03-10 02:31:29 --> Loader Class Initialized
INFO - 2017-03-10 02:31:29 --> Database Driver Class Initialized
INFO - 2017-03-10 02:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:31:29 --> Controller Class Initialized
INFO - 2017-03-10 02:31:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:31:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:31:30 --> Total execution time: 1.2082
INFO - 2017-03-10 02:31:32 --> Config Class Initialized
INFO - 2017-03-10 02:31:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:31:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:31:32 --> Utf8 Class Initialized
INFO - 2017-03-10 02:31:33 --> URI Class Initialized
INFO - 2017-03-10 02:31:33 --> Router Class Initialized
INFO - 2017-03-10 02:31:33 --> Output Class Initialized
INFO - 2017-03-10 02:31:33 --> Security Class Initialized
DEBUG - 2017-03-10 02:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:31:33 --> Input Class Initialized
INFO - 2017-03-10 02:31:33 --> Language Class Initialized
ERROR - 2017-03-10 02:31:33 --> 404 Page Not Found: Scripts/jquery.countdown.js
INFO - 2017-03-10 02:32:29 --> Config Class Initialized
INFO - 2017-03-10 02:32:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:32:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:32:29 --> Utf8 Class Initialized
INFO - 2017-03-10 02:32:29 --> URI Class Initialized
INFO - 2017-03-10 02:32:29 --> Router Class Initialized
INFO - 2017-03-10 02:32:29 --> Output Class Initialized
INFO - 2017-03-10 02:32:29 --> Security Class Initialized
DEBUG - 2017-03-10 02:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:32:29 --> Input Class Initialized
INFO - 2017-03-10 02:32:29 --> Language Class Initialized
INFO - 2017-03-10 02:32:29 --> Loader Class Initialized
INFO - 2017-03-10 02:32:29 --> Database Driver Class Initialized
INFO - 2017-03-10 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:32:30 --> Controller Class Initialized
INFO - 2017-03-10 02:32:30 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:32:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:32:30 --> Helper loaded: url_helper
INFO - 2017-03-10 02:32:30 --> Helper loaded: download_helper
INFO - 2017-03-10 02:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:32:30 --> Final output sent to browser
DEBUG - 2017-03-10 02:32:30 --> Total execution time: 1.1133
INFO - 2017-03-10 02:32:30 --> Config Class Initialized
INFO - 2017-03-10 02:32:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:32:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:32:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:32:30 --> URI Class Initialized
INFO - 2017-03-10 02:32:30 --> Router Class Initialized
INFO - 2017-03-10 02:32:30 --> Output Class Initialized
INFO - 2017-03-10 02:32:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:32:30 --> Input Class Initialized
INFO - 2017-03-10 02:32:30 --> Language Class Initialized
ERROR - 2017-03-10 02:32:30 --> 404 Page Not Found: User/js
INFO - 2017-03-10 02:32:30 --> Config Class Initialized
INFO - 2017-03-10 02:32:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:32:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:32:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:32:30 --> URI Class Initialized
INFO - 2017-03-10 02:32:30 --> Router Class Initialized
INFO - 2017-03-10 02:32:30 --> Output Class Initialized
INFO - 2017-03-10 02:32:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:32:30 --> Input Class Initialized
INFO - 2017-03-10 02:32:30 --> Language Class Initialized
ERROR - 2017-03-10 02:32:30 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:32:30 --> Config Class Initialized
INFO - 2017-03-10 02:32:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:32:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:32:30 --> Utf8 Class Initialized
INFO - 2017-03-10 02:32:30 --> URI Class Initialized
INFO - 2017-03-10 02:32:30 --> Router Class Initialized
INFO - 2017-03-10 02:32:30 --> Output Class Initialized
INFO - 2017-03-10 02:32:30 --> Security Class Initialized
DEBUG - 2017-03-10 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:32:30 --> Input Class Initialized
INFO - 2017-03-10 02:32:30 --> Language Class Initialized
INFO - 2017-03-10 02:32:30 --> Loader Class Initialized
INFO - 2017-03-10 02:32:30 --> Database Driver Class Initialized
INFO - 2017-03-10 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:32:30 --> Controller Class Initialized
INFO - 2017-03-10 02:32:30 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:32:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:32:31 --> Final output sent to browser
DEBUG - 2017-03-10 02:32:31 --> Total execution time: 0.2528
INFO - 2017-03-10 02:33:50 --> Config Class Initialized
INFO - 2017-03-10 02:33:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:33:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:33:50 --> Utf8 Class Initialized
INFO - 2017-03-10 02:33:50 --> URI Class Initialized
INFO - 2017-03-10 02:33:50 --> Router Class Initialized
INFO - 2017-03-10 02:33:50 --> Output Class Initialized
INFO - 2017-03-10 02:33:50 --> Security Class Initialized
DEBUG - 2017-03-10 02:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:33:50 --> Input Class Initialized
INFO - 2017-03-10 02:33:50 --> Language Class Initialized
INFO - 2017-03-10 02:33:50 --> Loader Class Initialized
INFO - 2017-03-10 02:33:51 --> Database Driver Class Initialized
INFO - 2017-03-10 02:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:33:51 --> Controller Class Initialized
INFO - 2017-03-10 02:33:51 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:33:51 --> Helper loaded: url_helper
INFO - 2017-03-10 02:33:51 --> Helper loaded: download_helper
INFO - 2017-03-10 02:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:33:51 --> Final output sent to browser
DEBUG - 2017-03-10 02:33:51 --> Total execution time: 1.0956
INFO - 2017-03-10 02:33:51 --> Config Class Initialized
INFO - 2017-03-10 02:33:51 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:33:51 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:33:51 --> Utf8 Class Initialized
INFO - 2017-03-10 02:33:51 --> URI Class Initialized
INFO - 2017-03-10 02:33:51 --> Router Class Initialized
INFO - 2017-03-10 02:33:51 --> Output Class Initialized
INFO - 2017-03-10 02:33:51 --> Config Class Initialized
INFO - 2017-03-10 02:33:51 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:33:51 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:33:51 --> Utf8 Class Initialized
INFO - 2017-03-10 02:33:51 --> Security Class Initialized
DEBUG - 2017-03-10 02:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:33:51 --> Input Class Initialized
INFO - 2017-03-10 02:33:51 --> Language Class Initialized
INFO - 2017-03-10 02:33:51 --> URI Class Initialized
ERROR - 2017-03-10 02:33:51 --> 404 Page Not Found: Templates/js
INFO - 2017-03-10 02:33:51 --> Router Class Initialized
INFO - 2017-03-10 02:33:51 --> Output Class Initialized
INFO - 2017-03-10 02:33:51 --> Security Class Initialized
DEBUG - 2017-03-10 02:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:33:51 --> Input Class Initialized
INFO - 2017-03-10 02:33:51 --> Language Class Initialized
ERROR - 2017-03-10 02:33:51 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:33:52 --> Config Class Initialized
INFO - 2017-03-10 02:33:52 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:33:52 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:33:52 --> Utf8 Class Initialized
INFO - 2017-03-10 02:33:52 --> URI Class Initialized
INFO - 2017-03-10 02:33:52 --> Router Class Initialized
INFO - 2017-03-10 02:33:52 --> Output Class Initialized
INFO - 2017-03-10 02:33:52 --> Security Class Initialized
DEBUG - 2017-03-10 02:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:33:52 --> Input Class Initialized
INFO - 2017-03-10 02:33:52 --> Language Class Initialized
INFO - 2017-03-10 02:33:52 --> Loader Class Initialized
INFO - 2017-03-10 02:33:52 --> Database Driver Class Initialized
INFO - 2017-03-10 02:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:33:52 --> Controller Class Initialized
INFO - 2017-03-10 02:33:52 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:33:52 --> Final output sent to browser
DEBUG - 2017-03-10 02:33:52 --> Total execution time: 0.2578
INFO - 2017-03-10 02:37:44 --> Config Class Initialized
INFO - 2017-03-10 02:37:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:37:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:37:44 --> Utf8 Class Initialized
INFO - 2017-03-10 02:37:44 --> URI Class Initialized
INFO - 2017-03-10 02:37:44 --> Router Class Initialized
INFO - 2017-03-10 02:37:44 --> Output Class Initialized
INFO - 2017-03-10 02:37:44 --> Security Class Initialized
DEBUG - 2017-03-10 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:37:44 --> Input Class Initialized
INFO - 2017-03-10 02:37:44 --> Language Class Initialized
INFO - 2017-03-10 02:37:44 --> Loader Class Initialized
INFO - 2017-03-10 02:37:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:37:45 --> Controller Class Initialized
INFO - 2017-03-10 02:37:45 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:37:45 --> Helper loaded: url_helper
INFO - 2017-03-10 02:37:45 --> Helper loaded: download_helper
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:37:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:37:45 --> Total execution time: 1.0959
INFO - 2017-03-10 02:37:45 --> Config Class Initialized
INFO - 2017-03-10 02:37:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:37:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:37:45 --> Utf8 Class Initialized
INFO - 2017-03-10 02:37:45 --> URI Class Initialized
INFO - 2017-03-10 02:37:45 --> Router Class Initialized
INFO - 2017-03-10 02:37:45 --> Output Class Initialized
INFO - 2017-03-10 02:37:45 --> Security Class Initialized
DEBUG - 2017-03-10 02:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:37:45 --> Input Class Initialized
INFO - 2017-03-10 02:37:45 --> Language Class Initialized
INFO - 2017-03-10 02:37:45 --> Loader Class Initialized
INFO - 2017-03-10 02:37:45 --> Database Driver Class Initialized
INFO - 2017-03-10 02:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:37:45 --> Controller Class Initialized
INFO - 2017-03-10 02:37:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:37:45 --> Final output sent to browser
DEBUG - 2017-03-10 02:37:45 --> Total execution time: 0.2494
INFO - 2017-03-10 02:37:48 --> Config Class Initialized
INFO - 2017-03-10 02:37:48 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:37:48 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:37:48 --> Utf8 Class Initialized
INFO - 2017-03-10 02:37:48 --> URI Class Initialized
INFO - 2017-03-10 02:37:48 --> Router Class Initialized
INFO - 2017-03-10 02:37:48 --> Output Class Initialized
INFO - 2017-03-10 02:37:48 --> Security Class Initialized
DEBUG - 2017-03-10 02:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:37:48 --> Input Class Initialized
INFO - 2017-03-10 02:37:48 --> Language Class Initialized
ERROR - 2017-03-10 02:37:48 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:38:21 --> Config Class Initialized
INFO - 2017-03-10 02:38:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:38:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:38:21 --> Utf8 Class Initialized
INFO - 2017-03-10 02:38:21 --> URI Class Initialized
INFO - 2017-03-10 02:38:21 --> Router Class Initialized
INFO - 2017-03-10 02:38:21 --> Output Class Initialized
INFO - 2017-03-10 02:38:21 --> Security Class Initialized
DEBUG - 2017-03-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:38:21 --> Input Class Initialized
INFO - 2017-03-10 02:38:21 --> Language Class Initialized
INFO - 2017-03-10 02:38:21 --> Loader Class Initialized
INFO - 2017-03-10 02:38:21 --> Database Driver Class Initialized
INFO - 2017-03-10 02:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:38:21 --> Controller Class Initialized
INFO - 2017-03-10 02:38:21 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:38:21 --> Helper loaded: url_helper
INFO - 2017-03-10 02:38:21 --> Helper loaded: download_helper
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:38:21 --> Final output sent to browser
DEBUG - 2017-03-10 02:38:21 --> Total execution time: 0.0204
INFO - 2017-03-10 02:38:21 --> Config Class Initialized
INFO - 2017-03-10 02:38:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:38:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:38:21 --> Utf8 Class Initialized
INFO - 2017-03-10 02:38:21 --> URI Class Initialized
INFO - 2017-03-10 02:38:21 --> Router Class Initialized
INFO - 2017-03-10 02:38:21 --> Output Class Initialized
INFO - 2017-03-10 02:38:21 --> Security Class Initialized
DEBUG - 2017-03-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:38:21 --> Input Class Initialized
INFO - 2017-03-10 02:38:21 --> Language Class Initialized
INFO - 2017-03-10 02:38:21 --> Loader Class Initialized
INFO - 2017-03-10 02:38:21 --> Database Driver Class Initialized
INFO - 2017-03-10 02:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:38:21 --> Controller Class Initialized
INFO - 2017-03-10 02:38:21 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:38:21 --> Final output sent to browser
DEBUG - 2017-03-10 02:38:21 --> Total execution time: 0.0139
INFO - 2017-03-10 02:38:24 --> Config Class Initialized
INFO - 2017-03-10 02:38:24 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:38:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:38:24 --> Utf8 Class Initialized
INFO - 2017-03-10 02:38:24 --> URI Class Initialized
INFO - 2017-03-10 02:38:24 --> Router Class Initialized
INFO - 2017-03-10 02:38:24 --> Output Class Initialized
INFO - 2017-03-10 02:38:24 --> Security Class Initialized
DEBUG - 2017-03-10 02:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:38:24 --> Input Class Initialized
INFO - 2017-03-10 02:38:24 --> Language Class Initialized
ERROR - 2017-03-10 02:38:24 --> 404 Page Not Found: Templates/usuario
INFO - 2017-03-10 02:39:31 --> Config Class Initialized
INFO - 2017-03-10 02:39:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:39:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:39:31 --> Utf8 Class Initialized
INFO - 2017-03-10 02:39:31 --> URI Class Initialized
INFO - 2017-03-10 02:39:31 --> Router Class Initialized
INFO - 2017-03-10 02:39:31 --> Output Class Initialized
INFO - 2017-03-10 02:39:31 --> Security Class Initialized
DEBUG - 2017-03-10 02:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:39:31 --> Input Class Initialized
INFO - 2017-03-10 02:39:31 --> Language Class Initialized
INFO - 2017-03-10 02:39:31 --> Loader Class Initialized
INFO - 2017-03-10 02:39:31 --> Database Driver Class Initialized
INFO - 2017-03-10 02:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:39:32 --> Controller Class Initialized
INFO - 2017-03-10 02:39:32 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:39:32 --> Helper loaded: url_helper
INFO - 2017-03-10 02:39:32 --> Helper loaded: download_helper
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:39:32 --> Final output sent to browser
DEBUG - 2017-03-10 02:39:32 --> Total execution time: 1.1177
INFO - 2017-03-10 02:39:32 --> Config Class Initialized
INFO - 2017-03-10 02:39:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:39:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:39:32 --> Utf8 Class Initialized
INFO - 2017-03-10 02:39:32 --> URI Class Initialized
INFO - 2017-03-10 02:39:32 --> Router Class Initialized
INFO - 2017-03-10 02:39:32 --> Output Class Initialized
INFO - 2017-03-10 02:39:32 --> Security Class Initialized
DEBUG - 2017-03-10 02:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:39:32 --> Input Class Initialized
INFO - 2017-03-10 02:39:32 --> Language Class Initialized
INFO - 2017-03-10 02:39:32 --> Loader Class Initialized
INFO - 2017-03-10 02:39:32 --> Database Driver Class Initialized
INFO - 2017-03-10 02:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:39:32 --> Controller Class Initialized
INFO - 2017-03-10 02:39:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:39:32 --> Final output sent to browser
DEBUG - 2017-03-10 02:39:32 --> Total execution time: 0.2669
INFO - 2017-03-10 02:39:43 --> Config Class Initialized
INFO - 2017-03-10 02:39:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:39:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:39:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:39:43 --> URI Class Initialized
INFO - 2017-03-10 02:39:43 --> Router Class Initialized
INFO - 2017-03-10 02:39:43 --> Output Class Initialized
INFO - 2017-03-10 02:39:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:39:43 --> Input Class Initialized
INFO - 2017-03-10 02:39:43 --> Language Class Initialized
INFO - 2017-03-10 02:39:43 --> Loader Class Initialized
INFO - 2017-03-10 02:39:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:39:43 --> Controller Class Initialized
INFO - 2017-03-10 02:39:43 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:39:43 --> Helper loaded: url_helper
INFO - 2017-03-10 02:39:43 --> Helper loaded: download_helper
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:39:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:39:43 --> Total execution time: 0.0222
INFO - 2017-03-10 02:39:43 --> Config Class Initialized
INFO - 2017-03-10 02:39:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:39:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:39:43 --> Utf8 Class Initialized
INFO - 2017-03-10 02:39:43 --> URI Class Initialized
INFO - 2017-03-10 02:39:43 --> Router Class Initialized
INFO - 2017-03-10 02:39:43 --> Output Class Initialized
INFO - 2017-03-10 02:39:43 --> Security Class Initialized
DEBUG - 2017-03-10 02:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:39:43 --> Input Class Initialized
INFO - 2017-03-10 02:39:43 --> Language Class Initialized
INFO - 2017-03-10 02:39:43 --> Loader Class Initialized
INFO - 2017-03-10 02:39:43 --> Database Driver Class Initialized
INFO - 2017-03-10 02:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:39:43 --> Controller Class Initialized
INFO - 2017-03-10 02:39:43 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:39:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:39:43 --> Final output sent to browser
DEBUG - 2017-03-10 02:39:43 --> Total execution time: 0.0147
INFO - 2017-03-10 02:40:07 --> Config Class Initialized
INFO - 2017-03-10 02:40:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:07 --> URI Class Initialized
INFO - 2017-03-10 02:40:07 --> Router Class Initialized
INFO - 2017-03-10 02:40:07 --> Output Class Initialized
INFO - 2017-03-10 02:40:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:07 --> Input Class Initialized
INFO - 2017-03-10 02:40:07 --> Language Class Initialized
INFO - 2017-03-10 02:40:07 --> Loader Class Initialized
INFO - 2017-03-10 02:40:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:07 --> Controller Class Initialized
INFO - 2017-03-10 02:40:07 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:07 --> Helper loaded: url_helper
INFO - 2017-03-10 02:40:07 --> Helper loaded: download_helper
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:07 --> Total execution time: 0.0198
INFO - 2017-03-10 02:40:07 --> Config Class Initialized
INFO - 2017-03-10 02:40:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:07 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:07 --> URI Class Initialized
INFO - 2017-03-10 02:40:07 --> Router Class Initialized
INFO - 2017-03-10 02:40:07 --> Output Class Initialized
INFO - 2017-03-10 02:40:07 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:07 --> Input Class Initialized
INFO - 2017-03-10 02:40:07 --> Language Class Initialized
INFO - 2017-03-10 02:40:07 --> Loader Class Initialized
INFO - 2017-03-10 02:40:07 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:07 --> Controller Class Initialized
INFO - 2017-03-10 02:40:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:40:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:07 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:07 --> Total execution time: 0.0139
INFO - 2017-03-10 02:40:08 --> Config Class Initialized
INFO - 2017-03-10 02:40:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:08 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:08 --> URI Class Initialized
INFO - 2017-03-10 02:40:08 --> Router Class Initialized
INFO - 2017-03-10 02:40:08 --> Output Class Initialized
INFO - 2017-03-10 02:40:08 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:08 --> Input Class Initialized
INFO - 2017-03-10 02:40:08 --> Language Class Initialized
INFO - 2017-03-10 02:40:08 --> Loader Class Initialized
INFO - 2017-03-10 02:40:08 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:08 --> Controller Class Initialized
INFO - 2017-03-10 02:40:08 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:08 --> Helper loaded: url_helper
INFO - 2017-03-10 02:40:08 --> Helper loaded: download_helper
INFO - 2017-03-10 02:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:40:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:08 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:08 --> Total execution time: 0.0209
INFO - 2017-03-10 02:40:09 --> Config Class Initialized
INFO - 2017-03-10 02:40:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:09 --> URI Class Initialized
INFO - 2017-03-10 02:40:09 --> Router Class Initialized
INFO - 2017-03-10 02:40:09 --> Output Class Initialized
INFO - 2017-03-10 02:40:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:09 --> Input Class Initialized
INFO - 2017-03-10 02:40:09 --> Language Class Initialized
INFO - 2017-03-10 02:40:09 --> Loader Class Initialized
INFO - 2017-03-10 02:40:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:09 --> Controller Class Initialized
INFO - 2017-03-10 02:40:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:09 --> Total execution time: 0.0137
INFO - 2017-03-10 02:40:09 --> Config Class Initialized
INFO - 2017-03-10 02:40:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:09 --> URI Class Initialized
INFO - 2017-03-10 02:40:09 --> Router Class Initialized
INFO - 2017-03-10 02:40:09 --> Output Class Initialized
INFO - 2017-03-10 02:40:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:09 --> Input Class Initialized
INFO - 2017-03-10 02:40:09 --> Language Class Initialized
INFO - 2017-03-10 02:40:09 --> Loader Class Initialized
INFO - 2017-03-10 02:40:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:09 --> Controller Class Initialized
INFO - 2017-03-10 02:40:09 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:09 --> Helper loaded: url_helper
INFO - 2017-03-10 02:40:09 --> Helper loaded: download_helper
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:09 --> Total execution time: 0.0194
INFO - 2017-03-10 02:40:09 --> Config Class Initialized
INFO - 2017-03-10 02:40:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:09 --> URI Class Initialized
INFO - 2017-03-10 02:40:09 --> Router Class Initialized
INFO - 2017-03-10 02:40:09 --> Output Class Initialized
INFO - 2017-03-10 02:40:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:09 --> Input Class Initialized
INFO - 2017-03-10 02:40:09 --> Language Class Initialized
INFO - 2017-03-10 02:40:09 --> Loader Class Initialized
INFO - 2017-03-10 02:40:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:09 --> Controller Class Initialized
INFO - 2017-03-10 02:40:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:09 --> Total execution time: 0.0144
INFO - 2017-03-10 02:40:09 --> Config Class Initialized
INFO - 2017-03-10 02:40:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:09 --> URI Class Initialized
INFO - 2017-03-10 02:40:09 --> Router Class Initialized
INFO - 2017-03-10 02:40:09 --> Output Class Initialized
INFO - 2017-03-10 02:40:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:09 --> Input Class Initialized
INFO - 2017-03-10 02:40:09 --> Language Class Initialized
INFO - 2017-03-10 02:40:09 --> Loader Class Initialized
INFO - 2017-03-10 02:40:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:09 --> Controller Class Initialized
INFO - 2017-03-10 02:40:09 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:09 --> Helper loaded: url_helper
INFO - 2017-03-10 02:40:09 --> Helper loaded: download_helper
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:09 --> Total execution time: 0.0727
INFO - 2017-03-10 02:40:09 --> Config Class Initialized
INFO - 2017-03-10 02:40:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:09 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:09 --> URI Class Initialized
INFO - 2017-03-10 02:40:09 --> Router Class Initialized
INFO - 2017-03-10 02:40:09 --> Output Class Initialized
INFO - 2017-03-10 02:40:09 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:09 --> Input Class Initialized
INFO - 2017-03-10 02:40:09 --> Language Class Initialized
INFO - 2017-03-10 02:40:09 --> Loader Class Initialized
INFO - 2017-03-10 02:40:09 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:09 --> Controller Class Initialized
INFO - 2017-03-10 02:40:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:09 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:09 --> Total execution time: 0.0151
INFO - 2017-03-10 02:40:10 --> Config Class Initialized
INFO - 2017-03-10 02:40:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:10 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:10 --> URI Class Initialized
INFO - 2017-03-10 02:40:10 --> Router Class Initialized
INFO - 2017-03-10 02:40:10 --> Output Class Initialized
INFO - 2017-03-10 02:40:10 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:10 --> Input Class Initialized
INFO - 2017-03-10 02:40:10 --> Language Class Initialized
INFO - 2017-03-10 02:40:10 --> Loader Class Initialized
INFO - 2017-03-10 02:40:10 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:10 --> Controller Class Initialized
INFO - 2017-03-10 02:40:10 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:10 --> Helper loaded: url_helper
INFO - 2017-03-10 02:40:10 --> Helper loaded: download_helper
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:10 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:10 --> Total execution time: 0.0199
INFO - 2017-03-10 02:40:10 --> Config Class Initialized
INFO - 2017-03-10 02:40:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:10 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:10 --> URI Class Initialized
INFO - 2017-03-10 02:40:10 --> Router Class Initialized
INFO - 2017-03-10 02:40:10 --> Output Class Initialized
INFO - 2017-03-10 02:40:10 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:10 --> Input Class Initialized
INFO - 2017-03-10 02:40:10 --> Language Class Initialized
INFO - 2017-03-10 02:40:10 --> Loader Class Initialized
INFO - 2017-03-10 02:40:10 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:10 --> Controller Class Initialized
INFO - 2017-03-10 02:40:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:10 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:10 --> Total execution time: 0.0138
INFO - 2017-03-10 02:40:47 --> Config Class Initialized
INFO - 2017-03-10 02:40:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:47 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:47 --> URI Class Initialized
INFO - 2017-03-10 02:40:47 --> Router Class Initialized
INFO - 2017-03-10 02:40:47 --> Output Class Initialized
INFO - 2017-03-10 02:40:47 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:47 --> Input Class Initialized
INFO - 2017-03-10 02:40:47 --> Language Class Initialized
INFO - 2017-03-10 02:40:47 --> Loader Class Initialized
INFO - 2017-03-10 02:40:47 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:47 --> Controller Class Initialized
INFO - 2017-03-10 02:40:47 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:47 --> Helper loaded: url_helper
INFO - 2017-03-10 02:40:47 --> Helper loaded: download_helper
INFO - 2017-03-10 02:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:47 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:47 --> Total execution time: 0.0545
INFO - 2017-03-10 02:40:48 --> Config Class Initialized
INFO - 2017-03-10 02:40:48 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:40:48 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:40:48 --> Utf8 Class Initialized
INFO - 2017-03-10 02:40:48 --> URI Class Initialized
INFO - 2017-03-10 02:40:48 --> Router Class Initialized
INFO - 2017-03-10 02:40:48 --> Output Class Initialized
INFO - 2017-03-10 02:40:48 --> Security Class Initialized
DEBUG - 2017-03-10 02:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:40:48 --> Input Class Initialized
INFO - 2017-03-10 02:40:48 --> Language Class Initialized
INFO - 2017-03-10 02:40:48 --> Loader Class Initialized
INFO - 2017-03-10 02:40:48 --> Database Driver Class Initialized
INFO - 2017-03-10 02:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:40:48 --> Controller Class Initialized
INFO - 2017-03-10 02:40:48 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:40:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:40:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:40:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:40:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:40:48 --> Final output sent to browser
DEBUG - 2017-03-10 02:40:48 --> Total execution time: 0.0144
INFO - 2017-03-10 02:41:25 --> Config Class Initialized
INFO - 2017-03-10 02:41:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:41:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:41:25 --> Utf8 Class Initialized
INFO - 2017-03-10 02:41:25 --> URI Class Initialized
INFO - 2017-03-10 02:41:25 --> Router Class Initialized
INFO - 2017-03-10 02:41:25 --> Output Class Initialized
INFO - 2017-03-10 02:41:25 --> Security Class Initialized
DEBUG - 2017-03-10 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:41:25 --> Input Class Initialized
INFO - 2017-03-10 02:41:25 --> Language Class Initialized
INFO - 2017-03-10 02:41:25 --> Loader Class Initialized
INFO - 2017-03-10 02:41:25 --> Database Driver Class Initialized
INFO - 2017-03-10 02:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:41:25 --> Controller Class Initialized
INFO - 2017-03-10 02:41:25 --> Helper loaded: date_helper
DEBUG - 2017-03-10 02:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:41:25 --> Helper loaded: url_helper
INFO - 2017-03-10 02:41:25 --> Helper loaded: download_helper
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:41:25 --> Final output sent to browser
DEBUG - 2017-03-10 02:41:25 --> Total execution time: 0.0739
INFO - 2017-03-10 02:41:25 --> Config Class Initialized
INFO - 2017-03-10 02:41:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 02:41:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 02:41:25 --> Utf8 Class Initialized
INFO - 2017-03-10 02:41:25 --> URI Class Initialized
INFO - 2017-03-10 02:41:25 --> Router Class Initialized
INFO - 2017-03-10 02:41:25 --> Output Class Initialized
INFO - 2017-03-10 02:41:25 --> Security Class Initialized
DEBUG - 2017-03-10 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 02:41:25 --> Input Class Initialized
INFO - 2017-03-10 02:41:25 --> Language Class Initialized
INFO - 2017-03-10 02:41:25 --> Loader Class Initialized
INFO - 2017-03-10 02:41:25 --> Database Driver Class Initialized
INFO - 2017-03-10 02:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 02:41:25 --> Controller Class Initialized
INFO - 2017-03-10 02:41:25 --> Helper loaded: url_helper
DEBUG - 2017-03-10 02:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 02:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 02:41:25 --> Final output sent to browser
DEBUG - 2017-03-10 02:41:25 --> Total execution time: 0.0142
INFO - 2017-03-10 03:53:57 --> Config Class Initialized
INFO - 2017-03-10 03:53:57 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:53:57 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:53:57 --> Utf8 Class Initialized
INFO - 2017-03-10 03:53:57 --> URI Class Initialized
INFO - 2017-03-10 03:53:57 --> Router Class Initialized
INFO - 2017-03-10 03:53:57 --> Output Class Initialized
INFO - 2017-03-10 03:53:57 --> Security Class Initialized
DEBUG - 2017-03-10 03:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:53:57 --> Input Class Initialized
INFO - 2017-03-10 03:53:57 --> Language Class Initialized
INFO - 2017-03-10 03:53:57 --> Loader Class Initialized
INFO - 2017-03-10 03:53:58 --> Database Driver Class Initialized
INFO - 2017-03-10 03:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:53:58 --> Controller Class Initialized
INFO - 2017-03-10 03:53:58 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:53:58 --> Helper loaded: form_helper
INFO - 2017-03-10 03:53:58 --> Form Validation Class Initialized
INFO - 2017-03-10 03:53:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 03:53:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-10 03:53:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 03:53:58 --> Final output sent to browser
DEBUG - 2017-03-10 03:53:58 --> Total execution time: 1.1002
INFO - 2017-03-10 03:53:58 --> Config Class Initialized
INFO - 2017-03-10 03:53:58 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:53:58 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:53:58 --> Utf8 Class Initialized
INFO - 2017-03-10 03:53:58 --> URI Class Initialized
INFO - 2017-03-10 03:53:58 --> Router Class Initialized
INFO - 2017-03-10 03:53:58 --> Output Class Initialized
INFO - 2017-03-10 03:53:58 --> Security Class Initialized
DEBUG - 2017-03-10 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:53:58 --> Input Class Initialized
INFO - 2017-03-10 03:53:58 --> Language Class Initialized
INFO - 2017-03-10 03:53:58 --> Loader Class Initialized
INFO - 2017-03-10 03:53:58 --> Database Driver Class Initialized
INFO - 2017-03-10 03:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:53:58 --> Controller Class Initialized
INFO - 2017-03-10 03:53:58 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:53:59 --> Final output sent to browser
DEBUG - 2017-03-10 03:53:59 --> Total execution time: 0.2757
INFO - 2017-03-10 03:54:12 --> Config Class Initialized
INFO - 2017-03-10 03:54:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:12 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:12 --> URI Class Initialized
INFO - 2017-03-10 03:54:12 --> Router Class Initialized
INFO - 2017-03-10 03:54:12 --> Output Class Initialized
INFO - 2017-03-10 03:54:12 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:12 --> Input Class Initialized
INFO - 2017-03-10 03:54:12 --> Language Class Initialized
INFO - 2017-03-10 03:54:12 --> Loader Class Initialized
INFO - 2017-03-10 03:54:12 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:12 --> Controller Class Initialized
INFO - 2017-03-10 03:54:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:12 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:12 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-10 03:54:12 --> Config Class Initialized
INFO - 2017-03-10 03:54:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:12 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:12 --> URI Class Initialized
INFO - 2017-03-10 03:54:12 --> Router Class Initialized
INFO - 2017-03-10 03:54:12 --> Output Class Initialized
INFO - 2017-03-10 03:54:12 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:12 --> Input Class Initialized
INFO - 2017-03-10 03:54:12 --> Language Class Initialized
INFO - 2017-03-10 03:54:12 --> Loader Class Initialized
INFO - 2017-03-10 03:54:12 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:12 --> Controller Class Initialized
INFO - 2017-03-10 03:54:12 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:13 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:13 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:13 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 03:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 03:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-10 03:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-10 03:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 03:54:13 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:13 --> Total execution time: 0.1090
INFO - 2017-03-10 03:54:13 --> Config Class Initialized
INFO - 2017-03-10 03:54:13 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:13 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:13 --> URI Class Initialized
INFO - 2017-03-10 03:54:13 --> Router Class Initialized
INFO - 2017-03-10 03:54:13 --> Output Class Initialized
INFO - 2017-03-10 03:54:13 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:13 --> Input Class Initialized
INFO - 2017-03-10 03:54:13 --> Language Class Initialized
INFO - 2017-03-10 03:54:13 --> Loader Class Initialized
INFO - 2017-03-10 03:54:13 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:13 --> Controller Class Initialized
INFO - 2017-03-10 03:54:13 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:13 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:13 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:13 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:13 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:13 --> Total execution time: 0.0741
INFO - 2017-03-10 03:54:14 --> Config Class Initialized
INFO - 2017-03-10 03:54:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:14 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:14 --> URI Class Initialized
INFO - 2017-03-10 03:54:14 --> Router Class Initialized
INFO - 2017-03-10 03:54:14 --> Output Class Initialized
INFO - 2017-03-10 03:54:14 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:14 --> Input Class Initialized
INFO - 2017-03-10 03:54:14 --> Language Class Initialized
INFO - 2017-03-10 03:54:14 --> Loader Class Initialized
INFO - 2017-03-10 03:54:14 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:14 --> Controller Class Initialized
INFO - 2017-03-10 03:54:14 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:54:14 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:14 --> Total execution time: 0.0138
INFO - 2017-03-10 03:54:23 --> Config Class Initialized
INFO - 2017-03-10 03:54:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:23 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:23 --> URI Class Initialized
INFO - 2017-03-10 03:54:23 --> Router Class Initialized
INFO - 2017-03-10 03:54:23 --> Output Class Initialized
INFO - 2017-03-10 03:54:23 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:23 --> Input Class Initialized
INFO - 2017-03-10 03:54:23 --> Language Class Initialized
INFO - 2017-03-10 03:54:23 --> Loader Class Initialized
INFO - 2017-03-10 03:54:23 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:23 --> Controller Class Initialized
INFO - 2017-03-10 03:54:23 --> Upload Class Initialized
INFO - 2017-03-10 03:54:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:23 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:23 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 03:54:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 03:54:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-03-10 03:54:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-03-10 03:54:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 03:54:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 03:54:23 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:23 --> Total execution time: 0.1491
INFO - 2017-03-10 03:54:24 --> Config Class Initialized
INFO - 2017-03-10 03:54:24 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:24 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:24 --> URI Class Initialized
INFO - 2017-03-10 03:54:24 --> Router Class Initialized
INFO - 2017-03-10 03:54:24 --> Output Class Initialized
INFO - 2017-03-10 03:54:24 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:24 --> Input Class Initialized
INFO - 2017-03-10 03:54:24 --> Language Class Initialized
INFO - 2017-03-10 03:54:24 --> Loader Class Initialized
INFO - 2017-03-10 03:54:24 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:24 --> Controller Class Initialized
INFO - 2017-03-10 03:54:24 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:54:24 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:24 --> Total execution time: 0.0136
INFO - 2017-03-10 03:54:27 --> Config Class Initialized
INFO - 2017-03-10 03:54:27 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:27 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:27 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:27 --> URI Class Initialized
INFO - 2017-03-10 03:54:27 --> Router Class Initialized
INFO - 2017-03-10 03:54:27 --> Output Class Initialized
INFO - 2017-03-10 03:54:27 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:27 --> Input Class Initialized
INFO - 2017-03-10 03:54:27 --> Language Class Initialized
INFO - 2017-03-10 03:54:27 --> Loader Class Initialized
INFO - 2017-03-10 03:54:27 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:27 --> Controller Class Initialized
INFO - 2017-03-10 03:54:27 --> Upload Class Initialized
INFO - 2017-03-10 03:54:27 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:27 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:27 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:27 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 03:54:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 03:54:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-03-10 03:54:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-03-10 03:54:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-10 03:54:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 03:54:27 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:27 --> Total execution time: 0.0499
INFO - 2017-03-10 03:54:28 --> Config Class Initialized
INFO - 2017-03-10 03:54:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:28 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:28 --> URI Class Initialized
INFO - 2017-03-10 03:54:28 --> Router Class Initialized
INFO - 2017-03-10 03:54:28 --> Output Class Initialized
INFO - 2017-03-10 03:54:28 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:28 --> Input Class Initialized
INFO - 2017-03-10 03:54:28 --> Language Class Initialized
INFO - 2017-03-10 03:54:28 --> Loader Class Initialized
INFO - 2017-03-10 03:54:28 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:28 --> Controller Class Initialized
INFO - 2017-03-10 03:54:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:54:28 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:28 --> Total execution time: 0.0138
INFO - 2017-03-10 03:54:31 --> Config Class Initialized
INFO - 2017-03-10 03:54:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:31 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:31 --> URI Class Initialized
INFO - 2017-03-10 03:54:31 --> Router Class Initialized
INFO - 2017-03-10 03:54:31 --> Output Class Initialized
INFO - 2017-03-10 03:54:31 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:31 --> Input Class Initialized
INFO - 2017-03-10 03:54:31 --> Language Class Initialized
INFO - 2017-03-10 03:54:31 --> Loader Class Initialized
INFO - 2017-03-10 03:54:31 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:31 --> Controller Class Initialized
INFO - 2017-03-10 03:54:31 --> Upload Class Initialized
INFO - 2017-03-10 03:54:31 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:31 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:31 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:31 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:31 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:31 --> Total execution time: 0.0155
INFO - 2017-03-10 03:54:37 --> Config Class Initialized
INFO - 2017-03-10 03:54:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:37 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:37 --> URI Class Initialized
INFO - 2017-03-10 03:54:37 --> Router Class Initialized
INFO - 2017-03-10 03:54:37 --> Output Class Initialized
INFO - 2017-03-10 03:54:37 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:37 --> Input Class Initialized
INFO - 2017-03-10 03:54:37 --> Language Class Initialized
INFO - 2017-03-10 03:54:37 --> Loader Class Initialized
INFO - 2017-03-10 03:54:37 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:37 --> Controller Class Initialized
INFO - 2017-03-10 03:54:37 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:37 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:37 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 03:54:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-10 03:54:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-03-10 03:54:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-03-10 03:54:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 03:54:37 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:37 --> Total execution time: 0.0489
INFO - 2017-03-10 03:54:38 --> Config Class Initialized
INFO - 2017-03-10 03:54:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:38 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:38 --> URI Class Initialized
INFO - 2017-03-10 03:54:38 --> Router Class Initialized
INFO - 2017-03-10 03:54:38 --> Output Class Initialized
INFO - 2017-03-10 03:54:38 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:38 --> Input Class Initialized
INFO - 2017-03-10 03:54:38 --> Language Class Initialized
INFO - 2017-03-10 03:54:38 --> Loader Class Initialized
INFO - 2017-03-10 03:54:38 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:38 --> Controller Class Initialized
INFO - 2017-03-10 03:54:38 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:38 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:38 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:38 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:38 --> Total execution time: 0.0151
INFO - 2017-03-10 03:54:38 --> Config Class Initialized
INFO - 2017-03-10 03:54:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:38 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:38 --> URI Class Initialized
INFO - 2017-03-10 03:54:38 --> Router Class Initialized
INFO - 2017-03-10 03:54:38 --> Output Class Initialized
INFO - 2017-03-10 03:54:38 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:38 --> Input Class Initialized
INFO - 2017-03-10 03:54:38 --> Language Class Initialized
INFO - 2017-03-10 03:54:38 --> Loader Class Initialized
INFO - 2017-03-10 03:54:38 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:38 --> Controller Class Initialized
INFO - 2017-03-10 03:54:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:54:38 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:38 --> Total execution time: 0.0147
INFO - 2017-03-10 03:54:40 --> Config Class Initialized
INFO - 2017-03-10 03:54:40 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:40 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:40 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:40 --> URI Class Initialized
INFO - 2017-03-10 03:54:40 --> Router Class Initialized
INFO - 2017-03-10 03:54:40 --> Output Class Initialized
INFO - 2017-03-10 03:54:40 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:40 --> Input Class Initialized
INFO - 2017-03-10 03:54:40 --> Language Class Initialized
INFO - 2017-03-10 03:54:40 --> Loader Class Initialized
INFO - 2017-03-10 03:54:40 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:40 --> Controller Class Initialized
INFO - 2017-03-10 03:54:40 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:40 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:40 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:40 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:40 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:40 --> Total execution time: 0.0148
INFO - 2017-03-10 03:54:44 --> Config Class Initialized
INFO - 2017-03-10 03:54:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:44 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:44 --> URI Class Initialized
INFO - 2017-03-10 03:54:44 --> Router Class Initialized
INFO - 2017-03-10 03:54:44 --> Output Class Initialized
INFO - 2017-03-10 03:54:44 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:44 --> Input Class Initialized
INFO - 2017-03-10 03:54:44 --> Language Class Initialized
INFO - 2017-03-10 03:54:44 --> Loader Class Initialized
INFO - 2017-03-10 03:54:44 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:44 --> Controller Class Initialized
INFO - 2017-03-10 03:54:44 --> Helper loaded: date_helper
INFO - 2017-03-10 03:54:44 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:44 --> Helper loaded: form_helper
INFO - 2017-03-10 03:54:44 --> Form Validation Class Initialized
INFO - 2017-03-10 03:54:44 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:44 --> Total execution time: 0.0164
INFO - 2017-03-10 03:54:49 --> Config Class Initialized
INFO - 2017-03-10 03:54:49 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:54:49 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:54:49 --> Utf8 Class Initialized
INFO - 2017-03-10 03:54:49 --> URI Class Initialized
DEBUG - 2017-03-10 03:54:49 --> No URI present. Default controller set.
INFO - 2017-03-10 03:54:49 --> Router Class Initialized
INFO - 2017-03-10 03:54:49 --> Output Class Initialized
INFO - 2017-03-10 03:54:49 --> Security Class Initialized
DEBUG - 2017-03-10 03:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:54:49 --> Input Class Initialized
INFO - 2017-03-10 03:54:49 --> Language Class Initialized
INFO - 2017-03-10 03:54:49 --> Loader Class Initialized
INFO - 2017-03-10 03:54:49 --> Database Driver Class Initialized
INFO - 2017-03-10 03:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:54:49 --> Controller Class Initialized
INFO - 2017-03-10 03:54:49 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:54:49 --> Final output sent to browser
DEBUG - 2017-03-10 03:54:49 --> Total execution time: 0.0141
INFO - 2017-03-10 03:55:03 --> Config Class Initialized
INFO - 2017-03-10 03:55:03 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:55:03 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:55:03 --> Utf8 Class Initialized
INFO - 2017-03-10 03:55:03 --> URI Class Initialized
INFO - 2017-03-10 03:55:03 --> Router Class Initialized
INFO - 2017-03-10 03:55:03 --> Output Class Initialized
INFO - 2017-03-10 03:55:03 --> Security Class Initialized
DEBUG - 2017-03-10 03:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:55:03 --> Input Class Initialized
INFO - 2017-03-10 03:55:03 --> Language Class Initialized
INFO - 2017-03-10 03:55:03 --> Loader Class Initialized
INFO - 2017-03-10 03:55:03 --> Database Driver Class Initialized
INFO - 2017-03-10 03:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:55:03 --> Controller Class Initialized
INFO - 2017-03-10 03:55:03 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:55:03 --> Final output sent to browser
DEBUG - 2017-03-10 03:55:03 --> Total execution time: 0.0141
INFO - 2017-03-10 03:55:07 --> Config Class Initialized
INFO - 2017-03-10 03:55:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:55:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:55:07 --> Utf8 Class Initialized
INFO - 2017-03-10 03:55:07 --> URI Class Initialized
INFO - 2017-03-10 03:55:07 --> Router Class Initialized
INFO - 2017-03-10 03:55:07 --> Output Class Initialized
INFO - 2017-03-10 03:55:07 --> Security Class Initialized
DEBUG - 2017-03-10 03:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:55:07 --> Input Class Initialized
INFO - 2017-03-10 03:55:07 --> Language Class Initialized
INFO - 2017-03-10 03:55:07 --> Loader Class Initialized
INFO - 2017-03-10 03:55:07 --> Database Driver Class Initialized
INFO - 2017-03-10 03:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:55:07 --> Controller Class Initialized
INFO - 2017-03-10 03:55:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:55:09 --> Config Class Initialized
INFO - 2017-03-10 03:55:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:55:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:55:09 --> Utf8 Class Initialized
INFO - 2017-03-10 03:55:09 --> URI Class Initialized
INFO - 2017-03-10 03:55:09 --> Router Class Initialized
INFO - 2017-03-10 03:55:09 --> Output Class Initialized
INFO - 2017-03-10 03:55:09 --> Security Class Initialized
DEBUG - 2017-03-10 03:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:55:09 --> Input Class Initialized
INFO - 2017-03-10 03:55:09 --> Language Class Initialized
INFO - 2017-03-10 03:55:09 --> Loader Class Initialized
INFO - 2017-03-10 03:55:09 --> Database Driver Class Initialized
INFO - 2017-03-10 03:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:55:09 --> Controller Class Initialized
INFO - 2017-03-10 03:55:09 --> Helper loaded: date_helper
DEBUG - 2017-03-10 03:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:55:09 --> Helper loaded: url_helper
INFO - 2017-03-10 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:55:09 --> Final output sent to browser
DEBUG - 2017-03-10 03:55:09 --> Total execution time: 0.0394
INFO - 2017-03-10 03:55:12 --> Config Class Initialized
INFO - 2017-03-10 03:55:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:55:12 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:55:12 --> Utf8 Class Initialized
INFO - 2017-03-10 03:55:12 --> URI Class Initialized
INFO - 2017-03-10 03:55:12 --> Router Class Initialized
INFO - 2017-03-10 03:55:12 --> Output Class Initialized
INFO - 2017-03-10 03:55:12 --> Security Class Initialized
DEBUG - 2017-03-10 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:55:12 --> Input Class Initialized
INFO - 2017-03-10 03:55:12 --> Language Class Initialized
INFO - 2017-03-10 03:55:12 --> Loader Class Initialized
INFO - 2017-03-10 03:55:12 --> Database Driver Class Initialized
INFO - 2017-03-10 03:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:55:12 --> Controller Class Initialized
INFO - 2017-03-10 03:55:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:55:12 --> Final output sent to browser
DEBUG - 2017-03-10 03:55:12 --> Total execution time: 0.0141
INFO - 2017-03-10 03:55:17 --> Config Class Initialized
INFO - 2017-03-10 03:55:17 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:55:17 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:55:17 --> Utf8 Class Initialized
INFO - 2017-03-10 03:55:17 --> URI Class Initialized
INFO - 2017-03-10 03:55:17 --> Router Class Initialized
INFO - 2017-03-10 03:55:17 --> Output Class Initialized
INFO - 2017-03-10 03:55:17 --> Security Class Initialized
DEBUG - 2017-03-10 03:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:55:17 --> Input Class Initialized
INFO - 2017-03-10 03:55:17 --> Language Class Initialized
INFO - 2017-03-10 03:55:17 --> Loader Class Initialized
INFO - 2017-03-10 03:55:17 --> Database Driver Class Initialized
INFO - 2017-03-10 03:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:55:17 --> Controller Class Initialized
INFO - 2017-03-10 03:55:17 --> Helper loaded: date_helper
DEBUG - 2017-03-10 03:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:55:17 --> Helper loaded: url_helper
INFO - 2017-03-10 03:55:17 --> Helper loaded: download_helper
INFO - 2017-03-10 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:55:17 --> Final output sent to browser
DEBUG - 2017-03-10 03:55:17 --> Total execution time: 0.0513
INFO - 2017-03-10 03:55:26 --> Config Class Initialized
INFO - 2017-03-10 03:55:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:55:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:55:26 --> Utf8 Class Initialized
INFO - 2017-03-10 03:55:26 --> URI Class Initialized
INFO - 2017-03-10 03:55:26 --> Router Class Initialized
INFO - 2017-03-10 03:55:26 --> Output Class Initialized
INFO - 2017-03-10 03:55:26 --> Security Class Initialized
DEBUG - 2017-03-10 03:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:55:26 --> Input Class Initialized
INFO - 2017-03-10 03:55:26 --> Language Class Initialized
INFO - 2017-03-10 03:55:26 --> Loader Class Initialized
INFO - 2017-03-10 03:55:26 --> Database Driver Class Initialized
INFO - 2017-03-10 03:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:55:26 --> Controller Class Initialized
INFO - 2017-03-10 03:55:26 --> Helper loaded: date_helper
DEBUG - 2017-03-10 03:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:55:26 --> Helper loaded: url_helper
INFO - 2017-03-10 03:55:26 --> Helper loaded: download_helper
INFO - 2017-03-10 03:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 03:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 03:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 03:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:55:26 --> Final output sent to browser
DEBUG - 2017-03-10 03:55:26 --> Total execution time: 0.0191
INFO - 2017-03-10 03:55:28 --> Config Class Initialized
INFO - 2017-03-10 03:55:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:55:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:55:28 --> Utf8 Class Initialized
INFO - 2017-03-10 03:55:28 --> URI Class Initialized
INFO - 2017-03-10 03:55:28 --> Router Class Initialized
INFO - 2017-03-10 03:55:28 --> Output Class Initialized
INFO - 2017-03-10 03:55:28 --> Security Class Initialized
DEBUG - 2017-03-10 03:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:55:28 --> Input Class Initialized
INFO - 2017-03-10 03:55:28 --> Language Class Initialized
INFO - 2017-03-10 03:55:28 --> Loader Class Initialized
INFO - 2017-03-10 03:55:28 --> Database Driver Class Initialized
INFO - 2017-03-10 03:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:55:28 --> Controller Class Initialized
INFO - 2017-03-10 03:55:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:55:28 --> Final output sent to browser
DEBUG - 2017-03-10 03:55:28 --> Total execution time: 0.0145
INFO - 2017-03-10 03:59:34 --> Config Class Initialized
INFO - 2017-03-10 03:59:34 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:59:34 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:59:34 --> Utf8 Class Initialized
INFO - 2017-03-10 03:59:34 --> URI Class Initialized
INFO - 2017-03-10 03:59:34 --> Router Class Initialized
INFO - 2017-03-10 03:59:34 --> Output Class Initialized
INFO - 2017-03-10 03:59:34 --> Security Class Initialized
DEBUG - 2017-03-10 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:59:34 --> Input Class Initialized
INFO - 2017-03-10 03:59:34 --> Language Class Initialized
INFO - 2017-03-10 03:59:34 --> Loader Class Initialized
INFO - 2017-03-10 03:59:35 --> Database Driver Class Initialized
INFO - 2017-03-10 03:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:59:35 --> Controller Class Initialized
INFO - 2017-03-10 03:59:35 --> Helper loaded: date_helper
DEBUG - 2017-03-10 03:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:59:35 --> Helper loaded: url_helper
INFO - 2017-03-10 03:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-10 03:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 03:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-10 03:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-10 03:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:59:35 --> Final output sent to browser
DEBUG - 2017-03-10 03:59:35 --> Total execution time: 1.0943
INFO - 2017-03-10 03:59:36 --> Config Class Initialized
INFO - 2017-03-10 03:59:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:59:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:59:36 --> Utf8 Class Initialized
INFO - 2017-03-10 03:59:36 --> URI Class Initialized
INFO - 2017-03-10 03:59:36 --> Router Class Initialized
INFO - 2017-03-10 03:59:36 --> Output Class Initialized
INFO - 2017-03-10 03:59:36 --> Security Class Initialized
DEBUG - 2017-03-10 03:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:59:36 --> Input Class Initialized
INFO - 2017-03-10 03:59:36 --> Language Class Initialized
INFO - 2017-03-10 03:59:36 --> Loader Class Initialized
INFO - 2017-03-10 03:59:36 --> Database Driver Class Initialized
INFO - 2017-03-10 03:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:59:36 --> Controller Class Initialized
INFO - 2017-03-10 03:59:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:59:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:59:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:59:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:59:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:59:36 --> Final output sent to browser
DEBUG - 2017-03-10 03:59:36 --> Total execution time: 0.2720
INFO - 2017-03-10 03:59:37 --> Config Class Initialized
INFO - 2017-03-10 03:59:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:59:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:59:37 --> Utf8 Class Initialized
INFO - 2017-03-10 03:59:37 --> URI Class Initialized
INFO - 2017-03-10 03:59:37 --> Router Class Initialized
INFO - 2017-03-10 03:59:37 --> Output Class Initialized
INFO - 2017-03-10 03:59:37 --> Security Class Initialized
DEBUG - 2017-03-10 03:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:59:38 --> Input Class Initialized
INFO - 2017-03-10 03:59:38 --> Language Class Initialized
INFO - 2017-03-10 03:59:38 --> Loader Class Initialized
INFO - 2017-03-10 03:59:38 --> Database Driver Class Initialized
INFO - 2017-03-10 03:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:59:38 --> Controller Class Initialized
INFO - 2017-03-10 03:59:38 --> Helper loaded: date_helper
DEBUG - 2017-03-10 03:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:59:38 --> Helper loaded: url_helper
INFO - 2017-03-10 03:59:38 --> Helper loaded: download_helper
INFO - 2017-03-10 03:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 03:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 03:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 03:59:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:59:38 --> Final output sent to browser
DEBUG - 2017-03-10 03:59:38 --> Total execution time: 1.3664
INFO - 2017-03-10 03:59:40 --> Config Class Initialized
INFO - 2017-03-10 03:59:40 --> Hooks Class Initialized
DEBUG - 2017-03-10 03:59:40 --> UTF-8 Support Enabled
INFO - 2017-03-10 03:59:40 --> Utf8 Class Initialized
INFO - 2017-03-10 03:59:40 --> URI Class Initialized
INFO - 2017-03-10 03:59:40 --> Router Class Initialized
INFO - 2017-03-10 03:59:40 --> Output Class Initialized
INFO - 2017-03-10 03:59:40 --> Security Class Initialized
DEBUG - 2017-03-10 03:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 03:59:40 --> Input Class Initialized
INFO - 2017-03-10 03:59:40 --> Language Class Initialized
INFO - 2017-03-10 03:59:40 --> Loader Class Initialized
INFO - 2017-03-10 03:59:40 --> Database Driver Class Initialized
INFO - 2017-03-10 03:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 03:59:41 --> Controller Class Initialized
INFO - 2017-03-10 03:59:41 --> Helper loaded: url_helper
DEBUG - 2017-03-10 03:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 03:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 03:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 03:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 03:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 03:59:41 --> Final output sent to browser
DEBUG - 2017-03-10 03:59:41 --> Total execution time: 1.2107
INFO - 2017-03-10 06:59:33 --> Config Class Initialized
INFO - 2017-03-10 06:59:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 06:59:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 06:59:33 --> Utf8 Class Initialized
INFO - 2017-03-10 06:59:33 --> URI Class Initialized
INFO - 2017-03-10 06:59:34 --> Router Class Initialized
INFO - 2017-03-10 06:59:34 --> Output Class Initialized
INFO - 2017-03-10 06:59:34 --> Security Class Initialized
DEBUG - 2017-03-10 06:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 06:59:34 --> Input Class Initialized
INFO - 2017-03-10 06:59:34 --> Language Class Initialized
INFO - 2017-03-10 06:59:34 --> Loader Class Initialized
INFO - 2017-03-10 06:59:34 --> Database Driver Class Initialized
INFO - 2017-03-10 06:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 06:59:34 --> Controller Class Initialized
INFO - 2017-03-10 06:59:34 --> Helper loaded: date_helper
DEBUG - 2017-03-10 06:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 06:59:34 --> Helper loaded: url_helper
INFO - 2017-03-10 06:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 06:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 06:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 06:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 06:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 06:59:34 --> Final output sent to browser
DEBUG - 2017-03-10 06:59:34 --> Total execution time: 1.4382
INFO - 2017-03-10 06:59:42 --> Config Class Initialized
INFO - 2017-03-10 06:59:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 06:59:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 06:59:42 --> Utf8 Class Initialized
INFO - 2017-03-10 06:59:42 --> URI Class Initialized
INFO - 2017-03-10 06:59:42 --> Router Class Initialized
INFO - 2017-03-10 06:59:42 --> Output Class Initialized
INFO - 2017-03-10 06:59:42 --> Security Class Initialized
DEBUG - 2017-03-10 06:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 06:59:42 --> Input Class Initialized
INFO - 2017-03-10 06:59:42 --> Language Class Initialized
INFO - 2017-03-10 06:59:42 --> Loader Class Initialized
INFO - 2017-03-10 06:59:42 --> Database Driver Class Initialized
INFO - 2017-03-10 06:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 06:59:42 --> Controller Class Initialized
INFO - 2017-03-10 06:59:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 06:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 06:59:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 06:59:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 06:59:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 06:59:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 06:59:42 --> Final output sent to browser
DEBUG - 2017-03-10 06:59:42 --> Total execution time: 0.2626
INFO - 2017-03-10 06:59:47 --> Config Class Initialized
INFO - 2017-03-10 06:59:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 06:59:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 06:59:47 --> Utf8 Class Initialized
INFO - 2017-03-10 06:59:47 --> URI Class Initialized
INFO - 2017-03-10 06:59:47 --> Router Class Initialized
INFO - 2017-03-10 06:59:47 --> Output Class Initialized
INFO - 2017-03-10 06:59:47 --> Security Class Initialized
DEBUG - 2017-03-10 06:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 06:59:47 --> Input Class Initialized
INFO - 2017-03-10 06:59:47 --> Language Class Initialized
INFO - 2017-03-10 06:59:47 --> Loader Class Initialized
INFO - 2017-03-10 06:59:47 --> Database Driver Class Initialized
INFO - 2017-03-10 06:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 06:59:47 --> Controller Class Initialized
INFO - 2017-03-10 06:59:47 --> Helper loaded: date_helper
DEBUG - 2017-03-10 06:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 06:59:47 --> Helper loaded: url_helper
INFO - 2017-03-10 06:59:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 06:59:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 06:59:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 06:59:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 06:59:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 06:59:47 --> Final output sent to browser
DEBUG - 2017-03-10 06:59:47 --> Total execution time: 0.0145
INFO - 2017-03-10 06:59:55 --> Config Class Initialized
INFO - 2017-03-10 06:59:55 --> Hooks Class Initialized
DEBUG - 2017-03-10 06:59:55 --> UTF-8 Support Enabled
INFO - 2017-03-10 06:59:55 --> Utf8 Class Initialized
INFO - 2017-03-10 06:59:55 --> URI Class Initialized
INFO - 2017-03-10 06:59:55 --> Router Class Initialized
INFO - 2017-03-10 06:59:55 --> Output Class Initialized
INFO - 2017-03-10 06:59:55 --> Security Class Initialized
DEBUG - 2017-03-10 06:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 06:59:55 --> Input Class Initialized
INFO - 2017-03-10 06:59:55 --> Language Class Initialized
INFO - 2017-03-10 06:59:55 --> Loader Class Initialized
INFO - 2017-03-10 06:59:55 --> Database Driver Class Initialized
INFO - 2017-03-10 06:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 06:59:55 --> Controller Class Initialized
INFO - 2017-03-10 06:59:55 --> Helper loaded: url_helper
DEBUG - 2017-03-10 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 06:59:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 06:59:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 06:59:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 06:59:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 06:59:55 --> Final output sent to browser
DEBUG - 2017-03-10 06:59:55 --> Total execution time: 0.0133
INFO - 2017-03-10 13:06:00 --> Config Class Initialized
INFO - 2017-03-10 13:06:00 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:06:00 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:06:00 --> Utf8 Class Initialized
INFO - 2017-03-10 13:06:00 --> URI Class Initialized
DEBUG - 2017-03-10 13:06:01 --> No URI present. Default controller set.
INFO - 2017-03-10 13:06:01 --> Router Class Initialized
INFO - 2017-03-10 13:06:01 --> Output Class Initialized
INFO - 2017-03-10 13:06:01 --> Security Class Initialized
DEBUG - 2017-03-10 13:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:06:01 --> Input Class Initialized
INFO - 2017-03-10 13:06:01 --> Language Class Initialized
INFO - 2017-03-10 13:06:01 --> Loader Class Initialized
INFO - 2017-03-10 13:06:01 --> Database Driver Class Initialized
INFO - 2017-03-10 13:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:06:02 --> Controller Class Initialized
INFO - 2017-03-10 13:06:02 --> Helper loaded: url_helper
DEBUG - 2017-03-10 13:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 13:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 13:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:06:02 --> Final output sent to browser
DEBUG - 2017-03-10 13:06:02 --> Total execution time: 1.4938
INFO - 2017-03-10 13:06:05 --> Config Class Initialized
INFO - 2017-03-10 13:06:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:06:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:06:05 --> Utf8 Class Initialized
INFO - 2017-03-10 13:06:05 --> URI Class Initialized
INFO - 2017-03-10 13:06:05 --> Router Class Initialized
INFO - 2017-03-10 13:06:05 --> Output Class Initialized
INFO - 2017-03-10 13:06:05 --> Security Class Initialized
DEBUG - 2017-03-10 13:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:06:05 --> Input Class Initialized
INFO - 2017-03-10 13:06:05 --> Language Class Initialized
INFO - 2017-03-10 13:06:05 --> Loader Class Initialized
INFO - 2017-03-10 13:06:05 --> Database Driver Class Initialized
INFO - 2017-03-10 13:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:06:05 --> Controller Class Initialized
INFO - 2017-03-10 13:06:05 --> Helper loaded: url_helper
DEBUG - 2017-03-10 13:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 13:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 13:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:06:05 --> Final output sent to browser
DEBUG - 2017-03-10 13:06:05 --> Total execution time: 0.0133
INFO - 2017-03-10 13:06:09 --> Config Class Initialized
INFO - 2017-03-10 13:06:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:06:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:06:09 --> Utf8 Class Initialized
INFO - 2017-03-10 13:06:09 --> URI Class Initialized
INFO - 2017-03-10 13:06:09 --> Router Class Initialized
INFO - 2017-03-10 13:06:09 --> Output Class Initialized
INFO - 2017-03-10 13:06:09 --> Security Class Initialized
DEBUG - 2017-03-10 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:06:09 --> Input Class Initialized
INFO - 2017-03-10 13:06:09 --> Language Class Initialized
INFO - 2017-03-10 13:06:09 --> Loader Class Initialized
INFO - 2017-03-10 13:06:09 --> Database Driver Class Initialized
INFO - 2017-03-10 13:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:06:09 --> Controller Class Initialized
INFO - 2017-03-10 13:06:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 13:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:06:11 --> Config Class Initialized
INFO - 2017-03-10 13:06:11 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:06:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:06:11 --> Utf8 Class Initialized
INFO - 2017-03-10 13:06:11 --> URI Class Initialized
INFO - 2017-03-10 13:06:11 --> Router Class Initialized
INFO - 2017-03-10 13:06:11 --> Output Class Initialized
INFO - 2017-03-10 13:06:11 --> Security Class Initialized
DEBUG - 2017-03-10 13:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:06:11 --> Input Class Initialized
INFO - 2017-03-10 13:06:11 --> Language Class Initialized
INFO - 2017-03-10 13:06:11 --> Loader Class Initialized
INFO - 2017-03-10 13:06:11 --> Database Driver Class Initialized
INFO - 2017-03-10 13:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:06:11 --> Controller Class Initialized
INFO - 2017-03-10 13:06:11 --> Helper loaded: date_helper
DEBUG - 2017-03-10 13:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:06:11 --> Helper loaded: url_helper
INFO - 2017-03-10 13:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 13:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 13:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 13:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:06:11 --> Final output sent to browser
DEBUG - 2017-03-10 13:06:11 --> Total execution time: 0.1511
INFO - 2017-03-10 13:06:13 --> Config Class Initialized
INFO - 2017-03-10 13:06:13 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:06:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:06:13 --> Utf8 Class Initialized
INFO - 2017-03-10 13:06:13 --> URI Class Initialized
INFO - 2017-03-10 13:06:13 --> Router Class Initialized
INFO - 2017-03-10 13:06:13 --> Output Class Initialized
INFO - 2017-03-10 13:06:13 --> Security Class Initialized
DEBUG - 2017-03-10 13:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:06:13 --> Input Class Initialized
INFO - 2017-03-10 13:06:13 --> Language Class Initialized
INFO - 2017-03-10 13:06:13 --> Loader Class Initialized
INFO - 2017-03-10 13:06:13 --> Database Driver Class Initialized
INFO - 2017-03-10 13:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:06:13 --> Controller Class Initialized
INFO - 2017-03-10 13:06:13 --> Helper loaded: url_helper
DEBUG - 2017-03-10 13:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:06:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:06:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 13:06:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 13:06:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:06:13 --> Final output sent to browser
DEBUG - 2017-03-10 13:06:13 --> Total execution time: 0.0139
INFO - 2017-03-10 13:07:21 --> Config Class Initialized
INFO - 2017-03-10 13:07:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:07:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:07:21 --> Utf8 Class Initialized
INFO - 2017-03-10 13:07:21 --> URI Class Initialized
INFO - 2017-03-10 13:07:21 --> Router Class Initialized
INFO - 2017-03-10 13:07:21 --> Output Class Initialized
INFO - 2017-03-10 13:07:21 --> Security Class Initialized
DEBUG - 2017-03-10 13:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:07:22 --> Input Class Initialized
INFO - 2017-03-10 13:07:22 --> Language Class Initialized
INFO - 2017-03-10 13:07:22 --> Loader Class Initialized
INFO - 2017-03-10 13:07:22 --> Database Driver Class Initialized
INFO - 2017-03-10 13:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:07:22 --> Controller Class Initialized
INFO - 2017-03-10 13:07:22 --> Helper loaded: date_helper
DEBUG - 2017-03-10 13:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:07:22 --> Helper loaded: url_helper
INFO - 2017-03-10 13:07:22 --> Helper loaded: download_helper
INFO - 2017-03-10 13:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 13:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 13:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 13:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:07:22 --> Final output sent to browser
DEBUG - 2017-03-10 13:07:22 --> Total execution time: 1.1129
INFO - 2017-03-10 13:07:24 --> Config Class Initialized
INFO - 2017-03-10 13:07:24 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:07:24 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:07:24 --> Utf8 Class Initialized
INFO - 2017-03-10 13:07:24 --> URI Class Initialized
INFO - 2017-03-10 13:07:24 --> Router Class Initialized
INFO - 2017-03-10 13:07:24 --> Output Class Initialized
INFO - 2017-03-10 13:07:24 --> Security Class Initialized
DEBUG - 2017-03-10 13:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:07:24 --> Input Class Initialized
INFO - 2017-03-10 13:07:24 --> Language Class Initialized
INFO - 2017-03-10 13:07:24 --> Loader Class Initialized
INFO - 2017-03-10 13:07:24 --> Database Driver Class Initialized
INFO - 2017-03-10 13:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:07:24 --> Controller Class Initialized
INFO - 2017-03-10 13:07:24 --> Helper loaded: url_helper
DEBUG - 2017-03-10 13:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 13:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 13:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:07:24 --> Final output sent to browser
DEBUG - 2017-03-10 13:07:24 --> Total execution time: 0.2506
INFO - 2017-03-10 13:08:04 --> Config Class Initialized
INFO - 2017-03-10 13:08:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:08:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:08:05 --> Utf8 Class Initialized
INFO - 2017-03-10 13:08:05 --> URI Class Initialized
DEBUG - 2017-03-10 13:08:05 --> No URI present. Default controller set.
INFO - 2017-03-10 13:08:05 --> Router Class Initialized
INFO - 2017-03-10 13:08:05 --> Output Class Initialized
INFO - 2017-03-10 13:08:05 --> Security Class Initialized
DEBUG - 2017-03-10 13:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:08:05 --> Input Class Initialized
INFO - 2017-03-10 13:08:05 --> Language Class Initialized
INFO - 2017-03-10 13:08:05 --> Loader Class Initialized
INFO - 2017-03-10 13:08:05 --> Database Driver Class Initialized
INFO - 2017-03-10 13:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:08:05 --> Controller Class Initialized
INFO - 2017-03-10 13:08:05 --> Helper loaded: url_helper
DEBUG - 2017-03-10 13:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 13:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 13:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:08:06 --> Final output sent to browser
DEBUG - 2017-03-10 13:08:06 --> Total execution time: 1.2008
INFO - 2017-03-10 13:08:07 --> Config Class Initialized
INFO - 2017-03-10 13:08:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 13:08:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 13:08:07 --> Utf8 Class Initialized
INFO - 2017-03-10 13:08:07 --> URI Class Initialized
INFO - 2017-03-10 13:08:07 --> Router Class Initialized
INFO - 2017-03-10 13:08:07 --> Output Class Initialized
INFO - 2017-03-10 13:08:07 --> Security Class Initialized
DEBUG - 2017-03-10 13:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 13:08:07 --> Input Class Initialized
INFO - 2017-03-10 13:08:07 --> Language Class Initialized
INFO - 2017-03-10 13:08:07 --> Loader Class Initialized
INFO - 2017-03-10 13:08:07 --> Database Driver Class Initialized
INFO - 2017-03-10 13:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 13:08:07 --> Controller Class Initialized
INFO - 2017-03-10 13:08:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 13:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 13:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 13:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 13:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 13:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 13:08:07 --> Final output sent to browser
DEBUG - 2017-03-10 13:08:07 --> Total execution time: 0.0143
INFO - 2017-03-10 17:08:23 --> Config Class Initialized
INFO - 2017-03-10 17:08:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 17:08:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 17:08:23 --> Utf8 Class Initialized
INFO - 2017-03-10 17:08:23 --> URI Class Initialized
DEBUG - 2017-03-10 17:08:23 --> No URI present. Default controller set.
INFO - 2017-03-10 17:08:23 --> Router Class Initialized
INFO - 2017-03-10 17:08:23 --> Output Class Initialized
INFO - 2017-03-10 17:08:23 --> Security Class Initialized
DEBUG - 2017-03-10 17:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 17:08:23 --> Input Class Initialized
INFO - 2017-03-10 17:08:23 --> Language Class Initialized
INFO - 2017-03-10 17:08:23 --> Loader Class Initialized
INFO - 2017-03-10 17:08:24 --> Database Driver Class Initialized
INFO - 2017-03-10 17:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 17:08:24 --> Controller Class Initialized
INFO - 2017-03-10 17:08:24 --> Helper loaded: url_helper
DEBUG - 2017-03-10 17:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 17:08:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 17:08:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 17:08:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 17:08:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 17:08:25 --> Final output sent to browser
DEBUG - 2017-03-10 17:08:25 --> Total execution time: 2.0656
INFO - 2017-03-10 17:08:55 --> Config Class Initialized
INFO - 2017-03-10 17:08:55 --> Hooks Class Initialized
DEBUG - 2017-03-10 17:08:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 17:08:56 --> Utf8 Class Initialized
INFO - 2017-03-10 17:08:56 --> URI Class Initialized
INFO - 2017-03-10 17:08:56 --> Router Class Initialized
INFO - 2017-03-10 17:08:56 --> Output Class Initialized
INFO - 2017-03-10 17:08:56 --> Security Class Initialized
DEBUG - 2017-03-10 17:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 17:08:56 --> Input Class Initialized
INFO - 2017-03-10 17:08:56 --> Language Class Initialized
INFO - 2017-03-10 17:08:56 --> Loader Class Initialized
INFO - 2017-03-10 17:08:57 --> Database Driver Class Initialized
INFO - 2017-03-10 17:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 17:08:57 --> Controller Class Initialized
INFO - 2017-03-10 17:08:57 --> Helper loaded: url_helper
DEBUG - 2017-03-10 17:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 17:09:05 --> Config Class Initialized
INFO - 2017-03-10 17:09:05 --> Hooks Class Initialized
DEBUG - 2017-03-10 17:09:05 --> UTF-8 Support Enabled
INFO - 2017-03-10 17:09:05 --> Utf8 Class Initialized
INFO - 2017-03-10 17:09:05 --> URI Class Initialized
INFO - 2017-03-10 17:09:05 --> Router Class Initialized
INFO - 2017-03-10 17:09:05 --> Output Class Initialized
INFO - 2017-03-10 17:09:05 --> Security Class Initialized
DEBUG - 2017-03-10 17:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 17:09:06 --> Input Class Initialized
INFO - 2017-03-10 17:09:06 --> Language Class Initialized
INFO - 2017-03-10 17:09:06 --> Loader Class Initialized
INFO - 2017-03-10 17:09:06 --> Database Driver Class Initialized
INFO - 2017-03-10 17:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 17:09:06 --> Controller Class Initialized
INFO - 2017-03-10 17:09:06 --> Helper loaded: date_helper
DEBUG - 2017-03-10 17:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 17:09:06 --> Helper loaded: url_helper
INFO - 2017-03-10 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 17:09:06 --> Final output sent to browser
DEBUG - 2017-03-10 17:09:06 --> Total execution time: 1.3593
INFO - 2017-03-10 17:09:14 --> Config Class Initialized
INFO - 2017-03-10 17:09:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 17:09:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 17:09:15 --> Utf8 Class Initialized
INFO - 2017-03-10 17:09:15 --> URI Class Initialized
INFO - 2017-03-10 17:09:15 --> Router Class Initialized
INFO - 2017-03-10 17:09:15 --> Output Class Initialized
INFO - 2017-03-10 17:09:15 --> Security Class Initialized
DEBUG - 2017-03-10 17:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 17:09:15 --> Input Class Initialized
INFO - 2017-03-10 17:09:15 --> Language Class Initialized
INFO - 2017-03-10 17:09:15 --> Loader Class Initialized
INFO - 2017-03-10 17:09:15 --> Database Driver Class Initialized
INFO - 2017-03-10 17:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 17:09:15 --> Controller Class Initialized
INFO - 2017-03-10 17:09:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 17:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 17:09:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 17:09:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 17:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 17:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 17:09:16 --> Final output sent to browser
DEBUG - 2017-03-10 17:09:16 --> Total execution time: 1.4461
INFO - 2017-03-10 18:42:25 --> Config Class Initialized
INFO - 2017-03-10 18:42:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:42:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:42:25 --> Utf8 Class Initialized
INFO - 2017-03-10 18:42:25 --> URI Class Initialized
DEBUG - 2017-03-10 18:42:25 --> No URI present. Default controller set.
INFO - 2017-03-10 18:42:25 --> Router Class Initialized
INFO - 2017-03-10 18:42:25 --> Output Class Initialized
INFO - 2017-03-10 18:42:25 --> Security Class Initialized
DEBUG - 2017-03-10 18:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:42:25 --> Input Class Initialized
INFO - 2017-03-10 18:42:25 --> Language Class Initialized
INFO - 2017-03-10 18:42:25 --> Loader Class Initialized
INFO - 2017-03-10 18:42:26 --> Database Driver Class Initialized
INFO - 2017-03-10 18:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:42:26 --> Controller Class Initialized
INFO - 2017-03-10 18:42:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:42:27 --> Final output sent to browser
DEBUG - 2017-03-10 18:42:27 --> Total execution time: 1.7606
INFO - 2017-03-10 18:42:29 --> Config Class Initialized
INFO - 2017-03-10 18:42:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:42:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:42:29 --> Utf8 Class Initialized
INFO - 2017-03-10 18:42:29 --> URI Class Initialized
DEBUG - 2017-03-10 18:42:29 --> No URI present. Default controller set.
INFO - 2017-03-10 18:42:29 --> Router Class Initialized
INFO - 2017-03-10 18:42:29 --> Output Class Initialized
INFO - 2017-03-10 18:42:29 --> Security Class Initialized
DEBUG - 2017-03-10 18:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:42:29 --> Input Class Initialized
INFO - 2017-03-10 18:42:29 --> Language Class Initialized
INFO - 2017-03-10 18:42:29 --> Loader Class Initialized
INFO - 2017-03-10 18:42:29 --> Database Driver Class Initialized
INFO - 2017-03-10 18:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:42:29 --> Controller Class Initialized
INFO - 2017-03-10 18:42:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:42:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:42:29 --> Final output sent to browser
DEBUG - 2017-03-10 18:42:29 --> Total execution time: 0.0148
INFO - 2017-03-10 18:42:59 --> Config Class Initialized
INFO - 2017-03-10 18:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:42:59 --> Utf8 Class Initialized
INFO - 2017-03-10 18:42:59 --> URI Class Initialized
INFO - 2017-03-10 18:43:00 --> Router Class Initialized
INFO - 2017-03-10 18:43:00 --> Output Class Initialized
INFO - 2017-03-10 18:43:00 --> Security Class Initialized
DEBUG - 2017-03-10 18:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:43:00 --> Input Class Initialized
INFO - 2017-03-10 18:43:00 --> Language Class Initialized
INFO - 2017-03-10 18:43:00 --> Loader Class Initialized
INFO - 2017-03-10 18:43:00 --> Database Driver Class Initialized
INFO - 2017-03-10 18:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:43:01 --> Controller Class Initialized
INFO - 2017-03-10 18:43:01 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-10 18:43:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-10 18:43:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-10 18:43:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-10 18:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:43:01 --> Final output sent to browser
DEBUG - 2017-03-10 18:43:01 --> Total execution time: 2.2702
INFO - 2017-03-10 18:43:09 --> Config Class Initialized
INFO - 2017-03-10 18:43:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:43:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:43:09 --> Utf8 Class Initialized
INFO - 2017-03-10 18:43:09 --> URI Class Initialized
INFO - 2017-03-10 18:43:09 --> Router Class Initialized
INFO - 2017-03-10 18:43:09 --> Output Class Initialized
INFO - 2017-03-10 18:43:09 --> Security Class Initialized
DEBUG - 2017-03-10 18:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:43:09 --> Input Class Initialized
INFO - 2017-03-10 18:43:09 --> Language Class Initialized
INFO - 2017-03-10 18:43:09 --> Loader Class Initialized
INFO - 2017-03-10 18:43:09 --> Database Driver Class Initialized
INFO - 2017-03-10 18:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:43:09 --> Controller Class Initialized
INFO - 2017-03-10 18:43:09 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:43:10 --> Final output sent to browser
DEBUG - 2017-03-10 18:43:10 --> Total execution time: 1.2431
INFO - 2017-03-10 18:44:41 --> Config Class Initialized
INFO - 2017-03-10 18:44:41 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:44:41 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:44:41 --> Utf8 Class Initialized
INFO - 2017-03-10 18:44:41 --> URI Class Initialized
INFO - 2017-03-10 18:44:42 --> Router Class Initialized
INFO - 2017-03-10 18:44:42 --> Output Class Initialized
INFO - 2017-03-10 18:44:42 --> Security Class Initialized
DEBUG - 2017-03-10 18:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:44:42 --> Input Class Initialized
INFO - 2017-03-10 18:44:42 --> Language Class Initialized
INFO - 2017-03-10 18:44:42 --> Loader Class Initialized
INFO - 2017-03-10 18:44:42 --> Database Driver Class Initialized
INFO - 2017-03-10 18:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:44:42 --> Controller Class Initialized
INFO - 2017-03-10 18:44:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:44:43 --> Final output sent to browser
DEBUG - 2017-03-10 18:44:43 --> Total execution time: 1.5876
INFO - 2017-03-10 18:45:21 --> Config Class Initialized
INFO - 2017-03-10 18:45:21 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:21 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:21 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:21 --> URI Class Initialized
INFO - 2017-03-10 18:45:21 --> Router Class Initialized
INFO - 2017-03-10 18:45:21 --> Output Class Initialized
INFO - 2017-03-10 18:45:21 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:21 --> Input Class Initialized
INFO - 2017-03-10 18:45:21 --> Language Class Initialized
INFO - 2017-03-10 18:45:21 --> Loader Class Initialized
INFO - 2017-03-10 18:45:22 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:22 --> Controller Class Initialized
INFO - 2017-03-10 18:45:22 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:27 --> Config Class Initialized
INFO - 2017-03-10 18:45:27 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:27 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:27 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:27 --> URI Class Initialized
INFO - 2017-03-10 18:45:27 --> Router Class Initialized
INFO - 2017-03-10 18:45:27 --> Output Class Initialized
INFO - 2017-03-10 18:45:27 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:28 --> Input Class Initialized
INFO - 2017-03-10 18:45:28 --> Language Class Initialized
INFO - 2017-03-10 18:45:28 --> Loader Class Initialized
INFO - 2017-03-10 18:45:28 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:28 --> Controller Class Initialized
INFO - 2017-03-10 18:45:28 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:28 --> Helper loaded: url_helper
INFO - 2017-03-10 18:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 18:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 18:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:45:28 --> Final output sent to browser
DEBUG - 2017-03-10 18:45:28 --> Total execution time: 1.4178
INFO - 2017-03-10 18:45:32 --> Config Class Initialized
INFO - 2017-03-10 18:45:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:32 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:32 --> URI Class Initialized
INFO - 2017-03-10 18:45:32 --> Router Class Initialized
INFO - 2017-03-10 18:45:32 --> Output Class Initialized
INFO - 2017-03-10 18:45:32 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:32 --> Input Class Initialized
INFO - 2017-03-10 18:45:32 --> Language Class Initialized
INFO - 2017-03-10 18:45:32 --> Loader Class Initialized
INFO - 2017-03-10 18:45:32 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:32 --> Controller Class Initialized
INFO - 2017-03-10 18:45:32 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:33 --> Config Class Initialized
INFO - 2017-03-10 18:45:33 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:33 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:33 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:33 --> URI Class Initialized
INFO - 2017-03-10 18:45:33 --> Router Class Initialized
INFO - 2017-03-10 18:45:33 --> Output Class Initialized
INFO - 2017-03-10 18:45:33 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:33 --> Input Class Initialized
INFO - 2017-03-10 18:45:33 --> Language Class Initialized
INFO - 2017-03-10 18:45:33 --> Loader Class Initialized
INFO - 2017-03-10 18:45:33 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:33 --> Controller Class Initialized
INFO - 2017-03-10 18:45:33 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:33 --> Helper loaded: url_helper
INFO - 2017-03-10 18:45:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:45:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 18:45:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 18:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:45:34 --> Final output sent to browser
DEBUG - 2017-03-10 18:45:34 --> Total execution time: 0.0583
INFO - 2017-03-10 18:45:35 --> Config Class Initialized
INFO - 2017-03-10 18:45:35 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:35 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:35 --> URI Class Initialized
INFO - 2017-03-10 18:45:35 --> Router Class Initialized
INFO - 2017-03-10 18:45:35 --> Output Class Initialized
INFO - 2017-03-10 18:45:35 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:35 --> Input Class Initialized
INFO - 2017-03-10 18:45:35 --> Language Class Initialized
INFO - 2017-03-10 18:45:35 --> Loader Class Initialized
INFO - 2017-03-10 18:45:35 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:35 --> Controller Class Initialized
INFO - 2017-03-10 18:45:35 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:45:35 --> Final output sent to browser
DEBUG - 2017-03-10 18:45:35 --> Total execution time: 0.0506
INFO - 2017-03-10 18:45:38 --> Config Class Initialized
INFO - 2017-03-10 18:45:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:38 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:38 --> URI Class Initialized
INFO - 2017-03-10 18:45:38 --> Router Class Initialized
INFO - 2017-03-10 18:45:38 --> Output Class Initialized
INFO - 2017-03-10 18:45:38 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:38 --> Input Class Initialized
INFO - 2017-03-10 18:45:38 --> Language Class Initialized
INFO - 2017-03-10 18:45:38 --> Loader Class Initialized
INFO - 2017-03-10 18:45:38 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:38 --> Controller Class Initialized
INFO - 2017-03-10 18:45:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:45:38 --> Final output sent to browser
DEBUG - 2017-03-10 18:45:38 --> Total execution time: 0.2742
INFO - 2017-03-10 18:45:46 --> Config Class Initialized
INFO - 2017-03-10 18:45:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:46 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:46 --> URI Class Initialized
DEBUG - 2017-03-10 18:45:46 --> No URI present. Default controller set.
INFO - 2017-03-10 18:45:46 --> Router Class Initialized
INFO - 2017-03-10 18:45:46 --> Output Class Initialized
INFO - 2017-03-10 18:45:46 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:46 --> Input Class Initialized
INFO - 2017-03-10 18:45:46 --> Language Class Initialized
INFO - 2017-03-10 18:45:46 --> Loader Class Initialized
INFO - 2017-03-10 18:45:46 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:46 --> Controller Class Initialized
INFO - 2017-03-10 18:45:46 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:45:46 --> Final output sent to browser
DEBUG - 2017-03-10 18:45:46 --> Total execution time: 0.0387
INFO - 2017-03-10 18:45:54 --> Config Class Initialized
INFO - 2017-03-10 18:45:54 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:45:54 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:45:54 --> Utf8 Class Initialized
INFO - 2017-03-10 18:45:54 --> URI Class Initialized
INFO - 2017-03-10 18:45:54 --> Router Class Initialized
INFO - 2017-03-10 18:45:54 --> Output Class Initialized
INFO - 2017-03-10 18:45:54 --> Security Class Initialized
DEBUG - 2017-03-10 18:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:45:55 --> Input Class Initialized
INFO - 2017-03-10 18:45:55 --> Language Class Initialized
INFO - 2017-03-10 18:45:55 --> Loader Class Initialized
INFO - 2017-03-10 18:45:55 --> Database Driver Class Initialized
INFO - 2017-03-10 18:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:45:55 --> Controller Class Initialized
INFO - 2017-03-10 18:45:55 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:45:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:45:56 --> Final output sent to browser
DEBUG - 2017-03-10 18:45:56 --> Total execution time: 1.5967
INFO - 2017-03-10 18:46:08 --> Config Class Initialized
INFO - 2017-03-10 18:46:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:46:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:46:08 --> Utf8 Class Initialized
INFO - 2017-03-10 18:46:08 --> URI Class Initialized
INFO - 2017-03-10 18:46:08 --> Router Class Initialized
INFO - 2017-03-10 18:46:08 --> Output Class Initialized
INFO - 2017-03-10 18:46:08 --> Security Class Initialized
DEBUG - 2017-03-10 18:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:46:08 --> Input Class Initialized
INFO - 2017-03-10 18:46:08 --> Language Class Initialized
INFO - 2017-03-10 18:46:08 --> Loader Class Initialized
INFO - 2017-03-10 18:46:08 --> Database Driver Class Initialized
INFO - 2017-03-10 18:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:46:08 --> Controller Class Initialized
INFO - 2017-03-10 18:46:08 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-10 18:46:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-10 18:46:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-10 18:46:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-10 18:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:46:08 --> Final output sent to browser
DEBUG - 2017-03-10 18:46:08 --> Total execution time: 0.1316
INFO - 2017-03-10 18:46:10 --> Config Class Initialized
INFO - 2017-03-10 18:46:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:46:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:46:10 --> Utf8 Class Initialized
INFO - 2017-03-10 18:46:10 --> URI Class Initialized
INFO - 2017-03-10 18:46:10 --> Router Class Initialized
INFO - 2017-03-10 18:46:10 --> Output Class Initialized
INFO - 2017-03-10 18:46:10 --> Security Class Initialized
DEBUG - 2017-03-10 18:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:46:10 --> Input Class Initialized
INFO - 2017-03-10 18:46:10 --> Language Class Initialized
INFO - 2017-03-10 18:46:10 --> Loader Class Initialized
INFO - 2017-03-10 18:46:10 --> Database Driver Class Initialized
INFO - 2017-03-10 18:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:46:10 --> Controller Class Initialized
INFO - 2017-03-10 18:46:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:46:10 --> Final output sent to browser
DEBUG - 2017-03-10 18:46:10 --> Total execution time: 0.0143
INFO - 2017-03-10 18:46:36 --> Config Class Initialized
INFO - 2017-03-10 18:46:36 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:46:36 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:46:36 --> Utf8 Class Initialized
INFO - 2017-03-10 18:46:36 --> URI Class Initialized
DEBUG - 2017-03-10 18:46:36 --> No URI present. Default controller set.
INFO - 2017-03-10 18:46:36 --> Router Class Initialized
INFO - 2017-03-10 18:46:36 --> Output Class Initialized
INFO - 2017-03-10 18:46:36 --> Security Class Initialized
DEBUG - 2017-03-10 18:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:46:36 --> Input Class Initialized
INFO - 2017-03-10 18:46:36 --> Language Class Initialized
INFO - 2017-03-10 18:46:36 --> Loader Class Initialized
INFO - 2017-03-10 18:46:36 --> Database Driver Class Initialized
INFO - 2017-03-10 18:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:46:36 --> Controller Class Initialized
INFO - 2017-03-10 18:46:36 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:46:36 --> Final output sent to browser
DEBUG - 2017-03-10 18:46:36 --> Total execution time: 0.0154
INFO - 2017-03-10 18:46:47 --> Config Class Initialized
INFO - 2017-03-10 18:46:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:46:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:46:47 --> Utf8 Class Initialized
INFO - 2017-03-10 18:46:47 --> URI Class Initialized
INFO - 2017-03-10 18:46:47 --> Router Class Initialized
INFO - 2017-03-10 18:46:47 --> Output Class Initialized
INFO - 2017-03-10 18:46:47 --> Security Class Initialized
DEBUG - 2017-03-10 18:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:46:47 --> Input Class Initialized
INFO - 2017-03-10 18:46:47 --> Language Class Initialized
INFO - 2017-03-10 18:46:47 --> Loader Class Initialized
INFO - 2017-03-10 18:46:47 --> Database Driver Class Initialized
INFO - 2017-03-10 18:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:46:47 --> Controller Class Initialized
INFO - 2017-03-10 18:46:47 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:46:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:46:49 --> Config Class Initialized
INFO - 2017-03-10 18:46:49 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:46:49 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:46:49 --> Utf8 Class Initialized
INFO - 2017-03-10 18:46:49 --> URI Class Initialized
INFO - 2017-03-10 18:46:49 --> Router Class Initialized
INFO - 2017-03-10 18:46:49 --> Output Class Initialized
INFO - 2017-03-10 18:46:49 --> Security Class Initialized
DEBUG - 2017-03-10 18:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:46:49 --> Input Class Initialized
INFO - 2017-03-10 18:46:49 --> Language Class Initialized
INFO - 2017-03-10 18:46:49 --> Loader Class Initialized
INFO - 2017-03-10 18:46:49 --> Database Driver Class Initialized
INFO - 2017-03-10 18:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:46:49 --> Controller Class Initialized
INFO - 2017-03-10 18:46:49 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:46:49 --> Helper loaded: url_helper
INFO - 2017-03-10 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:46:49 --> Final output sent to browser
DEBUG - 2017-03-10 18:46:49 --> Total execution time: 0.1263
INFO - 2017-03-10 18:46:56 --> Config Class Initialized
INFO - 2017-03-10 18:46:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:46:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:46:56 --> Utf8 Class Initialized
INFO - 2017-03-10 18:46:56 --> URI Class Initialized
INFO - 2017-03-10 18:46:56 --> Router Class Initialized
INFO - 2017-03-10 18:46:56 --> Output Class Initialized
INFO - 2017-03-10 18:46:56 --> Security Class Initialized
DEBUG - 2017-03-10 18:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:46:56 --> Input Class Initialized
INFO - 2017-03-10 18:46:56 --> Language Class Initialized
INFO - 2017-03-10 18:46:56 --> Loader Class Initialized
INFO - 2017-03-10 18:46:56 --> Database Driver Class Initialized
INFO - 2017-03-10 18:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:46:56 --> Controller Class Initialized
INFO - 2017-03-10 18:46:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:46:56 --> Final output sent to browser
DEBUG - 2017-03-10 18:46:56 --> Total execution time: 0.0145
INFO - 2017-03-10 18:48:03 --> Config Class Initialized
INFO - 2017-03-10 18:48:03 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:48:03 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:48:03 --> Utf8 Class Initialized
INFO - 2017-03-10 18:48:03 --> URI Class Initialized
INFO - 2017-03-10 18:48:03 --> Router Class Initialized
INFO - 2017-03-10 18:48:03 --> Output Class Initialized
INFO - 2017-03-10 18:48:03 --> Security Class Initialized
DEBUG - 2017-03-10 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:48:03 --> Input Class Initialized
INFO - 2017-03-10 18:48:03 --> Language Class Initialized
INFO - 2017-03-10 18:48:03 --> Loader Class Initialized
INFO - 2017-03-10 18:48:03 --> Database Driver Class Initialized
INFO - 2017-03-10 18:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:48:03 --> Controller Class Initialized
INFO - 2017-03-10 18:48:03 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:48:04 --> Config Class Initialized
INFO - 2017-03-10 18:48:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:48:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:48:04 --> Utf8 Class Initialized
INFO - 2017-03-10 18:48:04 --> URI Class Initialized
INFO - 2017-03-10 18:48:04 --> Router Class Initialized
INFO - 2017-03-10 18:48:04 --> Output Class Initialized
INFO - 2017-03-10 18:48:04 --> Security Class Initialized
DEBUG - 2017-03-10 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:48:04 --> Input Class Initialized
INFO - 2017-03-10 18:48:04 --> Language Class Initialized
INFO - 2017-03-10 18:48:04 --> Loader Class Initialized
INFO - 2017-03-10 18:48:04 --> Database Driver Class Initialized
INFO - 2017-03-10 18:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:48:04 --> Controller Class Initialized
INFO - 2017-03-10 18:48:04 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:48:04 --> Helper loaded: url_helper
INFO - 2017-03-10 18:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 18:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 18:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:48:04 --> Final output sent to browser
DEBUG - 2017-03-10 18:48:04 --> Total execution time: 0.0300
INFO - 2017-03-10 18:48:06 --> Config Class Initialized
INFO - 2017-03-10 18:48:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:48:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:48:06 --> Utf8 Class Initialized
INFO - 2017-03-10 18:48:06 --> URI Class Initialized
INFO - 2017-03-10 18:48:06 --> Router Class Initialized
INFO - 2017-03-10 18:48:06 --> Output Class Initialized
INFO - 2017-03-10 18:48:06 --> Security Class Initialized
DEBUG - 2017-03-10 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:48:06 --> Input Class Initialized
INFO - 2017-03-10 18:48:06 --> Language Class Initialized
INFO - 2017-03-10 18:48:06 --> Loader Class Initialized
INFO - 2017-03-10 18:48:06 --> Database Driver Class Initialized
INFO - 2017-03-10 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:48:06 --> Controller Class Initialized
INFO - 2017-03-10 18:48:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:48:06 --> Final output sent to browser
DEBUG - 2017-03-10 18:48:06 --> Total execution time: 0.0151
INFO - 2017-03-10 18:48:06 --> Config Class Initialized
INFO - 2017-03-10 18:48:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:48:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:48:06 --> Utf8 Class Initialized
INFO - 2017-03-10 18:48:06 --> URI Class Initialized
DEBUG - 2017-03-10 18:48:06 --> No URI present. Default controller set.
INFO - 2017-03-10 18:48:06 --> Router Class Initialized
INFO - 2017-03-10 18:48:06 --> Output Class Initialized
INFO - 2017-03-10 18:48:06 --> Security Class Initialized
DEBUG - 2017-03-10 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:48:06 --> Input Class Initialized
INFO - 2017-03-10 18:48:06 --> Language Class Initialized
INFO - 2017-03-10 18:48:06 --> Loader Class Initialized
INFO - 2017-03-10 18:48:06 --> Database Driver Class Initialized
INFO - 2017-03-10 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:48:06 --> Controller Class Initialized
INFO - 2017-03-10 18:48:06 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:48:06 --> Final output sent to browser
DEBUG - 2017-03-10 18:48:06 --> Total execution time: 0.0147
INFO - 2017-03-10 18:48:08 --> Config Class Initialized
INFO - 2017-03-10 18:48:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:48:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:48:08 --> Utf8 Class Initialized
INFO - 2017-03-10 18:48:08 --> URI Class Initialized
INFO - 2017-03-10 18:48:08 --> Router Class Initialized
INFO - 2017-03-10 18:48:08 --> Output Class Initialized
INFO - 2017-03-10 18:48:08 --> Security Class Initialized
DEBUG - 2017-03-10 18:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:48:08 --> Input Class Initialized
INFO - 2017-03-10 18:48:08 --> Language Class Initialized
INFO - 2017-03-10 18:48:08 --> Loader Class Initialized
INFO - 2017-03-10 18:48:08 --> Database Driver Class Initialized
INFO - 2017-03-10 18:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:48:08 --> Controller Class Initialized
INFO - 2017-03-10 18:48:08 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:48:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:48:08 --> Final output sent to browser
DEBUG - 2017-03-10 18:48:08 --> Total execution time: 0.0154
INFO - 2017-03-10 18:48:22 --> Config Class Initialized
INFO - 2017-03-10 18:48:22 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:48:22 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:48:22 --> Utf8 Class Initialized
INFO - 2017-03-10 18:48:22 --> URI Class Initialized
INFO - 2017-03-10 18:48:22 --> Router Class Initialized
INFO - 2017-03-10 18:48:22 --> Output Class Initialized
INFO - 2017-03-10 18:48:22 --> Security Class Initialized
DEBUG - 2017-03-10 18:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:48:22 --> Input Class Initialized
INFO - 2017-03-10 18:48:22 --> Language Class Initialized
INFO - 2017-03-10 18:48:22 --> Loader Class Initialized
INFO - 2017-03-10 18:48:23 --> Database Driver Class Initialized
INFO - 2017-03-10 18:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:48:23 --> Controller Class Initialized
INFO - 2017-03-10 18:48:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:48:24 --> Final output sent to browser
DEBUG - 2017-03-10 18:48:24 --> Total execution time: 1.7338
INFO - 2017-03-10 18:48:45 --> Config Class Initialized
INFO - 2017-03-10 18:48:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:48:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:48:45 --> Utf8 Class Initialized
INFO - 2017-03-10 18:48:45 --> URI Class Initialized
DEBUG - 2017-03-10 18:48:45 --> No URI present. Default controller set.
INFO - 2017-03-10 18:48:45 --> Router Class Initialized
INFO - 2017-03-10 18:48:45 --> Output Class Initialized
INFO - 2017-03-10 18:48:45 --> Security Class Initialized
DEBUG - 2017-03-10 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:48:45 --> Input Class Initialized
INFO - 2017-03-10 18:48:45 --> Language Class Initialized
INFO - 2017-03-10 18:48:45 --> Loader Class Initialized
INFO - 2017-03-10 18:48:45 --> Database Driver Class Initialized
INFO - 2017-03-10 18:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:48:45 --> Controller Class Initialized
INFO - 2017-03-10 18:48:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:48:45 --> Final output sent to browser
DEBUG - 2017-03-10 18:48:45 --> Total execution time: 0.0162
INFO - 2017-03-10 18:54:28 --> Config Class Initialized
INFO - 2017-03-10 18:54:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:54:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:54:28 --> Utf8 Class Initialized
INFO - 2017-03-10 18:54:28 --> URI Class Initialized
DEBUG - 2017-03-10 18:54:28 --> No URI present. Default controller set.
INFO - 2017-03-10 18:54:28 --> Router Class Initialized
INFO - 2017-03-10 18:54:28 --> Output Class Initialized
INFO - 2017-03-10 18:54:28 --> Security Class Initialized
DEBUG - 2017-03-10 18:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:54:28 --> Input Class Initialized
INFO - 2017-03-10 18:54:28 --> Language Class Initialized
INFO - 2017-03-10 18:54:28 --> Loader Class Initialized
INFO - 2017-03-10 18:54:28 --> Database Driver Class Initialized
INFO - 2017-03-10 18:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:54:29 --> Controller Class Initialized
INFO - 2017-03-10 18:54:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:54:29 --> Final output sent to browser
DEBUG - 2017-03-10 18:54:29 --> Total execution time: 1.5278
INFO - 2017-03-10 18:54:42 --> Config Class Initialized
INFO - 2017-03-10 18:54:42 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:54:42 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:54:42 --> Utf8 Class Initialized
INFO - 2017-03-10 18:54:42 --> URI Class Initialized
INFO - 2017-03-10 18:54:42 --> Router Class Initialized
INFO - 2017-03-10 18:54:42 --> Output Class Initialized
INFO - 2017-03-10 18:54:42 --> Security Class Initialized
DEBUG - 2017-03-10 18:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:54:42 --> Input Class Initialized
INFO - 2017-03-10 18:54:42 --> Language Class Initialized
INFO - 2017-03-10 18:54:42 --> Loader Class Initialized
INFO - 2017-03-10 18:54:42 --> Database Driver Class Initialized
INFO - 2017-03-10 18:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:54:42 --> Controller Class Initialized
INFO - 2017-03-10 18:54:42 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:54:43 --> Config Class Initialized
INFO - 2017-03-10 18:54:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:54:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:54:43 --> Utf8 Class Initialized
INFO - 2017-03-10 18:54:43 --> URI Class Initialized
INFO - 2017-03-10 18:54:43 --> Router Class Initialized
INFO - 2017-03-10 18:54:43 --> Output Class Initialized
INFO - 2017-03-10 18:54:43 --> Security Class Initialized
DEBUG - 2017-03-10 18:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:54:43 --> Input Class Initialized
INFO - 2017-03-10 18:54:43 --> Language Class Initialized
INFO - 2017-03-10 18:54:43 --> Loader Class Initialized
INFO - 2017-03-10 18:54:43 --> Database Driver Class Initialized
INFO - 2017-03-10 18:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:54:43 --> Controller Class Initialized
INFO - 2017-03-10 18:54:43 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:54:43 --> Helper loaded: url_helper
INFO - 2017-03-10 18:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 18:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:54:44 --> Final output sent to browser
DEBUG - 2017-03-10 18:54:44 --> Total execution time: 0.2020
INFO - 2017-03-10 18:54:44 --> Config Class Initialized
INFO - 2017-03-10 18:54:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:54:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:54:44 --> Utf8 Class Initialized
INFO - 2017-03-10 18:54:44 --> URI Class Initialized
INFO - 2017-03-10 18:54:44 --> Router Class Initialized
INFO - 2017-03-10 18:54:44 --> Output Class Initialized
INFO - 2017-03-10 18:54:44 --> Security Class Initialized
DEBUG - 2017-03-10 18:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:54:44 --> Input Class Initialized
INFO - 2017-03-10 18:54:44 --> Language Class Initialized
INFO - 2017-03-10 18:54:44 --> Loader Class Initialized
INFO - 2017-03-10 18:54:44 --> Database Driver Class Initialized
INFO - 2017-03-10 18:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:54:44 --> Controller Class Initialized
INFO - 2017-03-10 18:54:44 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:54:44 --> Final output sent to browser
DEBUG - 2017-03-10 18:54:44 --> Total execution time: 0.0150
INFO - 2017-03-10 18:55:35 --> Config Class Initialized
INFO - 2017-03-10 18:55:35 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:55:35 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:55:35 --> Utf8 Class Initialized
INFO - 2017-03-10 18:55:35 --> URI Class Initialized
DEBUG - 2017-03-10 18:55:35 --> No URI present. Default controller set.
INFO - 2017-03-10 18:55:35 --> Router Class Initialized
INFO - 2017-03-10 18:55:35 --> Output Class Initialized
INFO - 2017-03-10 18:55:35 --> Security Class Initialized
DEBUG - 2017-03-10 18:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:55:35 --> Input Class Initialized
INFO - 2017-03-10 18:55:35 --> Language Class Initialized
INFO - 2017-03-10 18:55:35 --> Loader Class Initialized
INFO - 2017-03-10 18:55:35 --> Database Driver Class Initialized
INFO - 2017-03-10 18:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:55:35 --> Controller Class Initialized
INFO - 2017-03-10 18:55:35 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:55:35 --> Final output sent to browser
DEBUG - 2017-03-10 18:55:35 --> Total execution time: 0.0138
INFO - 2017-03-10 18:55:54 --> Config Class Initialized
INFO - 2017-03-10 18:55:54 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:55:54 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:55:54 --> Utf8 Class Initialized
INFO - 2017-03-10 18:55:54 --> URI Class Initialized
INFO - 2017-03-10 18:55:54 --> Router Class Initialized
INFO - 2017-03-10 18:55:54 --> Output Class Initialized
INFO - 2017-03-10 18:55:54 --> Security Class Initialized
DEBUG - 2017-03-10 18:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:55:54 --> Input Class Initialized
INFO - 2017-03-10 18:55:54 --> Language Class Initialized
INFO - 2017-03-10 18:55:54 --> Loader Class Initialized
INFO - 2017-03-10 18:55:54 --> Database Driver Class Initialized
INFO - 2017-03-10 18:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:55:54 --> Controller Class Initialized
INFO - 2017-03-10 18:55:54 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:55:55 --> Config Class Initialized
INFO - 2017-03-10 18:55:55 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:55:55 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:55:55 --> Utf8 Class Initialized
INFO - 2017-03-10 18:55:55 --> URI Class Initialized
INFO - 2017-03-10 18:55:55 --> Router Class Initialized
INFO - 2017-03-10 18:55:55 --> Output Class Initialized
INFO - 2017-03-10 18:55:55 --> Security Class Initialized
DEBUG - 2017-03-10 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:55:55 --> Input Class Initialized
INFO - 2017-03-10 18:55:55 --> Language Class Initialized
INFO - 2017-03-10 18:55:55 --> Loader Class Initialized
INFO - 2017-03-10 18:55:55 --> Database Driver Class Initialized
INFO - 2017-03-10 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:55:55 --> Controller Class Initialized
INFO - 2017-03-10 18:55:55 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:55:55 --> Helper loaded: url_helper
INFO - 2017-03-10 18:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 18:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 18:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:55:55 --> Final output sent to browser
DEBUG - 2017-03-10 18:55:55 --> Total execution time: 0.0144
INFO - 2017-03-10 18:57:15 --> Config Class Initialized
INFO - 2017-03-10 18:57:15 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:57:15 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:57:15 --> Utf8 Class Initialized
INFO - 2017-03-10 18:57:15 --> URI Class Initialized
DEBUG - 2017-03-10 18:57:15 --> No URI present. Default controller set.
INFO - 2017-03-10 18:57:15 --> Router Class Initialized
INFO - 2017-03-10 18:57:15 --> Output Class Initialized
INFO - 2017-03-10 18:57:15 --> Security Class Initialized
DEBUG - 2017-03-10 18:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:57:15 --> Input Class Initialized
INFO - 2017-03-10 18:57:15 --> Language Class Initialized
INFO - 2017-03-10 18:57:15 --> Loader Class Initialized
INFO - 2017-03-10 18:57:15 --> Database Driver Class Initialized
INFO - 2017-03-10 18:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:57:15 --> Controller Class Initialized
INFO - 2017-03-10 18:57:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:57:16 --> Final output sent to browser
DEBUG - 2017-03-10 18:57:16 --> Total execution time: 1.2044
INFO - 2017-03-10 18:57:25 --> Config Class Initialized
INFO - 2017-03-10 18:57:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:57:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:57:25 --> Utf8 Class Initialized
INFO - 2017-03-10 18:57:25 --> URI Class Initialized
DEBUG - 2017-03-10 18:57:25 --> No URI present. Default controller set.
INFO - 2017-03-10 18:57:25 --> Router Class Initialized
INFO - 2017-03-10 18:57:25 --> Output Class Initialized
INFO - 2017-03-10 18:57:25 --> Security Class Initialized
DEBUG - 2017-03-10 18:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:57:25 --> Input Class Initialized
INFO - 2017-03-10 18:57:25 --> Language Class Initialized
INFO - 2017-03-10 18:57:25 --> Loader Class Initialized
INFO - 2017-03-10 18:57:25 --> Database Driver Class Initialized
INFO - 2017-03-10 18:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:57:26 --> Controller Class Initialized
INFO - 2017-03-10 18:57:26 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:57:26 --> Final output sent to browser
DEBUG - 2017-03-10 18:57:26 --> Total execution time: 0.2881
INFO - 2017-03-10 18:58:44 --> Config Class Initialized
INFO - 2017-03-10 18:58:44 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:58:44 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:58:44 --> Utf8 Class Initialized
INFO - 2017-03-10 18:58:44 --> URI Class Initialized
INFO - 2017-03-10 18:58:44 --> Router Class Initialized
INFO - 2017-03-10 18:58:44 --> Output Class Initialized
INFO - 2017-03-10 18:58:44 --> Security Class Initialized
DEBUG - 2017-03-10 18:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:58:44 --> Input Class Initialized
INFO - 2017-03-10 18:58:44 --> Language Class Initialized
INFO - 2017-03-10 18:58:44 --> Loader Class Initialized
INFO - 2017-03-10 18:58:44 --> Database Driver Class Initialized
INFO - 2017-03-10 18:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:58:44 --> Controller Class Initialized
INFO - 2017-03-10 18:58:45 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:58:45 --> Helper loaded: url_helper
INFO - 2017-03-10 18:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 18:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 18:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:58:45 --> Final output sent to browser
DEBUG - 2017-03-10 18:58:45 --> Total execution time: 1.0795
INFO - 2017-03-10 18:58:45 --> Config Class Initialized
INFO - 2017-03-10 18:58:45 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:58:45 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:58:45 --> Utf8 Class Initialized
INFO - 2017-03-10 18:58:45 --> URI Class Initialized
INFO - 2017-03-10 18:58:45 --> Router Class Initialized
INFO - 2017-03-10 18:58:45 --> Output Class Initialized
INFO - 2017-03-10 18:58:45 --> Security Class Initialized
DEBUG - 2017-03-10 18:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:58:45 --> Input Class Initialized
INFO - 2017-03-10 18:58:45 --> Language Class Initialized
INFO - 2017-03-10 18:58:45 --> Loader Class Initialized
INFO - 2017-03-10 18:58:45 --> Database Driver Class Initialized
INFO - 2017-03-10 18:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:58:45 --> Controller Class Initialized
INFO - 2017-03-10 18:58:45 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:58:46 --> Config Class Initialized
INFO - 2017-03-10 18:58:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:58:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:58:46 --> Utf8 Class Initialized
INFO - 2017-03-10 18:58:46 --> URI Class Initialized
INFO - 2017-03-10 18:58:46 --> Router Class Initialized
INFO - 2017-03-10 18:58:47 --> Output Class Initialized
INFO - 2017-03-10 18:58:47 --> Security Class Initialized
DEBUG - 2017-03-10 18:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:58:47 --> Input Class Initialized
INFO - 2017-03-10 18:58:47 --> Language Class Initialized
INFO - 2017-03-10 18:58:47 --> Loader Class Initialized
INFO - 2017-03-10 18:58:47 --> Database Driver Class Initialized
INFO - 2017-03-10 18:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:58:47 --> Controller Class Initialized
INFO - 2017-03-10 18:58:47 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:58:47 --> Helper loaded: url_helper
INFO - 2017-03-10 18:58:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:58:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 18:58:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 18:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:58:48 --> Final output sent to browser
DEBUG - 2017-03-10 18:58:48 --> Total execution time: 1.2773
INFO - 2017-03-10 18:59:23 --> Config Class Initialized
INFO - 2017-03-10 18:59:23 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:59:23 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:59:23 --> Utf8 Class Initialized
INFO - 2017-03-10 18:59:23 --> URI Class Initialized
INFO - 2017-03-10 18:59:23 --> Router Class Initialized
INFO - 2017-03-10 18:59:23 --> Output Class Initialized
INFO - 2017-03-10 18:59:23 --> Security Class Initialized
DEBUG - 2017-03-10 18:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:59:23 --> Input Class Initialized
INFO - 2017-03-10 18:59:23 --> Language Class Initialized
INFO - 2017-03-10 18:59:23 --> Loader Class Initialized
INFO - 2017-03-10 18:59:23 --> Database Driver Class Initialized
INFO - 2017-03-10 18:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:59:23 --> Controller Class Initialized
INFO - 2017-03-10 18:59:23 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:59:25 --> Config Class Initialized
INFO - 2017-03-10 18:59:25 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:59:25 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:59:25 --> Utf8 Class Initialized
INFO - 2017-03-10 18:59:25 --> URI Class Initialized
INFO - 2017-03-10 18:59:25 --> Router Class Initialized
INFO - 2017-03-10 18:59:25 --> Output Class Initialized
INFO - 2017-03-10 18:59:25 --> Security Class Initialized
DEBUG - 2017-03-10 18:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:59:25 --> Input Class Initialized
INFO - 2017-03-10 18:59:25 --> Language Class Initialized
INFO - 2017-03-10 18:59:25 --> Loader Class Initialized
INFO - 2017-03-10 18:59:25 --> Database Driver Class Initialized
INFO - 2017-03-10 18:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:59:25 --> Controller Class Initialized
INFO - 2017-03-10 18:59:25 --> Helper loaded: date_helper
DEBUG - 2017-03-10 18:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:59:25 --> Helper loaded: url_helper
INFO - 2017-03-10 18:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 18:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 18:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 18:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:59:25 --> Final output sent to browser
DEBUG - 2017-03-10 18:59:25 --> Total execution time: 0.1064
INFO - 2017-03-10 18:59:28 --> Config Class Initialized
INFO - 2017-03-10 18:59:28 --> Hooks Class Initialized
DEBUG - 2017-03-10 18:59:28 --> UTF-8 Support Enabled
INFO - 2017-03-10 18:59:28 --> Utf8 Class Initialized
INFO - 2017-03-10 18:59:28 --> URI Class Initialized
DEBUG - 2017-03-10 18:59:28 --> No URI present. Default controller set.
INFO - 2017-03-10 18:59:28 --> Router Class Initialized
INFO - 2017-03-10 18:59:28 --> Output Class Initialized
INFO - 2017-03-10 18:59:28 --> Security Class Initialized
DEBUG - 2017-03-10 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 18:59:28 --> Input Class Initialized
INFO - 2017-03-10 18:59:28 --> Language Class Initialized
INFO - 2017-03-10 18:59:28 --> Loader Class Initialized
INFO - 2017-03-10 18:59:28 --> Database Driver Class Initialized
INFO - 2017-03-10 18:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 18:59:28 --> Controller Class Initialized
INFO - 2017-03-10 18:59:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 18:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 18:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 18:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 18:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 18:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 18:59:28 --> Final output sent to browser
DEBUG - 2017-03-10 18:59:28 --> Total execution time: 0.1660
INFO - 2017-03-10 19:00:19 --> Config Class Initialized
INFO - 2017-03-10 19:00:19 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:00:19 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:00:19 --> Utf8 Class Initialized
INFO - 2017-03-10 19:00:19 --> URI Class Initialized
INFO - 2017-03-10 19:00:19 --> Router Class Initialized
INFO - 2017-03-10 19:00:19 --> Output Class Initialized
INFO - 2017-03-10 19:00:19 --> Security Class Initialized
DEBUG - 2017-03-10 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:00:19 --> Input Class Initialized
INFO - 2017-03-10 19:00:19 --> Language Class Initialized
INFO - 2017-03-10 19:00:19 --> Loader Class Initialized
INFO - 2017-03-10 19:00:20 --> Database Driver Class Initialized
INFO - 2017-03-10 19:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:00:20 --> Controller Class Initialized
INFO - 2017-03-10 19:00:20 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 19:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 19:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:00:20 --> Final output sent to browser
DEBUG - 2017-03-10 19:00:20 --> Total execution time: 1.2795
INFO - 2017-03-10 19:00:38 --> Config Class Initialized
INFO - 2017-03-10 19:00:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:00:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:00:38 --> Utf8 Class Initialized
INFO - 2017-03-10 19:00:38 --> URI Class Initialized
INFO - 2017-03-10 19:00:38 --> Router Class Initialized
INFO - 2017-03-10 19:00:38 --> Output Class Initialized
INFO - 2017-03-10 19:00:38 --> Security Class Initialized
DEBUG - 2017-03-10 19:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:00:39 --> Input Class Initialized
INFO - 2017-03-10 19:00:39 --> Language Class Initialized
INFO - 2017-03-10 19:00:39 --> Loader Class Initialized
INFO - 2017-03-10 19:00:39 --> Database Driver Class Initialized
INFO - 2017-03-10 19:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:00:39 --> Controller Class Initialized
INFO - 2017-03-10 19:00:39 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:00:50 --> Config Class Initialized
INFO - 2017-03-10 19:00:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:00:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:00:50 --> Utf8 Class Initialized
INFO - 2017-03-10 19:00:50 --> URI Class Initialized
INFO - 2017-03-10 19:00:50 --> Router Class Initialized
INFO - 2017-03-10 19:00:51 --> Output Class Initialized
INFO - 2017-03-10 19:00:51 --> Security Class Initialized
DEBUG - 2017-03-10 19:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:00:51 --> Input Class Initialized
INFO - 2017-03-10 19:00:51 --> Language Class Initialized
INFO - 2017-03-10 19:00:53 --> Loader Class Initialized
INFO - 2017-03-10 19:00:53 --> Database Driver Class Initialized
INFO - 2017-03-10 19:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:00:53 --> Controller Class Initialized
INFO - 2017-03-10 19:00:53 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:00:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:00:53 --> Config Class Initialized
INFO - 2017-03-10 19:00:53 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:00:54 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:00:54 --> Utf8 Class Initialized
INFO - 2017-03-10 19:00:54 --> URI Class Initialized
INFO - 2017-03-10 19:00:54 --> Router Class Initialized
INFO - 2017-03-10 19:00:54 --> Output Class Initialized
INFO - 2017-03-10 19:00:54 --> Security Class Initialized
DEBUG - 2017-03-10 19:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:00:54 --> Input Class Initialized
INFO - 2017-03-10 19:00:54 --> Language Class Initialized
INFO - 2017-03-10 19:00:54 --> Loader Class Initialized
INFO - 2017-03-10 19:00:55 --> Database Driver Class Initialized
INFO - 2017-03-10 19:00:55 --> Config Class Initialized
INFO - 2017-03-10 19:00:55 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:00:55 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:00:56 --> Utf8 Class Initialized
INFO - 2017-03-10 19:00:56 --> URI Class Initialized
INFO - 2017-03-10 19:00:56 --> Router Class Initialized
INFO - 2017-03-10 19:00:56 --> Output Class Initialized
INFO - 2017-03-10 19:00:56 --> Security Class Initialized
DEBUG - 2017-03-10 19:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:00:56 --> Input Class Initialized
INFO - 2017-03-10 19:00:56 --> Language Class Initialized
INFO - 2017-03-10 19:00:56 --> Loader Class Initialized
INFO - 2017-03-10 19:00:56 --> Database Driver Class Initialized
INFO - 2017-03-10 19:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:00:56 --> Controller Class Initialized
INFO - 2017-03-10 19:00:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:01:01 --> Config Class Initialized
INFO - 2017-03-10 19:01:01 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:01:01 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:01:02 --> Utf8 Class Initialized
INFO - 2017-03-10 19:01:02 --> Controller Class Initialized
INFO - 2017-03-10 19:01:04 --> URI Class Initialized
INFO - 2017-03-10 19:01:04 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:01:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:01:04 --> Router Class Initialized
INFO - 2017-03-10 19:01:04 --> Output Class Initialized
INFO - 2017-03-10 19:01:04 --> Security Class Initialized
DEBUG - 2017-03-10 19:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:01:05 --> Input Class Initialized
INFO - 2017-03-10 19:01:05 --> Language Class Initialized
INFO - 2017-03-10 19:01:05 --> Loader Class Initialized
INFO - 2017-03-10 19:01:05 --> Database Driver Class Initialized
INFO - 2017-03-10 19:01:06 --> Config Class Initialized
INFO - 2017-03-10 19:01:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:01:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:01:06 --> Utf8 Class Initialized
INFO - 2017-03-10 19:01:06 --> URI Class Initialized
INFO - 2017-03-10 19:01:06 --> Router Class Initialized
INFO - 2017-03-10 19:01:06 --> Output Class Initialized
INFO - 2017-03-10 19:01:06 --> Security Class Initialized
DEBUG - 2017-03-10 19:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:01:06 --> Input Class Initialized
INFO - 2017-03-10 19:01:06 --> Language Class Initialized
INFO - 2017-03-10 19:01:06 --> Loader Class Initialized
INFO - 2017-03-10 19:01:06 --> Database Driver Class Initialized
INFO - 2017-03-10 19:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:01:07 --> Controller Class Initialized
INFO - 2017-03-10 19:01:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:01:07 --> Controller Class Initialized
INFO - 2017-03-10 19:01:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:01:07 --> Config Class Initialized
INFO - 2017-03-10 19:01:07 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:01:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:01:07 --> Utf8 Class Initialized
INFO - 2017-03-10 19:01:07 --> URI Class Initialized
INFO - 2017-03-10 19:01:07 --> Router Class Initialized
INFO - 2017-03-10 19:01:07 --> Output Class Initialized
INFO - 2017-03-10 19:01:07 --> Security Class Initialized
DEBUG - 2017-03-10 19:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:01:07 --> Input Class Initialized
INFO - 2017-03-10 19:01:07 --> Language Class Initialized
INFO - 2017-03-10 19:01:07 --> Loader Class Initialized
INFO - 2017-03-10 19:01:07 --> Database Driver Class Initialized
INFO - 2017-03-10 19:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:01:07 --> Controller Class Initialized
INFO - 2017-03-10 19:01:07 --> Helper loaded: date_helper
DEBUG - 2017-03-10 19:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:01:07 --> Helper loaded: url_helper
INFO - 2017-03-10 19:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 19:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 19:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 19:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:01:07 --> Final output sent to browser
DEBUG - 2017-03-10 19:01:07 --> Total execution time: 0.1139
INFO - 2017-03-10 19:01:18 --> Config Class Initialized
INFO - 2017-03-10 19:01:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:01:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:01:18 --> Utf8 Class Initialized
INFO - 2017-03-10 19:01:18 --> URI Class Initialized
INFO - 2017-03-10 19:01:18 --> Router Class Initialized
INFO - 2017-03-10 19:01:18 --> Output Class Initialized
INFO - 2017-03-10 19:01:18 --> Security Class Initialized
DEBUG - 2017-03-10 19:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:01:18 --> Input Class Initialized
INFO - 2017-03-10 19:01:18 --> Language Class Initialized
INFO - 2017-03-10 19:01:18 --> Loader Class Initialized
INFO - 2017-03-10 19:01:18 --> Database Driver Class Initialized
INFO - 2017-03-10 19:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:01:19 --> Controller Class Initialized
INFO - 2017-03-10 19:01:19 --> Helper loaded: date_helper
DEBUG - 2017-03-10 19:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:01:19 --> Helper loaded: url_helper
INFO - 2017-03-10 19:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-10 19:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-10 19:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 19:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:01:19 --> Final output sent to browser
DEBUG - 2017-03-10 19:01:19 --> Total execution time: 1.5710
INFO - 2017-03-10 19:49:05 --> Config Class Initialized
INFO - 2017-03-10 19:49:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:49:06 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:49:06 --> Utf8 Class Initialized
INFO - 2017-03-10 19:49:06 --> URI Class Initialized
DEBUG - 2017-03-10 19:49:06 --> No URI present. Default controller set.
INFO - 2017-03-10 19:49:06 --> Router Class Initialized
INFO - 2017-03-10 19:49:06 --> Output Class Initialized
INFO - 2017-03-10 19:49:06 --> Security Class Initialized
DEBUG - 2017-03-10 19:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:49:06 --> Input Class Initialized
INFO - 2017-03-10 19:49:06 --> Language Class Initialized
INFO - 2017-03-10 19:49:06 --> Loader Class Initialized
INFO - 2017-03-10 19:49:06 --> Database Driver Class Initialized
INFO - 2017-03-10 19:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:49:07 --> Controller Class Initialized
INFO - 2017-03-10 19:49:07 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:49:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:49:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 19:49:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 19:49:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:49:07 --> Final output sent to browser
DEBUG - 2017-03-10 19:49:07 --> Total execution time: 2.0645
INFO - 2017-03-10 19:49:26 --> Config Class Initialized
INFO - 2017-03-10 19:49:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:49:26 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:49:26 --> Utf8 Class Initialized
INFO - 2017-03-10 19:49:26 --> URI Class Initialized
INFO - 2017-03-10 19:49:26 --> Router Class Initialized
INFO - 2017-03-10 19:49:26 --> Output Class Initialized
INFO - 2017-03-10 19:49:26 --> Security Class Initialized
DEBUG - 2017-03-10 19:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:49:26 --> Input Class Initialized
INFO - 2017-03-10 19:49:26 --> Language Class Initialized
INFO - 2017-03-10 19:49:26 --> Loader Class Initialized
INFO - 2017-03-10 19:49:27 --> Database Driver Class Initialized
INFO - 2017-03-10 19:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:49:27 --> Controller Class Initialized
INFO - 2017-03-10 19:49:27 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 19:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 19:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:49:27 --> Final output sent to browser
DEBUG - 2017-03-10 19:49:27 --> Total execution time: 1.7495
INFO - 2017-03-10 19:49:37 --> Config Class Initialized
INFO - 2017-03-10 19:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:49:37 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:49:37 --> Utf8 Class Initialized
INFO - 2017-03-10 19:49:37 --> URI Class Initialized
INFO - 2017-03-10 19:49:37 --> Router Class Initialized
INFO - 2017-03-10 19:49:37 --> Output Class Initialized
INFO - 2017-03-10 19:49:37 --> Security Class Initialized
DEBUG - 2017-03-10 19:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:49:37 --> Input Class Initialized
INFO - 2017-03-10 19:49:37 --> Language Class Initialized
INFO - 2017-03-10 19:49:37 --> Loader Class Initialized
INFO - 2017-03-10 19:49:37 --> Database Driver Class Initialized
INFO - 2017-03-10 19:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:49:37 --> Controller Class Initialized
INFO - 2017-03-10 19:49:37 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-10 19:49:37 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-10 19:49:37 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-10 19:49:37 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-10 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:49:37 --> Final output sent to browser
DEBUG - 2017-03-10 19:49:37 --> Total execution time: 0.6114
INFO - 2017-03-10 19:49:56 --> Config Class Initialized
INFO - 2017-03-10 19:49:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:49:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:49:56 --> Utf8 Class Initialized
INFO - 2017-03-10 19:49:56 --> URI Class Initialized
INFO - 2017-03-10 19:49:56 --> Router Class Initialized
INFO - 2017-03-10 19:49:56 --> Output Class Initialized
INFO - 2017-03-10 19:49:56 --> Security Class Initialized
DEBUG - 2017-03-10 19:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:49:56 --> Input Class Initialized
INFO - 2017-03-10 19:49:56 --> Language Class Initialized
INFO - 2017-03-10 19:49:56 --> Loader Class Initialized
INFO - 2017-03-10 19:49:56 --> Database Driver Class Initialized
INFO - 2017-03-10 19:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:49:56 --> Controller Class Initialized
INFO - 2017-03-10 19:49:56 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 19:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 19:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:49:56 --> Final output sent to browser
DEBUG - 2017-03-10 19:49:56 --> Total execution time: 0.0136
INFO - 2017-03-10 19:50:29 --> Config Class Initialized
INFO - 2017-03-10 19:50:29 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:50:29 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:50:29 --> Utf8 Class Initialized
INFO - 2017-03-10 19:50:29 --> URI Class Initialized
INFO - 2017-03-10 19:50:29 --> Router Class Initialized
INFO - 2017-03-10 19:50:29 --> Output Class Initialized
INFO - 2017-03-10 19:50:29 --> Security Class Initialized
DEBUG - 2017-03-10 19:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:50:29 --> Input Class Initialized
INFO - 2017-03-10 19:50:29 --> Language Class Initialized
INFO - 2017-03-10 19:50:29 --> Loader Class Initialized
INFO - 2017-03-10 19:50:29 --> Database Driver Class Initialized
INFO - 2017-03-10 19:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:50:29 --> Controller Class Initialized
INFO - 2017-03-10 19:50:29 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:50:30 --> Config Class Initialized
INFO - 2017-03-10 19:50:30 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:50:30 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:50:30 --> Utf8 Class Initialized
INFO - 2017-03-10 19:50:30 --> URI Class Initialized
INFO - 2017-03-10 19:50:30 --> Router Class Initialized
INFO - 2017-03-10 19:50:30 --> Output Class Initialized
INFO - 2017-03-10 19:50:30 --> Security Class Initialized
DEBUG - 2017-03-10 19:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:50:30 --> Input Class Initialized
INFO - 2017-03-10 19:50:30 --> Language Class Initialized
INFO - 2017-03-10 19:50:30 --> Loader Class Initialized
INFO - 2017-03-10 19:50:30 --> Database Driver Class Initialized
INFO - 2017-03-10 19:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:50:30 --> Controller Class Initialized
INFO - 2017-03-10 19:50:30 --> Helper loaded: date_helper
DEBUG - 2017-03-10 19:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:50:30 --> Helper loaded: url_helper
INFO - 2017-03-10 19:50:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:50:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 19:50:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-10 19:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-10 19:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:50:31 --> Final output sent to browser
DEBUG - 2017-03-10 19:50:31 --> Total execution time: 0.3832
INFO - 2017-03-10 19:50:38 --> Config Class Initialized
INFO - 2017-03-10 19:50:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:50:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:50:38 --> Utf8 Class Initialized
INFO - 2017-03-10 19:50:38 --> URI Class Initialized
INFO - 2017-03-10 19:50:38 --> Router Class Initialized
INFO - 2017-03-10 19:50:38 --> Output Class Initialized
INFO - 2017-03-10 19:50:38 --> Security Class Initialized
DEBUG - 2017-03-10 19:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:50:38 --> Input Class Initialized
INFO - 2017-03-10 19:50:38 --> Language Class Initialized
INFO - 2017-03-10 19:50:38 --> Loader Class Initialized
INFO - 2017-03-10 19:50:38 --> Database Driver Class Initialized
INFO - 2017-03-10 19:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:50:38 --> Controller Class Initialized
INFO - 2017-03-10 19:50:38 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:50:38 --> Final output sent to browser
DEBUG - 2017-03-10 19:50:38 --> Total execution time: 0.0141
INFO - 2017-03-10 19:55:16 --> Config Class Initialized
INFO - 2017-03-10 19:55:16 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:55:16 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:55:16 --> Utf8 Class Initialized
INFO - 2017-03-10 19:55:16 --> URI Class Initialized
INFO - 2017-03-10 19:55:16 --> Router Class Initialized
INFO - 2017-03-10 19:55:16 --> Output Class Initialized
INFO - 2017-03-10 19:55:16 --> Security Class Initialized
DEBUG - 2017-03-10 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:55:16 --> Input Class Initialized
INFO - 2017-03-10 19:55:16 --> Language Class Initialized
INFO - 2017-03-10 19:55:16 --> Loader Class Initialized
INFO - 2017-03-10 19:55:17 --> Database Driver Class Initialized
INFO - 2017-03-10 19:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:55:17 --> Controller Class Initialized
INFO - 2017-03-10 19:55:17 --> Helper loaded: date_helper
DEBUG - 2017-03-10 19:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:55:17 --> Helper loaded: url_helper
INFO - 2017-03-10 19:55:17 --> Helper loaded: download_helper
INFO - 2017-03-10 19:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-10 19:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-10 19:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-10 19:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:55:18 --> Final output sent to browser
DEBUG - 2017-03-10 19:55:18 --> Total execution time: 1.9834
INFO - 2017-03-10 19:55:32 --> Config Class Initialized
INFO - 2017-03-10 19:55:32 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:55:32 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:55:32 --> Utf8 Class Initialized
INFO - 2017-03-10 19:55:32 --> URI Class Initialized
INFO - 2017-03-10 19:55:32 --> Router Class Initialized
INFO - 2017-03-10 19:55:32 --> Output Class Initialized
INFO - 2017-03-10 19:55:32 --> Security Class Initialized
DEBUG - 2017-03-10 19:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:55:33 --> Input Class Initialized
INFO - 2017-03-10 19:55:33 --> Language Class Initialized
INFO - 2017-03-10 19:55:33 --> Loader Class Initialized
INFO - 2017-03-10 19:55:33 --> Database Driver Class Initialized
INFO - 2017-03-10 19:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:55:33 --> Controller Class Initialized
INFO - 2017-03-10 19:55:33 --> Helper loaded: url_helper
DEBUG - 2017-03-10 19:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 19:55:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 19:55:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 19:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 19:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 19:55:34 --> Final output sent to browser
DEBUG - 2017-03-10 19:55:34 --> Total execution time: 1.7376
INFO - 2017-03-10 20:55:09 --> Config Class Initialized
INFO - 2017-03-10 20:55:09 --> Hooks Class Initialized
DEBUG - 2017-03-10 20:55:09 --> UTF-8 Support Enabled
INFO - 2017-03-10 20:55:09 --> Utf8 Class Initialized
INFO - 2017-03-10 20:55:09 --> URI Class Initialized
DEBUG - 2017-03-10 20:55:09 --> No URI present. Default controller set.
INFO - 2017-03-10 20:55:09 --> Router Class Initialized
INFO - 2017-03-10 20:55:09 --> Output Class Initialized
INFO - 2017-03-10 20:55:09 --> Security Class Initialized
DEBUG - 2017-03-10 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 20:55:09 --> Input Class Initialized
INFO - 2017-03-10 20:55:09 --> Language Class Initialized
INFO - 2017-03-10 20:55:09 --> Loader Class Initialized
INFO - 2017-03-10 20:55:10 --> Database Driver Class Initialized
INFO - 2017-03-10 20:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 20:55:10 --> Controller Class Initialized
INFO - 2017-03-10 20:55:10 --> Helper loaded: url_helper
DEBUG - 2017-03-10 20:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 20:55:10 --> Final output sent to browser
DEBUG - 2017-03-10 20:55:10 --> Total execution time: 1.5112
INFO - 2017-03-10 23:06:56 --> Config Class Initialized
INFO - 2017-03-10 23:06:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:06:56 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:06:56 --> Utf8 Class Initialized
INFO - 2017-03-10 23:06:56 --> URI Class Initialized
INFO - 2017-03-10 23:06:56 --> Router Class Initialized
INFO - 2017-03-10 23:06:56 --> Output Class Initialized
INFO - 2017-03-10 23:06:56 --> Security Class Initialized
DEBUG - 2017-03-10 23:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:06:56 --> Input Class Initialized
INFO - 2017-03-10 23:06:56 --> Language Class Initialized
INFO - 2017-03-10 23:06:56 --> Loader Class Initialized
INFO - 2017-03-10 23:06:57 --> Database Driver Class Initialized
INFO - 2017-03-10 23:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:06:57 --> Controller Class Initialized
INFO - 2017-03-10 23:06:57 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 23:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 23:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 23:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 23:06:57 --> Final output sent to browser
DEBUG - 2017-03-10 23:06:57 --> Total execution time: 1.8545
INFO - 2017-03-10 23:07:26 --> Config Class Initialized
INFO - 2017-03-10 23:07:26 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:07:27 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:07:27 --> Utf8 Class Initialized
INFO - 2017-03-10 23:07:27 --> URI Class Initialized
DEBUG - 2017-03-10 23:07:27 --> No URI present. Default controller set.
INFO - 2017-03-10 23:07:27 --> Router Class Initialized
INFO - 2017-03-10 23:07:27 --> Output Class Initialized
INFO - 2017-03-10 23:07:27 --> Security Class Initialized
DEBUG - 2017-03-10 23:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:07:27 --> Input Class Initialized
INFO - 2017-03-10 23:07:27 --> Language Class Initialized
INFO - 2017-03-10 23:07:27 --> Loader Class Initialized
INFO - 2017-03-10 23:07:27 --> Database Driver Class Initialized
INFO - 2017-03-10 23:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:07:28 --> Controller Class Initialized
INFO - 2017-03-10 23:07:28 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 23:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 23:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 23:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 23:07:28 --> Final output sent to browser
DEBUG - 2017-03-10 23:07:28 --> Total execution time: 1.7259
INFO - 2017-03-10 23:10:56 --> Config Class Initialized
INFO - 2017-03-10 23:10:56 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:10:57 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:10:57 --> Utf8 Class Initialized
INFO - 2017-03-10 23:10:57 --> URI Class Initialized
INFO - 2017-03-10 23:10:57 --> Router Class Initialized
INFO - 2017-03-10 23:10:57 --> Output Class Initialized
INFO - 2017-03-10 23:10:57 --> Security Class Initialized
DEBUG - 2017-03-10 23:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:10:57 --> Input Class Initialized
INFO - 2017-03-10 23:10:57 --> Language Class Initialized
INFO - 2017-03-10 23:10:57 --> Loader Class Initialized
INFO - 2017-03-10 23:10:58 --> Database Driver Class Initialized
INFO - 2017-03-10 23:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:10:58 --> Controller Class Initialized
INFO - 2017-03-10 23:10:58 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-10 23:10:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-10 23:10:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-10 23:10:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-10 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 23:10:59 --> Final output sent to browser
DEBUG - 2017-03-10 23:10:59 --> Total execution time: 2.3594
INFO - 2017-03-10 23:11:11 --> Config Class Initialized
INFO - 2017-03-10 23:11:11 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:11:11 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:11:11 --> Utf8 Class Initialized
INFO - 2017-03-10 23:11:11 --> URI Class Initialized
INFO - 2017-03-10 23:11:11 --> Router Class Initialized
INFO - 2017-03-10 23:11:11 --> Output Class Initialized
INFO - 2017-03-10 23:11:11 --> Security Class Initialized
DEBUG - 2017-03-10 23:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:11:12 --> Input Class Initialized
INFO - 2017-03-10 23:11:12 --> Language Class Initialized
INFO - 2017-03-10 23:11:12 --> Loader Class Initialized
INFO - 2017-03-10 23:11:12 --> Database Driver Class Initialized
INFO - 2017-03-10 23:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:11:12 --> Controller Class Initialized
INFO - 2017-03-10 23:11:12 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:11:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-10 23:11:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-10 23:11:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Angelica Ortiz')
INFO - 2017-03-10 23:11:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-10 23:11:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-10 23:21:06 --> Config Class Initialized
INFO - 2017-03-10 23:21:06 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:21:07 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:21:07 --> Utf8 Class Initialized
INFO - 2017-03-10 23:21:07 --> URI Class Initialized
INFO - 2017-03-10 23:21:07 --> Router Class Initialized
INFO - 2017-03-10 23:21:07 --> Output Class Initialized
INFO - 2017-03-10 23:21:07 --> Security Class Initialized
DEBUG - 2017-03-10 23:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:21:07 --> Input Class Initialized
INFO - 2017-03-10 23:21:07 --> Language Class Initialized
INFO - 2017-03-10 23:21:07 --> Loader Class Initialized
INFO - 2017-03-10 23:21:07 --> Database Driver Class Initialized
INFO - 2017-03-10 23:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:21:08 --> Controller Class Initialized
INFO - 2017-03-10 23:21:08 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 23:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 23:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 23:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 23:21:08 --> Final output sent to browser
DEBUG - 2017-03-10 23:21:08 --> Total execution time: 1.7459
INFO - 2017-03-10 23:23:12 --> Config Class Initialized
INFO - 2017-03-10 23:23:12 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:23:13 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:23:13 --> Utf8 Class Initialized
INFO - 2017-03-10 23:23:13 --> URI Class Initialized
DEBUG - 2017-03-10 23:23:13 --> No URI present. Default controller set.
INFO - 2017-03-10 23:23:13 --> Router Class Initialized
INFO - 2017-03-10 23:23:13 --> Output Class Initialized
INFO - 2017-03-10 23:23:13 --> Security Class Initialized
DEBUG - 2017-03-10 23:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:23:13 --> Input Class Initialized
INFO - 2017-03-10 23:23:13 --> Language Class Initialized
INFO - 2017-03-10 23:23:14 --> Loader Class Initialized
INFO - 2017-03-10 23:23:14 --> Database Driver Class Initialized
INFO - 2017-03-10 23:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:23:15 --> Controller Class Initialized
INFO - 2017-03-10 23:23:15 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:23:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 23:23:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 23:23:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 23:23:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 23:23:15 --> Final output sent to browser
DEBUG - 2017-03-10 23:23:15 --> Total execution time: 4.4753
INFO - 2017-03-10 23:50:42 --> Config Class Initialized
INFO - 2017-03-10 23:50:42 --> Config Class Initialized
INFO - 2017-03-10 23:50:43 --> Hooks Class Initialized
INFO - 2017-03-10 23:50:43 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:50:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:50:43 --> Utf8 Class Initialized
DEBUG - 2017-03-10 23:50:43 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:50:43 --> Utf8 Class Initialized
INFO - 2017-03-10 23:50:43 --> URI Class Initialized
INFO - 2017-03-10 23:50:43 --> URI Class Initialized
INFO - 2017-03-10 23:50:43 --> Router Class Initialized
DEBUG - 2017-03-10 23:50:43 --> No URI present. Default controller set.
INFO - 2017-03-10 23:50:43 --> Router Class Initialized
INFO - 2017-03-10 23:50:43 --> Output Class Initialized
INFO - 2017-03-10 23:50:43 --> Security Class Initialized
INFO - 2017-03-10 23:50:43 --> Output Class Initialized
INFO - 2017-03-10 23:50:43 --> Security Class Initialized
DEBUG - 2017-03-10 23:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:50:43 --> Input Class Initialized
INFO - 2017-03-10 23:50:43 --> Language Class Initialized
DEBUG - 2017-03-10 23:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:50:43 --> Input Class Initialized
INFO - 2017-03-10 23:50:43 --> Language Class Initialized
INFO - 2017-03-10 23:50:43 --> Loader Class Initialized
INFO - 2017-03-10 23:50:43 --> Loader Class Initialized
INFO - 2017-03-10 23:50:43 --> Database Driver Class Initialized
INFO - 2017-03-10 23:50:43 --> Database Driver Class Initialized
INFO - 2017-03-10 23:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:50:44 --> Controller Class Initialized
INFO - 2017-03-10 23:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:50:44 --> Controller Class Initialized
INFO - 2017-03-10 23:50:44 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:50:44 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:50:44 --> Helper loaded: form_helper
INFO - 2017-03-10 23:50:44 --> Form Validation Class Initialized
INFO - 2017-03-10 23:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 23:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 23:50:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-10 23:50:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-10 23:50:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-10 23:50:44 --> Final output sent to browser
DEBUG - 2017-03-10 23:50:44 --> Total execution time: 1.9008
INFO - 2017-03-10 23:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 23:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 23:50:44 --> Final output sent to browser
DEBUG - 2017-03-10 23:50:44 --> Total execution time: 1.9592
INFO - 2017-03-10 23:50:46 --> Config Class Initialized
INFO - 2017-03-10 23:50:46 --> Hooks Class Initialized
DEBUG - 2017-03-10 23:50:46 --> UTF-8 Support Enabled
INFO - 2017-03-10 23:50:46 --> Utf8 Class Initialized
INFO - 2017-03-10 23:50:46 --> URI Class Initialized
INFO - 2017-03-10 23:50:46 --> Router Class Initialized
INFO - 2017-03-10 23:50:46 --> Output Class Initialized
INFO - 2017-03-10 23:50:46 --> Security Class Initialized
DEBUG - 2017-03-10 23:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 23:50:46 --> Input Class Initialized
INFO - 2017-03-10 23:50:46 --> Language Class Initialized
INFO - 2017-03-10 23:50:46 --> Loader Class Initialized
INFO - 2017-03-10 23:50:46 --> Database Driver Class Initialized
INFO - 2017-03-10 23:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 23:50:46 --> Controller Class Initialized
INFO - 2017-03-10 23:50:46 --> Helper loaded: url_helper
DEBUG - 2017-03-10 23:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-10 23:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-10 23:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-10 23:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-10 23:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-10 23:50:46 --> Final output sent to browser
DEBUG - 2017-03-10 23:50:46 --> Total execution time: 0.7352

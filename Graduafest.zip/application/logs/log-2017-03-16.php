<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-16 00:37:29 --> Config Class Initialized
INFO - 2017-03-16 00:37:29 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:37:29 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:37:29 --> Utf8 Class Initialized
INFO - 2017-03-16 00:37:29 --> URI Class Initialized
INFO - 2017-03-16 00:37:29 --> Router Class Initialized
INFO - 2017-03-16 00:37:30 --> Output Class Initialized
INFO - 2017-03-16 00:37:30 --> Security Class Initialized
DEBUG - 2017-03-16 00:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:37:30 --> Input Class Initialized
INFO - 2017-03-16 00:37:30 --> Language Class Initialized
INFO - 2017-03-16 00:37:30 --> Loader Class Initialized
INFO - 2017-03-16 00:37:30 --> Database Driver Class Initialized
INFO - 2017-03-16 00:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:37:31 --> Controller Class Initialized
INFO - 2017-03-16 00:37:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:37:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 00:37:32 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 00:37:32 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-16 00:37:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 00:37:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 00:37:32 --> Config Class Initialized
INFO - 2017-03-16 00:37:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:37:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:37:32 --> Utf8 Class Initialized
INFO - 2017-03-16 00:37:32 --> URI Class Initialized
INFO - 2017-03-16 00:37:32 --> Router Class Initialized
INFO - 2017-03-16 00:37:32 --> Output Class Initialized
INFO - 2017-03-16 00:37:32 --> Security Class Initialized
DEBUG - 2017-03-16 00:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:37:32 --> Input Class Initialized
INFO - 2017-03-16 00:37:32 --> Language Class Initialized
INFO - 2017-03-16 00:37:32 --> Loader Class Initialized
INFO - 2017-03-16 00:37:32 --> Database Driver Class Initialized
INFO - 2017-03-16 00:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:37:32 --> Controller Class Initialized
INFO - 2017-03-16 00:37:32 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:37:32 --> Final output sent to browser
DEBUG - 2017-03-16 00:37:32 --> Total execution time: 0.1621
INFO - 2017-03-16 00:37:36 --> Config Class Initialized
INFO - 2017-03-16 00:37:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:37:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:37:36 --> Utf8 Class Initialized
INFO - 2017-03-16 00:37:36 --> URI Class Initialized
DEBUG - 2017-03-16 00:37:36 --> No URI present. Default controller set.
INFO - 2017-03-16 00:37:36 --> Router Class Initialized
INFO - 2017-03-16 00:37:36 --> Output Class Initialized
INFO - 2017-03-16 00:37:36 --> Security Class Initialized
DEBUG - 2017-03-16 00:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:37:36 --> Input Class Initialized
INFO - 2017-03-16 00:37:36 --> Language Class Initialized
INFO - 2017-03-16 00:37:36 --> Loader Class Initialized
INFO - 2017-03-16 00:37:36 --> Database Driver Class Initialized
INFO - 2017-03-16 00:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:37:36 --> Controller Class Initialized
INFO - 2017-03-16 00:37:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:37:36 --> Final output sent to browser
DEBUG - 2017-03-16 00:37:36 --> Total execution time: 0.0202
INFO - 2017-03-16 00:37:39 --> Config Class Initialized
INFO - 2017-03-16 00:37:39 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:37:39 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:37:39 --> Utf8 Class Initialized
INFO - 2017-03-16 00:37:39 --> URI Class Initialized
INFO - 2017-03-16 00:37:39 --> Router Class Initialized
INFO - 2017-03-16 00:37:39 --> Output Class Initialized
INFO - 2017-03-16 00:37:39 --> Security Class Initialized
DEBUG - 2017-03-16 00:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:37:39 --> Input Class Initialized
INFO - 2017-03-16 00:37:39 --> Language Class Initialized
INFO - 2017-03-16 00:37:39 --> Loader Class Initialized
INFO - 2017-03-16 00:37:39 --> Database Driver Class Initialized
INFO - 2017-03-16 00:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:37:39 --> Controller Class Initialized
INFO - 2017-03-16 00:37:39 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:37:39 --> Final output sent to browser
DEBUG - 2017-03-16 00:37:39 --> Total execution time: 0.0126
INFO - 2017-03-16 00:38:08 --> Config Class Initialized
INFO - 2017-03-16 00:38:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:08 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:08 --> URI Class Initialized
DEBUG - 2017-03-16 00:38:08 --> No URI present. Default controller set.
INFO - 2017-03-16 00:38:08 --> Router Class Initialized
INFO - 2017-03-16 00:38:08 --> Output Class Initialized
INFO - 2017-03-16 00:38:08 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:08 --> Input Class Initialized
INFO - 2017-03-16 00:38:08 --> Language Class Initialized
INFO - 2017-03-16 00:38:08 --> Loader Class Initialized
INFO - 2017-03-16 00:38:08 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:08 --> Controller Class Initialized
INFO - 2017-03-16 00:38:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:08 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:08 --> Total execution time: 0.0128
INFO - 2017-03-16 00:38:08 --> Config Class Initialized
INFO - 2017-03-16 00:38:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:08 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:08 --> URI Class Initialized
INFO - 2017-03-16 00:38:08 --> Router Class Initialized
INFO - 2017-03-16 00:38:08 --> Output Class Initialized
INFO - 2017-03-16 00:38:08 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:08 --> Input Class Initialized
INFO - 2017-03-16 00:38:08 --> Language Class Initialized
INFO - 2017-03-16 00:38:08 --> Loader Class Initialized
INFO - 2017-03-16 00:38:08 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:08 --> Controller Class Initialized
INFO - 2017-03-16 00:38:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:08 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:08 --> Total execution time: 0.0138
INFO - 2017-03-16 00:38:10 --> Config Class Initialized
INFO - 2017-03-16 00:38:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:10 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:10 --> URI Class Initialized
INFO - 2017-03-16 00:38:10 --> Router Class Initialized
INFO - 2017-03-16 00:38:10 --> Output Class Initialized
INFO - 2017-03-16 00:38:10 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:10 --> Input Class Initialized
INFO - 2017-03-16 00:38:10 --> Language Class Initialized
INFO - 2017-03-16 00:38:10 --> Loader Class Initialized
INFO - 2017-03-16 00:38:10 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:10 --> Controller Class Initialized
INFO - 2017-03-16 00:38:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:10 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:10 --> Total execution time: 0.0128
INFO - 2017-03-16 00:38:13 --> Config Class Initialized
INFO - 2017-03-16 00:38:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:13 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:13 --> URI Class Initialized
INFO - 2017-03-16 00:38:13 --> Router Class Initialized
INFO - 2017-03-16 00:38:13 --> Output Class Initialized
INFO - 2017-03-16 00:38:13 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:13 --> Input Class Initialized
INFO - 2017-03-16 00:38:13 --> Language Class Initialized
INFO - 2017-03-16 00:38:13 --> Loader Class Initialized
INFO - 2017-03-16 00:38:13 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:13 --> Controller Class Initialized
INFO - 2017-03-16 00:38:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:13 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:13 --> Total execution time: 0.0131
INFO - 2017-03-16 00:38:49 --> Config Class Initialized
INFO - 2017-03-16 00:38:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:49 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:49 --> URI Class Initialized
INFO - 2017-03-16 00:38:49 --> Router Class Initialized
INFO - 2017-03-16 00:38:49 --> Output Class Initialized
INFO - 2017-03-16 00:38:49 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:49 --> Input Class Initialized
INFO - 2017-03-16 00:38:49 --> Language Class Initialized
INFO - 2017-03-16 00:38:49 --> Loader Class Initialized
INFO - 2017-03-16 00:38:49 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:49 --> Controller Class Initialized
INFO - 2017-03-16 00:38:49 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:50 --> Config Class Initialized
INFO - 2017-03-16 00:38:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:50 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:50 --> URI Class Initialized
INFO - 2017-03-16 00:38:50 --> Router Class Initialized
INFO - 2017-03-16 00:38:50 --> Output Class Initialized
INFO - 2017-03-16 00:38:50 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:50 --> Input Class Initialized
INFO - 2017-03-16 00:38:50 --> Language Class Initialized
INFO - 2017-03-16 00:38:50 --> Loader Class Initialized
INFO - 2017-03-16 00:38:50 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:50 --> Controller Class Initialized
INFO - 2017-03-16 00:38:50 --> Helper loaded: date_helper
DEBUG - 2017-03-16 00:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:50 --> Helper loaded: url_helper
INFO - 2017-03-16 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:50 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:50 --> Total execution time: 0.1617
INFO - 2017-03-16 00:38:51 --> Config Class Initialized
INFO - 2017-03-16 00:38:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:51 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:51 --> URI Class Initialized
INFO - 2017-03-16 00:38:51 --> Router Class Initialized
INFO - 2017-03-16 00:38:51 --> Output Class Initialized
INFO - 2017-03-16 00:38:51 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:51 --> Input Class Initialized
INFO - 2017-03-16 00:38:51 --> Language Class Initialized
INFO - 2017-03-16 00:38:51 --> Loader Class Initialized
INFO - 2017-03-16 00:38:51 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:51 --> Controller Class Initialized
INFO - 2017-03-16 00:38:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:51 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:51 --> Total execution time: 0.0133
INFO - 2017-03-16 00:38:51 --> Config Class Initialized
INFO - 2017-03-16 00:38:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:51 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:51 --> URI Class Initialized
INFO - 2017-03-16 00:38:51 --> Router Class Initialized
INFO - 2017-03-16 00:38:51 --> Output Class Initialized
INFO - 2017-03-16 00:38:51 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:51 --> Input Class Initialized
INFO - 2017-03-16 00:38:51 --> Language Class Initialized
INFO - 2017-03-16 00:38:51 --> Loader Class Initialized
INFO - 2017-03-16 00:38:51 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:51 --> Controller Class Initialized
INFO - 2017-03-16 00:38:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:51 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:51 --> Total execution time: 0.0138
INFO - 2017-03-16 00:38:53 --> Config Class Initialized
INFO - 2017-03-16 00:38:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:38:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:38:53 --> Utf8 Class Initialized
INFO - 2017-03-16 00:38:53 --> URI Class Initialized
INFO - 2017-03-16 00:38:53 --> Router Class Initialized
INFO - 2017-03-16 00:38:53 --> Output Class Initialized
INFO - 2017-03-16 00:38:53 --> Security Class Initialized
DEBUG - 2017-03-16 00:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:38:53 --> Input Class Initialized
INFO - 2017-03-16 00:38:53 --> Language Class Initialized
INFO - 2017-03-16 00:38:53 --> Loader Class Initialized
INFO - 2017-03-16 00:38:53 --> Database Driver Class Initialized
INFO - 2017-03-16 00:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:38:53 --> Controller Class Initialized
INFO - 2017-03-16 00:38:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:38:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:38:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:38:53 --> Final output sent to browser
DEBUG - 2017-03-16 00:38:53 --> Total execution time: 0.0132
INFO - 2017-03-16 00:39:12 --> Config Class Initialized
INFO - 2017-03-16 00:39:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:39:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:39:12 --> Utf8 Class Initialized
INFO - 2017-03-16 00:39:12 --> URI Class Initialized
INFO - 2017-03-16 00:39:12 --> Router Class Initialized
INFO - 2017-03-16 00:39:12 --> Output Class Initialized
INFO - 2017-03-16 00:39:12 --> Security Class Initialized
DEBUG - 2017-03-16 00:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:39:12 --> Input Class Initialized
INFO - 2017-03-16 00:39:12 --> Language Class Initialized
INFO - 2017-03-16 00:39:12 --> Loader Class Initialized
INFO - 2017-03-16 00:39:12 --> Database Driver Class Initialized
INFO - 2017-03-16 00:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:39:12 --> Controller Class Initialized
INFO - 2017-03-16 00:39:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:39:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:39:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:39:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:39:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:39:12 --> Final output sent to browser
DEBUG - 2017-03-16 00:39:12 --> Total execution time: 0.0140
INFO - 2017-03-16 00:39:14 --> Config Class Initialized
INFO - 2017-03-16 00:39:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:39:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:39:14 --> Utf8 Class Initialized
INFO - 2017-03-16 00:39:14 --> URI Class Initialized
INFO - 2017-03-16 00:39:14 --> Router Class Initialized
INFO - 2017-03-16 00:39:14 --> Output Class Initialized
INFO - 2017-03-16 00:39:14 --> Security Class Initialized
DEBUG - 2017-03-16 00:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:39:14 --> Input Class Initialized
INFO - 2017-03-16 00:39:14 --> Language Class Initialized
INFO - 2017-03-16 00:39:14 --> Loader Class Initialized
INFO - 2017-03-16 00:39:14 --> Database Driver Class Initialized
INFO - 2017-03-16 00:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:39:14 --> Controller Class Initialized
INFO - 2017-03-16 00:39:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:39:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:39:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:39:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:39:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:39:14 --> Final output sent to browser
DEBUG - 2017-03-16 00:39:14 --> Total execution time: 0.0132
INFO - 2017-03-16 00:39:21 --> Config Class Initialized
INFO - 2017-03-16 00:39:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:39:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:39:21 --> Utf8 Class Initialized
INFO - 2017-03-16 00:39:21 --> URI Class Initialized
DEBUG - 2017-03-16 00:39:21 --> No URI present. Default controller set.
INFO - 2017-03-16 00:39:21 --> Router Class Initialized
INFO - 2017-03-16 00:39:21 --> Output Class Initialized
INFO - 2017-03-16 00:39:21 --> Security Class Initialized
DEBUG - 2017-03-16 00:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:39:21 --> Input Class Initialized
INFO - 2017-03-16 00:39:21 --> Language Class Initialized
INFO - 2017-03-16 00:39:21 --> Loader Class Initialized
INFO - 2017-03-16 00:39:21 --> Database Driver Class Initialized
INFO - 2017-03-16 00:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:39:21 --> Controller Class Initialized
INFO - 2017-03-16 00:39:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:39:21 --> Final output sent to browser
DEBUG - 2017-03-16 00:39:21 --> Total execution time: 0.0129
INFO - 2017-03-16 00:39:23 --> Config Class Initialized
INFO - 2017-03-16 00:39:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:39:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:39:23 --> Utf8 Class Initialized
INFO - 2017-03-16 00:39:23 --> URI Class Initialized
INFO - 2017-03-16 00:39:23 --> Router Class Initialized
INFO - 2017-03-16 00:39:23 --> Output Class Initialized
INFO - 2017-03-16 00:39:23 --> Security Class Initialized
DEBUG - 2017-03-16 00:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:39:23 --> Input Class Initialized
INFO - 2017-03-16 00:39:23 --> Language Class Initialized
INFO - 2017-03-16 00:39:23 --> Loader Class Initialized
INFO - 2017-03-16 00:39:23 --> Database Driver Class Initialized
INFO - 2017-03-16 00:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:39:23 --> Controller Class Initialized
INFO - 2017-03-16 00:39:23 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:39:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:39:23 --> Final output sent to browser
DEBUG - 2017-03-16 00:39:23 --> Total execution time: 0.0132
INFO - 2017-03-16 00:40:26 --> Config Class Initialized
INFO - 2017-03-16 00:40:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:40:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:40:26 --> Utf8 Class Initialized
INFO - 2017-03-16 00:40:26 --> URI Class Initialized
DEBUG - 2017-03-16 00:40:26 --> No URI present. Default controller set.
INFO - 2017-03-16 00:40:26 --> Router Class Initialized
INFO - 2017-03-16 00:40:26 --> Output Class Initialized
INFO - 2017-03-16 00:40:26 --> Security Class Initialized
DEBUG - 2017-03-16 00:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:40:26 --> Input Class Initialized
INFO - 2017-03-16 00:40:26 --> Language Class Initialized
INFO - 2017-03-16 00:40:26 --> Loader Class Initialized
INFO - 2017-03-16 00:40:26 --> Database Driver Class Initialized
INFO - 2017-03-16 00:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:40:26 --> Controller Class Initialized
INFO - 2017-03-16 00:40:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:40:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:40:26 --> Final output sent to browser
DEBUG - 2017-03-16 00:40:26 --> Total execution time: 0.2199
INFO - 2017-03-16 00:40:28 --> Config Class Initialized
INFO - 2017-03-16 00:40:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:40:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:40:28 --> Utf8 Class Initialized
INFO - 2017-03-16 00:40:28 --> URI Class Initialized
INFO - 2017-03-16 00:40:28 --> Router Class Initialized
INFO - 2017-03-16 00:40:28 --> Output Class Initialized
INFO - 2017-03-16 00:40:28 --> Security Class Initialized
DEBUG - 2017-03-16 00:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:40:28 --> Input Class Initialized
INFO - 2017-03-16 00:40:28 --> Language Class Initialized
INFO - 2017-03-16 00:40:28 --> Loader Class Initialized
INFO - 2017-03-16 00:40:28 --> Database Driver Class Initialized
INFO - 2017-03-16 00:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:40:28 --> Controller Class Initialized
INFO - 2017-03-16 00:40:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:40:28 --> Final output sent to browser
DEBUG - 2017-03-16 00:40:28 --> Total execution time: 0.0130
INFO - 2017-03-16 00:40:54 --> Config Class Initialized
INFO - 2017-03-16 00:40:54 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:40:54 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:40:54 --> Utf8 Class Initialized
INFO - 2017-03-16 00:40:54 --> URI Class Initialized
INFO - 2017-03-16 00:40:54 --> Router Class Initialized
INFO - 2017-03-16 00:40:54 --> Output Class Initialized
INFO - 2017-03-16 00:40:54 --> Security Class Initialized
DEBUG - 2017-03-16 00:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:40:54 --> Input Class Initialized
INFO - 2017-03-16 00:40:54 --> Language Class Initialized
INFO - 2017-03-16 00:40:54 --> Loader Class Initialized
INFO - 2017-03-16 00:40:54 --> Database Driver Class Initialized
INFO - 2017-03-16 00:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:40:54 --> Controller Class Initialized
INFO - 2017-03-16 00:40:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:40:54 --> Final output sent to browser
DEBUG - 2017-03-16 00:40:54 --> Total execution time: 0.4466
INFO - 2017-03-16 00:40:56 --> Config Class Initialized
INFO - 2017-03-16 00:40:56 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:40:56 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:40:56 --> Utf8 Class Initialized
INFO - 2017-03-16 00:40:56 --> URI Class Initialized
INFO - 2017-03-16 00:40:56 --> Router Class Initialized
INFO - 2017-03-16 00:40:56 --> Output Class Initialized
INFO - 2017-03-16 00:40:56 --> Security Class Initialized
DEBUG - 2017-03-16 00:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:40:56 --> Input Class Initialized
INFO - 2017-03-16 00:40:56 --> Language Class Initialized
INFO - 2017-03-16 00:40:56 --> Loader Class Initialized
INFO - 2017-03-16 00:40:56 --> Database Driver Class Initialized
INFO - 2017-03-16 00:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:40:56 --> Controller Class Initialized
INFO - 2017-03-16 00:40:56 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:40:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:40:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:40:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:40:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:40:56 --> Final output sent to browser
DEBUG - 2017-03-16 00:40:56 --> Total execution time: 0.0135
INFO - 2017-03-16 00:41:18 --> Config Class Initialized
INFO - 2017-03-16 00:41:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:18 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:18 --> URI Class Initialized
INFO - 2017-03-16 00:41:18 --> Router Class Initialized
INFO - 2017-03-16 00:41:18 --> Output Class Initialized
INFO - 2017-03-16 00:41:18 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:18 --> Input Class Initialized
INFO - 2017-03-16 00:41:18 --> Language Class Initialized
INFO - 2017-03-16 00:41:18 --> Loader Class Initialized
INFO - 2017-03-16 00:41:18 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:18 --> Controller Class Initialized
INFO - 2017-03-16 00:41:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:20 --> Config Class Initialized
INFO - 2017-03-16 00:41:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:20 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:20 --> URI Class Initialized
INFO - 2017-03-16 00:41:20 --> Router Class Initialized
INFO - 2017-03-16 00:41:20 --> Output Class Initialized
INFO - 2017-03-16 00:41:20 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:20 --> Input Class Initialized
INFO - 2017-03-16 00:41:20 --> Language Class Initialized
INFO - 2017-03-16 00:41:20 --> Loader Class Initialized
INFO - 2017-03-16 00:41:20 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:20 --> Controller Class Initialized
INFO - 2017-03-16 00:41:20 --> Helper loaded: date_helper
DEBUG - 2017-03-16 00:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:20 --> Helper loaded: url_helper
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:20 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:20 --> Total execution time: 0.1051
INFO - 2017-03-16 00:41:20 --> Config Class Initialized
INFO - 2017-03-16 00:41:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:20 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:20 --> URI Class Initialized
INFO - 2017-03-16 00:41:20 --> Router Class Initialized
INFO - 2017-03-16 00:41:20 --> Output Class Initialized
INFO - 2017-03-16 00:41:20 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:20 --> Input Class Initialized
INFO - 2017-03-16 00:41:20 --> Language Class Initialized
INFO - 2017-03-16 00:41:20 --> Loader Class Initialized
INFO - 2017-03-16 00:41:20 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:20 --> Controller Class Initialized
INFO - 2017-03-16 00:41:20 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:20 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:20 --> Total execution time: 0.0136
INFO - 2017-03-16 00:41:24 --> Config Class Initialized
INFO - 2017-03-16 00:41:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:24 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:24 --> URI Class Initialized
INFO - 2017-03-16 00:41:24 --> Router Class Initialized
INFO - 2017-03-16 00:41:24 --> Output Class Initialized
INFO - 2017-03-16 00:41:24 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:24 --> Input Class Initialized
INFO - 2017-03-16 00:41:24 --> Language Class Initialized
INFO - 2017-03-16 00:41:24 --> Loader Class Initialized
INFO - 2017-03-16 00:41:24 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:24 --> Controller Class Initialized
INFO - 2017-03-16 00:41:24 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:24 --> Config Class Initialized
INFO - 2017-03-16 00:41:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:24 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:24 --> URI Class Initialized
INFO - 2017-03-16 00:41:24 --> Router Class Initialized
INFO - 2017-03-16 00:41:24 --> Output Class Initialized
INFO - 2017-03-16 00:41:24 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:24 --> Input Class Initialized
INFO - 2017-03-16 00:41:24 --> Language Class Initialized
INFO - 2017-03-16 00:41:24 --> Loader Class Initialized
INFO - 2017-03-16 00:41:24 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:24 --> Controller Class Initialized
INFO - 2017-03-16 00:41:24 --> Helper loaded: date_helper
DEBUG - 2017-03-16 00:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:24 --> Helper loaded: url_helper
INFO - 2017-03-16 00:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 00:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 00:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 00:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:24 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:24 --> Total execution time: 0.0144
INFO - 2017-03-16 00:41:25 --> Config Class Initialized
INFO - 2017-03-16 00:41:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:25 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:25 --> URI Class Initialized
INFO - 2017-03-16 00:41:25 --> Router Class Initialized
INFO - 2017-03-16 00:41:25 --> Output Class Initialized
INFO - 2017-03-16 00:41:25 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:25 --> Input Class Initialized
INFO - 2017-03-16 00:41:25 --> Language Class Initialized
INFO - 2017-03-16 00:41:25 --> Loader Class Initialized
INFO - 2017-03-16 00:41:25 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:25 --> Controller Class Initialized
INFO - 2017-03-16 00:41:25 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:25 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:25 --> Total execution time: 0.0130
INFO - 2017-03-16 00:41:29 --> Config Class Initialized
INFO - 2017-03-16 00:41:29 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:29 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:29 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:29 --> URI Class Initialized
DEBUG - 2017-03-16 00:41:29 --> No URI present. Default controller set.
INFO - 2017-03-16 00:41:29 --> Router Class Initialized
INFO - 2017-03-16 00:41:29 --> Output Class Initialized
INFO - 2017-03-16 00:41:29 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:29 --> Input Class Initialized
INFO - 2017-03-16 00:41:29 --> Language Class Initialized
INFO - 2017-03-16 00:41:29 --> Loader Class Initialized
INFO - 2017-03-16 00:41:29 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:29 --> Controller Class Initialized
INFO - 2017-03-16 00:41:29 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:29 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:29 --> Total execution time: 0.0129
INFO - 2017-03-16 00:41:29 --> Config Class Initialized
INFO - 2017-03-16 00:41:29 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:29 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:29 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:29 --> URI Class Initialized
INFO - 2017-03-16 00:41:29 --> Router Class Initialized
INFO - 2017-03-16 00:41:29 --> Output Class Initialized
INFO - 2017-03-16 00:41:29 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:29 --> Input Class Initialized
INFO - 2017-03-16 00:41:29 --> Language Class Initialized
INFO - 2017-03-16 00:41:29 --> Loader Class Initialized
INFO - 2017-03-16 00:41:29 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:29 --> Controller Class Initialized
INFO - 2017-03-16 00:41:29 --> Helper loaded: date_helper
DEBUG - 2017-03-16 00:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:29 --> Helper loaded: url_helper
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 00:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:29 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:29 --> Total execution time: 0.0133
INFO - 2017-03-16 00:41:30 --> Config Class Initialized
INFO - 2017-03-16 00:41:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:30 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:30 --> URI Class Initialized
INFO - 2017-03-16 00:41:30 --> Router Class Initialized
INFO - 2017-03-16 00:41:30 --> Output Class Initialized
INFO - 2017-03-16 00:41:30 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:30 --> Input Class Initialized
INFO - 2017-03-16 00:41:30 --> Language Class Initialized
INFO - 2017-03-16 00:41:30 --> Loader Class Initialized
INFO - 2017-03-16 00:41:30 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:30 --> Controller Class Initialized
INFO - 2017-03-16 00:41:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:30 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:30 --> Total execution time: 0.0129
INFO - 2017-03-16 00:41:33 --> Config Class Initialized
INFO - 2017-03-16 00:41:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:33 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:33 --> URI Class Initialized
INFO - 2017-03-16 00:41:33 --> Router Class Initialized
INFO - 2017-03-16 00:41:33 --> Output Class Initialized
INFO - 2017-03-16 00:41:33 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:33 --> Input Class Initialized
INFO - 2017-03-16 00:41:33 --> Language Class Initialized
INFO - 2017-03-16 00:41:33 --> Loader Class Initialized
INFO - 2017-03-16 00:41:33 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:33 --> Controller Class Initialized
INFO - 2017-03-16 00:41:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:33 --> Config Class Initialized
INFO - 2017-03-16 00:41:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:33 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:33 --> URI Class Initialized
INFO - 2017-03-16 00:41:33 --> Router Class Initialized
INFO - 2017-03-16 00:41:33 --> Output Class Initialized
INFO - 2017-03-16 00:41:33 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:33 --> Input Class Initialized
INFO - 2017-03-16 00:41:33 --> Language Class Initialized
INFO - 2017-03-16 00:41:33 --> Loader Class Initialized
INFO - 2017-03-16 00:41:33 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:33 --> Controller Class Initialized
INFO - 2017-03-16 00:41:33 --> Helper loaded: date_helper
DEBUG - 2017-03-16 00:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:33 --> Helper loaded: url_helper
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:33 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:33 --> Total execution time: 0.0134
INFO - 2017-03-16 00:41:33 --> Config Class Initialized
INFO - 2017-03-16 00:41:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:33 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:33 --> URI Class Initialized
INFO - 2017-03-16 00:41:33 --> Router Class Initialized
INFO - 2017-03-16 00:41:33 --> Output Class Initialized
INFO - 2017-03-16 00:41:33 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:33 --> Input Class Initialized
INFO - 2017-03-16 00:41:33 --> Language Class Initialized
INFO - 2017-03-16 00:41:33 --> Loader Class Initialized
INFO - 2017-03-16 00:41:33 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:33 --> Controller Class Initialized
INFO - 2017-03-16 00:41:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:33 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:33 --> Total execution time: 0.0134
INFO - 2017-03-16 00:41:37 --> Config Class Initialized
INFO - 2017-03-16 00:41:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:37 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:37 --> URI Class Initialized
DEBUG - 2017-03-16 00:41:37 --> No URI present. Default controller set.
INFO - 2017-03-16 00:41:37 --> Router Class Initialized
INFO - 2017-03-16 00:41:37 --> Output Class Initialized
INFO - 2017-03-16 00:41:37 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:37 --> Input Class Initialized
INFO - 2017-03-16 00:41:37 --> Language Class Initialized
INFO - 2017-03-16 00:41:37 --> Loader Class Initialized
INFO - 2017-03-16 00:41:37 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:37 --> Controller Class Initialized
INFO - 2017-03-16 00:41:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:37 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:37 --> Total execution time: 0.0131
INFO - 2017-03-16 00:41:38 --> Config Class Initialized
INFO - 2017-03-16 00:41:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:41:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:41:38 --> Utf8 Class Initialized
INFO - 2017-03-16 00:41:38 --> URI Class Initialized
INFO - 2017-03-16 00:41:38 --> Router Class Initialized
INFO - 2017-03-16 00:41:38 --> Output Class Initialized
INFO - 2017-03-16 00:41:38 --> Security Class Initialized
DEBUG - 2017-03-16 00:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:41:38 --> Input Class Initialized
INFO - 2017-03-16 00:41:38 --> Language Class Initialized
INFO - 2017-03-16 00:41:38 --> Loader Class Initialized
INFO - 2017-03-16 00:41:38 --> Database Driver Class Initialized
INFO - 2017-03-16 00:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:41:38 --> Controller Class Initialized
INFO - 2017-03-16 00:41:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:41:38 --> Final output sent to browser
DEBUG - 2017-03-16 00:41:38 --> Total execution time: 0.0133
INFO - 2017-03-16 00:42:35 --> Config Class Initialized
INFO - 2017-03-16 00:42:35 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:42:35 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:42:35 --> Utf8 Class Initialized
INFO - 2017-03-16 00:42:35 --> URI Class Initialized
INFO - 2017-03-16 00:42:35 --> Router Class Initialized
INFO - 2017-03-16 00:42:35 --> Output Class Initialized
INFO - 2017-03-16 00:42:35 --> Security Class Initialized
DEBUG - 2017-03-16 00:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:42:35 --> Input Class Initialized
INFO - 2017-03-16 00:42:35 --> Language Class Initialized
INFO - 2017-03-16 00:42:35 --> Loader Class Initialized
INFO - 2017-03-16 00:42:36 --> Database Driver Class Initialized
INFO - 2017-03-16 00:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:42:36 --> Controller Class Initialized
INFO - 2017-03-16 00:42:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:42:36 --> Final output sent to browser
DEBUG - 2017-03-16 00:42:36 --> Total execution time: 1.1591
INFO - 2017-03-16 00:42:37 --> Config Class Initialized
INFO - 2017-03-16 00:42:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:42:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:42:37 --> Utf8 Class Initialized
INFO - 2017-03-16 00:42:37 --> URI Class Initialized
INFO - 2017-03-16 00:42:37 --> Router Class Initialized
INFO - 2017-03-16 00:42:37 --> Output Class Initialized
INFO - 2017-03-16 00:42:37 --> Security Class Initialized
DEBUG - 2017-03-16 00:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:42:37 --> Input Class Initialized
INFO - 2017-03-16 00:42:37 --> Language Class Initialized
INFO - 2017-03-16 00:42:37 --> Loader Class Initialized
INFO - 2017-03-16 00:42:37 --> Database Driver Class Initialized
INFO - 2017-03-16 00:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:42:37 --> Controller Class Initialized
INFO - 2017-03-16 00:42:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:42:37 --> Final output sent to browser
DEBUG - 2017-03-16 00:42:37 --> Total execution time: 0.0134
INFO - 2017-03-16 00:42:51 --> Config Class Initialized
INFO - 2017-03-16 00:42:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:42:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:42:51 --> Utf8 Class Initialized
INFO - 2017-03-16 00:42:51 --> URI Class Initialized
INFO - 2017-03-16 00:42:51 --> Router Class Initialized
INFO - 2017-03-16 00:42:51 --> Output Class Initialized
INFO - 2017-03-16 00:42:51 --> Security Class Initialized
DEBUG - 2017-03-16 00:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:42:51 --> Input Class Initialized
INFO - 2017-03-16 00:42:51 --> Language Class Initialized
INFO - 2017-03-16 00:42:51 --> Loader Class Initialized
INFO - 2017-03-16 00:42:51 --> Database Driver Class Initialized
INFO - 2017-03-16 00:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:42:51 --> Controller Class Initialized
INFO - 2017-03-16 00:42:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:42:51 --> Final output sent to browser
DEBUG - 2017-03-16 00:42:51 --> Total execution time: 0.0140
INFO - 2017-03-16 00:42:52 --> Config Class Initialized
INFO - 2017-03-16 00:42:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:42:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:42:52 --> Utf8 Class Initialized
INFO - 2017-03-16 00:42:52 --> URI Class Initialized
INFO - 2017-03-16 00:42:52 --> Router Class Initialized
INFO - 2017-03-16 00:42:52 --> Output Class Initialized
INFO - 2017-03-16 00:42:52 --> Security Class Initialized
DEBUG - 2017-03-16 00:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:42:52 --> Input Class Initialized
INFO - 2017-03-16 00:42:52 --> Language Class Initialized
INFO - 2017-03-16 00:42:52 --> Loader Class Initialized
INFO - 2017-03-16 00:42:52 --> Database Driver Class Initialized
INFO - 2017-03-16 00:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:42:52 --> Controller Class Initialized
INFO - 2017-03-16 00:42:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:42:52 --> Final output sent to browser
DEBUG - 2017-03-16 00:42:52 --> Total execution time: 0.0134
INFO - 2017-03-16 00:43:03 --> Config Class Initialized
INFO - 2017-03-16 00:43:03 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:03 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:03 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:03 --> URI Class Initialized
INFO - 2017-03-16 00:43:03 --> Router Class Initialized
INFO - 2017-03-16 00:43:03 --> Output Class Initialized
INFO - 2017-03-16 00:43:03 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:03 --> Input Class Initialized
INFO - 2017-03-16 00:43:03 --> Language Class Initialized
INFO - 2017-03-16 00:43:03 --> Loader Class Initialized
INFO - 2017-03-16 00:43:03 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:03 --> Controller Class Initialized
INFO - 2017-03-16 00:43:03 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:43:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:43:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:03 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:03 --> Total execution time: 0.0146
INFO - 2017-03-16 00:43:04 --> Config Class Initialized
INFO - 2017-03-16 00:43:04 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:04 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:04 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:04 --> URI Class Initialized
INFO - 2017-03-16 00:43:04 --> Router Class Initialized
INFO - 2017-03-16 00:43:04 --> Output Class Initialized
INFO - 2017-03-16 00:43:04 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:04 --> Input Class Initialized
INFO - 2017-03-16 00:43:04 --> Language Class Initialized
INFO - 2017-03-16 00:43:04 --> Loader Class Initialized
INFO - 2017-03-16 00:43:04 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:04 --> Controller Class Initialized
INFO - 2017-03-16 00:43:04 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:04 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:04 --> Total execution time: 0.0135
INFO - 2017-03-16 00:43:30 --> Config Class Initialized
INFO - 2017-03-16 00:43:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:30 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:30 --> URI Class Initialized
INFO - 2017-03-16 00:43:30 --> Router Class Initialized
INFO - 2017-03-16 00:43:30 --> Output Class Initialized
INFO - 2017-03-16 00:43:30 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:30 --> Input Class Initialized
INFO - 2017-03-16 00:43:30 --> Language Class Initialized
INFO - 2017-03-16 00:43:30 --> Loader Class Initialized
INFO - 2017-03-16 00:43:30 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:30 --> Controller Class Initialized
INFO - 2017-03-16 00:43:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:31 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:31 --> Total execution time: 0.7893
INFO - 2017-03-16 00:43:32 --> Config Class Initialized
INFO - 2017-03-16 00:43:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:32 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:32 --> URI Class Initialized
INFO - 2017-03-16 00:43:32 --> Router Class Initialized
INFO - 2017-03-16 00:43:32 --> Output Class Initialized
INFO - 2017-03-16 00:43:32 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:32 --> Input Class Initialized
INFO - 2017-03-16 00:43:32 --> Language Class Initialized
INFO - 2017-03-16 00:43:32 --> Loader Class Initialized
INFO - 2017-03-16 00:43:32 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:32 --> Controller Class Initialized
INFO - 2017-03-16 00:43:32 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:32 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:32 --> Total execution time: 0.0139
INFO - 2017-03-16 00:43:49 --> Config Class Initialized
INFO - 2017-03-16 00:43:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:49 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:49 --> URI Class Initialized
INFO - 2017-03-16 00:43:49 --> Router Class Initialized
INFO - 2017-03-16 00:43:49 --> Output Class Initialized
INFO - 2017-03-16 00:43:49 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:49 --> Input Class Initialized
INFO - 2017-03-16 00:43:49 --> Language Class Initialized
INFO - 2017-03-16 00:43:49 --> Loader Class Initialized
INFO - 2017-03-16 00:43:49 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:49 --> Controller Class Initialized
INFO - 2017-03-16 00:43:49 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:49 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:49 --> Total execution time: 0.0142
INFO - 2017-03-16 00:43:50 --> Config Class Initialized
INFO - 2017-03-16 00:43:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:50 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:50 --> URI Class Initialized
INFO - 2017-03-16 00:43:50 --> Router Class Initialized
INFO - 2017-03-16 00:43:50 --> Output Class Initialized
INFO - 2017-03-16 00:43:50 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:50 --> Input Class Initialized
INFO - 2017-03-16 00:43:50 --> Language Class Initialized
INFO - 2017-03-16 00:43:50 --> Loader Class Initialized
INFO - 2017-03-16 00:43:50 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:50 --> Controller Class Initialized
INFO - 2017-03-16 00:43:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:50 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:50 --> Total execution time: 0.0133
INFO - 2017-03-16 00:43:55 --> Config Class Initialized
INFO - 2017-03-16 00:43:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:55 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:55 --> URI Class Initialized
INFO - 2017-03-16 00:43:55 --> Router Class Initialized
INFO - 2017-03-16 00:43:55 --> Output Class Initialized
INFO - 2017-03-16 00:43:55 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:55 --> Input Class Initialized
INFO - 2017-03-16 00:43:55 --> Language Class Initialized
INFO - 2017-03-16 00:43:55 --> Loader Class Initialized
INFO - 2017-03-16 00:43:55 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:55 --> Controller Class Initialized
INFO - 2017-03-16 00:43:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:57 --> Config Class Initialized
INFO - 2017-03-16 00:43:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:57 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:57 --> URI Class Initialized
INFO - 2017-03-16 00:43:57 --> Router Class Initialized
INFO - 2017-03-16 00:43:57 --> Output Class Initialized
INFO - 2017-03-16 00:43:57 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:57 --> Input Class Initialized
INFO - 2017-03-16 00:43:57 --> Language Class Initialized
INFO - 2017-03-16 00:43:57 --> Loader Class Initialized
INFO - 2017-03-16 00:43:57 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:57 --> Controller Class Initialized
INFO - 2017-03-16 00:43:57 --> Helper loaded: date_helper
DEBUG - 2017-03-16 00:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:57 --> Helper loaded: url_helper
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:57 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:57 --> Total execution time: 0.0971
INFO - 2017-03-16 00:43:57 --> Config Class Initialized
INFO - 2017-03-16 00:43:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:43:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:43:57 --> Utf8 Class Initialized
INFO - 2017-03-16 00:43:57 --> URI Class Initialized
INFO - 2017-03-16 00:43:57 --> Router Class Initialized
INFO - 2017-03-16 00:43:57 --> Output Class Initialized
INFO - 2017-03-16 00:43:57 --> Security Class Initialized
DEBUG - 2017-03-16 00:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:43:57 --> Input Class Initialized
INFO - 2017-03-16 00:43:57 --> Language Class Initialized
INFO - 2017-03-16 00:43:57 --> Loader Class Initialized
INFO - 2017-03-16 00:43:57 --> Database Driver Class Initialized
INFO - 2017-03-16 00:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:43:57 --> Controller Class Initialized
INFO - 2017-03-16 00:43:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:43:57 --> Final output sent to browser
DEBUG - 2017-03-16 00:43:57 --> Total execution time: 0.0143
INFO - 2017-03-16 00:44:02 --> Config Class Initialized
INFO - 2017-03-16 00:44:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:44:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:44:02 --> Utf8 Class Initialized
INFO - 2017-03-16 00:44:02 --> URI Class Initialized
DEBUG - 2017-03-16 00:44:02 --> No URI present. Default controller set.
INFO - 2017-03-16 00:44:02 --> Router Class Initialized
INFO - 2017-03-16 00:44:02 --> Output Class Initialized
INFO - 2017-03-16 00:44:02 --> Security Class Initialized
DEBUG - 2017-03-16 00:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:44:02 --> Input Class Initialized
INFO - 2017-03-16 00:44:02 --> Language Class Initialized
INFO - 2017-03-16 00:44:02 --> Loader Class Initialized
INFO - 2017-03-16 00:44:02 --> Database Driver Class Initialized
INFO - 2017-03-16 00:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:44:02 --> Controller Class Initialized
INFO - 2017-03-16 00:44:02 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:44:02 --> Final output sent to browser
DEBUG - 2017-03-16 00:44:02 --> Total execution time: 0.0130
INFO - 2017-03-16 00:44:03 --> Config Class Initialized
INFO - 2017-03-16 00:44:03 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:44:03 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:44:03 --> Utf8 Class Initialized
INFO - 2017-03-16 00:44:03 --> URI Class Initialized
INFO - 2017-03-16 00:44:03 --> Router Class Initialized
INFO - 2017-03-16 00:44:03 --> Output Class Initialized
INFO - 2017-03-16 00:44:03 --> Security Class Initialized
DEBUG - 2017-03-16 00:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:44:03 --> Input Class Initialized
INFO - 2017-03-16 00:44:03 --> Language Class Initialized
INFO - 2017-03-16 00:44:03 --> Loader Class Initialized
INFO - 2017-03-16 00:44:03 --> Database Driver Class Initialized
INFO - 2017-03-16 00:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:44:03 --> Controller Class Initialized
INFO - 2017-03-16 00:44:03 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:44:03 --> Final output sent to browser
DEBUG - 2017-03-16 00:44:03 --> Total execution time: 0.0135
INFO - 2017-03-16 00:44:42 --> Config Class Initialized
INFO - 2017-03-16 00:44:42 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:44:42 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:44:42 --> Utf8 Class Initialized
INFO - 2017-03-16 00:44:42 --> URI Class Initialized
INFO - 2017-03-16 00:44:42 --> Router Class Initialized
INFO - 2017-03-16 00:44:42 --> Output Class Initialized
INFO - 2017-03-16 00:44:42 --> Security Class Initialized
DEBUG - 2017-03-16 00:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:44:42 --> Input Class Initialized
INFO - 2017-03-16 00:44:42 --> Language Class Initialized
INFO - 2017-03-16 00:44:42 --> Loader Class Initialized
INFO - 2017-03-16 00:44:42 --> Database Driver Class Initialized
INFO - 2017-03-16 00:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:44:42 --> Controller Class Initialized
INFO - 2017-03-16 00:44:42 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:44:42 --> Final output sent to browser
DEBUG - 2017-03-16 00:44:42 --> Total execution time: 0.2172
INFO - 2017-03-16 00:44:43 --> Config Class Initialized
INFO - 2017-03-16 00:44:43 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:44:43 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:44:43 --> Utf8 Class Initialized
INFO - 2017-03-16 00:44:43 --> URI Class Initialized
INFO - 2017-03-16 00:44:43 --> Router Class Initialized
INFO - 2017-03-16 00:44:43 --> Output Class Initialized
INFO - 2017-03-16 00:44:43 --> Security Class Initialized
DEBUG - 2017-03-16 00:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:44:43 --> Input Class Initialized
INFO - 2017-03-16 00:44:43 --> Language Class Initialized
INFO - 2017-03-16 00:44:43 --> Loader Class Initialized
INFO - 2017-03-16 00:44:43 --> Database Driver Class Initialized
INFO - 2017-03-16 00:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:44:43 --> Controller Class Initialized
INFO - 2017-03-16 00:44:43 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:44:43 --> Final output sent to browser
DEBUG - 2017-03-16 00:44:43 --> Total execution time: 0.0133
INFO - 2017-03-16 00:44:55 --> Config Class Initialized
INFO - 2017-03-16 00:44:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:44:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:44:55 --> Utf8 Class Initialized
INFO - 2017-03-16 00:44:55 --> URI Class Initialized
INFO - 2017-03-16 00:44:55 --> Router Class Initialized
INFO - 2017-03-16 00:44:55 --> Output Class Initialized
INFO - 2017-03-16 00:44:55 --> Security Class Initialized
DEBUG - 2017-03-16 00:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:44:55 --> Input Class Initialized
INFO - 2017-03-16 00:44:55 --> Language Class Initialized
INFO - 2017-03-16 00:44:55 --> Loader Class Initialized
INFO - 2017-03-16 00:44:55 --> Database Driver Class Initialized
INFO - 2017-03-16 00:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:44:55 --> Controller Class Initialized
INFO - 2017-03-16 00:44:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:44:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:44:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:44:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:44:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:44:55 --> Final output sent to browser
DEBUG - 2017-03-16 00:44:55 --> Total execution time: 0.0148
INFO - 2017-03-16 00:44:56 --> Config Class Initialized
INFO - 2017-03-16 00:44:56 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:44:56 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:44:56 --> Utf8 Class Initialized
INFO - 2017-03-16 00:44:56 --> URI Class Initialized
INFO - 2017-03-16 00:44:56 --> Router Class Initialized
INFO - 2017-03-16 00:44:56 --> Output Class Initialized
INFO - 2017-03-16 00:44:56 --> Security Class Initialized
DEBUG - 2017-03-16 00:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:44:56 --> Input Class Initialized
INFO - 2017-03-16 00:44:56 --> Language Class Initialized
INFO - 2017-03-16 00:44:56 --> Loader Class Initialized
INFO - 2017-03-16 00:44:56 --> Database Driver Class Initialized
INFO - 2017-03-16 00:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:44:56 --> Controller Class Initialized
INFO - 2017-03-16 00:44:56 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:44:56 --> Final output sent to browser
DEBUG - 2017-03-16 00:44:56 --> Total execution time: 0.0134
INFO - 2017-03-16 00:50:32 --> Config Class Initialized
INFO - 2017-03-16 00:50:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:50:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:50:32 --> Utf8 Class Initialized
INFO - 2017-03-16 00:50:32 --> URI Class Initialized
DEBUG - 2017-03-16 00:50:32 --> No URI present. Default controller set.
INFO - 2017-03-16 00:50:32 --> Router Class Initialized
INFO - 2017-03-16 00:50:33 --> Output Class Initialized
INFO - 2017-03-16 00:50:33 --> Security Class Initialized
DEBUG - 2017-03-16 00:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:50:33 --> Input Class Initialized
INFO - 2017-03-16 00:50:33 --> Language Class Initialized
INFO - 2017-03-16 00:50:33 --> Loader Class Initialized
INFO - 2017-03-16 00:50:33 --> Database Driver Class Initialized
INFO - 2017-03-16 00:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:50:33 --> Controller Class Initialized
INFO - 2017-03-16 00:50:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:50:34 --> Final output sent to browser
DEBUG - 2017-03-16 00:50:34 --> Total execution time: 1.6199
INFO - 2017-03-16 00:50:40 --> Config Class Initialized
INFO - 2017-03-16 00:50:40 --> Hooks Class Initialized
DEBUG - 2017-03-16 00:50:40 --> UTF-8 Support Enabled
INFO - 2017-03-16 00:50:40 --> Utf8 Class Initialized
INFO - 2017-03-16 00:50:40 --> URI Class Initialized
INFO - 2017-03-16 00:50:40 --> Router Class Initialized
INFO - 2017-03-16 00:50:40 --> Output Class Initialized
INFO - 2017-03-16 00:50:40 --> Security Class Initialized
DEBUG - 2017-03-16 00:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 00:50:40 --> Input Class Initialized
INFO - 2017-03-16 00:50:40 --> Language Class Initialized
INFO - 2017-03-16 00:50:40 --> Loader Class Initialized
INFO - 2017-03-16 00:50:40 --> Database Driver Class Initialized
INFO - 2017-03-16 00:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 00:50:40 --> Controller Class Initialized
INFO - 2017-03-16 00:50:40 --> Helper loaded: url_helper
DEBUG - 2017-03-16 00:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 00:50:40 --> Final output sent to browser
DEBUG - 2017-03-16 00:50:40 --> Total execution time: 0.0129
INFO - 2017-03-16 01:00:04 --> Config Class Initialized
INFO - 2017-03-16 01:00:04 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:00:04 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:00:04 --> Utf8 Class Initialized
INFO - 2017-03-16 01:00:04 --> URI Class Initialized
DEBUG - 2017-03-16 01:00:04 --> No URI present. Default controller set.
INFO - 2017-03-16 01:00:04 --> Router Class Initialized
INFO - 2017-03-16 01:00:05 --> Output Class Initialized
INFO - 2017-03-16 01:00:05 --> Security Class Initialized
DEBUG - 2017-03-16 01:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:00:05 --> Input Class Initialized
INFO - 2017-03-16 01:00:05 --> Language Class Initialized
INFO - 2017-03-16 01:00:05 --> Loader Class Initialized
INFO - 2017-03-16 01:00:05 --> Database Driver Class Initialized
INFO - 2017-03-16 01:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:00:05 --> Controller Class Initialized
INFO - 2017-03-16 01:00:05 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:00:06 --> Final output sent to browser
DEBUG - 2017-03-16 01:00:06 --> Total execution time: 1.4876
INFO - 2017-03-16 01:00:32 --> Config Class Initialized
INFO - 2017-03-16 01:00:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:00:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:00:32 --> Utf8 Class Initialized
INFO - 2017-03-16 01:00:32 --> URI Class Initialized
INFO - 2017-03-16 01:00:32 --> Router Class Initialized
INFO - 2017-03-16 01:00:32 --> Output Class Initialized
INFO - 2017-03-16 01:00:33 --> Security Class Initialized
DEBUG - 2017-03-16 01:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:00:33 --> Input Class Initialized
INFO - 2017-03-16 01:00:33 --> Language Class Initialized
INFO - 2017-03-16 01:00:33 --> Loader Class Initialized
INFO - 2017-03-16 01:00:33 --> Database Driver Class Initialized
INFO - 2017-03-16 01:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:00:33 --> Controller Class Initialized
INFO - 2017-03-16 01:00:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:00:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:00:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:00:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:00:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:00:33 --> Final output sent to browser
DEBUG - 2017-03-16 01:00:33 --> Total execution time: 1.2109
INFO - 2017-03-16 01:00:49 --> Config Class Initialized
INFO - 2017-03-16 01:00:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:00:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:00:49 --> Utf8 Class Initialized
INFO - 2017-03-16 01:00:49 --> URI Class Initialized
INFO - 2017-03-16 01:00:49 --> Router Class Initialized
INFO - 2017-03-16 01:00:49 --> Output Class Initialized
INFO - 2017-03-16 01:00:49 --> Security Class Initialized
DEBUG - 2017-03-16 01:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:00:49 --> Input Class Initialized
INFO - 2017-03-16 01:00:49 --> Language Class Initialized
INFO - 2017-03-16 01:00:49 --> Loader Class Initialized
INFO - 2017-03-16 01:00:49 --> Database Driver Class Initialized
INFO - 2017-03-16 01:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:00:49 --> Controller Class Initialized
INFO - 2017-03-16 01:00:49 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:00:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 01:00:51 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 01:00:51 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Susana Casas')
INFO - 2017-03-16 01:00:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 01:00:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 01:00:51 --> Config Class Initialized
INFO - 2017-03-16 01:00:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:00:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:00:51 --> Utf8 Class Initialized
INFO - 2017-03-16 01:00:51 --> URI Class Initialized
INFO - 2017-03-16 01:00:51 --> Router Class Initialized
INFO - 2017-03-16 01:00:51 --> Output Class Initialized
INFO - 2017-03-16 01:00:51 --> Security Class Initialized
DEBUG - 2017-03-16 01:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:00:51 --> Input Class Initialized
INFO - 2017-03-16 01:00:51 --> Language Class Initialized
INFO - 2017-03-16 01:00:51 --> Loader Class Initialized
INFO - 2017-03-16 01:00:52 --> Database Driver Class Initialized
INFO - 2017-03-16 01:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:00:52 --> Controller Class Initialized
INFO - 2017-03-16 01:00:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:00:52 --> Final output sent to browser
DEBUG - 2017-03-16 01:00:52 --> Total execution time: 0.3668
INFO - 2017-03-16 01:00:58 --> Config Class Initialized
INFO - 2017-03-16 01:00:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:00:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:00:58 --> Utf8 Class Initialized
INFO - 2017-03-16 01:00:58 --> URI Class Initialized
DEBUG - 2017-03-16 01:00:58 --> No URI present. Default controller set.
INFO - 2017-03-16 01:00:58 --> Router Class Initialized
INFO - 2017-03-16 01:00:58 --> Output Class Initialized
INFO - 2017-03-16 01:00:58 --> Security Class Initialized
DEBUG - 2017-03-16 01:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:00:58 --> Input Class Initialized
INFO - 2017-03-16 01:00:58 --> Language Class Initialized
INFO - 2017-03-16 01:00:58 --> Loader Class Initialized
INFO - 2017-03-16 01:00:58 --> Database Driver Class Initialized
INFO - 2017-03-16 01:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:00:58 --> Controller Class Initialized
INFO - 2017-03-16 01:00:58 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:00:58 --> Final output sent to browser
DEBUG - 2017-03-16 01:00:58 --> Total execution time: 0.0127
INFO - 2017-03-16 01:01:02 --> Config Class Initialized
INFO - 2017-03-16 01:01:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:01:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:01:02 --> Utf8 Class Initialized
INFO - 2017-03-16 01:01:02 --> URI Class Initialized
INFO - 2017-03-16 01:01:02 --> Router Class Initialized
INFO - 2017-03-16 01:01:02 --> Output Class Initialized
INFO - 2017-03-16 01:01:02 --> Security Class Initialized
DEBUG - 2017-03-16 01:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:01:02 --> Input Class Initialized
INFO - 2017-03-16 01:01:02 --> Language Class Initialized
INFO - 2017-03-16 01:01:02 --> Loader Class Initialized
INFO - 2017-03-16 01:01:02 --> Database Driver Class Initialized
INFO - 2017-03-16 01:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:01:02 --> Controller Class Initialized
INFO - 2017-03-16 01:01:02 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:01:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:01:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:01:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:01:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:01:02 --> Final output sent to browser
DEBUG - 2017-03-16 01:01:02 --> Total execution time: 0.0846
INFO - 2017-03-16 01:02:20 --> Config Class Initialized
INFO - 2017-03-16 01:02:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:02:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:02:21 --> Utf8 Class Initialized
INFO - 2017-03-16 01:02:21 --> URI Class Initialized
INFO - 2017-03-16 01:02:21 --> Router Class Initialized
INFO - 2017-03-16 01:02:21 --> Output Class Initialized
INFO - 2017-03-16 01:02:21 --> Security Class Initialized
DEBUG - 2017-03-16 01:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:02:21 --> Input Class Initialized
INFO - 2017-03-16 01:02:21 --> Language Class Initialized
INFO - 2017-03-16 01:02:21 --> Loader Class Initialized
INFO - 2017-03-16 01:02:21 --> Database Driver Class Initialized
INFO - 2017-03-16 01:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:02:21 --> Controller Class Initialized
INFO - 2017-03-16 01:02:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:02:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:02:22 --> Config Class Initialized
INFO - 2017-03-16 01:02:22 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:02:22 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:02:22 --> Utf8 Class Initialized
INFO - 2017-03-16 01:02:22 --> URI Class Initialized
INFO - 2017-03-16 01:02:22 --> Router Class Initialized
INFO - 2017-03-16 01:02:22 --> Output Class Initialized
INFO - 2017-03-16 01:02:22 --> Security Class Initialized
DEBUG - 2017-03-16 01:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:02:22 --> Input Class Initialized
INFO - 2017-03-16 01:02:22 --> Language Class Initialized
INFO - 2017-03-16 01:02:22 --> Loader Class Initialized
INFO - 2017-03-16 01:02:22 --> Database Driver Class Initialized
INFO - 2017-03-16 01:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:02:22 --> Controller Class Initialized
INFO - 2017-03-16 01:02:22 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:02:22 --> Helper loaded: url_helper
INFO - 2017-03-16 01:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:02:22 --> Final output sent to browser
DEBUG - 2017-03-16 01:02:22 --> Total execution time: 0.1118
INFO - 2017-03-16 01:02:24 --> Config Class Initialized
INFO - 2017-03-16 01:02:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:02:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:02:24 --> Utf8 Class Initialized
INFO - 2017-03-16 01:02:24 --> URI Class Initialized
INFO - 2017-03-16 01:02:24 --> Router Class Initialized
INFO - 2017-03-16 01:02:24 --> Output Class Initialized
INFO - 2017-03-16 01:02:24 --> Security Class Initialized
DEBUG - 2017-03-16 01:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:02:24 --> Input Class Initialized
INFO - 2017-03-16 01:02:24 --> Language Class Initialized
INFO - 2017-03-16 01:02:24 --> Loader Class Initialized
INFO - 2017-03-16 01:02:24 --> Database Driver Class Initialized
INFO - 2017-03-16 01:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:02:24 --> Controller Class Initialized
INFO - 2017-03-16 01:02:24 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:02:24 --> Final output sent to browser
DEBUG - 2017-03-16 01:02:24 --> Total execution time: 0.0348
INFO - 2017-03-16 01:02:32 --> Config Class Initialized
INFO - 2017-03-16 01:02:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:02:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:02:32 --> Utf8 Class Initialized
INFO - 2017-03-16 01:02:32 --> URI Class Initialized
DEBUG - 2017-03-16 01:02:32 --> No URI present. Default controller set.
INFO - 2017-03-16 01:02:32 --> Router Class Initialized
INFO - 2017-03-16 01:02:32 --> Output Class Initialized
INFO - 2017-03-16 01:02:32 --> Security Class Initialized
DEBUG - 2017-03-16 01:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:02:32 --> Input Class Initialized
INFO - 2017-03-16 01:02:32 --> Language Class Initialized
INFO - 2017-03-16 01:02:32 --> Loader Class Initialized
INFO - 2017-03-16 01:02:32 --> Database Driver Class Initialized
INFO - 2017-03-16 01:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:02:32 --> Controller Class Initialized
INFO - 2017-03-16 01:02:32 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:02:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:02:32 --> Final output sent to browser
DEBUG - 2017-03-16 01:02:32 --> Total execution time: 0.0136
INFO - 2017-03-16 01:02:34 --> Config Class Initialized
INFO - 2017-03-16 01:02:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:02:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:02:34 --> Utf8 Class Initialized
INFO - 2017-03-16 01:02:34 --> URI Class Initialized
INFO - 2017-03-16 01:02:34 --> Router Class Initialized
INFO - 2017-03-16 01:02:34 --> Output Class Initialized
INFO - 2017-03-16 01:02:34 --> Security Class Initialized
DEBUG - 2017-03-16 01:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:02:34 --> Input Class Initialized
INFO - 2017-03-16 01:02:34 --> Language Class Initialized
INFO - 2017-03-16 01:02:34 --> Loader Class Initialized
INFO - 2017-03-16 01:02:34 --> Database Driver Class Initialized
INFO - 2017-03-16 01:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:02:34 --> Controller Class Initialized
INFO - 2017-03-16 01:02:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:02:34 --> Final output sent to browser
DEBUG - 2017-03-16 01:02:34 --> Total execution time: 0.0133
INFO - 2017-03-16 01:03:06 --> Config Class Initialized
INFO - 2017-03-16 01:03:06 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:06 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:06 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:06 --> URI Class Initialized
INFO - 2017-03-16 01:03:06 --> Router Class Initialized
INFO - 2017-03-16 01:03:06 --> Output Class Initialized
INFO - 2017-03-16 01:03:06 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:06 --> Input Class Initialized
INFO - 2017-03-16 01:03:06 --> Language Class Initialized
INFO - 2017-03-16 01:03:06 --> Loader Class Initialized
INFO - 2017-03-16 01:03:06 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:06 --> Controller Class Initialized
INFO - 2017-03-16 01:03:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:07 --> Config Class Initialized
INFO - 2017-03-16 01:03:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:07 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:07 --> URI Class Initialized
INFO - 2017-03-16 01:03:07 --> Router Class Initialized
INFO - 2017-03-16 01:03:07 --> Output Class Initialized
INFO - 2017-03-16 01:03:07 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:07 --> Input Class Initialized
INFO - 2017-03-16 01:03:07 --> Language Class Initialized
INFO - 2017-03-16 01:03:07 --> Loader Class Initialized
INFO - 2017-03-16 01:03:07 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:08 --> Controller Class Initialized
INFO - 2017-03-16 01:03:08 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:08 --> Helper loaded: url_helper
INFO - 2017-03-16 01:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:08 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:08 --> Total execution time: 0.3161
INFO - 2017-03-16 01:03:09 --> Config Class Initialized
INFO - 2017-03-16 01:03:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:09 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:09 --> URI Class Initialized
INFO - 2017-03-16 01:03:09 --> Router Class Initialized
INFO - 2017-03-16 01:03:09 --> Output Class Initialized
INFO - 2017-03-16 01:03:09 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:09 --> Input Class Initialized
INFO - 2017-03-16 01:03:09 --> Language Class Initialized
INFO - 2017-03-16 01:03:09 --> Loader Class Initialized
INFO - 2017-03-16 01:03:09 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:09 --> Controller Class Initialized
INFO - 2017-03-16 01:03:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:09 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:09 --> Total execution time: 0.0613
INFO - 2017-03-16 01:03:14 --> Config Class Initialized
INFO - 2017-03-16 01:03:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:14 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:14 --> URI Class Initialized
DEBUG - 2017-03-16 01:03:14 --> No URI present. Default controller set.
INFO - 2017-03-16 01:03:14 --> Router Class Initialized
INFO - 2017-03-16 01:03:14 --> Output Class Initialized
INFO - 2017-03-16 01:03:14 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:14 --> Input Class Initialized
INFO - 2017-03-16 01:03:14 --> Language Class Initialized
INFO - 2017-03-16 01:03:14 --> Loader Class Initialized
INFO - 2017-03-16 01:03:14 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:14 --> Controller Class Initialized
INFO - 2017-03-16 01:03:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:14 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:14 --> Total execution time: 0.0131
INFO - 2017-03-16 01:03:21 --> Config Class Initialized
INFO - 2017-03-16 01:03:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:21 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:21 --> URI Class Initialized
INFO - 2017-03-16 01:03:21 --> Router Class Initialized
INFO - 2017-03-16 01:03:21 --> Output Class Initialized
INFO - 2017-03-16 01:03:21 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:21 --> Input Class Initialized
INFO - 2017-03-16 01:03:21 --> Language Class Initialized
INFO - 2017-03-16 01:03:21 --> Loader Class Initialized
INFO - 2017-03-16 01:03:21 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:21 --> Controller Class Initialized
INFO - 2017-03-16 01:03:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:21 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:21 --> Total execution time: 0.2977
INFO - 2017-03-16 01:03:24 --> Config Class Initialized
INFO - 2017-03-16 01:03:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:24 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:24 --> URI Class Initialized
INFO - 2017-03-16 01:03:24 --> Router Class Initialized
INFO - 2017-03-16 01:03:24 --> Output Class Initialized
INFO - 2017-03-16 01:03:24 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:24 --> Input Class Initialized
INFO - 2017-03-16 01:03:24 --> Language Class Initialized
INFO - 2017-03-16 01:03:24 --> Loader Class Initialized
INFO - 2017-03-16 01:03:24 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:24 --> Controller Class Initialized
INFO - 2017-03-16 01:03:24 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:24 --> Helper loaded: url_helper
INFO - 2017-03-16 01:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:24 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:24 --> Total execution time: 0.0294
INFO - 2017-03-16 01:03:25 --> Config Class Initialized
INFO - 2017-03-16 01:03:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:25 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:25 --> URI Class Initialized
INFO - 2017-03-16 01:03:25 --> Router Class Initialized
INFO - 2017-03-16 01:03:25 --> Output Class Initialized
INFO - 2017-03-16 01:03:25 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:25 --> Input Class Initialized
INFO - 2017-03-16 01:03:25 --> Language Class Initialized
INFO - 2017-03-16 01:03:25 --> Loader Class Initialized
INFO - 2017-03-16 01:03:25 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:25 --> Controller Class Initialized
INFO - 2017-03-16 01:03:25 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:25 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:25 --> Total execution time: 0.0130
INFO - 2017-03-16 01:03:30 --> Config Class Initialized
INFO - 2017-03-16 01:03:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:30 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:30 --> URI Class Initialized
INFO - 2017-03-16 01:03:30 --> Router Class Initialized
INFO - 2017-03-16 01:03:30 --> Output Class Initialized
INFO - 2017-03-16 01:03:30 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:30 --> Input Class Initialized
INFO - 2017-03-16 01:03:30 --> Language Class Initialized
INFO - 2017-03-16 01:03:30 --> Loader Class Initialized
INFO - 2017-03-16 01:03:30 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:30 --> Controller Class Initialized
INFO - 2017-03-16 01:03:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:30 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:30 --> Total execution time: 0.4615
INFO - 2017-03-16 01:03:34 --> Config Class Initialized
INFO - 2017-03-16 01:03:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:03:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:03:34 --> Utf8 Class Initialized
INFO - 2017-03-16 01:03:34 --> URI Class Initialized
INFO - 2017-03-16 01:03:34 --> Router Class Initialized
INFO - 2017-03-16 01:03:34 --> Output Class Initialized
INFO - 2017-03-16 01:03:34 --> Security Class Initialized
DEBUG - 2017-03-16 01:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:03:34 --> Input Class Initialized
INFO - 2017-03-16 01:03:34 --> Language Class Initialized
INFO - 2017-03-16 01:03:34 --> Loader Class Initialized
INFO - 2017-03-16 01:03:34 --> Database Driver Class Initialized
INFO - 2017-03-16 01:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:03:34 --> Controller Class Initialized
INFO - 2017-03-16 01:03:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:03:34 --> Final output sent to browser
DEBUG - 2017-03-16 01:03:34 --> Total execution time: 0.0132
INFO - 2017-03-16 01:46:50 --> Config Class Initialized
INFO - 2017-03-16 01:46:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:46:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:46:50 --> Utf8 Class Initialized
INFO - 2017-03-16 01:46:50 --> URI Class Initialized
DEBUG - 2017-03-16 01:46:50 --> No URI present. Default controller set.
INFO - 2017-03-16 01:46:50 --> Router Class Initialized
INFO - 2017-03-16 01:46:50 --> Output Class Initialized
INFO - 2017-03-16 01:46:50 --> Security Class Initialized
DEBUG - 2017-03-16 01:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:46:50 --> Input Class Initialized
INFO - 2017-03-16 01:46:50 --> Language Class Initialized
INFO - 2017-03-16 01:46:51 --> Loader Class Initialized
INFO - 2017-03-16 01:46:51 --> Database Driver Class Initialized
INFO - 2017-03-16 01:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:46:51 --> Controller Class Initialized
INFO - 2017-03-16 01:46:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:46:52 --> Final output sent to browser
DEBUG - 2017-03-16 01:46:52 --> Total execution time: 1.4747
INFO - 2017-03-16 01:46:57 --> Config Class Initialized
INFO - 2017-03-16 01:46:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:46:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:46:57 --> Utf8 Class Initialized
INFO - 2017-03-16 01:46:57 --> URI Class Initialized
INFO - 2017-03-16 01:46:57 --> Router Class Initialized
INFO - 2017-03-16 01:46:57 --> Output Class Initialized
INFO - 2017-03-16 01:46:57 --> Security Class Initialized
DEBUG - 2017-03-16 01:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:46:57 --> Input Class Initialized
INFO - 2017-03-16 01:46:57 --> Language Class Initialized
INFO - 2017-03-16 01:46:57 --> Loader Class Initialized
INFO - 2017-03-16 01:46:57 --> Database Driver Class Initialized
INFO - 2017-03-16 01:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:46:57 --> Controller Class Initialized
INFO - 2017-03-16 01:46:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:46:57 --> Final output sent to browser
DEBUG - 2017-03-16 01:46:57 --> Total execution time: 0.0132
INFO - 2017-03-16 01:47:08 --> Config Class Initialized
INFO - 2017-03-16 01:47:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:47:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:47:08 --> Utf8 Class Initialized
INFO - 2017-03-16 01:47:08 --> URI Class Initialized
INFO - 2017-03-16 01:47:08 --> Router Class Initialized
INFO - 2017-03-16 01:47:08 --> Output Class Initialized
INFO - 2017-03-16 01:47:08 --> Security Class Initialized
DEBUG - 2017-03-16 01:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:47:08 --> Input Class Initialized
INFO - 2017-03-16 01:47:08 --> Language Class Initialized
INFO - 2017-03-16 01:47:08 --> Loader Class Initialized
INFO - 2017-03-16 01:47:08 --> Database Driver Class Initialized
INFO - 2017-03-16 01:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:47:08 --> Controller Class Initialized
INFO - 2017-03-16 01:47:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:47:09 --> Config Class Initialized
INFO - 2017-03-16 01:47:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:47:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:47:09 --> Utf8 Class Initialized
INFO - 2017-03-16 01:47:09 --> URI Class Initialized
INFO - 2017-03-16 01:47:09 --> Router Class Initialized
INFO - 2017-03-16 01:47:09 --> Output Class Initialized
INFO - 2017-03-16 01:47:09 --> Security Class Initialized
DEBUG - 2017-03-16 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:47:09 --> Input Class Initialized
INFO - 2017-03-16 01:47:09 --> Language Class Initialized
INFO - 2017-03-16 01:47:09 --> Loader Class Initialized
INFO - 2017-03-16 01:47:09 --> Database Driver Class Initialized
INFO - 2017-03-16 01:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:47:09 --> Controller Class Initialized
INFO - 2017-03-16 01:47:09 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:47:10 --> Helper loaded: url_helper
INFO - 2017-03-16 01:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-16 01:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-16 01:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:47:10 --> Final output sent to browser
DEBUG - 2017-03-16 01:47:10 --> Total execution time: 0.1188
INFO - 2017-03-16 01:47:11 --> Config Class Initialized
INFO - 2017-03-16 01:47:11 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:47:11 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:47:11 --> Utf8 Class Initialized
INFO - 2017-03-16 01:47:11 --> URI Class Initialized
INFO - 2017-03-16 01:47:11 --> Router Class Initialized
INFO - 2017-03-16 01:47:11 --> Output Class Initialized
INFO - 2017-03-16 01:47:11 --> Security Class Initialized
DEBUG - 2017-03-16 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:47:11 --> Input Class Initialized
INFO - 2017-03-16 01:47:11 --> Language Class Initialized
INFO - 2017-03-16 01:47:11 --> Loader Class Initialized
INFO - 2017-03-16 01:47:11 --> Database Driver Class Initialized
INFO - 2017-03-16 01:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:47:11 --> Controller Class Initialized
INFO - 2017-03-16 01:47:11 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:47:11 --> Final output sent to browser
DEBUG - 2017-03-16 01:47:11 --> Total execution time: 0.0136
INFO - 2017-03-16 01:48:53 --> Config Class Initialized
INFO - 2017-03-16 01:48:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:48:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:48:53 --> Utf8 Class Initialized
INFO - 2017-03-16 01:48:53 --> URI Class Initialized
DEBUG - 2017-03-16 01:48:54 --> No URI present. Default controller set.
INFO - 2017-03-16 01:48:54 --> Router Class Initialized
INFO - 2017-03-16 01:48:54 --> Output Class Initialized
INFO - 2017-03-16 01:48:54 --> Security Class Initialized
DEBUG - 2017-03-16 01:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:48:54 --> Input Class Initialized
INFO - 2017-03-16 01:48:54 --> Language Class Initialized
INFO - 2017-03-16 01:48:54 --> Loader Class Initialized
INFO - 2017-03-16 01:48:54 --> Database Driver Class Initialized
INFO - 2017-03-16 01:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:48:54 --> Controller Class Initialized
INFO - 2017-03-16 01:48:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:48:55 --> Final output sent to browser
DEBUG - 2017-03-16 01:48:55 --> Total execution time: 1.2138
INFO - 2017-03-16 01:49:41 --> Config Class Initialized
INFO - 2017-03-16 01:49:41 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:49:41 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:49:41 --> Utf8 Class Initialized
INFO - 2017-03-16 01:49:41 --> URI Class Initialized
DEBUG - 2017-03-16 01:49:41 --> No URI present. Default controller set.
INFO - 2017-03-16 01:49:41 --> Router Class Initialized
INFO - 2017-03-16 01:49:41 --> Output Class Initialized
INFO - 2017-03-16 01:49:41 --> Security Class Initialized
DEBUG - 2017-03-16 01:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:49:41 --> Input Class Initialized
INFO - 2017-03-16 01:49:41 --> Language Class Initialized
INFO - 2017-03-16 01:49:41 --> Loader Class Initialized
INFO - 2017-03-16 01:49:41 --> Database Driver Class Initialized
INFO - 2017-03-16 01:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:49:42 --> Controller Class Initialized
INFO - 2017-03-16 01:49:42 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:49:42 --> Final output sent to browser
DEBUG - 2017-03-16 01:49:42 --> Total execution time: 0.2826
INFO - 2017-03-16 01:49:51 --> Config Class Initialized
INFO - 2017-03-16 01:49:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:49:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:49:51 --> Utf8 Class Initialized
INFO - 2017-03-16 01:49:51 --> URI Class Initialized
INFO - 2017-03-16 01:49:51 --> Router Class Initialized
INFO - 2017-03-16 01:49:51 --> Output Class Initialized
INFO - 2017-03-16 01:49:51 --> Security Class Initialized
DEBUG - 2017-03-16 01:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:49:51 --> Input Class Initialized
INFO - 2017-03-16 01:49:51 --> Language Class Initialized
INFO - 2017-03-16 01:49:51 --> Loader Class Initialized
INFO - 2017-03-16 01:49:51 --> Database Driver Class Initialized
INFO - 2017-03-16 01:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:49:51 --> Controller Class Initialized
INFO - 2017-03-16 01:49:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:49:51 --> Final output sent to browser
DEBUG - 2017-03-16 01:49:51 --> Total execution time: 0.0134
INFO - 2017-03-16 01:49:57 --> Config Class Initialized
INFO - 2017-03-16 01:49:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:49:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:49:57 --> Utf8 Class Initialized
INFO - 2017-03-16 01:49:57 --> URI Class Initialized
DEBUG - 2017-03-16 01:49:57 --> No URI present. Default controller set.
INFO - 2017-03-16 01:49:57 --> Router Class Initialized
INFO - 2017-03-16 01:49:57 --> Output Class Initialized
INFO - 2017-03-16 01:49:57 --> Security Class Initialized
DEBUG - 2017-03-16 01:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:49:57 --> Input Class Initialized
INFO - 2017-03-16 01:49:57 --> Language Class Initialized
INFO - 2017-03-16 01:49:57 --> Loader Class Initialized
INFO - 2017-03-16 01:49:57 --> Database Driver Class Initialized
INFO - 2017-03-16 01:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:49:57 --> Controller Class Initialized
INFO - 2017-03-16 01:49:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:49:57 --> Final output sent to browser
DEBUG - 2017-03-16 01:49:57 --> Total execution time: 0.0135
INFO - 2017-03-16 01:49:58 --> Config Class Initialized
INFO - 2017-03-16 01:49:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:49:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:49:58 --> Utf8 Class Initialized
INFO - 2017-03-16 01:49:58 --> URI Class Initialized
INFO - 2017-03-16 01:49:58 --> Router Class Initialized
INFO - 2017-03-16 01:49:58 --> Output Class Initialized
INFO - 2017-03-16 01:49:58 --> Security Class Initialized
DEBUG - 2017-03-16 01:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:49:58 --> Input Class Initialized
INFO - 2017-03-16 01:49:58 --> Language Class Initialized
INFO - 2017-03-16 01:49:58 --> Loader Class Initialized
INFO - 2017-03-16 01:49:58 --> Database Driver Class Initialized
INFO - 2017-03-16 01:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:49:58 --> Controller Class Initialized
INFO - 2017-03-16 01:49:58 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:49:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:49:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:49:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:49:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:49:58 --> Final output sent to browser
DEBUG - 2017-03-16 01:49:58 --> Total execution time: 0.0182
INFO - 2017-03-16 01:50:10 --> Config Class Initialized
INFO - 2017-03-16 01:50:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:50:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:50:10 --> Utf8 Class Initialized
INFO - 2017-03-16 01:50:10 --> URI Class Initialized
INFO - 2017-03-16 01:50:10 --> Router Class Initialized
INFO - 2017-03-16 01:50:10 --> Output Class Initialized
INFO - 2017-03-16 01:50:10 --> Security Class Initialized
DEBUG - 2017-03-16 01:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:50:10 --> Input Class Initialized
INFO - 2017-03-16 01:50:10 --> Language Class Initialized
INFO - 2017-03-16 01:50:10 --> Loader Class Initialized
INFO - 2017-03-16 01:50:10 --> Database Driver Class Initialized
INFO - 2017-03-16 01:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:50:10 --> Controller Class Initialized
INFO - 2017-03-16 01:50:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:50:12 --> Config Class Initialized
INFO - 2017-03-16 01:50:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:50:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:50:12 --> Utf8 Class Initialized
INFO - 2017-03-16 01:50:12 --> URI Class Initialized
INFO - 2017-03-16 01:50:12 --> Router Class Initialized
INFO - 2017-03-16 01:50:12 --> Output Class Initialized
INFO - 2017-03-16 01:50:12 --> Security Class Initialized
DEBUG - 2017-03-16 01:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:50:12 --> Input Class Initialized
INFO - 2017-03-16 01:50:12 --> Language Class Initialized
INFO - 2017-03-16 01:50:12 --> Loader Class Initialized
INFO - 2017-03-16 01:50:12 --> Database Driver Class Initialized
INFO - 2017-03-16 01:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:50:12 --> Controller Class Initialized
INFO - 2017-03-16 01:50:12 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:50:12 --> Helper loaded: url_helper
INFO - 2017-03-16 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:50:12 --> Final output sent to browser
DEBUG - 2017-03-16 01:50:12 --> Total execution time: 0.0903
INFO - 2017-03-16 01:50:13 --> Config Class Initialized
INFO - 2017-03-16 01:50:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:50:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:50:13 --> Utf8 Class Initialized
INFO - 2017-03-16 01:50:13 --> URI Class Initialized
INFO - 2017-03-16 01:50:13 --> Router Class Initialized
INFO - 2017-03-16 01:50:13 --> Output Class Initialized
INFO - 2017-03-16 01:50:13 --> Security Class Initialized
DEBUG - 2017-03-16 01:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:50:13 --> Input Class Initialized
INFO - 2017-03-16 01:50:13 --> Language Class Initialized
INFO - 2017-03-16 01:50:13 --> Loader Class Initialized
INFO - 2017-03-16 01:50:13 --> Database Driver Class Initialized
INFO - 2017-03-16 01:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:50:13 --> Controller Class Initialized
INFO - 2017-03-16 01:50:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:50:13 --> Final output sent to browser
DEBUG - 2017-03-16 01:50:13 --> Total execution time: 0.0140
INFO - 2017-03-16 01:50:26 --> Config Class Initialized
INFO - 2017-03-16 01:50:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:50:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:50:26 --> Utf8 Class Initialized
INFO - 2017-03-16 01:50:26 --> URI Class Initialized
DEBUG - 2017-03-16 01:50:26 --> No URI present. Default controller set.
INFO - 2017-03-16 01:50:26 --> Router Class Initialized
INFO - 2017-03-16 01:50:26 --> Output Class Initialized
INFO - 2017-03-16 01:50:26 --> Security Class Initialized
DEBUG - 2017-03-16 01:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:50:26 --> Input Class Initialized
INFO - 2017-03-16 01:50:26 --> Language Class Initialized
INFO - 2017-03-16 01:50:26 --> Loader Class Initialized
INFO - 2017-03-16 01:50:26 --> Database Driver Class Initialized
INFO - 2017-03-16 01:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:50:26 --> Controller Class Initialized
INFO - 2017-03-16 01:50:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:50:26 --> Final output sent to browser
DEBUG - 2017-03-16 01:50:26 --> Total execution time: 0.0132
INFO - 2017-03-16 01:50:27 --> Config Class Initialized
INFO - 2017-03-16 01:50:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:50:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:50:27 --> Utf8 Class Initialized
INFO - 2017-03-16 01:50:27 --> URI Class Initialized
INFO - 2017-03-16 01:50:27 --> Router Class Initialized
INFO - 2017-03-16 01:50:27 --> Output Class Initialized
INFO - 2017-03-16 01:50:27 --> Security Class Initialized
DEBUG - 2017-03-16 01:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:50:27 --> Input Class Initialized
INFO - 2017-03-16 01:50:27 --> Language Class Initialized
INFO - 2017-03-16 01:50:27 --> Loader Class Initialized
INFO - 2017-03-16 01:50:27 --> Database Driver Class Initialized
INFO - 2017-03-16 01:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:50:27 --> Controller Class Initialized
INFO - 2017-03-16 01:50:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:50:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:50:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:50:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:50:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:50:27 --> Final output sent to browser
DEBUG - 2017-03-16 01:50:27 --> Total execution time: 0.0137
INFO - 2017-03-16 01:51:57 --> Config Class Initialized
INFO - 2017-03-16 01:51:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:51:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:51:57 --> Utf8 Class Initialized
INFO - 2017-03-16 01:51:57 --> URI Class Initialized
DEBUG - 2017-03-16 01:51:57 --> No URI present. Default controller set.
INFO - 2017-03-16 01:51:57 --> Router Class Initialized
INFO - 2017-03-16 01:51:57 --> Output Class Initialized
INFO - 2017-03-16 01:51:57 --> Security Class Initialized
DEBUG - 2017-03-16 01:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:51:57 --> Input Class Initialized
INFO - 2017-03-16 01:51:57 --> Language Class Initialized
INFO - 2017-03-16 01:51:57 --> Loader Class Initialized
INFO - 2017-03-16 01:51:58 --> Database Driver Class Initialized
INFO - 2017-03-16 01:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:51:58 --> Controller Class Initialized
INFO - 2017-03-16 01:51:58 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:51:58 --> Final output sent to browser
DEBUG - 2017-03-16 01:51:58 --> Total execution time: 0.7358
INFO - 2017-03-16 01:52:02 --> Config Class Initialized
INFO - 2017-03-16 01:52:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:02 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:02 --> URI Class Initialized
INFO - 2017-03-16 01:52:02 --> Router Class Initialized
INFO - 2017-03-16 01:52:02 --> Output Class Initialized
INFO - 2017-03-16 01:52:02 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:02 --> Input Class Initialized
INFO - 2017-03-16 01:52:02 --> Language Class Initialized
INFO - 2017-03-16 01:52:02 --> Loader Class Initialized
INFO - 2017-03-16 01:52:02 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:02 --> Controller Class Initialized
INFO - 2017-03-16 01:52:02 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:02 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:02 --> Total execution time: 0.0135
INFO - 2017-03-16 01:52:25 --> Config Class Initialized
INFO - 2017-03-16 01:52:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:25 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:25 --> URI Class Initialized
INFO - 2017-03-16 01:52:25 --> Router Class Initialized
INFO - 2017-03-16 01:52:25 --> Output Class Initialized
INFO - 2017-03-16 01:52:25 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:25 --> Input Class Initialized
INFO - 2017-03-16 01:52:25 --> Language Class Initialized
INFO - 2017-03-16 01:52:25 --> Loader Class Initialized
INFO - 2017-03-16 01:52:25 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:25 --> Controller Class Initialized
INFO - 2017-03-16 01:52:25 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:25 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:25 --> Total execution time: 0.0140
INFO - 2017-03-16 01:52:28 --> Config Class Initialized
INFO - 2017-03-16 01:52:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:28 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:28 --> URI Class Initialized
INFO - 2017-03-16 01:52:28 --> Router Class Initialized
INFO - 2017-03-16 01:52:28 --> Output Class Initialized
INFO - 2017-03-16 01:52:28 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:28 --> Input Class Initialized
INFO - 2017-03-16 01:52:28 --> Language Class Initialized
INFO - 2017-03-16 01:52:28 --> Loader Class Initialized
INFO - 2017-03-16 01:52:28 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:28 --> Controller Class Initialized
INFO - 2017-03-16 01:52:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:28 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:28 --> Total execution time: 0.0131
INFO - 2017-03-16 01:52:39 --> Config Class Initialized
INFO - 2017-03-16 01:52:39 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:39 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:39 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:39 --> URI Class Initialized
INFO - 2017-03-16 01:52:39 --> Router Class Initialized
INFO - 2017-03-16 01:52:39 --> Output Class Initialized
INFO - 2017-03-16 01:52:39 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:39 --> Input Class Initialized
INFO - 2017-03-16 01:52:39 --> Language Class Initialized
INFO - 2017-03-16 01:52:39 --> Loader Class Initialized
INFO - 2017-03-16 01:52:39 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:39 --> Controller Class Initialized
INFO - 2017-03-16 01:52:39 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:39 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:39 --> Total execution time: 0.0346
INFO - 2017-03-16 01:52:41 --> Config Class Initialized
INFO - 2017-03-16 01:52:41 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:41 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:41 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:41 --> URI Class Initialized
INFO - 2017-03-16 01:52:41 --> Router Class Initialized
INFO - 2017-03-16 01:52:41 --> Output Class Initialized
INFO - 2017-03-16 01:52:41 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:41 --> Input Class Initialized
INFO - 2017-03-16 01:52:41 --> Language Class Initialized
INFO - 2017-03-16 01:52:41 --> Loader Class Initialized
INFO - 2017-03-16 01:52:41 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:41 --> Controller Class Initialized
INFO - 2017-03-16 01:52:41 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:41 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:41 --> Total execution time: 0.0136
INFO - 2017-03-16 01:52:50 --> Config Class Initialized
INFO - 2017-03-16 01:52:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:50 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:50 --> URI Class Initialized
DEBUG - 2017-03-16 01:52:50 --> No URI present. Default controller set.
INFO - 2017-03-16 01:52:50 --> Router Class Initialized
INFO - 2017-03-16 01:52:50 --> Output Class Initialized
INFO - 2017-03-16 01:52:50 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:50 --> Input Class Initialized
INFO - 2017-03-16 01:52:50 --> Language Class Initialized
INFO - 2017-03-16 01:52:50 --> Loader Class Initialized
INFO - 2017-03-16 01:52:50 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:51 --> Controller Class Initialized
INFO - 2017-03-16 01:52:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:51 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:51 --> Total execution time: 0.1796
INFO - 2017-03-16 01:52:52 --> Config Class Initialized
INFO - 2017-03-16 01:52:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:52 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:52 --> URI Class Initialized
INFO - 2017-03-16 01:52:52 --> Router Class Initialized
INFO - 2017-03-16 01:52:52 --> Output Class Initialized
INFO - 2017-03-16 01:52:52 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:52 --> Input Class Initialized
INFO - 2017-03-16 01:52:52 --> Language Class Initialized
INFO - 2017-03-16 01:52:52 --> Loader Class Initialized
INFO - 2017-03-16 01:52:52 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:52 --> Controller Class Initialized
INFO - 2017-03-16 01:52:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:52 --> Config Class Initialized
INFO - 2017-03-16 01:52:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:52 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:52 --> URI Class Initialized
INFO - 2017-03-16 01:52:52 --> Router Class Initialized
INFO - 2017-03-16 01:52:52 --> Output Class Initialized
INFO - 2017-03-16 01:52:52 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:52 --> Input Class Initialized
INFO - 2017-03-16 01:52:52 --> Language Class Initialized
INFO - 2017-03-16 01:52:52 --> Loader Class Initialized
INFO - 2017-03-16 01:52:52 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:52 --> Controller Class Initialized
INFO - 2017-03-16 01:52:52 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:52 --> Helper loaded: url_helper
INFO - 2017-03-16 01:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:52 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:52 --> Total execution time: 0.0962
INFO - 2017-03-16 01:52:54 --> Config Class Initialized
INFO - 2017-03-16 01:52:54 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:52:54 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:52:54 --> Utf8 Class Initialized
INFO - 2017-03-16 01:52:54 --> URI Class Initialized
INFO - 2017-03-16 01:52:54 --> Router Class Initialized
INFO - 2017-03-16 01:52:54 --> Output Class Initialized
INFO - 2017-03-16 01:52:54 --> Security Class Initialized
DEBUG - 2017-03-16 01:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:52:54 --> Input Class Initialized
INFO - 2017-03-16 01:52:54 --> Language Class Initialized
INFO - 2017-03-16 01:52:54 --> Loader Class Initialized
INFO - 2017-03-16 01:52:54 --> Database Driver Class Initialized
INFO - 2017-03-16 01:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:52:54 --> Controller Class Initialized
INFO - 2017-03-16 01:52:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:52:54 --> Final output sent to browser
DEBUG - 2017-03-16 01:52:54 --> Total execution time: 0.0130
INFO - 2017-03-16 01:53:01 --> Config Class Initialized
INFO - 2017-03-16 01:53:01 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:53:01 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:53:01 --> Utf8 Class Initialized
INFO - 2017-03-16 01:53:01 --> URI Class Initialized
INFO - 2017-03-16 01:53:01 --> Router Class Initialized
INFO - 2017-03-16 01:53:01 --> Output Class Initialized
INFO - 2017-03-16 01:53:01 --> Security Class Initialized
DEBUG - 2017-03-16 01:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:53:01 --> Input Class Initialized
INFO - 2017-03-16 01:53:01 --> Language Class Initialized
INFO - 2017-03-16 01:53:01 --> Loader Class Initialized
INFO - 2017-03-16 01:53:01 --> Database Driver Class Initialized
INFO - 2017-03-16 01:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:53:01 --> Controller Class Initialized
INFO - 2017-03-16 01:53:01 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:53:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:53:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:53:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:53:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:53:01 --> Final output sent to browser
DEBUG - 2017-03-16 01:53:01 --> Total execution time: 0.0130
INFO - 2017-03-16 01:53:16 --> Config Class Initialized
INFO - 2017-03-16 01:53:16 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:53:16 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:53:16 --> Utf8 Class Initialized
INFO - 2017-03-16 01:53:16 --> URI Class Initialized
INFO - 2017-03-16 01:53:16 --> Router Class Initialized
INFO - 2017-03-16 01:53:16 --> Output Class Initialized
INFO - 2017-03-16 01:53:16 --> Security Class Initialized
DEBUG - 2017-03-16 01:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:53:16 --> Input Class Initialized
INFO - 2017-03-16 01:53:16 --> Language Class Initialized
INFO - 2017-03-16 01:53:16 --> Loader Class Initialized
INFO - 2017-03-16 01:53:16 --> Database Driver Class Initialized
INFO - 2017-03-16 01:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:53:16 --> Controller Class Initialized
INFO - 2017-03-16 01:53:16 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:53:18 --> Config Class Initialized
INFO - 2017-03-16 01:53:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:53:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:53:18 --> Utf8 Class Initialized
INFO - 2017-03-16 01:53:18 --> URI Class Initialized
INFO - 2017-03-16 01:53:18 --> Router Class Initialized
INFO - 2017-03-16 01:53:18 --> Output Class Initialized
INFO - 2017-03-16 01:53:18 --> Security Class Initialized
DEBUG - 2017-03-16 01:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:53:18 --> Input Class Initialized
INFO - 2017-03-16 01:53:18 --> Language Class Initialized
INFO - 2017-03-16 01:53:18 --> Loader Class Initialized
INFO - 2017-03-16 01:53:18 --> Database Driver Class Initialized
INFO - 2017-03-16 01:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:53:18 --> Controller Class Initialized
INFO - 2017-03-16 01:53:18 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:53:18 --> Helper loaded: url_helper
INFO - 2017-03-16 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:53:18 --> Final output sent to browser
DEBUG - 2017-03-16 01:53:18 --> Total execution time: 0.0132
INFO - 2017-03-16 01:53:21 --> Config Class Initialized
INFO - 2017-03-16 01:53:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:53:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:53:21 --> Utf8 Class Initialized
INFO - 2017-03-16 01:53:21 --> URI Class Initialized
DEBUG - 2017-03-16 01:53:21 --> No URI present. Default controller set.
INFO - 2017-03-16 01:53:21 --> Router Class Initialized
INFO - 2017-03-16 01:53:21 --> Output Class Initialized
INFO - 2017-03-16 01:53:21 --> Security Class Initialized
DEBUG - 2017-03-16 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:53:21 --> Input Class Initialized
INFO - 2017-03-16 01:53:21 --> Language Class Initialized
INFO - 2017-03-16 01:53:21 --> Loader Class Initialized
INFO - 2017-03-16 01:53:21 --> Database Driver Class Initialized
INFO - 2017-03-16 01:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:53:21 --> Controller Class Initialized
INFO - 2017-03-16 01:53:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:53:21 --> Final output sent to browser
DEBUG - 2017-03-16 01:53:21 --> Total execution time: 0.0131
INFO - 2017-03-16 01:53:26 --> Config Class Initialized
INFO - 2017-03-16 01:53:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:53:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:53:26 --> Utf8 Class Initialized
INFO - 2017-03-16 01:53:26 --> URI Class Initialized
INFO - 2017-03-16 01:53:26 --> Router Class Initialized
INFO - 2017-03-16 01:53:26 --> Output Class Initialized
INFO - 2017-03-16 01:53:26 --> Security Class Initialized
DEBUG - 2017-03-16 01:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:53:26 --> Input Class Initialized
INFO - 2017-03-16 01:53:26 --> Language Class Initialized
INFO - 2017-03-16 01:53:26 --> Loader Class Initialized
INFO - 2017-03-16 01:53:26 --> Database Driver Class Initialized
INFO - 2017-03-16 01:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:53:26 --> Controller Class Initialized
INFO - 2017-03-16 01:53:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:53:27 --> Final output sent to browser
DEBUG - 2017-03-16 01:53:27 --> Total execution time: 1.0756
INFO - 2017-03-16 01:54:47 --> Config Class Initialized
INFO - 2017-03-16 01:54:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:54:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:54:47 --> Utf8 Class Initialized
INFO - 2017-03-16 01:54:47 --> URI Class Initialized
INFO - 2017-03-16 01:54:47 --> Router Class Initialized
INFO - 2017-03-16 01:54:47 --> Output Class Initialized
INFO - 2017-03-16 01:54:47 --> Security Class Initialized
DEBUG - 2017-03-16 01:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:54:47 --> Input Class Initialized
INFO - 2017-03-16 01:54:47 --> Language Class Initialized
INFO - 2017-03-16 01:54:47 --> Loader Class Initialized
INFO - 2017-03-16 01:54:47 --> Database Driver Class Initialized
INFO - 2017-03-16 01:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:54:48 --> Controller Class Initialized
INFO - 2017-03-16 01:54:48 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:54:50 --> Config Class Initialized
INFO - 2017-03-16 01:54:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:54:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:54:50 --> Utf8 Class Initialized
INFO - 2017-03-16 01:54:50 --> URI Class Initialized
INFO - 2017-03-16 01:54:50 --> Router Class Initialized
INFO - 2017-03-16 01:54:50 --> Output Class Initialized
INFO - 2017-03-16 01:54:50 --> Security Class Initialized
DEBUG - 2017-03-16 01:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:54:50 --> Input Class Initialized
INFO - 2017-03-16 01:54:50 --> Language Class Initialized
INFO - 2017-03-16 01:54:50 --> Loader Class Initialized
INFO - 2017-03-16 01:54:50 --> Database Driver Class Initialized
INFO - 2017-03-16 01:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:54:50 --> Controller Class Initialized
INFO - 2017-03-16 01:54:50 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:54:50 --> Helper loaded: url_helper
INFO - 2017-03-16 01:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:54:50 --> Final output sent to browser
DEBUG - 2017-03-16 01:54:50 --> Total execution time: 0.1241
INFO - 2017-03-16 01:54:51 --> Config Class Initialized
INFO - 2017-03-16 01:54:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:54:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:54:51 --> Utf8 Class Initialized
INFO - 2017-03-16 01:54:51 --> URI Class Initialized
INFO - 2017-03-16 01:54:51 --> Router Class Initialized
INFO - 2017-03-16 01:54:51 --> Output Class Initialized
INFO - 2017-03-16 01:54:51 --> Security Class Initialized
DEBUG - 2017-03-16 01:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:54:51 --> Input Class Initialized
INFO - 2017-03-16 01:54:51 --> Language Class Initialized
INFO - 2017-03-16 01:54:51 --> Loader Class Initialized
INFO - 2017-03-16 01:54:51 --> Database Driver Class Initialized
INFO - 2017-03-16 01:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:54:51 --> Controller Class Initialized
INFO - 2017-03-16 01:54:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:54:51 --> Final output sent to browser
DEBUG - 2017-03-16 01:54:51 --> Total execution time: 0.0209
INFO - 2017-03-16 01:54:58 --> Config Class Initialized
INFO - 2017-03-16 01:54:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:54:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:54:58 --> Utf8 Class Initialized
INFO - 2017-03-16 01:54:58 --> URI Class Initialized
INFO - 2017-03-16 01:54:58 --> Router Class Initialized
INFO - 2017-03-16 01:54:58 --> Output Class Initialized
INFO - 2017-03-16 01:54:58 --> Security Class Initialized
DEBUG - 2017-03-16 01:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:54:58 --> Input Class Initialized
INFO - 2017-03-16 01:54:58 --> Language Class Initialized
INFO - 2017-03-16 01:54:58 --> Loader Class Initialized
INFO - 2017-03-16 01:54:58 --> Database Driver Class Initialized
INFO - 2017-03-16 01:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:54:58 --> Controller Class Initialized
INFO - 2017-03-16 01:54:58 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:54:58 --> Config Class Initialized
INFO - 2017-03-16 01:54:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:54:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:54:58 --> Utf8 Class Initialized
INFO - 2017-03-16 01:54:58 --> URI Class Initialized
INFO - 2017-03-16 01:54:58 --> Router Class Initialized
INFO - 2017-03-16 01:54:58 --> Output Class Initialized
INFO - 2017-03-16 01:54:58 --> Security Class Initialized
DEBUG - 2017-03-16 01:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:54:58 --> Input Class Initialized
INFO - 2017-03-16 01:54:58 --> Language Class Initialized
INFO - 2017-03-16 01:54:58 --> Loader Class Initialized
INFO - 2017-03-16 01:54:58 --> Database Driver Class Initialized
INFO - 2017-03-16 01:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:54:58 --> Controller Class Initialized
INFO - 2017-03-16 01:54:58 --> Helper loaded: date_helper
DEBUG - 2017-03-16 01:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:54:58 --> Helper loaded: url_helper
INFO - 2017-03-16 01:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 01:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 01:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 01:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:54:58 --> Final output sent to browser
DEBUG - 2017-03-16 01:54:58 --> Total execution time: 0.0133
INFO - 2017-03-16 01:54:59 --> Config Class Initialized
INFO - 2017-03-16 01:54:59 --> Hooks Class Initialized
DEBUG - 2017-03-16 01:54:59 --> UTF-8 Support Enabled
INFO - 2017-03-16 01:54:59 --> Utf8 Class Initialized
INFO - 2017-03-16 01:54:59 --> URI Class Initialized
INFO - 2017-03-16 01:54:59 --> Router Class Initialized
INFO - 2017-03-16 01:54:59 --> Output Class Initialized
INFO - 2017-03-16 01:54:59 --> Security Class Initialized
DEBUG - 2017-03-16 01:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 01:54:59 --> Input Class Initialized
INFO - 2017-03-16 01:54:59 --> Language Class Initialized
INFO - 2017-03-16 01:54:59 --> Loader Class Initialized
INFO - 2017-03-16 01:54:59 --> Database Driver Class Initialized
INFO - 2017-03-16 01:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 01:54:59 --> Controller Class Initialized
INFO - 2017-03-16 01:54:59 --> Helper loaded: url_helper
DEBUG - 2017-03-16 01:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 01:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 01:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 01:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 01:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 01:54:59 --> Final output sent to browser
DEBUG - 2017-03-16 01:54:59 --> Total execution time: 0.0135
INFO - 2017-03-16 02:01:52 --> Config Class Initialized
INFO - 2017-03-16 02:01:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:01:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:01:52 --> Utf8 Class Initialized
INFO - 2017-03-16 02:01:52 --> URI Class Initialized
DEBUG - 2017-03-16 02:01:52 --> No URI present. Default controller set.
INFO - 2017-03-16 02:01:52 --> Router Class Initialized
INFO - 2017-03-16 02:01:52 --> Output Class Initialized
INFO - 2017-03-16 02:01:52 --> Security Class Initialized
DEBUG - 2017-03-16 02:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:01:52 --> Input Class Initialized
INFO - 2017-03-16 02:01:52 --> Language Class Initialized
INFO - 2017-03-16 02:01:53 --> Loader Class Initialized
INFO - 2017-03-16 02:01:53 --> Database Driver Class Initialized
INFO - 2017-03-16 02:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:01:54 --> Controller Class Initialized
INFO - 2017-03-16 02:01:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:01:54 --> Final output sent to browser
DEBUG - 2017-03-16 02:01:54 --> Total execution time: 2.9457
INFO - 2017-03-16 02:02:24 --> Config Class Initialized
INFO - 2017-03-16 02:02:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:24 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:24 --> URI Class Initialized
DEBUG - 2017-03-16 02:02:24 --> No URI present. Default controller set.
INFO - 2017-03-16 02:02:24 --> Router Class Initialized
INFO - 2017-03-16 02:02:24 --> Output Class Initialized
INFO - 2017-03-16 02:02:24 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:24 --> Input Class Initialized
INFO - 2017-03-16 02:02:24 --> Language Class Initialized
INFO - 2017-03-16 02:02:24 --> Loader Class Initialized
INFO - 2017-03-16 02:02:25 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:25 --> Controller Class Initialized
INFO - 2017-03-16 02:02:25 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:25 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:25 --> Total execution time: 1.2460
INFO - 2017-03-16 02:02:26 --> Config Class Initialized
INFO - 2017-03-16 02:02:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:26 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:26 --> URI Class Initialized
INFO - 2017-03-16 02:02:26 --> Router Class Initialized
INFO - 2017-03-16 02:02:26 --> Output Class Initialized
INFO - 2017-03-16 02:02:26 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:26 --> Input Class Initialized
INFO - 2017-03-16 02:02:26 --> Language Class Initialized
INFO - 2017-03-16 02:02:26 --> Loader Class Initialized
INFO - 2017-03-16 02:02:26 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:26 --> Controller Class Initialized
INFO - 2017-03-16 02:02:26 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:26 --> Helper loaded: url_helper
INFO - 2017-03-16 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:26 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:26 --> Total execution time: 0.1474
INFO - 2017-03-16 02:02:31 --> Config Class Initialized
INFO - 2017-03-16 02:02:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:31 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:31 --> URI Class Initialized
INFO - 2017-03-16 02:02:31 --> Router Class Initialized
INFO - 2017-03-16 02:02:31 --> Output Class Initialized
INFO - 2017-03-16 02:02:31 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:31 --> Input Class Initialized
INFO - 2017-03-16 02:02:31 --> Language Class Initialized
INFO - 2017-03-16 02:02:31 --> Loader Class Initialized
INFO - 2017-03-16 02:02:31 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:31 --> Controller Class Initialized
INFO - 2017-03-16 02:02:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:31 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:31 --> Total execution time: 0.0134
INFO - 2017-03-16 02:02:38 --> Config Class Initialized
INFO - 2017-03-16 02:02:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:38 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:38 --> URI Class Initialized
INFO - 2017-03-16 02:02:38 --> Router Class Initialized
INFO - 2017-03-16 02:02:38 --> Output Class Initialized
INFO - 2017-03-16 02:02:38 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:38 --> Input Class Initialized
INFO - 2017-03-16 02:02:38 --> Language Class Initialized
INFO - 2017-03-16 02:02:38 --> Loader Class Initialized
INFO - 2017-03-16 02:02:38 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:38 --> Controller Class Initialized
INFO - 2017-03-16 02:02:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:38 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:38 --> Total execution time: 0.0142
INFO - 2017-03-16 02:02:41 --> Config Class Initialized
INFO - 2017-03-16 02:02:41 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:41 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:41 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:41 --> URI Class Initialized
INFO - 2017-03-16 02:02:41 --> Router Class Initialized
INFO - 2017-03-16 02:02:41 --> Output Class Initialized
INFO - 2017-03-16 02:02:41 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:41 --> Input Class Initialized
INFO - 2017-03-16 02:02:41 --> Language Class Initialized
INFO - 2017-03-16 02:02:41 --> Loader Class Initialized
INFO - 2017-03-16 02:02:41 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:41 --> Controller Class Initialized
INFO - 2017-03-16 02:02:41 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:41 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:41 --> Total execution time: 0.0131
INFO - 2017-03-16 02:02:45 --> Config Class Initialized
INFO - 2017-03-16 02:02:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:45 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:45 --> URI Class Initialized
INFO - 2017-03-16 02:02:45 --> Router Class Initialized
INFO - 2017-03-16 02:02:45 --> Output Class Initialized
INFO - 2017-03-16 02:02:45 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:45 --> Input Class Initialized
INFO - 2017-03-16 02:02:45 --> Language Class Initialized
INFO - 2017-03-16 02:02:45 --> Loader Class Initialized
INFO - 2017-03-16 02:02:45 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:45 --> Controller Class Initialized
INFO - 2017-03-16 02:02:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:47 --> Config Class Initialized
INFO - 2017-03-16 02:02:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:47 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:47 --> URI Class Initialized
INFO - 2017-03-16 02:02:47 --> Router Class Initialized
INFO - 2017-03-16 02:02:47 --> Output Class Initialized
INFO - 2017-03-16 02:02:47 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:47 --> Input Class Initialized
INFO - 2017-03-16 02:02:47 --> Language Class Initialized
INFO - 2017-03-16 02:02:47 --> Loader Class Initialized
INFO - 2017-03-16 02:02:47 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:47 --> Controller Class Initialized
INFO - 2017-03-16 02:02:47 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:47 --> Helper loaded: url_helper
INFO - 2017-03-16 02:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:47 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:47 --> Total execution time: 0.0166
INFO - 2017-03-16 02:02:48 --> Config Class Initialized
INFO - 2017-03-16 02:02:48 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:48 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:48 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:48 --> URI Class Initialized
INFO - 2017-03-16 02:02:48 --> Router Class Initialized
INFO - 2017-03-16 02:02:48 --> Output Class Initialized
INFO - 2017-03-16 02:02:48 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:48 --> Input Class Initialized
INFO - 2017-03-16 02:02:48 --> Language Class Initialized
INFO - 2017-03-16 02:02:48 --> Loader Class Initialized
INFO - 2017-03-16 02:02:48 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:48 --> Controller Class Initialized
INFO - 2017-03-16 02:02:48 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:48 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:48 --> Total execution time: 0.0129
INFO - 2017-03-16 02:02:51 --> Config Class Initialized
INFO - 2017-03-16 02:02:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:51 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:51 --> URI Class Initialized
INFO - 2017-03-16 02:02:51 --> Router Class Initialized
INFO - 2017-03-16 02:02:51 --> Output Class Initialized
INFO - 2017-03-16 02:02:51 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:51 --> Input Class Initialized
INFO - 2017-03-16 02:02:51 --> Language Class Initialized
INFO - 2017-03-16 02:02:51 --> Loader Class Initialized
INFO - 2017-03-16 02:02:51 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:51 --> Controller Class Initialized
INFO - 2017-03-16 02:02:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:51 --> Config Class Initialized
INFO - 2017-03-16 02:02:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:51 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:51 --> URI Class Initialized
INFO - 2017-03-16 02:02:51 --> Router Class Initialized
INFO - 2017-03-16 02:02:51 --> Output Class Initialized
INFO - 2017-03-16 02:02:51 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:51 --> Input Class Initialized
INFO - 2017-03-16 02:02:51 --> Language Class Initialized
INFO - 2017-03-16 02:02:51 --> Loader Class Initialized
INFO - 2017-03-16 02:02:51 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:51 --> Controller Class Initialized
INFO - 2017-03-16 02:02:51 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:51 --> Helper loaded: url_helper
INFO - 2017-03-16 02:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:51 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:51 --> Total execution time: 0.0134
INFO - 2017-03-16 02:02:52 --> Config Class Initialized
INFO - 2017-03-16 02:02:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:52 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:52 --> URI Class Initialized
INFO - 2017-03-16 02:02:52 --> Router Class Initialized
INFO - 2017-03-16 02:02:52 --> Output Class Initialized
INFO - 2017-03-16 02:02:52 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:52 --> Input Class Initialized
INFO - 2017-03-16 02:02:52 --> Language Class Initialized
INFO - 2017-03-16 02:02:52 --> Loader Class Initialized
INFO - 2017-03-16 02:02:52 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:52 --> Controller Class Initialized
INFO - 2017-03-16 02:02:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:52 --> Config Class Initialized
INFO - 2017-03-16 02:02:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:52 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:52 --> URI Class Initialized
INFO - 2017-03-16 02:02:52 --> Router Class Initialized
INFO - 2017-03-16 02:02:52 --> Output Class Initialized
INFO - 2017-03-16 02:02:52 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:52 --> Input Class Initialized
INFO - 2017-03-16 02:02:52 --> Language Class Initialized
INFO - 2017-03-16 02:02:52 --> Loader Class Initialized
INFO - 2017-03-16 02:02:52 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:52 --> Controller Class Initialized
INFO - 2017-03-16 02:02:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:52 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:52 --> Total execution time: 0.0345
INFO - 2017-03-16 02:02:52 --> Config Class Initialized
INFO - 2017-03-16 02:02:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:52 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:52 --> URI Class Initialized
INFO - 2017-03-16 02:02:52 --> Router Class Initialized
INFO - 2017-03-16 02:02:52 --> Output Class Initialized
INFO - 2017-03-16 02:02:52 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:52 --> Input Class Initialized
INFO - 2017-03-16 02:02:52 --> Language Class Initialized
INFO - 2017-03-16 02:02:52 --> Loader Class Initialized
INFO - 2017-03-16 02:02:52 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:52 --> Controller Class Initialized
INFO - 2017-03-16 02:02:52 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:52 --> Helper loaded: url_helper
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:52 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:52 --> Total execution time: 0.0139
INFO - 2017-03-16 02:02:54 --> Config Class Initialized
INFO - 2017-03-16 02:02:54 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:54 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:54 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:54 --> URI Class Initialized
INFO - 2017-03-16 02:02:54 --> Router Class Initialized
INFO - 2017-03-16 02:02:54 --> Output Class Initialized
INFO - 2017-03-16 02:02:54 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:54 --> Input Class Initialized
INFO - 2017-03-16 02:02:54 --> Language Class Initialized
INFO - 2017-03-16 02:02:54 --> Loader Class Initialized
INFO - 2017-03-16 02:02:54 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:54 --> Controller Class Initialized
INFO - 2017-03-16 02:02:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:54 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:54 --> Total execution time: 0.0130
INFO - 2017-03-16 02:02:59 --> Config Class Initialized
INFO - 2017-03-16 02:02:59 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:02:59 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:02:59 --> Utf8 Class Initialized
INFO - 2017-03-16 02:02:59 --> URI Class Initialized
INFO - 2017-03-16 02:02:59 --> Router Class Initialized
INFO - 2017-03-16 02:02:59 --> Output Class Initialized
INFO - 2017-03-16 02:02:59 --> Security Class Initialized
DEBUG - 2017-03-16 02:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:02:59 --> Input Class Initialized
INFO - 2017-03-16 02:02:59 --> Language Class Initialized
INFO - 2017-03-16 02:02:59 --> Loader Class Initialized
INFO - 2017-03-16 02:02:59 --> Database Driver Class Initialized
INFO - 2017-03-16 02:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:02:59 --> Controller Class Initialized
INFO - 2017-03-16 02:02:59 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:02:59 --> Helper loaded: url_helper
INFO - 2017-03-16 02:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:02:59 --> Final output sent to browser
DEBUG - 2017-03-16 02:02:59 --> Total execution time: 0.0138
INFO - 2017-03-16 02:03:00 --> Config Class Initialized
INFO - 2017-03-16 02:03:00 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:00 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:00 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:00 --> URI Class Initialized
DEBUG - 2017-03-16 02:03:00 --> No URI present. Default controller set.
INFO - 2017-03-16 02:03:00 --> Router Class Initialized
INFO - 2017-03-16 02:03:00 --> Output Class Initialized
INFO - 2017-03-16 02:03:00 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:00 --> Input Class Initialized
INFO - 2017-03-16 02:03:00 --> Language Class Initialized
INFO - 2017-03-16 02:03:00 --> Loader Class Initialized
INFO - 2017-03-16 02:03:00 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:00 --> Controller Class Initialized
INFO - 2017-03-16 02:03:00 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:00 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:00 --> Total execution time: 0.0133
INFO - 2017-03-16 02:03:01 --> Config Class Initialized
INFO - 2017-03-16 02:03:01 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:01 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:01 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:01 --> URI Class Initialized
INFO - 2017-03-16 02:03:01 --> Router Class Initialized
INFO - 2017-03-16 02:03:01 --> Output Class Initialized
INFO - 2017-03-16 02:03:01 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:01 --> Input Class Initialized
INFO - 2017-03-16 02:03:01 --> Language Class Initialized
INFO - 2017-03-16 02:03:01 --> Loader Class Initialized
INFO - 2017-03-16 02:03:01 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:01 --> Controller Class Initialized
INFO - 2017-03-16 02:03:01 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:01 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:01 --> Total execution time: 0.0137
INFO - 2017-03-16 02:03:09 --> Config Class Initialized
INFO - 2017-03-16 02:03:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:09 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:09 --> URI Class Initialized
INFO - 2017-03-16 02:03:09 --> Router Class Initialized
INFO - 2017-03-16 02:03:09 --> Output Class Initialized
INFO - 2017-03-16 02:03:09 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:09 --> Input Class Initialized
INFO - 2017-03-16 02:03:09 --> Language Class Initialized
INFO - 2017-03-16 02:03:09 --> Loader Class Initialized
INFO - 2017-03-16 02:03:09 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:09 --> Controller Class Initialized
INFO - 2017-03-16 02:03:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:09 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:09 --> Total execution time: 0.0134
INFO - 2017-03-16 02:03:16 --> Config Class Initialized
INFO - 2017-03-16 02:03:16 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:16 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:16 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:16 --> URI Class Initialized
DEBUG - 2017-03-16 02:03:16 --> No URI present. Default controller set.
INFO - 2017-03-16 02:03:16 --> Router Class Initialized
INFO - 2017-03-16 02:03:16 --> Output Class Initialized
INFO - 2017-03-16 02:03:16 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:16 --> Input Class Initialized
INFO - 2017-03-16 02:03:16 --> Language Class Initialized
INFO - 2017-03-16 02:03:16 --> Loader Class Initialized
INFO - 2017-03-16 02:03:16 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:16 --> Controller Class Initialized
INFO - 2017-03-16 02:03:16 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:16 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:16 --> Total execution time: 0.0129
INFO - 2017-03-16 02:03:22 --> Config Class Initialized
INFO - 2017-03-16 02:03:22 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:22 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:22 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:22 --> URI Class Initialized
INFO - 2017-03-16 02:03:22 --> Router Class Initialized
INFO - 2017-03-16 02:03:22 --> Output Class Initialized
INFO - 2017-03-16 02:03:22 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:22 --> Input Class Initialized
INFO - 2017-03-16 02:03:22 --> Language Class Initialized
INFO - 2017-03-16 02:03:22 --> Loader Class Initialized
INFO - 2017-03-16 02:03:22 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:22 --> Controller Class Initialized
INFO - 2017-03-16 02:03:22 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:22 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:22 --> Total execution time: 0.0134
INFO - 2017-03-16 02:03:36 --> Config Class Initialized
INFO - 2017-03-16 02:03:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:36 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:36 --> URI Class Initialized
INFO - 2017-03-16 02:03:36 --> Router Class Initialized
INFO - 2017-03-16 02:03:36 --> Output Class Initialized
INFO - 2017-03-16 02:03:36 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:36 --> Input Class Initialized
INFO - 2017-03-16 02:03:36 --> Language Class Initialized
INFO - 2017-03-16 02:03:36 --> Loader Class Initialized
INFO - 2017-03-16 02:03:36 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:36 --> Controller Class Initialized
INFO - 2017-03-16 02:03:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:36 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:36 --> Total execution time: 0.0166
INFO - 2017-03-16 02:03:37 --> Config Class Initialized
INFO - 2017-03-16 02:03:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:37 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:37 --> URI Class Initialized
INFO - 2017-03-16 02:03:37 --> Router Class Initialized
INFO - 2017-03-16 02:03:37 --> Output Class Initialized
INFO - 2017-03-16 02:03:37 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:37 --> Input Class Initialized
INFO - 2017-03-16 02:03:37 --> Language Class Initialized
INFO - 2017-03-16 02:03:37 --> Loader Class Initialized
INFO - 2017-03-16 02:03:37 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:37 --> Controller Class Initialized
INFO - 2017-03-16 02:03:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:37 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:37 --> Total execution time: 0.0133
INFO - 2017-03-16 02:03:42 --> Config Class Initialized
INFO - 2017-03-16 02:03:42 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:42 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:42 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:42 --> URI Class Initialized
INFO - 2017-03-16 02:03:42 --> Router Class Initialized
INFO - 2017-03-16 02:03:42 --> Output Class Initialized
INFO - 2017-03-16 02:03:42 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:42 --> Input Class Initialized
INFO - 2017-03-16 02:03:42 --> Language Class Initialized
INFO - 2017-03-16 02:03:42 --> Loader Class Initialized
INFO - 2017-03-16 02:03:42 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:42 --> Controller Class Initialized
INFO - 2017-03-16 02:03:42 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:42 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:42 --> Total execution time: 0.0149
INFO - 2017-03-16 02:03:44 --> Config Class Initialized
INFO - 2017-03-16 02:03:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:44 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:44 --> URI Class Initialized
INFO - 2017-03-16 02:03:44 --> Router Class Initialized
INFO - 2017-03-16 02:03:44 --> Output Class Initialized
INFO - 2017-03-16 02:03:44 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:44 --> Input Class Initialized
INFO - 2017-03-16 02:03:44 --> Language Class Initialized
INFO - 2017-03-16 02:03:44 --> Loader Class Initialized
INFO - 2017-03-16 02:03:44 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:44 --> Controller Class Initialized
INFO - 2017-03-16 02:03:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:44 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:44 --> Total execution time: 0.0130
INFO - 2017-03-16 02:03:53 --> Config Class Initialized
INFO - 2017-03-16 02:03:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:53 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:53 --> URI Class Initialized
INFO - 2017-03-16 02:03:53 --> Router Class Initialized
INFO - 2017-03-16 02:03:53 --> Output Class Initialized
INFO - 2017-03-16 02:03:53 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:53 --> Input Class Initialized
INFO - 2017-03-16 02:03:53 --> Language Class Initialized
INFO - 2017-03-16 02:03:53 --> Loader Class Initialized
INFO - 2017-03-16 02:03:53 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:53 --> Controller Class Initialized
INFO - 2017-03-16 02:03:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:54 --> Config Class Initialized
INFO - 2017-03-16 02:03:54 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:54 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:54 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:54 --> URI Class Initialized
INFO - 2017-03-16 02:03:54 --> Router Class Initialized
INFO - 2017-03-16 02:03:54 --> Output Class Initialized
INFO - 2017-03-16 02:03:54 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:54 --> Input Class Initialized
INFO - 2017-03-16 02:03:54 --> Language Class Initialized
INFO - 2017-03-16 02:03:54 --> Loader Class Initialized
INFO - 2017-03-16 02:03:54 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:54 --> Controller Class Initialized
INFO - 2017-03-16 02:03:54 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:54 --> Helper loaded: url_helper
INFO - 2017-03-16 02:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:54 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:54 --> Total execution time: 0.0142
INFO - 2017-03-16 02:03:55 --> Config Class Initialized
INFO - 2017-03-16 02:03:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:03:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:03:55 --> Utf8 Class Initialized
INFO - 2017-03-16 02:03:55 --> URI Class Initialized
INFO - 2017-03-16 02:03:55 --> Router Class Initialized
INFO - 2017-03-16 02:03:55 --> Output Class Initialized
INFO - 2017-03-16 02:03:55 --> Security Class Initialized
DEBUG - 2017-03-16 02:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:03:55 --> Input Class Initialized
INFO - 2017-03-16 02:03:55 --> Language Class Initialized
INFO - 2017-03-16 02:03:55 --> Loader Class Initialized
INFO - 2017-03-16 02:03:55 --> Database Driver Class Initialized
INFO - 2017-03-16 02:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:03:55 --> Controller Class Initialized
INFO - 2017-03-16 02:03:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:03:55 --> Final output sent to browser
DEBUG - 2017-03-16 02:03:55 --> Total execution time: 0.0142
INFO - 2017-03-16 02:04:55 --> Config Class Initialized
INFO - 2017-03-16 02:04:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:04:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:04:55 --> Utf8 Class Initialized
INFO - 2017-03-16 02:04:55 --> URI Class Initialized
INFO - 2017-03-16 02:04:55 --> Router Class Initialized
INFO - 2017-03-16 02:04:55 --> Output Class Initialized
INFO - 2017-03-16 02:04:55 --> Security Class Initialized
DEBUG - 2017-03-16 02:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:04:55 --> Input Class Initialized
INFO - 2017-03-16 02:04:55 --> Language Class Initialized
INFO - 2017-03-16 02:04:55 --> Loader Class Initialized
INFO - 2017-03-16 02:04:55 --> Database Driver Class Initialized
INFO - 2017-03-16 02:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:04:55 --> Controller Class Initialized
INFO - 2017-03-16 02:04:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:04:55 --> Final output sent to browser
DEBUG - 2017-03-16 02:04:55 --> Total execution time: 0.0148
INFO - 2017-03-16 02:04:56 --> Config Class Initialized
INFO - 2017-03-16 02:04:56 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:04:56 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:04:56 --> Utf8 Class Initialized
INFO - 2017-03-16 02:04:56 --> URI Class Initialized
INFO - 2017-03-16 02:04:56 --> Router Class Initialized
INFO - 2017-03-16 02:04:56 --> Output Class Initialized
INFO - 2017-03-16 02:04:56 --> Security Class Initialized
DEBUG - 2017-03-16 02:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:04:56 --> Input Class Initialized
INFO - 2017-03-16 02:04:56 --> Language Class Initialized
INFO - 2017-03-16 02:04:56 --> Loader Class Initialized
INFO - 2017-03-16 02:04:56 --> Database Driver Class Initialized
INFO - 2017-03-16 02:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:04:56 --> Controller Class Initialized
INFO - 2017-03-16 02:04:56 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:04:56 --> Final output sent to browser
DEBUG - 2017-03-16 02:04:56 --> Total execution time: 0.0134
INFO - 2017-03-16 02:05:19 --> Config Class Initialized
INFO - 2017-03-16 02:05:19 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:05:19 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:05:19 --> Utf8 Class Initialized
INFO - 2017-03-16 02:05:19 --> URI Class Initialized
INFO - 2017-03-16 02:05:20 --> Router Class Initialized
INFO - 2017-03-16 02:05:20 --> Output Class Initialized
INFO - 2017-03-16 02:05:20 --> Security Class Initialized
DEBUG - 2017-03-16 02:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:05:20 --> Input Class Initialized
INFO - 2017-03-16 02:05:20 --> Language Class Initialized
INFO - 2017-03-16 02:05:20 --> Loader Class Initialized
INFO - 2017-03-16 02:05:20 --> Database Driver Class Initialized
INFO - 2017-03-16 02:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:05:20 --> Controller Class Initialized
INFO - 2017-03-16 02:05:20 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:05:20 --> Config Class Initialized
INFO - 2017-03-16 02:05:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:05:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:05:20 --> Utf8 Class Initialized
INFO - 2017-03-16 02:05:20 --> URI Class Initialized
INFO - 2017-03-16 02:05:20 --> Router Class Initialized
INFO - 2017-03-16 02:05:20 --> Output Class Initialized
INFO - 2017-03-16 02:05:20 --> Security Class Initialized
DEBUG - 2017-03-16 02:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:05:20 --> Input Class Initialized
INFO - 2017-03-16 02:05:20 --> Language Class Initialized
INFO - 2017-03-16 02:05:20 --> Loader Class Initialized
INFO - 2017-03-16 02:05:20 --> Database Driver Class Initialized
INFO - 2017-03-16 02:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:05:20 --> Controller Class Initialized
INFO - 2017-03-16 02:05:20 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:05:20 --> Helper loaded: url_helper
INFO - 2017-03-16 02:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:05:20 --> Final output sent to browser
DEBUG - 2017-03-16 02:05:20 --> Total execution time: 0.0303
INFO - 2017-03-16 02:05:21 --> Config Class Initialized
INFO - 2017-03-16 02:05:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:05:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:05:21 --> Utf8 Class Initialized
INFO - 2017-03-16 02:05:21 --> URI Class Initialized
INFO - 2017-03-16 02:05:21 --> Router Class Initialized
INFO - 2017-03-16 02:05:21 --> Output Class Initialized
INFO - 2017-03-16 02:05:21 --> Security Class Initialized
DEBUG - 2017-03-16 02:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:05:21 --> Input Class Initialized
INFO - 2017-03-16 02:05:21 --> Language Class Initialized
INFO - 2017-03-16 02:05:21 --> Loader Class Initialized
INFO - 2017-03-16 02:05:21 --> Database Driver Class Initialized
INFO - 2017-03-16 02:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:05:21 --> Controller Class Initialized
INFO - 2017-03-16 02:05:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:05:21 --> Final output sent to browser
DEBUG - 2017-03-16 02:05:21 --> Total execution time: 0.0141
INFO - 2017-03-16 02:05:29 --> Config Class Initialized
INFO - 2017-03-16 02:05:29 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:05:29 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:05:29 --> Utf8 Class Initialized
INFO - 2017-03-16 02:05:29 --> URI Class Initialized
DEBUG - 2017-03-16 02:05:29 --> No URI present. Default controller set.
INFO - 2017-03-16 02:05:29 --> Router Class Initialized
INFO - 2017-03-16 02:05:29 --> Output Class Initialized
INFO - 2017-03-16 02:05:29 --> Security Class Initialized
DEBUG - 2017-03-16 02:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:05:29 --> Input Class Initialized
INFO - 2017-03-16 02:05:29 --> Language Class Initialized
INFO - 2017-03-16 02:05:29 --> Loader Class Initialized
INFO - 2017-03-16 02:05:29 --> Database Driver Class Initialized
INFO - 2017-03-16 02:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:05:29 --> Controller Class Initialized
INFO - 2017-03-16 02:05:29 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:05:29 --> Final output sent to browser
DEBUG - 2017-03-16 02:05:29 --> Total execution time: 0.0130
INFO - 2017-03-16 02:05:30 --> Config Class Initialized
INFO - 2017-03-16 02:05:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:05:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:05:30 --> Utf8 Class Initialized
INFO - 2017-03-16 02:05:30 --> URI Class Initialized
INFO - 2017-03-16 02:05:30 --> Router Class Initialized
INFO - 2017-03-16 02:05:30 --> Output Class Initialized
INFO - 2017-03-16 02:05:30 --> Security Class Initialized
DEBUG - 2017-03-16 02:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:05:30 --> Input Class Initialized
INFO - 2017-03-16 02:05:30 --> Language Class Initialized
INFO - 2017-03-16 02:05:30 --> Loader Class Initialized
INFO - 2017-03-16 02:05:30 --> Database Driver Class Initialized
INFO - 2017-03-16 02:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:05:30 --> Controller Class Initialized
INFO - 2017-03-16 02:05:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:05:30 --> Final output sent to browser
DEBUG - 2017-03-16 02:05:30 --> Total execution time: 0.0133
INFO - 2017-03-16 02:07:11 --> Config Class Initialized
INFO - 2017-03-16 02:07:11 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:07:11 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:07:11 --> Utf8 Class Initialized
INFO - 2017-03-16 02:07:11 --> URI Class Initialized
DEBUG - 2017-03-16 02:07:11 --> No URI present. Default controller set.
INFO - 2017-03-16 02:07:11 --> Router Class Initialized
INFO - 2017-03-16 02:07:11 --> Output Class Initialized
INFO - 2017-03-16 02:07:11 --> Security Class Initialized
DEBUG - 2017-03-16 02:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:07:11 --> Input Class Initialized
INFO - 2017-03-16 02:07:11 --> Language Class Initialized
INFO - 2017-03-16 02:07:11 --> Loader Class Initialized
INFO - 2017-03-16 02:07:11 --> Database Driver Class Initialized
INFO - 2017-03-16 02:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:07:11 --> Controller Class Initialized
INFO - 2017-03-16 02:07:11 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:07:12 --> Final output sent to browser
DEBUG - 2017-03-16 02:07:12 --> Total execution time: 1.1460
INFO - 2017-03-16 02:19:30 --> Config Class Initialized
INFO - 2017-03-16 02:19:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:19:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:19:30 --> Utf8 Class Initialized
INFO - 2017-03-16 02:19:30 --> URI Class Initialized
DEBUG - 2017-03-16 02:19:30 --> No URI present. Default controller set.
INFO - 2017-03-16 02:19:30 --> Router Class Initialized
INFO - 2017-03-16 02:19:30 --> Output Class Initialized
INFO - 2017-03-16 02:19:30 --> Security Class Initialized
DEBUG - 2017-03-16 02:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:19:30 --> Input Class Initialized
INFO - 2017-03-16 02:19:30 --> Language Class Initialized
INFO - 2017-03-16 02:19:30 --> Loader Class Initialized
INFO - 2017-03-16 02:19:30 --> Database Driver Class Initialized
INFO - 2017-03-16 02:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:19:31 --> Controller Class Initialized
INFO - 2017-03-16 02:19:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:19:31 --> Final output sent to browser
DEBUG - 2017-03-16 02:19:31 --> Total execution time: 1.4720
INFO - 2017-03-16 02:19:31 --> Config Class Initialized
INFO - 2017-03-16 02:19:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:19:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:19:31 --> Utf8 Class Initialized
INFO - 2017-03-16 02:19:31 --> URI Class Initialized
DEBUG - 2017-03-16 02:19:31 --> No URI present. Default controller set.
INFO - 2017-03-16 02:19:31 --> Router Class Initialized
INFO - 2017-03-16 02:19:31 --> Output Class Initialized
INFO - 2017-03-16 02:19:31 --> Security Class Initialized
DEBUG - 2017-03-16 02:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:19:31 --> Input Class Initialized
INFO - 2017-03-16 02:19:31 --> Language Class Initialized
INFO - 2017-03-16 02:19:31 --> Loader Class Initialized
INFO - 2017-03-16 02:19:31 --> Database Driver Class Initialized
INFO - 2017-03-16 02:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:19:31 --> Controller Class Initialized
INFO - 2017-03-16 02:19:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:19:31 --> Final output sent to browser
DEBUG - 2017-03-16 02:19:31 --> Total execution time: 0.0131
INFO - 2017-03-16 02:20:43 --> Config Class Initialized
INFO - 2017-03-16 02:20:43 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:20:43 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:20:43 --> Utf8 Class Initialized
INFO - 2017-03-16 02:20:43 --> URI Class Initialized
DEBUG - 2017-03-16 02:20:43 --> No URI present. Default controller set.
INFO - 2017-03-16 02:20:43 --> Router Class Initialized
INFO - 2017-03-16 02:20:43 --> Output Class Initialized
INFO - 2017-03-16 02:20:43 --> Security Class Initialized
DEBUG - 2017-03-16 02:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:20:44 --> Input Class Initialized
INFO - 2017-03-16 02:20:44 --> Language Class Initialized
INFO - 2017-03-16 02:20:44 --> Loader Class Initialized
INFO - 2017-03-16 02:20:44 --> Database Driver Class Initialized
INFO - 2017-03-16 02:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:20:44 --> Controller Class Initialized
INFO - 2017-03-16 02:20:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:20:44 --> Final output sent to browser
DEBUG - 2017-03-16 02:20:44 --> Total execution time: 1.1919
INFO - 2017-03-16 02:24:39 --> Config Class Initialized
INFO - 2017-03-16 02:24:39 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:24:39 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:24:39 --> Utf8 Class Initialized
INFO - 2017-03-16 02:24:39 --> URI Class Initialized
DEBUG - 2017-03-16 02:24:39 --> No URI present. Default controller set.
INFO - 2017-03-16 02:24:39 --> Router Class Initialized
INFO - 2017-03-16 02:24:39 --> Output Class Initialized
INFO - 2017-03-16 02:24:39 --> Security Class Initialized
DEBUG - 2017-03-16 02:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:24:39 --> Input Class Initialized
INFO - 2017-03-16 02:24:39 --> Language Class Initialized
INFO - 2017-03-16 02:24:39 --> Loader Class Initialized
INFO - 2017-03-16 02:24:39 --> Database Driver Class Initialized
INFO - 2017-03-16 02:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:24:40 --> Controller Class Initialized
INFO - 2017-03-16 02:24:40 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:24:40 --> Final output sent to browser
DEBUG - 2017-03-16 02:24:40 --> Total execution time: 1.4876
INFO - 2017-03-16 02:26:50 --> Config Class Initialized
INFO - 2017-03-16 02:26:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:26:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:26:50 --> Utf8 Class Initialized
INFO - 2017-03-16 02:26:50 --> URI Class Initialized
DEBUG - 2017-03-16 02:26:50 --> No URI present. Default controller set.
INFO - 2017-03-16 02:26:50 --> Router Class Initialized
INFO - 2017-03-16 02:26:50 --> Output Class Initialized
INFO - 2017-03-16 02:26:50 --> Security Class Initialized
DEBUG - 2017-03-16 02:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:26:50 --> Input Class Initialized
INFO - 2017-03-16 02:26:50 --> Language Class Initialized
INFO - 2017-03-16 02:26:50 --> Loader Class Initialized
INFO - 2017-03-16 02:26:50 --> Database Driver Class Initialized
INFO - 2017-03-16 02:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:26:50 --> Controller Class Initialized
INFO - 2017-03-16 02:26:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:26:50 --> Final output sent to browser
DEBUG - 2017-03-16 02:26:50 --> Total execution time: 0.0134
INFO - 2017-03-16 02:29:33 --> Config Class Initialized
INFO - 2017-03-16 02:29:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:29:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:29:33 --> Utf8 Class Initialized
INFO - 2017-03-16 02:29:33 --> URI Class Initialized
DEBUG - 2017-03-16 02:29:33 --> No URI present. Default controller set.
INFO - 2017-03-16 02:29:33 --> Router Class Initialized
INFO - 2017-03-16 02:29:33 --> Output Class Initialized
INFO - 2017-03-16 02:29:33 --> Security Class Initialized
DEBUG - 2017-03-16 02:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:29:33 --> Input Class Initialized
INFO - 2017-03-16 02:29:33 --> Language Class Initialized
INFO - 2017-03-16 02:29:33 --> Loader Class Initialized
INFO - 2017-03-16 02:29:33 --> Database Driver Class Initialized
INFO - 2017-03-16 02:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:29:33 --> Controller Class Initialized
INFO - 2017-03-16 02:29:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:29:33 --> Final output sent to browser
DEBUG - 2017-03-16 02:29:33 --> Total execution time: 0.0639
INFO - 2017-03-16 02:31:33 --> Config Class Initialized
INFO - 2017-03-16 02:31:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:31:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:31:33 --> Utf8 Class Initialized
INFO - 2017-03-16 02:31:33 --> URI Class Initialized
DEBUG - 2017-03-16 02:31:33 --> No URI present. Default controller set.
INFO - 2017-03-16 02:31:33 --> Router Class Initialized
INFO - 2017-03-16 02:31:33 --> Output Class Initialized
INFO - 2017-03-16 02:31:33 --> Security Class Initialized
DEBUG - 2017-03-16 02:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:31:33 --> Input Class Initialized
INFO - 2017-03-16 02:31:33 --> Language Class Initialized
INFO - 2017-03-16 02:31:33 --> Loader Class Initialized
INFO - 2017-03-16 02:31:34 --> Database Driver Class Initialized
INFO - 2017-03-16 02:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:31:34 --> Controller Class Initialized
INFO - 2017-03-16 02:31:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:31:34 --> Final output sent to browser
DEBUG - 2017-03-16 02:31:34 --> Total execution time: 1.4815
INFO - 2017-03-16 02:32:43 --> Config Class Initialized
INFO - 2017-03-16 02:32:43 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:32:43 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:32:43 --> Utf8 Class Initialized
INFO - 2017-03-16 02:32:43 --> URI Class Initialized
INFO - 2017-03-16 02:32:43 --> Router Class Initialized
INFO - 2017-03-16 02:32:43 --> Output Class Initialized
INFO - 2017-03-16 02:32:43 --> Security Class Initialized
DEBUG - 2017-03-16 02:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:32:43 --> Input Class Initialized
INFO - 2017-03-16 02:32:43 --> Language Class Initialized
INFO - 2017-03-16 02:32:43 --> Loader Class Initialized
INFO - 2017-03-16 02:32:43 --> Database Driver Class Initialized
INFO - 2017-03-16 02:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:32:43 --> Controller Class Initialized
INFO - 2017-03-16 02:32:43 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:32:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 02:32:45 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 02:32:45 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jose Guadalupe Hurtado Martinez')
INFO - 2017-03-16 02:32:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 02:32:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 02:32:45 --> Config Class Initialized
INFO - 2017-03-16 02:32:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:32:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:32:45 --> Utf8 Class Initialized
INFO - 2017-03-16 02:32:45 --> URI Class Initialized
INFO - 2017-03-16 02:32:45 --> Router Class Initialized
INFO - 2017-03-16 02:32:45 --> Output Class Initialized
INFO - 2017-03-16 02:32:45 --> Security Class Initialized
DEBUG - 2017-03-16 02:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:32:46 --> Input Class Initialized
INFO - 2017-03-16 02:32:46 --> Language Class Initialized
INFO - 2017-03-16 02:32:46 --> Loader Class Initialized
INFO - 2017-03-16 02:32:46 --> Database Driver Class Initialized
INFO - 2017-03-16 02:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:32:46 --> Controller Class Initialized
INFO - 2017-03-16 02:32:46 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:32:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:32:46 --> Final output sent to browser
DEBUG - 2017-03-16 02:32:46 --> Total execution time: 0.1666
INFO - 2017-03-16 02:32:46 --> Config Class Initialized
INFO - 2017-03-16 02:32:46 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:32:46 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:32:46 --> Utf8 Class Initialized
INFO - 2017-03-16 02:32:46 --> URI Class Initialized
INFO - 2017-03-16 02:32:46 --> Router Class Initialized
INFO - 2017-03-16 02:32:46 --> Output Class Initialized
INFO - 2017-03-16 02:32:46 --> Security Class Initialized
DEBUG - 2017-03-16 02:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:32:46 --> Input Class Initialized
INFO - 2017-03-16 02:32:46 --> Language Class Initialized
INFO - 2017-03-16 02:32:46 --> Loader Class Initialized
INFO - 2017-03-16 02:32:46 --> Database Driver Class Initialized
INFO - 2017-03-16 02:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:32:46 --> Controller Class Initialized
INFO - 2017-03-16 02:32:46 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:32:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:32:46 --> Final output sent to browser
DEBUG - 2017-03-16 02:32:46 --> Total execution time: 0.0133
INFO - 2017-03-16 02:33:02 --> Config Class Initialized
INFO - 2017-03-16 02:33:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:33:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:33:02 --> Utf8 Class Initialized
INFO - 2017-03-16 02:33:02 --> URI Class Initialized
INFO - 2017-03-16 02:33:02 --> Router Class Initialized
INFO - 2017-03-16 02:33:02 --> Output Class Initialized
INFO - 2017-03-16 02:33:02 --> Security Class Initialized
DEBUG - 2017-03-16 02:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:33:06 --> Input Class Initialized
INFO - 2017-03-16 02:33:06 --> Language Class Initialized
INFO - 2017-03-16 02:33:06 --> Loader Class Initialized
INFO - 2017-03-16 02:33:06 --> Database Driver Class Initialized
INFO - 2017-03-16 02:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:33:06 --> Controller Class Initialized
INFO - 2017-03-16 02:33:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:33:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 02:33:07 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 02:33:07 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jose Guadalupe Hurtado Martinez')
INFO - 2017-03-16 02:33:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 02:33:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 02:33:13 --> Config Class Initialized
INFO - 2017-03-16 02:33:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:33:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:33:13 --> Utf8 Class Initialized
INFO - 2017-03-16 02:33:13 --> URI Class Initialized
INFO - 2017-03-16 02:33:13 --> Router Class Initialized
INFO - 2017-03-16 02:33:13 --> Output Class Initialized
INFO - 2017-03-16 02:33:13 --> Security Class Initialized
DEBUG - 2017-03-16 02:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:33:13 --> Input Class Initialized
INFO - 2017-03-16 02:33:13 --> Language Class Initialized
INFO - 2017-03-16 02:33:13 --> Loader Class Initialized
INFO - 2017-03-16 02:33:13 --> Database Driver Class Initialized
INFO - 2017-03-16 02:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:33:13 --> Controller Class Initialized
INFO - 2017-03-16 02:33:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:33:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 02:33:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 02:33:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jose Guadalupe Hurtado Martinez')
INFO - 2017-03-16 02:33:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 02:33:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 02:33:14 --> Config Class Initialized
INFO - 2017-03-16 02:33:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:33:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:33:14 --> Utf8 Class Initialized
INFO - 2017-03-16 02:33:14 --> URI Class Initialized
INFO - 2017-03-16 02:33:14 --> Router Class Initialized
INFO - 2017-03-16 02:33:14 --> Output Class Initialized
INFO - 2017-03-16 02:33:14 --> Security Class Initialized
DEBUG - 2017-03-16 02:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:33:14 --> Input Class Initialized
INFO - 2017-03-16 02:33:14 --> Language Class Initialized
INFO - 2017-03-16 02:33:14 --> Loader Class Initialized
INFO - 2017-03-16 02:33:14 --> Database Driver Class Initialized
INFO - 2017-03-16 02:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:33:14 --> Controller Class Initialized
INFO - 2017-03-16 02:33:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:33:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 02:33:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 02:33:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jose Guadalupe Hurtado Martinez')
INFO - 2017-03-16 02:33:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 02:33:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 02:33:25 --> Config Class Initialized
INFO - 2017-03-16 02:33:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:33:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:33:25 --> Utf8 Class Initialized
INFO - 2017-03-16 02:33:25 --> URI Class Initialized
INFO - 2017-03-16 02:33:25 --> Router Class Initialized
INFO - 2017-03-16 02:33:25 --> Output Class Initialized
INFO - 2017-03-16 02:33:25 --> Security Class Initialized
DEBUG - 2017-03-16 02:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:33:25 --> Input Class Initialized
INFO - 2017-03-16 02:33:25 --> Language Class Initialized
INFO - 2017-03-16 02:33:26 --> Loader Class Initialized
INFO - 2017-03-16 02:33:26 --> Database Driver Class Initialized
INFO - 2017-03-16 02:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:33:26 --> Controller Class Initialized
INFO - 2017-03-16 02:33:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:33:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 02:33:26 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 02:33:26 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jose Guadalupe Hurtado Martinez')
INFO - 2017-03-16 02:33:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 02:33:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 02:33:27 --> Config Class Initialized
INFO - 2017-03-16 02:33:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:33:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:33:27 --> Utf8 Class Initialized
INFO - 2017-03-16 02:33:27 --> URI Class Initialized
INFO - 2017-03-16 02:33:27 --> Router Class Initialized
INFO - 2017-03-16 02:33:27 --> Output Class Initialized
INFO - 2017-03-16 02:33:27 --> Security Class Initialized
DEBUG - 2017-03-16 02:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:33:27 --> Input Class Initialized
INFO - 2017-03-16 02:33:27 --> Language Class Initialized
INFO - 2017-03-16 02:33:27 --> Loader Class Initialized
INFO - 2017-03-16 02:33:27 --> Database Driver Class Initialized
INFO - 2017-03-16 02:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:33:27 --> Controller Class Initialized
INFO - 2017-03-16 02:33:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:33:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 02:33:28 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 02:33:28 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jose Guadalupe Hurtado Martinez')
INFO - 2017-03-16 02:33:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 02:33:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 02:33:37 --> Config Class Initialized
INFO - 2017-03-16 02:33:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:33:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:33:37 --> Utf8 Class Initialized
INFO - 2017-03-16 02:33:37 --> URI Class Initialized
DEBUG - 2017-03-16 02:33:38 --> No URI present. Default controller set.
INFO - 2017-03-16 02:33:38 --> Router Class Initialized
INFO - 2017-03-16 02:33:38 --> Output Class Initialized
INFO - 2017-03-16 02:33:38 --> Security Class Initialized
DEBUG - 2017-03-16 02:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:33:38 --> Input Class Initialized
INFO - 2017-03-16 02:33:38 --> Language Class Initialized
INFO - 2017-03-16 02:33:38 --> Loader Class Initialized
INFO - 2017-03-16 02:33:38 --> Database Driver Class Initialized
INFO - 2017-03-16 02:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:33:38 --> Controller Class Initialized
INFO - 2017-03-16 02:33:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:33:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:33:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:33:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:33:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:33:39 --> Final output sent to browser
DEBUG - 2017-03-16 02:33:39 --> Total execution time: 1.2180
INFO - 2017-03-16 02:33:44 --> Config Class Initialized
INFO - 2017-03-16 02:33:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:33:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:33:44 --> Utf8 Class Initialized
INFO - 2017-03-16 02:33:44 --> URI Class Initialized
INFO - 2017-03-16 02:33:44 --> Router Class Initialized
INFO - 2017-03-16 02:33:44 --> Output Class Initialized
INFO - 2017-03-16 02:33:44 --> Security Class Initialized
DEBUG - 2017-03-16 02:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:33:44 --> Input Class Initialized
INFO - 2017-03-16 02:33:44 --> Language Class Initialized
INFO - 2017-03-16 02:33:44 --> Loader Class Initialized
INFO - 2017-03-16 02:33:45 --> Database Driver Class Initialized
INFO - 2017-03-16 02:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:33:45 --> Controller Class Initialized
INFO - 2017-03-16 02:33:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:33:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 02:33:47 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 02:33:48 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jose Guadalupe Hurtado Martinez')
INFO - 2017-03-16 02:33:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 02:33:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 02:34:05 --> Config Class Initialized
INFO - 2017-03-16 02:34:05 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:34:05 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:34:05 --> Utf8 Class Initialized
INFO - 2017-03-16 02:34:05 --> URI Class Initialized
DEBUG - 2017-03-16 02:34:05 --> No URI present. Default controller set.
INFO - 2017-03-16 02:34:05 --> Router Class Initialized
INFO - 2017-03-16 02:34:05 --> Output Class Initialized
INFO - 2017-03-16 02:34:05 --> Security Class Initialized
DEBUG - 2017-03-16 02:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:34:05 --> Input Class Initialized
INFO - 2017-03-16 02:34:05 --> Language Class Initialized
INFO - 2017-03-16 02:34:05 --> Loader Class Initialized
INFO - 2017-03-16 02:34:05 --> Database Driver Class Initialized
INFO - 2017-03-16 02:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:34:06 --> Controller Class Initialized
INFO - 2017-03-16 02:34:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:34:06 --> Final output sent to browser
DEBUG - 2017-03-16 02:34:06 --> Total execution time: 1.4926
INFO - 2017-03-16 02:36:15 --> Config Class Initialized
INFO - 2017-03-16 02:36:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:36:16 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:36:16 --> Utf8 Class Initialized
INFO - 2017-03-16 02:36:16 --> URI Class Initialized
DEBUG - 2017-03-16 02:36:16 --> No URI present. Default controller set.
INFO - 2017-03-16 02:36:16 --> Router Class Initialized
INFO - 2017-03-16 02:36:16 --> Output Class Initialized
INFO - 2017-03-16 02:36:16 --> Security Class Initialized
DEBUG - 2017-03-16 02:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:36:16 --> Input Class Initialized
INFO - 2017-03-16 02:36:16 --> Language Class Initialized
INFO - 2017-03-16 02:36:16 --> Loader Class Initialized
INFO - 2017-03-16 02:36:16 --> Database Driver Class Initialized
INFO - 2017-03-16 02:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:36:16 --> Controller Class Initialized
INFO - 2017-03-16 02:36:16 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:36:17 --> Final output sent to browser
DEBUG - 2017-03-16 02:36:17 --> Total execution time: 1.2112
INFO - 2017-03-16 02:36:26 --> Config Class Initialized
INFO - 2017-03-16 02:36:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:36:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:36:26 --> Utf8 Class Initialized
INFO - 2017-03-16 02:36:26 --> URI Class Initialized
INFO - 2017-03-16 02:36:26 --> Router Class Initialized
INFO - 2017-03-16 02:36:26 --> Output Class Initialized
INFO - 2017-03-16 02:36:26 --> Security Class Initialized
DEBUG - 2017-03-16 02:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:36:26 --> Input Class Initialized
INFO - 2017-03-16 02:36:26 --> Language Class Initialized
INFO - 2017-03-16 02:36:26 --> Loader Class Initialized
INFO - 2017-03-16 02:36:26 --> Database Driver Class Initialized
INFO - 2017-03-16 02:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:36:26 --> Controller Class Initialized
INFO - 2017-03-16 02:36:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:36:28 --> Config Class Initialized
INFO - 2017-03-16 02:36:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:36:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:36:28 --> Utf8 Class Initialized
INFO - 2017-03-16 02:36:28 --> URI Class Initialized
INFO - 2017-03-16 02:36:28 --> Router Class Initialized
INFO - 2017-03-16 02:36:28 --> Output Class Initialized
INFO - 2017-03-16 02:36:28 --> Security Class Initialized
DEBUG - 2017-03-16 02:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:36:28 --> Input Class Initialized
INFO - 2017-03-16 02:36:28 --> Language Class Initialized
INFO - 2017-03-16 02:36:28 --> Loader Class Initialized
INFO - 2017-03-16 02:36:28 --> Database Driver Class Initialized
INFO - 2017-03-16 02:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:36:28 --> Controller Class Initialized
INFO - 2017-03-16 02:36:28 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:36:28 --> Helper loaded: url_helper
INFO - 2017-03-16 02:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:36:28 --> Final output sent to browser
DEBUG - 2017-03-16 02:36:28 --> Total execution time: 0.5233
INFO - 2017-03-16 02:38:27 --> Config Class Initialized
INFO - 2017-03-16 02:38:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:38:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:38:27 --> Utf8 Class Initialized
INFO - 2017-03-16 02:38:27 --> URI Class Initialized
DEBUG - 2017-03-16 02:38:27 --> No URI present. Default controller set.
INFO - 2017-03-16 02:38:27 --> Router Class Initialized
INFO - 2017-03-16 02:38:28 --> Output Class Initialized
INFO - 2017-03-16 02:38:28 --> Security Class Initialized
DEBUG - 2017-03-16 02:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:38:28 --> Input Class Initialized
INFO - 2017-03-16 02:38:28 --> Language Class Initialized
INFO - 2017-03-16 02:38:28 --> Loader Class Initialized
INFO - 2017-03-16 02:38:28 --> Database Driver Class Initialized
INFO - 2017-03-16 02:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:38:28 --> Controller Class Initialized
INFO - 2017-03-16 02:38:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:38:29 --> Final output sent to browser
DEBUG - 2017-03-16 02:38:29 --> Total execution time: 1.6517
INFO - 2017-03-16 02:47:59 --> Config Class Initialized
INFO - 2017-03-16 02:47:59 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:47:59 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:47:59 --> Utf8 Class Initialized
INFO - 2017-03-16 02:47:59 --> URI Class Initialized
DEBUG - 2017-03-16 02:47:59 --> No URI present. Default controller set.
INFO - 2017-03-16 02:47:59 --> Router Class Initialized
INFO - 2017-03-16 02:47:59 --> Output Class Initialized
INFO - 2017-03-16 02:47:59 --> Security Class Initialized
DEBUG - 2017-03-16 02:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:47:59 --> Input Class Initialized
INFO - 2017-03-16 02:47:59 --> Language Class Initialized
INFO - 2017-03-16 02:47:59 --> Loader Class Initialized
INFO - 2017-03-16 02:48:00 --> Database Driver Class Initialized
INFO - 2017-03-16 02:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:48:00 --> Controller Class Initialized
INFO - 2017-03-16 02:48:00 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:48:00 --> Config Class Initialized
INFO - 2017-03-16 02:48:00 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:48:00 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:48:00 --> Utf8 Class Initialized
INFO - 2017-03-16 02:48:00 --> URI Class Initialized
DEBUG - 2017-03-16 02:48:00 --> No URI present. Default controller set.
INFO - 2017-03-16 02:48:00 --> Router Class Initialized
INFO - 2017-03-16 02:48:00 --> Output Class Initialized
INFO - 2017-03-16 02:48:00 --> Security Class Initialized
DEBUG - 2017-03-16 02:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:48:00 --> Input Class Initialized
INFO - 2017-03-16 02:48:00 --> Language Class Initialized
INFO - 2017-03-16 02:48:00 --> Loader Class Initialized
INFO - 2017-03-16 02:48:00 --> Database Driver Class Initialized
INFO - 2017-03-16 02:48:00 --> Final output sent to browser
DEBUG - 2017-03-16 02:48:00 --> Total execution time: 1.4767
INFO - 2017-03-16 02:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:48:00 --> Controller Class Initialized
INFO - 2017-03-16 02:48:00 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:48:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:48:00 --> Final output sent to browser
DEBUG - 2017-03-16 02:48:00 --> Total execution time: 0.0158
INFO - 2017-03-16 02:52:12 --> Config Class Initialized
INFO - 2017-03-16 02:52:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:12 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:12 --> URI Class Initialized
DEBUG - 2017-03-16 02:52:12 --> No URI present. Default controller set.
INFO - 2017-03-16 02:52:12 --> Router Class Initialized
INFO - 2017-03-16 02:52:12 --> Output Class Initialized
INFO - 2017-03-16 02:52:12 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:12 --> Input Class Initialized
INFO - 2017-03-16 02:52:12 --> Language Class Initialized
INFO - 2017-03-16 02:52:12 --> Loader Class Initialized
INFO - 2017-03-16 02:52:12 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:13 --> Controller Class Initialized
INFO - 2017-03-16 02:52:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:52:13 --> Final output sent to browser
DEBUG - 2017-03-16 02:52:13 --> Total execution time: 1.4670
INFO - 2017-03-16 02:52:17 --> Config Class Initialized
INFO - 2017-03-16 02:52:17 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:17 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:17 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:17 --> URI Class Initialized
INFO - 2017-03-16 02:52:17 --> Router Class Initialized
INFO - 2017-03-16 02:52:17 --> Output Class Initialized
INFO - 2017-03-16 02:52:17 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:17 --> Input Class Initialized
INFO - 2017-03-16 02:52:17 --> Language Class Initialized
INFO - 2017-03-16 02:52:17 --> Loader Class Initialized
INFO - 2017-03-16 02:52:17 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:17 --> Controller Class Initialized
INFO - 2017-03-16 02:52:17 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:52:17 --> Final output sent to browser
DEBUG - 2017-03-16 02:52:17 --> Total execution time: 0.0143
INFO - 2017-03-16 02:52:23 --> Config Class Initialized
INFO - 2017-03-16 02:52:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:23 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:23 --> URI Class Initialized
INFO - 2017-03-16 02:52:23 --> Router Class Initialized
INFO - 2017-03-16 02:52:23 --> Output Class Initialized
INFO - 2017-03-16 02:52:23 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:23 --> Input Class Initialized
INFO - 2017-03-16 02:52:23 --> Language Class Initialized
INFO - 2017-03-16 02:52:23 --> Loader Class Initialized
INFO - 2017-03-16 02:52:23 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:23 --> Controller Class Initialized
INFO - 2017-03-16 02:52:23 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:25 --> Config Class Initialized
INFO - 2017-03-16 02:52:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:25 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:25 --> URI Class Initialized
INFO - 2017-03-16 02:52:25 --> Router Class Initialized
INFO - 2017-03-16 02:52:25 --> Output Class Initialized
INFO - 2017-03-16 02:52:25 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:25 --> Input Class Initialized
INFO - 2017-03-16 02:52:25 --> Language Class Initialized
INFO - 2017-03-16 02:52:25 --> Loader Class Initialized
INFO - 2017-03-16 02:52:26 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:26 --> Controller Class Initialized
INFO - 2017-03-16 02:52:26 --> Helper loaded: date_helper
DEBUG - 2017-03-16 02:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:26 --> Helper loaded: url_helper
INFO - 2017-03-16 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 02:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:52:26 --> Final output sent to browser
DEBUG - 2017-03-16 02:52:26 --> Total execution time: 0.8093
INFO - 2017-03-16 02:52:27 --> Config Class Initialized
INFO - 2017-03-16 02:52:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:27 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:27 --> URI Class Initialized
INFO - 2017-03-16 02:52:27 --> Router Class Initialized
INFO - 2017-03-16 02:52:27 --> Output Class Initialized
INFO - 2017-03-16 02:52:27 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:27 --> Input Class Initialized
INFO - 2017-03-16 02:52:27 --> Language Class Initialized
INFO - 2017-03-16 02:52:27 --> Loader Class Initialized
INFO - 2017-03-16 02:52:27 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:27 --> Controller Class Initialized
INFO - 2017-03-16 02:52:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:52:27 --> Final output sent to browser
DEBUG - 2017-03-16 02:52:27 --> Total execution time: 0.0573
INFO - 2017-03-16 02:52:33 --> Config Class Initialized
INFO - 2017-03-16 02:52:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:33 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:33 --> URI Class Initialized
DEBUG - 2017-03-16 02:52:33 --> No URI present. Default controller set.
INFO - 2017-03-16 02:52:33 --> Router Class Initialized
INFO - 2017-03-16 02:52:33 --> Output Class Initialized
INFO - 2017-03-16 02:52:33 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:33 --> Input Class Initialized
INFO - 2017-03-16 02:52:33 --> Language Class Initialized
INFO - 2017-03-16 02:52:33 --> Loader Class Initialized
INFO - 2017-03-16 02:52:33 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:33 --> Controller Class Initialized
INFO - 2017-03-16 02:52:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:52:34 --> Final output sent to browser
DEBUG - 2017-03-16 02:52:34 --> Total execution time: 0.6489
INFO - 2017-03-16 02:52:35 --> Config Class Initialized
INFO - 2017-03-16 02:52:35 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:35 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:35 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:35 --> URI Class Initialized
INFO - 2017-03-16 02:52:35 --> Router Class Initialized
INFO - 2017-03-16 02:52:35 --> Output Class Initialized
INFO - 2017-03-16 02:52:35 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:35 --> Input Class Initialized
INFO - 2017-03-16 02:52:35 --> Language Class Initialized
INFO - 2017-03-16 02:52:35 --> Loader Class Initialized
INFO - 2017-03-16 02:52:35 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:35 --> Controller Class Initialized
INFO - 2017-03-16 02:52:35 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:52:35 --> Final output sent to browser
DEBUG - 2017-03-16 02:52:35 --> Total execution time: 0.0201
INFO - 2017-03-16 02:52:55 --> Config Class Initialized
INFO - 2017-03-16 02:52:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:55 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:55 --> URI Class Initialized
INFO - 2017-03-16 02:52:55 --> Router Class Initialized
INFO - 2017-03-16 02:52:56 --> Output Class Initialized
INFO - 2017-03-16 02:52:56 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:56 --> Input Class Initialized
INFO - 2017-03-16 02:52:56 --> Language Class Initialized
INFO - 2017-03-16 02:52:56 --> Loader Class Initialized
INFO - 2017-03-16 02:52:56 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:56 --> Controller Class Initialized
INFO - 2017-03-16 02:52:56 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:52:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:52:57 --> Final output sent to browser
DEBUG - 2017-03-16 02:52:57 --> Total execution time: 1.2445
INFO - 2017-03-16 02:52:58 --> Config Class Initialized
INFO - 2017-03-16 02:52:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:52:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:52:58 --> Utf8 Class Initialized
INFO - 2017-03-16 02:52:58 --> URI Class Initialized
INFO - 2017-03-16 02:52:59 --> Router Class Initialized
INFO - 2017-03-16 02:52:59 --> Output Class Initialized
INFO - 2017-03-16 02:52:59 --> Security Class Initialized
DEBUG - 2017-03-16 02:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:52:59 --> Input Class Initialized
INFO - 2017-03-16 02:52:59 --> Language Class Initialized
INFO - 2017-03-16 02:52:59 --> Loader Class Initialized
INFO - 2017-03-16 02:52:59 --> Database Driver Class Initialized
INFO - 2017-03-16 02:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:52:59 --> Controller Class Initialized
INFO - 2017-03-16 02:52:59 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:53:00 --> Final output sent to browser
DEBUG - 2017-03-16 02:53:00 --> Total execution time: 1.2213
INFO - 2017-03-16 02:53:12 --> Config Class Initialized
INFO - 2017-03-16 02:53:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:53:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:53:12 --> Utf8 Class Initialized
INFO - 2017-03-16 02:53:12 --> URI Class Initialized
INFO - 2017-03-16 02:53:12 --> Router Class Initialized
INFO - 2017-03-16 02:53:12 --> Output Class Initialized
INFO - 2017-03-16 02:53:12 --> Security Class Initialized
DEBUG - 2017-03-16 02:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:53:12 --> Input Class Initialized
INFO - 2017-03-16 02:53:12 --> Language Class Initialized
INFO - 2017-03-16 02:53:12 --> Loader Class Initialized
INFO - 2017-03-16 02:53:12 --> Database Driver Class Initialized
INFO - 2017-03-16 02:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:53:12 --> Controller Class Initialized
INFO - 2017-03-16 02:53:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:53:12 --> Final output sent to browser
DEBUG - 2017-03-16 02:53:12 --> Total execution time: 0.0291
INFO - 2017-03-16 02:53:14 --> Config Class Initialized
INFO - 2017-03-16 02:53:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:53:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:53:14 --> Utf8 Class Initialized
INFO - 2017-03-16 02:53:14 --> URI Class Initialized
INFO - 2017-03-16 02:53:14 --> Router Class Initialized
INFO - 2017-03-16 02:53:14 --> Output Class Initialized
INFO - 2017-03-16 02:53:14 --> Security Class Initialized
DEBUG - 2017-03-16 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:53:14 --> Input Class Initialized
INFO - 2017-03-16 02:53:14 --> Language Class Initialized
INFO - 2017-03-16 02:53:14 --> Loader Class Initialized
INFO - 2017-03-16 02:53:14 --> Database Driver Class Initialized
INFO - 2017-03-16 02:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:53:14 --> Controller Class Initialized
INFO - 2017-03-16 02:53:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:53:14 --> Final output sent to browser
DEBUG - 2017-03-16 02:53:14 --> Total execution time: 0.0130
INFO - 2017-03-16 02:53:26 --> Config Class Initialized
INFO - 2017-03-16 02:53:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:53:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:53:26 --> Utf8 Class Initialized
INFO - 2017-03-16 02:53:26 --> URI Class Initialized
INFO - 2017-03-16 02:53:26 --> Router Class Initialized
INFO - 2017-03-16 02:53:26 --> Output Class Initialized
INFO - 2017-03-16 02:53:26 --> Security Class Initialized
DEBUG - 2017-03-16 02:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:53:26 --> Input Class Initialized
INFO - 2017-03-16 02:53:26 --> Language Class Initialized
INFO - 2017-03-16 02:53:26 --> Loader Class Initialized
INFO - 2017-03-16 02:53:26 --> Database Driver Class Initialized
INFO - 2017-03-16 02:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:53:26 --> Controller Class Initialized
INFO - 2017-03-16 02:53:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:53:26 --> Final output sent to browser
DEBUG - 2017-03-16 02:53:26 --> Total execution time: 0.0139
INFO - 2017-03-16 02:53:27 --> Config Class Initialized
INFO - 2017-03-16 02:53:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:53:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:53:27 --> Utf8 Class Initialized
INFO - 2017-03-16 02:53:27 --> URI Class Initialized
INFO - 2017-03-16 02:53:27 --> Router Class Initialized
INFO - 2017-03-16 02:53:27 --> Output Class Initialized
INFO - 2017-03-16 02:53:27 --> Security Class Initialized
DEBUG - 2017-03-16 02:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:53:27 --> Input Class Initialized
INFO - 2017-03-16 02:53:27 --> Language Class Initialized
INFO - 2017-03-16 02:53:27 --> Loader Class Initialized
INFO - 2017-03-16 02:53:27 --> Database Driver Class Initialized
INFO - 2017-03-16 02:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:53:27 --> Controller Class Initialized
INFO - 2017-03-16 02:53:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:53:27 --> Final output sent to browser
DEBUG - 2017-03-16 02:53:27 --> Total execution time: 0.0135
INFO - 2017-03-16 02:53:38 --> Config Class Initialized
INFO - 2017-03-16 02:53:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 02:53:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 02:53:38 --> Utf8 Class Initialized
INFO - 2017-03-16 02:53:38 --> URI Class Initialized
INFO - 2017-03-16 02:53:38 --> Router Class Initialized
INFO - 2017-03-16 02:53:38 --> Output Class Initialized
INFO - 2017-03-16 02:53:38 --> Security Class Initialized
DEBUG - 2017-03-16 02:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 02:53:38 --> Input Class Initialized
INFO - 2017-03-16 02:53:38 --> Language Class Initialized
INFO - 2017-03-16 02:53:38 --> Loader Class Initialized
INFO - 2017-03-16 02:53:38 --> Database Driver Class Initialized
INFO - 2017-03-16 02:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 02:53:38 --> Controller Class Initialized
INFO - 2017-03-16 02:53:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 02:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 02:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 02:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 02:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 02:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 02:53:38 --> Final output sent to browser
DEBUG - 2017-03-16 02:53:38 --> Total execution time: 0.0143
INFO - 2017-03-16 03:00:33 --> Config Class Initialized
INFO - 2017-03-16 03:00:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:00:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:00:33 --> Utf8 Class Initialized
INFO - 2017-03-16 03:00:33 --> URI Class Initialized
INFO - 2017-03-16 03:00:33 --> Router Class Initialized
INFO - 2017-03-16 03:00:33 --> Output Class Initialized
INFO - 2017-03-16 03:00:33 --> Security Class Initialized
DEBUG - 2017-03-16 03:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:00:33 --> Input Class Initialized
INFO - 2017-03-16 03:00:33 --> Language Class Initialized
INFO - 2017-03-16 03:00:33 --> Loader Class Initialized
INFO - 2017-03-16 03:00:34 --> Database Driver Class Initialized
INFO - 2017-03-16 03:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:00:34 --> Controller Class Initialized
INFO - 2017-03-16 03:00:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:00:36 --> Config Class Initialized
INFO - 2017-03-16 03:00:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:00:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:00:36 --> Utf8 Class Initialized
INFO - 2017-03-16 03:00:36 --> URI Class Initialized
INFO - 2017-03-16 03:00:36 --> Router Class Initialized
INFO - 2017-03-16 03:00:36 --> Output Class Initialized
INFO - 2017-03-16 03:00:36 --> Security Class Initialized
DEBUG - 2017-03-16 03:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:00:36 --> Input Class Initialized
INFO - 2017-03-16 03:00:36 --> Language Class Initialized
INFO - 2017-03-16 03:00:36 --> Loader Class Initialized
INFO - 2017-03-16 03:00:36 --> Database Driver Class Initialized
INFO - 2017-03-16 03:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:00:36 --> Controller Class Initialized
INFO - 2017-03-16 03:00:36 --> Helper loaded: date_helper
DEBUG - 2017-03-16 03:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:00:36 --> Helper loaded: url_helper
INFO - 2017-03-16 03:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 03:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 03:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 03:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:00:36 --> Final output sent to browser
DEBUG - 2017-03-16 03:00:36 --> Total execution time: 0.1425
INFO - 2017-03-16 03:00:37 --> Config Class Initialized
INFO - 2017-03-16 03:00:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:00:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:00:37 --> Utf8 Class Initialized
INFO - 2017-03-16 03:00:37 --> URI Class Initialized
INFO - 2017-03-16 03:00:37 --> Router Class Initialized
INFO - 2017-03-16 03:00:37 --> Output Class Initialized
INFO - 2017-03-16 03:00:37 --> Security Class Initialized
DEBUG - 2017-03-16 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:00:37 --> Input Class Initialized
INFO - 2017-03-16 03:00:37 --> Language Class Initialized
INFO - 2017-03-16 03:00:37 --> Loader Class Initialized
INFO - 2017-03-16 03:00:37 --> Database Driver Class Initialized
INFO - 2017-03-16 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:00:37 --> Controller Class Initialized
INFO - 2017-03-16 03:00:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:00:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:00:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:00:38 --> Final output sent to browser
DEBUG - 2017-03-16 03:00:38 --> Total execution time: 0.5913
INFO - 2017-03-16 03:25:40 --> Config Class Initialized
INFO - 2017-03-16 03:25:40 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:25:40 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:25:40 --> Utf8 Class Initialized
INFO - 2017-03-16 03:25:40 --> URI Class Initialized
DEBUG - 2017-03-16 03:25:40 --> No URI present. Default controller set.
INFO - 2017-03-16 03:25:40 --> Router Class Initialized
INFO - 2017-03-16 03:25:40 --> Output Class Initialized
INFO - 2017-03-16 03:25:40 --> Security Class Initialized
DEBUG - 2017-03-16 03:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:25:40 --> Input Class Initialized
INFO - 2017-03-16 03:25:40 --> Language Class Initialized
INFO - 2017-03-16 03:25:40 --> Loader Class Initialized
INFO - 2017-03-16 03:25:41 --> Database Driver Class Initialized
INFO - 2017-03-16 03:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:25:41 --> Controller Class Initialized
INFO - 2017-03-16 03:25:41 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:25:41 --> Final output sent to browser
DEBUG - 2017-03-16 03:25:41 --> Total execution time: 1.2293
INFO - 2017-03-16 03:29:12 --> Config Class Initialized
INFO - 2017-03-16 03:29:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:29:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:29:13 --> Utf8 Class Initialized
INFO - 2017-03-16 03:29:13 --> URI Class Initialized
INFO - 2017-03-16 03:29:13 --> Router Class Initialized
INFO - 2017-03-16 03:29:13 --> Output Class Initialized
INFO - 2017-03-16 03:29:13 --> Security Class Initialized
DEBUG - 2017-03-16 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:29:13 --> Input Class Initialized
INFO - 2017-03-16 03:29:13 --> Language Class Initialized
INFO - 2017-03-16 03:29:13 --> Loader Class Initialized
INFO - 2017-03-16 03:29:13 --> Database Driver Class Initialized
INFO - 2017-03-16 03:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:29:13 --> Controller Class Initialized
INFO - 2017-03-16 03:29:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:29:14 --> Final output sent to browser
DEBUG - 2017-03-16 03:29:14 --> Total execution time: 1.2377
INFO - 2017-03-16 03:30:08 --> Config Class Initialized
INFO - 2017-03-16 03:30:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:30:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:30:08 --> Utf8 Class Initialized
INFO - 2017-03-16 03:30:08 --> URI Class Initialized
INFO - 2017-03-16 03:30:08 --> Router Class Initialized
INFO - 2017-03-16 03:30:08 --> Output Class Initialized
INFO - 2017-03-16 03:30:08 --> Security Class Initialized
DEBUG - 2017-03-16 03:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:30:08 --> Input Class Initialized
INFO - 2017-03-16 03:30:08 --> Language Class Initialized
INFO - 2017-03-16 03:30:08 --> Loader Class Initialized
INFO - 2017-03-16 03:30:09 --> Database Driver Class Initialized
INFO - 2017-03-16 03:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:30:09 --> Controller Class Initialized
INFO - 2017-03-16 03:30:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:30:09 --> Final output sent to browser
DEBUG - 2017-03-16 03:30:09 --> Total execution time: 1.2372
INFO - 2017-03-16 03:30:25 --> Config Class Initialized
INFO - 2017-03-16 03:30:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:30:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:30:25 --> Utf8 Class Initialized
INFO - 2017-03-16 03:30:25 --> URI Class Initialized
INFO - 2017-03-16 03:30:25 --> Router Class Initialized
INFO - 2017-03-16 03:30:25 --> Output Class Initialized
INFO - 2017-03-16 03:30:25 --> Security Class Initialized
DEBUG - 2017-03-16 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:30:25 --> Input Class Initialized
INFO - 2017-03-16 03:30:25 --> Language Class Initialized
INFO - 2017-03-16 03:30:26 --> Loader Class Initialized
INFO - 2017-03-16 03:30:26 --> Database Driver Class Initialized
INFO - 2017-03-16 03:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:30:26 --> Controller Class Initialized
INFO - 2017-03-16 03:30:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:30:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:30:28 --> Config Class Initialized
INFO - 2017-03-16 03:30:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:30:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:30:29 --> Utf8 Class Initialized
INFO - 2017-03-16 03:30:29 --> URI Class Initialized
INFO - 2017-03-16 03:30:29 --> Router Class Initialized
INFO - 2017-03-16 03:30:29 --> Output Class Initialized
INFO - 2017-03-16 03:30:29 --> Security Class Initialized
DEBUG - 2017-03-16 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:30:29 --> Input Class Initialized
INFO - 2017-03-16 03:30:29 --> Language Class Initialized
INFO - 2017-03-16 03:30:29 --> Loader Class Initialized
INFO - 2017-03-16 03:30:29 --> Database Driver Class Initialized
INFO - 2017-03-16 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:30:29 --> Controller Class Initialized
INFO - 2017-03-16 03:30:29 --> Helper loaded: date_helper
DEBUG - 2017-03-16 03:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:30:29 --> Helper loaded: url_helper
INFO - 2017-03-16 03:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 03:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 03:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 03:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:30:29 --> Final output sent to browser
DEBUG - 2017-03-16 03:30:29 --> Total execution time: 1.1064
INFO - 2017-03-16 03:30:46 --> Config Class Initialized
INFO - 2017-03-16 03:30:46 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:30:46 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:30:46 --> Utf8 Class Initialized
INFO - 2017-03-16 03:30:46 --> URI Class Initialized
DEBUG - 2017-03-16 03:30:47 --> No URI present. Default controller set.
INFO - 2017-03-16 03:30:47 --> Router Class Initialized
INFO - 2017-03-16 03:30:47 --> Output Class Initialized
INFO - 2017-03-16 03:30:47 --> Security Class Initialized
DEBUG - 2017-03-16 03:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:30:47 --> Input Class Initialized
INFO - 2017-03-16 03:30:47 --> Language Class Initialized
INFO - 2017-03-16 03:30:47 --> Loader Class Initialized
INFO - 2017-03-16 03:30:47 --> Database Driver Class Initialized
INFO - 2017-03-16 03:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:30:47 --> Controller Class Initialized
INFO - 2017-03-16 03:30:47 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:30:48 --> Final output sent to browser
DEBUG - 2017-03-16 03:30:48 --> Total execution time: 1.2597
INFO - 2017-03-16 03:31:44 --> Config Class Initialized
INFO - 2017-03-16 03:31:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:31:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:31:44 --> Utf8 Class Initialized
INFO - 2017-03-16 03:31:44 --> URI Class Initialized
INFO - 2017-03-16 03:31:44 --> Router Class Initialized
INFO - 2017-03-16 03:31:44 --> Output Class Initialized
INFO - 2017-03-16 03:31:44 --> Security Class Initialized
DEBUG - 2017-03-16 03:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:31:44 --> Input Class Initialized
INFO - 2017-03-16 03:31:44 --> Language Class Initialized
INFO - 2017-03-16 03:31:44 --> Loader Class Initialized
INFO - 2017-03-16 03:31:44 --> Database Driver Class Initialized
INFO - 2017-03-16 03:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:31:44 --> Controller Class Initialized
INFO - 2017-03-16 03:31:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:31:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:31:46 --> Config Class Initialized
INFO - 2017-03-16 03:31:46 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:31:46 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:31:46 --> Utf8 Class Initialized
INFO - 2017-03-16 03:31:46 --> URI Class Initialized
INFO - 2017-03-16 03:31:46 --> Router Class Initialized
INFO - 2017-03-16 03:31:46 --> Output Class Initialized
INFO - 2017-03-16 03:31:46 --> Security Class Initialized
DEBUG - 2017-03-16 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:31:46 --> Input Class Initialized
INFO - 2017-03-16 03:31:46 --> Language Class Initialized
INFO - 2017-03-16 03:31:46 --> Loader Class Initialized
INFO - 2017-03-16 03:31:46 --> Database Driver Class Initialized
INFO - 2017-03-16 03:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:31:46 --> Controller Class Initialized
INFO - 2017-03-16 03:31:46 --> Helper loaded: date_helper
DEBUG - 2017-03-16 03:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:31:46 --> Helper loaded: url_helper
INFO - 2017-03-16 03:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 03:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 03:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 03:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:31:46 --> Final output sent to browser
DEBUG - 2017-03-16 03:31:46 --> Total execution time: 0.0868
INFO - 2017-03-16 03:32:38 --> Config Class Initialized
INFO - 2017-03-16 03:32:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:32:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:32:38 --> Utf8 Class Initialized
INFO - 2017-03-16 03:32:38 --> URI Class Initialized
DEBUG - 2017-03-16 03:32:38 --> No URI present. Default controller set.
INFO - 2017-03-16 03:32:38 --> Router Class Initialized
INFO - 2017-03-16 03:32:38 --> Output Class Initialized
INFO - 2017-03-16 03:32:38 --> Security Class Initialized
DEBUG - 2017-03-16 03:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:32:38 --> Input Class Initialized
INFO - 2017-03-16 03:32:38 --> Language Class Initialized
INFO - 2017-03-16 03:32:38 --> Loader Class Initialized
INFO - 2017-03-16 03:32:38 --> Database Driver Class Initialized
INFO - 2017-03-16 03:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:32:38 --> Controller Class Initialized
INFO - 2017-03-16 03:32:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:32:38 --> Final output sent to browser
DEBUG - 2017-03-16 03:32:38 --> Total execution time: 0.0131
INFO - 2017-03-16 03:33:24 --> Config Class Initialized
INFO - 2017-03-16 03:33:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:33:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:33:24 --> Utf8 Class Initialized
INFO - 2017-03-16 03:33:24 --> URI Class Initialized
INFO - 2017-03-16 03:33:24 --> Router Class Initialized
INFO - 2017-03-16 03:33:24 --> Output Class Initialized
INFO - 2017-03-16 03:33:24 --> Security Class Initialized
DEBUG - 2017-03-16 03:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:33:24 --> Input Class Initialized
INFO - 2017-03-16 03:33:24 --> Language Class Initialized
INFO - 2017-03-16 03:33:24 --> Loader Class Initialized
INFO - 2017-03-16 03:33:24 --> Database Driver Class Initialized
INFO - 2017-03-16 03:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:33:24 --> Controller Class Initialized
INFO - 2017-03-16 03:33:24 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:33:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:33:24 --> Final output sent to browser
DEBUG - 2017-03-16 03:33:24 --> Total execution time: 0.0144
INFO - 2017-03-16 03:34:07 --> Config Class Initialized
INFO - 2017-03-16 03:34:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:34:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:34:07 --> Utf8 Class Initialized
INFO - 2017-03-16 03:34:07 --> URI Class Initialized
INFO - 2017-03-16 03:34:07 --> Router Class Initialized
INFO - 2017-03-16 03:34:07 --> Output Class Initialized
INFO - 2017-03-16 03:34:07 --> Security Class Initialized
DEBUG - 2017-03-16 03:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:34:07 --> Input Class Initialized
INFO - 2017-03-16 03:34:07 --> Language Class Initialized
INFO - 2017-03-16 03:34:07 --> Loader Class Initialized
INFO - 2017-03-16 03:34:07 --> Database Driver Class Initialized
INFO - 2017-03-16 03:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:34:07 --> Controller Class Initialized
INFO - 2017-03-16 03:34:07 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:34:07 --> Final output sent to browser
DEBUG - 2017-03-16 03:34:07 --> Total execution time: 0.0138
INFO - 2017-03-16 03:34:09 --> Config Class Initialized
INFO - 2017-03-16 03:34:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:34:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:34:09 --> Utf8 Class Initialized
INFO - 2017-03-16 03:34:09 --> URI Class Initialized
INFO - 2017-03-16 03:34:09 --> Router Class Initialized
INFO - 2017-03-16 03:34:09 --> Output Class Initialized
INFO - 2017-03-16 03:34:09 --> Security Class Initialized
DEBUG - 2017-03-16 03:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:34:09 --> Input Class Initialized
INFO - 2017-03-16 03:34:09 --> Language Class Initialized
INFO - 2017-03-16 03:34:09 --> Loader Class Initialized
INFO - 2017-03-16 03:34:09 --> Database Driver Class Initialized
INFO - 2017-03-16 03:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:34:09 --> Controller Class Initialized
INFO - 2017-03-16 03:34:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:34:09 --> Final output sent to browser
DEBUG - 2017-03-16 03:34:09 --> Total execution time: 0.0702
INFO - 2017-03-16 03:34:54 --> Config Class Initialized
INFO - 2017-03-16 03:34:54 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:34:54 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:34:54 --> Utf8 Class Initialized
INFO - 2017-03-16 03:34:54 --> URI Class Initialized
INFO - 2017-03-16 03:34:54 --> Router Class Initialized
INFO - 2017-03-16 03:34:54 --> Output Class Initialized
INFO - 2017-03-16 03:34:54 --> Security Class Initialized
DEBUG - 2017-03-16 03:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:34:54 --> Input Class Initialized
INFO - 2017-03-16 03:34:54 --> Language Class Initialized
INFO - 2017-03-16 03:34:54 --> Loader Class Initialized
INFO - 2017-03-16 03:34:54 --> Database Driver Class Initialized
INFO - 2017-03-16 03:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:34:54 --> Controller Class Initialized
INFO - 2017-03-16 03:34:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:34:54 --> Final output sent to browser
DEBUG - 2017-03-16 03:34:54 --> Total execution time: 0.0145
INFO - 2017-03-16 03:34:55 --> Config Class Initialized
INFO - 2017-03-16 03:34:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:34:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:34:55 --> Utf8 Class Initialized
INFO - 2017-03-16 03:34:55 --> URI Class Initialized
INFO - 2017-03-16 03:34:55 --> Router Class Initialized
INFO - 2017-03-16 03:34:55 --> Output Class Initialized
INFO - 2017-03-16 03:34:55 --> Security Class Initialized
DEBUG - 2017-03-16 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:34:55 --> Input Class Initialized
INFO - 2017-03-16 03:34:55 --> Language Class Initialized
INFO - 2017-03-16 03:34:55 --> Loader Class Initialized
INFO - 2017-03-16 03:34:55 --> Database Driver Class Initialized
INFO - 2017-03-16 03:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:34:55 --> Controller Class Initialized
INFO - 2017-03-16 03:34:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:34:55 --> Final output sent to browser
DEBUG - 2017-03-16 03:34:55 --> Total execution time: 0.0140
INFO - 2017-03-16 03:35:58 --> Config Class Initialized
INFO - 2017-03-16 03:35:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:35:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:35:58 --> Utf8 Class Initialized
INFO - 2017-03-16 03:35:58 --> URI Class Initialized
INFO - 2017-03-16 03:35:58 --> Router Class Initialized
INFO - 2017-03-16 03:35:58 --> Output Class Initialized
INFO - 2017-03-16 03:35:58 --> Security Class Initialized
DEBUG - 2017-03-16 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:35:58 --> Input Class Initialized
INFO - 2017-03-16 03:35:58 --> Language Class Initialized
INFO - 2017-03-16 03:35:59 --> Loader Class Initialized
INFO - 2017-03-16 03:35:59 --> Database Driver Class Initialized
INFO - 2017-03-16 03:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:35:59 --> Controller Class Initialized
INFO - 2017-03-16 03:35:59 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:35:59 --> Final output sent to browser
DEBUG - 2017-03-16 03:35:59 --> Total execution time: 1.2599
INFO - 2017-03-16 03:36:00 --> Config Class Initialized
INFO - 2017-03-16 03:36:00 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:36:00 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:36:00 --> Utf8 Class Initialized
INFO - 2017-03-16 03:36:00 --> URI Class Initialized
DEBUG - 2017-03-16 03:36:00 --> No URI present. Default controller set.
INFO - 2017-03-16 03:36:00 --> Router Class Initialized
INFO - 2017-03-16 03:36:00 --> Output Class Initialized
INFO - 2017-03-16 03:36:00 --> Security Class Initialized
DEBUG - 2017-03-16 03:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:36:00 --> Input Class Initialized
INFO - 2017-03-16 03:36:00 --> Language Class Initialized
INFO - 2017-03-16 03:36:00 --> Loader Class Initialized
INFO - 2017-03-16 03:36:00 --> Database Driver Class Initialized
INFO - 2017-03-16 03:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:36:00 --> Controller Class Initialized
INFO - 2017-03-16 03:36:00 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:36:00 --> Final output sent to browser
DEBUG - 2017-03-16 03:36:00 --> Total execution time: 0.0142
INFO - 2017-03-16 03:36:17 --> Config Class Initialized
INFO - 2017-03-16 03:36:17 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:36:17 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:36:17 --> Utf8 Class Initialized
INFO - 2017-03-16 03:36:17 --> URI Class Initialized
INFO - 2017-03-16 03:36:17 --> Router Class Initialized
INFO - 2017-03-16 03:36:17 --> Output Class Initialized
INFO - 2017-03-16 03:36:17 --> Security Class Initialized
DEBUG - 2017-03-16 03:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:36:17 --> Input Class Initialized
INFO - 2017-03-16 03:36:17 --> Language Class Initialized
INFO - 2017-03-16 03:36:17 --> Loader Class Initialized
INFO - 2017-03-16 03:36:17 --> Database Driver Class Initialized
INFO - 2017-03-16 03:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:36:17 --> Controller Class Initialized
INFO - 2017-03-16 03:36:17 --> Helper loaded: date_helper
DEBUG - 2017-03-16 03:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:36:17 --> Helper loaded: url_helper
INFO - 2017-03-16 03:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 03:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 03:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 03:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:36:17 --> Final output sent to browser
DEBUG - 2017-03-16 03:36:17 --> Total execution time: 0.0976
INFO - 2017-03-16 03:36:20 --> Config Class Initialized
INFO - 2017-03-16 03:36:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:36:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:36:20 --> Utf8 Class Initialized
INFO - 2017-03-16 03:36:20 --> URI Class Initialized
INFO - 2017-03-16 03:36:20 --> Router Class Initialized
INFO - 2017-03-16 03:36:20 --> Output Class Initialized
INFO - 2017-03-16 03:36:20 --> Security Class Initialized
DEBUG - 2017-03-16 03:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:36:20 --> Input Class Initialized
INFO - 2017-03-16 03:36:20 --> Language Class Initialized
INFO - 2017-03-16 03:36:20 --> Loader Class Initialized
INFO - 2017-03-16 03:36:20 --> Database Driver Class Initialized
INFO - 2017-03-16 03:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:36:20 --> Controller Class Initialized
INFO - 2017-03-16 03:36:20 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:36:20 --> Final output sent to browser
DEBUG - 2017-03-16 03:36:20 --> Total execution time: 0.0135
INFO - 2017-03-16 03:36:26 --> Config Class Initialized
INFO - 2017-03-16 03:36:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:36:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:36:26 --> Utf8 Class Initialized
INFO - 2017-03-16 03:36:26 --> URI Class Initialized
INFO - 2017-03-16 03:36:26 --> Router Class Initialized
INFO - 2017-03-16 03:36:26 --> Output Class Initialized
INFO - 2017-03-16 03:36:26 --> Security Class Initialized
DEBUG - 2017-03-16 03:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:36:26 --> Input Class Initialized
INFO - 2017-03-16 03:36:26 --> Language Class Initialized
INFO - 2017-03-16 03:36:26 --> Loader Class Initialized
INFO - 2017-03-16 03:36:26 --> Database Driver Class Initialized
INFO - 2017-03-16 03:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:36:26 --> Controller Class Initialized
INFO - 2017-03-16 03:36:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:36:26 --> Final output sent to browser
DEBUG - 2017-03-16 03:36:26 --> Total execution time: 0.0401
INFO - 2017-03-16 03:36:27 --> Config Class Initialized
INFO - 2017-03-16 03:36:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:36:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:36:27 --> Utf8 Class Initialized
INFO - 2017-03-16 03:36:27 --> URI Class Initialized
INFO - 2017-03-16 03:36:27 --> Router Class Initialized
INFO - 2017-03-16 03:36:27 --> Output Class Initialized
INFO - 2017-03-16 03:36:27 --> Security Class Initialized
DEBUG - 2017-03-16 03:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:36:27 --> Input Class Initialized
INFO - 2017-03-16 03:36:27 --> Language Class Initialized
INFO - 2017-03-16 03:36:27 --> Loader Class Initialized
INFO - 2017-03-16 03:36:27 --> Database Driver Class Initialized
INFO - 2017-03-16 03:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:36:27 --> Controller Class Initialized
INFO - 2017-03-16 03:36:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:36:27 --> Final output sent to browser
DEBUG - 2017-03-16 03:36:27 --> Total execution time: 0.0136
INFO - 2017-03-16 03:36:44 --> Config Class Initialized
INFO - 2017-03-16 03:36:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:36:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:36:44 --> Utf8 Class Initialized
INFO - 2017-03-16 03:36:44 --> URI Class Initialized
DEBUG - 2017-03-16 03:36:44 --> No URI present. Default controller set.
INFO - 2017-03-16 03:36:44 --> Router Class Initialized
INFO - 2017-03-16 03:36:44 --> Output Class Initialized
INFO - 2017-03-16 03:36:44 --> Security Class Initialized
DEBUG - 2017-03-16 03:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:36:44 --> Input Class Initialized
INFO - 2017-03-16 03:36:44 --> Language Class Initialized
INFO - 2017-03-16 03:36:44 --> Loader Class Initialized
INFO - 2017-03-16 03:36:44 --> Database Driver Class Initialized
INFO - 2017-03-16 03:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:36:44 --> Controller Class Initialized
INFO - 2017-03-16 03:36:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:36:44 --> Final output sent to browser
DEBUG - 2017-03-16 03:36:44 --> Total execution time: 0.0130
INFO - 2017-03-16 03:36:53 --> Config Class Initialized
INFO - 2017-03-16 03:36:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:36:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:36:53 --> Utf8 Class Initialized
INFO - 2017-03-16 03:36:53 --> URI Class Initialized
INFO - 2017-03-16 03:36:53 --> Router Class Initialized
INFO - 2017-03-16 03:36:53 --> Output Class Initialized
INFO - 2017-03-16 03:36:53 --> Security Class Initialized
DEBUG - 2017-03-16 03:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:36:53 --> Input Class Initialized
INFO - 2017-03-16 03:36:53 --> Language Class Initialized
INFO - 2017-03-16 03:36:53 --> Loader Class Initialized
INFO - 2017-03-16 03:36:53 --> Database Driver Class Initialized
INFO - 2017-03-16 03:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:36:53 --> Controller Class Initialized
INFO - 2017-03-16 03:36:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-16 03:36:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-16 03:36:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-16 03:36:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-16 03:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:36:53 --> Final output sent to browser
DEBUG - 2017-03-16 03:36:53 --> Total execution time: 0.0375
INFO - 2017-03-16 03:39:27 --> Config Class Initialized
INFO - 2017-03-16 03:39:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:39:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:39:28 --> Utf8 Class Initialized
INFO - 2017-03-16 03:39:28 --> URI Class Initialized
INFO - 2017-03-16 03:39:28 --> Router Class Initialized
INFO - 2017-03-16 03:39:28 --> Output Class Initialized
INFO - 2017-03-16 03:39:28 --> Security Class Initialized
DEBUG - 2017-03-16 03:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:39:28 --> Input Class Initialized
INFO - 2017-03-16 03:39:28 --> Language Class Initialized
INFO - 2017-03-16 03:39:28 --> Loader Class Initialized
INFO - 2017-03-16 03:39:28 --> Database Driver Class Initialized
INFO - 2017-03-16 03:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:39:28 --> Controller Class Initialized
INFO - 2017-03-16 03:39:28 --> Helper loaded: date_helper
DEBUG - 2017-03-16 03:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:39:28 --> Helper loaded: url_helper
INFO - 2017-03-16 03:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 03:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 03:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 03:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:39:29 --> Final output sent to browser
DEBUG - 2017-03-16 03:39:29 --> Total execution time: 1.0886
INFO - 2017-03-16 03:41:32 --> Config Class Initialized
INFO - 2017-03-16 03:41:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:41:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:41:32 --> Utf8 Class Initialized
INFO - 2017-03-16 03:41:32 --> URI Class Initialized
DEBUG - 2017-03-16 03:41:33 --> No URI present. Default controller set.
INFO - 2017-03-16 03:41:33 --> Router Class Initialized
INFO - 2017-03-16 03:41:33 --> Output Class Initialized
INFO - 2017-03-16 03:41:33 --> Security Class Initialized
DEBUG - 2017-03-16 03:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:41:33 --> Input Class Initialized
INFO - 2017-03-16 03:41:33 --> Language Class Initialized
INFO - 2017-03-16 03:41:33 --> Loader Class Initialized
INFO - 2017-03-16 03:41:33 --> Database Driver Class Initialized
INFO - 2017-03-16 03:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:41:33 --> Controller Class Initialized
INFO - 2017-03-16 03:41:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:41:34 --> Final output sent to browser
DEBUG - 2017-03-16 03:41:34 --> Total execution time: 1.3907
INFO - 2017-03-16 03:41:36 --> Config Class Initialized
INFO - 2017-03-16 03:41:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:41:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:41:36 --> Utf8 Class Initialized
INFO - 2017-03-16 03:41:36 --> URI Class Initialized
INFO - 2017-03-16 03:41:36 --> Router Class Initialized
INFO - 2017-03-16 03:41:36 --> Output Class Initialized
INFO - 2017-03-16 03:41:36 --> Security Class Initialized
DEBUG - 2017-03-16 03:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:41:36 --> Input Class Initialized
INFO - 2017-03-16 03:41:36 --> Language Class Initialized
INFO - 2017-03-16 03:41:36 --> Loader Class Initialized
INFO - 2017-03-16 03:41:36 --> Database Driver Class Initialized
INFO - 2017-03-16 03:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:41:36 --> Controller Class Initialized
INFO - 2017-03-16 03:41:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:41:36 --> Final output sent to browser
DEBUG - 2017-03-16 03:41:36 --> Total execution time: 0.0132
INFO - 2017-03-16 03:41:45 --> Config Class Initialized
INFO - 2017-03-16 03:41:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:41:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:41:45 --> Utf8 Class Initialized
INFO - 2017-03-16 03:41:45 --> URI Class Initialized
INFO - 2017-03-16 03:41:45 --> Router Class Initialized
INFO - 2017-03-16 03:41:45 --> Output Class Initialized
INFO - 2017-03-16 03:41:45 --> Security Class Initialized
DEBUG - 2017-03-16 03:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:41:45 --> Input Class Initialized
INFO - 2017-03-16 03:41:45 --> Language Class Initialized
INFO - 2017-03-16 03:41:45 --> Loader Class Initialized
INFO - 2017-03-16 03:41:45 --> Database Driver Class Initialized
INFO - 2017-03-16 03:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:41:45 --> Controller Class Initialized
INFO - 2017-03-16 03:41:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:41:47 --> Config Class Initialized
INFO - 2017-03-16 03:41:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:41:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:41:47 --> Utf8 Class Initialized
INFO - 2017-03-16 03:41:47 --> URI Class Initialized
INFO - 2017-03-16 03:41:47 --> Router Class Initialized
INFO - 2017-03-16 03:41:47 --> Output Class Initialized
INFO - 2017-03-16 03:41:47 --> Security Class Initialized
DEBUG - 2017-03-16 03:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:41:47 --> Input Class Initialized
INFO - 2017-03-16 03:41:47 --> Language Class Initialized
INFO - 2017-03-16 03:41:47 --> Loader Class Initialized
INFO - 2017-03-16 03:41:47 --> Database Driver Class Initialized
INFO - 2017-03-16 03:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:41:47 --> Controller Class Initialized
INFO - 2017-03-16 03:41:47 --> Helper loaded: date_helper
DEBUG - 2017-03-16 03:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:41:47 --> Helper loaded: url_helper
INFO - 2017-03-16 03:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 03:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 03:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 03:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:41:47 --> Final output sent to browser
DEBUG - 2017-03-16 03:41:47 --> Total execution time: 0.0833
INFO - 2017-03-16 03:41:48 --> Config Class Initialized
INFO - 2017-03-16 03:41:48 --> Hooks Class Initialized
DEBUG - 2017-03-16 03:41:48 --> UTF-8 Support Enabled
INFO - 2017-03-16 03:41:48 --> Utf8 Class Initialized
INFO - 2017-03-16 03:41:48 --> URI Class Initialized
INFO - 2017-03-16 03:41:48 --> Router Class Initialized
INFO - 2017-03-16 03:41:48 --> Output Class Initialized
INFO - 2017-03-16 03:41:48 --> Security Class Initialized
DEBUG - 2017-03-16 03:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 03:41:48 --> Input Class Initialized
INFO - 2017-03-16 03:41:48 --> Language Class Initialized
INFO - 2017-03-16 03:41:48 --> Loader Class Initialized
INFO - 2017-03-16 03:41:48 --> Database Driver Class Initialized
INFO - 2017-03-16 03:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 03:41:48 --> Controller Class Initialized
INFO - 2017-03-16 03:41:48 --> Helper loaded: url_helper
DEBUG - 2017-03-16 03:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 03:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 03:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 03:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 03:41:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 03:41:48 --> Final output sent to browser
DEBUG - 2017-03-16 03:41:48 --> Total execution time: 0.0133
INFO - 2017-03-16 04:01:42 --> Config Class Initialized
INFO - 2017-03-16 04:01:42 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:01:42 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:01:42 --> Utf8 Class Initialized
INFO - 2017-03-16 04:01:42 --> URI Class Initialized
DEBUG - 2017-03-16 04:01:42 --> No URI present. Default controller set.
INFO - 2017-03-16 04:01:42 --> Router Class Initialized
INFO - 2017-03-16 04:01:42 --> Output Class Initialized
INFO - 2017-03-16 04:01:42 --> Security Class Initialized
DEBUG - 2017-03-16 04:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:01:42 --> Input Class Initialized
INFO - 2017-03-16 04:01:42 --> Language Class Initialized
INFO - 2017-03-16 04:01:42 --> Loader Class Initialized
INFO - 2017-03-16 04:01:43 --> Database Driver Class Initialized
INFO - 2017-03-16 04:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:01:43 --> Controller Class Initialized
INFO - 2017-03-16 04:01:43 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:01:43 --> Final output sent to browser
DEBUG - 2017-03-16 04:01:43 --> Total execution time: 1.2584
INFO - 2017-03-16 04:01:53 --> Config Class Initialized
INFO - 2017-03-16 04:01:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:01:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:01:53 --> Utf8 Class Initialized
INFO - 2017-03-16 04:01:53 --> URI Class Initialized
INFO - 2017-03-16 04:01:53 --> Router Class Initialized
INFO - 2017-03-16 04:01:53 --> Output Class Initialized
INFO - 2017-03-16 04:01:53 --> Security Class Initialized
DEBUG - 2017-03-16 04:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:01:53 --> Input Class Initialized
INFO - 2017-03-16 04:01:53 --> Language Class Initialized
INFO - 2017-03-16 04:01:53 --> Loader Class Initialized
INFO - 2017-03-16 04:01:53 --> Database Driver Class Initialized
INFO - 2017-03-16 04:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:01:53 --> Controller Class Initialized
INFO - 2017-03-16 04:01:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:01:53 --> Final output sent to browser
DEBUG - 2017-03-16 04:01:53 --> Total execution time: 0.0168
INFO - 2017-03-16 04:02:04 --> Config Class Initialized
INFO - 2017-03-16 04:02:04 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:02:04 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:02:04 --> Utf8 Class Initialized
INFO - 2017-03-16 04:02:04 --> URI Class Initialized
INFO - 2017-03-16 04:02:04 --> Router Class Initialized
INFO - 2017-03-16 04:02:04 --> Output Class Initialized
INFO - 2017-03-16 04:02:04 --> Security Class Initialized
DEBUG - 2017-03-16 04:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:02:04 --> Input Class Initialized
INFO - 2017-03-16 04:02:04 --> Language Class Initialized
INFO - 2017-03-16 04:02:04 --> Loader Class Initialized
INFO - 2017-03-16 04:02:04 --> Database Driver Class Initialized
INFO - 2017-03-16 04:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:02:04 --> Controller Class Initialized
INFO - 2017-03-16 04:02:04 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:02:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-16 04:02:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-16 04:02:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-16 04:02:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-16 04:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:02:04 --> Final output sent to browser
DEBUG - 2017-03-16 04:02:04 --> Total execution time: 0.0567
INFO - 2017-03-16 04:02:08 --> Config Class Initialized
INFO - 2017-03-16 04:02:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:02:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:02:08 --> Utf8 Class Initialized
INFO - 2017-03-16 04:02:08 --> URI Class Initialized
INFO - 2017-03-16 04:02:08 --> Router Class Initialized
INFO - 2017-03-16 04:02:08 --> Output Class Initialized
INFO - 2017-03-16 04:02:08 --> Security Class Initialized
DEBUG - 2017-03-16 04:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:02:08 --> Input Class Initialized
INFO - 2017-03-16 04:02:08 --> Language Class Initialized
INFO - 2017-03-16 04:02:08 --> Loader Class Initialized
INFO - 2017-03-16 04:02:08 --> Database Driver Class Initialized
INFO - 2017-03-16 04:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:02:08 --> Controller Class Initialized
INFO - 2017-03-16 04:02:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:02:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:02:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:02:08 --> Final output sent to browser
DEBUG - 2017-03-16 04:02:08 --> Total execution time: 0.2952
INFO - 2017-03-16 04:02:26 --> Config Class Initialized
INFO - 2017-03-16 04:02:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:02:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:02:26 --> Utf8 Class Initialized
INFO - 2017-03-16 04:02:26 --> URI Class Initialized
INFO - 2017-03-16 04:02:26 --> Router Class Initialized
INFO - 2017-03-16 04:02:26 --> Output Class Initialized
INFO - 2017-03-16 04:02:26 --> Security Class Initialized
DEBUG - 2017-03-16 04:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:02:26 --> Input Class Initialized
INFO - 2017-03-16 04:02:26 --> Language Class Initialized
INFO - 2017-03-16 04:02:26 --> Loader Class Initialized
INFO - 2017-03-16 04:02:26 --> Database Driver Class Initialized
INFO - 2017-03-16 04:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:02:26 --> Controller Class Initialized
INFO - 2017-03-16 04:02:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:02:28 --> Config Class Initialized
INFO - 2017-03-16 04:02:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:02:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:02:28 --> Utf8 Class Initialized
INFO - 2017-03-16 04:02:28 --> URI Class Initialized
INFO - 2017-03-16 04:02:28 --> Router Class Initialized
INFO - 2017-03-16 04:02:28 --> Output Class Initialized
INFO - 2017-03-16 04:02:28 --> Security Class Initialized
DEBUG - 2017-03-16 04:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:02:28 --> Input Class Initialized
INFO - 2017-03-16 04:02:28 --> Language Class Initialized
INFO - 2017-03-16 04:02:28 --> Loader Class Initialized
INFO - 2017-03-16 04:02:28 --> Database Driver Class Initialized
INFO - 2017-03-16 04:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:02:28 --> Controller Class Initialized
INFO - 2017-03-16 04:02:28 --> Helper loaded: date_helper
DEBUG - 2017-03-16 04:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:02:28 --> Helper loaded: url_helper
INFO - 2017-03-16 04:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 04:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 04:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 04:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:02:28 --> Final output sent to browser
DEBUG - 2017-03-16 04:02:28 --> Total execution time: 0.0980
INFO - 2017-03-16 04:02:31 --> Config Class Initialized
INFO - 2017-03-16 04:02:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:02:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:02:31 --> Utf8 Class Initialized
INFO - 2017-03-16 04:02:31 --> URI Class Initialized
INFO - 2017-03-16 04:02:31 --> Router Class Initialized
INFO - 2017-03-16 04:02:31 --> Output Class Initialized
INFO - 2017-03-16 04:02:31 --> Security Class Initialized
DEBUG - 2017-03-16 04:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:02:31 --> Input Class Initialized
INFO - 2017-03-16 04:02:31 --> Language Class Initialized
INFO - 2017-03-16 04:02:31 --> Loader Class Initialized
INFO - 2017-03-16 04:02:31 --> Database Driver Class Initialized
INFO - 2017-03-16 04:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:02:31 --> Controller Class Initialized
INFO - 2017-03-16 04:02:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:02:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:02:31 --> Final output sent to browser
DEBUG - 2017-03-16 04:02:31 --> Total execution time: 0.0285
INFO - 2017-03-16 04:09:09 --> Config Class Initialized
INFO - 2017-03-16 04:09:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:09:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:09:09 --> Utf8 Class Initialized
INFO - 2017-03-16 04:09:09 --> URI Class Initialized
INFO - 2017-03-16 04:09:09 --> Router Class Initialized
INFO - 2017-03-16 04:09:09 --> Output Class Initialized
INFO - 2017-03-16 04:09:09 --> Security Class Initialized
DEBUG - 2017-03-16 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:09:09 --> Input Class Initialized
INFO - 2017-03-16 04:09:09 --> Language Class Initialized
INFO - 2017-03-16 04:09:09 --> Loader Class Initialized
INFO - 2017-03-16 04:09:09 --> Database Driver Class Initialized
INFO - 2017-03-16 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:09:10 --> Controller Class Initialized
INFO - 2017-03-16 04:09:10 --> Helper loaded: date_helper
DEBUG - 2017-03-16 04:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:09:10 --> Helper loaded: url_helper
INFO - 2017-03-16 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:09:10 --> Final output sent to browser
DEBUG - 2017-03-16 04:09:10 --> Total execution time: 1.1360
INFO - 2017-03-16 04:09:12 --> Config Class Initialized
INFO - 2017-03-16 04:09:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:09:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:09:12 --> Utf8 Class Initialized
INFO - 2017-03-16 04:09:12 --> URI Class Initialized
INFO - 2017-03-16 04:09:12 --> Router Class Initialized
INFO - 2017-03-16 04:09:12 --> Output Class Initialized
INFO - 2017-03-16 04:09:12 --> Security Class Initialized
DEBUG - 2017-03-16 04:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:09:12 --> Input Class Initialized
INFO - 2017-03-16 04:09:12 --> Language Class Initialized
INFO - 2017-03-16 04:09:12 --> Loader Class Initialized
INFO - 2017-03-16 04:09:12 --> Database Driver Class Initialized
INFO - 2017-03-16 04:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:09:12 --> Controller Class Initialized
INFO - 2017-03-16 04:09:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:09:12 --> Final output sent to browser
DEBUG - 2017-03-16 04:09:12 --> Total execution time: 0.2384
INFO - 2017-03-16 04:12:22 --> Config Class Initialized
INFO - 2017-03-16 04:12:22 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:22 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:22 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:22 --> URI Class Initialized
DEBUG - 2017-03-16 04:12:22 --> No URI present. Default controller set.
INFO - 2017-03-16 04:12:22 --> Router Class Initialized
INFO - 2017-03-16 04:12:22 --> Output Class Initialized
INFO - 2017-03-16 04:12:22 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:22 --> Input Class Initialized
INFO - 2017-03-16 04:12:22 --> Language Class Initialized
INFO - 2017-03-16 04:12:22 --> Loader Class Initialized
INFO - 2017-03-16 04:12:23 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:23 --> Controller Class Initialized
INFO - 2017-03-16 04:12:23 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:23 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:23 --> Total execution time: 1.2210
INFO - 2017-03-16 04:12:27 --> Config Class Initialized
INFO - 2017-03-16 04:12:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:27 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:27 --> URI Class Initialized
INFO - 2017-03-16 04:12:27 --> Router Class Initialized
INFO - 2017-03-16 04:12:27 --> Output Class Initialized
INFO - 2017-03-16 04:12:27 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:27 --> Input Class Initialized
INFO - 2017-03-16 04:12:27 --> Language Class Initialized
INFO - 2017-03-16 04:12:27 --> Loader Class Initialized
INFO - 2017-03-16 04:12:27 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:27 --> Controller Class Initialized
INFO - 2017-03-16 04:12:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:28 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:28 --> Total execution time: 1.1484
INFO - 2017-03-16 04:12:30 --> Config Class Initialized
INFO - 2017-03-16 04:12:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:30 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:30 --> URI Class Initialized
INFO - 2017-03-16 04:12:30 --> Router Class Initialized
INFO - 2017-03-16 04:12:30 --> Output Class Initialized
INFO - 2017-03-16 04:12:30 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:30 --> Input Class Initialized
INFO - 2017-03-16 04:12:30 --> Language Class Initialized
INFO - 2017-03-16 04:12:30 --> Loader Class Initialized
INFO - 2017-03-16 04:12:30 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:30 --> Controller Class Initialized
INFO - 2017-03-16 04:12:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:30 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:30 --> Total execution time: 0.0295
INFO - 2017-03-16 04:12:31 --> Config Class Initialized
INFO - 2017-03-16 04:12:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:31 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:31 --> URI Class Initialized
INFO - 2017-03-16 04:12:31 --> Router Class Initialized
INFO - 2017-03-16 04:12:31 --> Output Class Initialized
INFO - 2017-03-16 04:12:31 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:31 --> Input Class Initialized
INFO - 2017-03-16 04:12:31 --> Language Class Initialized
INFO - 2017-03-16 04:12:31 --> Loader Class Initialized
INFO - 2017-03-16 04:12:31 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:31 --> Controller Class Initialized
INFO - 2017-03-16 04:12:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:12:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:12:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:31 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:31 --> Total execution time: 0.0148
INFO - 2017-03-16 04:12:35 --> Config Class Initialized
INFO - 2017-03-16 04:12:35 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:35 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:35 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:35 --> URI Class Initialized
INFO - 2017-03-16 04:12:35 --> Router Class Initialized
INFO - 2017-03-16 04:12:35 --> Output Class Initialized
INFO - 2017-03-16 04:12:35 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:35 --> Input Class Initialized
INFO - 2017-03-16 04:12:35 --> Language Class Initialized
INFO - 2017-03-16 04:12:35 --> Loader Class Initialized
INFO - 2017-03-16 04:12:35 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:35 --> Controller Class Initialized
INFO - 2017-03-16 04:12:35 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:37 --> Config Class Initialized
INFO - 2017-03-16 04:12:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:37 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:37 --> URI Class Initialized
INFO - 2017-03-16 04:12:37 --> Router Class Initialized
INFO - 2017-03-16 04:12:37 --> Output Class Initialized
INFO - 2017-03-16 04:12:37 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:37 --> Input Class Initialized
INFO - 2017-03-16 04:12:37 --> Language Class Initialized
INFO - 2017-03-16 04:12:37 --> Loader Class Initialized
INFO - 2017-03-16 04:12:37 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:37 --> Controller Class Initialized
INFO - 2017-03-16 04:12:37 --> Helper loaded: date_helper
DEBUG - 2017-03-16 04:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:37 --> Helper loaded: url_helper
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:37 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:37 --> Total execution time: 0.0908
INFO - 2017-03-16 04:12:37 --> Config Class Initialized
INFO - 2017-03-16 04:12:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:37 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:37 --> URI Class Initialized
INFO - 2017-03-16 04:12:37 --> Router Class Initialized
INFO - 2017-03-16 04:12:37 --> Output Class Initialized
INFO - 2017-03-16 04:12:37 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:37 --> Input Class Initialized
INFO - 2017-03-16 04:12:37 --> Language Class Initialized
INFO - 2017-03-16 04:12:37 --> Loader Class Initialized
INFO - 2017-03-16 04:12:37 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:37 --> Controller Class Initialized
INFO - 2017-03-16 04:12:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:37 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:37 --> Total execution time: 0.0140
INFO - 2017-03-16 04:12:45 --> Config Class Initialized
INFO - 2017-03-16 04:12:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:45 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:45 --> URI Class Initialized
DEBUG - 2017-03-16 04:12:45 --> No URI present. Default controller set.
INFO - 2017-03-16 04:12:45 --> Router Class Initialized
INFO - 2017-03-16 04:12:45 --> Output Class Initialized
INFO - 2017-03-16 04:12:45 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:45 --> Input Class Initialized
INFO - 2017-03-16 04:12:45 --> Language Class Initialized
INFO - 2017-03-16 04:12:45 --> Loader Class Initialized
INFO - 2017-03-16 04:12:45 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:45 --> Controller Class Initialized
INFO - 2017-03-16 04:12:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:12:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:12:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:45 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:45 --> Total execution time: 0.0131
INFO - 2017-03-16 04:12:46 --> Config Class Initialized
INFO - 2017-03-16 04:12:46 --> Hooks Class Initialized
DEBUG - 2017-03-16 04:12:46 --> UTF-8 Support Enabled
INFO - 2017-03-16 04:12:46 --> Utf8 Class Initialized
INFO - 2017-03-16 04:12:46 --> URI Class Initialized
INFO - 2017-03-16 04:12:46 --> Router Class Initialized
INFO - 2017-03-16 04:12:46 --> Output Class Initialized
INFO - 2017-03-16 04:12:46 --> Security Class Initialized
DEBUG - 2017-03-16 04:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 04:12:46 --> Input Class Initialized
INFO - 2017-03-16 04:12:46 --> Language Class Initialized
INFO - 2017-03-16 04:12:46 --> Loader Class Initialized
INFO - 2017-03-16 04:12:46 --> Database Driver Class Initialized
INFO - 2017-03-16 04:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 04:12:46 --> Controller Class Initialized
INFO - 2017-03-16 04:12:46 --> Helper loaded: url_helper
DEBUG - 2017-03-16 04:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 04:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 04:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 04:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 04:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 04:12:46 --> Final output sent to browser
DEBUG - 2017-03-16 04:12:46 --> Total execution time: 0.0132
INFO - 2017-03-16 05:05:07 --> Config Class Initialized
INFO - 2017-03-16 05:05:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 05:05:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 05:05:07 --> Utf8 Class Initialized
INFO - 2017-03-16 05:05:07 --> URI Class Initialized
DEBUG - 2017-03-16 05:05:07 --> No URI present. Default controller set.
INFO - 2017-03-16 05:05:07 --> Router Class Initialized
INFO - 2017-03-16 05:05:07 --> Output Class Initialized
INFO - 2017-03-16 05:05:07 --> Security Class Initialized
DEBUG - 2017-03-16 05:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 05:05:07 --> Input Class Initialized
INFO - 2017-03-16 05:05:07 --> Language Class Initialized
INFO - 2017-03-16 05:05:07 --> Loader Class Initialized
INFO - 2017-03-16 05:05:08 --> Database Driver Class Initialized
INFO - 2017-03-16 05:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 05:05:08 --> Controller Class Initialized
INFO - 2017-03-16 05:05:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 05:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 05:05:08 --> Final output sent to browser
DEBUG - 2017-03-16 05:05:08 --> Total execution time: 1.2461
INFO - 2017-03-16 07:03:23 --> Config Class Initialized
INFO - 2017-03-16 07:03:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:03:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:03:23 --> Utf8 Class Initialized
INFO - 2017-03-16 07:03:23 --> URI Class Initialized
DEBUG - 2017-03-16 07:03:24 --> No URI present. Default controller set.
INFO - 2017-03-16 07:03:24 --> Router Class Initialized
INFO - 2017-03-16 07:03:24 --> Output Class Initialized
INFO - 2017-03-16 07:03:24 --> Security Class Initialized
DEBUG - 2017-03-16 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:03:24 --> Input Class Initialized
INFO - 2017-03-16 07:03:24 --> Language Class Initialized
INFO - 2017-03-16 07:03:24 --> Loader Class Initialized
INFO - 2017-03-16 07:03:24 --> Database Driver Class Initialized
INFO - 2017-03-16 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:03:24 --> Controller Class Initialized
INFO - 2017-03-16 07:03:24 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:03:24 --> Final output sent to browser
DEBUG - 2017-03-16 07:03:24 --> Total execution time: 1.3587
INFO - 2017-03-16 07:03:35 --> Config Class Initialized
INFO - 2017-03-16 07:03:35 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:03:35 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:03:35 --> Utf8 Class Initialized
INFO - 2017-03-16 07:03:35 --> URI Class Initialized
INFO - 2017-03-16 07:03:35 --> Router Class Initialized
INFO - 2017-03-16 07:03:35 --> Output Class Initialized
INFO - 2017-03-16 07:03:35 --> Security Class Initialized
DEBUG - 2017-03-16 07:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:03:35 --> Input Class Initialized
INFO - 2017-03-16 07:03:35 --> Language Class Initialized
INFO - 2017-03-16 07:03:35 --> Loader Class Initialized
INFO - 2017-03-16 07:03:35 --> Database Driver Class Initialized
INFO - 2017-03-16 07:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:03:35 --> Controller Class Initialized
INFO - 2017-03-16 07:03:35 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:03:35 --> Final output sent to browser
DEBUG - 2017-03-16 07:03:35 --> Total execution time: 0.0144
INFO - 2017-03-16 07:09:17 --> Config Class Initialized
INFO - 2017-03-16 07:09:17 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:09:17 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:09:17 --> Utf8 Class Initialized
INFO - 2017-03-16 07:09:17 --> URI Class Initialized
INFO - 2017-03-16 07:09:17 --> Router Class Initialized
INFO - 2017-03-16 07:09:17 --> Output Class Initialized
INFO - 2017-03-16 07:09:17 --> Security Class Initialized
DEBUG - 2017-03-16 07:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:09:18 --> Input Class Initialized
INFO - 2017-03-16 07:09:18 --> Language Class Initialized
INFO - 2017-03-16 07:09:18 --> Loader Class Initialized
INFO - 2017-03-16 07:09:18 --> Database Driver Class Initialized
INFO - 2017-03-16 07:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:09:18 --> Controller Class Initialized
INFO - 2017-03-16 07:09:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:09:18 --> Final output sent to browser
DEBUG - 2017-03-16 07:09:18 --> Total execution time: 1.2989
INFO - 2017-03-16 07:09:20 --> Config Class Initialized
INFO - 2017-03-16 07:09:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:09:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:09:20 --> Utf8 Class Initialized
INFO - 2017-03-16 07:09:20 --> URI Class Initialized
INFO - 2017-03-16 07:09:20 --> Router Class Initialized
INFO - 2017-03-16 07:09:20 --> Output Class Initialized
INFO - 2017-03-16 07:09:20 --> Security Class Initialized
DEBUG - 2017-03-16 07:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:09:20 --> Input Class Initialized
INFO - 2017-03-16 07:09:20 --> Language Class Initialized
INFO - 2017-03-16 07:09:20 --> Loader Class Initialized
INFO - 2017-03-16 07:09:20 --> Database Driver Class Initialized
INFO - 2017-03-16 07:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:09:20 --> Controller Class Initialized
INFO - 2017-03-16 07:09:20 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:09:20 --> Final output sent to browser
DEBUG - 2017-03-16 07:09:20 --> Total execution time: 0.0136
INFO - 2017-03-16 07:09:36 --> Config Class Initialized
INFO - 2017-03-16 07:09:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:09:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:09:36 --> Utf8 Class Initialized
INFO - 2017-03-16 07:09:36 --> URI Class Initialized
INFO - 2017-03-16 07:09:36 --> Router Class Initialized
INFO - 2017-03-16 07:09:36 --> Output Class Initialized
INFO - 2017-03-16 07:09:36 --> Security Class Initialized
DEBUG - 2017-03-16 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:09:36 --> Input Class Initialized
INFO - 2017-03-16 07:09:36 --> Language Class Initialized
INFO - 2017-03-16 07:09:36 --> Loader Class Initialized
INFO - 2017-03-16 07:09:36 --> Database Driver Class Initialized
INFO - 2017-03-16 07:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:09:36 --> Controller Class Initialized
INFO - 2017-03-16 07:09:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:09:36 --> Final output sent to browser
DEBUG - 2017-03-16 07:09:36 --> Total execution time: 0.0138
INFO - 2017-03-16 07:09:38 --> Config Class Initialized
INFO - 2017-03-16 07:09:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:09:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:09:38 --> Utf8 Class Initialized
INFO - 2017-03-16 07:09:38 --> URI Class Initialized
INFO - 2017-03-16 07:09:38 --> Router Class Initialized
INFO - 2017-03-16 07:09:38 --> Output Class Initialized
INFO - 2017-03-16 07:09:38 --> Security Class Initialized
DEBUG - 2017-03-16 07:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:09:38 --> Input Class Initialized
INFO - 2017-03-16 07:09:38 --> Language Class Initialized
INFO - 2017-03-16 07:09:38 --> Loader Class Initialized
INFO - 2017-03-16 07:09:38 --> Database Driver Class Initialized
INFO - 2017-03-16 07:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:09:38 --> Controller Class Initialized
INFO - 2017-03-16 07:09:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:09:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:09:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:09:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:09:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:09:38 --> Final output sent to browser
DEBUG - 2017-03-16 07:09:38 --> Total execution time: 0.0131
INFO - 2017-03-16 07:26:31 --> Config Class Initialized
INFO - 2017-03-16 07:26:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:26:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:26:31 --> Utf8 Class Initialized
INFO - 2017-03-16 07:26:31 --> URI Class Initialized
INFO - 2017-03-16 07:26:31 --> Router Class Initialized
INFO - 2017-03-16 07:26:31 --> Output Class Initialized
INFO - 2017-03-16 07:26:31 --> Security Class Initialized
DEBUG - 2017-03-16 07:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:26:31 --> Input Class Initialized
INFO - 2017-03-16 07:26:31 --> Language Class Initialized
INFO - 2017-03-16 07:26:31 --> Loader Class Initialized
INFO - 2017-03-16 07:26:32 --> Database Driver Class Initialized
INFO - 2017-03-16 07:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:26:32 --> Controller Class Initialized
INFO - 2017-03-16 07:26:32 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:26:32 --> Final output sent to browser
DEBUG - 2017-03-16 07:26:32 --> Total execution time: 1.2228
INFO - 2017-03-16 07:26:32 --> Config Class Initialized
INFO - 2017-03-16 07:26:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 07:26:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 07:26:32 --> Utf8 Class Initialized
INFO - 2017-03-16 07:26:32 --> URI Class Initialized
DEBUG - 2017-03-16 07:26:32 --> No URI present. Default controller set.
INFO - 2017-03-16 07:26:32 --> Router Class Initialized
INFO - 2017-03-16 07:26:32 --> Output Class Initialized
INFO - 2017-03-16 07:26:32 --> Security Class Initialized
DEBUG - 2017-03-16 07:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 07:26:32 --> Input Class Initialized
INFO - 2017-03-16 07:26:32 --> Language Class Initialized
INFO - 2017-03-16 07:26:32 --> Loader Class Initialized
INFO - 2017-03-16 07:26:32 --> Database Driver Class Initialized
INFO - 2017-03-16 07:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 07:26:32 --> Controller Class Initialized
INFO - 2017-03-16 07:26:32 --> Helper loaded: url_helper
DEBUG - 2017-03-16 07:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 07:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 07:26:32 --> Final output sent to browser
DEBUG - 2017-03-16 07:26:32 --> Total execution time: 0.0133
INFO - 2017-03-16 14:16:34 --> Config Class Initialized
INFO - 2017-03-16 14:16:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 14:16:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 14:16:34 --> Utf8 Class Initialized
INFO - 2017-03-16 14:16:34 --> URI Class Initialized
INFO - 2017-03-16 14:16:34 --> Router Class Initialized
INFO - 2017-03-16 14:16:34 --> Output Class Initialized
INFO - 2017-03-16 14:16:34 --> Security Class Initialized
DEBUG - 2017-03-16 14:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 14:16:34 --> Input Class Initialized
INFO - 2017-03-16 14:16:34 --> Language Class Initialized
INFO - 2017-03-16 14:16:34 --> Loader Class Initialized
INFO - 2017-03-16 14:16:35 --> Database Driver Class Initialized
INFO - 2017-03-16 14:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 14:16:35 --> Controller Class Initialized
INFO - 2017-03-16 14:16:35 --> Helper loaded: date_helper
DEBUG - 2017-03-16 14:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 14:16:35 --> Helper loaded: url_helper
INFO - 2017-03-16 14:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 14:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 14:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 14:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 14:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 14:16:35 --> Final output sent to browser
DEBUG - 2017-03-16 14:16:35 --> Total execution time: 1.4376
INFO - 2017-03-16 16:49:55 --> Config Class Initialized
INFO - 2017-03-16 16:49:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 16:49:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 16:49:55 --> Utf8 Class Initialized
INFO - 2017-03-16 16:49:55 --> URI Class Initialized
INFO - 2017-03-16 16:49:55 --> Router Class Initialized
INFO - 2017-03-16 16:49:55 --> Output Class Initialized
INFO - 2017-03-16 16:49:56 --> Security Class Initialized
DEBUG - 2017-03-16 16:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 16:49:56 --> Input Class Initialized
INFO - 2017-03-16 16:49:56 --> Language Class Initialized
INFO - 2017-03-16 16:49:56 --> Loader Class Initialized
INFO - 2017-03-16 16:49:56 --> Database Driver Class Initialized
INFO - 2017-03-16 16:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 16:49:57 --> Controller Class Initialized
INFO - 2017-03-16 16:49:57 --> Helper loaded: date_helper
DEBUG - 2017-03-16 16:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 16:49:57 --> Helper loaded: url_helper
INFO - 2017-03-16 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 16:49:57 --> Final output sent to browser
DEBUG - 2017-03-16 16:49:57 --> Total execution time: 2.0625
INFO - 2017-03-16 16:50:20 --> Config Class Initialized
INFO - 2017-03-16 16:50:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 16:50:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 16:50:20 --> Utf8 Class Initialized
INFO - 2017-03-16 16:50:20 --> URI Class Initialized
INFO - 2017-03-16 16:50:20 --> Router Class Initialized
INFO - 2017-03-16 16:50:20 --> Output Class Initialized
INFO - 2017-03-16 16:50:20 --> Security Class Initialized
DEBUG - 2017-03-16 16:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 16:50:20 --> Input Class Initialized
INFO - 2017-03-16 16:50:20 --> Language Class Initialized
INFO - 2017-03-16 16:50:20 --> Loader Class Initialized
INFO - 2017-03-16 16:50:20 --> Database Driver Class Initialized
INFO - 2017-03-16 16:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 16:50:20 --> Controller Class Initialized
INFO - 2017-03-16 16:50:20 --> Helper loaded: date_helper
DEBUG - 2017-03-16 16:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 16:50:20 --> Helper loaded: url_helper
INFO - 2017-03-16 16:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 16:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 16:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 16:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 16:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 16:50:20 --> Final output sent to browser
DEBUG - 2017-03-16 16:50:20 --> Total execution time: 0.0138
INFO - 2017-03-16 17:01:27 --> Config Class Initialized
INFO - 2017-03-16 17:01:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:01:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:01:27 --> Utf8 Class Initialized
INFO - 2017-03-16 17:01:27 --> URI Class Initialized
DEBUG - 2017-03-16 17:01:27 --> No URI present. Default controller set.
INFO - 2017-03-16 17:01:27 --> Router Class Initialized
INFO - 2017-03-16 17:01:27 --> Output Class Initialized
INFO - 2017-03-16 17:01:27 --> Security Class Initialized
DEBUG - 2017-03-16 17:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:01:27 --> Input Class Initialized
INFO - 2017-03-16 17:01:27 --> Language Class Initialized
INFO - 2017-03-16 17:01:27 --> Loader Class Initialized
INFO - 2017-03-16 17:01:28 --> Database Driver Class Initialized
INFO - 2017-03-16 17:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:01:28 --> Controller Class Initialized
INFO - 2017-03-16 17:01:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:01:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:01:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:01:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:01:29 --> Final output sent to browser
DEBUG - 2017-03-16 17:01:29 --> Total execution time: 1.7260
INFO - 2017-03-16 17:03:18 --> Config Class Initialized
INFO - 2017-03-16 17:03:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:03:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:03:18 --> Utf8 Class Initialized
INFO - 2017-03-16 17:03:18 --> URI Class Initialized
DEBUG - 2017-03-16 17:03:18 --> No URI present. Default controller set.
INFO - 2017-03-16 17:03:18 --> Router Class Initialized
INFO - 2017-03-16 17:03:18 --> Output Class Initialized
INFO - 2017-03-16 17:03:18 --> Security Class Initialized
DEBUG - 2017-03-16 17:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:03:18 --> Input Class Initialized
INFO - 2017-03-16 17:03:18 --> Language Class Initialized
INFO - 2017-03-16 17:03:18 --> Loader Class Initialized
INFO - 2017-03-16 17:03:18 --> Database Driver Class Initialized
INFO - 2017-03-16 17:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:03:19 --> Controller Class Initialized
INFO - 2017-03-16 17:03:19 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:03:19 --> Final output sent to browser
DEBUG - 2017-03-16 17:03:19 --> Total execution time: 1.4628
INFO - 2017-03-16 17:03:34 --> Config Class Initialized
INFO - 2017-03-16 17:03:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:03:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:03:34 --> Utf8 Class Initialized
INFO - 2017-03-16 17:03:34 --> URI Class Initialized
INFO - 2017-03-16 17:03:34 --> Router Class Initialized
INFO - 2017-03-16 17:03:34 --> Output Class Initialized
INFO - 2017-03-16 17:03:34 --> Security Class Initialized
DEBUG - 2017-03-16 17:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:03:34 --> Input Class Initialized
INFO - 2017-03-16 17:03:34 --> Language Class Initialized
INFO - 2017-03-16 17:03:34 --> Loader Class Initialized
INFO - 2017-03-16 17:03:34 --> Database Driver Class Initialized
INFO - 2017-03-16 17:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:03:34 --> Controller Class Initialized
INFO - 2017-03-16 17:03:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:03:34 --> Final output sent to browser
DEBUG - 2017-03-16 17:03:34 --> Total execution time: 0.0136
INFO - 2017-03-16 17:06:11 --> Config Class Initialized
INFO - 2017-03-16 17:06:11 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:06:11 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:06:11 --> Utf8 Class Initialized
INFO - 2017-03-16 17:06:11 --> URI Class Initialized
INFO - 2017-03-16 17:06:11 --> Router Class Initialized
INFO - 2017-03-16 17:06:11 --> Output Class Initialized
INFO - 2017-03-16 17:06:11 --> Security Class Initialized
DEBUG - 2017-03-16 17:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:06:11 --> Input Class Initialized
INFO - 2017-03-16 17:06:11 --> Language Class Initialized
INFO - 2017-03-16 17:06:11 --> Loader Class Initialized
INFO - 2017-03-16 17:06:11 --> Database Driver Class Initialized
INFO - 2017-03-16 17:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:06:12 --> Controller Class Initialized
INFO - 2017-03-16 17:06:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:06:14 --> Config Class Initialized
INFO - 2017-03-16 17:06:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:06:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:06:14 --> Utf8 Class Initialized
INFO - 2017-03-16 17:06:14 --> URI Class Initialized
INFO - 2017-03-16 17:06:14 --> Router Class Initialized
INFO - 2017-03-16 17:06:14 --> Output Class Initialized
INFO - 2017-03-16 17:06:14 --> Security Class Initialized
DEBUG - 2017-03-16 17:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:06:14 --> Input Class Initialized
INFO - 2017-03-16 17:06:14 --> Language Class Initialized
INFO - 2017-03-16 17:06:14 --> Loader Class Initialized
INFO - 2017-03-16 17:06:14 --> Database Driver Class Initialized
INFO - 2017-03-16 17:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:06:14 --> Controller Class Initialized
INFO - 2017-03-16 17:06:14 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:06:14 --> Helper loaded: url_helper
INFO - 2017-03-16 17:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:06:14 --> Final output sent to browser
DEBUG - 2017-03-16 17:06:14 --> Total execution time: 0.1272
INFO - 2017-03-16 17:08:32 --> Config Class Initialized
INFO - 2017-03-16 17:08:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:08:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:08:32 --> Utf8 Class Initialized
INFO - 2017-03-16 17:08:32 --> URI Class Initialized
DEBUG - 2017-03-16 17:08:32 --> No URI present. Default controller set.
INFO - 2017-03-16 17:08:32 --> Router Class Initialized
INFO - 2017-03-16 17:08:32 --> Output Class Initialized
INFO - 2017-03-16 17:08:32 --> Security Class Initialized
DEBUG - 2017-03-16 17:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:08:32 --> Input Class Initialized
INFO - 2017-03-16 17:08:32 --> Language Class Initialized
INFO - 2017-03-16 17:08:32 --> Loader Class Initialized
INFO - 2017-03-16 17:08:33 --> Database Driver Class Initialized
INFO - 2017-03-16 17:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:08:33 --> Controller Class Initialized
INFO - 2017-03-16 17:08:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:08:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:08:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:08:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:08:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:08:34 --> Final output sent to browser
DEBUG - 2017-03-16 17:08:34 --> Total execution time: 1.7171
INFO - 2017-03-16 17:08:34 --> Config Class Initialized
INFO - 2017-03-16 17:08:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:08:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:08:34 --> Utf8 Class Initialized
INFO - 2017-03-16 17:08:34 --> URI Class Initialized
DEBUG - 2017-03-16 17:08:34 --> No URI present. Default controller set.
INFO - 2017-03-16 17:08:34 --> Router Class Initialized
INFO - 2017-03-16 17:08:34 --> Output Class Initialized
INFO - 2017-03-16 17:08:34 --> Security Class Initialized
DEBUG - 2017-03-16 17:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:08:34 --> Input Class Initialized
INFO - 2017-03-16 17:08:34 --> Language Class Initialized
INFO - 2017-03-16 17:08:34 --> Loader Class Initialized
INFO - 2017-03-16 17:08:34 --> Database Driver Class Initialized
INFO - 2017-03-16 17:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:08:34 --> Controller Class Initialized
INFO - 2017-03-16 17:08:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:08:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:08:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:08:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:08:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:08:34 --> Final output sent to browser
DEBUG - 2017-03-16 17:08:34 --> Total execution time: 0.0142
INFO - 2017-03-16 17:08:44 --> Config Class Initialized
INFO - 2017-03-16 17:08:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:08:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:08:44 --> Utf8 Class Initialized
INFO - 2017-03-16 17:08:44 --> URI Class Initialized
INFO - 2017-03-16 17:08:44 --> Router Class Initialized
INFO - 2017-03-16 17:08:44 --> Output Class Initialized
INFO - 2017-03-16 17:08:44 --> Security Class Initialized
DEBUG - 2017-03-16 17:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:08:44 --> Input Class Initialized
INFO - 2017-03-16 17:08:44 --> Language Class Initialized
INFO - 2017-03-16 17:08:44 --> Loader Class Initialized
INFO - 2017-03-16 17:08:44 --> Database Driver Class Initialized
INFO - 2017-03-16 17:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:08:44 --> Controller Class Initialized
INFO - 2017-03-16 17:08:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:08:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 17:08:46 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 17:08:46 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-16 17:08:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 17:08:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 17:08:51 --> Config Class Initialized
INFO - 2017-03-16 17:08:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:08:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:08:51 --> Utf8 Class Initialized
INFO - 2017-03-16 17:08:51 --> URI Class Initialized
DEBUG - 2017-03-16 17:08:51 --> No URI present. Default controller set.
INFO - 2017-03-16 17:08:51 --> Router Class Initialized
INFO - 2017-03-16 17:08:51 --> Output Class Initialized
INFO - 2017-03-16 17:08:51 --> Security Class Initialized
DEBUG - 2017-03-16 17:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:08:51 --> Input Class Initialized
INFO - 2017-03-16 17:08:51 --> Language Class Initialized
INFO - 2017-03-16 17:08:51 --> Loader Class Initialized
INFO - 2017-03-16 17:08:51 --> Database Driver Class Initialized
INFO - 2017-03-16 17:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:08:51 --> Controller Class Initialized
INFO - 2017-03-16 17:08:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:08:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:08:51 --> Final output sent to browser
DEBUG - 2017-03-16 17:08:51 --> Total execution time: 0.0139
INFO - 2017-03-16 17:08:53 --> Config Class Initialized
INFO - 2017-03-16 17:08:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:08:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:08:53 --> Utf8 Class Initialized
INFO - 2017-03-16 17:08:53 --> URI Class Initialized
INFO - 2017-03-16 17:08:53 --> Router Class Initialized
INFO - 2017-03-16 17:08:53 --> Output Class Initialized
INFO - 2017-03-16 17:08:53 --> Security Class Initialized
DEBUG - 2017-03-16 17:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:08:53 --> Input Class Initialized
INFO - 2017-03-16 17:08:53 --> Language Class Initialized
INFO - 2017-03-16 17:08:53 --> Loader Class Initialized
INFO - 2017-03-16 17:08:53 --> Database Driver Class Initialized
INFO - 2017-03-16 17:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:08:53 --> Controller Class Initialized
INFO - 2017-03-16 17:08:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:08:53 --> Final output sent to browser
DEBUG - 2017-03-16 17:08:53 --> Total execution time: 0.0130
INFO - 2017-03-16 17:09:06 --> Config Class Initialized
INFO - 2017-03-16 17:09:06 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:09:06 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:09:06 --> Utf8 Class Initialized
INFO - 2017-03-16 17:09:06 --> URI Class Initialized
INFO - 2017-03-16 17:09:06 --> Router Class Initialized
INFO - 2017-03-16 17:09:06 --> Output Class Initialized
INFO - 2017-03-16 17:09:06 --> Security Class Initialized
DEBUG - 2017-03-16 17:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:09:06 --> Input Class Initialized
INFO - 2017-03-16 17:09:06 --> Language Class Initialized
INFO - 2017-03-16 17:09:06 --> Loader Class Initialized
INFO - 2017-03-16 17:09:06 --> Database Driver Class Initialized
INFO - 2017-03-16 17:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:09:06 --> Controller Class Initialized
INFO - 2017-03-16 17:09:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-16 17:09:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-16 17:09:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-16 17:09:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-16 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:09:06 --> Final output sent to browser
DEBUG - 2017-03-16 17:09:06 --> Total execution time: 0.1473
INFO - 2017-03-16 17:09:18 --> Config Class Initialized
INFO - 2017-03-16 17:09:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:09:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:09:18 --> Utf8 Class Initialized
INFO - 2017-03-16 17:09:18 --> URI Class Initialized
INFO - 2017-03-16 17:09:18 --> Router Class Initialized
INFO - 2017-03-16 17:09:18 --> Output Class Initialized
INFO - 2017-03-16 17:09:18 --> Security Class Initialized
DEBUG - 2017-03-16 17:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:09:18 --> Input Class Initialized
INFO - 2017-03-16 17:09:18 --> Language Class Initialized
INFO - 2017-03-16 17:09:18 --> Loader Class Initialized
INFO - 2017-03-16 17:09:18 --> Database Driver Class Initialized
INFO - 2017-03-16 17:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:09:18 --> Controller Class Initialized
INFO - 2017-03-16 17:09:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:09:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 17:09:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 17:09:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Michelle Zapata')
INFO - 2017-03-16 17:09:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 17:09:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 17:09:32 --> Config Class Initialized
INFO - 2017-03-16 17:09:32 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:09:32 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:09:32 --> Utf8 Class Initialized
INFO - 2017-03-16 17:09:32 --> URI Class Initialized
INFO - 2017-03-16 17:09:32 --> Router Class Initialized
INFO - 2017-03-16 17:09:32 --> Output Class Initialized
INFO - 2017-03-16 17:09:32 --> Security Class Initialized
DEBUG - 2017-03-16 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:09:32 --> Input Class Initialized
INFO - 2017-03-16 17:09:32 --> Language Class Initialized
INFO - 2017-03-16 17:09:32 --> Loader Class Initialized
INFO - 2017-03-16 17:09:32 --> Database Driver Class Initialized
INFO - 2017-03-16 17:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:09:32 --> Controller Class Initialized
INFO - 2017-03-16 17:09:32 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:09:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 17:09:32 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 17:09:33 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Michelle Zapata')
INFO - 2017-03-16 17:09:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 17:09:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 17:09:37 --> Config Class Initialized
INFO - 2017-03-16 17:09:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:09:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:09:37 --> Utf8 Class Initialized
INFO - 2017-03-16 17:09:37 --> URI Class Initialized
DEBUG - 2017-03-16 17:09:37 --> No URI present. Default controller set.
INFO - 2017-03-16 17:09:37 --> Router Class Initialized
INFO - 2017-03-16 17:09:37 --> Output Class Initialized
INFO - 2017-03-16 17:09:37 --> Security Class Initialized
DEBUG - 2017-03-16 17:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:09:37 --> Input Class Initialized
INFO - 2017-03-16 17:09:37 --> Language Class Initialized
INFO - 2017-03-16 17:09:37 --> Loader Class Initialized
INFO - 2017-03-16 17:09:37 --> Database Driver Class Initialized
INFO - 2017-03-16 17:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:09:37 --> Controller Class Initialized
INFO - 2017-03-16 17:09:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:09:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:09:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:09:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:09:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:09:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:09:37 --> Final output sent to browser
DEBUG - 2017-03-16 17:09:37 --> Total execution time: 0.0262
INFO - 2017-03-16 17:09:41 --> Config Class Initialized
INFO - 2017-03-16 17:09:41 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:09:41 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:09:41 --> Utf8 Class Initialized
INFO - 2017-03-16 17:09:41 --> URI Class Initialized
INFO - 2017-03-16 17:09:41 --> Router Class Initialized
INFO - 2017-03-16 17:09:41 --> Output Class Initialized
INFO - 2017-03-16 17:09:41 --> Security Class Initialized
DEBUG - 2017-03-16 17:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:09:41 --> Input Class Initialized
INFO - 2017-03-16 17:09:41 --> Language Class Initialized
INFO - 2017-03-16 17:09:41 --> Loader Class Initialized
INFO - 2017-03-16 17:09:41 --> Database Driver Class Initialized
INFO - 2017-03-16 17:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:09:41 --> Controller Class Initialized
INFO - 2017-03-16 17:09:41 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:09:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:09:41 --> Final output sent to browser
DEBUG - 2017-03-16 17:09:41 --> Total execution time: 0.0134
INFO - 2017-03-16 17:09:45 --> Config Class Initialized
INFO - 2017-03-16 17:09:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:09:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:09:45 --> Utf8 Class Initialized
INFO - 2017-03-16 17:09:45 --> URI Class Initialized
INFO - 2017-03-16 17:09:45 --> Router Class Initialized
INFO - 2017-03-16 17:09:45 --> Output Class Initialized
INFO - 2017-03-16 17:09:45 --> Security Class Initialized
DEBUG - 2017-03-16 17:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:09:45 --> Input Class Initialized
INFO - 2017-03-16 17:09:45 --> Language Class Initialized
INFO - 2017-03-16 17:09:45 --> Loader Class Initialized
INFO - 2017-03-16 17:09:45 --> Database Driver Class Initialized
INFO - 2017-03-16 17:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:09:45 --> Controller Class Initialized
INFO - 2017-03-16 17:09:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:09:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 17:09:45 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 17:09:45 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Michelle Zapata')
INFO - 2017-03-16 17:09:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 17:09:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 17:10:14 --> Config Class Initialized
INFO - 2017-03-16 17:10:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:14 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:14 --> URI Class Initialized
INFO - 2017-03-16 17:10:14 --> Router Class Initialized
INFO - 2017-03-16 17:10:14 --> Output Class Initialized
INFO - 2017-03-16 17:10:14 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:14 --> Input Class Initialized
INFO - 2017-03-16 17:10:14 --> Language Class Initialized
INFO - 2017-03-16 17:10:14 --> Loader Class Initialized
INFO - 2017-03-16 17:10:14 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:14 --> Controller Class Initialized
INFO - 2017-03-16 17:10:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:14 --> Config Class Initialized
INFO - 2017-03-16 17:10:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:14 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:14 --> URI Class Initialized
DEBUG - 2017-03-16 17:10:14 --> No URI present. Default controller set.
INFO - 2017-03-16 17:10:14 --> Router Class Initialized
INFO - 2017-03-16 17:10:14 --> Output Class Initialized
INFO - 2017-03-16 17:10:14 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:14 --> Input Class Initialized
INFO - 2017-03-16 17:10:14 --> Language Class Initialized
INFO - 2017-03-16 17:10:14 --> Loader Class Initialized
INFO - 2017-03-16 17:10:14 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:14 --> Controller Class Initialized
INFO - 2017-03-16 17:10:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:14 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:14 --> Total execution time: 0.0134
INFO - 2017-03-16 17:10:14 --> Config Class Initialized
INFO - 2017-03-16 17:10:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:14 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:14 --> URI Class Initialized
INFO - 2017-03-16 17:10:14 --> Router Class Initialized
INFO - 2017-03-16 17:10:14 --> Output Class Initialized
INFO - 2017-03-16 17:10:14 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:14 --> Input Class Initialized
INFO - 2017-03-16 17:10:14 --> Language Class Initialized
INFO - 2017-03-16 17:10:14 --> Loader Class Initialized
INFO - 2017-03-16 17:10:14 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:14 --> Controller Class Initialized
INFO - 2017-03-16 17:10:14 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:14 --> Helper loaded: url_helper
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:14 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:14 --> Total execution time: 0.0894
INFO - 2017-03-16 17:10:20 --> Config Class Initialized
INFO - 2017-03-16 17:10:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:20 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:20 --> URI Class Initialized
DEBUG - 2017-03-16 17:10:20 --> No URI present. Default controller set.
INFO - 2017-03-16 17:10:20 --> Router Class Initialized
INFO - 2017-03-16 17:10:20 --> Output Class Initialized
INFO - 2017-03-16 17:10:20 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:20 --> Input Class Initialized
INFO - 2017-03-16 17:10:20 --> Language Class Initialized
INFO - 2017-03-16 17:10:20 --> Loader Class Initialized
INFO - 2017-03-16 17:10:20 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:20 --> Controller Class Initialized
INFO - 2017-03-16 17:10:20 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:20 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:20 --> Total execution time: 0.0140
INFO - 2017-03-16 17:10:21 --> Config Class Initialized
INFO - 2017-03-16 17:10:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:21 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:21 --> URI Class Initialized
INFO - 2017-03-16 17:10:21 --> Router Class Initialized
INFO - 2017-03-16 17:10:21 --> Output Class Initialized
INFO - 2017-03-16 17:10:21 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:21 --> Input Class Initialized
INFO - 2017-03-16 17:10:21 --> Language Class Initialized
INFO - 2017-03-16 17:10:21 --> Loader Class Initialized
INFO - 2017-03-16 17:10:21 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:21 --> Controller Class Initialized
INFO - 2017-03-16 17:10:21 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:21 --> Helper loaded: url_helper
INFO - 2017-03-16 17:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:21 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:21 --> Total execution time: 0.0143
INFO - 2017-03-16 17:10:28 --> Config Class Initialized
INFO - 2017-03-16 17:10:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:28 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:28 --> URI Class Initialized
INFO - 2017-03-16 17:10:28 --> Router Class Initialized
INFO - 2017-03-16 17:10:28 --> Output Class Initialized
INFO - 2017-03-16 17:10:28 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:28 --> Input Class Initialized
INFO - 2017-03-16 17:10:28 --> Language Class Initialized
INFO - 2017-03-16 17:10:28 --> Loader Class Initialized
INFO - 2017-03-16 17:10:28 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:28 --> Controller Class Initialized
INFO - 2017-03-16 17:10:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:28 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:28 --> Total execution time: 0.0140
INFO - 2017-03-16 17:10:33 --> Config Class Initialized
INFO - 2017-03-16 17:10:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:33 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:33 --> URI Class Initialized
DEBUG - 2017-03-16 17:10:33 --> No URI present. Default controller set.
INFO - 2017-03-16 17:10:33 --> Router Class Initialized
INFO - 2017-03-16 17:10:33 --> Output Class Initialized
INFO - 2017-03-16 17:10:33 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:33 --> Input Class Initialized
INFO - 2017-03-16 17:10:33 --> Language Class Initialized
INFO - 2017-03-16 17:10:33 --> Loader Class Initialized
INFO - 2017-03-16 17:10:33 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:33 --> Controller Class Initialized
INFO - 2017-03-16 17:10:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:33 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:33 --> Total execution time: 0.0138
INFO - 2017-03-16 17:10:37 --> Config Class Initialized
INFO - 2017-03-16 17:10:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:37 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:37 --> URI Class Initialized
INFO - 2017-03-16 17:10:37 --> Router Class Initialized
INFO - 2017-03-16 17:10:37 --> Output Class Initialized
INFO - 2017-03-16 17:10:37 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:37 --> Input Class Initialized
INFO - 2017-03-16 17:10:37 --> Language Class Initialized
INFO - 2017-03-16 17:10:37 --> Loader Class Initialized
INFO - 2017-03-16 17:10:37 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:37 --> Controller Class Initialized
INFO - 2017-03-16 17:10:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:37 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:37 --> Total execution time: 0.0140
INFO - 2017-03-16 17:10:44 --> Config Class Initialized
INFO - 2017-03-16 17:10:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:44 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:44 --> URI Class Initialized
INFO - 2017-03-16 17:10:44 --> Router Class Initialized
INFO - 2017-03-16 17:10:44 --> Output Class Initialized
INFO - 2017-03-16 17:10:44 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:44 --> Input Class Initialized
INFO - 2017-03-16 17:10:44 --> Language Class Initialized
INFO - 2017-03-16 17:10:44 --> Loader Class Initialized
INFO - 2017-03-16 17:10:45 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:45 --> Controller Class Initialized
INFO - 2017-03-16 17:10:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-16 17:10:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-16 17:10:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-16 17:10:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-16 17:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:10:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:46 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:46 --> Total execution time: 1.7551
INFO - 2017-03-16 17:10:52 --> Config Class Initialized
INFO - 2017-03-16 17:10:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:10:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:10:52 --> Utf8 Class Initialized
INFO - 2017-03-16 17:10:52 --> URI Class Initialized
DEBUG - 2017-03-16 17:10:52 --> No URI present. Default controller set.
INFO - 2017-03-16 17:10:52 --> Router Class Initialized
INFO - 2017-03-16 17:10:52 --> Output Class Initialized
INFO - 2017-03-16 17:10:52 --> Security Class Initialized
DEBUG - 2017-03-16 17:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:10:52 --> Input Class Initialized
INFO - 2017-03-16 17:10:52 --> Language Class Initialized
INFO - 2017-03-16 17:10:52 --> Loader Class Initialized
INFO - 2017-03-16 17:10:52 --> Database Driver Class Initialized
INFO - 2017-03-16 17:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:10:52 --> Controller Class Initialized
INFO - 2017-03-16 17:10:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:10:52 --> Final output sent to browser
DEBUG - 2017-03-16 17:10:52 --> Total execution time: 0.0214
INFO - 2017-03-16 17:11:03 --> Config Class Initialized
INFO - 2017-03-16 17:11:03 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:03 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:03 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:03 --> URI Class Initialized
INFO - 2017-03-16 17:11:03 --> Router Class Initialized
INFO - 2017-03-16 17:11:03 --> Output Class Initialized
INFO - 2017-03-16 17:11:03 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:03 --> Input Class Initialized
INFO - 2017-03-16 17:11:03 --> Language Class Initialized
INFO - 2017-03-16 17:11:03 --> Loader Class Initialized
INFO - 2017-03-16 17:11:03 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:03 --> Controller Class Initialized
INFO - 2017-03-16 17:11:03 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 17:11:04 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 17:11:04 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Peter Mendez')
INFO - 2017-03-16 17:11:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 17:11:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 17:11:05 --> Config Class Initialized
INFO - 2017-03-16 17:11:05 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:05 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:05 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:05 --> URI Class Initialized
INFO - 2017-03-16 17:11:05 --> Router Class Initialized
INFO - 2017-03-16 17:11:05 --> Output Class Initialized
INFO - 2017-03-16 17:11:05 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:05 --> Input Class Initialized
INFO - 2017-03-16 17:11:05 --> Language Class Initialized
INFO - 2017-03-16 17:11:05 --> Loader Class Initialized
INFO - 2017-03-16 17:11:05 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:05 --> Controller Class Initialized
INFO - 2017-03-16 17:11:05 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:11:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:11:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:05 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:05 --> Total execution time: 0.0148
INFO - 2017-03-16 17:11:08 --> Config Class Initialized
INFO - 2017-03-16 17:11:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:08 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:08 --> URI Class Initialized
INFO - 2017-03-16 17:11:08 --> Router Class Initialized
INFO - 2017-03-16 17:11:08 --> Output Class Initialized
INFO - 2017-03-16 17:11:08 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:08 --> Input Class Initialized
INFO - 2017-03-16 17:11:08 --> Language Class Initialized
INFO - 2017-03-16 17:11:08 --> Loader Class Initialized
INFO - 2017-03-16 17:11:08 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:08 --> Controller Class Initialized
INFO - 2017-03-16 17:11:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 17:11:08 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 17:11:08 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Peter Mendez')
INFO - 2017-03-16 17:11:08 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 17:11:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 17:11:08 --> Config Class Initialized
INFO - 2017-03-16 17:11:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:08 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:08 --> URI Class Initialized
INFO - 2017-03-16 17:11:08 --> Router Class Initialized
INFO - 2017-03-16 17:11:08 --> Output Class Initialized
INFO - 2017-03-16 17:11:08 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:08 --> Input Class Initialized
INFO - 2017-03-16 17:11:08 --> Language Class Initialized
INFO - 2017-03-16 17:11:08 --> Loader Class Initialized
INFO - 2017-03-16 17:11:08 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:08 --> Controller Class Initialized
INFO - 2017-03-16 17:11:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:08 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:08 --> Total execution time: 0.0136
INFO - 2017-03-16 17:11:09 --> Config Class Initialized
INFO - 2017-03-16 17:11:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:09 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:09 --> URI Class Initialized
INFO - 2017-03-16 17:11:09 --> Router Class Initialized
INFO - 2017-03-16 17:11:09 --> Output Class Initialized
INFO - 2017-03-16 17:11:09 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:09 --> Input Class Initialized
INFO - 2017-03-16 17:11:09 --> Language Class Initialized
INFO - 2017-03-16 17:11:09 --> Loader Class Initialized
INFO - 2017-03-16 17:11:09 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:09 --> Controller Class Initialized
INFO - 2017-03-16 17:11:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 17:11:10 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 17:11:10 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Peter Mendez')
INFO - 2017-03-16 17:11:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 17:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 17:11:10 --> Config Class Initialized
INFO - 2017-03-16 17:11:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:10 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:10 --> URI Class Initialized
INFO - 2017-03-16 17:11:10 --> Router Class Initialized
INFO - 2017-03-16 17:11:10 --> Output Class Initialized
INFO - 2017-03-16 17:11:10 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:10 --> Input Class Initialized
INFO - 2017-03-16 17:11:10 --> Language Class Initialized
INFO - 2017-03-16 17:11:10 --> Loader Class Initialized
INFO - 2017-03-16 17:11:10 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:10 --> Controller Class Initialized
INFO - 2017-03-16 17:11:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:10 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:10 --> Total execution time: 0.0133
INFO - 2017-03-16 17:11:10 --> Config Class Initialized
INFO - 2017-03-16 17:11:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:10 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:10 --> URI Class Initialized
DEBUG - 2017-03-16 17:11:10 --> No URI present. Default controller set.
INFO - 2017-03-16 17:11:10 --> Router Class Initialized
INFO - 2017-03-16 17:11:10 --> Output Class Initialized
INFO - 2017-03-16 17:11:10 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:10 --> Input Class Initialized
INFO - 2017-03-16 17:11:10 --> Language Class Initialized
INFO - 2017-03-16 17:11:10 --> Loader Class Initialized
INFO - 2017-03-16 17:11:10 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:10 --> Controller Class Initialized
INFO - 2017-03-16 17:11:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:11:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:10 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:10 --> Total execution time: 0.0275
INFO - 2017-03-16 17:11:19 --> Config Class Initialized
INFO - 2017-03-16 17:11:19 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:19 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:19 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:19 --> URI Class Initialized
DEBUG - 2017-03-16 17:11:19 --> No URI present. Default controller set.
INFO - 2017-03-16 17:11:19 --> Router Class Initialized
INFO - 2017-03-16 17:11:19 --> Output Class Initialized
INFO - 2017-03-16 17:11:19 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:19 --> Input Class Initialized
INFO - 2017-03-16 17:11:19 --> Language Class Initialized
INFO - 2017-03-16 17:11:19 --> Loader Class Initialized
INFO - 2017-03-16 17:11:19 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:20 --> Controller Class Initialized
INFO - 2017-03-16 17:11:20 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:20 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:20 --> Total execution time: 1.2335
INFO - 2017-03-16 17:11:23 --> Config Class Initialized
INFO - 2017-03-16 17:11:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:23 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:23 --> URI Class Initialized
INFO - 2017-03-16 17:11:23 --> Router Class Initialized
INFO - 2017-03-16 17:11:23 --> Output Class Initialized
INFO - 2017-03-16 17:11:23 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:23 --> Input Class Initialized
INFO - 2017-03-16 17:11:23 --> Language Class Initialized
INFO - 2017-03-16 17:11:23 --> Loader Class Initialized
INFO - 2017-03-16 17:11:23 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:23 --> Controller Class Initialized
INFO - 2017-03-16 17:11:23 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:23 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:23 --> Total execution time: 0.0145
INFO - 2017-03-16 17:11:29 --> Config Class Initialized
INFO - 2017-03-16 17:11:29 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:29 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:29 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:29 --> URI Class Initialized
DEBUG - 2017-03-16 17:11:29 --> No URI present. Default controller set.
INFO - 2017-03-16 17:11:29 --> Router Class Initialized
INFO - 2017-03-16 17:11:29 --> Output Class Initialized
INFO - 2017-03-16 17:11:29 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:29 --> Input Class Initialized
INFO - 2017-03-16 17:11:29 --> Language Class Initialized
INFO - 2017-03-16 17:11:29 --> Loader Class Initialized
INFO - 2017-03-16 17:11:29 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:29 --> Controller Class Initialized
INFO - 2017-03-16 17:11:29 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:29 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:29 --> Total execution time: 0.0140
INFO - 2017-03-16 17:11:30 --> Config Class Initialized
INFO - 2017-03-16 17:11:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:30 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:30 --> URI Class Initialized
INFO - 2017-03-16 17:11:30 --> Router Class Initialized
INFO - 2017-03-16 17:11:30 --> Output Class Initialized
INFO - 2017-03-16 17:11:30 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:30 --> Input Class Initialized
INFO - 2017-03-16 17:11:30 --> Language Class Initialized
INFO - 2017-03-16 17:11:30 --> Loader Class Initialized
INFO - 2017-03-16 17:11:30 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:30 --> Controller Class Initialized
INFO - 2017-03-16 17:11:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:30 --> Config Class Initialized
INFO - 2017-03-16 17:11:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:11:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:11:30 --> Utf8 Class Initialized
INFO - 2017-03-16 17:11:30 --> URI Class Initialized
INFO - 2017-03-16 17:11:30 --> Router Class Initialized
INFO - 2017-03-16 17:11:30 --> Output Class Initialized
INFO - 2017-03-16 17:11:30 --> Security Class Initialized
DEBUG - 2017-03-16 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:11:30 --> Input Class Initialized
INFO - 2017-03-16 17:11:30 --> Language Class Initialized
INFO - 2017-03-16 17:11:30 --> Loader Class Initialized
INFO - 2017-03-16 17:11:30 --> Database Driver Class Initialized
INFO - 2017-03-16 17:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:11:30 --> Controller Class Initialized
INFO - 2017-03-16 17:11:30 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:11:30 --> Helper loaded: url_helper
INFO - 2017-03-16 17:11:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:11:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:11:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:11:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:11:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:11:30 --> Final output sent to browser
DEBUG - 2017-03-16 17:11:30 --> Total execution time: 0.0976
INFO - 2017-03-16 17:12:33 --> Config Class Initialized
INFO - 2017-03-16 17:12:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:12:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:12:33 --> Utf8 Class Initialized
INFO - 2017-03-16 17:12:33 --> URI Class Initialized
INFO - 2017-03-16 17:12:33 --> Router Class Initialized
INFO - 2017-03-16 17:12:33 --> Output Class Initialized
INFO - 2017-03-16 17:12:33 --> Security Class Initialized
DEBUG - 2017-03-16 17:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:12:33 --> Input Class Initialized
INFO - 2017-03-16 17:12:33 --> Language Class Initialized
INFO - 2017-03-16 17:12:33 --> Loader Class Initialized
INFO - 2017-03-16 17:12:33 --> Database Driver Class Initialized
INFO - 2017-03-16 17:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:12:34 --> Controller Class Initialized
INFO - 2017-03-16 17:12:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:12:34 --> Config Class Initialized
INFO - 2017-03-16 17:12:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:12:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:12:34 --> Utf8 Class Initialized
INFO - 2017-03-16 17:12:34 --> URI Class Initialized
INFO - 2017-03-16 17:12:34 --> Router Class Initialized
INFO - 2017-03-16 17:12:34 --> Output Class Initialized
INFO - 2017-03-16 17:12:34 --> Security Class Initialized
DEBUG - 2017-03-16 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:12:34 --> Input Class Initialized
INFO - 2017-03-16 17:12:34 --> Language Class Initialized
INFO - 2017-03-16 17:12:34 --> Loader Class Initialized
INFO - 2017-03-16 17:12:34 --> Database Driver Class Initialized
INFO - 2017-03-16 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:12:34 --> Controller Class Initialized
INFO - 2017-03-16 17:12:34 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:12:34 --> Helper loaded: url_helper
INFO - 2017-03-16 17:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:12:34 --> Final output sent to browser
DEBUG - 2017-03-16 17:12:34 --> Total execution time: 0.0979
INFO - 2017-03-16 17:12:36 --> Config Class Initialized
INFO - 2017-03-16 17:12:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:12:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:12:36 --> Utf8 Class Initialized
INFO - 2017-03-16 17:12:36 --> URI Class Initialized
INFO - 2017-03-16 17:12:36 --> Router Class Initialized
INFO - 2017-03-16 17:12:36 --> Output Class Initialized
INFO - 2017-03-16 17:12:36 --> Security Class Initialized
DEBUG - 2017-03-16 17:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:12:36 --> Input Class Initialized
INFO - 2017-03-16 17:12:36 --> Language Class Initialized
INFO - 2017-03-16 17:12:36 --> Loader Class Initialized
INFO - 2017-03-16 17:12:36 --> Database Driver Class Initialized
INFO - 2017-03-16 17:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:12:36 --> Controller Class Initialized
INFO - 2017-03-16 17:12:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:12:36 --> Final output sent to browser
DEBUG - 2017-03-16 17:12:36 --> Total execution time: 0.0258
INFO - 2017-03-16 17:12:57 --> Config Class Initialized
INFO - 2017-03-16 17:12:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:12:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:12:57 --> Utf8 Class Initialized
INFO - 2017-03-16 17:12:57 --> URI Class Initialized
DEBUG - 2017-03-16 17:12:57 --> No URI present. Default controller set.
INFO - 2017-03-16 17:12:57 --> Router Class Initialized
INFO - 2017-03-16 17:12:57 --> Output Class Initialized
INFO - 2017-03-16 17:12:57 --> Security Class Initialized
DEBUG - 2017-03-16 17:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:12:57 --> Input Class Initialized
INFO - 2017-03-16 17:12:57 --> Language Class Initialized
INFO - 2017-03-16 17:12:57 --> Loader Class Initialized
INFO - 2017-03-16 17:12:57 --> Database Driver Class Initialized
INFO - 2017-03-16 17:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:12:57 --> Controller Class Initialized
INFO - 2017-03-16 17:12:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:12:57 --> Final output sent to browser
DEBUG - 2017-03-16 17:12:57 --> Total execution time: 0.0255
INFO - 2017-03-16 17:12:59 --> Config Class Initialized
INFO - 2017-03-16 17:12:59 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:12:59 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:12:59 --> Utf8 Class Initialized
INFO - 2017-03-16 17:12:59 --> URI Class Initialized
INFO - 2017-03-16 17:12:59 --> Router Class Initialized
INFO - 2017-03-16 17:12:59 --> Output Class Initialized
INFO - 2017-03-16 17:13:00 --> Security Class Initialized
DEBUG - 2017-03-16 17:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:13:00 --> Input Class Initialized
INFO - 2017-03-16 17:13:00 --> Language Class Initialized
INFO - 2017-03-16 17:13:00 --> Loader Class Initialized
INFO - 2017-03-16 17:13:00 --> Database Driver Class Initialized
INFO - 2017-03-16 17:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:13:00 --> Controller Class Initialized
INFO - 2017-03-16 17:13:00 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:13:00 --> Final output sent to browser
DEBUG - 2017-03-16 17:13:00 --> Total execution time: 0.0135
INFO - 2017-03-16 17:13:50 --> Config Class Initialized
INFO - 2017-03-16 17:13:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:13:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:13:50 --> Utf8 Class Initialized
INFO - 2017-03-16 17:13:50 --> URI Class Initialized
INFO - 2017-03-16 17:13:50 --> Router Class Initialized
INFO - 2017-03-16 17:13:50 --> Output Class Initialized
INFO - 2017-03-16 17:13:50 --> Security Class Initialized
DEBUG - 2017-03-16 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:13:50 --> Input Class Initialized
INFO - 2017-03-16 17:13:50 --> Language Class Initialized
INFO - 2017-03-16 17:13:50 --> Loader Class Initialized
INFO - 2017-03-16 17:13:50 --> Database Driver Class Initialized
INFO - 2017-03-16 17:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:13:50 --> Controller Class Initialized
INFO - 2017-03-16 17:13:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:13:50 --> Helper loaded: form_helper
INFO - 2017-03-16 17:13:50 --> Form Validation Class Initialized
INFO - 2017-03-16 17:13:50 --> Config Class Initialized
INFO - 2017-03-16 17:13:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:13:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:13:50 --> Utf8 Class Initialized
INFO - 2017-03-16 17:13:50 --> URI Class Initialized
DEBUG - 2017-03-16 17:13:50 --> No URI present. Default controller set.
INFO - 2017-03-16 17:13:50 --> Router Class Initialized
INFO - 2017-03-16 17:13:50 --> Output Class Initialized
INFO - 2017-03-16 17:13:50 --> Security Class Initialized
DEBUG - 2017-03-16 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:13:50 --> Input Class Initialized
INFO - 2017-03-16 17:13:50 --> Language Class Initialized
INFO - 2017-03-16 17:13:50 --> Loader Class Initialized
INFO - 2017-03-16 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 17:13:50 --> Database Driver Class Initialized
INFO - 2017-03-16 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-16 17:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:13:50 --> Controller Class Initialized
INFO - 2017-03-16 17:13:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:13:50 --> Final output sent to browser
DEBUG - 2017-03-16 17:13:50 --> Total execution time: 0.8575
INFO - 2017-03-16 17:13:50 --> Final output sent to browser
DEBUG - 2017-03-16 17:13:50 --> Total execution time: 0.7891
INFO - 2017-03-16 17:13:51 --> Config Class Initialized
INFO - 2017-03-16 17:13:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:13:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:13:51 --> Utf8 Class Initialized
INFO - 2017-03-16 17:13:51 --> URI Class Initialized
INFO - 2017-03-16 17:13:51 --> Router Class Initialized
INFO - 2017-03-16 17:13:51 --> Output Class Initialized
INFO - 2017-03-16 17:13:51 --> Security Class Initialized
DEBUG - 2017-03-16 17:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:13:51 --> Input Class Initialized
INFO - 2017-03-16 17:13:51 --> Language Class Initialized
INFO - 2017-03-16 17:13:51 --> Loader Class Initialized
INFO - 2017-03-16 17:13:51 --> Database Driver Class Initialized
INFO - 2017-03-16 17:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:13:51 --> Controller Class Initialized
INFO - 2017-03-16 17:13:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:13:51 --> Final output sent to browser
DEBUG - 2017-03-16 17:13:51 --> Total execution time: 0.0138
INFO - 2017-03-16 17:14:16 --> Config Class Initialized
INFO - 2017-03-16 17:14:16 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:14:16 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:14:16 --> Utf8 Class Initialized
INFO - 2017-03-16 17:14:16 --> URI Class Initialized
INFO - 2017-03-16 17:14:16 --> Router Class Initialized
INFO - 2017-03-16 17:14:16 --> Output Class Initialized
INFO - 2017-03-16 17:14:16 --> Security Class Initialized
DEBUG - 2017-03-16 17:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:14:16 --> Input Class Initialized
INFO - 2017-03-16 17:14:16 --> Language Class Initialized
INFO - 2017-03-16 17:14:16 --> Loader Class Initialized
INFO - 2017-03-16 17:14:16 --> Database Driver Class Initialized
INFO - 2017-03-16 17:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:14:16 --> Controller Class Initialized
INFO - 2017-03-16 17:14:16 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:14:22 --> Config Class Initialized
INFO - 2017-03-16 17:14:22 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:14:22 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:14:22 --> Utf8 Class Initialized
INFO - 2017-03-16 17:14:22 --> URI Class Initialized
INFO - 2017-03-16 17:14:22 --> Router Class Initialized
INFO - 2017-03-16 17:14:22 --> Output Class Initialized
INFO - 2017-03-16 17:14:22 --> Security Class Initialized
DEBUG - 2017-03-16 17:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:14:22 --> Input Class Initialized
INFO - 2017-03-16 17:14:22 --> Language Class Initialized
INFO - 2017-03-16 17:14:22 --> Loader Class Initialized
INFO - 2017-03-16 17:14:22 --> Database Driver Class Initialized
INFO - 2017-03-16 17:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:14:22 --> Controller Class Initialized
INFO - 2017-03-16 17:14:22 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:14:22 --> Helper loaded: url_helper
INFO - 2017-03-16 17:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:14:22 --> Final output sent to browser
DEBUG - 2017-03-16 17:14:22 --> Total execution time: 0.0140
INFO - 2017-03-16 17:32:07 --> Config Class Initialized
INFO - 2017-03-16 17:32:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:32:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:32:07 --> Utf8 Class Initialized
INFO - 2017-03-16 17:32:07 --> URI Class Initialized
INFO - 2017-03-16 17:32:07 --> Router Class Initialized
INFO - 2017-03-16 17:32:07 --> Output Class Initialized
INFO - 2017-03-16 17:32:07 --> Security Class Initialized
DEBUG - 2017-03-16 17:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:32:08 --> Input Class Initialized
INFO - 2017-03-16 17:32:08 --> Language Class Initialized
INFO - 2017-03-16 17:32:08 --> Loader Class Initialized
INFO - 2017-03-16 17:32:08 --> Database Driver Class Initialized
INFO - 2017-03-16 17:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:32:09 --> Controller Class Initialized
INFO - 2017-03-16 17:32:09 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:32:09 --> Helper loaded: url_helper
INFO - 2017-03-16 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:32:09 --> Final output sent to browser
DEBUG - 2017-03-16 17:32:09 --> Total execution time: 2.0043
INFO - 2017-03-16 17:34:27 --> Config Class Initialized
INFO - 2017-03-16 17:34:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:34:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:34:27 --> Utf8 Class Initialized
INFO - 2017-03-16 17:34:27 --> URI Class Initialized
INFO - 2017-03-16 17:34:27 --> Router Class Initialized
INFO - 2017-03-16 17:34:27 --> Output Class Initialized
INFO - 2017-03-16 17:34:27 --> Security Class Initialized
DEBUG - 2017-03-16 17:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:34:27 --> Input Class Initialized
INFO - 2017-03-16 17:34:27 --> Language Class Initialized
INFO - 2017-03-16 17:34:27 --> Loader Class Initialized
INFO - 2017-03-16 17:34:28 --> Database Driver Class Initialized
INFO - 2017-03-16 17:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:34:28 --> Controller Class Initialized
INFO - 2017-03-16 17:34:28 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:34:28 --> Helper loaded: url_helper
INFO - 2017-03-16 17:34:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:34:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:34:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:34:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:34:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:34:28 --> Final output sent to browser
DEBUG - 2017-03-16 17:34:28 --> Total execution time: 1.4838
INFO - 2017-03-16 17:36:54 --> Config Class Initialized
INFO - 2017-03-16 17:36:54 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:36:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:36:55 --> Utf8 Class Initialized
INFO - 2017-03-16 17:36:55 --> URI Class Initialized
DEBUG - 2017-03-16 17:36:55 --> No URI present. Default controller set.
INFO - 2017-03-16 17:36:55 --> Router Class Initialized
INFO - 2017-03-16 17:36:55 --> Output Class Initialized
INFO - 2017-03-16 17:36:55 --> Security Class Initialized
DEBUG - 2017-03-16 17:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:36:55 --> Input Class Initialized
INFO - 2017-03-16 17:36:55 --> Language Class Initialized
INFO - 2017-03-16 17:36:55 --> Loader Class Initialized
INFO - 2017-03-16 17:36:55 --> Database Driver Class Initialized
INFO - 2017-03-16 17:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:36:56 --> Controller Class Initialized
INFO - 2017-03-16 17:36:56 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:36:56 --> Final output sent to browser
DEBUG - 2017-03-16 17:36:56 --> Total execution time: 1.6407
INFO - 2017-03-16 17:37:02 --> Config Class Initialized
INFO - 2017-03-16 17:37:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:37:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:37:02 --> Utf8 Class Initialized
INFO - 2017-03-16 17:37:02 --> URI Class Initialized
INFO - 2017-03-16 17:37:02 --> Router Class Initialized
INFO - 2017-03-16 17:37:06 --> Output Class Initialized
INFO - 2017-03-16 17:37:06 --> Security Class Initialized
DEBUG - 2017-03-16 17:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:37:06 --> Input Class Initialized
INFO - 2017-03-16 17:37:06 --> Language Class Initialized
INFO - 2017-03-16 17:37:06 --> Loader Class Initialized
INFO - 2017-03-16 17:37:06 --> Database Driver Class Initialized
INFO - 2017-03-16 17:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:37:06 --> Controller Class Initialized
INFO - 2017-03-16 17:37:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:37:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:37:06 --> Final output sent to browser
DEBUG - 2017-03-16 17:37:06 --> Total execution time: 4.4277
INFO - 2017-03-16 17:37:10 --> Config Class Initialized
INFO - 2017-03-16 17:37:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:37:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:37:10 --> Utf8 Class Initialized
INFO - 2017-03-16 17:37:10 --> URI Class Initialized
INFO - 2017-03-16 17:37:10 --> Router Class Initialized
INFO - 2017-03-16 17:37:10 --> Output Class Initialized
INFO - 2017-03-16 17:37:10 --> Security Class Initialized
DEBUG - 2017-03-16 17:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:37:10 --> Input Class Initialized
INFO - 2017-03-16 17:37:10 --> Language Class Initialized
INFO - 2017-03-16 17:37:10 --> Loader Class Initialized
INFO - 2017-03-16 17:37:10 --> Database Driver Class Initialized
INFO - 2017-03-16 17:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:37:10 --> Controller Class Initialized
INFO - 2017-03-16 17:37:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:37:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:37:11 --> Config Class Initialized
INFO - 2017-03-16 17:37:11 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:37:11 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:37:11 --> Utf8 Class Initialized
INFO - 2017-03-16 17:37:11 --> URI Class Initialized
INFO - 2017-03-16 17:37:11 --> Router Class Initialized
INFO - 2017-03-16 17:37:11 --> Output Class Initialized
INFO - 2017-03-16 17:37:11 --> Security Class Initialized
DEBUG - 2017-03-16 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:37:11 --> Input Class Initialized
INFO - 2017-03-16 17:37:11 --> Language Class Initialized
INFO - 2017-03-16 17:37:11 --> Loader Class Initialized
INFO - 2017-03-16 17:37:11 --> Database Driver Class Initialized
INFO - 2017-03-16 17:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:37:11 --> Controller Class Initialized
INFO - 2017-03-16 17:37:11 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:37:11 --> Helper loaded: url_helper
INFO - 2017-03-16 17:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:37:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:37:11 --> Final output sent to browser
DEBUG - 2017-03-16 17:37:11 --> Total execution time: 0.0954
INFO - 2017-03-16 17:37:12 --> Config Class Initialized
INFO - 2017-03-16 17:37:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:37:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:37:12 --> Utf8 Class Initialized
INFO - 2017-03-16 17:37:12 --> URI Class Initialized
INFO - 2017-03-16 17:37:12 --> Router Class Initialized
INFO - 2017-03-16 17:37:12 --> Output Class Initialized
INFO - 2017-03-16 17:37:12 --> Security Class Initialized
DEBUG - 2017-03-16 17:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:37:12 --> Input Class Initialized
INFO - 2017-03-16 17:37:12 --> Language Class Initialized
INFO - 2017-03-16 17:37:12 --> Loader Class Initialized
INFO - 2017-03-16 17:37:12 --> Database Driver Class Initialized
INFO - 2017-03-16 17:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:37:12 --> Controller Class Initialized
INFO - 2017-03-16 17:37:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:37:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:37:12 --> Final output sent to browser
DEBUG - 2017-03-16 17:37:12 --> Total execution time: 0.0135
INFO - 2017-03-16 17:37:15 --> Config Class Initialized
INFO - 2017-03-16 17:37:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:37:15 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:37:15 --> Utf8 Class Initialized
INFO - 2017-03-16 17:37:15 --> URI Class Initialized
DEBUG - 2017-03-16 17:37:15 --> No URI present. Default controller set.
INFO - 2017-03-16 17:37:15 --> Router Class Initialized
INFO - 2017-03-16 17:37:15 --> Output Class Initialized
INFO - 2017-03-16 17:37:15 --> Security Class Initialized
DEBUG - 2017-03-16 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:37:15 --> Input Class Initialized
INFO - 2017-03-16 17:37:15 --> Language Class Initialized
INFO - 2017-03-16 17:37:15 --> Loader Class Initialized
INFO - 2017-03-16 17:37:15 --> Database Driver Class Initialized
INFO - 2017-03-16 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:37:15 --> Controller Class Initialized
INFO - 2017-03-16 17:37:15 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:37:15 --> Final output sent to browser
DEBUG - 2017-03-16 17:37:15 --> Total execution time: 0.0134
INFO - 2017-03-16 17:37:15 --> Config Class Initialized
INFO - 2017-03-16 17:37:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:37:15 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:37:15 --> Utf8 Class Initialized
INFO - 2017-03-16 17:37:15 --> URI Class Initialized
INFO - 2017-03-16 17:37:15 --> Router Class Initialized
INFO - 2017-03-16 17:37:15 --> Output Class Initialized
INFO - 2017-03-16 17:37:15 --> Security Class Initialized
DEBUG - 2017-03-16 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:37:15 --> Input Class Initialized
INFO - 2017-03-16 17:37:15 --> Language Class Initialized
INFO - 2017-03-16 17:37:15 --> Loader Class Initialized
INFO - 2017-03-16 17:37:15 --> Database Driver Class Initialized
INFO - 2017-03-16 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:37:15 --> Controller Class Initialized
INFO - 2017-03-16 17:37:15 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:37:15 --> Final output sent to browser
DEBUG - 2017-03-16 17:37:15 --> Total execution time: 0.0134
INFO - 2017-03-16 17:58:18 --> Config Class Initialized
INFO - 2017-03-16 17:58:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:18 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:18 --> URI Class Initialized
INFO - 2017-03-16 17:58:18 --> Router Class Initialized
INFO - 2017-03-16 17:58:18 --> Output Class Initialized
INFO - 2017-03-16 17:58:18 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:18 --> Input Class Initialized
INFO - 2017-03-16 17:58:18 --> Language Class Initialized
ERROR - 2017-03-16 17:58:18 --> 404 Page Not Found: Phone/index.html
INFO - 2017-03-16 17:58:18 --> Config Class Initialized
INFO - 2017-03-16 17:58:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:18 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:18 --> URI Class Initialized
INFO - 2017-03-16 17:58:18 --> Router Class Initialized
INFO - 2017-03-16 17:58:18 --> Output Class Initialized
INFO - 2017-03-16 17:58:18 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:18 --> Input Class Initialized
INFO - 2017-03-16 17:58:18 --> Language Class Initialized
INFO - 2017-03-16 17:58:18 --> Loader Class Initialized
INFO - 2017-03-16 17:58:19 --> Database Driver Class Initialized
INFO - 2017-03-16 17:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:58:19 --> Controller Class Initialized
INFO - 2017-03-16 17:58:19 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:58:19 --> Final output sent to browser
DEBUG - 2017-03-16 17:58:19 --> Total execution time: 0.2580
INFO - 2017-03-16 17:58:21 --> Config Class Initialized
INFO - 2017-03-16 17:58:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:21 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:21 --> URI Class Initialized
INFO - 2017-03-16 17:58:21 --> Router Class Initialized
INFO - 2017-03-16 17:58:21 --> Output Class Initialized
INFO - 2017-03-16 17:58:21 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:21 --> Input Class Initialized
INFO - 2017-03-16 17:58:21 --> Language Class Initialized
ERROR - 2017-03-16 17:58:21 --> 404 Page Not Found: Phone/index.html
INFO - 2017-03-16 17:58:21 --> Config Class Initialized
INFO - 2017-03-16 17:58:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:21 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:21 --> URI Class Initialized
INFO - 2017-03-16 17:58:21 --> Router Class Initialized
INFO - 2017-03-16 17:58:21 --> Output Class Initialized
INFO - 2017-03-16 17:58:21 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:21 --> Input Class Initialized
INFO - 2017-03-16 17:58:21 --> Language Class Initialized
INFO - 2017-03-16 17:58:21 --> Loader Class Initialized
INFO - 2017-03-16 17:58:21 --> Database Driver Class Initialized
INFO - 2017-03-16 17:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:58:21 --> Controller Class Initialized
INFO - 2017-03-16 17:58:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:58:21 --> Final output sent to browser
DEBUG - 2017-03-16 17:58:21 --> Total execution time: 0.0132
INFO - 2017-03-16 17:58:31 --> Config Class Initialized
INFO - 2017-03-16 17:58:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:31 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:31 --> URI Class Initialized
INFO - 2017-03-16 17:58:31 --> Router Class Initialized
INFO - 2017-03-16 17:58:31 --> Output Class Initialized
INFO - 2017-03-16 17:58:31 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:31 --> Input Class Initialized
INFO - 2017-03-16 17:58:31 --> Language Class Initialized
ERROR - 2017-03-16 17:58:31 --> 404 Page Not Found: Phone/index.html
INFO - 2017-03-16 17:58:31 --> Config Class Initialized
INFO - 2017-03-16 17:58:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:31 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:31 --> URI Class Initialized
INFO - 2017-03-16 17:58:31 --> Router Class Initialized
INFO - 2017-03-16 17:58:31 --> Output Class Initialized
INFO - 2017-03-16 17:58:31 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:31 --> Input Class Initialized
INFO - 2017-03-16 17:58:31 --> Language Class Initialized
INFO - 2017-03-16 17:58:31 --> Loader Class Initialized
INFO - 2017-03-16 17:58:31 --> Database Driver Class Initialized
INFO - 2017-03-16 17:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:58:31 --> Controller Class Initialized
INFO - 2017-03-16 17:58:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:58:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:58:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:58:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:58:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:58:31 --> Final output sent to browser
DEBUG - 2017-03-16 17:58:31 --> Total execution time: 0.0268
INFO - 2017-03-16 17:58:41 --> Config Class Initialized
INFO - 2017-03-16 17:58:41 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:41 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:41 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:41 --> URI Class Initialized
DEBUG - 2017-03-16 17:58:41 --> No URI present. Default controller set.
INFO - 2017-03-16 17:58:41 --> Router Class Initialized
INFO - 2017-03-16 17:58:41 --> Output Class Initialized
INFO - 2017-03-16 17:58:41 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:41 --> Input Class Initialized
INFO - 2017-03-16 17:58:41 --> Language Class Initialized
INFO - 2017-03-16 17:58:41 --> Loader Class Initialized
INFO - 2017-03-16 17:58:41 --> Database Driver Class Initialized
INFO - 2017-03-16 17:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:58:41 --> Controller Class Initialized
INFO - 2017-03-16 17:58:41 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:58:41 --> Final output sent to browser
DEBUG - 2017-03-16 17:58:41 --> Total execution time: 0.0143
INFO - 2017-03-16 17:58:47 --> Config Class Initialized
INFO - 2017-03-16 17:58:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:47 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:47 --> URI Class Initialized
INFO - 2017-03-16 17:58:47 --> Router Class Initialized
INFO - 2017-03-16 17:58:47 --> Output Class Initialized
INFO - 2017-03-16 17:58:47 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:47 --> Input Class Initialized
INFO - 2017-03-16 17:58:47 --> Language Class Initialized
INFO - 2017-03-16 17:58:47 --> Loader Class Initialized
INFO - 2017-03-16 17:58:47 --> Database Driver Class Initialized
INFO - 2017-03-16 17:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:58:47 --> Controller Class Initialized
INFO - 2017-03-16 17:58:47 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:58:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:58:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:58:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:58:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:58:47 --> Final output sent to browser
DEBUG - 2017-03-16 17:58:47 --> Total execution time: 0.0130
INFO - 2017-03-16 17:58:57 --> Config Class Initialized
INFO - 2017-03-16 17:58:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:57 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:57 --> URI Class Initialized
INFO - 2017-03-16 17:58:57 --> Router Class Initialized
INFO - 2017-03-16 17:58:57 --> Output Class Initialized
INFO - 2017-03-16 17:58:57 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:57 --> Input Class Initialized
INFO - 2017-03-16 17:58:57 --> Language Class Initialized
INFO - 2017-03-16 17:58:57 --> Loader Class Initialized
INFO - 2017-03-16 17:58:57 --> Database Driver Class Initialized
INFO - 2017-03-16 17:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:58:57 --> Controller Class Initialized
INFO - 2017-03-16 17:58:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:58:58 --> Config Class Initialized
INFO - 2017-03-16 17:58:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:58:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:58:58 --> Utf8 Class Initialized
INFO - 2017-03-16 17:58:58 --> URI Class Initialized
INFO - 2017-03-16 17:58:58 --> Router Class Initialized
INFO - 2017-03-16 17:58:58 --> Output Class Initialized
INFO - 2017-03-16 17:58:58 --> Security Class Initialized
DEBUG - 2017-03-16 17:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:58:58 --> Input Class Initialized
INFO - 2017-03-16 17:58:58 --> Language Class Initialized
INFO - 2017-03-16 17:58:58 --> Loader Class Initialized
INFO - 2017-03-16 17:58:58 --> Database Driver Class Initialized
INFO - 2017-03-16 17:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:58:58 --> Controller Class Initialized
INFO - 2017-03-16 17:58:58 --> Helper loaded: date_helper
DEBUG - 2017-03-16 17:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:58:58 --> Helper loaded: url_helper
INFO - 2017-03-16 17:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 17:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 17:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 17:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:58:58 --> Final output sent to browser
DEBUG - 2017-03-16 17:58:58 --> Total execution time: 0.0859
INFO - 2017-03-16 17:59:00 --> Config Class Initialized
INFO - 2017-03-16 17:59:00 --> Hooks Class Initialized
DEBUG - 2017-03-16 17:59:00 --> UTF-8 Support Enabled
INFO - 2017-03-16 17:59:00 --> Utf8 Class Initialized
INFO - 2017-03-16 17:59:00 --> URI Class Initialized
INFO - 2017-03-16 17:59:00 --> Router Class Initialized
INFO - 2017-03-16 17:59:00 --> Output Class Initialized
INFO - 2017-03-16 17:59:00 --> Security Class Initialized
DEBUG - 2017-03-16 17:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 17:59:00 --> Input Class Initialized
INFO - 2017-03-16 17:59:00 --> Language Class Initialized
INFO - 2017-03-16 17:59:00 --> Loader Class Initialized
INFO - 2017-03-16 17:59:00 --> Database Driver Class Initialized
INFO - 2017-03-16 17:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 17:59:00 --> Controller Class Initialized
INFO - 2017-03-16 17:59:00 --> Helper loaded: url_helper
DEBUG - 2017-03-16 17:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 17:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 17:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 17:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 17:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 17:59:00 --> Final output sent to browser
DEBUG - 2017-03-16 17:59:00 --> Total execution time: 0.0143
INFO - 2017-03-16 18:08:02 --> Config Class Initialized
INFO - 2017-03-16 18:08:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 18:08:03 --> UTF-8 Support Enabled
INFO - 2017-03-16 18:08:03 --> Utf8 Class Initialized
INFO - 2017-03-16 18:08:03 --> URI Class Initialized
DEBUG - 2017-03-16 18:08:03 --> No URI present. Default controller set.
INFO - 2017-03-16 18:08:03 --> Router Class Initialized
INFO - 2017-03-16 18:08:03 --> Output Class Initialized
INFO - 2017-03-16 18:08:03 --> Security Class Initialized
DEBUG - 2017-03-16 18:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 18:08:03 --> Input Class Initialized
INFO - 2017-03-16 18:08:03 --> Language Class Initialized
INFO - 2017-03-16 18:08:03 --> Loader Class Initialized
INFO - 2017-03-16 18:08:03 --> Database Driver Class Initialized
INFO - 2017-03-16 18:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 18:08:04 --> Controller Class Initialized
INFO - 2017-03-16 18:08:04 --> Helper loaded: url_helper
DEBUG - 2017-03-16 18:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 18:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 18:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 18:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 18:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 18:08:04 --> Final output sent to browser
DEBUG - 2017-03-16 18:08:04 --> Total execution time: 1.5044
INFO - 2017-03-16 18:08:05 --> Config Class Initialized
INFO - 2017-03-16 18:08:05 --> Hooks Class Initialized
DEBUG - 2017-03-16 18:08:05 --> UTF-8 Support Enabled
INFO - 2017-03-16 18:08:05 --> Utf8 Class Initialized
INFO - 2017-03-16 18:08:05 --> URI Class Initialized
INFO - 2017-03-16 18:08:05 --> Router Class Initialized
INFO - 2017-03-16 18:08:05 --> Output Class Initialized
INFO - 2017-03-16 18:08:05 --> Security Class Initialized
DEBUG - 2017-03-16 18:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 18:08:05 --> Input Class Initialized
INFO - 2017-03-16 18:08:05 --> Language Class Initialized
INFO - 2017-03-16 18:08:05 --> Loader Class Initialized
INFO - 2017-03-16 18:08:05 --> Database Driver Class Initialized
INFO - 2017-03-16 18:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 18:08:06 --> Controller Class Initialized
INFO - 2017-03-16 18:08:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 18:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 18:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 18:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 18:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 18:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 18:08:06 --> Final output sent to browser
DEBUG - 2017-03-16 18:08:06 --> Total execution time: 0.0421
INFO - 2017-03-16 19:23:20 --> Config Class Initialized
INFO - 2017-03-16 19:23:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:23:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:23:20 --> Utf8 Class Initialized
INFO - 2017-03-16 19:23:20 --> URI Class Initialized
DEBUG - 2017-03-16 19:23:20 --> No URI present. Default controller set.
INFO - 2017-03-16 19:23:20 --> Router Class Initialized
INFO - 2017-03-16 19:23:20 --> Output Class Initialized
INFO - 2017-03-16 19:23:20 --> Security Class Initialized
DEBUG - 2017-03-16 19:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:23:20 --> Input Class Initialized
INFO - 2017-03-16 19:23:20 --> Language Class Initialized
INFO - 2017-03-16 19:23:20 --> Loader Class Initialized
INFO - 2017-03-16 19:23:21 --> Database Driver Class Initialized
INFO - 2017-03-16 19:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:23:21 --> Controller Class Initialized
INFO - 2017-03-16 19:23:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:23:21 --> Final output sent to browser
DEBUG - 2017-03-16 19:23:21 --> Total execution time: 1.4613
INFO - 2017-03-16 19:23:24 --> Config Class Initialized
INFO - 2017-03-16 19:23:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:23:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:23:24 --> Utf8 Class Initialized
INFO - 2017-03-16 19:23:24 --> URI Class Initialized
INFO - 2017-03-16 19:23:24 --> Router Class Initialized
INFO - 2017-03-16 19:23:24 --> Output Class Initialized
INFO - 2017-03-16 19:23:24 --> Security Class Initialized
DEBUG - 2017-03-16 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:23:24 --> Input Class Initialized
INFO - 2017-03-16 19:23:24 --> Language Class Initialized
INFO - 2017-03-16 19:23:24 --> Loader Class Initialized
INFO - 2017-03-16 19:23:24 --> Database Driver Class Initialized
INFO - 2017-03-16 19:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:23:24 --> Controller Class Initialized
INFO - 2017-03-16 19:23:24 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:23:24 --> Final output sent to browser
DEBUG - 2017-03-16 19:23:24 --> Total execution time: 0.0162
INFO - 2017-03-16 19:24:03 --> Config Class Initialized
INFO - 2017-03-16 19:24:03 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:24:03 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:24:03 --> Utf8 Class Initialized
INFO - 2017-03-16 19:24:03 --> URI Class Initialized
INFO - 2017-03-16 19:24:03 --> Router Class Initialized
INFO - 2017-03-16 19:24:03 --> Output Class Initialized
INFO - 2017-03-16 19:24:03 --> Security Class Initialized
DEBUG - 2017-03-16 19:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:24:03 --> Input Class Initialized
INFO - 2017-03-16 19:24:03 --> Language Class Initialized
INFO - 2017-03-16 19:24:03 --> Loader Class Initialized
INFO - 2017-03-16 19:24:03 --> Database Driver Class Initialized
INFO - 2017-03-16 19:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:24:03 --> Controller Class Initialized
INFO - 2017-03-16 19:24:03 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:24:06 --> Config Class Initialized
INFO - 2017-03-16 19:24:06 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:24:06 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:24:06 --> Utf8 Class Initialized
INFO - 2017-03-16 19:24:06 --> URI Class Initialized
INFO - 2017-03-16 19:24:06 --> Router Class Initialized
INFO - 2017-03-16 19:24:06 --> Output Class Initialized
INFO - 2017-03-16 19:24:06 --> Security Class Initialized
DEBUG - 2017-03-16 19:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:24:06 --> Input Class Initialized
INFO - 2017-03-16 19:24:06 --> Language Class Initialized
INFO - 2017-03-16 19:24:06 --> Loader Class Initialized
INFO - 2017-03-16 19:24:06 --> Database Driver Class Initialized
INFO - 2017-03-16 19:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:24:06 --> Controller Class Initialized
INFO - 2017-03-16 19:24:06 --> Helper loaded: date_helper
DEBUG - 2017-03-16 19:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:24:06 --> Helper loaded: url_helper
INFO - 2017-03-16 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 19:24:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:24:06 --> Final output sent to browser
DEBUG - 2017-03-16 19:24:06 --> Total execution time: 0.7998
INFO - 2017-03-16 19:24:08 --> Config Class Initialized
INFO - 2017-03-16 19:24:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:24:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:24:08 --> Utf8 Class Initialized
INFO - 2017-03-16 19:24:08 --> URI Class Initialized
INFO - 2017-03-16 19:24:08 --> Router Class Initialized
INFO - 2017-03-16 19:24:08 --> Output Class Initialized
INFO - 2017-03-16 19:24:08 --> Security Class Initialized
DEBUG - 2017-03-16 19:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:24:08 --> Input Class Initialized
INFO - 2017-03-16 19:24:08 --> Language Class Initialized
INFO - 2017-03-16 19:24:08 --> Loader Class Initialized
INFO - 2017-03-16 19:24:08 --> Database Driver Class Initialized
INFO - 2017-03-16 19:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:24:08 --> Controller Class Initialized
INFO - 2017-03-16 19:24:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:24:08 --> Final output sent to browser
DEBUG - 2017-03-16 19:24:08 --> Total execution time: 0.0960
INFO - 2017-03-16 19:24:11 --> Config Class Initialized
INFO - 2017-03-16 19:24:11 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:24:11 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:24:11 --> Utf8 Class Initialized
INFO - 2017-03-16 19:24:11 --> URI Class Initialized
INFO - 2017-03-16 19:24:11 --> Router Class Initialized
INFO - 2017-03-16 19:24:11 --> Output Class Initialized
INFO - 2017-03-16 19:24:11 --> Security Class Initialized
DEBUG - 2017-03-16 19:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:24:11 --> Input Class Initialized
INFO - 2017-03-16 19:24:11 --> Language Class Initialized
INFO - 2017-03-16 19:24:11 --> Loader Class Initialized
INFO - 2017-03-16 19:24:11 --> Database Driver Class Initialized
INFO - 2017-03-16 19:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:24:11 --> Controller Class Initialized
INFO - 2017-03-16 19:24:11 --> Helper loaded: date_helper
DEBUG - 2017-03-16 19:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:24:11 --> Helper loaded: url_helper
INFO - 2017-03-16 19:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 19:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 19:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 19:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:24:11 --> Final output sent to browser
DEBUG - 2017-03-16 19:24:11 --> Total execution time: 0.0137
INFO - 2017-03-16 19:24:12 --> Config Class Initialized
INFO - 2017-03-16 19:24:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:24:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:24:12 --> Utf8 Class Initialized
INFO - 2017-03-16 19:24:12 --> URI Class Initialized
INFO - 2017-03-16 19:24:12 --> Router Class Initialized
INFO - 2017-03-16 19:24:12 --> Output Class Initialized
INFO - 2017-03-16 19:24:12 --> Security Class Initialized
DEBUG - 2017-03-16 19:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:24:12 --> Input Class Initialized
INFO - 2017-03-16 19:24:12 --> Language Class Initialized
INFO - 2017-03-16 19:24:12 --> Loader Class Initialized
INFO - 2017-03-16 19:24:12 --> Database Driver Class Initialized
INFO - 2017-03-16 19:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:24:12 --> Controller Class Initialized
INFO - 2017-03-16 19:24:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:24:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:24:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:24:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:24:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:24:12 --> Final output sent to browser
DEBUG - 2017-03-16 19:24:12 --> Total execution time: 0.0134
INFO - 2017-03-16 19:24:13 --> Config Class Initialized
INFO - 2017-03-16 19:24:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:24:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:24:13 --> Utf8 Class Initialized
INFO - 2017-03-16 19:24:13 --> URI Class Initialized
DEBUG - 2017-03-16 19:24:13 --> No URI present. Default controller set.
INFO - 2017-03-16 19:24:13 --> Router Class Initialized
INFO - 2017-03-16 19:24:13 --> Output Class Initialized
INFO - 2017-03-16 19:24:13 --> Security Class Initialized
DEBUG - 2017-03-16 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:24:13 --> Input Class Initialized
INFO - 2017-03-16 19:24:13 --> Language Class Initialized
INFO - 2017-03-16 19:24:13 --> Loader Class Initialized
INFO - 2017-03-16 19:24:13 --> Database Driver Class Initialized
INFO - 2017-03-16 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:24:13 --> Controller Class Initialized
INFO - 2017-03-16 19:24:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:24:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:24:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:24:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:24:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:24:13 --> Final output sent to browser
DEBUG - 2017-03-16 19:24:13 --> Total execution time: 0.0135
INFO - 2017-03-16 19:24:14 --> Config Class Initialized
INFO - 2017-03-16 19:24:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:24:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:24:14 --> Utf8 Class Initialized
INFO - 2017-03-16 19:24:14 --> URI Class Initialized
INFO - 2017-03-16 19:24:14 --> Router Class Initialized
INFO - 2017-03-16 19:24:14 --> Output Class Initialized
INFO - 2017-03-16 19:24:14 --> Security Class Initialized
DEBUG - 2017-03-16 19:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:24:14 --> Input Class Initialized
INFO - 2017-03-16 19:24:14 --> Language Class Initialized
INFO - 2017-03-16 19:24:14 --> Loader Class Initialized
INFO - 2017-03-16 19:24:14 --> Database Driver Class Initialized
INFO - 2017-03-16 19:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:24:14 --> Controller Class Initialized
INFO - 2017-03-16 19:24:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:24:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:24:14 --> Final output sent to browser
DEBUG - 2017-03-16 19:24:14 --> Total execution time: 0.0139
INFO - 2017-03-16 19:39:23 --> Config Class Initialized
INFO - 2017-03-16 19:39:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:39:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:39:23 --> Utf8 Class Initialized
INFO - 2017-03-16 19:39:23 --> URI Class Initialized
INFO - 2017-03-16 19:39:23 --> Router Class Initialized
INFO - 2017-03-16 19:39:23 --> Output Class Initialized
INFO - 2017-03-16 19:39:23 --> Security Class Initialized
DEBUG - 2017-03-16 19:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:39:24 --> Input Class Initialized
INFO - 2017-03-16 19:39:24 --> Language Class Initialized
INFO - 2017-03-16 19:39:24 --> Loader Class Initialized
INFO - 2017-03-16 19:39:24 --> Database Driver Class Initialized
INFO - 2017-03-16 19:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:39:24 --> Controller Class Initialized
INFO - 2017-03-16 19:39:24 --> Helper loaded: date_helper
DEBUG - 2017-03-16 19:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:39:24 --> Helper loaded: url_helper
INFO - 2017-03-16 19:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 19:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 19:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 19:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:39:24 --> Final output sent to browser
DEBUG - 2017-03-16 19:39:24 --> Total execution time: 1.3957
INFO - 2017-03-16 19:47:22 --> Config Class Initialized
INFO - 2017-03-16 19:47:22 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:47:22 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:47:23 --> Utf8 Class Initialized
INFO - 2017-03-16 19:47:23 --> URI Class Initialized
INFO - 2017-03-16 19:47:23 --> Router Class Initialized
INFO - 2017-03-16 19:47:23 --> Output Class Initialized
INFO - 2017-03-16 19:47:23 --> Security Class Initialized
DEBUG - 2017-03-16 19:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:47:23 --> Input Class Initialized
INFO - 2017-03-16 19:47:23 --> Language Class Initialized
INFO - 2017-03-16 19:47:23 --> Loader Class Initialized
INFO - 2017-03-16 19:47:23 --> Database Driver Class Initialized
INFO - 2017-03-16 19:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:47:24 --> Controller Class Initialized
INFO - 2017-03-16 19:47:24 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:47:24 --> Final output sent to browser
DEBUG - 2017-03-16 19:47:24 --> Total execution time: 1.4576
INFO - 2017-03-16 19:50:37 --> Config Class Initialized
INFO - 2017-03-16 19:50:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:50:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:50:37 --> Utf8 Class Initialized
INFO - 2017-03-16 19:50:37 --> URI Class Initialized
DEBUG - 2017-03-16 19:50:37 --> No URI present. Default controller set.
INFO - 2017-03-16 19:50:37 --> Router Class Initialized
INFO - 2017-03-16 19:50:37 --> Output Class Initialized
INFO - 2017-03-16 19:50:37 --> Security Class Initialized
DEBUG - 2017-03-16 19:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:50:37 --> Input Class Initialized
INFO - 2017-03-16 19:50:37 --> Language Class Initialized
INFO - 2017-03-16 19:50:37 --> Loader Class Initialized
INFO - 2017-03-16 19:50:38 --> Database Driver Class Initialized
INFO - 2017-03-16 19:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:50:38 --> Controller Class Initialized
INFO - 2017-03-16 19:50:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:50:38 --> Final output sent to browser
DEBUG - 2017-03-16 19:50:38 --> Total execution time: 1.4509
INFO - 2017-03-16 19:50:49 --> Config Class Initialized
INFO - 2017-03-16 19:50:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:50:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:50:49 --> Utf8 Class Initialized
INFO - 2017-03-16 19:50:49 --> URI Class Initialized
INFO - 2017-03-16 19:50:49 --> Router Class Initialized
INFO - 2017-03-16 19:50:49 --> Output Class Initialized
INFO - 2017-03-16 19:50:49 --> Security Class Initialized
DEBUG - 2017-03-16 19:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:50:49 --> Input Class Initialized
INFO - 2017-03-16 19:50:49 --> Language Class Initialized
INFO - 2017-03-16 19:50:49 --> Loader Class Initialized
INFO - 2017-03-16 19:50:49 --> Database Driver Class Initialized
INFO - 2017-03-16 19:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:50:50 --> Controller Class Initialized
INFO - 2017-03-16 19:50:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:50:50 --> Final output sent to browser
DEBUG - 2017-03-16 19:50:50 --> Total execution time: 1.1923
INFO - 2017-03-16 19:51:38 --> Config Class Initialized
INFO - 2017-03-16 19:51:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:51:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:51:38 --> Utf8 Class Initialized
INFO - 2017-03-16 19:51:38 --> URI Class Initialized
DEBUG - 2017-03-16 19:51:38 --> No URI present. Default controller set.
INFO - 2017-03-16 19:51:38 --> Router Class Initialized
INFO - 2017-03-16 19:51:38 --> Output Class Initialized
INFO - 2017-03-16 19:51:38 --> Security Class Initialized
DEBUG - 2017-03-16 19:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:51:38 --> Input Class Initialized
INFO - 2017-03-16 19:51:38 --> Language Class Initialized
INFO - 2017-03-16 19:51:38 --> Loader Class Initialized
INFO - 2017-03-16 19:51:38 --> Database Driver Class Initialized
INFO - 2017-03-16 19:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:51:38 --> Controller Class Initialized
INFO - 2017-03-16 19:51:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:51:38 --> Final output sent to browser
DEBUG - 2017-03-16 19:51:38 --> Total execution time: 0.0154
INFO - 2017-03-16 19:51:39 --> Config Class Initialized
INFO - 2017-03-16 19:51:39 --> Hooks Class Initialized
DEBUG - 2017-03-16 19:51:39 --> UTF-8 Support Enabled
INFO - 2017-03-16 19:51:39 --> Utf8 Class Initialized
INFO - 2017-03-16 19:51:39 --> URI Class Initialized
INFO - 2017-03-16 19:51:39 --> Router Class Initialized
INFO - 2017-03-16 19:51:39 --> Output Class Initialized
INFO - 2017-03-16 19:51:39 --> Security Class Initialized
DEBUG - 2017-03-16 19:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 19:51:39 --> Input Class Initialized
INFO - 2017-03-16 19:51:39 --> Language Class Initialized
INFO - 2017-03-16 19:51:39 --> Loader Class Initialized
INFO - 2017-03-16 19:51:39 --> Database Driver Class Initialized
INFO - 2017-03-16 19:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 19:51:39 --> Controller Class Initialized
INFO - 2017-03-16 19:51:39 --> Helper loaded: url_helper
DEBUG - 2017-03-16 19:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 19:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 19:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 19:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 19:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 19:51:39 --> Final output sent to browser
DEBUG - 2017-03-16 19:51:39 --> Total execution time: 0.0422
INFO - 2017-03-16 20:41:50 --> Config Class Initialized
INFO - 2017-03-16 20:41:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 20:41:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 20:41:50 --> Utf8 Class Initialized
INFO - 2017-03-16 20:41:50 --> URI Class Initialized
INFO - 2017-03-16 20:41:50 --> Router Class Initialized
INFO - 2017-03-16 20:41:50 --> Output Class Initialized
INFO - 2017-03-16 20:41:50 --> Security Class Initialized
DEBUG - 2017-03-16 20:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 20:41:50 --> Input Class Initialized
INFO - 2017-03-16 20:41:50 --> Language Class Initialized
INFO - 2017-03-16 20:41:50 --> Loader Class Initialized
INFO - 2017-03-16 20:41:50 --> Database Driver Class Initialized
INFO - 2017-03-16 20:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 20:41:50 --> Controller Class Initialized
INFO - 2017-03-16 20:41:51 --> Helper loaded: date_helper
DEBUG - 2017-03-16 20:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 20:41:51 --> Helper loaded: url_helper
INFO - 2017-03-16 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 20:41:51 --> Final output sent to browser
DEBUG - 2017-03-16 20:41:51 --> Total execution time: 1.1224
INFO - 2017-03-16 20:43:03 --> Config Class Initialized
INFO - 2017-03-16 20:43:03 --> Hooks Class Initialized
DEBUG - 2017-03-16 20:43:03 --> UTF-8 Support Enabled
INFO - 2017-03-16 20:43:03 --> Utf8 Class Initialized
INFO - 2017-03-16 20:43:03 --> URI Class Initialized
INFO - 2017-03-16 20:43:03 --> Router Class Initialized
INFO - 2017-03-16 20:43:03 --> Output Class Initialized
INFO - 2017-03-16 20:43:03 --> Security Class Initialized
DEBUG - 2017-03-16 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 20:43:03 --> Input Class Initialized
INFO - 2017-03-16 20:43:03 --> Language Class Initialized
INFO - 2017-03-16 20:43:03 --> Loader Class Initialized
INFO - 2017-03-16 20:43:03 --> Database Driver Class Initialized
INFO - 2017-03-16 20:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 20:43:04 --> Controller Class Initialized
INFO - 2017-03-16 20:43:04 --> Helper loaded: date_helper
DEBUG - 2017-03-16 20:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 20:43:04 --> Helper loaded: url_helper
INFO - 2017-03-16 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 20:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 20:43:04 --> Final output sent to browser
DEBUG - 2017-03-16 20:43:04 --> Total execution time: 1.1346
INFO - 2017-03-16 20:43:11 --> Config Class Initialized
INFO - 2017-03-16 20:43:11 --> Hooks Class Initialized
DEBUG - 2017-03-16 20:43:11 --> UTF-8 Support Enabled
INFO - 2017-03-16 20:43:11 --> Utf8 Class Initialized
INFO - 2017-03-16 20:43:11 --> URI Class Initialized
INFO - 2017-03-16 20:43:11 --> Router Class Initialized
INFO - 2017-03-16 20:43:11 --> Output Class Initialized
INFO - 2017-03-16 20:43:11 --> Security Class Initialized
DEBUG - 2017-03-16 20:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 20:43:11 --> Input Class Initialized
INFO - 2017-03-16 20:43:11 --> Language Class Initialized
INFO - 2017-03-16 20:43:11 --> Loader Class Initialized
INFO - 2017-03-16 20:43:11 --> Database Driver Class Initialized
INFO - 2017-03-16 20:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 20:43:11 --> Controller Class Initialized
INFO - 2017-03-16 20:43:11 --> Helper loaded: url_helper
DEBUG - 2017-03-16 20:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 20:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 20:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 20:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 20:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 20:43:11 --> Final output sent to browser
DEBUG - 2017-03-16 20:43:11 --> Total execution time: 0.5281
INFO - 2017-03-16 20:59:17 --> Config Class Initialized
INFO - 2017-03-16 20:59:17 --> Hooks Class Initialized
DEBUG - 2017-03-16 20:59:17 --> UTF-8 Support Enabled
INFO - 2017-03-16 20:59:17 --> Utf8 Class Initialized
INFO - 2017-03-16 20:59:17 --> URI Class Initialized
INFO - 2017-03-16 20:59:17 --> Router Class Initialized
INFO - 2017-03-16 20:59:17 --> Output Class Initialized
INFO - 2017-03-16 20:59:17 --> Security Class Initialized
DEBUG - 2017-03-16 20:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 20:59:18 --> Input Class Initialized
INFO - 2017-03-16 20:59:18 --> Language Class Initialized
INFO - 2017-03-16 20:59:18 --> Loader Class Initialized
INFO - 2017-03-16 20:59:18 --> Database Driver Class Initialized
INFO - 2017-03-16 20:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 20:59:18 --> Controller Class Initialized
INFO - 2017-03-16 20:59:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 20:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 20:59:18 --> Final output sent to browser
DEBUG - 2017-03-16 20:59:18 --> Total execution time: 1.2012
INFO - 2017-03-16 20:59:38 --> Config Class Initialized
INFO - 2017-03-16 20:59:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 20:59:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 20:59:38 --> Utf8 Class Initialized
INFO - 2017-03-16 20:59:38 --> URI Class Initialized
DEBUG - 2017-03-16 20:59:38 --> No URI present. Default controller set.
INFO - 2017-03-16 20:59:38 --> Router Class Initialized
INFO - 2017-03-16 20:59:38 --> Output Class Initialized
INFO - 2017-03-16 20:59:38 --> Security Class Initialized
DEBUG - 2017-03-16 20:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 20:59:38 --> Input Class Initialized
INFO - 2017-03-16 20:59:38 --> Language Class Initialized
INFO - 2017-03-16 20:59:38 --> Loader Class Initialized
INFO - 2017-03-16 20:59:38 --> Database Driver Class Initialized
INFO - 2017-03-16 20:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 20:59:39 --> Controller Class Initialized
INFO - 2017-03-16 20:59:39 --> Helper loaded: url_helper
DEBUG - 2017-03-16 20:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 20:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 20:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 20:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 20:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 20:59:39 --> Final output sent to browser
DEBUG - 2017-03-16 20:59:39 --> Total execution time: 1.4701
INFO - 2017-03-16 21:46:25 --> Config Class Initialized
INFO - 2017-03-16 21:46:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:46:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:46:25 --> Utf8 Class Initialized
INFO - 2017-03-16 21:46:25 --> URI Class Initialized
INFO - 2017-03-16 21:46:25 --> Router Class Initialized
INFO - 2017-03-16 21:46:25 --> Output Class Initialized
INFO - 2017-03-16 21:46:25 --> Security Class Initialized
DEBUG - 2017-03-16 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:46:25 --> Input Class Initialized
INFO - 2017-03-16 21:46:25 --> Language Class Initialized
INFO - 2017-03-16 21:46:25 --> Loader Class Initialized
INFO - 2017-03-16 21:46:25 --> Database Driver Class Initialized
INFO - 2017-03-16 21:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:46:26 --> Controller Class Initialized
INFO - 2017-03-16 21:46:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:46:26 --> Helper loaded: form_helper
INFO - 2017-03-16 21:46:26 --> Form Validation Class Initialized
INFO - 2017-03-16 21:46:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:46:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-16 21:46:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:46:26 --> Final output sent to browser
DEBUG - 2017-03-16 21:46:26 --> Total execution time: 1.4576
INFO - 2017-03-16 21:46:27 --> Config Class Initialized
INFO - 2017-03-16 21:46:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:46:27 --> Utf8 Class Initialized
INFO - 2017-03-16 21:46:27 --> URI Class Initialized
INFO - 2017-03-16 21:46:27 --> Router Class Initialized
INFO - 2017-03-16 21:46:27 --> Output Class Initialized
INFO - 2017-03-16 21:46:27 --> Security Class Initialized
DEBUG - 2017-03-16 21:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:46:27 --> Input Class Initialized
INFO - 2017-03-16 21:46:27 --> Language Class Initialized
INFO - 2017-03-16 21:46:27 --> Loader Class Initialized
INFO - 2017-03-16 21:46:27 --> Database Driver Class Initialized
INFO - 2017-03-16 21:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:46:27 --> Controller Class Initialized
INFO - 2017-03-16 21:46:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:46:27 --> Final output sent to browser
DEBUG - 2017-03-16 21:46:27 --> Total execution time: 0.2642
INFO - 2017-03-16 21:46:36 --> Config Class Initialized
INFO - 2017-03-16 21:46:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:46:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:46:36 --> Utf8 Class Initialized
INFO - 2017-03-16 21:46:36 --> URI Class Initialized
INFO - 2017-03-16 21:46:36 --> Router Class Initialized
INFO - 2017-03-16 21:46:36 --> Output Class Initialized
INFO - 2017-03-16 21:46:36 --> Security Class Initialized
DEBUG - 2017-03-16 21:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:46:37 --> Input Class Initialized
INFO - 2017-03-16 21:46:37 --> Language Class Initialized
INFO - 2017-03-16 21:46:37 --> Loader Class Initialized
INFO - 2017-03-16 21:46:37 --> Database Driver Class Initialized
INFO - 2017-03-16 21:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:46:37 --> Controller Class Initialized
INFO - 2017-03-16 21:46:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:46:37 --> Helper loaded: form_helper
INFO - 2017-03-16 21:46:37 --> Form Validation Class Initialized
INFO - 2017-03-16 21:46:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-16 21:46:39 --> Config Class Initialized
INFO - 2017-03-16 21:46:39 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:46:39 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:46:39 --> Utf8 Class Initialized
INFO - 2017-03-16 21:46:39 --> URI Class Initialized
INFO - 2017-03-16 21:46:39 --> Router Class Initialized
INFO - 2017-03-16 21:46:39 --> Output Class Initialized
INFO - 2017-03-16 21:46:39 --> Security Class Initialized
DEBUG - 2017-03-16 21:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:46:39 --> Input Class Initialized
INFO - 2017-03-16 21:46:39 --> Language Class Initialized
INFO - 2017-03-16 21:46:39 --> Loader Class Initialized
INFO - 2017-03-16 21:46:40 --> Database Driver Class Initialized
INFO - 2017-03-16 21:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:46:40 --> Controller Class Initialized
INFO - 2017-03-16 21:46:40 --> Helper loaded: date_helper
INFO - 2017-03-16 21:46:40 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:46:40 --> Helper loaded: form_helper
INFO - 2017-03-16 21:46:40 --> Form Validation Class Initialized
INFO - 2017-03-16 21:46:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:46:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-16 21:46:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-16 21:46:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-16 21:46:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:46:40 --> Final output sent to browser
DEBUG - 2017-03-16 21:46:40 --> Total execution time: 1.3785
INFO - 2017-03-16 21:46:41 --> Config Class Initialized
INFO - 2017-03-16 21:46:41 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:46:41 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:46:41 --> Utf8 Class Initialized
INFO - 2017-03-16 21:46:41 --> URI Class Initialized
INFO - 2017-03-16 21:46:41 --> Router Class Initialized
INFO - 2017-03-16 21:46:41 --> Output Class Initialized
INFO - 2017-03-16 21:46:41 --> Security Class Initialized
DEBUG - 2017-03-16 21:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:46:41 --> Input Class Initialized
INFO - 2017-03-16 21:46:41 --> Language Class Initialized
INFO - 2017-03-16 21:46:41 --> Loader Class Initialized
INFO - 2017-03-16 21:46:42 --> Database Driver Class Initialized
INFO - 2017-03-16 21:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:46:42 --> Controller Class Initialized
INFO - 2017-03-16 21:46:42 --> Helper loaded: date_helper
INFO - 2017-03-16 21:46:42 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:46:42 --> Helper loaded: form_helper
INFO - 2017-03-16 21:46:42 --> Form Validation Class Initialized
INFO - 2017-03-16 21:46:42 --> Final output sent to browser
DEBUG - 2017-03-16 21:46:42 --> Total execution time: 1.1293
INFO - 2017-03-16 21:46:42 --> Config Class Initialized
INFO - 2017-03-16 21:46:42 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:46:42 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:46:42 --> Utf8 Class Initialized
INFO - 2017-03-16 21:46:42 --> URI Class Initialized
INFO - 2017-03-16 21:46:42 --> Router Class Initialized
INFO - 2017-03-16 21:46:42 --> Output Class Initialized
INFO - 2017-03-16 21:46:42 --> Security Class Initialized
DEBUG - 2017-03-16 21:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:46:42 --> Input Class Initialized
INFO - 2017-03-16 21:46:42 --> Language Class Initialized
INFO - 2017-03-16 21:46:42 --> Loader Class Initialized
INFO - 2017-03-16 21:46:42 --> Database Driver Class Initialized
INFO - 2017-03-16 21:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:46:42 --> Controller Class Initialized
INFO - 2017-03-16 21:46:42 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:46:42 --> Final output sent to browser
DEBUG - 2017-03-16 21:46:42 --> Total execution time: 0.3259
INFO - 2017-03-16 21:48:08 --> Config Class Initialized
INFO - 2017-03-16 21:48:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:08 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:08 --> URI Class Initialized
INFO - 2017-03-16 21:48:08 --> Router Class Initialized
INFO - 2017-03-16 21:48:08 --> Output Class Initialized
INFO - 2017-03-16 21:48:08 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:08 --> Input Class Initialized
INFO - 2017-03-16 21:48:08 --> Language Class Initialized
INFO - 2017-03-16 21:48:08 --> Loader Class Initialized
INFO - 2017-03-16 21:48:09 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:09 --> Controller Class Initialized
INFO - 2017-03-16 21:48:09 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:09 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:09 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:48:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-16 21:48:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-03-16 21:48:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-03-16 21:48:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:48:09 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:09 --> Total execution time: 1.7556
INFO - 2017-03-16 21:48:10 --> Config Class Initialized
INFO - 2017-03-16 21:48:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:10 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:10 --> URI Class Initialized
INFO - 2017-03-16 21:48:10 --> Router Class Initialized
INFO - 2017-03-16 21:48:10 --> Output Class Initialized
INFO - 2017-03-16 21:48:10 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:10 --> Input Class Initialized
INFO - 2017-03-16 21:48:10 --> Language Class Initialized
INFO - 2017-03-16 21:48:10 --> Loader Class Initialized
INFO - 2017-03-16 21:48:10 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:10 --> Controller Class Initialized
INFO - 2017-03-16 21:48:10 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:10 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:10 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:10 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:10 --> Total execution time: 0.0139
INFO - 2017-03-16 21:48:10 --> Config Class Initialized
INFO - 2017-03-16 21:48:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:10 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:10 --> URI Class Initialized
INFO - 2017-03-16 21:48:10 --> Router Class Initialized
INFO - 2017-03-16 21:48:10 --> Output Class Initialized
INFO - 2017-03-16 21:48:10 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:10 --> Input Class Initialized
INFO - 2017-03-16 21:48:10 --> Language Class Initialized
INFO - 2017-03-16 21:48:10 --> Loader Class Initialized
INFO - 2017-03-16 21:48:10 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:10 --> Controller Class Initialized
INFO - 2017-03-16 21:48:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:48:10 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:10 --> Total execution time: 0.2999
INFO - 2017-03-16 21:48:13 --> Config Class Initialized
INFO - 2017-03-16 21:48:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:13 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:13 --> URI Class Initialized
INFO - 2017-03-16 21:48:13 --> Router Class Initialized
INFO - 2017-03-16 21:48:13 --> Output Class Initialized
INFO - 2017-03-16 21:48:13 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:13 --> Input Class Initialized
INFO - 2017-03-16 21:48:13 --> Language Class Initialized
INFO - 2017-03-16 21:48:13 --> Loader Class Initialized
INFO - 2017-03-16 21:48:13 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:13 --> Controller Class Initialized
INFO - 2017-03-16 21:48:13 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:13 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:13 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:13 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:13 --> Total execution time: 0.0141
INFO - 2017-03-16 21:48:23 --> Config Class Initialized
INFO - 2017-03-16 21:48:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:23 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:23 --> URI Class Initialized
INFO - 2017-03-16 21:48:23 --> Router Class Initialized
INFO - 2017-03-16 21:48:23 --> Output Class Initialized
INFO - 2017-03-16 21:48:23 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:23 --> Input Class Initialized
INFO - 2017-03-16 21:48:23 --> Language Class Initialized
INFO - 2017-03-16 21:48:23 --> Loader Class Initialized
INFO - 2017-03-16 21:48:23 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:23 --> Controller Class Initialized
INFO - 2017-03-16 21:48:23 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:23 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:23 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:23 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:23 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:23 --> Total execution time: 0.0142
INFO - 2017-03-16 21:48:28 --> Config Class Initialized
INFO - 2017-03-16 21:48:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:28 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:28 --> URI Class Initialized
INFO - 2017-03-16 21:48:28 --> Router Class Initialized
INFO - 2017-03-16 21:48:28 --> Output Class Initialized
INFO - 2017-03-16 21:48:28 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:28 --> Input Class Initialized
INFO - 2017-03-16 21:48:28 --> Language Class Initialized
INFO - 2017-03-16 21:48:28 --> Loader Class Initialized
INFO - 2017-03-16 21:48:28 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:28 --> Controller Class Initialized
INFO - 2017-03-16 21:48:28 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:28 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:28 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:28 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:28 --> Total execution time: 0.0183
INFO - 2017-03-16 21:48:28 --> Config Class Initialized
INFO - 2017-03-16 21:48:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:28 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:28 --> URI Class Initialized
INFO - 2017-03-16 21:48:28 --> Router Class Initialized
INFO - 2017-03-16 21:48:28 --> Output Class Initialized
INFO - 2017-03-16 21:48:28 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:28 --> Input Class Initialized
INFO - 2017-03-16 21:48:28 --> Language Class Initialized
INFO - 2017-03-16 21:48:28 --> Loader Class Initialized
INFO - 2017-03-16 21:48:28 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:28 --> Controller Class Initialized
INFO - 2017-03-16 21:48:28 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:28 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:28 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:28 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:28 --> Total execution time: 0.0143
INFO - 2017-03-16 21:48:34 --> Config Class Initialized
INFO - 2017-03-16 21:48:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:34 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:34 --> URI Class Initialized
INFO - 2017-03-16 21:48:34 --> Router Class Initialized
INFO - 2017-03-16 21:48:34 --> Output Class Initialized
INFO - 2017-03-16 21:48:34 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:34 --> Input Class Initialized
INFO - 2017-03-16 21:48:34 --> Language Class Initialized
INFO - 2017-03-16 21:48:34 --> Loader Class Initialized
INFO - 2017-03-16 21:48:34 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:34 --> Controller Class Initialized
INFO - 2017-03-16 21:48:34 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:34 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:34 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:34 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:34 --> Total execution time: 0.0148
INFO - 2017-03-16 21:48:39 --> Config Class Initialized
INFO - 2017-03-16 21:48:39 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:39 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:39 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:39 --> URI Class Initialized
INFO - 2017-03-16 21:48:39 --> Router Class Initialized
INFO - 2017-03-16 21:48:39 --> Output Class Initialized
INFO - 2017-03-16 21:48:39 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:39 --> Input Class Initialized
INFO - 2017-03-16 21:48:39 --> Language Class Initialized
INFO - 2017-03-16 21:48:39 --> Loader Class Initialized
INFO - 2017-03-16 21:48:39 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:39 --> Controller Class Initialized
INFO - 2017-03-16 21:48:39 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:39 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:39 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:39 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:39 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:39 --> Total execution time: 0.0145
INFO - 2017-03-16 21:48:39 --> Config Class Initialized
INFO - 2017-03-16 21:48:39 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:39 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:39 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:39 --> URI Class Initialized
INFO - 2017-03-16 21:48:39 --> Router Class Initialized
INFO - 2017-03-16 21:48:39 --> Output Class Initialized
INFO - 2017-03-16 21:48:39 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:39 --> Input Class Initialized
INFO - 2017-03-16 21:48:39 --> Language Class Initialized
INFO - 2017-03-16 21:48:39 --> Loader Class Initialized
INFO - 2017-03-16 21:48:39 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:39 --> Controller Class Initialized
INFO - 2017-03-16 21:48:39 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:39 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:39 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:39 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:39 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:39 --> Total execution time: 0.0147
INFO - 2017-03-16 21:48:44 --> Config Class Initialized
INFO - 2017-03-16 21:48:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:44 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:44 --> URI Class Initialized
INFO - 2017-03-16 21:48:44 --> Router Class Initialized
INFO - 2017-03-16 21:48:44 --> Output Class Initialized
INFO - 2017-03-16 21:48:44 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:44 --> Input Class Initialized
INFO - 2017-03-16 21:48:44 --> Language Class Initialized
INFO - 2017-03-16 21:48:44 --> Loader Class Initialized
INFO - 2017-03-16 21:48:44 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:44 --> Controller Class Initialized
INFO - 2017-03-16 21:48:44 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:44 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:44 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:44 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:44 --> Total execution time: 0.0144
INFO - 2017-03-16 21:48:46 --> Config Class Initialized
INFO - 2017-03-16 21:48:46 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:46 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:46 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:46 --> URI Class Initialized
INFO - 2017-03-16 21:48:46 --> Router Class Initialized
INFO - 2017-03-16 21:48:46 --> Output Class Initialized
INFO - 2017-03-16 21:48:46 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:46 --> Input Class Initialized
INFO - 2017-03-16 21:48:46 --> Language Class Initialized
INFO - 2017-03-16 21:48:46 --> Loader Class Initialized
INFO - 2017-03-16 21:48:46 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:46 --> Controller Class Initialized
INFO - 2017-03-16 21:48:46 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:46 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:46 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:46 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:46 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:46 --> Total execution time: 0.0149
INFO - 2017-03-16 21:48:50 --> Config Class Initialized
INFO - 2017-03-16 21:48:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:48:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:48:50 --> Utf8 Class Initialized
INFO - 2017-03-16 21:48:50 --> URI Class Initialized
INFO - 2017-03-16 21:48:50 --> Router Class Initialized
INFO - 2017-03-16 21:48:50 --> Output Class Initialized
INFO - 2017-03-16 21:48:50 --> Security Class Initialized
DEBUG - 2017-03-16 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:48:50 --> Input Class Initialized
INFO - 2017-03-16 21:48:50 --> Language Class Initialized
INFO - 2017-03-16 21:48:50 --> Loader Class Initialized
INFO - 2017-03-16 21:48:50 --> Database Driver Class Initialized
INFO - 2017-03-16 21:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:48:50 --> Controller Class Initialized
INFO - 2017-03-16 21:48:50 --> Helper loaded: date_helper
INFO - 2017-03-16 21:48:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:48:50 --> Helper loaded: form_helper
INFO - 2017-03-16 21:48:50 --> Form Validation Class Initialized
INFO - 2017-03-16 21:48:50 --> Final output sent to browser
DEBUG - 2017-03-16 21:48:50 --> Total execution time: 0.0147
INFO - 2017-03-16 21:49:20 --> Config Class Initialized
INFO - 2017-03-16 21:49:20 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:20 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:20 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:20 --> URI Class Initialized
INFO - 2017-03-16 21:49:20 --> Router Class Initialized
INFO - 2017-03-16 21:49:20 --> Output Class Initialized
INFO - 2017-03-16 21:49:20 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:20 --> Input Class Initialized
INFO - 2017-03-16 21:49:20 --> Language Class Initialized
INFO - 2017-03-16 21:49:20 --> Loader Class Initialized
INFO - 2017-03-16 21:49:21 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:21 --> Controller Class Initialized
INFO - 2017-03-16 21:49:21 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:21 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:21 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:21 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:21 --> Total execution time: 1.3940
INFO - 2017-03-16 21:49:25 --> Config Class Initialized
INFO - 2017-03-16 21:49:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:25 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:25 --> URI Class Initialized
INFO - 2017-03-16 21:49:25 --> Router Class Initialized
INFO - 2017-03-16 21:49:25 --> Output Class Initialized
INFO - 2017-03-16 21:49:25 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:25 --> Input Class Initialized
INFO - 2017-03-16 21:49:25 --> Language Class Initialized
INFO - 2017-03-16 21:49:25 --> Loader Class Initialized
INFO - 2017-03-16 21:49:25 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:25 --> Controller Class Initialized
INFO - 2017-03-16 21:49:25 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:25 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:25 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:25 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:25 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:25 --> Total execution time: 0.0142
INFO - 2017-03-16 21:49:26 --> Config Class Initialized
INFO - 2017-03-16 21:49:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:26 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:26 --> URI Class Initialized
INFO - 2017-03-16 21:49:26 --> Router Class Initialized
INFO - 2017-03-16 21:49:26 --> Output Class Initialized
INFO - 2017-03-16 21:49:26 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:26 --> Input Class Initialized
INFO - 2017-03-16 21:49:26 --> Language Class Initialized
INFO - 2017-03-16 21:49:26 --> Loader Class Initialized
INFO - 2017-03-16 21:49:26 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:26 --> Controller Class Initialized
INFO - 2017-03-16 21:49:26 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:26 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:26 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:26 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:26 --> Total execution time: 0.0151
INFO - 2017-03-16 21:49:37 --> Config Class Initialized
INFO - 2017-03-16 21:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:37 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:37 --> URI Class Initialized
INFO - 2017-03-16 21:49:37 --> Router Class Initialized
INFO - 2017-03-16 21:49:37 --> Output Class Initialized
INFO - 2017-03-16 21:49:37 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:37 --> Input Class Initialized
INFO - 2017-03-16 21:49:37 --> Language Class Initialized
INFO - 2017-03-16 21:49:37 --> Loader Class Initialized
INFO - 2017-03-16 21:49:37 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:37 --> Controller Class Initialized
INFO - 2017-03-16 21:49:37 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:37 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:37 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:37 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:37 --> Total execution time: 0.0165
INFO - 2017-03-16 21:49:38 --> Config Class Initialized
INFO - 2017-03-16 21:49:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:38 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:38 --> URI Class Initialized
INFO - 2017-03-16 21:49:38 --> Router Class Initialized
INFO - 2017-03-16 21:49:38 --> Output Class Initialized
INFO - 2017-03-16 21:49:38 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:38 --> Input Class Initialized
INFO - 2017-03-16 21:49:38 --> Language Class Initialized
INFO - 2017-03-16 21:49:38 --> Loader Class Initialized
INFO - 2017-03-16 21:49:38 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:38 --> Controller Class Initialized
INFO - 2017-03-16 21:49:38 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:38 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:38 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:38 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:38 --> Total execution time: 0.0144
INFO - 2017-03-16 21:49:44 --> Config Class Initialized
INFO - 2017-03-16 21:49:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:44 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:44 --> URI Class Initialized
INFO - 2017-03-16 21:49:44 --> Router Class Initialized
INFO - 2017-03-16 21:49:44 --> Output Class Initialized
INFO - 2017-03-16 21:49:44 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:44 --> Input Class Initialized
INFO - 2017-03-16 21:49:44 --> Language Class Initialized
INFO - 2017-03-16 21:49:44 --> Loader Class Initialized
INFO - 2017-03-16 21:49:44 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:44 --> Controller Class Initialized
INFO - 2017-03-16 21:49:44 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:44 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:44 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:44 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:44 --> Total execution time: 0.0141
INFO - 2017-03-16 21:49:51 --> Config Class Initialized
INFO - 2017-03-16 21:49:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:51 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:51 --> URI Class Initialized
INFO - 2017-03-16 21:49:51 --> Router Class Initialized
INFO - 2017-03-16 21:49:51 --> Output Class Initialized
INFO - 2017-03-16 21:49:51 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:51 --> Input Class Initialized
INFO - 2017-03-16 21:49:51 --> Language Class Initialized
INFO - 2017-03-16 21:49:51 --> Loader Class Initialized
INFO - 2017-03-16 21:49:51 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:51 --> Controller Class Initialized
INFO - 2017-03-16 21:49:51 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:51 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:51 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:51 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:51 --> Total execution time: 0.0142
INFO - 2017-03-16 21:49:53 --> Config Class Initialized
INFO - 2017-03-16 21:49:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:53 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:53 --> URI Class Initialized
INFO - 2017-03-16 21:49:53 --> Router Class Initialized
INFO - 2017-03-16 21:49:53 --> Output Class Initialized
INFO - 2017-03-16 21:49:53 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:53 --> Input Class Initialized
INFO - 2017-03-16 21:49:53 --> Language Class Initialized
INFO - 2017-03-16 21:49:53 --> Loader Class Initialized
INFO - 2017-03-16 21:49:53 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:53 --> Controller Class Initialized
INFO - 2017-03-16 21:49:53 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:53 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:53 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:53 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:53 --> Total execution time: 0.0145
INFO - 2017-03-16 21:49:53 --> Config Class Initialized
INFO - 2017-03-16 21:49:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:49:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:49:53 --> Utf8 Class Initialized
INFO - 2017-03-16 21:49:53 --> URI Class Initialized
INFO - 2017-03-16 21:49:53 --> Router Class Initialized
INFO - 2017-03-16 21:49:53 --> Output Class Initialized
INFO - 2017-03-16 21:49:53 --> Security Class Initialized
DEBUG - 2017-03-16 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:49:53 --> Input Class Initialized
INFO - 2017-03-16 21:49:53 --> Language Class Initialized
INFO - 2017-03-16 21:49:53 --> Loader Class Initialized
INFO - 2017-03-16 21:49:53 --> Database Driver Class Initialized
INFO - 2017-03-16 21:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:49:53 --> Controller Class Initialized
INFO - 2017-03-16 21:49:53 --> Helper loaded: date_helper
INFO - 2017-03-16 21:49:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:49:53 --> Helper loaded: form_helper
INFO - 2017-03-16 21:49:53 --> Form Validation Class Initialized
INFO - 2017-03-16 21:49:53 --> Final output sent to browser
DEBUG - 2017-03-16 21:49:53 --> Total execution time: 0.0155
INFO - 2017-03-16 21:50:04 --> Config Class Initialized
INFO - 2017-03-16 21:50:04 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:04 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:04 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:04 --> URI Class Initialized
INFO - 2017-03-16 21:50:04 --> Router Class Initialized
INFO - 2017-03-16 21:50:04 --> Output Class Initialized
INFO - 2017-03-16 21:50:04 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:04 --> Input Class Initialized
INFO - 2017-03-16 21:50:04 --> Language Class Initialized
INFO - 2017-03-16 21:50:04 --> Loader Class Initialized
INFO - 2017-03-16 21:50:04 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:04 --> Controller Class Initialized
INFO - 2017-03-16 21:50:04 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:04 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:04 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:04 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:04 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:04 --> Total execution time: 0.0142
INFO - 2017-03-16 21:50:08 --> Config Class Initialized
INFO - 2017-03-16 21:50:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:08 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:08 --> URI Class Initialized
INFO - 2017-03-16 21:50:08 --> Router Class Initialized
INFO - 2017-03-16 21:50:08 --> Output Class Initialized
INFO - 2017-03-16 21:50:08 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:08 --> Input Class Initialized
INFO - 2017-03-16 21:50:08 --> Language Class Initialized
INFO - 2017-03-16 21:50:08 --> Loader Class Initialized
INFO - 2017-03-16 21:50:08 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:08 --> Controller Class Initialized
INFO - 2017-03-16 21:50:08 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:08 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:08 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:08 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:08 --> Total execution time: 0.0146
INFO - 2017-03-16 21:50:09 --> Config Class Initialized
INFO - 2017-03-16 21:50:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:09 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:09 --> URI Class Initialized
INFO - 2017-03-16 21:50:09 --> Router Class Initialized
INFO - 2017-03-16 21:50:09 --> Output Class Initialized
INFO - 2017-03-16 21:50:09 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:09 --> Input Class Initialized
INFO - 2017-03-16 21:50:09 --> Language Class Initialized
INFO - 2017-03-16 21:50:09 --> Loader Class Initialized
INFO - 2017-03-16 21:50:09 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:09 --> Controller Class Initialized
INFO - 2017-03-16 21:50:09 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:09 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:09 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:09 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:09 --> Total execution time: 0.0146
INFO - 2017-03-16 21:50:09 --> Config Class Initialized
INFO - 2017-03-16 21:50:09 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:09 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:09 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:09 --> URI Class Initialized
INFO - 2017-03-16 21:50:09 --> Router Class Initialized
INFO - 2017-03-16 21:50:09 --> Output Class Initialized
INFO - 2017-03-16 21:50:09 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:09 --> Input Class Initialized
INFO - 2017-03-16 21:50:09 --> Language Class Initialized
INFO - 2017-03-16 21:50:09 --> Loader Class Initialized
INFO - 2017-03-16 21:50:09 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:09 --> Controller Class Initialized
INFO - 2017-03-16 21:50:09 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:09 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:09 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:09 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:09 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:09 --> Total execution time: 0.0643
INFO - 2017-03-16 21:50:10 --> Config Class Initialized
INFO - 2017-03-16 21:50:10 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:10 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:10 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:10 --> URI Class Initialized
INFO - 2017-03-16 21:50:10 --> Router Class Initialized
INFO - 2017-03-16 21:50:10 --> Output Class Initialized
INFO - 2017-03-16 21:50:10 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:10 --> Input Class Initialized
INFO - 2017-03-16 21:50:10 --> Language Class Initialized
INFO - 2017-03-16 21:50:10 --> Loader Class Initialized
INFO - 2017-03-16 21:50:10 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:10 --> Controller Class Initialized
INFO - 2017-03-16 21:50:10 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:10 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:10 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:10 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:10 --> Total execution time: 0.0154
INFO - 2017-03-16 21:50:18 --> Config Class Initialized
INFO - 2017-03-16 21:50:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:18 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:18 --> URI Class Initialized
INFO - 2017-03-16 21:50:18 --> Router Class Initialized
INFO - 2017-03-16 21:50:18 --> Output Class Initialized
INFO - 2017-03-16 21:50:18 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:18 --> Input Class Initialized
INFO - 2017-03-16 21:50:18 --> Language Class Initialized
INFO - 2017-03-16 21:50:18 --> Loader Class Initialized
INFO - 2017-03-16 21:50:18 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:18 --> Controller Class Initialized
INFO - 2017-03-16 21:50:18 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:18 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:18 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:18 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:18 --> Total execution time: 0.0146
INFO - 2017-03-16 21:50:24 --> Config Class Initialized
INFO - 2017-03-16 21:50:24 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:24 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:24 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:24 --> URI Class Initialized
INFO - 2017-03-16 21:50:24 --> Router Class Initialized
INFO - 2017-03-16 21:50:24 --> Output Class Initialized
INFO - 2017-03-16 21:50:24 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:24 --> Input Class Initialized
INFO - 2017-03-16 21:50:24 --> Language Class Initialized
INFO - 2017-03-16 21:50:24 --> Loader Class Initialized
INFO - 2017-03-16 21:50:24 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:24 --> Controller Class Initialized
INFO - 2017-03-16 21:50:24 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:24 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:24 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:24 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:24 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:24 --> Total execution time: 0.0147
INFO - 2017-03-16 21:50:33 --> Config Class Initialized
INFO - 2017-03-16 21:50:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:33 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:33 --> URI Class Initialized
INFO - 2017-03-16 21:50:33 --> Router Class Initialized
INFO - 2017-03-16 21:50:33 --> Output Class Initialized
INFO - 2017-03-16 21:50:33 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:33 --> Input Class Initialized
INFO - 2017-03-16 21:50:33 --> Language Class Initialized
INFO - 2017-03-16 21:50:33 --> Loader Class Initialized
INFO - 2017-03-16 21:50:33 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:33 --> Controller Class Initialized
INFO - 2017-03-16 21:50:33 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:33 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:33 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:33 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:33 --> Total execution time: 0.0147
INFO - 2017-03-16 21:50:36 --> Config Class Initialized
INFO - 2017-03-16 21:50:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:36 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:36 --> URI Class Initialized
INFO - 2017-03-16 21:50:36 --> Router Class Initialized
INFO - 2017-03-16 21:50:36 --> Output Class Initialized
INFO - 2017-03-16 21:50:36 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:36 --> Input Class Initialized
INFO - 2017-03-16 21:50:36 --> Language Class Initialized
INFO - 2017-03-16 21:50:36 --> Loader Class Initialized
INFO - 2017-03-16 21:50:36 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:36 --> Controller Class Initialized
INFO - 2017-03-16 21:50:36 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:36 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:36 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:36 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:36 --> Total execution time: 0.0155
INFO - 2017-03-16 21:50:38 --> Config Class Initialized
INFO - 2017-03-16 21:50:38 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:38 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:38 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:38 --> URI Class Initialized
INFO - 2017-03-16 21:50:38 --> Router Class Initialized
INFO - 2017-03-16 21:50:38 --> Output Class Initialized
INFO - 2017-03-16 21:50:38 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:38 --> Input Class Initialized
INFO - 2017-03-16 21:50:38 --> Language Class Initialized
INFO - 2017-03-16 21:50:38 --> Loader Class Initialized
INFO - 2017-03-16 21:50:38 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:38 --> Controller Class Initialized
INFO - 2017-03-16 21:50:38 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:38 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:38 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:38 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:38 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:38 --> Total execution time: 0.0138
INFO - 2017-03-16 21:50:45 --> Config Class Initialized
INFO - 2017-03-16 21:50:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:45 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:45 --> URI Class Initialized
INFO - 2017-03-16 21:50:45 --> Router Class Initialized
INFO - 2017-03-16 21:50:45 --> Output Class Initialized
INFO - 2017-03-16 21:50:45 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:45 --> Input Class Initialized
INFO - 2017-03-16 21:50:45 --> Language Class Initialized
INFO - 2017-03-16 21:50:45 --> Loader Class Initialized
INFO - 2017-03-16 21:50:45 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:45 --> Controller Class Initialized
INFO - 2017-03-16 21:50:45 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:45 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:45 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:45 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:45 --> Total execution time: 0.0145
INFO - 2017-03-16 21:50:45 --> Config Class Initialized
INFO - 2017-03-16 21:50:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:45 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:45 --> URI Class Initialized
INFO - 2017-03-16 21:50:45 --> Router Class Initialized
INFO - 2017-03-16 21:50:45 --> Output Class Initialized
INFO - 2017-03-16 21:50:45 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:45 --> Input Class Initialized
INFO - 2017-03-16 21:50:45 --> Language Class Initialized
INFO - 2017-03-16 21:50:45 --> Loader Class Initialized
INFO - 2017-03-16 21:50:45 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:45 --> Controller Class Initialized
INFO - 2017-03-16 21:50:45 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:45 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:45 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:45 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:45 --> Total execution time: 0.0147
INFO - 2017-03-16 21:50:45 --> Config Class Initialized
INFO - 2017-03-16 21:50:45 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:45 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:45 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:45 --> URI Class Initialized
INFO - 2017-03-16 21:50:45 --> Router Class Initialized
INFO - 2017-03-16 21:50:45 --> Output Class Initialized
INFO - 2017-03-16 21:50:45 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:45 --> Input Class Initialized
INFO - 2017-03-16 21:50:45 --> Language Class Initialized
INFO - 2017-03-16 21:50:45 --> Loader Class Initialized
INFO - 2017-03-16 21:50:45 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:45 --> Controller Class Initialized
INFO - 2017-03-16 21:50:45 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:45 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:45 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:45 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:45 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:45 --> Total execution time: 0.0141
INFO - 2017-03-16 21:50:48 --> Config Class Initialized
INFO - 2017-03-16 21:50:48 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:48 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:48 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:48 --> URI Class Initialized
INFO - 2017-03-16 21:50:48 --> Router Class Initialized
INFO - 2017-03-16 21:50:48 --> Output Class Initialized
INFO - 2017-03-16 21:50:48 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:48 --> Input Class Initialized
INFO - 2017-03-16 21:50:48 --> Language Class Initialized
INFO - 2017-03-16 21:50:48 --> Loader Class Initialized
INFO - 2017-03-16 21:50:48 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:48 --> Controller Class Initialized
INFO - 2017-03-16 21:50:48 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:48 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:48 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:48 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:48 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:48 --> Total execution time: 0.0141
INFO - 2017-03-16 21:50:58 --> Config Class Initialized
INFO - 2017-03-16 21:50:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:50:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:50:58 --> Utf8 Class Initialized
INFO - 2017-03-16 21:50:58 --> URI Class Initialized
INFO - 2017-03-16 21:50:58 --> Router Class Initialized
INFO - 2017-03-16 21:50:58 --> Output Class Initialized
INFO - 2017-03-16 21:50:58 --> Security Class Initialized
DEBUG - 2017-03-16 21:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:50:58 --> Input Class Initialized
INFO - 2017-03-16 21:50:58 --> Language Class Initialized
INFO - 2017-03-16 21:50:58 --> Loader Class Initialized
INFO - 2017-03-16 21:50:58 --> Database Driver Class Initialized
INFO - 2017-03-16 21:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:50:58 --> Controller Class Initialized
INFO - 2017-03-16 21:50:58 --> Helper loaded: date_helper
INFO - 2017-03-16 21:50:58 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:50:58 --> Helper loaded: form_helper
INFO - 2017-03-16 21:50:58 --> Form Validation Class Initialized
INFO - 2017-03-16 21:50:59 --> Final output sent to browser
DEBUG - 2017-03-16 21:50:59 --> Total execution time: 0.0142
INFO - 2017-03-16 21:51:05 --> Config Class Initialized
INFO - 2017-03-16 21:51:05 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:05 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:05 --> URI Class Initialized
INFO - 2017-03-16 21:51:05 --> Router Class Initialized
INFO - 2017-03-16 21:51:05 --> Output Class Initialized
INFO - 2017-03-16 21:51:05 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:05 --> Input Class Initialized
INFO - 2017-03-16 21:51:05 --> Language Class Initialized
INFO - 2017-03-16 21:51:05 --> Loader Class Initialized
INFO - 2017-03-16 21:51:05 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:05 --> Controller Class Initialized
INFO - 2017-03-16 21:51:05 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:05 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:05 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:05 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:05 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:05 --> Total execution time: 0.0246
INFO - 2017-03-16 21:51:07 --> Config Class Initialized
INFO - 2017-03-16 21:51:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:07 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:07 --> URI Class Initialized
INFO - 2017-03-16 21:51:07 --> Router Class Initialized
INFO - 2017-03-16 21:51:07 --> Output Class Initialized
INFO - 2017-03-16 21:51:07 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:07 --> Input Class Initialized
INFO - 2017-03-16 21:51:07 --> Language Class Initialized
INFO - 2017-03-16 21:51:07 --> Loader Class Initialized
INFO - 2017-03-16 21:51:07 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:07 --> Controller Class Initialized
INFO - 2017-03-16 21:51:07 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:07 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:07 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:07 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:07 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:07 --> Total execution time: 0.0144
INFO - 2017-03-16 21:51:08 --> Config Class Initialized
INFO - 2017-03-16 21:51:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:08 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:08 --> URI Class Initialized
INFO - 2017-03-16 21:51:08 --> Router Class Initialized
INFO - 2017-03-16 21:51:08 --> Output Class Initialized
INFO - 2017-03-16 21:51:08 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:08 --> Input Class Initialized
INFO - 2017-03-16 21:51:08 --> Language Class Initialized
INFO - 2017-03-16 21:51:08 --> Loader Class Initialized
INFO - 2017-03-16 21:51:08 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:08 --> Controller Class Initialized
INFO - 2017-03-16 21:51:08 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:08 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:08 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:08 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:08 --> Total execution time: 0.0486
INFO - 2017-03-16 21:51:15 --> Config Class Initialized
INFO - 2017-03-16 21:51:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:15 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:15 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:15 --> URI Class Initialized
INFO - 2017-03-16 21:51:15 --> Router Class Initialized
INFO - 2017-03-16 21:51:15 --> Output Class Initialized
INFO - 2017-03-16 21:51:15 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:15 --> Input Class Initialized
INFO - 2017-03-16 21:51:15 --> Language Class Initialized
INFO - 2017-03-16 21:51:15 --> Loader Class Initialized
INFO - 2017-03-16 21:51:15 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:15 --> Controller Class Initialized
INFO - 2017-03-16 21:51:15 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:15 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:15 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:15 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:15 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:15 --> Total execution time: 0.0140
INFO - 2017-03-16 21:51:18 --> Config Class Initialized
INFO - 2017-03-16 21:51:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:18 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:18 --> URI Class Initialized
INFO - 2017-03-16 21:51:18 --> Router Class Initialized
INFO - 2017-03-16 21:51:18 --> Output Class Initialized
INFO - 2017-03-16 21:51:18 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:18 --> Input Class Initialized
INFO - 2017-03-16 21:51:18 --> Language Class Initialized
INFO - 2017-03-16 21:51:18 --> Loader Class Initialized
INFO - 2017-03-16 21:51:18 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:18 --> Controller Class Initialized
INFO - 2017-03-16 21:51:18 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:18 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:18 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:18 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:18 --> Total execution time: 0.0145
INFO - 2017-03-16 21:51:19 --> Config Class Initialized
INFO - 2017-03-16 21:51:19 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:19 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:19 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:19 --> URI Class Initialized
INFO - 2017-03-16 21:51:19 --> Router Class Initialized
INFO - 2017-03-16 21:51:19 --> Output Class Initialized
INFO - 2017-03-16 21:51:19 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:19 --> Input Class Initialized
INFO - 2017-03-16 21:51:19 --> Language Class Initialized
INFO - 2017-03-16 21:51:19 --> Loader Class Initialized
INFO - 2017-03-16 21:51:19 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:19 --> Controller Class Initialized
INFO - 2017-03-16 21:51:19 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:19 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:19 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:19 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:19 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:19 --> Total execution time: 0.0142
INFO - 2017-03-16 21:51:27 --> Config Class Initialized
INFO - 2017-03-16 21:51:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:27 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:27 --> URI Class Initialized
INFO - 2017-03-16 21:51:27 --> Router Class Initialized
INFO - 2017-03-16 21:51:27 --> Output Class Initialized
INFO - 2017-03-16 21:51:27 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:27 --> Input Class Initialized
INFO - 2017-03-16 21:51:27 --> Language Class Initialized
INFO - 2017-03-16 21:51:27 --> Loader Class Initialized
INFO - 2017-03-16 21:51:27 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:27 --> Controller Class Initialized
INFO - 2017-03-16 21:51:27 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:27 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:27 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:27 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:27 --> Total execution time: 0.0145
INFO - 2017-03-16 21:51:27 --> Config Class Initialized
INFO - 2017-03-16 21:51:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:27 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:27 --> URI Class Initialized
INFO - 2017-03-16 21:51:27 --> Router Class Initialized
INFO - 2017-03-16 21:51:27 --> Output Class Initialized
INFO - 2017-03-16 21:51:27 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:27 --> Input Class Initialized
INFO - 2017-03-16 21:51:27 --> Language Class Initialized
INFO - 2017-03-16 21:51:27 --> Loader Class Initialized
INFO - 2017-03-16 21:51:27 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:27 --> Controller Class Initialized
INFO - 2017-03-16 21:51:27 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:27 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:27 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:27 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:27 --> Total execution time: 0.0153
INFO - 2017-03-16 21:51:31 --> Config Class Initialized
INFO - 2017-03-16 21:51:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:31 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:31 --> URI Class Initialized
INFO - 2017-03-16 21:51:31 --> Router Class Initialized
INFO - 2017-03-16 21:51:31 --> Output Class Initialized
INFO - 2017-03-16 21:51:31 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:31 --> Input Class Initialized
INFO - 2017-03-16 21:51:31 --> Language Class Initialized
INFO - 2017-03-16 21:51:31 --> Loader Class Initialized
INFO - 2017-03-16 21:51:31 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:31 --> Controller Class Initialized
INFO - 2017-03-16 21:51:31 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:31 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:31 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:31 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:31 --> Total execution time: 0.0152
INFO - 2017-03-16 21:51:34 --> Config Class Initialized
INFO - 2017-03-16 21:51:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:34 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:34 --> URI Class Initialized
INFO - 2017-03-16 21:51:34 --> Router Class Initialized
INFO - 2017-03-16 21:51:34 --> Output Class Initialized
INFO - 2017-03-16 21:51:34 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:34 --> Input Class Initialized
INFO - 2017-03-16 21:51:34 --> Language Class Initialized
INFO - 2017-03-16 21:51:34 --> Loader Class Initialized
INFO - 2017-03-16 21:51:34 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:34 --> Controller Class Initialized
INFO - 2017-03-16 21:51:34 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:34 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:34 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:34 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:34 --> Total execution time: 0.0177
INFO - 2017-03-16 21:51:34 --> Config Class Initialized
INFO - 2017-03-16 21:51:34 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:34 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:34 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:34 --> URI Class Initialized
INFO - 2017-03-16 21:51:34 --> Router Class Initialized
INFO - 2017-03-16 21:51:34 --> Output Class Initialized
INFO - 2017-03-16 21:51:34 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:34 --> Input Class Initialized
INFO - 2017-03-16 21:51:34 --> Language Class Initialized
INFO - 2017-03-16 21:51:34 --> Loader Class Initialized
INFO - 2017-03-16 21:51:34 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:34 --> Controller Class Initialized
INFO - 2017-03-16 21:51:34 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:34 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:34 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:34 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:34 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:34 --> Total execution time: 0.0145
INFO - 2017-03-16 21:51:35 --> Config Class Initialized
INFO - 2017-03-16 21:51:35 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:35 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:35 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:35 --> URI Class Initialized
INFO - 2017-03-16 21:51:35 --> Router Class Initialized
INFO - 2017-03-16 21:51:35 --> Output Class Initialized
INFO - 2017-03-16 21:51:35 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:35 --> Input Class Initialized
INFO - 2017-03-16 21:51:35 --> Language Class Initialized
INFO - 2017-03-16 21:51:35 --> Loader Class Initialized
INFO - 2017-03-16 21:51:35 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:35 --> Controller Class Initialized
INFO - 2017-03-16 21:51:35 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:35 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:35 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:35 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:35 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:35 --> Total execution time: 0.0151
INFO - 2017-03-16 21:51:37 --> Config Class Initialized
INFO - 2017-03-16 21:51:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:37 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:37 --> URI Class Initialized
INFO - 2017-03-16 21:51:37 --> Router Class Initialized
INFO - 2017-03-16 21:51:37 --> Output Class Initialized
INFO - 2017-03-16 21:51:37 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:37 --> Input Class Initialized
INFO - 2017-03-16 21:51:37 --> Language Class Initialized
INFO - 2017-03-16 21:51:37 --> Loader Class Initialized
INFO - 2017-03-16 21:51:37 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:37 --> Controller Class Initialized
INFO - 2017-03-16 21:51:37 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:37 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:37 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:37 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:37 --> Total execution time: 0.0140
INFO - 2017-03-16 21:51:46 --> Config Class Initialized
INFO - 2017-03-16 21:51:46 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:46 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:46 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:46 --> URI Class Initialized
INFO - 2017-03-16 21:51:46 --> Router Class Initialized
INFO - 2017-03-16 21:51:46 --> Output Class Initialized
INFO - 2017-03-16 21:51:46 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:46 --> Input Class Initialized
INFO - 2017-03-16 21:51:46 --> Language Class Initialized
INFO - 2017-03-16 21:51:46 --> Loader Class Initialized
INFO - 2017-03-16 21:51:46 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:46 --> Controller Class Initialized
INFO - 2017-03-16 21:51:46 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:46 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:46 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:46 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:46 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:46 --> Total execution time: 0.0147
INFO - 2017-03-16 21:51:50 --> Config Class Initialized
INFO - 2017-03-16 21:51:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:50 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:50 --> URI Class Initialized
INFO - 2017-03-16 21:51:50 --> Router Class Initialized
INFO - 2017-03-16 21:51:50 --> Output Class Initialized
INFO - 2017-03-16 21:51:50 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:50 --> Input Class Initialized
INFO - 2017-03-16 21:51:50 --> Language Class Initialized
INFO - 2017-03-16 21:51:50 --> Loader Class Initialized
INFO - 2017-03-16 21:51:50 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:50 --> Controller Class Initialized
INFO - 2017-03-16 21:51:50 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:50 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:50 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:50 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:50 --> Total execution time: 0.0144
INFO - 2017-03-16 21:51:55 --> Config Class Initialized
INFO - 2017-03-16 21:51:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:55 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:55 --> URI Class Initialized
INFO - 2017-03-16 21:51:55 --> Router Class Initialized
INFO - 2017-03-16 21:51:55 --> Output Class Initialized
INFO - 2017-03-16 21:51:55 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:55 --> Input Class Initialized
INFO - 2017-03-16 21:51:55 --> Language Class Initialized
INFO - 2017-03-16 21:51:55 --> Loader Class Initialized
INFO - 2017-03-16 21:51:55 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:55 --> Controller Class Initialized
INFO - 2017-03-16 21:51:55 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:55 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:55 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:55 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:55 --> Total execution time: 0.0142
INFO - 2017-03-16 21:51:58 --> Config Class Initialized
INFO - 2017-03-16 21:51:58 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:51:58 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:51:58 --> Utf8 Class Initialized
INFO - 2017-03-16 21:51:58 --> URI Class Initialized
INFO - 2017-03-16 21:51:58 --> Router Class Initialized
INFO - 2017-03-16 21:51:58 --> Output Class Initialized
INFO - 2017-03-16 21:51:59 --> Security Class Initialized
DEBUG - 2017-03-16 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:51:59 --> Input Class Initialized
INFO - 2017-03-16 21:51:59 --> Language Class Initialized
INFO - 2017-03-16 21:51:59 --> Loader Class Initialized
INFO - 2017-03-16 21:51:59 --> Database Driver Class Initialized
INFO - 2017-03-16 21:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:51:59 --> Controller Class Initialized
INFO - 2017-03-16 21:51:59 --> Helper loaded: date_helper
INFO - 2017-03-16 21:51:59 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:51:59 --> Helper loaded: form_helper
INFO - 2017-03-16 21:51:59 --> Form Validation Class Initialized
INFO - 2017-03-16 21:51:59 --> Final output sent to browser
DEBUG - 2017-03-16 21:51:59 --> Total execution time: 0.0408
INFO - 2017-03-16 21:52:06 --> Config Class Initialized
INFO - 2017-03-16 21:52:06 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:52:06 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:52:06 --> Utf8 Class Initialized
INFO - 2017-03-16 21:52:06 --> URI Class Initialized
INFO - 2017-03-16 21:52:06 --> Router Class Initialized
INFO - 2017-03-16 21:52:06 --> Output Class Initialized
INFO - 2017-03-16 21:52:06 --> Security Class Initialized
DEBUG - 2017-03-16 21:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:52:06 --> Input Class Initialized
INFO - 2017-03-16 21:52:06 --> Language Class Initialized
INFO - 2017-03-16 21:52:06 --> Loader Class Initialized
INFO - 2017-03-16 21:52:06 --> Database Driver Class Initialized
INFO - 2017-03-16 21:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:52:06 --> Controller Class Initialized
INFO - 2017-03-16 21:52:06 --> Helper loaded: date_helper
INFO - 2017-03-16 21:52:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:52:06 --> Helper loaded: form_helper
INFO - 2017-03-16 21:52:06 --> Form Validation Class Initialized
INFO - 2017-03-16 21:52:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:52:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-16 21:52:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-16 21:52:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-16 21:52:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:52:06 --> Final output sent to browser
DEBUG - 2017-03-16 21:52:06 --> Total execution time: 0.1187
INFO - 2017-03-16 21:52:06 --> Config Class Initialized
INFO - 2017-03-16 21:52:06 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:52:06 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:52:06 --> Utf8 Class Initialized
INFO - 2017-03-16 21:52:06 --> URI Class Initialized
INFO - 2017-03-16 21:52:06 --> Router Class Initialized
INFO - 2017-03-16 21:52:06 --> Output Class Initialized
INFO - 2017-03-16 21:52:06 --> Security Class Initialized
DEBUG - 2017-03-16 21:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:52:06 --> Input Class Initialized
INFO - 2017-03-16 21:52:06 --> Language Class Initialized
INFO - 2017-03-16 21:52:06 --> Loader Class Initialized
INFO - 2017-03-16 21:52:06 --> Database Driver Class Initialized
INFO - 2017-03-16 21:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:52:06 --> Controller Class Initialized
INFO - 2017-03-16 21:52:06 --> Helper loaded: date_helper
INFO - 2017-03-16 21:52:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:52:06 --> Helper loaded: form_helper
INFO - 2017-03-16 21:52:06 --> Form Validation Class Initialized
INFO - 2017-03-16 21:52:06 --> Final output sent to browser
DEBUG - 2017-03-16 21:52:06 --> Total execution time: 0.0150
INFO - 2017-03-16 21:52:06 --> Config Class Initialized
INFO - 2017-03-16 21:52:06 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:52:06 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:52:06 --> Utf8 Class Initialized
INFO - 2017-03-16 21:52:06 --> URI Class Initialized
INFO - 2017-03-16 21:52:06 --> Router Class Initialized
INFO - 2017-03-16 21:52:06 --> Output Class Initialized
INFO - 2017-03-16 21:52:06 --> Security Class Initialized
DEBUG - 2017-03-16 21:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:52:06 --> Input Class Initialized
INFO - 2017-03-16 21:52:06 --> Language Class Initialized
INFO - 2017-03-16 21:52:06 --> Loader Class Initialized
INFO - 2017-03-16 21:52:06 --> Database Driver Class Initialized
INFO - 2017-03-16 21:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:52:06 --> Controller Class Initialized
INFO - 2017-03-16 21:52:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:52:07 --> Final output sent to browser
DEBUG - 2017-03-16 21:52:07 --> Total execution time: 0.2828
INFO - 2017-03-16 21:53:13 --> Config Class Initialized
INFO - 2017-03-16 21:53:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:53:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:53:13 --> Utf8 Class Initialized
INFO - 2017-03-16 21:53:13 --> URI Class Initialized
INFO - 2017-03-16 21:53:13 --> Router Class Initialized
INFO - 2017-03-16 21:53:13 --> Output Class Initialized
INFO - 2017-03-16 21:53:13 --> Security Class Initialized
DEBUG - 2017-03-16 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:53:13 --> Input Class Initialized
INFO - 2017-03-16 21:53:13 --> Language Class Initialized
INFO - 2017-03-16 21:53:13 --> Loader Class Initialized
INFO - 2017-03-16 21:53:14 --> Database Driver Class Initialized
INFO - 2017-03-16 21:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:53:14 --> Controller Class Initialized
INFO - 2017-03-16 21:53:14 --> Helper loaded: date_helper
INFO - 2017-03-16 21:53:14 --> Config Class Initialized
INFO - 2017-03-16 21:53:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:53:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:53:14 --> Utf8 Class Initialized
INFO - 2017-03-16 21:53:14 --> URI Class Initialized
INFO - 2017-03-16 21:53:14 --> Router Class Initialized
INFO - 2017-03-16 21:53:14 --> Output Class Initialized
INFO - 2017-03-16 21:53:14 --> Security Class Initialized
DEBUG - 2017-03-16 21:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:53:14 --> Input Class Initialized
INFO - 2017-03-16 21:53:14 --> Language Class Initialized
INFO - 2017-03-16 21:53:14 --> Loader Class Initialized
INFO - 2017-03-16 21:53:14 --> Database Driver Class Initialized
INFO - 2017-03-16 21:53:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:53:14 --> Helper loaded: form_helper
INFO - 2017-03-16 21:53:14 --> Form Validation Class Initialized
INFO - 2017-03-16 21:53:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:53:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:53:15 --> Final output sent to browser
DEBUG - 2017-03-16 21:53:15 --> Total execution time: 2.0686
INFO - 2017-03-16 21:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:53:15 --> Controller Class Initialized
INFO - 2017-03-16 21:53:15 --> Upload Class Initialized
INFO - 2017-03-16 21:53:15 --> Helper loaded: date_helper
INFO - 2017-03-16 21:53:15 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:53:15 --> Helper loaded: form_helper
INFO - 2017-03-16 21:53:15 --> Form Validation Class Initialized
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:53:15 --> Final output sent to browser
DEBUG - 2017-03-16 21:53:15 --> Total execution time: 1.2722
INFO - 2017-03-16 21:53:15 --> Config Class Initialized
INFO - 2017-03-16 21:53:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:53:15 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:53:15 --> Utf8 Class Initialized
INFO - 2017-03-16 21:53:15 --> URI Class Initialized
INFO - 2017-03-16 21:53:15 --> Router Class Initialized
INFO - 2017-03-16 21:53:15 --> Output Class Initialized
INFO - 2017-03-16 21:53:15 --> Security Class Initialized
DEBUG - 2017-03-16 21:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:53:15 --> Input Class Initialized
INFO - 2017-03-16 21:53:15 --> Language Class Initialized
INFO - 2017-03-16 21:53:15 --> Loader Class Initialized
INFO - 2017-03-16 21:53:15 --> Database Driver Class Initialized
INFO - 2017-03-16 21:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:53:15 --> Controller Class Initialized
INFO - 2017-03-16 21:53:15 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:53:16 --> Final output sent to browser
DEBUG - 2017-03-16 21:53:16 --> Total execution time: 0.2510
INFO - 2017-03-16 21:53:19 --> Config Class Initialized
INFO - 2017-03-16 21:53:19 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:53:19 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:53:19 --> Utf8 Class Initialized
INFO - 2017-03-16 21:53:19 --> URI Class Initialized
INFO - 2017-03-16 21:53:19 --> Router Class Initialized
INFO - 2017-03-16 21:53:19 --> Output Class Initialized
INFO - 2017-03-16 21:53:19 --> Security Class Initialized
DEBUG - 2017-03-16 21:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:53:19 --> Input Class Initialized
INFO - 2017-03-16 21:53:19 --> Language Class Initialized
INFO - 2017-03-16 21:53:19 --> Loader Class Initialized
INFO - 2017-03-16 21:53:19 --> Database Driver Class Initialized
INFO - 2017-03-16 21:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:53:19 --> Controller Class Initialized
INFO - 2017-03-16 21:53:19 --> Upload Class Initialized
INFO - 2017-03-16 21:53:19 --> Helper loaded: date_helper
INFO - 2017-03-16 21:53:19 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:53:19 --> Helper loaded: form_helper
INFO - 2017-03-16 21:53:19 --> Form Validation Class Initialized
INFO - 2017-03-16 21:53:19 --> Final output sent to browser
DEBUG - 2017-03-16 21:53:19 --> Total execution time: 0.0151
INFO - 2017-03-16 21:53:26 --> Config Class Initialized
INFO - 2017-03-16 21:53:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:53:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:53:26 --> Utf8 Class Initialized
INFO - 2017-03-16 21:53:26 --> URI Class Initialized
INFO - 2017-03-16 21:53:26 --> Router Class Initialized
INFO - 2017-03-16 21:53:26 --> Output Class Initialized
INFO - 2017-03-16 21:53:26 --> Security Class Initialized
DEBUG - 2017-03-16 21:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:53:26 --> Input Class Initialized
INFO - 2017-03-16 21:53:26 --> Language Class Initialized
INFO - 2017-03-16 21:53:26 --> Loader Class Initialized
INFO - 2017-03-16 21:53:27 --> Database Driver Class Initialized
INFO - 2017-03-16 21:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:53:27 --> Controller Class Initialized
INFO - 2017-03-16 21:53:27 --> Upload Class Initialized
INFO - 2017-03-16 21:53:27 --> Helper loaded: date_helper
INFO - 2017-03-16 21:53:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:53:27 --> Helper loaded: form_helper
INFO - 2017-03-16 21:53:27 --> Form Validation Class Initialized
INFO - 2017-03-16 21:53:27 --> Final output sent to browser
DEBUG - 2017-03-16 21:53:27 --> Total execution time: 0.0150
INFO - 2017-03-16 21:55:01 --> Config Class Initialized
INFO - 2017-03-16 21:55:01 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:01 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:01 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:01 --> URI Class Initialized
INFO - 2017-03-16 21:55:01 --> Router Class Initialized
INFO - 2017-03-16 21:55:01 --> Output Class Initialized
INFO - 2017-03-16 21:55:01 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:01 --> Input Class Initialized
INFO - 2017-03-16 21:55:01 --> Language Class Initialized
INFO - 2017-03-16 21:55:01 --> Loader Class Initialized
INFO - 2017-03-16 21:55:01 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:01 --> Controller Class Initialized
INFO - 2017-03-16 21:55:01 --> Upload Class Initialized
INFO - 2017-03-16 21:55:01 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:07 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:07 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:07 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:07 --> Config Class Initialized
INFO - 2017-03-16 21:55:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:07 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:07 --> URI Class Initialized
INFO - 2017-03-16 21:55:07 --> Router Class Initialized
INFO - 2017-03-16 21:55:07 --> Output Class Initialized
INFO - 2017-03-16 21:55:07 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:07 --> Input Class Initialized
INFO - 2017-03-16 21:55:07 --> Language Class Initialized
INFO - 2017-03-16 21:55:07 --> Loader Class Initialized
INFO - 2017-03-16 21:55:07 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:07 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-03-16 21:55:07 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2017-03-16 21:55:07 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:07 --> Total execution time: 6.4054
INFO - 2017-03-16 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:07 --> Controller Class Initialized
INFO - 2017-03-16 21:55:07 --> Upload Class Initialized
INFO - 2017-03-16 21:55:07 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:07 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:07 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:07 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:07 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-03-16 21:55:07 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2017-03-16 21:55:07 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:07 --> Total execution time: 0.1907
INFO - 2017-03-16 21:55:07 --> Config Class Initialized
INFO - 2017-03-16 21:55:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:07 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:07 --> URI Class Initialized
INFO - 2017-03-16 21:55:07 --> Router Class Initialized
INFO - 2017-03-16 21:55:07 --> Output Class Initialized
INFO - 2017-03-16 21:55:07 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:07 --> Input Class Initialized
INFO - 2017-03-16 21:55:07 --> Language Class Initialized
INFO - 2017-03-16 21:55:07 --> Config Class Initialized
INFO - 2017-03-16 21:55:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:07 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:07 --> Loader Class Initialized
INFO - 2017-03-16 21:55:07 --> URI Class Initialized
INFO - 2017-03-16 21:55:07 --> Router Class Initialized
INFO - 2017-03-16 21:55:07 --> Output Class Initialized
INFO - 2017-03-16 21:55:07 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:07 --> Input Class Initialized
INFO - 2017-03-16 21:55:07 --> Language Class Initialized
INFO - 2017-03-16 21:55:07 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:07 --> Loader Class Initialized
INFO - 2017-03-16 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:07 --> Controller Class Initialized
INFO - 2017-03-16 21:55:07 --> Upload Class Initialized
INFO - 2017-03-16 21:55:07 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:07 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:07 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:07 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:07 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:07 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:07 --> Total execution time: 0.0239
INFO - 2017-03-16 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:07 --> Controller Class Initialized
INFO - 2017-03-16 21:55:07 --> Upload Class Initialized
INFO - 2017-03-16 21:55:07 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:07 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:07 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:07 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:07 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:07 --> Total execution time: 0.0994
INFO - 2017-03-16 21:55:08 --> Config Class Initialized
INFO - 2017-03-16 21:55:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:08 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:08 --> URI Class Initialized
INFO - 2017-03-16 21:55:08 --> Router Class Initialized
INFO - 2017-03-16 21:55:08 --> Output Class Initialized
INFO - 2017-03-16 21:55:08 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:08 --> Input Class Initialized
INFO - 2017-03-16 21:55:08 --> Language Class Initialized
INFO - 2017-03-16 21:55:08 --> Loader Class Initialized
INFO - 2017-03-16 21:55:08 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:08 --> Controller Class Initialized
INFO - 2017-03-16 21:55:08 --> Upload Class Initialized
INFO - 2017-03-16 21:55:08 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:08 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:08 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:08 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:08 --> Total execution time: 0.0155
INFO - 2017-03-16 21:55:11 --> Config Class Initialized
INFO - 2017-03-16 21:55:11 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:11 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:11 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:11 --> URI Class Initialized
INFO - 2017-03-16 21:55:11 --> Router Class Initialized
INFO - 2017-03-16 21:55:11 --> Output Class Initialized
INFO - 2017-03-16 21:55:11 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:11 --> Input Class Initialized
INFO - 2017-03-16 21:55:11 --> Language Class Initialized
INFO - 2017-03-16 21:55:11 --> Loader Class Initialized
INFO - 2017-03-16 21:55:11 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:11 --> Controller Class Initialized
INFO - 2017-03-16 21:55:11 --> Upload Class Initialized
INFO - 2017-03-16 21:55:11 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:11 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:11 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:11 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:11 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:11 --> Total execution time: 0.0150
INFO - 2017-03-16 21:55:25 --> Config Class Initialized
INFO - 2017-03-16 21:55:25 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:25 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:25 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:25 --> URI Class Initialized
INFO - 2017-03-16 21:55:25 --> Router Class Initialized
INFO - 2017-03-16 21:55:25 --> Output Class Initialized
INFO - 2017-03-16 21:55:25 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:25 --> Input Class Initialized
INFO - 2017-03-16 21:55:25 --> Language Class Initialized
INFO - 2017-03-16 21:55:25 --> Loader Class Initialized
INFO - 2017-03-16 21:55:25 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:25 --> Controller Class Initialized
INFO - 2017-03-16 21:55:25 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:25 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:25 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:25 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-16 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-16 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-16 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:55:25 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:25 --> Total execution time: 0.1203
INFO - 2017-03-16 21:55:26 --> Config Class Initialized
INFO - 2017-03-16 21:55:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:26 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:26 --> URI Class Initialized
INFO - 2017-03-16 21:55:26 --> Router Class Initialized
INFO - 2017-03-16 21:55:26 --> Output Class Initialized
INFO - 2017-03-16 21:55:26 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:26 --> Input Class Initialized
INFO - 2017-03-16 21:55:26 --> Language Class Initialized
INFO - 2017-03-16 21:55:26 --> Loader Class Initialized
INFO - 2017-03-16 21:55:26 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:26 --> Controller Class Initialized
INFO - 2017-03-16 21:55:26 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:26 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:26 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:26 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:26 --> Total execution time: 0.0143
INFO - 2017-03-16 21:55:26 --> Config Class Initialized
INFO - 2017-03-16 21:55:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:26 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:26 --> URI Class Initialized
INFO - 2017-03-16 21:55:26 --> Router Class Initialized
INFO - 2017-03-16 21:55:26 --> Output Class Initialized
INFO - 2017-03-16 21:55:26 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:26 --> Input Class Initialized
INFO - 2017-03-16 21:55:26 --> Language Class Initialized
INFO - 2017-03-16 21:55:26 --> Loader Class Initialized
INFO - 2017-03-16 21:55:26 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:26 --> Controller Class Initialized
INFO - 2017-03-16 21:55:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:55:26 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:26 --> Total execution time: 0.2832
INFO - 2017-03-16 21:55:28 --> Config Class Initialized
INFO - 2017-03-16 21:55:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:28 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:28 --> URI Class Initialized
INFO - 2017-03-16 21:55:28 --> Router Class Initialized
INFO - 2017-03-16 21:55:28 --> Output Class Initialized
INFO - 2017-03-16 21:55:28 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:28 --> Input Class Initialized
INFO - 2017-03-16 21:55:28 --> Language Class Initialized
INFO - 2017-03-16 21:55:28 --> Loader Class Initialized
INFO - 2017-03-16 21:55:28 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:28 --> Controller Class Initialized
INFO - 2017-03-16 21:55:28 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:28 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:28 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:28 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:28 --> Total execution time: 0.0415
INFO - 2017-03-16 21:55:28 --> Config Class Initialized
INFO - 2017-03-16 21:55:28 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:28 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:28 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:28 --> URI Class Initialized
INFO - 2017-03-16 21:55:28 --> Router Class Initialized
INFO - 2017-03-16 21:55:28 --> Output Class Initialized
INFO - 2017-03-16 21:55:28 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:28 --> Input Class Initialized
INFO - 2017-03-16 21:55:28 --> Language Class Initialized
INFO - 2017-03-16 21:55:28 --> Loader Class Initialized
INFO - 2017-03-16 21:55:28 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:28 --> Controller Class Initialized
INFO - 2017-03-16 21:55:28 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:28 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:28 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:28 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:28 --> Total execution time: 0.0209
INFO - 2017-03-16 21:55:33 --> Config Class Initialized
INFO - 2017-03-16 21:55:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:33 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:33 --> URI Class Initialized
INFO - 2017-03-16 21:55:33 --> Router Class Initialized
INFO - 2017-03-16 21:55:33 --> Output Class Initialized
INFO - 2017-03-16 21:55:33 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:33 --> Input Class Initialized
INFO - 2017-03-16 21:55:33 --> Language Class Initialized
INFO - 2017-03-16 21:55:33 --> Loader Class Initialized
INFO - 2017-03-16 21:55:33 --> Config Class Initialized
INFO - 2017-03-16 21:55:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:33 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:33 --> URI Class Initialized
INFO - 2017-03-16 21:55:33 --> Router Class Initialized
INFO - 2017-03-16 21:55:33 --> Output Class Initialized
INFO - 2017-03-16 21:55:33 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:33 --> Input Class Initialized
INFO - 2017-03-16 21:55:33 --> Language Class Initialized
INFO - 2017-03-16 21:55:33 --> Loader Class Initialized
INFO - 2017-03-16 21:55:33 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:33 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:33 --> Controller Class Initialized
INFO - 2017-03-16 21:55:33 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:33 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:33 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:33 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:33 --> Total execution time: 0.0254
INFO - 2017-03-16 21:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:33 --> Controller Class Initialized
INFO - 2017-03-16 21:55:33 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:33 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:33 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:33 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:33 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:33 --> Total execution time: 0.0919
INFO - 2017-03-16 21:55:36 --> Config Class Initialized
INFO - 2017-03-16 21:55:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:36 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:36 --> URI Class Initialized
INFO - 2017-03-16 21:55:36 --> Router Class Initialized
INFO - 2017-03-16 21:55:36 --> Output Class Initialized
INFO - 2017-03-16 21:55:36 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:36 --> Input Class Initialized
INFO - 2017-03-16 21:55:36 --> Language Class Initialized
INFO - 2017-03-16 21:55:36 --> Loader Class Initialized
INFO - 2017-03-16 21:55:36 --> Config Class Initialized
INFO - 2017-03-16 21:55:36 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:36 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:36 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:36 --> URI Class Initialized
INFO - 2017-03-16 21:55:36 --> Router Class Initialized
INFO - 2017-03-16 21:55:36 --> Output Class Initialized
INFO - 2017-03-16 21:55:36 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:36 --> Input Class Initialized
INFO - 2017-03-16 21:55:36 --> Language Class Initialized
INFO - 2017-03-16 21:55:36 --> Loader Class Initialized
INFO - 2017-03-16 21:55:36 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:36 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:36 --> Controller Class Initialized
INFO - 2017-03-16 21:55:36 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:36 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:36 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:36 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:36 --> Total execution time: 0.0291
INFO - 2017-03-16 21:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:36 --> Controller Class Initialized
INFO - 2017-03-16 21:55:36 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:36 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:36 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:36 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:36 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:36 --> Total execution time: 0.0285
INFO - 2017-03-16 21:55:43 --> Config Class Initialized
INFO - 2017-03-16 21:55:43 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:43 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:43 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:43 --> URI Class Initialized
INFO - 2017-03-16 21:55:43 --> Router Class Initialized
INFO - 2017-03-16 21:55:43 --> Output Class Initialized
INFO - 2017-03-16 21:55:43 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:43 --> Input Class Initialized
INFO - 2017-03-16 21:55:43 --> Language Class Initialized
INFO - 2017-03-16 21:55:43 --> Loader Class Initialized
INFO - 2017-03-16 21:55:43 --> Config Class Initialized
INFO - 2017-03-16 21:55:43 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:43 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:43 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:43 --> URI Class Initialized
INFO - 2017-03-16 21:55:43 --> Router Class Initialized
INFO - 2017-03-16 21:55:43 --> Output Class Initialized
INFO - 2017-03-16 21:55:43 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:43 --> Input Class Initialized
INFO - 2017-03-16 21:55:43 --> Language Class Initialized
INFO - 2017-03-16 21:55:43 --> Loader Class Initialized
INFO - 2017-03-16 21:55:43 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:43 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:43 --> Controller Class Initialized
INFO - 2017-03-16 21:55:43 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:43 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:43 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:43 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:43 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:43 --> Total execution time: 0.0175
INFO - 2017-03-16 21:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:43 --> Controller Class Initialized
INFO - 2017-03-16 21:55:43 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:43 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:43 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:43 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:43 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:43 --> Total execution time: 0.0416
INFO - 2017-03-16 21:55:47 --> Config Class Initialized
INFO - 2017-03-16 21:55:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:47 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:47 --> URI Class Initialized
INFO - 2017-03-16 21:55:47 --> Router Class Initialized
INFO - 2017-03-16 21:55:47 --> Output Class Initialized
INFO - 2017-03-16 21:55:47 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:47 --> Input Class Initialized
INFO - 2017-03-16 21:55:47 --> Language Class Initialized
INFO - 2017-03-16 21:55:47 --> Loader Class Initialized
INFO - 2017-03-16 21:55:47 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:47 --> Config Class Initialized
INFO - 2017-03-16 21:55:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:47 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:47 --> URI Class Initialized
INFO - 2017-03-16 21:55:47 --> Router Class Initialized
INFO - 2017-03-16 21:55:47 --> Output Class Initialized
INFO - 2017-03-16 21:55:47 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:47 --> Input Class Initialized
INFO - 2017-03-16 21:55:47 --> Language Class Initialized
INFO - 2017-03-16 21:55:47 --> Loader Class Initialized
INFO - 2017-03-16 21:55:47 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:47 --> Controller Class Initialized
INFO - 2017-03-16 21:55:47 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:47 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:47 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:47 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:47 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:47 --> Total execution time: 0.0773
INFO - 2017-03-16 21:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:47 --> Controller Class Initialized
INFO - 2017-03-16 21:55:47 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:47 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:47 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:47 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:47 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:47 --> Total execution time: 0.0827
INFO - 2017-03-16 21:55:49 --> Config Class Initialized
INFO - 2017-03-16 21:55:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:49 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:49 --> URI Class Initialized
INFO - 2017-03-16 21:55:49 --> Router Class Initialized
INFO - 2017-03-16 21:55:49 --> Output Class Initialized
INFO - 2017-03-16 21:55:49 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:49 --> Input Class Initialized
INFO - 2017-03-16 21:55:49 --> Language Class Initialized
INFO - 2017-03-16 21:55:49 --> Loader Class Initialized
INFO - 2017-03-16 21:55:49 --> Config Class Initialized
INFO - 2017-03-16 21:55:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:49 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:49 --> URI Class Initialized
INFO - 2017-03-16 21:55:49 --> Router Class Initialized
INFO - 2017-03-16 21:55:49 --> Output Class Initialized
INFO - 2017-03-16 21:55:49 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:49 --> Input Class Initialized
INFO - 2017-03-16 21:55:49 --> Language Class Initialized
INFO - 2017-03-16 21:55:49 --> Loader Class Initialized
INFO - 2017-03-16 21:55:49 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:49 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:49 --> Controller Class Initialized
INFO - 2017-03-16 21:55:49 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:49 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:49 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:49 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:49 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:49 --> Total execution time: 0.0251
INFO - 2017-03-16 21:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:49 --> Controller Class Initialized
INFO - 2017-03-16 21:55:49 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:49 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:49 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:49 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:49 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:49 --> Total execution time: 0.0220
INFO - 2017-03-16 21:55:51 --> Config Class Initialized
INFO - 2017-03-16 21:55:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:51 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:51 --> Config Class Initialized
INFO - 2017-03-16 21:55:51 --> Hooks Class Initialized
INFO - 2017-03-16 21:55:51 --> URI Class Initialized
INFO - 2017-03-16 21:55:51 --> Router Class Initialized
DEBUG - 2017-03-16 21:55:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:51 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:51 --> URI Class Initialized
INFO - 2017-03-16 21:55:51 --> Output Class Initialized
INFO - 2017-03-16 21:55:51 --> Router Class Initialized
INFO - 2017-03-16 21:55:51 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:51 --> Input Class Initialized
INFO - 2017-03-16 21:55:51 --> Output Class Initialized
INFO - 2017-03-16 21:55:51 --> Language Class Initialized
INFO - 2017-03-16 21:55:51 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:51 --> Loader Class Initialized
INFO - 2017-03-16 21:55:51 --> Input Class Initialized
INFO - 2017-03-16 21:55:51 --> Language Class Initialized
INFO - 2017-03-16 21:55:51 --> Loader Class Initialized
INFO - 2017-03-16 21:55:51 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:51 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:51 --> Controller Class Initialized
INFO - 2017-03-16 21:55:51 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:51 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:51 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:51 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:51 --> Total execution time: 0.0151
INFO - 2017-03-16 21:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:51 --> Controller Class Initialized
INFO - 2017-03-16 21:55:51 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:51 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:51 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:51 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:51 --> Total execution time: 0.0177
INFO - 2017-03-16 21:55:53 --> Config Class Initialized
INFO - 2017-03-16 21:55:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:53 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:53 --> URI Class Initialized
INFO - 2017-03-16 21:55:53 --> Router Class Initialized
INFO - 2017-03-16 21:55:53 --> Output Class Initialized
INFO - 2017-03-16 21:55:53 --> Config Class Initialized
INFO - 2017-03-16 21:55:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:53 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:53 --> URI Class Initialized
INFO - 2017-03-16 21:55:53 --> Router Class Initialized
INFO - 2017-03-16 21:55:53 --> Output Class Initialized
INFO - 2017-03-16 21:55:53 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:53 --> Input Class Initialized
INFO - 2017-03-16 21:55:53 --> Language Class Initialized
INFO - 2017-03-16 21:55:53 --> Loader Class Initialized
INFO - 2017-03-16 21:55:53 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:53 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:53 --> Input Class Initialized
INFO - 2017-03-16 21:55:53 --> Language Class Initialized
INFO - 2017-03-16 21:55:53 --> Loader Class Initialized
INFO - 2017-03-16 21:55:53 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:53 --> Controller Class Initialized
INFO - 2017-03-16 21:55:53 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:53 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:53 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:53 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:53 --> Total execution time: 0.0243
INFO - 2017-03-16 21:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:53 --> Controller Class Initialized
INFO - 2017-03-16 21:55:53 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:53 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:53 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:53 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:53 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:53 --> Total execution time: 0.0651
INFO - 2017-03-16 21:55:55 --> Config Class Initialized
INFO - 2017-03-16 21:55:55 --> Hooks Class Initialized
INFO - 2017-03-16 21:55:55 --> Config Class Initialized
INFO - 2017-03-16 21:55:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:55 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:55 --> URI Class Initialized
DEBUG - 2017-03-16 21:55:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:55 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:55 --> URI Class Initialized
INFO - 2017-03-16 21:55:55 --> Router Class Initialized
INFO - 2017-03-16 21:55:55 --> Router Class Initialized
INFO - 2017-03-16 21:55:55 --> Output Class Initialized
INFO - 2017-03-16 21:55:55 --> Security Class Initialized
INFO - 2017-03-16 21:55:55 --> Output Class Initialized
DEBUG - 2017-03-16 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:55 --> Security Class Initialized
INFO - 2017-03-16 21:55:55 --> Input Class Initialized
INFO - 2017-03-16 21:55:55 --> Language Class Initialized
DEBUG - 2017-03-16 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:55 --> Input Class Initialized
INFO - 2017-03-16 21:55:55 --> Language Class Initialized
INFO - 2017-03-16 21:55:55 --> Loader Class Initialized
INFO - 2017-03-16 21:55:55 --> Loader Class Initialized
INFO - 2017-03-16 21:55:55 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:55 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:55 --> Controller Class Initialized
INFO - 2017-03-16 21:55:55 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:55 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:55 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:55 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:55 --> Total execution time: 0.0877
INFO - 2017-03-16 21:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:55 --> Controller Class Initialized
INFO - 2017-03-16 21:55:55 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:55 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:55 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:55 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:55 --> Total execution time: 0.0977
INFO - 2017-03-16 21:55:57 --> Config Class Initialized
INFO - 2017-03-16 21:55:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:57 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:57 --> URI Class Initialized
INFO - 2017-03-16 21:55:57 --> Router Class Initialized
INFO - 2017-03-16 21:55:57 --> Output Class Initialized
INFO - 2017-03-16 21:55:57 --> Config Class Initialized
INFO - 2017-03-16 21:55:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:55:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:55:57 --> Utf8 Class Initialized
INFO - 2017-03-16 21:55:57 --> URI Class Initialized
INFO - 2017-03-16 21:55:57 --> Router Class Initialized
INFO - 2017-03-16 21:55:57 --> Output Class Initialized
INFO - 2017-03-16 21:55:57 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:57 --> Input Class Initialized
INFO - 2017-03-16 21:55:57 --> Language Class Initialized
INFO - 2017-03-16 21:55:57 --> Loader Class Initialized
INFO - 2017-03-16 21:55:57 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:57 --> Security Class Initialized
DEBUG - 2017-03-16 21:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:55:57 --> Input Class Initialized
INFO - 2017-03-16 21:55:57 --> Language Class Initialized
INFO - 2017-03-16 21:55:57 --> Loader Class Initialized
INFO - 2017-03-16 21:55:57 --> Database Driver Class Initialized
INFO - 2017-03-16 21:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:57 --> Controller Class Initialized
INFO - 2017-03-16 21:55:57 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:57 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:57 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:57 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:57 --> Total execution time: 0.0798
INFO - 2017-03-16 21:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:55:57 --> Controller Class Initialized
INFO - 2017-03-16 21:55:57 --> Helper loaded: date_helper
INFO - 2017-03-16 21:55:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:55:57 --> Helper loaded: form_helper
INFO - 2017-03-16 21:55:57 --> Form Validation Class Initialized
INFO - 2017-03-16 21:55:57 --> Final output sent to browser
DEBUG - 2017-03-16 21:55:57 --> Total execution time: 0.0826
INFO - 2017-03-16 21:56:02 --> Config Class Initialized
INFO - 2017-03-16 21:56:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:02 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:02 --> URI Class Initialized
INFO - 2017-03-16 21:56:02 --> Router Class Initialized
INFO - 2017-03-16 21:56:02 --> Output Class Initialized
INFO - 2017-03-16 21:56:02 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:02 --> Input Class Initialized
INFO - 2017-03-16 21:56:02 --> Language Class Initialized
INFO - 2017-03-16 21:56:02 --> Config Class Initialized
INFO - 2017-03-16 21:56:02 --> Hooks Class Initialized
INFO - 2017-03-16 21:56:02 --> Loader Class Initialized
DEBUG - 2017-03-16 21:56:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:02 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:02 --> URI Class Initialized
INFO - 2017-03-16 21:56:02 --> Router Class Initialized
INFO - 2017-03-16 21:56:02 --> Output Class Initialized
INFO - 2017-03-16 21:56:02 --> Security Class Initialized
INFO - 2017-03-16 21:56:02 --> Database Driver Class Initialized
DEBUG - 2017-03-16 21:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:02 --> Input Class Initialized
INFO - 2017-03-16 21:56:02 --> Language Class Initialized
INFO - 2017-03-16 21:56:02 --> Loader Class Initialized
INFO - 2017-03-16 21:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:02 --> Controller Class Initialized
INFO - 2017-03-16 21:56:02 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:02 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:02 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:02 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:02 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:02 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:02 --> Total execution time: 0.0149
INFO - 2017-03-16 21:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:02 --> Controller Class Initialized
INFO - 2017-03-16 21:56:02 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:02 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:02 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:02 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:02 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:02 --> Total execution time: 0.0947
INFO - 2017-03-16 21:56:08 --> Config Class Initialized
INFO - 2017-03-16 21:56:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:08 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:08 --> URI Class Initialized
INFO - 2017-03-16 21:56:08 --> Router Class Initialized
INFO - 2017-03-16 21:56:08 --> Output Class Initialized
INFO - 2017-03-16 21:56:08 --> Config Class Initialized
INFO - 2017-03-16 21:56:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:08 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:08 --> URI Class Initialized
INFO - 2017-03-16 21:56:08 --> Router Class Initialized
INFO - 2017-03-16 21:56:08 --> Output Class Initialized
INFO - 2017-03-16 21:56:08 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:08 --> Input Class Initialized
INFO - 2017-03-16 21:56:08 --> Language Class Initialized
INFO - 2017-03-16 21:56:08 --> Loader Class Initialized
INFO - 2017-03-16 21:56:08 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:08 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:08 --> Input Class Initialized
INFO - 2017-03-16 21:56:08 --> Language Class Initialized
INFO - 2017-03-16 21:56:08 --> Loader Class Initialized
INFO - 2017-03-16 21:56:08 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:08 --> Controller Class Initialized
INFO - 2017-03-16 21:56:08 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:08 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:08 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:08 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:08 --> Total execution time: 0.0225
INFO - 2017-03-16 21:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:08 --> Controller Class Initialized
INFO - 2017-03-16 21:56:08 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:08 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:08 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:08 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:08 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:08 --> Total execution time: 0.0400
INFO - 2017-03-16 21:56:12 --> Config Class Initialized
INFO - 2017-03-16 21:56:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:12 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:12 --> URI Class Initialized
INFO - 2017-03-16 21:56:12 --> Config Class Initialized
INFO - 2017-03-16 21:56:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:12 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:12 --> URI Class Initialized
INFO - 2017-03-16 21:56:12 --> Router Class Initialized
INFO - 2017-03-16 21:56:12 --> Output Class Initialized
INFO - 2017-03-16 21:56:12 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:12 --> Input Class Initialized
INFO - 2017-03-16 21:56:12 --> Language Class Initialized
INFO - 2017-03-16 21:56:12 --> Loader Class Initialized
INFO - 2017-03-16 21:56:12 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:12 --> Router Class Initialized
INFO - 2017-03-16 21:56:12 --> Output Class Initialized
INFO - 2017-03-16 21:56:12 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:12 --> Input Class Initialized
INFO - 2017-03-16 21:56:12 --> Language Class Initialized
INFO - 2017-03-16 21:56:12 --> Loader Class Initialized
INFO - 2017-03-16 21:56:12 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:12 --> Controller Class Initialized
INFO - 2017-03-16 21:56:12 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:12 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:12 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:12 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:12 --> Total execution time: 0.0800
INFO - 2017-03-16 21:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:12 --> Controller Class Initialized
INFO - 2017-03-16 21:56:12 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:12 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:12 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:12 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:12 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:12 --> Total execution time: 0.0324
INFO - 2017-03-16 21:56:14 --> Config Class Initialized
INFO - 2017-03-16 21:56:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:14 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:14 --> URI Class Initialized
INFO - 2017-03-16 21:56:14 --> Router Class Initialized
INFO - 2017-03-16 21:56:14 --> Output Class Initialized
INFO - 2017-03-16 21:56:14 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:14 --> Input Class Initialized
INFO - 2017-03-16 21:56:14 --> Language Class Initialized
INFO - 2017-03-16 21:56:14 --> Loader Class Initialized
INFO - 2017-03-16 21:56:14 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:14 --> Config Class Initialized
INFO - 2017-03-16 21:56:14 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:14 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:14 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:14 --> URI Class Initialized
INFO - 2017-03-16 21:56:14 --> Router Class Initialized
INFO - 2017-03-16 21:56:14 --> Output Class Initialized
INFO - 2017-03-16 21:56:14 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:14 --> Input Class Initialized
INFO - 2017-03-16 21:56:14 --> Language Class Initialized
INFO - 2017-03-16 21:56:14 --> Loader Class Initialized
INFO - 2017-03-16 21:56:14 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:14 --> Controller Class Initialized
INFO - 2017-03-16 21:56:14 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:14 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:14 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:14 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:14 --> Total execution time: 0.0254
INFO - 2017-03-16 21:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:14 --> Controller Class Initialized
INFO - 2017-03-16 21:56:14 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:14 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:14 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:14 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:14 --> Total execution time: 0.0903
INFO - 2017-03-16 21:56:17 --> Config Class Initialized
INFO - 2017-03-16 21:56:17 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:17 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:17 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:17 --> URI Class Initialized
INFO - 2017-03-16 21:56:17 --> Router Class Initialized
INFO - 2017-03-16 21:56:17 --> Output Class Initialized
INFO - 2017-03-16 21:56:17 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:17 --> Input Class Initialized
INFO - 2017-03-16 21:56:17 --> Language Class Initialized
INFO - 2017-03-16 21:56:17 --> Loader Class Initialized
INFO - 2017-03-16 21:56:17 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:17 --> Config Class Initialized
INFO - 2017-03-16 21:56:17 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:17 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:17 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:17 --> URI Class Initialized
INFO - 2017-03-16 21:56:17 --> Router Class Initialized
INFO - 2017-03-16 21:56:17 --> Output Class Initialized
INFO - 2017-03-16 21:56:17 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:17 --> Input Class Initialized
INFO - 2017-03-16 21:56:17 --> Language Class Initialized
INFO - 2017-03-16 21:56:17 --> Loader Class Initialized
INFO - 2017-03-16 21:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:17 --> Controller Class Initialized
INFO - 2017-03-16 21:56:17 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:17 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:17 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:17 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:17 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:17 --> Total execution time: 0.0527
INFO - 2017-03-16 21:56:17 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:17 --> Controller Class Initialized
INFO - 2017-03-16 21:56:17 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:17 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:17 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:17 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:17 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:17 --> Total execution time: 0.0255
INFO - 2017-03-16 21:56:23 --> Config Class Initialized
INFO - 2017-03-16 21:56:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:23 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:23 --> URI Class Initialized
INFO - 2017-03-16 21:56:23 --> Router Class Initialized
INFO - 2017-03-16 21:56:23 --> Output Class Initialized
INFO - 2017-03-16 21:56:23 --> Security Class Initialized
INFO - 2017-03-16 21:56:23 --> Config Class Initialized
INFO - 2017-03-16 21:56:23 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:23 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:23 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:23 --> URI Class Initialized
INFO - 2017-03-16 21:56:23 --> Router Class Initialized
INFO - 2017-03-16 21:56:23 --> Output Class Initialized
INFO - 2017-03-16 21:56:23 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:23 --> Input Class Initialized
INFO - 2017-03-16 21:56:23 --> Language Class Initialized
INFO - 2017-03-16 21:56:23 --> Loader Class Initialized
DEBUG - 2017-03-16 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:23 --> Input Class Initialized
INFO - 2017-03-16 21:56:23 --> Language Class Initialized
INFO - 2017-03-16 21:56:23 --> Loader Class Initialized
INFO - 2017-03-16 21:56:23 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:23 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:23 --> Controller Class Initialized
INFO - 2017-03-16 21:56:23 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:23 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:23 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:23 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:23 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:23 --> Total execution time: 0.0206
INFO - 2017-03-16 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:23 --> Controller Class Initialized
INFO - 2017-03-16 21:56:23 --> Helper loaded: date_helper
INFO - 2017-03-16 21:56:23 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:23 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:23 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:23 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:23 --> Total execution time: 0.0408
INFO - 2017-03-16 21:56:26 --> Config Class Initialized
INFO - 2017-03-16 21:56:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:26 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:26 --> URI Class Initialized
INFO - 2017-03-16 21:56:26 --> Router Class Initialized
INFO - 2017-03-16 21:56:26 --> Output Class Initialized
INFO - 2017-03-16 21:56:26 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:26 --> Input Class Initialized
INFO - 2017-03-16 21:56:26 --> Language Class Initialized
INFO - 2017-03-16 21:56:26 --> Loader Class Initialized
INFO - 2017-03-16 21:56:26 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:26 --> Controller Class Initialized
INFO - 2017-03-16 21:56:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:26 --> Config Class Initialized
INFO - 2017-03-16 21:56:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:26 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:26 --> URI Class Initialized
INFO - 2017-03-16 21:56:26 --> Router Class Initialized
INFO - 2017-03-16 21:56:26 --> Output Class Initialized
INFO - 2017-03-16 21:56:26 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:26 --> Input Class Initialized
INFO - 2017-03-16 21:56:26 --> Language Class Initialized
INFO - 2017-03-16 21:56:26 --> Loader Class Initialized
INFO - 2017-03-16 21:56:26 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:26 --> Controller Class Initialized
INFO - 2017-03-16 21:56:26 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:26 --> Helper loaded: form_helper
INFO - 2017-03-16 21:56:26 --> Form Validation Class Initialized
INFO - 2017-03-16 21:56:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-16 21:56:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-16 21:56:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-16 21:56:26 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:26 --> Total execution time: 0.0189
INFO - 2017-03-16 21:56:26 --> Config Class Initialized
INFO - 2017-03-16 21:56:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:26 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:26 --> URI Class Initialized
INFO - 2017-03-16 21:56:26 --> Router Class Initialized
INFO - 2017-03-16 21:56:26 --> Output Class Initialized
INFO - 2017-03-16 21:56:26 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:26 --> Input Class Initialized
INFO - 2017-03-16 21:56:26 --> Language Class Initialized
INFO - 2017-03-16 21:56:26 --> Loader Class Initialized
INFO - 2017-03-16 21:56:26 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:27 --> Controller Class Initialized
INFO - 2017-03-16 21:56:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:56:27 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:27 --> Total execution time: 0.0290
INFO - 2017-03-16 21:56:27 --> Config Class Initialized
INFO - 2017-03-16 21:56:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 21:56:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 21:56:27 --> Utf8 Class Initialized
INFO - 2017-03-16 21:56:27 --> URI Class Initialized
INFO - 2017-03-16 21:56:27 --> Router Class Initialized
INFO - 2017-03-16 21:56:27 --> Output Class Initialized
INFO - 2017-03-16 21:56:27 --> Security Class Initialized
DEBUG - 2017-03-16 21:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 21:56:27 --> Input Class Initialized
INFO - 2017-03-16 21:56:27 --> Language Class Initialized
INFO - 2017-03-16 21:56:27 --> Loader Class Initialized
INFO - 2017-03-16 21:56:27 --> Database Driver Class Initialized
INFO - 2017-03-16 21:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 21:56:27 --> Controller Class Initialized
INFO - 2017-03-16 21:56:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 21:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 21:56:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 21:56:27 --> Final output sent to browser
DEBUG - 2017-03-16 21:56:27 --> Total execution time: 0.0619
INFO - 2017-03-16 22:35:53 --> Config Class Initialized
INFO - 2017-03-16 22:35:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:35:53 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:35:53 --> Utf8 Class Initialized
INFO - 2017-03-16 22:35:53 --> URI Class Initialized
INFO - 2017-03-16 22:35:53 --> Router Class Initialized
INFO - 2017-03-16 22:35:53 --> Output Class Initialized
INFO - 2017-03-16 22:35:53 --> Security Class Initialized
DEBUG - 2017-03-16 22:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:35:53 --> Input Class Initialized
INFO - 2017-03-16 22:35:53 --> Language Class Initialized
INFO - 2017-03-16 22:35:53 --> Loader Class Initialized
INFO - 2017-03-16 22:35:54 --> Database Driver Class Initialized
INFO - 2017-03-16 22:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:35:54 --> Controller Class Initialized
INFO - 2017-03-16 22:35:54 --> Helper loaded: date_helper
DEBUG - 2017-03-16 22:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:35:54 --> Helper loaded: url_helper
INFO - 2017-03-16 22:35:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:35:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 22:35:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 22:35:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 22:35:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:35:54 --> Final output sent to browser
DEBUG - 2017-03-16 22:35:54 --> Total execution time: 1.3345
INFO - 2017-03-16 22:35:57 --> Config Class Initialized
INFO - 2017-03-16 22:35:57 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:35:57 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:35:57 --> Utf8 Class Initialized
INFO - 2017-03-16 22:35:57 --> URI Class Initialized
INFO - 2017-03-16 22:35:57 --> Router Class Initialized
INFO - 2017-03-16 22:35:57 --> Output Class Initialized
INFO - 2017-03-16 22:35:57 --> Security Class Initialized
DEBUG - 2017-03-16 22:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:35:57 --> Input Class Initialized
INFO - 2017-03-16 22:35:57 --> Language Class Initialized
INFO - 2017-03-16 22:35:57 --> Loader Class Initialized
INFO - 2017-03-16 22:35:57 --> Database Driver Class Initialized
INFO - 2017-03-16 22:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:35:57 --> Controller Class Initialized
INFO - 2017-03-16 22:35:57 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:35:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:35:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:35:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:35:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:35:58 --> Final output sent to browser
DEBUG - 2017-03-16 22:35:58 --> Total execution time: 0.2616
INFO - 2017-03-16 22:37:46 --> Config Class Initialized
INFO - 2017-03-16 22:37:46 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:37:46 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:37:46 --> Utf8 Class Initialized
INFO - 2017-03-16 22:37:46 --> URI Class Initialized
DEBUG - 2017-03-16 22:37:46 --> No URI present. Default controller set.
INFO - 2017-03-16 22:37:46 --> Router Class Initialized
INFO - 2017-03-16 22:37:46 --> Output Class Initialized
INFO - 2017-03-16 22:37:46 --> Security Class Initialized
DEBUG - 2017-03-16 22:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:37:46 --> Input Class Initialized
INFO - 2017-03-16 22:37:46 --> Language Class Initialized
INFO - 2017-03-16 22:37:46 --> Loader Class Initialized
INFO - 2017-03-16 22:37:47 --> Database Driver Class Initialized
INFO - 2017-03-16 22:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:37:47 --> Controller Class Initialized
INFO - 2017-03-16 22:37:47 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:37:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:37:47 --> Final output sent to browser
DEBUG - 2017-03-16 22:37:47 --> Total execution time: 1.4542
INFO - 2017-03-16 22:37:50 --> Config Class Initialized
INFO - 2017-03-16 22:37:50 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:37:50 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:37:50 --> Utf8 Class Initialized
INFO - 2017-03-16 22:37:50 --> URI Class Initialized
INFO - 2017-03-16 22:37:50 --> Router Class Initialized
INFO - 2017-03-16 22:37:50 --> Output Class Initialized
INFO - 2017-03-16 22:37:50 --> Security Class Initialized
DEBUG - 2017-03-16 22:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:37:50 --> Input Class Initialized
INFO - 2017-03-16 22:37:50 --> Language Class Initialized
INFO - 2017-03-16 22:37:50 --> Loader Class Initialized
INFO - 2017-03-16 22:37:50 --> Database Driver Class Initialized
INFO - 2017-03-16 22:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:37:50 --> Controller Class Initialized
INFO - 2017-03-16 22:37:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:37:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:37:50 --> Final output sent to browser
DEBUG - 2017-03-16 22:37:50 --> Total execution time: 0.0134
INFO - 2017-03-16 22:37:52 --> Config Class Initialized
INFO - 2017-03-16 22:37:52 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:37:52 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:37:52 --> Utf8 Class Initialized
INFO - 2017-03-16 22:37:52 --> URI Class Initialized
DEBUG - 2017-03-16 22:37:52 --> No URI present. Default controller set.
INFO - 2017-03-16 22:37:52 --> Router Class Initialized
INFO - 2017-03-16 22:37:52 --> Output Class Initialized
INFO - 2017-03-16 22:37:52 --> Security Class Initialized
DEBUG - 2017-03-16 22:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:37:52 --> Input Class Initialized
INFO - 2017-03-16 22:37:52 --> Language Class Initialized
INFO - 2017-03-16 22:37:52 --> Loader Class Initialized
INFO - 2017-03-16 22:37:52 --> Database Driver Class Initialized
INFO - 2017-03-16 22:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:37:52 --> Controller Class Initialized
INFO - 2017-03-16 22:37:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:37:52 --> Final output sent to browser
DEBUG - 2017-03-16 22:37:52 --> Total execution time: 0.0152
INFO - 2017-03-16 22:37:53 --> Config Class Initialized
INFO - 2017-03-16 22:37:53 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:37:54 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:37:54 --> Utf8 Class Initialized
INFO - 2017-03-16 22:37:54 --> URI Class Initialized
INFO - 2017-03-16 22:37:54 --> Router Class Initialized
INFO - 2017-03-16 22:37:54 --> Output Class Initialized
INFO - 2017-03-16 22:37:54 --> Security Class Initialized
DEBUG - 2017-03-16 22:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:37:54 --> Input Class Initialized
INFO - 2017-03-16 22:37:54 --> Language Class Initialized
INFO - 2017-03-16 22:37:54 --> Loader Class Initialized
INFO - 2017-03-16 22:37:54 --> Database Driver Class Initialized
INFO - 2017-03-16 22:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:37:54 --> Controller Class Initialized
INFO - 2017-03-16 22:37:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:37:55 --> Final output sent to browser
DEBUG - 2017-03-16 22:37:55 --> Total execution time: 1.2269
INFO - 2017-03-16 22:38:08 --> Config Class Initialized
INFO - 2017-03-16 22:38:08 --> Config Class Initialized
INFO - 2017-03-16 22:38:08 --> Hooks Class Initialized
INFO - 2017-03-16 22:38:08 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:38:08 --> UTF-8 Support Enabled
DEBUG - 2017-03-16 22:38:08 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:38:08 --> Utf8 Class Initialized
INFO - 2017-03-16 22:38:08 --> Utf8 Class Initialized
INFO - 2017-03-16 22:38:08 --> URI Class Initialized
INFO - 2017-03-16 22:38:08 --> URI Class Initialized
DEBUG - 2017-03-16 22:38:08 --> No URI present. Default controller set.
INFO - 2017-03-16 22:38:08 --> Router Class Initialized
INFO - 2017-03-16 22:38:08 --> Router Class Initialized
INFO - 2017-03-16 22:38:09 --> Output Class Initialized
INFO - 2017-03-16 22:38:09 --> Output Class Initialized
INFO - 2017-03-16 22:38:09 --> Security Class Initialized
INFO - 2017-03-16 22:38:09 --> Security Class Initialized
DEBUG - 2017-03-16 22:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:38:09 --> Input Class Initialized
INFO - 2017-03-16 22:38:09 --> Language Class Initialized
DEBUG - 2017-03-16 22:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:38:09 --> Input Class Initialized
INFO - 2017-03-16 22:38:09 --> Language Class Initialized
INFO - 2017-03-16 22:38:09 --> Loader Class Initialized
INFO - 2017-03-16 22:38:09 --> Loader Class Initialized
INFO - 2017-03-16 22:38:09 --> Database Driver Class Initialized
INFO - 2017-03-16 22:38:09 --> Database Driver Class Initialized
INFO - 2017-03-16 22:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:38:09 --> Controller Class Initialized
INFO - 2017-03-16 22:38:09 --> Helper loaded: date_helper
DEBUG - 2017-03-16 22:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:38:09 --> Helper loaded: url_helper
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:38:10 --> Final output sent to browser
DEBUG - 2017-03-16 22:38:10 --> Total execution time: 1.3474
INFO - 2017-03-16 22:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:38:10 --> Controller Class Initialized
INFO - 2017-03-16 22:38:10 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:38:10 --> Final output sent to browser
DEBUG - 2017-03-16 22:38:10 --> Total execution time: 1.5870
INFO - 2017-03-16 22:38:18 --> Config Class Initialized
INFO - 2017-03-16 22:38:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:38:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:38:18 --> Utf8 Class Initialized
INFO - 2017-03-16 22:38:18 --> URI Class Initialized
INFO - 2017-03-16 22:38:18 --> Router Class Initialized
INFO - 2017-03-16 22:38:18 --> Output Class Initialized
INFO - 2017-03-16 22:38:18 --> Security Class Initialized
DEBUG - 2017-03-16 22:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:38:18 --> Input Class Initialized
INFO - 2017-03-16 22:38:18 --> Language Class Initialized
INFO - 2017-03-16 22:38:18 --> Loader Class Initialized
INFO - 2017-03-16 22:38:18 --> Database Driver Class Initialized
INFO - 2017-03-16 22:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:38:18 --> Controller Class Initialized
INFO - 2017-03-16 22:38:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:38:18 --> Final output sent to browser
DEBUG - 2017-03-16 22:38:18 --> Total execution time: 0.0136
INFO - 2017-03-16 22:38:18 --> Config Class Initialized
INFO - 2017-03-16 22:38:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:38:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:38:18 --> Utf8 Class Initialized
INFO - 2017-03-16 22:38:18 --> URI Class Initialized
INFO - 2017-03-16 22:38:18 --> Router Class Initialized
INFO - 2017-03-16 22:38:18 --> Output Class Initialized
INFO - 2017-03-16 22:38:18 --> Security Class Initialized
DEBUG - 2017-03-16 22:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:38:18 --> Input Class Initialized
INFO - 2017-03-16 22:38:18 --> Language Class Initialized
INFO - 2017-03-16 22:38:18 --> Loader Class Initialized
INFO - 2017-03-16 22:38:18 --> Database Driver Class Initialized
INFO - 2017-03-16 22:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:38:18 --> Controller Class Initialized
INFO - 2017-03-16 22:38:18 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:38:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:38:18 --> Final output sent to browser
DEBUG - 2017-03-16 22:38:18 --> Total execution time: 0.0128
INFO - 2017-03-16 22:56:01 --> Config Class Initialized
INFO - 2017-03-16 22:56:01 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:56:01 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:56:01 --> Utf8 Class Initialized
INFO - 2017-03-16 22:56:01 --> URI Class Initialized
DEBUG - 2017-03-16 22:56:01 --> No URI present. Default controller set.
INFO - 2017-03-16 22:56:01 --> Router Class Initialized
INFO - 2017-03-16 22:56:01 --> Output Class Initialized
INFO - 2017-03-16 22:56:01 --> Security Class Initialized
DEBUG - 2017-03-16 22:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:56:02 --> Input Class Initialized
INFO - 2017-03-16 22:56:02 --> Language Class Initialized
INFO - 2017-03-16 22:56:02 --> Loader Class Initialized
INFO - 2017-03-16 22:56:02 --> Database Driver Class Initialized
INFO - 2017-03-16 22:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:56:02 --> Controller Class Initialized
INFO - 2017-03-16 22:56:02 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:56:03 --> Final output sent to browser
DEBUG - 2017-03-16 22:56:03 --> Total execution time: 1.8565
INFO - 2017-03-16 22:56:06 --> Config Class Initialized
INFO - 2017-03-16 22:56:06 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:56:06 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:56:06 --> Utf8 Class Initialized
INFO - 2017-03-16 22:56:06 --> URI Class Initialized
INFO - 2017-03-16 22:56:06 --> Router Class Initialized
INFO - 2017-03-16 22:56:06 --> Output Class Initialized
INFO - 2017-03-16 22:56:06 --> Security Class Initialized
DEBUG - 2017-03-16 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:56:06 --> Input Class Initialized
INFO - 2017-03-16 22:56:06 --> Language Class Initialized
INFO - 2017-03-16 22:56:06 --> Loader Class Initialized
INFO - 2017-03-16 22:56:06 --> Database Driver Class Initialized
INFO - 2017-03-16 22:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:56:06 --> Controller Class Initialized
INFO - 2017-03-16 22:56:06 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:56:06 --> Final output sent to browser
DEBUG - 2017-03-16 22:56:06 --> Total execution time: 0.0133
INFO - 2017-03-16 22:56:16 --> Config Class Initialized
INFO - 2017-03-16 22:56:16 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:56:16 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:56:16 --> Utf8 Class Initialized
INFO - 2017-03-16 22:56:16 --> URI Class Initialized
INFO - 2017-03-16 22:56:16 --> Router Class Initialized
INFO - 2017-03-16 22:56:16 --> Output Class Initialized
INFO - 2017-03-16 22:56:16 --> Security Class Initialized
DEBUG - 2017-03-16 22:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:56:16 --> Input Class Initialized
INFO - 2017-03-16 22:56:16 --> Language Class Initialized
INFO - 2017-03-16 22:56:16 --> Loader Class Initialized
INFO - 2017-03-16 22:56:16 --> Database Driver Class Initialized
INFO - 2017-03-16 22:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:56:16 --> Controller Class Initialized
INFO - 2017-03-16 22:56:16 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:56:18 --> Config Class Initialized
INFO - 2017-03-16 22:56:18 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:56:18 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:56:18 --> Utf8 Class Initialized
INFO - 2017-03-16 22:56:18 --> URI Class Initialized
INFO - 2017-03-16 22:56:18 --> Router Class Initialized
INFO - 2017-03-16 22:56:18 --> Output Class Initialized
INFO - 2017-03-16 22:56:18 --> Security Class Initialized
DEBUG - 2017-03-16 22:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:56:18 --> Input Class Initialized
INFO - 2017-03-16 22:56:18 --> Language Class Initialized
INFO - 2017-03-16 22:56:18 --> Loader Class Initialized
INFO - 2017-03-16 22:56:18 --> Database Driver Class Initialized
INFO - 2017-03-16 22:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:56:18 --> Controller Class Initialized
INFO - 2017-03-16 22:56:18 --> Helper loaded: date_helper
DEBUG - 2017-03-16 22:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:56:18 --> Helper loaded: url_helper
INFO - 2017-03-16 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-16 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-16 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:56:18 --> Final output sent to browser
DEBUG - 2017-03-16 22:56:18 --> Total execution time: 0.1016
INFO - 2017-03-16 22:56:19 --> Config Class Initialized
INFO - 2017-03-16 22:56:19 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:56:19 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:56:19 --> Utf8 Class Initialized
INFO - 2017-03-16 22:56:19 --> URI Class Initialized
INFO - 2017-03-16 22:56:19 --> Router Class Initialized
INFO - 2017-03-16 22:56:19 --> Output Class Initialized
INFO - 2017-03-16 22:56:19 --> Security Class Initialized
DEBUG - 2017-03-16 22:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:56:19 --> Input Class Initialized
INFO - 2017-03-16 22:56:19 --> Language Class Initialized
INFO - 2017-03-16 22:56:19 --> Loader Class Initialized
INFO - 2017-03-16 22:56:19 --> Database Driver Class Initialized
INFO - 2017-03-16 22:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:56:19 --> Controller Class Initialized
INFO - 2017-03-16 22:56:19 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:56:19 --> Final output sent to browser
DEBUG - 2017-03-16 22:56:19 --> Total execution time: 0.0138
INFO - 2017-03-16 22:58:27 --> Config Class Initialized
INFO - 2017-03-16 22:58:27 --> Hooks Class Initialized
DEBUG - 2017-03-16 22:58:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 22:58:27 --> Utf8 Class Initialized
INFO - 2017-03-16 22:58:27 --> URI Class Initialized
DEBUG - 2017-03-16 22:58:27 --> No URI present. Default controller set.
INFO - 2017-03-16 22:58:27 --> Router Class Initialized
INFO - 2017-03-16 22:58:27 --> Output Class Initialized
INFO - 2017-03-16 22:58:27 --> Security Class Initialized
DEBUG - 2017-03-16 22:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 22:58:27 --> Input Class Initialized
INFO - 2017-03-16 22:58:27 --> Language Class Initialized
INFO - 2017-03-16 22:58:27 --> Loader Class Initialized
INFO - 2017-03-16 22:58:27 --> Database Driver Class Initialized
INFO - 2017-03-16 22:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 22:58:28 --> Controller Class Initialized
INFO - 2017-03-16 22:58:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 22:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 22:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 22:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 22:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 22:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 22:58:28 --> Final output sent to browser
DEBUG - 2017-03-16 22:58:28 --> Total execution time: 1.4658
INFO - 2017-03-16 23:15:00 --> Config Class Initialized
INFO - 2017-03-16 23:15:00 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:15:00 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:15:00 --> Utf8 Class Initialized
INFO - 2017-03-16 23:15:00 --> URI Class Initialized
INFO - 2017-03-16 23:15:00 --> Router Class Initialized
INFO - 2017-03-16 23:15:00 --> Output Class Initialized
INFO - 2017-03-16 23:15:00 --> Security Class Initialized
DEBUG - 2017-03-16 23:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:15:00 --> Input Class Initialized
INFO - 2017-03-16 23:15:00 --> Language Class Initialized
INFO - 2017-03-16 23:15:00 --> Loader Class Initialized
INFO - 2017-03-16 23:15:01 --> Database Driver Class Initialized
INFO - 2017-03-16 23:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:15:01 --> Controller Class Initialized
INFO - 2017-03-16 23:15:01 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:15:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:15:01 --> Final output sent to browser
DEBUG - 2017-03-16 23:15:01 --> Total execution time: 1.5475
INFO - 2017-03-16 23:17:26 --> Config Class Initialized
INFO - 2017-03-16 23:17:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:17:26 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:17:26 --> Utf8 Class Initialized
INFO - 2017-03-16 23:17:26 --> URI Class Initialized
DEBUG - 2017-03-16 23:17:27 --> No URI present. Default controller set.
INFO - 2017-03-16 23:17:27 --> Router Class Initialized
INFO - 2017-03-16 23:17:27 --> Output Class Initialized
INFO - 2017-03-16 23:17:27 --> Security Class Initialized
DEBUG - 2017-03-16 23:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:17:27 --> Input Class Initialized
INFO - 2017-03-16 23:17:27 --> Language Class Initialized
INFO - 2017-03-16 23:17:27 --> Loader Class Initialized
INFO - 2017-03-16 23:17:27 --> Database Driver Class Initialized
INFO - 2017-03-16 23:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:17:28 --> Controller Class Initialized
INFO - 2017-03-16 23:17:28 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:17:28 --> Final output sent to browser
DEBUG - 2017-03-16 23:17:28 --> Total execution time: 2.0592
INFO - 2017-03-16 23:25:55 --> Config Class Initialized
INFO - 2017-03-16 23:25:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:25:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:25:55 --> Utf8 Class Initialized
INFO - 2017-03-16 23:25:55 --> URI Class Initialized
DEBUG - 2017-03-16 23:25:55 --> No URI present. Default controller set.
INFO - 2017-03-16 23:25:55 --> Router Class Initialized
INFO - 2017-03-16 23:25:55 --> Output Class Initialized
INFO - 2017-03-16 23:25:55 --> Security Class Initialized
DEBUG - 2017-03-16 23:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:25:56 --> Input Class Initialized
INFO - 2017-03-16 23:25:56 --> Language Class Initialized
INFO - 2017-03-16 23:25:56 --> Loader Class Initialized
INFO - 2017-03-16 23:25:56 --> Database Driver Class Initialized
INFO - 2017-03-16 23:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:25:56 --> Controller Class Initialized
INFO - 2017-03-16 23:25:56 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:25:56 --> Final output sent to browser
DEBUG - 2017-03-16 23:25:56 --> Total execution time: 1.2334
INFO - 2017-03-16 23:26:02 --> Config Class Initialized
INFO - 2017-03-16 23:26:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:26:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:26:02 --> Utf8 Class Initialized
INFO - 2017-03-16 23:26:02 --> URI Class Initialized
INFO - 2017-03-16 23:26:02 --> Router Class Initialized
INFO - 2017-03-16 23:26:02 --> Output Class Initialized
INFO - 2017-03-16 23:26:02 --> Security Class Initialized
DEBUG - 2017-03-16 23:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:26:02 --> Input Class Initialized
INFO - 2017-03-16 23:26:02 --> Language Class Initialized
INFO - 2017-03-16 23:26:02 --> Loader Class Initialized
INFO - 2017-03-16 23:26:02 --> Database Driver Class Initialized
INFO - 2017-03-16 23:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:26:03 --> Controller Class Initialized
INFO - 2017-03-16 23:26:03 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:26:03 --> Final output sent to browser
DEBUG - 2017-03-16 23:26:03 --> Total execution time: 0.8522
INFO - 2017-03-16 23:27:13 --> Config Class Initialized
INFO - 2017-03-16 23:27:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:27:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:27:13 --> Utf8 Class Initialized
INFO - 2017-03-16 23:27:13 --> URI Class Initialized
INFO - 2017-03-16 23:27:13 --> Router Class Initialized
INFO - 2017-03-16 23:27:13 --> Output Class Initialized
INFO - 2017-03-16 23:27:13 --> Security Class Initialized
DEBUG - 2017-03-16 23:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:27:13 --> Input Class Initialized
INFO - 2017-03-16 23:27:13 --> Language Class Initialized
INFO - 2017-03-16 23:27:13 --> Loader Class Initialized
INFO - 2017-03-16 23:27:13 --> Database Driver Class Initialized
INFO - 2017-03-16 23:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:27:13 --> Controller Class Initialized
INFO - 2017-03-16 23:27:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:27:15 --> Config Class Initialized
INFO - 2017-03-16 23:27:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:27:15 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:27:15 --> Utf8 Class Initialized
INFO - 2017-03-16 23:27:15 --> URI Class Initialized
INFO - 2017-03-16 23:27:15 --> Router Class Initialized
INFO - 2017-03-16 23:27:15 --> Output Class Initialized
INFO - 2017-03-16 23:27:15 --> Security Class Initialized
DEBUG - 2017-03-16 23:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:27:15 --> Input Class Initialized
INFO - 2017-03-16 23:27:15 --> Language Class Initialized
INFO - 2017-03-16 23:27:15 --> Loader Class Initialized
INFO - 2017-03-16 23:27:15 --> Database Driver Class Initialized
INFO - 2017-03-16 23:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:27:15 --> Controller Class Initialized
INFO - 2017-03-16 23:27:15 --> Helper loaded: date_helper
DEBUG - 2017-03-16 23:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:27:15 --> Helper loaded: url_helper
INFO - 2017-03-16 23:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 23:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 23:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 23:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:27:15 --> Final output sent to browser
DEBUG - 2017-03-16 23:27:15 --> Total execution time: 0.1119
INFO - 2017-03-16 23:27:16 --> Config Class Initialized
INFO - 2017-03-16 23:27:16 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:27:16 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:27:16 --> Utf8 Class Initialized
INFO - 2017-03-16 23:27:16 --> URI Class Initialized
INFO - 2017-03-16 23:27:16 --> Router Class Initialized
INFO - 2017-03-16 23:27:16 --> Output Class Initialized
INFO - 2017-03-16 23:27:16 --> Security Class Initialized
DEBUG - 2017-03-16 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:27:16 --> Input Class Initialized
INFO - 2017-03-16 23:27:16 --> Language Class Initialized
INFO - 2017-03-16 23:27:16 --> Loader Class Initialized
INFO - 2017-03-16 23:27:16 --> Database Driver Class Initialized
INFO - 2017-03-16 23:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:27:16 --> Controller Class Initialized
INFO - 2017-03-16 23:27:16 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:27:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:27:16 --> Final output sent to browser
DEBUG - 2017-03-16 23:27:16 --> Total execution time: 0.0205
INFO - 2017-03-16 23:27:21 --> Config Class Initialized
INFO - 2017-03-16 23:27:21 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:27:21 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:27:21 --> Utf8 Class Initialized
INFO - 2017-03-16 23:27:21 --> URI Class Initialized
INFO - 2017-03-16 23:27:21 --> Router Class Initialized
INFO - 2017-03-16 23:27:21 --> Output Class Initialized
INFO - 2017-03-16 23:27:21 --> Security Class Initialized
DEBUG - 2017-03-16 23:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:27:21 --> Input Class Initialized
INFO - 2017-03-16 23:27:21 --> Language Class Initialized
INFO - 2017-03-16 23:27:21 --> Loader Class Initialized
INFO - 2017-03-16 23:27:21 --> Database Driver Class Initialized
INFO - 2017-03-16 23:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:27:21 --> Controller Class Initialized
INFO - 2017-03-16 23:27:21 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:27:22 --> Config Class Initialized
INFO - 2017-03-16 23:27:22 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:27:22 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:27:22 --> Utf8 Class Initialized
INFO - 2017-03-16 23:27:22 --> URI Class Initialized
INFO - 2017-03-16 23:27:22 --> Router Class Initialized
INFO - 2017-03-16 23:27:22 --> Output Class Initialized
INFO - 2017-03-16 23:27:22 --> Security Class Initialized
DEBUG - 2017-03-16 23:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:27:22 --> Input Class Initialized
INFO - 2017-03-16 23:27:22 --> Language Class Initialized
INFO - 2017-03-16 23:27:22 --> Loader Class Initialized
INFO - 2017-03-16 23:27:22 --> Database Driver Class Initialized
INFO - 2017-03-16 23:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:27:22 --> Controller Class Initialized
INFO - 2017-03-16 23:27:22 --> Helper loaded: date_helper
DEBUG - 2017-03-16 23:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:27:22 --> Helper loaded: url_helper
INFO - 2017-03-16 23:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 23:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 23:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 23:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:27:22 --> Final output sent to browser
DEBUG - 2017-03-16 23:27:22 --> Total execution time: 0.0134
INFO - 2017-03-16 23:27:22 --> Config Class Initialized
INFO - 2017-03-16 23:27:22 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:27:22 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:27:22 --> Utf8 Class Initialized
INFO - 2017-03-16 23:27:22 --> URI Class Initialized
INFO - 2017-03-16 23:27:22 --> Router Class Initialized
INFO - 2017-03-16 23:27:22 --> Output Class Initialized
INFO - 2017-03-16 23:27:22 --> Security Class Initialized
DEBUG - 2017-03-16 23:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:27:22 --> Input Class Initialized
INFO - 2017-03-16 23:27:22 --> Language Class Initialized
INFO - 2017-03-16 23:27:22 --> Loader Class Initialized
INFO - 2017-03-16 23:27:22 --> Database Driver Class Initialized
INFO - 2017-03-16 23:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:27:22 --> Controller Class Initialized
INFO - 2017-03-16 23:27:22 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:27:23 --> Final output sent to browser
DEBUG - 2017-03-16 23:27:23 --> Total execution time: 0.0132
INFO - 2017-03-16 23:28:47 --> Config Class Initialized
INFO - 2017-03-16 23:28:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:28:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:28:47 --> Utf8 Class Initialized
INFO - 2017-03-16 23:28:47 --> URI Class Initialized
DEBUG - 2017-03-16 23:28:47 --> No URI present. Default controller set.
INFO - 2017-03-16 23:28:47 --> Router Class Initialized
INFO - 2017-03-16 23:28:47 --> Output Class Initialized
INFO - 2017-03-16 23:28:47 --> Security Class Initialized
DEBUG - 2017-03-16 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:28:47 --> Input Class Initialized
INFO - 2017-03-16 23:28:47 --> Language Class Initialized
INFO - 2017-03-16 23:28:47 --> Loader Class Initialized
INFO - 2017-03-16 23:28:48 --> Database Driver Class Initialized
INFO - 2017-03-16 23:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:28:48 --> Controller Class Initialized
INFO - 2017-03-16 23:28:48 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:28:48 --> Final output sent to browser
DEBUG - 2017-03-16 23:28:48 --> Total execution time: 1.5461
INFO - 2017-03-16 23:28:55 --> Config Class Initialized
INFO - 2017-03-16 23:28:55 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:28:55 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:28:55 --> Utf8 Class Initialized
INFO - 2017-03-16 23:28:55 --> URI Class Initialized
INFO - 2017-03-16 23:28:55 --> Router Class Initialized
INFO - 2017-03-16 23:28:55 --> Output Class Initialized
INFO - 2017-03-16 23:28:55 --> Security Class Initialized
DEBUG - 2017-03-16 23:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:28:55 --> Input Class Initialized
INFO - 2017-03-16 23:28:55 --> Language Class Initialized
INFO - 2017-03-16 23:28:55 --> Loader Class Initialized
INFO - 2017-03-16 23:28:55 --> Database Driver Class Initialized
INFO - 2017-03-16 23:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:28:55 --> Controller Class Initialized
INFO - 2017-03-16 23:28:55 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:28:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:28:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:28:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:28:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:28:55 --> Final output sent to browser
DEBUG - 2017-03-16 23:28:55 --> Total execution time: 0.7065
INFO - 2017-03-16 23:30:01 --> Config Class Initialized
INFO - 2017-03-16 23:30:01 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:01 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:01 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:01 --> URI Class Initialized
INFO - 2017-03-16 23:30:01 --> Router Class Initialized
INFO - 2017-03-16 23:30:01 --> Output Class Initialized
INFO - 2017-03-16 23:30:01 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:01 --> Input Class Initialized
INFO - 2017-03-16 23:30:01 --> Language Class Initialized
INFO - 2017-03-16 23:30:01 --> Loader Class Initialized
INFO - 2017-03-16 23:30:01 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:01 --> Controller Class Initialized
INFO - 2017-03-16 23:30:01 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 23:30:04 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 23:30:04 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Itzeel Trejo')
INFO - 2017-03-16 23:30:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 23:30:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 23:30:07 --> Config Class Initialized
INFO - 2017-03-16 23:30:07 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:07 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:07 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:07 --> URI Class Initialized
INFO - 2017-03-16 23:30:07 --> Router Class Initialized
INFO - 2017-03-16 23:30:07 --> Output Class Initialized
INFO - 2017-03-16 23:30:07 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:07 --> Input Class Initialized
INFO - 2017-03-16 23:30:07 --> Language Class Initialized
INFO - 2017-03-16 23:30:07 --> Loader Class Initialized
INFO - 2017-03-16 23:30:07 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:07 --> Controller Class Initialized
INFO - 2017-03-16 23:30:07 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:30:08 --> Final output sent to browser
DEBUG - 2017-03-16 23:30:08 --> Total execution time: 1.3193
INFO - 2017-03-16 23:30:13 --> Config Class Initialized
INFO - 2017-03-16 23:30:13 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:13 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:13 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:13 --> URI Class Initialized
INFO - 2017-03-16 23:30:13 --> Router Class Initialized
INFO - 2017-03-16 23:30:13 --> Output Class Initialized
INFO - 2017-03-16 23:30:13 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:13 --> Input Class Initialized
INFO - 2017-03-16 23:30:13 --> Language Class Initialized
INFO - 2017-03-16 23:30:13 --> Loader Class Initialized
INFO - 2017-03-16 23:30:14 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:14 --> Controller Class Initialized
INFO - 2017-03-16 23:30:14 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 23:30:15 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 23:30:15 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Itzeel Trejo')
INFO - 2017-03-16 23:30:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 23:30:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 23:30:15 --> Config Class Initialized
INFO - 2017-03-16 23:30:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:15 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:15 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:15 --> URI Class Initialized
INFO - 2017-03-16 23:30:15 --> Router Class Initialized
INFO - 2017-03-16 23:30:15 --> Output Class Initialized
INFO - 2017-03-16 23:30:15 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:15 --> Input Class Initialized
INFO - 2017-03-16 23:30:15 --> Language Class Initialized
INFO - 2017-03-16 23:30:15 --> Loader Class Initialized
INFO - 2017-03-16 23:30:15 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:15 --> Controller Class Initialized
INFO - 2017-03-16 23:30:15 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:30:15 --> Final output sent to browser
DEBUG - 2017-03-16 23:30:15 --> Total execution time: 0.1769
INFO - 2017-03-16 23:30:35 --> Config Class Initialized
INFO - 2017-03-16 23:30:35 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:35 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:35 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:35 --> URI Class Initialized
DEBUG - 2017-03-16 23:30:35 --> No URI present. Default controller set.
INFO - 2017-03-16 23:30:35 --> Router Class Initialized
INFO - 2017-03-16 23:30:35 --> Output Class Initialized
INFO - 2017-03-16 23:30:35 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:35 --> Input Class Initialized
INFO - 2017-03-16 23:30:35 --> Language Class Initialized
INFO - 2017-03-16 23:30:35 --> Loader Class Initialized
INFO - 2017-03-16 23:30:35 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:35 --> Controller Class Initialized
INFO - 2017-03-16 23:30:35 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:30:35 --> Final output sent to browser
DEBUG - 2017-03-16 23:30:35 --> Total execution time: 0.0138
INFO - 2017-03-16 23:30:37 --> Config Class Initialized
INFO - 2017-03-16 23:30:37 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:37 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:37 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:37 --> URI Class Initialized
INFO - 2017-03-16 23:30:37 --> Router Class Initialized
INFO - 2017-03-16 23:30:37 --> Output Class Initialized
INFO - 2017-03-16 23:30:37 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:37 --> Input Class Initialized
INFO - 2017-03-16 23:30:37 --> Language Class Initialized
INFO - 2017-03-16 23:30:37 --> Loader Class Initialized
INFO - 2017-03-16 23:30:37 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:37 --> Controller Class Initialized
INFO - 2017-03-16 23:30:37 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:30:37 --> Final output sent to browser
DEBUG - 2017-03-16 23:30:37 --> Total execution time: 0.0135
INFO - 2017-03-16 23:30:42 --> Config Class Initialized
INFO - 2017-03-16 23:30:42 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:42 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:42 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:42 --> URI Class Initialized
INFO - 2017-03-16 23:30:42 --> Router Class Initialized
INFO - 2017-03-16 23:30:42 --> Output Class Initialized
INFO - 2017-03-16 23:30:42 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:42 --> Input Class Initialized
INFO - 2017-03-16 23:30:42 --> Language Class Initialized
INFO - 2017-03-16 23:30:42 --> Loader Class Initialized
INFO - 2017-03-16 23:30:42 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:42 --> Controller Class Initialized
INFO - 2017-03-16 23:30:42 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 23:30:43 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 23:30:43 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Itzeel Trejo')
INFO - 2017-03-16 23:30:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 23:30:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 23:30:44 --> Config Class Initialized
INFO - 2017-03-16 23:30:44 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:44 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:44 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:44 --> URI Class Initialized
INFO - 2017-03-16 23:30:44 --> Router Class Initialized
INFO - 2017-03-16 23:30:44 --> Output Class Initialized
INFO - 2017-03-16 23:30:44 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:44 --> Input Class Initialized
INFO - 2017-03-16 23:30:44 --> Language Class Initialized
INFO - 2017-03-16 23:30:44 --> Loader Class Initialized
INFO - 2017-03-16 23:30:44 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:44 --> Controller Class Initialized
INFO - 2017-03-16 23:30:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:30:44 --> Final output sent to browser
DEBUG - 2017-03-16 23:30:44 --> Total execution time: 0.0143
INFO - 2017-03-16 23:30:49 --> Config Class Initialized
INFO - 2017-03-16 23:30:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:49 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:49 --> URI Class Initialized
DEBUG - 2017-03-16 23:30:49 --> No URI present. Default controller set.
INFO - 2017-03-16 23:30:49 --> Router Class Initialized
INFO - 2017-03-16 23:30:49 --> Output Class Initialized
INFO - 2017-03-16 23:30:49 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:50 --> Input Class Initialized
INFO - 2017-03-16 23:30:50 --> Language Class Initialized
INFO - 2017-03-16 23:30:50 --> Loader Class Initialized
INFO - 2017-03-16 23:30:50 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:50 --> Controller Class Initialized
INFO - 2017-03-16 23:30:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:30:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:30:50 --> Final output sent to browser
DEBUG - 2017-03-16 23:30:50 --> Total execution time: 0.6281
INFO - 2017-03-16 23:30:51 --> Config Class Initialized
INFO - 2017-03-16 23:30:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:30:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:30:51 --> Utf8 Class Initialized
INFO - 2017-03-16 23:30:51 --> URI Class Initialized
INFO - 2017-03-16 23:30:51 --> Router Class Initialized
INFO - 2017-03-16 23:30:51 --> Output Class Initialized
INFO - 2017-03-16 23:30:51 --> Security Class Initialized
DEBUG - 2017-03-16 23:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:30:51 --> Input Class Initialized
INFO - 2017-03-16 23:30:51 --> Language Class Initialized
INFO - 2017-03-16 23:30:51 --> Loader Class Initialized
INFO - 2017-03-16 23:30:51 --> Database Driver Class Initialized
INFO - 2017-03-16 23:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:30:51 --> Controller Class Initialized
INFO - 2017-03-16 23:30:51 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:30:51 --> Final output sent to browser
DEBUG - 2017-03-16 23:30:51 --> Total execution time: 0.0136
INFO - 2017-03-16 23:31:02 --> Config Class Initialized
INFO - 2017-03-16 23:31:02 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:31:02 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:31:02 --> Utf8 Class Initialized
INFO - 2017-03-16 23:31:02 --> URI Class Initialized
INFO - 2017-03-16 23:31:02 --> Router Class Initialized
INFO - 2017-03-16 23:31:02 --> Output Class Initialized
INFO - 2017-03-16 23:31:02 --> Security Class Initialized
DEBUG - 2017-03-16 23:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:31:02 --> Input Class Initialized
INFO - 2017-03-16 23:31:02 --> Language Class Initialized
INFO - 2017-03-16 23:31:02 --> Loader Class Initialized
INFO - 2017-03-16 23:31:03 --> Database Driver Class Initialized
INFO - 2017-03-16 23:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:31:03 --> Controller Class Initialized
INFO - 2017-03-16 23:31:03 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:31:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 23:31:05 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 23:31:05 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Itzeel Trejo')
INFO - 2017-03-16 23:31:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 23:31:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 23:31:05 --> Config Class Initialized
INFO - 2017-03-16 23:31:05 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:31:05 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:31:05 --> Utf8 Class Initialized
INFO - 2017-03-16 23:31:05 --> URI Class Initialized
INFO - 2017-03-16 23:31:05 --> Router Class Initialized
INFO - 2017-03-16 23:31:05 --> Output Class Initialized
INFO - 2017-03-16 23:31:05 --> Security Class Initialized
DEBUG - 2017-03-16 23:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:31:05 --> Input Class Initialized
INFO - 2017-03-16 23:31:05 --> Language Class Initialized
INFO - 2017-03-16 23:31:05 --> Loader Class Initialized
INFO - 2017-03-16 23:31:05 --> Database Driver Class Initialized
INFO - 2017-03-16 23:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:31:05 --> Controller Class Initialized
INFO - 2017-03-16 23:31:05 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:31:05 --> Final output sent to browser
DEBUG - 2017-03-16 23:31:05 --> Total execution time: 0.1664
INFO - 2017-03-16 23:36:49 --> Config Class Initialized
INFO - 2017-03-16 23:36:49 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:36:49 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:36:49 --> Utf8 Class Initialized
INFO - 2017-03-16 23:36:49 --> URI Class Initialized
DEBUG - 2017-03-16 23:36:49 --> No URI present. Default controller set.
INFO - 2017-03-16 23:36:49 --> Router Class Initialized
INFO - 2017-03-16 23:36:49 --> Output Class Initialized
INFO - 2017-03-16 23:36:49 --> Security Class Initialized
DEBUG - 2017-03-16 23:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:36:49 --> Input Class Initialized
INFO - 2017-03-16 23:36:49 --> Language Class Initialized
INFO - 2017-03-16 23:36:49 --> Loader Class Initialized
INFO - 2017-03-16 23:36:50 --> Database Driver Class Initialized
INFO - 2017-03-16 23:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:36:50 --> Controller Class Initialized
INFO - 2017-03-16 23:36:50 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:36:51 --> Final output sent to browser
DEBUG - 2017-03-16 23:36:51 --> Total execution time: 1.5241
INFO - 2017-03-16 23:36:54 --> Config Class Initialized
INFO - 2017-03-16 23:36:54 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:36:54 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:36:54 --> Utf8 Class Initialized
INFO - 2017-03-16 23:36:54 --> URI Class Initialized
INFO - 2017-03-16 23:36:54 --> Router Class Initialized
INFO - 2017-03-16 23:36:54 --> Output Class Initialized
INFO - 2017-03-16 23:36:54 --> Security Class Initialized
DEBUG - 2017-03-16 23:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:36:54 --> Input Class Initialized
INFO - 2017-03-16 23:36:54 --> Language Class Initialized
INFO - 2017-03-16 23:36:54 --> Loader Class Initialized
INFO - 2017-03-16 23:36:54 --> Database Driver Class Initialized
INFO - 2017-03-16 23:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:36:54 --> Controller Class Initialized
INFO - 2017-03-16 23:36:54 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:36:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:36:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:36:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:36:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:36:54 --> Final output sent to browser
DEBUG - 2017-03-16 23:36:54 --> Total execution time: 0.0135
INFO - 2017-03-16 23:37:12 --> Config Class Initialized
INFO - 2017-03-16 23:37:12 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:37:12 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:37:12 --> Utf8 Class Initialized
INFO - 2017-03-16 23:37:12 --> URI Class Initialized
INFO - 2017-03-16 23:37:12 --> Router Class Initialized
INFO - 2017-03-16 23:37:12 --> Output Class Initialized
INFO - 2017-03-16 23:37:12 --> Security Class Initialized
DEBUG - 2017-03-16 23:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:37:12 --> Input Class Initialized
INFO - 2017-03-16 23:37:12 --> Language Class Initialized
INFO - 2017-03-16 23:37:12 --> Loader Class Initialized
INFO - 2017-03-16 23:37:12 --> Database Driver Class Initialized
INFO - 2017-03-16 23:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:37:13 --> Controller Class Initialized
INFO - 2017-03-16 23:37:13 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:37:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 23:37:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 23:37:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Itzeel Trejo')
INFO - 2017-03-16 23:37:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 23:37:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 23:37:15 --> Config Class Initialized
INFO - 2017-03-16 23:37:15 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:37:15 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:37:15 --> Utf8 Class Initialized
INFO - 2017-03-16 23:37:15 --> URI Class Initialized
INFO - 2017-03-16 23:37:15 --> Router Class Initialized
INFO - 2017-03-16 23:37:15 --> Output Class Initialized
INFO - 2017-03-16 23:37:15 --> Security Class Initialized
DEBUG - 2017-03-16 23:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:37:15 --> Input Class Initialized
INFO - 2017-03-16 23:37:15 --> Language Class Initialized
INFO - 2017-03-16 23:37:16 --> Loader Class Initialized
INFO - 2017-03-16 23:37:16 --> Database Driver Class Initialized
INFO - 2017-03-16 23:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:37:16 --> Controller Class Initialized
INFO - 2017-03-16 23:37:16 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:37:16 --> Final output sent to browser
DEBUG - 2017-03-16 23:37:16 --> Total execution time: 1.2263
INFO - 2017-03-16 23:37:30 --> Config Class Initialized
INFO - 2017-03-16 23:37:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:37:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:37:30 --> Utf8 Class Initialized
INFO - 2017-03-16 23:37:30 --> URI Class Initialized
INFO - 2017-03-16 23:37:30 --> Router Class Initialized
INFO - 2017-03-16 23:37:30 --> Output Class Initialized
INFO - 2017-03-16 23:37:30 --> Security Class Initialized
DEBUG - 2017-03-16 23:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:37:30 --> Input Class Initialized
INFO - 2017-03-16 23:37:30 --> Language Class Initialized
INFO - 2017-03-16 23:37:30 --> Loader Class Initialized
INFO - 2017-03-16 23:37:30 --> Database Driver Class Initialized
INFO - 2017-03-16 23:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:37:30 --> Controller Class Initialized
INFO - 2017-03-16 23:37:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-16 23:37:31 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-16 23:37:31 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Itzeel Trejo')
INFO - 2017-03-16 23:37:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-16 23:37:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-16 23:37:31 --> Config Class Initialized
INFO - 2017-03-16 23:37:31 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:37:31 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:37:31 --> Utf8 Class Initialized
INFO - 2017-03-16 23:37:31 --> URI Class Initialized
INFO - 2017-03-16 23:37:31 --> Router Class Initialized
INFO - 2017-03-16 23:37:31 --> Output Class Initialized
INFO - 2017-03-16 23:37:31 --> Security Class Initialized
DEBUG - 2017-03-16 23:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:37:31 --> Input Class Initialized
INFO - 2017-03-16 23:37:31 --> Language Class Initialized
INFO - 2017-03-16 23:37:31 --> Loader Class Initialized
INFO - 2017-03-16 23:37:31 --> Database Driver Class Initialized
INFO - 2017-03-16 23:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:37:31 --> Controller Class Initialized
INFO - 2017-03-16 23:37:31 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:37:31 --> Final output sent to browser
DEBUG - 2017-03-16 23:37:31 --> Total execution time: 0.0141
INFO - 2017-03-16 23:45:26 --> Config Class Initialized
INFO - 2017-03-16 23:45:26 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:45:27 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:45:27 --> Utf8 Class Initialized
INFO - 2017-03-16 23:45:27 --> URI Class Initialized
INFO - 2017-03-16 23:45:27 --> Router Class Initialized
INFO - 2017-03-16 23:45:27 --> Output Class Initialized
INFO - 2017-03-16 23:45:27 --> Security Class Initialized
DEBUG - 2017-03-16 23:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:45:27 --> Input Class Initialized
INFO - 2017-03-16 23:45:27 --> Language Class Initialized
INFO - 2017-03-16 23:45:27 --> Loader Class Initialized
INFO - 2017-03-16 23:45:27 --> Database Driver Class Initialized
INFO - 2017-03-16 23:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:45:27 --> Controller Class Initialized
INFO - 2017-03-16 23:45:27 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:45:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:45:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:45:28 --> Final output sent to browser
DEBUG - 2017-03-16 23:45:28 --> Total execution time: 1.2127
INFO - 2017-03-16 23:45:51 --> Config Class Initialized
INFO - 2017-03-16 23:45:51 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:45:51 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:45:51 --> Utf8 Class Initialized
INFO - 2017-03-16 23:45:51 --> URI Class Initialized
DEBUG - 2017-03-16 23:45:51 --> No URI present. Default controller set.
INFO - 2017-03-16 23:45:51 --> Router Class Initialized
INFO - 2017-03-16 23:45:51 --> Output Class Initialized
INFO - 2017-03-16 23:45:51 --> Security Class Initialized
DEBUG - 2017-03-16 23:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:45:51 --> Input Class Initialized
INFO - 2017-03-16 23:45:51 --> Language Class Initialized
INFO - 2017-03-16 23:45:51 --> Loader Class Initialized
INFO - 2017-03-16 23:45:51 --> Database Driver Class Initialized
INFO - 2017-03-16 23:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:45:52 --> Controller Class Initialized
INFO - 2017-03-16 23:45:52 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:45:52 --> Final output sent to browser
DEBUG - 2017-03-16 23:45:52 --> Total execution time: 0.8125
INFO - 2017-03-16 23:46:33 --> Config Class Initialized
INFO - 2017-03-16 23:46:33 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:46:33 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:46:33 --> Utf8 Class Initialized
INFO - 2017-03-16 23:46:33 --> URI Class Initialized
INFO - 2017-03-16 23:46:34 --> Router Class Initialized
INFO - 2017-03-16 23:46:34 --> Output Class Initialized
INFO - 2017-03-16 23:46:34 --> Security Class Initialized
DEBUG - 2017-03-16 23:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:46:34 --> Input Class Initialized
INFO - 2017-03-16 23:46:34 --> Language Class Initialized
INFO - 2017-03-16 23:46:34 --> Loader Class Initialized
INFO - 2017-03-16 23:46:34 --> Database Driver Class Initialized
INFO - 2017-03-16 23:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:46:34 --> Controller Class Initialized
INFO - 2017-03-16 23:46:34 --> Helper loaded: date_helper
DEBUG - 2017-03-16 23:46:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:46:34 --> Helper loaded: url_helper
INFO - 2017-03-16 23:46:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:46:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-16 23:46:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-16 23:46:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-16 23:46:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:46:34 --> Final output sent to browser
DEBUG - 2017-03-16 23:46:34 --> Total execution time: 1.0928
INFO - 2017-03-16 23:46:47 --> Config Class Initialized
INFO - 2017-03-16 23:46:47 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:46:47 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:46:47 --> Utf8 Class Initialized
INFO - 2017-03-16 23:46:47 --> URI Class Initialized
INFO - 2017-03-16 23:46:47 --> Router Class Initialized
INFO - 2017-03-16 23:46:47 --> Output Class Initialized
INFO - 2017-03-16 23:46:47 --> Security Class Initialized
DEBUG - 2017-03-16 23:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:46:47 --> Input Class Initialized
INFO - 2017-03-16 23:46:47 --> Language Class Initialized
INFO - 2017-03-16 23:46:47 --> Loader Class Initialized
INFO - 2017-03-16 23:46:47 --> Database Driver Class Initialized
INFO - 2017-03-16 23:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:46:47 --> Controller Class Initialized
INFO - 2017-03-16 23:46:47 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:46:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:46:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:46:48 --> Final output sent to browser
DEBUG - 2017-03-16 23:46:48 --> Total execution time: 0.2585
INFO - 2017-03-16 23:54:30 --> Config Class Initialized
INFO - 2017-03-16 23:54:30 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:54:30 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:54:30 --> Utf8 Class Initialized
INFO - 2017-03-16 23:54:30 --> URI Class Initialized
DEBUG - 2017-03-16 23:54:30 --> No URI present. Default controller set.
INFO - 2017-03-16 23:54:30 --> Router Class Initialized
INFO - 2017-03-16 23:54:30 --> Output Class Initialized
INFO - 2017-03-16 23:54:30 --> Security Class Initialized
DEBUG - 2017-03-16 23:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:54:30 --> Input Class Initialized
INFO - 2017-03-16 23:54:30 --> Language Class Initialized
INFO - 2017-03-16 23:54:30 --> Loader Class Initialized
INFO - 2017-03-16 23:54:30 --> Database Driver Class Initialized
INFO - 2017-03-16 23:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:54:30 --> Controller Class Initialized
INFO - 2017-03-16 23:54:30 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:54:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:54:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:54:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:54:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:54:31 --> Final output sent to browser
DEBUG - 2017-03-16 23:54:31 --> Total execution time: 1.2178
INFO - 2017-03-16 23:54:43 --> Config Class Initialized
INFO - 2017-03-16 23:54:43 --> Hooks Class Initialized
DEBUG - 2017-03-16 23:54:43 --> UTF-8 Support Enabled
INFO - 2017-03-16 23:54:43 --> Utf8 Class Initialized
INFO - 2017-03-16 23:54:43 --> URI Class Initialized
INFO - 2017-03-16 23:54:43 --> Router Class Initialized
INFO - 2017-03-16 23:54:44 --> Output Class Initialized
INFO - 2017-03-16 23:54:44 --> Security Class Initialized
DEBUG - 2017-03-16 23:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-16 23:54:44 --> Input Class Initialized
INFO - 2017-03-16 23:54:44 --> Language Class Initialized
INFO - 2017-03-16 23:54:44 --> Loader Class Initialized
INFO - 2017-03-16 23:54:44 --> Database Driver Class Initialized
INFO - 2017-03-16 23:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-16 23:54:44 --> Controller Class Initialized
INFO - 2017-03-16 23:54:44 --> Helper loaded: url_helper
DEBUG - 2017-03-16 23:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-16 23:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-16 23:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-16 23:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-16 23:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-16 23:54:44 --> Final output sent to browser
DEBUG - 2017-03-16 23:54:44 --> Total execution time: 1.2292

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-21 01:17:51 --> Config Class Initialized
INFO - 2017-01-21 01:17:51 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:17:51 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:17:51 --> Utf8 Class Initialized
INFO - 2017-01-21 01:17:51 --> URI Class Initialized
INFO - 2017-01-21 01:17:51 --> Router Class Initialized
INFO - 2017-01-21 01:17:51 --> Output Class Initialized
INFO - 2017-01-21 01:17:51 --> Security Class Initialized
DEBUG - 2017-01-21 01:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:17:51 --> Input Class Initialized
INFO - 2017-01-21 01:17:51 --> Language Class Initialized
INFO - 2017-01-21 01:17:51 --> Loader Class Initialized
INFO - 2017-01-21 01:17:51 --> Database Driver Class Initialized
INFO - 2017-01-21 01:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:17:51 --> Controller Class Initialized
INFO - 2017-01-21 01:17:51 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:17:51 --> Final output sent to browser
DEBUG - 2017-01-21 01:17:51 --> Total execution time: 0.1771
INFO - 2017-01-21 01:17:51 --> Config Class Initialized
INFO - 2017-01-21 01:17:51 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:17:51 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:17:51 --> Utf8 Class Initialized
INFO - 2017-01-21 01:17:51 --> URI Class Initialized
INFO - 2017-01-21 01:17:51 --> Router Class Initialized
INFO - 2017-01-21 01:17:51 --> Output Class Initialized
INFO - 2017-01-21 01:17:51 --> Security Class Initialized
DEBUG - 2017-01-21 01:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:17:51 --> Input Class Initialized
INFO - 2017-01-21 01:17:51 --> Language Class Initialized
INFO - 2017-01-21 01:17:51 --> Loader Class Initialized
INFO - 2017-01-21 01:17:51 --> Database Driver Class Initialized
INFO - 2017-01-21 01:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:17:51 --> Controller Class Initialized
INFO - 2017-01-21 01:17:51 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:17:51 --> Final output sent to browser
DEBUG - 2017-01-21 01:17:51 --> Total execution time: 0.0157
INFO - 2017-01-21 01:40:10 --> Config Class Initialized
INFO - 2017-01-21 01:40:10 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:40:10 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:40:10 --> Utf8 Class Initialized
INFO - 2017-01-21 01:40:10 --> URI Class Initialized
DEBUG - 2017-01-21 01:40:10 --> No URI present. Default controller set.
INFO - 2017-01-21 01:40:10 --> Router Class Initialized
INFO - 2017-01-21 01:40:10 --> Output Class Initialized
INFO - 2017-01-21 01:40:10 --> Security Class Initialized
DEBUG - 2017-01-21 01:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:40:10 --> Input Class Initialized
INFO - 2017-01-21 01:40:10 --> Language Class Initialized
INFO - 2017-01-21 01:40:10 --> Loader Class Initialized
INFO - 2017-01-21 01:40:10 --> Database Driver Class Initialized
INFO - 2017-01-21 01:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:40:10 --> Controller Class Initialized
INFO - 2017-01-21 01:40:10 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:40:10 --> Final output sent to browser
DEBUG - 2017-01-21 01:40:10 --> Total execution time: 0.0674
INFO - 2017-01-21 01:43:56 --> Config Class Initialized
INFO - 2017-01-21 01:43:56 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:43:56 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:43:56 --> Utf8 Class Initialized
INFO - 2017-01-21 01:43:56 --> URI Class Initialized
DEBUG - 2017-01-21 01:43:56 --> No URI present. Default controller set.
INFO - 2017-01-21 01:43:56 --> Router Class Initialized
INFO - 2017-01-21 01:43:56 --> Output Class Initialized
INFO - 2017-01-21 01:43:56 --> Security Class Initialized
DEBUG - 2017-01-21 01:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:43:56 --> Input Class Initialized
INFO - 2017-01-21 01:43:56 --> Language Class Initialized
INFO - 2017-01-21 01:43:56 --> Loader Class Initialized
INFO - 2017-01-21 01:43:56 --> Database Driver Class Initialized
INFO - 2017-01-21 01:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:43:56 --> Controller Class Initialized
INFO - 2017-01-21 01:43:56 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:43:56 --> Final output sent to browser
DEBUG - 2017-01-21 01:43:56 --> Total execution time: 0.0135
INFO - 2017-01-21 01:44:46 --> Config Class Initialized
INFO - 2017-01-21 01:44:46 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:44:46 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:44:46 --> Utf8 Class Initialized
INFO - 2017-01-21 01:44:46 --> URI Class Initialized
DEBUG - 2017-01-21 01:44:46 --> No URI present. Default controller set.
INFO - 2017-01-21 01:44:46 --> Router Class Initialized
INFO - 2017-01-21 01:44:46 --> Output Class Initialized
INFO - 2017-01-21 01:44:46 --> Security Class Initialized
DEBUG - 2017-01-21 01:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:44:46 --> Input Class Initialized
INFO - 2017-01-21 01:44:46 --> Language Class Initialized
INFO - 2017-01-21 01:44:46 --> Loader Class Initialized
INFO - 2017-01-21 01:44:46 --> Database Driver Class Initialized
INFO - 2017-01-21 01:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:44:46 --> Controller Class Initialized
INFO - 2017-01-21 01:44:46 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:44:46 --> Final output sent to browser
DEBUG - 2017-01-21 01:44:46 --> Total execution time: 0.0167
INFO - 2017-01-21 01:54:38 --> Config Class Initialized
INFO - 2017-01-21 01:54:38 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:54:38 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:54:38 --> Utf8 Class Initialized
INFO - 2017-01-21 01:54:38 --> URI Class Initialized
DEBUG - 2017-01-21 01:54:38 --> No URI present. Default controller set.
INFO - 2017-01-21 01:54:38 --> Router Class Initialized
INFO - 2017-01-21 01:54:38 --> Output Class Initialized
INFO - 2017-01-21 01:54:38 --> Security Class Initialized
DEBUG - 2017-01-21 01:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:54:38 --> Input Class Initialized
INFO - 2017-01-21 01:54:38 --> Language Class Initialized
INFO - 2017-01-21 01:54:38 --> Loader Class Initialized
INFO - 2017-01-21 01:54:38 --> Database Driver Class Initialized
INFO - 2017-01-21 01:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:54:38 --> Controller Class Initialized
INFO - 2017-01-21 01:54:38 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:54:38 --> Final output sent to browser
DEBUG - 2017-01-21 01:54:38 --> Total execution time: 0.0137
INFO - 2017-01-21 01:58:46 --> Config Class Initialized
INFO - 2017-01-21 01:58:46 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:58:46 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:58:46 --> Utf8 Class Initialized
INFO - 2017-01-21 01:58:46 --> URI Class Initialized
INFO - 2017-01-21 01:58:46 --> Router Class Initialized
INFO - 2017-01-21 01:58:46 --> Output Class Initialized
INFO - 2017-01-21 01:58:46 --> Security Class Initialized
DEBUG - 2017-01-21 01:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:58:46 --> Input Class Initialized
INFO - 2017-01-21 01:58:46 --> Language Class Initialized
INFO - 2017-01-21 01:58:46 --> Loader Class Initialized
INFO - 2017-01-21 01:58:46 --> Database Driver Class Initialized
INFO - 2017-01-21 01:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:58:46 --> Controller Class Initialized
INFO - 2017-01-21 01:58:46 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:58:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:58:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:58:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:58:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:58:46 --> Final output sent to browser
DEBUG - 2017-01-21 01:58:46 --> Total execution time: 0.1285
INFO - 2017-01-21 01:59:26 --> Config Class Initialized
INFO - 2017-01-21 01:59:26 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:59:26 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:59:26 --> Utf8 Class Initialized
INFO - 2017-01-21 01:59:26 --> URI Class Initialized
INFO - 2017-01-21 01:59:26 --> Router Class Initialized
INFO - 2017-01-21 01:59:26 --> Output Class Initialized
INFO - 2017-01-21 01:59:26 --> Security Class Initialized
DEBUG - 2017-01-21 01:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:59:26 --> Input Class Initialized
INFO - 2017-01-21 01:59:26 --> Language Class Initialized
INFO - 2017-01-21 01:59:26 --> Loader Class Initialized
INFO - 2017-01-21 01:59:26 --> Database Driver Class Initialized
INFO - 2017-01-21 01:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:59:26 --> Controller Class Initialized
INFO - 2017-01-21 01:59:26 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:59:26 --> Config Class Initialized
INFO - 2017-01-21 01:59:26 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:59:26 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:59:26 --> Utf8 Class Initialized
INFO - 2017-01-21 01:59:26 --> URI Class Initialized
INFO - 2017-01-21 01:59:26 --> Router Class Initialized
INFO - 2017-01-21 01:59:26 --> Output Class Initialized
INFO - 2017-01-21 01:59:26 --> Security Class Initialized
DEBUG - 2017-01-21 01:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:59:26 --> Input Class Initialized
INFO - 2017-01-21 01:59:26 --> Language Class Initialized
INFO - 2017-01-21 01:59:26 --> Loader Class Initialized
INFO - 2017-01-21 01:59:26 --> Database Driver Class Initialized
INFO - 2017-01-21 01:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:59:26 --> Controller Class Initialized
INFO - 2017-01-21 01:59:26 --> Helper loaded: date_helper
DEBUG - 2017-01-21 01:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:59:26 --> Helper loaded: url_helper
INFO - 2017-01-21 01:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-21 01:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-21 01:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 01:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:59:26 --> Final output sent to browser
DEBUG - 2017-01-21 01:59:26 --> Total execution time: 0.0480
INFO - 2017-01-21 01:59:27 --> Config Class Initialized
INFO - 2017-01-21 01:59:27 --> Hooks Class Initialized
DEBUG - 2017-01-21 01:59:27 --> UTF-8 Support Enabled
INFO - 2017-01-21 01:59:27 --> Utf8 Class Initialized
INFO - 2017-01-21 01:59:27 --> URI Class Initialized
INFO - 2017-01-21 01:59:27 --> Router Class Initialized
INFO - 2017-01-21 01:59:27 --> Output Class Initialized
INFO - 2017-01-21 01:59:27 --> Security Class Initialized
DEBUG - 2017-01-21 01:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 01:59:27 --> Input Class Initialized
INFO - 2017-01-21 01:59:27 --> Language Class Initialized
INFO - 2017-01-21 01:59:27 --> Loader Class Initialized
INFO - 2017-01-21 01:59:27 --> Database Driver Class Initialized
INFO - 2017-01-21 01:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 01:59:27 --> Controller Class Initialized
INFO - 2017-01-21 01:59:27 --> Helper loaded: url_helper
DEBUG - 2017-01-21 01:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 01:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 01:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 01:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 01:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 01:59:27 --> Final output sent to browser
DEBUG - 2017-01-21 01:59:27 --> Total execution time: 0.0142
INFO - 2017-01-21 02:01:42 --> Config Class Initialized
INFO - 2017-01-21 02:01:42 --> Hooks Class Initialized
DEBUG - 2017-01-21 02:01:42 --> UTF-8 Support Enabled
INFO - 2017-01-21 02:01:42 --> Utf8 Class Initialized
INFO - 2017-01-21 02:01:42 --> URI Class Initialized
DEBUG - 2017-01-21 02:01:42 --> No URI present. Default controller set.
INFO - 2017-01-21 02:01:42 --> Router Class Initialized
INFO - 2017-01-21 02:01:42 --> Output Class Initialized
INFO - 2017-01-21 02:01:42 --> Security Class Initialized
DEBUG - 2017-01-21 02:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 02:01:42 --> Input Class Initialized
INFO - 2017-01-21 02:01:42 --> Language Class Initialized
INFO - 2017-01-21 02:01:42 --> Loader Class Initialized
INFO - 2017-01-21 02:01:42 --> Database Driver Class Initialized
INFO - 2017-01-21 02:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 02:01:42 --> Controller Class Initialized
INFO - 2017-01-21 02:01:42 --> Helper loaded: url_helper
DEBUG - 2017-01-21 02:01:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 02:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 02:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 02:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 02:01:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 02:01:42 --> Final output sent to browser
DEBUG - 2017-01-21 02:01:42 --> Total execution time: 0.0131
INFO - 2017-01-21 03:55:14 --> Config Class Initialized
INFO - 2017-01-21 03:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:14 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:14 --> URI Class Initialized
INFO - 2017-01-21 03:55:14 --> Router Class Initialized
INFO - 2017-01-21 03:55:14 --> Output Class Initialized
INFO - 2017-01-21 03:55:14 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:14 --> Input Class Initialized
INFO - 2017-01-21 03:55:14 --> Language Class Initialized
INFO - 2017-01-21 03:55:14 --> Loader Class Initialized
INFO - 2017-01-21 03:55:14 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:14 --> Controller Class Initialized
INFO - 2017-01-21 03:55:14 --> Helper loaded: date_helper
DEBUG - 2017-01-21 03:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:14 --> Helper loaded: url_helper
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:14 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:14 --> Total execution time: 0.0224
INFO - 2017-01-21 03:55:14 --> Config Class Initialized
INFO - 2017-01-21 03:55:14 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:14 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:14 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:14 --> URI Class Initialized
INFO - 2017-01-21 03:55:14 --> Router Class Initialized
INFO - 2017-01-21 03:55:14 --> Output Class Initialized
INFO - 2017-01-21 03:55:14 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:14 --> Input Class Initialized
INFO - 2017-01-21 03:55:14 --> Language Class Initialized
INFO - 2017-01-21 03:55:14 --> Loader Class Initialized
INFO - 2017-01-21 03:55:14 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:14 --> Controller Class Initialized
INFO - 2017-01-21 03:55:14 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:14 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:14 --> Total execution time: 0.0431
INFO - 2017-01-21 03:55:15 --> Config Class Initialized
INFO - 2017-01-21 03:55:15 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:15 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:15 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:15 --> URI Class Initialized
INFO - 2017-01-21 03:55:15 --> Router Class Initialized
INFO - 2017-01-21 03:55:15 --> Output Class Initialized
INFO - 2017-01-21 03:55:15 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:15 --> Input Class Initialized
INFO - 2017-01-21 03:55:15 --> Language Class Initialized
INFO - 2017-01-21 03:55:15 --> Loader Class Initialized
INFO - 2017-01-21 03:55:15 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:15 --> Controller Class Initialized
INFO - 2017-01-21 03:55:15 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:15 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:15 --> Total execution time: 0.0164
INFO - 2017-01-21 03:55:15 --> Config Class Initialized
INFO - 2017-01-21 03:55:15 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:15 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:15 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:15 --> URI Class Initialized
INFO - 2017-01-21 03:55:15 --> Router Class Initialized
INFO - 2017-01-21 03:55:15 --> Output Class Initialized
INFO - 2017-01-21 03:55:15 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:15 --> Input Class Initialized
INFO - 2017-01-21 03:55:15 --> Language Class Initialized
INFO - 2017-01-21 03:55:15 --> Loader Class Initialized
INFO - 2017-01-21 03:55:15 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:15 --> Controller Class Initialized
INFO - 2017-01-21 03:55:15 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:15 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:15 --> Total execution time: 0.0143
INFO - 2017-01-21 03:55:17 --> Config Class Initialized
INFO - 2017-01-21 03:55:17 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:17 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:17 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:17 --> URI Class Initialized
INFO - 2017-01-21 03:55:17 --> Router Class Initialized
INFO - 2017-01-21 03:55:17 --> Output Class Initialized
INFO - 2017-01-21 03:55:17 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:17 --> Input Class Initialized
INFO - 2017-01-21 03:55:17 --> Language Class Initialized
INFO - 2017-01-21 03:55:17 --> Loader Class Initialized
INFO - 2017-01-21 03:55:17 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:17 --> Controller Class Initialized
INFO - 2017-01-21 03:55:17 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:17 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:17 --> Total execution time: 0.0148
INFO - 2017-01-21 03:55:17 --> Config Class Initialized
INFO - 2017-01-21 03:55:17 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:17 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:17 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:17 --> URI Class Initialized
INFO - 2017-01-21 03:55:17 --> Router Class Initialized
INFO - 2017-01-21 03:55:17 --> Output Class Initialized
INFO - 2017-01-21 03:55:17 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:17 --> Input Class Initialized
INFO - 2017-01-21 03:55:17 --> Language Class Initialized
INFO - 2017-01-21 03:55:17 --> Loader Class Initialized
INFO - 2017-01-21 03:55:17 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:17 --> Controller Class Initialized
INFO - 2017-01-21 03:55:17 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:17 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:17 --> Total execution time: 0.0622
INFO - 2017-01-21 03:55:18 --> Config Class Initialized
INFO - 2017-01-21 03:55:18 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:18 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:18 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:18 --> URI Class Initialized
INFO - 2017-01-21 03:55:18 --> Router Class Initialized
INFO - 2017-01-21 03:55:18 --> Output Class Initialized
INFO - 2017-01-21 03:55:18 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:18 --> Input Class Initialized
INFO - 2017-01-21 03:55:18 --> Language Class Initialized
INFO - 2017-01-21 03:55:18 --> Loader Class Initialized
INFO - 2017-01-21 03:55:18 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:18 --> Controller Class Initialized
INFO - 2017-01-21 03:55:18 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:18 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:18 --> Total execution time: 0.0162
INFO - 2017-01-21 03:55:18 --> Config Class Initialized
INFO - 2017-01-21 03:55:18 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:18 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:18 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:18 --> URI Class Initialized
INFO - 2017-01-21 03:55:18 --> Router Class Initialized
INFO - 2017-01-21 03:55:18 --> Output Class Initialized
INFO - 2017-01-21 03:55:18 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:18 --> Input Class Initialized
INFO - 2017-01-21 03:55:18 --> Language Class Initialized
INFO - 2017-01-21 03:55:18 --> Loader Class Initialized
INFO - 2017-01-21 03:55:18 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:18 --> Controller Class Initialized
INFO - 2017-01-21 03:55:18 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:18 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:18 --> Total execution time: 0.0132
INFO - 2017-01-21 03:55:18 --> Config Class Initialized
INFO - 2017-01-21 03:55:18 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:18 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:18 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:18 --> URI Class Initialized
INFO - 2017-01-21 03:55:18 --> Router Class Initialized
INFO - 2017-01-21 03:55:18 --> Output Class Initialized
INFO - 2017-01-21 03:55:18 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:18 --> Input Class Initialized
INFO - 2017-01-21 03:55:18 --> Language Class Initialized
INFO - 2017-01-21 03:55:18 --> Loader Class Initialized
INFO - 2017-01-21 03:55:18 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:18 --> Controller Class Initialized
INFO - 2017-01-21 03:55:18 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:18 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:18 --> Total execution time: 0.0136
INFO - 2017-01-21 03:55:19 --> Config Class Initialized
INFO - 2017-01-21 03:55:19 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:19 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:19 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:19 --> URI Class Initialized
INFO - 2017-01-21 03:55:19 --> Router Class Initialized
INFO - 2017-01-21 03:55:19 --> Output Class Initialized
INFO - 2017-01-21 03:55:19 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:19 --> Input Class Initialized
INFO - 2017-01-21 03:55:19 --> Language Class Initialized
INFO - 2017-01-21 03:55:19 --> Loader Class Initialized
INFO - 2017-01-21 03:55:19 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:19 --> Controller Class Initialized
INFO - 2017-01-21 03:55:19 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:19 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:19 --> Total execution time: 0.0220
INFO - 2017-01-21 03:55:19 --> Config Class Initialized
INFO - 2017-01-21 03:55:19 --> Hooks Class Initialized
DEBUG - 2017-01-21 03:55:19 --> UTF-8 Support Enabled
INFO - 2017-01-21 03:55:19 --> Utf8 Class Initialized
INFO - 2017-01-21 03:55:19 --> URI Class Initialized
INFO - 2017-01-21 03:55:19 --> Router Class Initialized
INFO - 2017-01-21 03:55:19 --> Output Class Initialized
INFO - 2017-01-21 03:55:19 --> Security Class Initialized
DEBUG - 2017-01-21 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 03:55:19 --> Input Class Initialized
INFO - 2017-01-21 03:55:19 --> Language Class Initialized
INFO - 2017-01-21 03:55:19 --> Loader Class Initialized
INFO - 2017-01-21 03:55:19 --> Database Driver Class Initialized
INFO - 2017-01-21 03:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 03:55:19 --> Controller Class Initialized
INFO - 2017-01-21 03:55:19 --> Helper loaded: url_helper
DEBUG - 2017-01-21 03:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 03:55:19 --> Final output sent to browser
DEBUG - 2017-01-21 03:55:19 --> Total execution time: 0.0265
INFO - 2017-01-21 06:05:15 --> Config Class Initialized
INFO - 2017-01-21 06:05:15 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:05:15 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:05:15 --> Utf8 Class Initialized
INFO - 2017-01-21 06:05:15 --> URI Class Initialized
DEBUG - 2017-01-21 06:05:15 --> No URI present. Default controller set.
INFO - 2017-01-21 06:05:15 --> Router Class Initialized
INFO - 2017-01-21 06:05:15 --> Output Class Initialized
INFO - 2017-01-21 06:05:15 --> Security Class Initialized
DEBUG - 2017-01-21 06:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:05:15 --> Input Class Initialized
INFO - 2017-01-21 06:05:15 --> Language Class Initialized
INFO - 2017-01-21 06:05:15 --> Loader Class Initialized
INFO - 2017-01-21 06:05:15 --> Database Driver Class Initialized
INFO - 2017-01-21 06:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:05:15 --> Controller Class Initialized
INFO - 2017-01-21 06:05:15 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:05:15 --> Final output sent to browser
DEBUG - 2017-01-21 06:05:15 --> Total execution time: 0.0239
INFO - 2017-01-21 06:05:15 --> Config Class Initialized
INFO - 2017-01-21 06:05:15 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:05:15 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:05:15 --> Utf8 Class Initialized
INFO - 2017-01-21 06:05:15 --> URI Class Initialized
INFO - 2017-01-21 06:05:15 --> Router Class Initialized
INFO - 2017-01-21 06:05:15 --> Output Class Initialized
INFO - 2017-01-21 06:05:15 --> Security Class Initialized
DEBUG - 2017-01-21 06:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:05:15 --> Input Class Initialized
INFO - 2017-01-21 06:05:15 --> Language Class Initialized
INFO - 2017-01-21 06:05:15 --> Loader Class Initialized
INFO - 2017-01-21 06:05:15 --> Database Driver Class Initialized
INFO - 2017-01-21 06:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:05:15 --> Controller Class Initialized
INFO - 2017-01-21 06:05:15 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-21 06:05:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-21 06:05:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-21 06:05:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:05:15 --> Final output sent to browser
DEBUG - 2017-01-21 06:05:15 --> Total execution time: 0.0408
INFO - 2017-01-21 06:05:15 --> Config Class Initialized
INFO - 2017-01-21 06:05:15 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:05:15 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:05:15 --> Utf8 Class Initialized
INFO - 2017-01-21 06:05:15 --> URI Class Initialized
INFO - 2017-01-21 06:05:15 --> Router Class Initialized
INFO - 2017-01-21 06:05:15 --> Output Class Initialized
INFO - 2017-01-21 06:05:15 --> Security Class Initialized
DEBUG - 2017-01-21 06:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:05:15 --> Input Class Initialized
INFO - 2017-01-21 06:05:15 --> Language Class Initialized
INFO - 2017-01-21 06:05:15 --> Loader Class Initialized
INFO - 2017-01-21 06:05:15 --> Database Driver Class Initialized
INFO - 2017-01-21 06:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:05:15 --> Controller Class Initialized
INFO - 2017-01-21 06:05:15 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-21 06:05:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-21 06:05:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-21 06:05:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:05:15 --> Final output sent to browser
DEBUG - 2017-01-21 06:05:15 --> Total execution time: 0.0143
INFO - 2017-01-21 06:05:21 --> Config Class Initialized
INFO - 2017-01-21 06:05:21 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:05:21 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:05:21 --> Utf8 Class Initialized
INFO - 2017-01-21 06:05:21 --> URI Class Initialized
INFO - 2017-01-21 06:05:21 --> Router Class Initialized
INFO - 2017-01-21 06:05:21 --> Output Class Initialized
INFO - 2017-01-21 06:05:21 --> Security Class Initialized
DEBUG - 2017-01-21 06:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:05:21 --> Input Class Initialized
INFO - 2017-01-21 06:05:21 --> Language Class Initialized
INFO - 2017-01-21 06:05:21 --> Loader Class Initialized
INFO - 2017-01-21 06:05:21 --> Database Driver Class Initialized
INFO - 2017-01-21 06:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:05:21 --> Controller Class Initialized
INFO - 2017-01-21 06:05:21 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:05:21 --> Final output sent to browser
DEBUG - 2017-01-21 06:05:21 --> Total execution time: 0.0139
INFO - 2017-01-21 06:05:21 --> Config Class Initialized
INFO - 2017-01-21 06:05:21 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:05:21 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:05:21 --> Utf8 Class Initialized
INFO - 2017-01-21 06:05:21 --> URI Class Initialized
INFO - 2017-01-21 06:05:21 --> Router Class Initialized
INFO - 2017-01-21 06:05:21 --> Output Class Initialized
INFO - 2017-01-21 06:05:21 --> Security Class Initialized
DEBUG - 2017-01-21 06:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:05:21 --> Input Class Initialized
INFO - 2017-01-21 06:05:21 --> Language Class Initialized
INFO - 2017-01-21 06:05:21 --> Loader Class Initialized
INFO - 2017-01-21 06:05:21 --> Database Driver Class Initialized
INFO - 2017-01-21 06:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:05:21 --> Controller Class Initialized
INFO - 2017-01-21 06:05:21 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:05:21 --> Final output sent to browser
DEBUG - 2017-01-21 06:05:21 --> Total execution time: 0.0149
INFO - 2017-01-21 06:05:21 --> Config Class Initialized
INFO - 2017-01-21 06:05:21 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:05:21 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:05:21 --> Utf8 Class Initialized
INFO - 2017-01-21 06:05:21 --> URI Class Initialized
INFO - 2017-01-21 06:05:21 --> Router Class Initialized
INFO - 2017-01-21 06:05:21 --> Output Class Initialized
INFO - 2017-01-21 06:05:21 --> Security Class Initialized
DEBUG - 2017-01-21 06:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:05:21 --> Input Class Initialized
INFO - 2017-01-21 06:05:21 --> Language Class Initialized
INFO - 2017-01-21 06:05:21 --> Loader Class Initialized
INFO - 2017-01-21 06:05:21 --> Database Driver Class Initialized
INFO - 2017-01-21 06:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:05:21 --> Controller Class Initialized
INFO - 2017-01-21 06:05:21 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:05:21 --> Final output sent to browser
DEBUG - 2017-01-21 06:05:21 --> Total execution time: 0.0142
INFO - 2017-01-21 06:28:27 --> Config Class Initialized
INFO - 2017-01-21 06:28:27 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:28:27 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:28:27 --> Utf8 Class Initialized
INFO - 2017-01-21 06:28:27 --> URI Class Initialized
DEBUG - 2017-01-21 06:28:27 --> No URI present. Default controller set.
INFO - 2017-01-21 06:28:27 --> Router Class Initialized
INFO - 2017-01-21 06:28:27 --> Output Class Initialized
INFO - 2017-01-21 06:28:27 --> Security Class Initialized
DEBUG - 2017-01-21 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:28:27 --> Input Class Initialized
INFO - 2017-01-21 06:28:27 --> Language Class Initialized
INFO - 2017-01-21 06:28:27 --> Loader Class Initialized
INFO - 2017-01-21 06:28:27 --> Database Driver Class Initialized
INFO - 2017-01-21 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:28:27 --> Controller Class Initialized
INFO - 2017-01-21 06:28:27 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:28:27 --> Final output sent to browser
DEBUG - 2017-01-21 06:28:27 --> Total execution time: 0.0131
INFO - 2017-01-21 06:28:31 --> Config Class Initialized
INFO - 2017-01-21 06:28:31 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:28:31 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:28:31 --> Utf8 Class Initialized
INFO - 2017-01-21 06:28:31 --> URI Class Initialized
INFO - 2017-01-21 06:28:31 --> Router Class Initialized
INFO - 2017-01-21 06:28:31 --> Output Class Initialized
INFO - 2017-01-21 06:28:31 --> Security Class Initialized
DEBUG - 2017-01-21 06:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:28:31 --> Input Class Initialized
INFO - 2017-01-21 06:28:31 --> Language Class Initialized
INFO - 2017-01-21 06:28:31 --> Loader Class Initialized
INFO - 2017-01-21 06:28:31 --> Database Driver Class Initialized
INFO - 2017-01-21 06:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:28:31 --> Controller Class Initialized
INFO - 2017-01-21 06:28:31 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:28:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:28:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:28:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:28:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:28:31 --> Final output sent to browser
DEBUG - 2017-01-21 06:28:31 --> Total execution time: 0.0132
INFO - 2017-01-21 06:29:51 --> Config Class Initialized
INFO - 2017-01-21 06:29:51 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:29:51 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:29:51 --> Utf8 Class Initialized
INFO - 2017-01-21 06:29:51 --> URI Class Initialized
INFO - 2017-01-21 06:29:51 --> Router Class Initialized
INFO - 2017-01-21 06:29:51 --> Output Class Initialized
INFO - 2017-01-21 06:29:51 --> Security Class Initialized
DEBUG - 2017-01-21 06:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:29:51 --> Input Class Initialized
INFO - 2017-01-21 06:29:51 --> Language Class Initialized
INFO - 2017-01-21 06:29:51 --> Loader Class Initialized
INFO - 2017-01-21 06:29:51 --> Database Driver Class Initialized
INFO - 2017-01-21 06:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:29:51 --> Controller Class Initialized
INFO - 2017-01-21 06:29:51 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:29:52 --> Config Class Initialized
INFO - 2017-01-21 06:29:52 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:29:52 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:29:52 --> Utf8 Class Initialized
INFO - 2017-01-21 06:29:52 --> URI Class Initialized
INFO - 2017-01-21 06:29:52 --> Router Class Initialized
INFO - 2017-01-21 06:29:52 --> Output Class Initialized
INFO - 2017-01-21 06:29:52 --> Security Class Initialized
DEBUG - 2017-01-21 06:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:29:52 --> Input Class Initialized
INFO - 2017-01-21 06:29:52 --> Language Class Initialized
INFO - 2017-01-21 06:29:52 --> Loader Class Initialized
INFO - 2017-01-21 06:29:52 --> Database Driver Class Initialized
INFO - 2017-01-21 06:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:29:52 --> Controller Class Initialized
INFO - 2017-01-21 06:29:52 --> Helper loaded: date_helper
DEBUG - 2017-01-21 06:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:29:52 --> Helper loaded: url_helper
INFO - 2017-01-21 06:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-21 06:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-21 06:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 06:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:29:52 --> Final output sent to browser
DEBUG - 2017-01-21 06:29:52 --> Total execution time: 0.0133
INFO - 2017-01-21 06:29:53 --> Config Class Initialized
INFO - 2017-01-21 06:29:53 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:29:53 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:29:53 --> Utf8 Class Initialized
INFO - 2017-01-21 06:29:53 --> URI Class Initialized
INFO - 2017-01-21 06:29:53 --> Router Class Initialized
INFO - 2017-01-21 06:29:53 --> Output Class Initialized
INFO - 2017-01-21 06:29:53 --> Security Class Initialized
DEBUG - 2017-01-21 06:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:29:53 --> Input Class Initialized
INFO - 2017-01-21 06:29:53 --> Language Class Initialized
INFO - 2017-01-21 06:29:53 --> Loader Class Initialized
INFO - 2017-01-21 06:29:53 --> Database Driver Class Initialized
INFO - 2017-01-21 06:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:29:53 --> Controller Class Initialized
INFO - 2017-01-21 06:29:53 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:29:53 --> Final output sent to browser
DEBUG - 2017-01-21 06:29:53 --> Total execution time: 0.0132
INFO - 2017-01-21 06:30:01 --> Config Class Initialized
INFO - 2017-01-21 06:30:01 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:30:01 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:30:01 --> Utf8 Class Initialized
INFO - 2017-01-21 06:30:01 --> URI Class Initialized
DEBUG - 2017-01-21 06:30:01 --> No URI present. Default controller set.
INFO - 2017-01-21 06:30:01 --> Router Class Initialized
INFO - 2017-01-21 06:30:01 --> Output Class Initialized
INFO - 2017-01-21 06:30:01 --> Security Class Initialized
DEBUG - 2017-01-21 06:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:30:01 --> Input Class Initialized
INFO - 2017-01-21 06:30:01 --> Language Class Initialized
INFO - 2017-01-21 06:30:01 --> Loader Class Initialized
INFO - 2017-01-21 06:30:01 --> Database Driver Class Initialized
INFO - 2017-01-21 06:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:30:01 --> Controller Class Initialized
INFO - 2017-01-21 06:30:01 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:30:01 --> Final output sent to browser
DEBUG - 2017-01-21 06:30:01 --> Total execution time: 0.0136
INFO - 2017-01-21 06:30:02 --> Config Class Initialized
INFO - 2017-01-21 06:30:02 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:30:02 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:30:02 --> Utf8 Class Initialized
INFO - 2017-01-21 06:30:02 --> URI Class Initialized
INFO - 2017-01-21 06:30:02 --> Router Class Initialized
INFO - 2017-01-21 06:30:02 --> Output Class Initialized
INFO - 2017-01-21 06:30:02 --> Security Class Initialized
DEBUG - 2017-01-21 06:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:30:02 --> Input Class Initialized
INFO - 2017-01-21 06:30:02 --> Language Class Initialized
INFO - 2017-01-21 06:30:02 --> Loader Class Initialized
INFO - 2017-01-21 06:30:02 --> Database Driver Class Initialized
INFO - 2017-01-21 06:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:30:02 --> Controller Class Initialized
INFO - 2017-01-21 06:30:02 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:30:02 --> Final output sent to browser
DEBUG - 2017-01-21 06:30:02 --> Total execution time: 0.0138
INFO - 2017-01-21 06:30:43 --> Config Class Initialized
INFO - 2017-01-21 06:30:43 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:30:43 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:30:43 --> Utf8 Class Initialized
INFO - 2017-01-21 06:30:43 --> URI Class Initialized
INFO - 2017-01-21 06:30:43 --> Router Class Initialized
INFO - 2017-01-21 06:30:43 --> Output Class Initialized
INFO - 2017-01-21 06:30:43 --> Security Class Initialized
DEBUG - 2017-01-21 06:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:30:43 --> Input Class Initialized
INFO - 2017-01-21 06:30:43 --> Language Class Initialized
INFO - 2017-01-21 06:30:43 --> Loader Class Initialized
INFO - 2017-01-21 06:30:43 --> Database Driver Class Initialized
INFO - 2017-01-21 06:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:30:43 --> Controller Class Initialized
INFO - 2017-01-21 06:30:43 --> Helper loaded: date_helper
DEBUG - 2017-01-21 06:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:30:43 --> Helper loaded: url_helper
INFO - 2017-01-21 06:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-21 06:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-21 06:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 06:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:30:43 --> Final output sent to browser
DEBUG - 2017-01-21 06:30:43 --> Total execution time: 0.1029
INFO - 2017-01-21 06:30:44 --> Config Class Initialized
INFO - 2017-01-21 06:30:44 --> Hooks Class Initialized
DEBUG - 2017-01-21 06:30:44 --> UTF-8 Support Enabled
INFO - 2017-01-21 06:30:44 --> Utf8 Class Initialized
INFO - 2017-01-21 06:30:44 --> URI Class Initialized
INFO - 2017-01-21 06:30:44 --> Router Class Initialized
INFO - 2017-01-21 06:30:44 --> Output Class Initialized
INFO - 2017-01-21 06:30:44 --> Security Class Initialized
DEBUG - 2017-01-21 06:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 06:30:44 --> Input Class Initialized
INFO - 2017-01-21 06:30:44 --> Language Class Initialized
INFO - 2017-01-21 06:30:44 --> Loader Class Initialized
INFO - 2017-01-21 06:30:44 --> Database Driver Class Initialized
INFO - 2017-01-21 06:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 06:30:44 --> Controller Class Initialized
INFO - 2017-01-21 06:30:44 --> Helper loaded: url_helper
DEBUG - 2017-01-21 06:30:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 06:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 06:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 06:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 06:30:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 06:30:44 --> Final output sent to browser
DEBUG - 2017-01-21 06:30:44 --> Total execution time: 0.0138
INFO - 2017-01-21 12:56:26 --> Config Class Initialized
INFO - 2017-01-21 12:56:26 --> Hooks Class Initialized
DEBUG - 2017-01-21 12:56:26 --> UTF-8 Support Enabled
INFO - 2017-01-21 12:56:26 --> Utf8 Class Initialized
INFO - 2017-01-21 12:56:26 --> URI Class Initialized
INFO - 2017-01-21 12:56:26 --> Router Class Initialized
INFO - 2017-01-21 12:56:26 --> Output Class Initialized
INFO - 2017-01-21 12:56:26 --> Security Class Initialized
DEBUG - 2017-01-21 12:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 12:56:26 --> Input Class Initialized
INFO - 2017-01-21 12:56:26 --> Language Class Initialized
INFO - 2017-01-21 12:56:26 --> Loader Class Initialized
INFO - 2017-01-21 12:56:26 --> Database Driver Class Initialized
INFO - 2017-01-21 12:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 12:56:26 --> Controller Class Initialized
INFO - 2017-01-21 12:56:26 --> Helper loaded: url_helper
DEBUG - 2017-01-21 12:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 12:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 12:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 12:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 12:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 12:56:26 --> Final output sent to browser
DEBUG - 2017-01-21 12:56:26 --> Total execution time: 0.0668
INFO - 2017-01-21 18:17:58 --> Config Class Initialized
INFO - 2017-01-21 18:17:58 --> Hooks Class Initialized
DEBUG - 2017-01-21 18:17:58 --> UTF-8 Support Enabled
INFO - 2017-01-21 18:17:58 --> Utf8 Class Initialized
INFO - 2017-01-21 18:17:58 --> URI Class Initialized
DEBUG - 2017-01-21 18:17:58 --> No URI present. Default controller set.
INFO - 2017-01-21 18:17:58 --> Router Class Initialized
INFO - 2017-01-21 18:17:58 --> Output Class Initialized
INFO - 2017-01-21 18:17:58 --> Security Class Initialized
DEBUG - 2017-01-21 18:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 18:17:58 --> Input Class Initialized
INFO - 2017-01-21 18:17:58 --> Language Class Initialized
INFO - 2017-01-21 18:17:58 --> Loader Class Initialized
INFO - 2017-01-21 18:17:58 --> Database Driver Class Initialized
INFO - 2017-01-21 18:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 18:17:58 --> Controller Class Initialized
INFO - 2017-01-21 18:17:58 --> Helper loaded: url_helper
DEBUG - 2017-01-21 18:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 18:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 18:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 18:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 18:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 18:17:58 --> Final output sent to browser
DEBUG - 2017-01-21 18:17:58 --> Total execution time: 0.1237
INFO - 2017-01-21 20:12:08 --> Config Class Initialized
INFO - 2017-01-21 20:12:08 --> Hooks Class Initialized
DEBUG - 2017-01-21 20:12:08 --> UTF-8 Support Enabled
INFO - 2017-01-21 20:12:08 --> Utf8 Class Initialized
INFO - 2017-01-21 20:12:08 --> URI Class Initialized
DEBUG - 2017-01-21 20:12:08 --> No URI present. Default controller set.
INFO - 2017-01-21 20:12:08 --> Router Class Initialized
INFO - 2017-01-21 20:12:08 --> Output Class Initialized
INFO - 2017-01-21 20:12:08 --> Security Class Initialized
DEBUG - 2017-01-21 20:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 20:12:08 --> Input Class Initialized
INFO - 2017-01-21 20:12:08 --> Language Class Initialized
INFO - 2017-01-21 20:12:08 --> Loader Class Initialized
INFO - 2017-01-21 20:12:08 --> Database Driver Class Initialized
INFO - 2017-01-21 20:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 20:12:08 --> Controller Class Initialized
INFO - 2017-01-21 20:12:08 --> Helper loaded: url_helper
DEBUG - 2017-01-21 20:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 20:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 20:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 20:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 20:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 20:12:08 --> Final output sent to browser
DEBUG - 2017-01-21 20:12:08 --> Total execution time: 0.0228
INFO - 2017-01-21 21:20:06 --> Config Class Initialized
INFO - 2017-01-21 21:20:06 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:06 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:06 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:06 --> URI Class Initialized
DEBUG - 2017-01-21 21:20:06 --> No URI present. Default controller set.
INFO - 2017-01-21 21:20:06 --> Router Class Initialized
INFO - 2017-01-21 21:20:06 --> Output Class Initialized
INFO - 2017-01-21 21:20:06 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:06 --> Input Class Initialized
INFO - 2017-01-21 21:20:06 --> Language Class Initialized
INFO - 2017-01-21 21:20:06 --> Loader Class Initialized
INFO - 2017-01-21 21:20:06 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:06 --> Controller Class Initialized
INFO - 2017-01-21 21:20:06 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:20:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:20:06 --> Final output sent to browser
DEBUG - 2017-01-21 21:20:06 --> Total execution time: 0.0172
INFO - 2017-01-21 21:20:14 --> Config Class Initialized
INFO - 2017-01-21 21:20:14 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:14 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:14 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:14 --> URI Class Initialized
INFO - 2017-01-21 21:20:14 --> Router Class Initialized
INFO - 2017-01-21 21:20:14 --> Output Class Initialized
INFO - 2017-01-21 21:20:14 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:14 --> Input Class Initialized
INFO - 2017-01-21 21:20:14 --> Language Class Initialized
INFO - 2017-01-21 21:20:14 --> Loader Class Initialized
INFO - 2017-01-21 21:20:14 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:14 --> Controller Class Initialized
INFO - 2017-01-21 21:20:14 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:20:14 --> Final output sent to browser
DEBUG - 2017-01-21 21:20:14 --> Total execution time: 0.0132
INFO - 2017-01-21 21:20:37 --> Config Class Initialized
INFO - 2017-01-21 21:20:37 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:37 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:37 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:37 --> URI Class Initialized
INFO - 2017-01-21 21:20:37 --> Router Class Initialized
INFO - 2017-01-21 21:20:37 --> Output Class Initialized
INFO - 2017-01-21 21:20:37 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:37 --> Input Class Initialized
INFO - 2017-01-21 21:20:37 --> Language Class Initialized
INFO - 2017-01-21 21:20:37 --> Loader Class Initialized
INFO - 2017-01-21 21:20:37 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:37 --> Controller Class Initialized
INFO - 2017-01-21 21:20:37 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:37 --> Helper loaded: form_helper
INFO - 2017-01-21 21:20:37 --> Form Validation Class Initialized
INFO - 2017-01-21 21:20:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:20:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-21 21:20:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:20:37 --> Final output sent to browser
DEBUG - 2017-01-21 21:20:37 --> Total execution time: 0.0814
INFO - 2017-01-21 21:20:38 --> Config Class Initialized
INFO - 2017-01-21 21:20:38 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:38 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:38 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:38 --> URI Class Initialized
INFO - 2017-01-21 21:20:38 --> Router Class Initialized
INFO - 2017-01-21 21:20:38 --> Output Class Initialized
INFO - 2017-01-21 21:20:38 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:38 --> Input Class Initialized
INFO - 2017-01-21 21:20:38 --> Language Class Initialized
INFO - 2017-01-21 21:20:38 --> Loader Class Initialized
INFO - 2017-01-21 21:20:38 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:38 --> Controller Class Initialized
INFO - 2017-01-21 21:20:38 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:20:38 --> Final output sent to browser
DEBUG - 2017-01-21 21:20:38 --> Total execution time: 0.0135
INFO - 2017-01-21 21:20:49 --> Config Class Initialized
INFO - 2017-01-21 21:20:49 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:49 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:49 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:49 --> URI Class Initialized
INFO - 2017-01-21 21:20:49 --> Router Class Initialized
INFO - 2017-01-21 21:20:49 --> Output Class Initialized
INFO - 2017-01-21 21:20:49 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:49 --> Input Class Initialized
INFO - 2017-01-21 21:20:49 --> Language Class Initialized
INFO - 2017-01-21 21:20:49 --> Loader Class Initialized
INFO - 2017-01-21 21:20:49 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:49 --> Controller Class Initialized
INFO - 2017-01-21 21:20:49 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:49 --> Helper loaded: form_helper
INFO - 2017-01-21 21:20:49 --> Form Validation Class Initialized
INFO - 2017-01-21 21:20:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-21 21:20:49 --> Config Class Initialized
INFO - 2017-01-21 21:20:49 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:49 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:49 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:49 --> URI Class Initialized
INFO - 2017-01-21 21:20:49 --> Router Class Initialized
INFO - 2017-01-21 21:20:49 --> Output Class Initialized
INFO - 2017-01-21 21:20:49 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:49 --> Input Class Initialized
INFO - 2017-01-21 21:20:49 --> Language Class Initialized
INFO - 2017-01-21 21:20:49 --> Loader Class Initialized
INFO - 2017-01-21 21:20:49 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:49 --> Controller Class Initialized
INFO - 2017-01-21 21:20:49 --> Helper loaded: date_helper
INFO - 2017-01-21 21:20:49 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:49 --> Helper loaded: form_helper
INFO - 2017-01-21 21:20:49 --> Form Validation Class Initialized
INFO - 2017-01-21 21:20:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:20:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:20:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-21 21:20:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-21 21:20:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:20:49 --> Final output sent to browser
DEBUG - 2017-01-21 21:20:49 --> Total execution time: 0.1003
INFO - 2017-01-21 21:20:49 --> Config Class Initialized
INFO - 2017-01-21 21:20:49 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:49 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:49 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:49 --> URI Class Initialized
INFO - 2017-01-21 21:20:49 --> Router Class Initialized
INFO - 2017-01-21 21:20:49 --> Output Class Initialized
INFO - 2017-01-21 21:20:49 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:49 --> Input Class Initialized
INFO - 2017-01-21 21:20:49 --> Language Class Initialized
INFO - 2017-01-21 21:20:49 --> Loader Class Initialized
INFO - 2017-01-21 21:20:49 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:49 --> Controller Class Initialized
INFO - 2017-01-21 21:20:49 --> Helper loaded: date_helper
INFO - 2017-01-21 21:20:49 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:49 --> Helper loaded: form_helper
INFO - 2017-01-21 21:20:49 --> Form Validation Class Initialized
INFO - 2017-01-21 21:20:50 --> Final output sent to browser
DEBUG - 2017-01-21 21:20:50 --> Total execution time: 0.0947
INFO - 2017-01-21 21:20:51 --> Config Class Initialized
INFO - 2017-01-21 21:20:51 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:20:51 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:20:51 --> Utf8 Class Initialized
INFO - 2017-01-21 21:20:51 --> URI Class Initialized
INFO - 2017-01-21 21:20:51 --> Router Class Initialized
INFO - 2017-01-21 21:20:51 --> Output Class Initialized
INFO - 2017-01-21 21:20:51 --> Security Class Initialized
DEBUG - 2017-01-21 21:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:20:51 --> Input Class Initialized
INFO - 2017-01-21 21:20:51 --> Language Class Initialized
INFO - 2017-01-21 21:20:51 --> Loader Class Initialized
INFO - 2017-01-21 21:20:51 --> Database Driver Class Initialized
INFO - 2017-01-21 21:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:20:51 --> Controller Class Initialized
INFO - 2017-01-21 21:20:51 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:20:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:20:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:20:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:20:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:20:51 --> Final output sent to browser
DEBUG - 2017-01-21 21:20:51 --> Total execution time: 0.0137
INFO - 2017-01-21 21:21:03 --> Config Class Initialized
INFO - 2017-01-21 21:21:03 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:03 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:03 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:03 --> URI Class Initialized
INFO - 2017-01-21 21:21:03 --> Router Class Initialized
INFO - 2017-01-21 21:21:03 --> Output Class Initialized
INFO - 2017-01-21 21:21:03 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:03 --> Input Class Initialized
INFO - 2017-01-21 21:21:03 --> Language Class Initialized
INFO - 2017-01-21 21:21:03 --> Loader Class Initialized
INFO - 2017-01-21 21:21:03 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:03 --> Controller Class Initialized
INFO - 2017-01-21 21:21:03 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:04 --> Config Class Initialized
INFO - 2017-01-21 21:21:04 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:04 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:04 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:04 --> URI Class Initialized
INFO - 2017-01-21 21:21:04 --> Router Class Initialized
INFO - 2017-01-21 21:21:04 --> Output Class Initialized
INFO - 2017-01-21 21:21:04 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:04 --> Input Class Initialized
INFO - 2017-01-21 21:21:04 --> Language Class Initialized
INFO - 2017-01-21 21:21:04 --> Loader Class Initialized
INFO - 2017-01-21 21:21:04 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:04 --> Controller Class Initialized
INFO - 2017-01-21 21:21:04 --> Helper loaded: date_helper
DEBUG - 2017-01-21 21:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:04 --> Helper loaded: url_helper
INFO - 2017-01-21 21:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 21:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-21 21:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 21:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:21:04 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:04 --> Total execution time: 0.0495
INFO - 2017-01-21 21:21:06 --> Config Class Initialized
INFO - 2017-01-21 21:21:06 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:06 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:06 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:06 --> URI Class Initialized
INFO - 2017-01-21 21:21:06 --> Router Class Initialized
INFO - 2017-01-21 21:21:06 --> Output Class Initialized
INFO - 2017-01-21 21:21:06 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:06 --> Input Class Initialized
INFO - 2017-01-21 21:21:06 --> Language Class Initialized
INFO - 2017-01-21 21:21:06 --> Loader Class Initialized
INFO - 2017-01-21 21:21:06 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:06 --> Controller Class Initialized
INFO - 2017-01-21 21:21:06 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:21:06 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:06 --> Total execution time: 0.0137
INFO - 2017-01-21 21:21:07 --> Config Class Initialized
INFO - 2017-01-21 21:21:07 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:07 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:07 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:07 --> URI Class Initialized
INFO - 2017-01-21 21:21:07 --> Router Class Initialized
INFO - 2017-01-21 21:21:07 --> Output Class Initialized
INFO - 2017-01-21 21:21:07 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:07 --> Input Class Initialized
INFO - 2017-01-21 21:21:07 --> Language Class Initialized
INFO - 2017-01-21 21:21:07 --> Loader Class Initialized
INFO - 2017-01-21 21:21:07 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:07 --> Controller Class Initialized
INFO - 2017-01-21 21:21:07 --> Helper loaded: date_helper
DEBUG - 2017-01-21 21:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:07 --> Helper loaded: url_helper
INFO - 2017-01-21 21:21:07 --> Helper loaded: download_helper
INFO - 2017-01-21 21:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 21:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-21 21:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-21 21:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:21:07 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:07 --> Total execution time: 0.1134
INFO - 2017-01-21 21:21:08 --> Config Class Initialized
INFO - 2017-01-21 21:21:08 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:08 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:08 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:08 --> URI Class Initialized
INFO - 2017-01-21 21:21:08 --> Router Class Initialized
INFO - 2017-01-21 21:21:08 --> Output Class Initialized
INFO - 2017-01-21 21:21:08 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:08 --> Input Class Initialized
INFO - 2017-01-21 21:21:08 --> Language Class Initialized
INFO - 2017-01-21 21:21:08 --> Loader Class Initialized
INFO - 2017-01-21 21:21:08 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:08 --> Controller Class Initialized
INFO - 2017-01-21 21:21:08 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:21:08 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:08 --> Total execution time: 0.0138
INFO - 2017-01-21 21:21:19 --> Config Class Initialized
INFO - 2017-01-21 21:21:19 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:19 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:19 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:19 --> URI Class Initialized
INFO - 2017-01-21 21:21:19 --> Router Class Initialized
INFO - 2017-01-21 21:21:19 --> Output Class Initialized
INFO - 2017-01-21 21:21:19 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:19 --> Input Class Initialized
INFO - 2017-01-21 21:21:19 --> Language Class Initialized
INFO - 2017-01-21 21:21:19 --> Loader Class Initialized
INFO - 2017-01-21 21:21:19 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:19 --> Controller Class Initialized
INFO - 2017-01-21 21:21:19 --> Helper loaded: date_helper
INFO - 2017-01-21 21:21:19 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:19 --> Helper loaded: form_helper
INFO - 2017-01-21 21:21:19 --> Form Validation Class Initialized
INFO - 2017-01-21 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-21 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-21 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:21:19 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:19 --> Total execution time: 0.2850
INFO - 2017-01-21 21:21:20 --> Config Class Initialized
INFO - 2017-01-21 21:21:20 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:20 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:20 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:20 --> URI Class Initialized
INFO - 2017-01-21 21:21:20 --> Router Class Initialized
INFO - 2017-01-21 21:21:20 --> Output Class Initialized
INFO - 2017-01-21 21:21:20 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:20 --> Input Class Initialized
INFO - 2017-01-21 21:21:20 --> Language Class Initialized
INFO - 2017-01-21 21:21:20 --> Loader Class Initialized
INFO - 2017-01-21 21:21:20 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:20 --> Controller Class Initialized
INFO - 2017-01-21 21:21:20 --> Helper loaded: date_helper
INFO - 2017-01-21 21:21:20 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:20 --> Helper loaded: form_helper
INFO - 2017-01-21 21:21:20 --> Form Validation Class Initialized
INFO - 2017-01-21 21:21:20 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:20 --> Total execution time: 0.0145
INFO - 2017-01-21 21:21:20 --> Config Class Initialized
INFO - 2017-01-21 21:21:20 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:20 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:20 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:20 --> URI Class Initialized
INFO - 2017-01-21 21:21:20 --> Router Class Initialized
INFO - 2017-01-21 21:21:20 --> Output Class Initialized
INFO - 2017-01-21 21:21:20 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:20 --> Input Class Initialized
INFO - 2017-01-21 21:21:20 --> Language Class Initialized
INFO - 2017-01-21 21:21:20 --> Loader Class Initialized
INFO - 2017-01-21 21:21:20 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:20 --> Controller Class Initialized
INFO - 2017-01-21 21:21:20 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:21:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:21:20 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:20 --> Total execution time: 0.0136
INFO - 2017-01-21 21:21:26 --> Config Class Initialized
INFO - 2017-01-21 21:21:26 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:26 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:26 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:26 --> URI Class Initialized
INFO - 2017-01-21 21:21:26 --> Router Class Initialized
INFO - 2017-01-21 21:21:26 --> Output Class Initialized
INFO - 2017-01-21 21:21:26 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:26 --> Input Class Initialized
INFO - 2017-01-21 21:21:26 --> Language Class Initialized
INFO - 2017-01-21 21:21:26 --> Loader Class Initialized
INFO - 2017-01-21 21:21:26 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:26 --> Controller Class Initialized
INFO - 2017-01-21 21:21:26 --> Helper loaded: date_helper
INFO - 2017-01-21 21:21:26 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:26 --> Helper loaded: form_helper
INFO - 2017-01-21 21:21:26 --> Form Validation Class Initialized
INFO - 2017-01-21 21:21:26 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:26 --> Total execution time: 0.0143
INFO - 2017-01-21 21:21:39 --> Config Class Initialized
INFO - 2017-01-21 21:21:39 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:39 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:39 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:39 --> URI Class Initialized
INFO - 2017-01-21 21:21:39 --> Router Class Initialized
INFO - 2017-01-21 21:21:39 --> Output Class Initialized
INFO - 2017-01-21 21:21:39 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:39 --> Input Class Initialized
INFO - 2017-01-21 21:21:39 --> Language Class Initialized
ERROR - 2017-01-21 21:21:39 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-21 21:21:54 --> Config Class Initialized
INFO - 2017-01-21 21:21:54 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:54 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:54 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:54 --> URI Class Initialized
INFO - 2017-01-21 21:21:54 --> Router Class Initialized
INFO - 2017-01-21 21:21:54 --> Output Class Initialized
INFO - 2017-01-21 21:21:54 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:54 --> Input Class Initialized
INFO - 2017-01-21 21:21:54 --> Language Class Initialized
INFO - 2017-01-21 21:21:54 --> Loader Class Initialized
INFO - 2017-01-21 21:21:54 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:54 --> Controller Class Initialized
INFO - 2017-01-21 21:21:54 --> Upload Class Initialized
INFO - 2017-01-21 21:21:54 --> Helper loaded: date_helper
INFO - 2017-01-21 21:21:54 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:54 --> Helper loaded: form_helper
INFO - 2017-01-21 21:21:54 --> Form Validation Class Initialized
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:21:54 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:54 --> Total execution time: 0.1215
INFO - 2017-01-21 21:21:54 --> Config Class Initialized
INFO - 2017-01-21 21:21:54 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:54 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:54 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:54 --> URI Class Initialized
INFO - 2017-01-21 21:21:54 --> Router Class Initialized
INFO - 2017-01-21 21:21:54 --> Output Class Initialized
INFO - 2017-01-21 21:21:54 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:54 --> Input Class Initialized
INFO - 2017-01-21 21:21:54 --> Language Class Initialized
INFO - 2017-01-21 21:21:54 --> Loader Class Initialized
INFO - 2017-01-21 21:21:54 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:54 --> Controller Class Initialized
INFO - 2017-01-21 21:21:54 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:21:54 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:54 --> Total execution time: 0.0134
INFO - 2017-01-21 21:21:55 --> Config Class Initialized
INFO - 2017-01-21 21:21:55 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:55 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:55 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:55 --> URI Class Initialized
INFO - 2017-01-21 21:21:55 --> Router Class Initialized
INFO - 2017-01-21 21:21:55 --> Output Class Initialized
INFO - 2017-01-21 21:21:55 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:55 --> Input Class Initialized
INFO - 2017-01-21 21:21:55 --> Language Class Initialized
INFO - 2017-01-21 21:21:55 --> Loader Class Initialized
INFO - 2017-01-21 21:21:55 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:55 --> Controller Class Initialized
INFO - 2017-01-21 21:21:55 --> Helper loaded: date_helper
INFO - 2017-01-21 21:21:55 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:55 --> Helper loaded: form_helper
INFO - 2017-01-21 21:21:55 --> Form Validation Class Initialized
INFO - 2017-01-21 21:21:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:21:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:21:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-21 21:21:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-21 21:21:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:21:55 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:55 --> Total execution time: 0.0154
INFO - 2017-01-21 21:21:56 --> Config Class Initialized
INFO - 2017-01-21 21:21:56 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:56 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:56 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:56 --> URI Class Initialized
INFO - 2017-01-21 21:21:56 --> Router Class Initialized
INFO - 2017-01-21 21:21:56 --> Output Class Initialized
INFO - 2017-01-21 21:21:56 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:56 --> Input Class Initialized
INFO - 2017-01-21 21:21:56 --> Language Class Initialized
INFO - 2017-01-21 21:21:56 --> Loader Class Initialized
INFO - 2017-01-21 21:21:56 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:56 --> Controller Class Initialized
INFO - 2017-01-21 21:21:56 --> Helper loaded: date_helper
INFO - 2017-01-21 21:21:56 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:56 --> Helper loaded: form_helper
INFO - 2017-01-21 21:21:56 --> Form Validation Class Initialized
INFO - 2017-01-21 21:21:56 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:56 --> Total execution time: 0.0373
INFO - 2017-01-21 21:21:56 --> Config Class Initialized
INFO - 2017-01-21 21:21:56 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:56 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:56 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:56 --> URI Class Initialized
INFO - 2017-01-21 21:21:56 --> Router Class Initialized
INFO - 2017-01-21 21:21:56 --> Output Class Initialized
INFO - 2017-01-21 21:21:56 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:56 --> Input Class Initialized
INFO - 2017-01-21 21:21:56 --> Language Class Initialized
INFO - 2017-01-21 21:21:56 --> Loader Class Initialized
INFO - 2017-01-21 21:21:56 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:56 --> Controller Class Initialized
INFO - 2017-01-21 21:21:56 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:21:56 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:56 --> Total execution time: 0.0135
INFO - 2017-01-21 21:21:59 --> Config Class Initialized
INFO - 2017-01-21 21:21:59 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:21:59 --> Utf8 Class Initialized
INFO - 2017-01-21 21:21:59 --> URI Class Initialized
INFO - 2017-01-21 21:21:59 --> Router Class Initialized
INFO - 2017-01-21 21:21:59 --> Output Class Initialized
INFO - 2017-01-21 21:21:59 --> Security Class Initialized
DEBUG - 2017-01-21 21:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:21:59 --> Input Class Initialized
INFO - 2017-01-21 21:21:59 --> Language Class Initialized
INFO - 2017-01-21 21:21:59 --> Loader Class Initialized
INFO - 2017-01-21 21:21:59 --> Database Driver Class Initialized
INFO - 2017-01-21 21:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:21:59 --> Controller Class Initialized
INFO - 2017-01-21 21:21:59 --> Helper loaded: date_helper
INFO - 2017-01-21 21:21:59 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:21:59 --> Helper loaded: form_helper
INFO - 2017-01-21 21:21:59 --> Form Validation Class Initialized
INFO - 2017-01-21 21:21:59 --> Final output sent to browser
DEBUG - 2017-01-21 21:21:59 --> Total execution time: 0.0143
INFO - 2017-01-21 21:22:03 --> Config Class Initialized
INFO - 2017-01-21 21:22:03 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:22:03 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:22:03 --> Utf8 Class Initialized
INFO - 2017-01-21 21:22:03 --> URI Class Initialized
INFO - 2017-01-21 21:22:03 --> Router Class Initialized
INFO - 2017-01-21 21:22:03 --> Output Class Initialized
INFO - 2017-01-21 21:22:03 --> Security Class Initialized
DEBUG - 2017-01-21 21:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:22:03 --> Input Class Initialized
INFO - 2017-01-21 21:22:03 --> Language Class Initialized
ERROR - 2017-01-21 21:22:03 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-21 21:25:58 --> Config Class Initialized
INFO - 2017-01-21 21:25:58 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:25:58 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:25:58 --> Utf8 Class Initialized
INFO - 2017-01-21 21:25:58 --> URI Class Initialized
DEBUG - 2017-01-21 21:25:58 --> No URI present. Default controller set.
INFO - 2017-01-21 21:25:58 --> Router Class Initialized
INFO - 2017-01-21 21:25:58 --> Output Class Initialized
INFO - 2017-01-21 21:25:58 --> Security Class Initialized
DEBUG - 2017-01-21 21:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:25:58 --> Input Class Initialized
INFO - 2017-01-21 21:25:58 --> Language Class Initialized
INFO - 2017-01-21 21:25:58 --> Loader Class Initialized
INFO - 2017-01-21 21:25:58 --> Database Driver Class Initialized
INFO - 2017-01-21 21:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:25:58 --> Controller Class Initialized
INFO - 2017-01-21 21:25:58 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:25:58 --> Final output sent to browser
DEBUG - 2017-01-21 21:25:58 --> Total execution time: 0.0137
INFO - 2017-01-21 21:25:59 --> Config Class Initialized
INFO - 2017-01-21 21:25:59 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:25:59 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:25:59 --> Utf8 Class Initialized
INFO - 2017-01-21 21:25:59 --> URI Class Initialized
INFO - 2017-01-21 21:25:59 --> Router Class Initialized
INFO - 2017-01-21 21:25:59 --> Output Class Initialized
INFO - 2017-01-21 21:25:59 --> Security Class Initialized
DEBUG - 2017-01-21 21:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:25:59 --> Input Class Initialized
INFO - 2017-01-21 21:25:59 --> Language Class Initialized
INFO - 2017-01-21 21:25:59 --> Loader Class Initialized
INFO - 2017-01-21 21:25:59 --> Database Driver Class Initialized
INFO - 2017-01-21 21:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:25:59 --> Controller Class Initialized
INFO - 2017-01-21 21:25:59 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:25:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:25:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:25:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:25:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:25:59 --> Final output sent to browser
DEBUG - 2017-01-21 21:25:59 --> Total execution time: 0.0135
INFO - 2017-01-21 21:26:03 --> Config Class Initialized
INFO - 2017-01-21 21:26:03 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:03 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:03 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:03 --> URI Class Initialized
INFO - 2017-01-21 21:26:03 --> Router Class Initialized
INFO - 2017-01-21 21:26:03 --> Output Class Initialized
INFO - 2017-01-21 21:26:03 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:03 --> Input Class Initialized
INFO - 2017-01-21 21:26:03 --> Language Class Initialized
INFO - 2017-01-21 21:26:03 --> Loader Class Initialized
INFO - 2017-01-21 21:26:03 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:03 --> Controller Class Initialized
INFO - 2017-01-21 21:26:03 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:03 --> Config Class Initialized
INFO - 2017-01-21 21:26:03 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:03 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:03 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:03 --> URI Class Initialized
INFO - 2017-01-21 21:26:03 --> Router Class Initialized
INFO - 2017-01-21 21:26:03 --> Output Class Initialized
INFO - 2017-01-21 21:26:03 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:03 --> Input Class Initialized
INFO - 2017-01-21 21:26:03 --> Language Class Initialized
INFO - 2017-01-21 21:26:03 --> Loader Class Initialized
INFO - 2017-01-21 21:26:03 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:03 --> Controller Class Initialized
INFO - 2017-01-21 21:26:03 --> Helper loaded: date_helper
INFO - 2017-01-21 21:26:03 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:03 --> Helper loaded: form_helper
INFO - 2017-01-21 21:26:03 --> Form Validation Class Initialized
INFO - 2017-01-21 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-21 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-21 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:26:03 --> Final output sent to browser
DEBUG - 2017-01-21 21:26:03 --> Total execution time: 0.0149
INFO - 2017-01-21 21:26:04 --> Config Class Initialized
INFO - 2017-01-21 21:26:04 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:04 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:04 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:04 --> URI Class Initialized
INFO - 2017-01-21 21:26:04 --> Router Class Initialized
INFO - 2017-01-21 21:26:04 --> Output Class Initialized
INFO - 2017-01-21 21:26:04 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:04 --> Input Class Initialized
INFO - 2017-01-21 21:26:04 --> Language Class Initialized
INFO - 2017-01-21 21:26:04 --> Loader Class Initialized
INFO - 2017-01-21 21:26:04 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:04 --> Controller Class Initialized
INFO - 2017-01-21 21:26:04 --> Helper loaded: date_helper
INFO - 2017-01-21 21:26:04 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:04 --> Helper loaded: form_helper
INFO - 2017-01-21 21:26:04 --> Form Validation Class Initialized
INFO - 2017-01-21 21:26:04 --> Final output sent to browser
DEBUG - 2017-01-21 21:26:04 --> Total execution time: 0.0668
INFO - 2017-01-21 21:26:04 --> Config Class Initialized
INFO - 2017-01-21 21:26:04 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:04 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:04 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:04 --> URI Class Initialized
INFO - 2017-01-21 21:26:04 --> Router Class Initialized
INFO - 2017-01-21 21:26:04 --> Output Class Initialized
INFO - 2017-01-21 21:26:04 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:04 --> Input Class Initialized
INFO - 2017-01-21 21:26:04 --> Language Class Initialized
INFO - 2017-01-21 21:26:04 --> Loader Class Initialized
INFO - 2017-01-21 21:26:04 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:04 --> Controller Class Initialized
INFO - 2017-01-21 21:26:04 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:26:04 --> Final output sent to browser
DEBUG - 2017-01-21 21:26:04 --> Total execution time: 0.0140
INFO - 2017-01-21 21:26:46 --> Config Class Initialized
INFO - 2017-01-21 21:26:46 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:46 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:46 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:46 --> URI Class Initialized
INFO - 2017-01-21 21:26:46 --> Router Class Initialized
INFO - 2017-01-21 21:26:46 --> Output Class Initialized
INFO - 2017-01-21 21:26:46 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:46 --> Input Class Initialized
INFO - 2017-01-21 21:26:46 --> Language Class Initialized
INFO - 2017-01-21 21:26:46 --> Loader Class Initialized
INFO - 2017-01-21 21:26:46 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:47 --> Controller Class Initialized
INFO - 2017-01-21 21:26:47 --> Helper loaded: date_helper
INFO - 2017-01-21 21:26:47 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:47 --> Helper loaded: form_helper
INFO - 2017-01-21 21:26:47 --> Form Validation Class Initialized
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:26:47 --> Final output sent to browser
DEBUG - 2017-01-21 21:26:47 --> Total execution time: 0.0533
INFO - 2017-01-21 21:26:47 --> Config Class Initialized
INFO - 2017-01-21 21:26:47 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:47 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:47 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:47 --> URI Class Initialized
INFO - 2017-01-21 21:26:47 --> Router Class Initialized
INFO - 2017-01-21 21:26:47 --> Output Class Initialized
INFO - 2017-01-21 21:26:47 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:47 --> Input Class Initialized
INFO - 2017-01-21 21:26:47 --> Language Class Initialized
INFO - 2017-01-21 21:26:47 --> Loader Class Initialized
INFO - 2017-01-21 21:26:47 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:47 --> Controller Class Initialized
INFO - 2017-01-21 21:26:47 --> Helper loaded: date_helper
INFO - 2017-01-21 21:26:47 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:47 --> Helper loaded: form_helper
INFO - 2017-01-21 21:26:47 --> Form Validation Class Initialized
INFO - 2017-01-21 21:26:47 --> Final output sent to browser
DEBUG - 2017-01-21 21:26:47 --> Total execution time: 0.0141
INFO - 2017-01-21 21:26:47 --> Config Class Initialized
INFO - 2017-01-21 21:26:47 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:47 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:47 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:47 --> URI Class Initialized
INFO - 2017-01-21 21:26:47 --> Router Class Initialized
INFO - 2017-01-21 21:26:47 --> Output Class Initialized
INFO - 2017-01-21 21:26:47 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:47 --> Input Class Initialized
INFO - 2017-01-21 21:26:47 --> Language Class Initialized
INFO - 2017-01-21 21:26:47 --> Loader Class Initialized
INFO - 2017-01-21 21:26:47 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:47 --> Controller Class Initialized
INFO - 2017-01-21 21:26:47 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:26:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:26:47 --> Final output sent to browser
DEBUG - 2017-01-21 21:26:47 --> Total execution time: 0.0138
INFO - 2017-01-21 21:26:52 --> Config Class Initialized
INFO - 2017-01-21 21:26:52 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:52 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:52 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:52 --> URI Class Initialized
INFO - 2017-01-21 21:26:52 --> Router Class Initialized
INFO - 2017-01-21 21:26:52 --> Output Class Initialized
INFO - 2017-01-21 21:26:52 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:52 --> Input Class Initialized
INFO - 2017-01-21 21:26:52 --> Language Class Initialized
INFO - 2017-01-21 21:26:52 --> Loader Class Initialized
INFO - 2017-01-21 21:26:52 --> Database Driver Class Initialized
INFO - 2017-01-21 21:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:26:52 --> Controller Class Initialized
INFO - 2017-01-21 21:26:52 --> Helper loaded: date_helper
INFO - 2017-01-21 21:26:52 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:26:52 --> Helper loaded: form_helper
INFO - 2017-01-21 21:26:52 --> Form Validation Class Initialized
INFO - 2017-01-21 21:26:52 --> Final output sent to browser
DEBUG - 2017-01-21 21:26:52 --> Total execution time: 0.0141
INFO - 2017-01-21 21:26:57 --> Config Class Initialized
INFO - 2017-01-21 21:26:57 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:26:57 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:26:57 --> Utf8 Class Initialized
INFO - 2017-01-21 21:26:57 --> URI Class Initialized
INFO - 2017-01-21 21:26:57 --> Router Class Initialized
INFO - 2017-01-21 21:26:57 --> Output Class Initialized
INFO - 2017-01-21 21:26:57 --> Security Class Initialized
DEBUG - 2017-01-21 21:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:26:57 --> Input Class Initialized
INFO - 2017-01-21 21:26:57 --> Language Class Initialized
ERROR - 2017-01-21 21:26:57 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-21 21:38:42 --> Config Class Initialized
INFO - 2017-01-21 21:38:42 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:38:42 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:38:42 --> Utf8 Class Initialized
INFO - 2017-01-21 21:38:42 --> URI Class Initialized
INFO - 2017-01-21 21:38:42 --> Router Class Initialized
INFO - 2017-01-21 21:38:42 --> Output Class Initialized
INFO - 2017-01-21 21:38:42 --> Security Class Initialized
DEBUG - 2017-01-21 21:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:38:42 --> Input Class Initialized
INFO - 2017-01-21 21:38:42 --> Language Class Initialized
INFO - 2017-01-21 21:38:42 --> Loader Class Initialized
INFO - 2017-01-21 21:38:42 --> Database Driver Class Initialized
INFO - 2017-01-21 21:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:38:42 --> Controller Class Initialized
INFO - 2017-01-21 21:38:42 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:38:42 --> Final output sent to browser
DEBUG - 2017-01-21 21:38:42 --> Total execution time: 0.0396
INFO - 2017-01-21 21:38:42 --> Config Class Initialized
INFO - 2017-01-21 21:38:42 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:38:42 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:38:42 --> Utf8 Class Initialized
INFO - 2017-01-21 21:38:42 --> URI Class Initialized
INFO - 2017-01-21 21:38:42 --> Router Class Initialized
INFO - 2017-01-21 21:38:42 --> Output Class Initialized
INFO - 2017-01-21 21:38:42 --> Security Class Initialized
DEBUG - 2017-01-21 21:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:38:42 --> Input Class Initialized
INFO - 2017-01-21 21:38:42 --> Language Class Initialized
ERROR - 2017-01-21 21:38:42 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2017-01-21 21:51:21 --> Config Class Initialized
INFO - 2017-01-21 21:51:21 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:21 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:21 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:21 --> URI Class Initialized
INFO - 2017-01-21 21:51:21 --> Router Class Initialized
INFO - 2017-01-21 21:51:21 --> Output Class Initialized
INFO - 2017-01-21 21:51:21 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:21 --> Input Class Initialized
INFO - 2017-01-21 21:51:21 --> Language Class Initialized
INFO - 2017-01-21 21:51:21 --> Loader Class Initialized
INFO - 2017-01-21 21:51:21 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:21 --> Controller Class Initialized
INFO - 2017-01-21 21:51:21 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:21 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:21 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:21 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:51:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:51:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-21 21:51:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-21 21:51:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:51:21 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:21 --> Total execution time: 0.0201
INFO - 2017-01-21 21:51:21 --> Config Class Initialized
INFO - 2017-01-21 21:51:21 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:21 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:21 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:21 --> URI Class Initialized
INFO - 2017-01-21 21:51:21 --> Router Class Initialized
INFO - 2017-01-21 21:51:21 --> Output Class Initialized
INFO - 2017-01-21 21:51:21 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:21 --> Input Class Initialized
INFO - 2017-01-21 21:51:21 --> Language Class Initialized
ERROR - 2017-01-21 21:51:21 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-21 21:51:21 --> Config Class Initialized
INFO - 2017-01-21 21:51:21 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:21 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:21 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:21 --> URI Class Initialized
INFO - 2017-01-21 21:51:21 --> Router Class Initialized
INFO - 2017-01-21 21:51:21 --> Output Class Initialized
INFO - 2017-01-21 21:51:21 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:21 --> Input Class Initialized
INFO - 2017-01-21 21:51:21 --> Language Class Initialized
INFO - 2017-01-21 21:51:22 --> Loader Class Initialized
INFO - 2017-01-21 21:51:22 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:22 --> Controller Class Initialized
INFO - 2017-01-21 21:51:22 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:22 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:22 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:22 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:22 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:22 --> Total execution time: 0.0548
INFO - 2017-01-21 21:51:22 --> Config Class Initialized
INFO - 2017-01-21 21:51:22 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:22 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:22 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:22 --> URI Class Initialized
INFO - 2017-01-21 21:51:22 --> Router Class Initialized
INFO - 2017-01-21 21:51:22 --> Output Class Initialized
INFO - 2017-01-21 21:51:22 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:22 --> Input Class Initialized
INFO - 2017-01-21 21:51:22 --> Language Class Initialized
INFO - 2017-01-21 21:51:22 --> Loader Class Initialized
INFO - 2017-01-21 21:51:22 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:22 --> Controller Class Initialized
INFO - 2017-01-21 21:51:22 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:51:22 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:22 --> Total execution time: 0.0134
INFO - 2017-01-21 21:51:25 --> Config Class Initialized
INFO - 2017-01-21 21:51:25 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:25 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:25 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:25 --> URI Class Initialized
INFO - 2017-01-21 21:51:25 --> Router Class Initialized
INFO - 2017-01-21 21:51:25 --> Output Class Initialized
INFO - 2017-01-21 21:51:25 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:25 --> Input Class Initialized
INFO - 2017-01-21 21:51:25 --> Language Class Initialized
INFO - 2017-01-21 21:51:25 --> Loader Class Initialized
INFO - 2017-01-21 21:51:25 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:25 --> Controller Class Initialized
INFO - 2017-01-21 21:51:25 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:25 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:25 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:25 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:25 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:25 --> Total execution time: 0.0145
INFO - 2017-01-21 21:51:30 --> Config Class Initialized
INFO - 2017-01-21 21:51:30 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:30 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:30 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:30 --> URI Class Initialized
INFO - 2017-01-21 21:51:30 --> Router Class Initialized
INFO - 2017-01-21 21:51:30 --> Output Class Initialized
INFO - 2017-01-21 21:51:30 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:30 --> Input Class Initialized
INFO - 2017-01-21 21:51:30 --> Language Class Initialized
INFO - 2017-01-21 21:51:30 --> Loader Class Initialized
INFO - 2017-01-21 21:51:30 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:30 --> Controller Class Initialized
INFO - 2017-01-21 21:51:30 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:30 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:30 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:30 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:30 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:30 --> Total execution time: 0.0171
INFO - 2017-01-21 21:51:36 --> Config Class Initialized
INFO - 2017-01-21 21:51:36 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:36 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:36 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:36 --> URI Class Initialized
INFO - 2017-01-21 21:51:36 --> Router Class Initialized
INFO - 2017-01-21 21:51:36 --> Output Class Initialized
INFO - 2017-01-21 21:51:36 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:36 --> Input Class Initialized
INFO - 2017-01-21 21:51:36 --> Language Class Initialized
INFO - 2017-01-21 21:51:36 --> Loader Class Initialized
INFO - 2017-01-21 21:51:36 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:36 --> Controller Class Initialized
INFO - 2017-01-21 21:51:36 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:36 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:36 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:36 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:36 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:36 --> Total execution time: 0.0161
INFO - 2017-01-21 21:51:38 --> Config Class Initialized
INFO - 2017-01-21 21:51:38 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:38 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:38 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:38 --> URI Class Initialized
INFO - 2017-01-21 21:51:38 --> Router Class Initialized
INFO - 2017-01-21 21:51:38 --> Output Class Initialized
INFO - 2017-01-21 21:51:38 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:38 --> Input Class Initialized
INFO - 2017-01-21 21:51:38 --> Language Class Initialized
ERROR - 2017-01-21 21:51:38 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-21 21:51:41 --> Config Class Initialized
INFO - 2017-01-21 21:51:41 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:41 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:41 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:41 --> URI Class Initialized
INFO - 2017-01-21 21:51:41 --> Router Class Initialized
INFO - 2017-01-21 21:51:41 --> Output Class Initialized
INFO - 2017-01-21 21:51:41 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:41 --> Input Class Initialized
INFO - 2017-01-21 21:51:41 --> Language Class Initialized
INFO - 2017-01-21 21:51:41 --> Loader Class Initialized
INFO - 2017-01-21 21:51:41 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:41 --> Controller Class Initialized
INFO - 2017-01-21 21:51:41 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:41 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:41 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:41 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:41 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:41 --> Total execution time: 0.0167
INFO - 2017-01-21 21:51:44 --> Config Class Initialized
INFO - 2017-01-21 21:51:44 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:44 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:44 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:44 --> URI Class Initialized
INFO - 2017-01-21 21:51:44 --> Router Class Initialized
INFO - 2017-01-21 21:51:44 --> Output Class Initialized
INFO - 2017-01-21 21:51:44 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:44 --> Input Class Initialized
INFO - 2017-01-21 21:51:44 --> Language Class Initialized
INFO - 2017-01-21 21:51:44 --> Loader Class Initialized
INFO - 2017-01-21 21:51:44 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:44 --> Controller Class Initialized
INFO - 2017-01-21 21:51:44 --> Upload Class Initialized
INFO - 2017-01-21 21:51:44 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:44 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:44 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:44 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:51:44 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:44 --> Total execution time: 0.0171
INFO - 2017-01-21 21:51:44 --> Config Class Initialized
INFO - 2017-01-21 21:51:44 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:44 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:44 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:44 --> URI Class Initialized
INFO - 2017-01-21 21:51:44 --> Router Class Initialized
INFO - 2017-01-21 21:51:44 --> Output Class Initialized
INFO - 2017-01-21 21:51:44 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:44 --> Input Class Initialized
INFO - 2017-01-21 21:51:44 --> Language Class Initialized
INFO - 2017-01-21 21:51:44 --> Loader Class Initialized
INFO - 2017-01-21 21:51:44 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:44 --> Controller Class Initialized
INFO - 2017-01-21 21:51:44 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:51:44 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:44 --> Total execution time: 0.0141
INFO - 2017-01-21 21:51:45 --> Config Class Initialized
INFO - 2017-01-21 21:51:45 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:45 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:45 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:45 --> URI Class Initialized
INFO - 2017-01-21 21:51:45 --> Router Class Initialized
INFO - 2017-01-21 21:51:45 --> Output Class Initialized
INFO - 2017-01-21 21:51:45 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:45 --> Input Class Initialized
INFO - 2017-01-21 21:51:45 --> Language Class Initialized
INFO - 2017-01-21 21:51:45 --> Loader Class Initialized
INFO - 2017-01-21 21:51:45 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:45 --> Controller Class Initialized
INFO - 2017-01-21 21:51:45 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:45 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:45 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:45 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-21 21:51:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-21 21:51:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-21 21:51:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-21 21:51:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-21 21:51:45 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:45 --> Total execution time: 0.0144
INFO - 2017-01-21 21:51:46 --> Config Class Initialized
INFO - 2017-01-21 21:51:46 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:46 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:46 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:46 --> URI Class Initialized
INFO - 2017-01-21 21:51:46 --> Router Class Initialized
INFO - 2017-01-21 21:51:46 --> Output Class Initialized
INFO - 2017-01-21 21:51:46 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:46 --> Input Class Initialized
INFO - 2017-01-21 21:51:46 --> Language Class Initialized
INFO - 2017-01-21 21:51:46 --> Loader Class Initialized
INFO - 2017-01-21 21:51:46 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:46 --> Controller Class Initialized
INFO - 2017-01-21 21:51:46 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:46 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:46 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:46 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:46 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:46 --> Total execution time: 0.0142
INFO - 2017-01-21 21:51:46 --> Config Class Initialized
INFO - 2017-01-21 21:51:46 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:46 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:46 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:46 --> URI Class Initialized
INFO - 2017-01-21 21:51:46 --> Router Class Initialized
INFO - 2017-01-21 21:51:46 --> Output Class Initialized
INFO - 2017-01-21 21:51:46 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:46 --> Input Class Initialized
INFO - 2017-01-21 21:51:46 --> Language Class Initialized
INFO - 2017-01-21 21:51:46 --> Loader Class Initialized
INFO - 2017-01-21 21:51:46 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:46 --> Controller Class Initialized
INFO - 2017-01-21 21:51:46 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:51:46 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:46 --> Total execution time: 0.0138
INFO - 2017-01-21 21:51:49 --> Config Class Initialized
INFO - 2017-01-21 21:51:49 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:49 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:49 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:49 --> URI Class Initialized
INFO - 2017-01-21 21:51:49 --> Router Class Initialized
INFO - 2017-01-21 21:51:49 --> Output Class Initialized
INFO - 2017-01-21 21:51:49 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:49 --> Input Class Initialized
INFO - 2017-01-21 21:51:49 --> Language Class Initialized
INFO - 2017-01-21 21:51:49 --> Loader Class Initialized
INFO - 2017-01-21 21:51:49 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:49 --> Controller Class Initialized
INFO - 2017-01-21 21:51:49 --> Helper loaded: date_helper
INFO - 2017-01-21 21:51:49 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:51:49 --> Helper loaded: form_helper
INFO - 2017-01-21 21:51:49 --> Form Validation Class Initialized
INFO - 2017-01-21 21:51:49 --> Final output sent to browser
DEBUG - 2017-01-21 21:51:49 --> Total execution time: 0.0151
INFO - 2017-01-21 21:51:59 --> Config Class Initialized
INFO - 2017-01-21 21:51:59 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:51:59 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:51:59 --> Utf8 Class Initialized
INFO - 2017-01-21 21:51:59 --> URI Class Initialized
INFO - 2017-01-21 21:51:59 --> Router Class Initialized
INFO - 2017-01-21 21:51:59 --> Output Class Initialized
INFO - 2017-01-21 21:51:59 --> Security Class Initialized
DEBUG - 2017-01-21 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:51:59 --> Input Class Initialized
INFO - 2017-01-21 21:51:59 --> Language Class Initialized
INFO - 2017-01-21 21:51:59 --> Loader Class Initialized
INFO - 2017-01-21 21:51:59 --> Database Driver Class Initialized
INFO - 2017-01-21 21:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:51:59 --> Controller Class Initialized
INFO - 2017-01-21 21:51:59 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:52:00 --> Config Class Initialized
INFO - 2017-01-21 21:52:00 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:52:00 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:52:00 --> Utf8 Class Initialized
INFO - 2017-01-21 21:52:00 --> URI Class Initialized
INFO - 2017-01-21 21:52:00 --> Router Class Initialized
INFO - 2017-01-21 21:52:00 --> Output Class Initialized
INFO - 2017-01-21 21:52:00 --> Security Class Initialized
DEBUG - 2017-01-21 21:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:52:00 --> Input Class Initialized
INFO - 2017-01-21 21:52:00 --> Language Class Initialized
INFO - 2017-01-21 21:52:00 --> Loader Class Initialized
INFO - 2017-01-21 21:52:00 --> Database Driver Class Initialized
INFO - 2017-01-21 21:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:52:00 --> Controller Class Initialized
INFO - 2017-01-21 21:52:00 --> Helper loaded: date_helper
DEBUG - 2017-01-21 21:52:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:52:00 --> Helper loaded: url_helper
INFO - 2017-01-21 21:52:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:52:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 21:52:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-21 21:52:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 21:52:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:52:00 --> Final output sent to browser
DEBUG - 2017-01-21 21:52:00 --> Total execution time: 0.0149
INFO - 2017-01-21 21:52:01 --> Config Class Initialized
INFO - 2017-01-21 21:52:01 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:52:01 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:52:01 --> Utf8 Class Initialized
INFO - 2017-01-21 21:52:01 --> URI Class Initialized
INFO - 2017-01-21 21:52:01 --> Router Class Initialized
INFO - 2017-01-21 21:52:01 --> Output Class Initialized
INFO - 2017-01-21 21:52:01 --> Security Class Initialized
DEBUG - 2017-01-21 21:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:52:01 --> Input Class Initialized
INFO - 2017-01-21 21:52:01 --> Language Class Initialized
INFO - 2017-01-21 21:52:01 --> Loader Class Initialized
INFO - 2017-01-21 21:52:01 --> Database Driver Class Initialized
INFO - 2017-01-21 21:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:52:01 --> Controller Class Initialized
INFO - 2017-01-21 21:52:01 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:52:01 --> Final output sent to browser
DEBUG - 2017-01-21 21:52:01 --> Total execution time: 0.0133
INFO - 2017-01-21 21:52:02 --> Config Class Initialized
INFO - 2017-01-21 21:52:02 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:52:02 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:52:02 --> Utf8 Class Initialized
INFO - 2017-01-21 21:52:02 --> URI Class Initialized
INFO - 2017-01-21 21:52:02 --> Router Class Initialized
INFO - 2017-01-21 21:52:02 --> Output Class Initialized
INFO - 2017-01-21 21:52:02 --> Security Class Initialized
DEBUG - 2017-01-21 21:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:52:02 --> Input Class Initialized
INFO - 2017-01-21 21:52:02 --> Language Class Initialized
INFO - 2017-01-21 21:52:02 --> Loader Class Initialized
INFO - 2017-01-21 21:52:02 --> Database Driver Class Initialized
INFO - 2017-01-21 21:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:52:02 --> Controller Class Initialized
INFO - 2017-01-21 21:52:02 --> Helper loaded: date_helper
DEBUG - 2017-01-21 21:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:52:02 --> Helper loaded: url_helper
INFO - 2017-01-21 21:52:02 --> Helper loaded: download_helper
INFO - 2017-01-21 21:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 21:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-21 21:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-21 21:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:52:02 --> Final output sent to browser
DEBUG - 2017-01-21 21:52:02 --> Total execution time: 0.0556
INFO - 2017-01-21 21:52:04 --> Config Class Initialized
INFO - 2017-01-21 21:52:04 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:52:04 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:52:04 --> Utf8 Class Initialized
INFO - 2017-01-21 21:52:04 --> URI Class Initialized
INFO - 2017-01-21 21:52:04 --> Router Class Initialized
INFO - 2017-01-21 21:52:04 --> Output Class Initialized
INFO - 2017-01-21 21:52:04 --> Security Class Initialized
DEBUG - 2017-01-21 21:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:52:04 --> Input Class Initialized
INFO - 2017-01-21 21:52:04 --> Language Class Initialized
INFO - 2017-01-21 21:52:04 --> Loader Class Initialized
INFO - 2017-01-21 21:52:04 --> Database Driver Class Initialized
INFO - 2017-01-21 21:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:52:04 --> Controller Class Initialized
INFO - 2017-01-21 21:52:04 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:52:04 --> Final output sent to browser
DEBUG - 2017-01-21 21:52:04 --> Total execution time: 0.0641
INFO - 2017-01-21 21:54:28 --> Config Class Initialized
INFO - 2017-01-21 21:54:28 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:54:28 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:54:28 --> Utf8 Class Initialized
INFO - 2017-01-21 21:54:28 --> URI Class Initialized
DEBUG - 2017-01-21 21:54:28 --> No URI present. Default controller set.
INFO - 2017-01-21 21:54:28 --> Router Class Initialized
INFO - 2017-01-21 21:54:28 --> Output Class Initialized
INFO - 2017-01-21 21:54:28 --> Security Class Initialized
DEBUG - 2017-01-21 21:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:54:28 --> Input Class Initialized
INFO - 2017-01-21 21:54:28 --> Language Class Initialized
INFO - 2017-01-21 21:54:28 --> Loader Class Initialized
INFO - 2017-01-21 21:54:28 --> Database Driver Class Initialized
INFO - 2017-01-21 21:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:54:28 --> Controller Class Initialized
INFO - 2017-01-21 21:54:28 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:54:28 --> Final output sent to browser
DEBUG - 2017-01-21 21:54:28 --> Total execution time: 0.0134
INFO - 2017-01-21 21:54:51 --> Config Class Initialized
INFO - 2017-01-21 21:54:51 --> Hooks Class Initialized
DEBUG - 2017-01-21 21:54:51 --> UTF-8 Support Enabled
INFO - 2017-01-21 21:54:51 --> Utf8 Class Initialized
INFO - 2017-01-21 21:54:51 --> URI Class Initialized
INFO - 2017-01-21 21:54:51 --> Router Class Initialized
INFO - 2017-01-21 21:54:51 --> Output Class Initialized
INFO - 2017-01-21 21:54:51 --> Security Class Initialized
DEBUG - 2017-01-21 21:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 21:54:51 --> Input Class Initialized
INFO - 2017-01-21 21:54:51 --> Language Class Initialized
INFO - 2017-01-21 21:54:51 --> Loader Class Initialized
INFO - 2017-01-21 21:54:51 --> Database Driver Class Initialized
INFO - 2017-01-21 21:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 21:54:51 --> Controller Class Initialized
INFO - 2017-01-21 21:54:51 --> Helper loaded: url_helper
DEBUG - 2017-01-21 21:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 21:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 21:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 21:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 21:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 21:54:51 --> Final output sent to browser
DEBUG - 2017-01-21 21:54:51 --> Total execution time: 0.0135
INFO - 2017-01-21 23:12:24 --> Config Class Initialized
INFO - 2017-01-21 23:12:24 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:12:24 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:12:24 --> Utf8 Class Initialized
INFO - 2017-01-21 23:12:24 --> URI Class Initialized
INFO - 2017-01-21 23:12:24 --> Router Class Initialized
INFO - 2017-01-21 23:12:24 --> Output Class Initialized
INFO - 2017-01-21 23:12:24 --> Security Class Initialized
DEBUG - 2017-01-21 23:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:12:24 --> Input Class Initialized
INFO - 2017-01-21 23:12:24 --> Language Class Initialized
INFO - 2017-01-21 23:12:24 --> Loader Class Initialized
INFO - 2017-01-21 23:12:24 --> Database Driver Class Initialized
INFO - 2017-01-21 23:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:12:24 --> Controller Class Initialized
INFO - 2017-01-21 23:12:24 --> Helper loaded: url_helper
DEBUG - 2017-01-21 23:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 23:12:24 --> Final output sent to browser
DEBUG - 2017-01-21 23:12:24 --> Total execution time: 0.0140
INFO - 2017-01-21 23:12:24 --> Config Class Initialized
INFO - 2017-01-21 23:12:24 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:12:24 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:12:24 --> Utf8 Class Initialized
INFO - 2017-01-21 23:12:24 --> URI Class Initialized
DEBUG - 2017-01-21 23:12:24 --> No URI present. Default controller set.
INFO - 2017-01-21 23:12:24 --> Router Class Initialized
INFO - 2017-01-21 23:12:24 --> Output Class Initialized
INFO - 2017-01-21 23:12:24 --> Security Class Initialized
DEBUG - 2017-01-21 23:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:12:24 --> Input Class Initialized
INFO - 2017-01-21 23:12:24 --> Language Class Initialized
INFO - 2017-01-21 23:12:24 --> Loader Class Initialized
INFO - 2017-01-21 23:12:24 --> Database Driver Class Initialized
INFO - 2017-01-21 23:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:12:24 --> Controller Class Initialized
INFO - 2017-01-21 23:12:24 --> Helper loaded: url_helper
DEBUG - 2017-01-21 23:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 23:12:24 --> Final output sent to browser
DEBUG - 2017-01-21 23:12:24 --> Total execution time: 0.0137
INFO - 2017-01-21 23:47:52 --> Config Class Initialized
INFO - 2017-01-21 23:47:52 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:47:52 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:47:52 --> Utf8 Class Initialized
INFO - 2017-01-21 23:47:52 --> URI Class Initialized
DEBUG - 2017-01-21 23:47:52 --> No URI present. Default controller set.
INFO - 2017-01-21 23:47:52 --> Router Class Initialized
INFO - 2017-01-21 23:47:52 --> Output Class Initialized
INFO - 2017-01-21 23:47:52 --> Security Class Initialized
DEBUG - 2017-01-21 23:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:47:52 --> Input Class Initialized
INFO - 2017-01-21 23:47:52 --> Language Class Initialized
INFO - 2017-01-21 23:47:52 --> Loader Class Initialized
INFO - 2017-01-21 23:47:52 --> Database Driver Class Initialized
INFO - 2017-01-21 23:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:47:52 --> Controller Class Initialized
INFO - 2017-01-21 23:47:52 --> Helper loaded: url_helper
DEBUG - 2017-01-21 23:47:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 23:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-21 23:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-21 23:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 23:47:52 --> Final output sent to browser
DEBUG - 2017-01-21 23:47:52 --> Total execution time: 0.0137
INFO - 2017-01-21 23:48:27 --> Config Class Initialized
INFO - 2017-01-21 23:48:27 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:48:27 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:48:27 --> Utf8 Class Initialized
INFO - 2017-01-21 23:48:27 --> URI Class Initialized
INFO - 2017-01-21 23:48:27 --> Router Class Initialized
INFO - 2017-01-21 23:48:27 --> Output Class Initialized
INFO - 2017-01-21 23:48:27 --> Security Class Initialized
DEBUG - 2017-01-21 23:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:48:27 --> Input Class Initialized
INFO - 2017-01-21 23:48:27 --> Language Class Initialized
INFO - 2017-01-21 23:48:27 --> Loader Class Initialized
INFO - 2017-01-21 23:48:27 --> Database Driver Class Initialized
INFO - 2017-01-21 23:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:48:27 --> Controller Class Initialized
INFO - 2017-01-21 23:48:27 --> Helper loaded: url_helper
DEBUG - 2017-01-21 23:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:48:27 --> Config Class Initialized
INFO - 2017-01-21 23:48:27 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:48:27 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:48:27 --> Utf8 Class Initialized
INFO - 2017-01-21 23:48:27 --> URI Class Initialized
INFO - 2017-01-21 23:48:27 --> Router Class Initialized
INFO - 2017-01-21 23:48:27 --> Output Class Initialized
INFO - 2017-01-21 23:48:27 --> Security Class Initialized
DEBUG - 2017-01-21 23:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:48:27 --> Input Class Initialized
INFO - 2017-01-21 23:48:27 --> Language Class Initialized
INFO - 2017-01-21 23:48:27 --> Loader Class Initialized
INFO - 2017-01-21 23:48:27 --> Database Driver Class Initialized
INFO - 2017-01-21 23:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:48:27 --> Controller Class Initialized
INFO - 2017-01-21 23:48:27 --> Helper loaded: date_helper
DEBUG - 2017-01-21 23:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:48:27 --> Helper loaded: url_helper
INFO - 2017-01-21 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-21 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 23:48:27 --> Final output sent to browser
DEBUG - 2017-01-21 23:48:27 --> Total execution time: 0.0269
INFO - 2017-01-21 23:48:39 --> Config Class Initialized
INFO - 2017-01-21 23:48:39 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:48:39 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:48:39 --> Utf8 Class Initialized
INFO - 2017-01-21 23:48:39 --> URI Class Initialized
INFO - 2017-01-21 23:48:39 --> Router Class Initialized
INFO - 2017-01-21 23:48:39 --> Output Class Initialized
INFO - 2017-01-21 23:48:39 --> Security Class Initialized
DEBUG - 2017-01-21 23:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:48:39 --> Input Class Initialized
INFO - 2017-01-21 23:48:39 --> Language Class Initialized
INFO - 2017-01-21 23:48:39 --> Loader Class Initialized
INFO - 2017-01-21 23:48:39 --> Database Driver Class Initialized
INFO - 2017-01-21 23:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:48:39 --> Controller Class Initialized
INFO - 2017-01-21 23:48:39 --> Helper loaded: date_helper
DEBUG - 2017-01-21 23:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:48:39 --> Helper loaded: url_helper
INFO - 2017-01-21 23:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 23:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 23:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-21 23:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-21 23:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 23:48:39 --> Final output sent to browser
DEBUG - 2017-01-21 23:48:39 --> Total execution time: 0.0154
INFO - 2017-01-21 23:49:01 --> Config Class Initialized
INFO - 2017-01-21 23:49:01 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:49:01 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:49:01 --> Utf8 Class Initialized
INFO - 2017-01-21 23:49:01 --> URI Class Initialized
INFO - 2017-01-21 23:49:01 --> Router Class Initialized
INFO - 2017-01-21 23:49:01 --> Output Class Initialized
INFO - 2017-01-21 23:49:01 --> Security Class Initialized
DEBUG - 2017-01-21 23:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:49:01 --> Input Class Initialized
INFO - 2017-01-21 23:49:01 --> Language Class Initialized
INFO - 2017-01-21 23:49:01 --> Loader Class Initialized
INFO - 2017-01-21 23:49:01 --> Database Driver Class Initialized
INFO - 2017-01-21 23:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:49:01 --> Controller Class Initialized
INFO - 2017-01-21 23:49:01 --> Helper loaded: date_helper
DEBUG - 2017-01-21 23:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:49:01 --> Helper loaded: url_helper
INFO - 2017-01-21 23:49:01 --> Helper loaded: download_helper
INFO - 2017-01-21 23:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 23:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 23:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-21 23:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-21 23:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 23:49:01 --> Final output sent to browser
DEBUG - 2017-01-21 23:49:01 --> Total execution time: 0.0459
INFO - 2017-01-21 23:49:16 --> Config Class Initialized
INFO - 2017-01-21 23:49:16 --> Hooks Class Initialized
DEBUG - 2017-01-21 23:49:16 --> UTF-8 Support Enabled
INFO - 2017-01-21 23:49:16 --> Utf8 Class Initialized
INFO - 2017-01-21 23:49:16 --> URI Class Initialized
INFO - 2017-01-21 23:49:16 --> Router Class Initialized
INFO - 2017-01-21 23:49:16 --> Output Class Initialized
INFO - 2017-01-21 23:49:16 --> Security Class Initialized
DEBUG - 2017-01-21 23:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-21 23:49:16 --> Input Class Initialized
INFO - 2017-01-21 23:49:16 --> Language Class Initialized
INFO - 2017-01-21 23:49:16 --> Loader Class Initialized
INFO - 2017-01-21 23:49:16 --> Database Driver Class Initialized
INFO - 2017-01-21 23:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-21 23:49:16 --> Controller Class Initialized
INFO - 2017-01-21 23:49:16 --> Upload Class Initialized
INFO - 2017-01-21 23:49:16 --> Helper loaded: date_helper
DEBUG - 2017-01-21 23:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-21 23:49:16 --> Helper loaded: url_helper
INFO - 2017-01-21 23:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-21 23:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-21 23:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-21 23:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-21 23:49:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-21 23:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-21 23:49:16 --> Final output sent to browser
DEBUG - 2017-01-21 23:49:16 --> Total execution time: 0.1640

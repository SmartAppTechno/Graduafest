<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-07 01:25:35 --> Config Class Initialized
INFO - 2017-02-07 01:25:35 --> Hooks Class Initialized
DEBUG - 2017-02-07 01:25:35 --> UTF-8 Support Enabled
INFO - 2017-02-07 01:25:35 --> Utf8 Class Initialized
INFO - 2017-02-07 01:25:35 --> URI Class Initialized
DEBUG - 2017-02-07 01:25:35 --> No URI present. Default controller set.
INFO - 2017-02-07 01:25:35 --> Router Class Initialized
INFO - 2017-02-07 01:25:35 --> Output Class Initialized
INFO - 2017-02-07 01:25:35 --> Security Class Initialized
DEBUG - 2017-02-07 01:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 01:25:35 --> Input Class Initialized
INFO - 2017-02-07 01:25:35 --> Language Class Initialized
INFO - 2017-02-07 01:25:35 --> Loader Class Initialized
INFO - 2017-02-07 01:25:36 --> Database Driver Class Initialized
INFO - 2017-02-07 01:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 01:25:36 --> Controller Class Initialized
INFO - 2017-02-07 01:25:36 --> Helper loaded: url_helper
DEBUG - 2017-02-07 01:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 01:25:36 --> Final output sent to browser
DEBUG - 2017-02-07 01:25:36 --> Total execution time: 1.6598
INFO - 2017-02-07 01:50:41 --> Config Class Initialized
INFO - 2017-02-07 01:50:41 --> Hooks Class Initialized
DEBUG - 2017-02-07 01:50:41 --> UTF-8 Support Enabled
INFO - 2017-02-07 01:50:41 --> Utf8 Class Initialized
INFO - 2017-02-07 01:50:41 --> URI Class Initialized
INFO - 2017-02-07 01:50:41 --> Router Class Initialized
INFO - 2017-02-07 01:50:41 --> Output Class Initialized
INFO - 2017-02-07 01:50:41 --> Security Class Initialized
DEBUG - 2017-02-07 01:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 01:50:41 --> Input Class Initialized
INFO - 2017-02-07 01:50:41 --> Language Class Initialized
INFO - 2017-02-07 01:50:41 --> Loader Class Initialized
INFO - 2017-02-07 01:50:42 --> Database Driver Class Initialized
INFO - 2017-02-07 01:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 01:50:42 --> Controller Class Initialized
INFO - 2017-02-07 01:50:42 --> Helper loaded: url_helper
DEBUG - 2017-02-07 01:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 01:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 01:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 01:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 01:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 01:50:42 --> Final output sent to browser
DEBUG - 2017-02-07 01:50:42 --> Total execution time: 1.4895
INFO - 2017-02-07 01:50:48 --> Config Class Initialized
INFO - 2017-02-07 01:50:48 --> Hooks Class Initialized
DEBUG - 2017-02-07 01:50:48 --> UTF-8 Support Enabled
INFO - 2017-02-07 01:50:48 --> Utf8 Class Initialized
INFO - 2017-02-07 01:50:48 --> URI Class Initialized
DEBUG - 2017-02-07 01:50:48 --> No URI present. Default controller set.
INFO - 2017-02-07 01:50:48 --> Router Class Initialized
INFO - 2017-02-07 01:50:48 --> Output Class Initialized
INFO - 2017-02-07 01:50:48 --> Security Class Initialized
DEBUG - 2017-02-07 01:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 01:50:48 --> Input Class Initialized
INFO - 2017-02-07 01:50:48 --> Language Class Initialized
INFO - 2017-02-07 01:50:48 --> Loader Class Initialized
INFO - 2017-02-07 01:50:48 --> Database Driver Class Initialized
INFO - 2017-02-07 01:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 01:50:48 --> Controller Class Initialized
INFO - 2017-02-07 01:50:48 --> Helper loaded: url_helper
DEBUG - 2017-02-07 01:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 01:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 01:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 01:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 01:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 01:50:48 --> Final output sent to browser
DEBUG - 2017-02-07 01:50:48 --> Total execution time: 0.0280
INFO - 2017-02-07 01:51:18 --> Config Class Initialized
INFO - 2017-02-07 01:51:18 --> Hooks Class Initialized
DEBUG - 2017-02-07 01:51:18 --> UTF-8 Support Enabled
INFO - 2017-02-07 01:51:18 --> Utf8 Class Initialized
INFO - 2017-02-07 01:51:18 --> URI Class Initialized
INFO - 2017-02-07 01:51:18 --> Router Class Initialized
INFO - 2017-02-07 01:51:18 --> Output Class Initialized
INFO - 2017-02-07 01:51:18 --> Security Class Initialized
DEBUG - 2017-02-07 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 01:51:18 --> Input Class Initialized
INFO - 2017-02-07 01:51:18 --> Language Class Initialized
INFO - 2017-02-07 01:51:18 --> Loader Class Initialized
INFO - 2017-02-07 01:51:19 --> Database Driver Class Initialized
INFO - 2017-02-07 01:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 01:51:19 --> Controller Class Initialized
INFO - 2017-02-07 01:51:19 --> Helper loaded: url_helper
DEBUG - 2017-02-07 01:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 01:51:19 --> Final output sent to browser
DEBUG - 2017-02-07 01:51:19 --> Total execution time: 0.9095
INFO - 2017-02-07 01:51:19 --> Config Class Initialized
INFO - 2017-02-07 01:51:19 --> Hooks Class Initialized
DEBUG - 2017-02-07 01:51:19 --> UTF-8 Support Enabled
INFO - 2017-02-07 01:51:19 --> Utf8 Class Initialized
INFO - 2017-02-07 01:51:19 --> URI Class Initialized
DEBUG - 2017-02-07 01:51:19 --> No URI present. Default controller set.
INFO - 2017-02-07 01:51:19 --> Router Class Initialized
INFO - 2017-02-07 01:51:19 --> Output Class Initialized
INFO - 2017-02-07 01:51:19 --> Security Class Initialized
DEBUG - 2017-02-07 01:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 01:51:19 --> Input Class Initialized
INFO - 2017-02-07 01:51:19 --> Language Class Initialized
INFO - 2017-02-07 01:51:19 --> Loader Class Initialized
INFO - 2017-02-07 01:51:19 --> Database Driver Class Initialized
INFO - 2017-02-07 01:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 01:51:19 --> Controller Class Initialized
INFO - 2017-02-07 01:51:19 --> Helper loaded: url_helper
DEBUG - 2017-02-07 01:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 01:51:19 --> Final output sent to browser
DEBUG - 2017-02-07 01:51:19 --> Total execution time: 0.2405
INFO - 2017-02-07 02:22:58 --> Config Class Initialized
INFO - 2017-02-07 02:22:58 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:22:58 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:22:58 --> Utf8 Class Initialized
INFO - 2017-02-07 02:22:58 --> URI Class Initialized
DEBUG - 2017-02-07 02:22:58 --> No URI present. Default controller set.
INFO - 2017-02-07 02:22:58 --> Router Class Initialized
INFO - 2017-02-07 02:22:58 --> Output Class Initialized
INFO - 2017-02-07 02:22:58 --> Security Class Initialized
DEBUG - 2017-02-07 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:22:59 --> Input Class Initialized
INFO - 2017-02-07 02:22:59 --> Language Class Initialized
INFO - 2017-02-07 02:22:59 --> Loader Class Initialized
INFO - 2017-02-07 02:22:59 --> Database Driver Class Initialized
INFO - 2017-02-07 02:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:22:59 --> Controller Class Initialized
INFO - 2017-02-07 02:22:59 --> Helper loaded: url_helper
DEBUG - 2017-02-07 02:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:22:59 --> Final output sent to browser
DEBUG - 2017-02-07 02:22:59 --> Total execution time: 1.1454
INFO - 2017-02-07 02:23:08 --> Config Class Initialized
INFO - 2017-02-07 02:23:08 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:23:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:23:08 --> Utf8 Class Initialized
INFO - 2017-02-07 02:23:08 --> URI Class Initialized
INFO - 2017-02-07 02:23:08 --> Router Class Initialized
INFO - 2017-02-07 02:23:08 --> Output Class Initialized
INFO - 2017-02-07 02:23:08 --> Security Class Initialized
DEBUG - 2017-02-07 02:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:23:08 --> Input Class Initialized
INFO - 2017-02-07 02:23:08 --> Language Class Initialized
INFO - 2017-02-07 02:23:08 --> Loader Class Initialized
INFO - 2017-02-07 02:23:08 --> Database Driver Class Initialized
INFO - 2017-02-07 02:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:23:08 --> Controller Class Initialized
INFO - 2017-02-07 02:23:08 --> Helper loaded: url_helper
DEBUG - 2017-02-07 02:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:23:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:23:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 02:23:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 02:23:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:23:08 --> Final output sent to browser
DEBUG - 2017-02-07 02:23:08 --> Total execution time: 0.0144
INFO - 2017-02-07 02:23:56 --> Config Class Initialized
INFO - 2017-02-07 02:23:56 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:23:56 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:23:56 --> Utf8 Class Initialized
INFO - 2017-02-07 02:23:56 --> URI Class Initialized
INFO - 2017-02-07 02:23:56 --> Router Class Initialized
INFO - 2017-02-07 02:23:56 --> Output Class Initialized
INFO - 2017-02-07 02:23:56 --> Security Class Initialized
DEBUG - 2017-02-07 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:23:56 --> Input Class Initialized
INFO - 2017-02-07 02:23:56 --> Language Class Initialized
INFO - 2017-02-07 02:23:56 --> Loader Class Initialized
INFO - 2017-02-07 02:23:57 --> Database Driver Class Initialized
INFO - 2017-02-07 02:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:23:57 --> Controller Class Initialized
INFO - 2017-02-07 02:23:57 --> Helper loaded: url_helper
DEBUG - 2017-02-07 02:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:24:01 --> Config Class Initialized
INFO - 2017-02-07 02:24:01 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:24:01 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:24:01 --> Utf8 Class Initialized
INFO - 2017-02-07 02:24:01 --> URI Class Initialized
INFO - 2017-02-07 02:24:01 --> Router Class Initialized
INFO - 2017-02-07 02:24:01 --> Output Class Initialized
INFO - 2017-02-07 02:24:01 --> Security Class Initialized
DEBUG - 2017-02-07 02:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:24:02 --> Input Class Initialized
INFO - 2017-02-07 02:24:02 --> Language Class Initialized
INFO - 2017-02-07 02:24:02 --> Loader Class Initialized
INFO - 2017-02-07 02:24:02 --> Database Driver Class Initialized
INFO - 2017-02-07 02:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:24:02 --> Controller Class Initialized
INFO - 2017-02-07 02:24:02 --> Helper loaded: date_helper
DEBUG - 2017-02-07 02:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:24:02 --> Helper loaded: url_helper
INFO - 2017-02-07 02:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 02:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 02:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 02:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:24:02 --> Final output sent to browser
DEBUG - 2017-02-07 02:24:02 --> Total execution time: 0.9235
INFO - 2017-02-07 02:24:03 --> Config Class Initialized
INFO - 2017-02-07 02:24:03 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:24:03 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:24:03 --> Utf8 Class Initialized
INFO - 2017-02-07 02:24:03 --> URI Class Initialized
INFO - 2017-02-07 02:24:03 --> Router Class Initialized
INFO - 2017-02-07 02:24:03 --> Output Class Initialized
INFO - 2017-02-07 02:24:03 --> Security Class Initialized
DEBUG - 2017-02-07 02:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:24:03 --> Input Class Initialized
INFO - 2017-02-07 02:24:03 --> Language Class Initialized
INFO - 2017-02-07 02:24:03 --> Loader Class Initialized
INFO - 2017-02-07 02:24:03 --> Database Driver Class Initialized
INFO - 2017-02-07 02:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:24:03 --> Controller Class Initialized
INFO - 2017-02-07 02:24:03 --> Helper loaded: url_helper
DEBUG - 2017-02-07 02:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 02:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 02:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:24:03 --> Final output sent to browser
DEBUG - 2017-02-07 02:24:03 --> Total execution time: 0.3940
INFO - 2017-02-07 02:24:17 --> Config Class Initialized
INFO - 2017-02-07 02:24:17 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:24:17 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:24:17 --> Utf8 Class Initialized
INFO - 2017-02-07 02:24:17 --> URI Class Initialized
DEBUG - 2017-02-07 02:24:17 --> No URI present. Default controller set.
INFO - 2017-02-07 02:24:17 --> Router Class Initialized
INFO - 2017-02-07 02:24:17 --> Output Class Initialized
INFO - 2017-02-07 02:24:17 --> Security Class Initialized
DEBUG - 2017-02-07 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:24:17 --> Input Class Initialized
INFO - 2017-02-07 02:24:17 --> Language Class Initialized
INFO - 2017-02-07 02:24:17 --> Loader Class Initialized
INFO - 2017-02-07 02:24:17 --> Database Driver Class Initialized
INFO - 2017-02-07 02:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:24:17 --> Controller Class Initialized
INFO - 2017-02-07 02:24:17 --> Helper loaded: url_helper
DEBUG - 2017-02-07 02:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:24:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:24:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 02:24:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 02:24:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:24:17 --> Final output sent to browser
DEBUG - 2017-02-07 02:24:17 --> Total execution time: 0.7432
INFO - 2017-02-07 02:24:19 --> Config Class Initialized
INFO - 2017-02-07 02:24:19 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:24:19 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:24:19 --> Utf8 Class Initialized
INFO - 2017-02-07 02:24:19 --> URI Class Initialized
INFO - 2017-02-07 02:24:19 --> Router Class Initialized
INFO - 2017-02-07 02:24:19 --> Output Class Initialized
INFO - 2017-02-07 02:24:19 --> Security Class Initialized
DEBUG - 2017-02-07 02:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:24:19 --> Input Class Initialized
INFO - 2017-02-07 02:24:19 --> Language Class Initialized
INFO - 2017-02-07 02:24:19 --> Loader Class Initialized
INFO - 2017-02-07 02:24:19 --> Database Driver Class Initialized
INFO - 2017-02-07 02:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:24:20 --> Controller Class Initialized
INFO - 2017-02-07 02:24:20 --> Helper loaded: url_helper
DEBUG - 2017-02-07 02:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 02:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 02:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:24:20 --> Final output sent to browser
DEBUG - 2017-02-07 02:24:20 --> Total execution time: 0.8204
INFO - 2017-02-07 02:41:07 --> Config Class Initialized
INFO - 2017-02-07 02:41:07 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:41:07 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:41:07 --> Utf8 Class Initialized
INFO - 2017-02-07 02:41:07 --> URI Class Initialized
INFO - 2017-02-07 02:41:07 --> Router Class Initialized
INFO - 2017-02-07 02:41:07 --> Output Class Initialized
INFO - 2017-02-07 02:41:07 --> Security Class Initialized
DEBUG - 2017-02-07 02:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:41:07 --> Input Class Initialized
INFO - 2017-02-07 02:41:07 --> Language Class Initialized
INFO - 2017-02-07 02:41:07 --> Loader Class Initialized
INFO - 2017-02-07 02:41:08 --> Database Driver Class Initialized
INFO - 2017-02-07 02:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:41:08 --> Controller Class Initialized
INFO - 2017-02-07 02:41:08 --> Helper loaded: date_helper
DEBUG - 2017-02-07 02:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:41:08 --> Helper loaded: url_helper
INFO - 2017-02-07 02:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 02:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 02:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 02:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:41:08 --> Final output sent to browser
DEBUG - 2017-02-07 02:41:08 --> Total execution time: 0.7716
INFO - 2017-02-07 02:41:12 --> Config Class Initialized
INFO - 2017-02-07 02:41:12 --> Hooks Class Initialized
DEBUG - 2017-02-07 02:41:12 --> UTF-8 Support Enabled
INFO - 2017-02-07 02:41:12 --> Utf8 Class Initialized
INFO - 2017-02-07 02:41:12 --> URI Class Initialized
INFO - 2017-02-07 02:41:12 --> Router Class Initialized
INFO - 2017-02-07 02:41:12 --> Output Class Initialized
INFO - 2017-02-07 02:41:12 --> Security Class Initialized
DEBUG - 2017-02-07 02:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 02:41:12 --> Input Class Initialized
INFO - 2017-02-07 02:41:12 --> Language Class Initialized
INFO - 2017-02-07 02:41:12 --> Loader Class Initialized
INFO - 2017-02-07 02:41:12 --> Database Driver Class Initialized
INFO - 2017-02-07 02:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 02:41:12 --> Controller Class Initialized
INFO - 2017-02-07 02:41:12 --> Helper loaded: url_helper
DEBUG - 2017-02-07 02:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 02:41:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 02:41:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 02:41:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 02:41:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 02:41:12 --> Final output sent to browser
DEBUG - 2017-02-07 02:41:12 --> Total execution time: 0.1309
INFO - 2017-02-07 04:34:53 --> Config Class Initialized
INFO - 2017-02-07 04:34:53 --> Hooks Class Initialized
DEBUG - 2017-02-07 04:34:54 --> UTF-8 Support Enabled
INFO - 2017-02-07 04:34:54 --> Utf8 Class Initialized
INFO - 2017-02-07 04:34:54 --> URI Class Initialized
INFO - 2017-02-07 04:34:54 --> Router Class Initialized
INFO - 2017-02-07 04:34:54 --> Output Class Initialized
INFO - 2017-02-07 04:34:54 --> Security Class Initialized
DEBUG - 2017-02-07 04:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 04:34:54 --> Input Class Initialized
INFO - 2017-02-07 04:34:54 --> Language Class Initialized
INFO - 2017-02-07 04:34:54 --> Loader Class Initialized
INFO - 2017-02-07 04:34:54 --> Database Driver Class Initialized
INFO - 2017-02-07 04:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 04:34:54 --> Controller Class Initialized
INFO - 2017-02-07 04:34:54 --> Helper loaded: url_helper
DEBUG - 2017-02-07 04:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 04:34:55 --> Final output sent to browser
DEBUG - 2017-02-07 04:34:55 --> Total execution time: 1.3230
INFO - 2017-02-07 04:34:55 --> Config Class Initialized
INFO - 2017-02-07 04:34:55 --> Hooks Class Initialized
DEBUG - 2017-02-07 04:34:55 --> UTF-8 Support Enabled
INFO - 2017-02-07 04:34:55 --> Utf8 Class Initialized
INFO - 2017-02-07 04:34:55 --> URI Class Initialized
DEBUG - 2017-02-07 04:34:55 --> No URI present. Default controller set.
INFO - 2017-02-07 04:34:55 --> Router Class Initialized
INFO - 2017-02-07 04:34:55 --> Output Class Initialized
INFO - 2017-02-07 04:34:55 --> Security Class Initialized
DEBUG - 2017-02-07 04:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 04:34:55 --> Input Class Initialized
INFO - 2017-02-07 04:34:55 --> Language Class Initialized
INFO - 2017-02-07 04:34:55 --> Loader Class Initialized
INFO - 2017-02-07 04:34:55 --> Database Driver Class Initialized
INFO - 2017-02-07 04:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 04:34:55 --> Controller Class Initialized
INFO - 2017-02-07 04:34:55 --> Helper loaded: url_helper
DEBUG - 2017-02-07 04:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 04:34:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 04:34:55 --> Final output sent to browser
DEBUG - 2017-02-07 04:34:55 --> Total execution time: 0.0150
INFO - 2017-02-07 04:57:26 --> Config Class Initialized
INFO - 2017-02-07 04:57:26 --> Hooks Class Initialized
DEBUG - 2017-02-07 04:57:27 --> UTF-8 Support Enabled
INFO - 2017-02-07 04:57:27 --> Utf8 Class Initialized
INFO - 2017-02-07 04:57:27 --> URI Class Initialized
INFO - 2017-02-07 04:57:27 --> Router Class Initialized
INFO - 2017-02-07 04:57:27 --> Output Class Initialized
INFO - 2017-02-07 04:57:27 --> Security Class Initialized
DEBUG - 2017-02-07 04:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 04:57:27 --> Input Class Initialized
INFO - 2017-02-07 04:57:27 --> Language Class Initialized
ERROR - 2017-02-07 04:57:27 --> 404 Page Not Found: Phone/index.html
INFO - 2017-02-07 04:58:10 --> Config Class Initialized
INFO - 2017-02-07 04:58:10 --> Hooks Class Initialized
DEBUG - 2017-02-07 04:58:10 --> UTF-8 Support Enabled
INFO - 2017-02-07 04:58:10 --> Utf8 Class Initialized
INFO - 2017-02-07 04:58:10 --> URI Class Initialized
INFO - 2017-02-07 04:58:10 --> Router Class Initialized
INFO - 2017-02-07 04:58:10 --> Output Class Initialized
INFO - 2017-02-07 04:58:10 --> Security Class Initialized
DEBUG - 2017-02-07 04:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 04:58:10 --> Input Class Initialized
INFO - 2017-02-07 04:58:10 --> Language Class Initialized
ERROR - 2017-02-07 04:58:10 --> 404 Page Not Found: Phone/index.html
INFO - 2017-02-07 04:59:00 --> Config Class Initialized
INFO - 2017-02-07 04:59:00 --> Hooks Class Initialized
DEBUG - 2017-02-07 04:59:01 --> UTF-8 Support Enabled
INFO - 2017-02-07 04:59:01 --> Utf8 Class Initialized
INFO - 2017-02-07 04:59:01 --> URI Class Initialized
DEBUG - 2017-02-07 04:59:01 --> No URI present. Default controller set.
INFO - 2017-02-07 04:59:01 --> Router Class Initialized
INFO - 2017-02-07 04:59:01 --> Output Class Initialized
INFO - 2017-02-07 04:59:01 --> Security Class Initialized
DEBUG - 2017-02-07 04:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 04:59:01 --> Input Class Initialized
INFO - 2017-02-07 04:59:01 --> Language Class Initialized
INFO - 2017-02-07 04:59:01 --> Loader Class Initialized
INFO - 2017-02-07 04:59:01 --> Database Driver Class Initialized
INFO - 2017-02-07 04:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 04:59:01 --> Controller Class Initialized
INFO - 2017-02-07 04:59:01 --> Helper loaded: url_helper
DEBUG - 2017-02-07 04:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 04:59:01 --> Final output sent to browser
DEBUG - 2017-02-07 04:59:01 --> Total execution time: 1.0239
INFO - 2017-02-07 05:00:49 --> Config Class Initialized
INFO - 2017-02-07 05:00:50 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:00:50 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:00:50 --> Utf8 Class Initialized
INFO - 2017-02-07 05:00:50 --> URI Class Initialized
INFO - 2017-02-07 05:00:50 --> Router Class Initialized
INFO - 2017-02-07 05:00:50 --> Output Class Initialized
INFO - 2017-02-07 05:00:50 --> Security Class Initialized
DEBUG - 2017-02-07 05:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:00:50 --> Input Class Initialized
INFO - 2017-02-07 05:00:50 --> Language Class Initialized
INFO - 2017-02-07 05:00:50 --> Loader Class Initialized
INFO - 2017-02-07 05:00:50 --> Database Driver Class Initialized
INFO - 2017-02-07 05:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:00:50 --> Controller Class Initialized
INFO - 2017-02-07 05:00:50 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:00:51 --> Final output sent to browser
DEBUG - 2017-02-07 05:00:51 --> Total execution time: 0.7979
INFO - 2017-02-07 05:00:58 --> Config Class Initialized
INFO - 2017-02-07 05:00:58 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:00:58 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:00:58 --> Utf8 Class Initialized
INFO - 2017-02-07 05:00:58 --> URI Class Initialized
INFO - 2017-02-07 05:00:58 --> Router Class Initialized
INFO - 2017-02-07 05:00:58 --> Output Class Initialized
INFO - 2017-02-07 05:00:58 --> Security Class Initialized
DEBUG - 2017-02-07 05:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:00:58 --> Input Class Initialized
INFO - 2017-02-07 05:00:58 --> Language Class Initialized
INFO - 2017-02-07 05:00:58 --> Loader Class Initialized
INFO - 2017-02-07 05:00:59 --> Database Driver Class Initialized
INFO - 2017-02-07 05:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:00:59 --> Controller Class Initialized
INFO - 2017-02-07 05:00:59 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:00:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:00:59 --> Final output sent to browser
DEBUG - 2017-02-07 05:00:59 --> Total execution time: 0.6988
INFO - 2017-02-07 05:01:04 --> Config Class Initialized
INFO - 2017-02-07 05:01:04 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:01:04 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:04 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:04 --> URI Class Initialized
INFO - 2017-02-07 05:01:04 --> Router Class Initialized
INFO - 2017-02-07 05:01:04 --> Output Class Initialized
INFO - 2017-02-07 05:01:04 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:04 --> Input Class Initialized
INFO - 2017-02-07 05:01:04 --> Language Class Initialized
INFO - 2017-02-07 05:01:04 --> Loader Class Initialized
INFO - 2017-02-07 05:01:04 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:05 --> Controller Class Initialized
INFO - 2017-02-07 05:01:05 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:05 --> Config Class Initialized
INFO - 2017-02-07 05:01:05 --> Hooks Class Initialized
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-02-07 05:01:05 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:05 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:05 --> URI Class Initialized
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:05 --> Router Class Initialized
INFO - 2017-02-07 05:01:05 --> Output Class Initialized
INFO - 2017-02-07 05:01:05 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:05 --> Input Class Initialized
INFO - 2017-02-07 05:01:05 --> Language Class Initialized
INFO - 2017-02-07 05:01:05 --> Loader Class Initialized
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:05 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:05 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:05 --> Total execution time: 0.9456
INFO - 2017-02-07 05:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:05 --> Controller Class Initialized
INFO - 2017-02-07 05:01:05 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:05 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:05 --> Total execution time: 0.4070
INFO - 2017-02-07 05:01:08 --> Config Class Initialized
INFO - 2017-02-07 05:01:08 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:01:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:08 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:08 --> URI Class Initialized
INFO - 2017-02-07 05:01:08 --> Router Class Initialized
INFO - 2017-02-07 05:01:08 --> Output Class Initialized
INFO - 2017-02-07 05:01:08 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:08 --> Input Class Initialized
INFO - 2017-02-07 05:01:08 --> Language Class Initialized
INFO - 2017-02-07 05:01:08 --> Loader Class Initialized
INFO - 2017-02-07 05:01:08 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:08 --> Controller Class Initialized
INFO - 2017-02-07 05:01:08 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:08 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:08 --> Total execution time: 0.0134
INFO - 2017-02-07 05:01:14 --> Config Class Initialized
INFO - 2017-02-07 05:01:14 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:01:14 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:14 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:14 --> URI Class Initialized
INFO - 2017-02-07 05:01:14 --> Router Class Initialized
INFO - 2017-02-07 05:01:14 --> Output Class Initialized
INFO - 2017-02-07 05:01:14 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:14 --> Input Class Initialized
INFO - 2017-02-07 05:01:14 --> Language Class Initialized
INFO - 2017-02-07 05:01:14 --> Loader Class Initialized
INFO - 2017-02-07 05:01:14 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:14 --> Controller Class Initialized
INFO - 2017-02-07 05:01:14 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:14 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:14 --> Total execution time: 0.0133
INFO - 2017-02-07 05:01:17 --> Config Class Initialized
INFO - 2017-02-07 05:01:17 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:01:17 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:17 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:17 --> URI Class Initialized
INFO - 2017-02-07 05:01:17 --> Router Class Initialized
INFO - 2017-02-07 05:01:17 --> Output Class Initialized
INFO - 2017-02-07 05:01:17 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:17 --> Input Class Initialized
INFO - 2017-02-07 05:01:17 --> Language Class Initialized
INFO - 2017-02-07 05:01:17 --> Loader Class Initialized
INFO - 2017-02-07 05:01:17 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:17 --> Controller Class Initialized
INFO - 2017-02-07 05:01:17 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:17 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:17 --> Total execution time: 0.6903
INFO - 2017-02-07 05:01:18 --> Config Class Initialized
INFO - 2017-02-07 05:01:18 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:01:18 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:18 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:18 --> URI Class Initialized
DEBUG - 2017-02-07 05:01:18 --> No URI present. Default controller set.
INFO - 2017-02-07 05:01:18 --> Router Class Initialized
INFO - 2017-02-07 05:01:18 --> Output Class Initialized
INFO - 2017-02-07 05:01:18 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:18 --> Input Class Initialized
INFO - 2017-02-07 05:01:18 --> Language Class Initialized
INFO - 2017-02-07 05:01:18 --> Loader Class Initialized
INFO - 2017-02-07 05:01:18 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:19 --> Controller Class Initialized
INFO - 2017-02-07 05:01:19 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:19 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:19 --> Total execution time: 0.9314
INFO - 2017-02-07 05:01:20 --> Config Class Initialized
INFO - 2017-02-07 05:01:20 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:01:20 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:20 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:20 --> URI Class Initialized
INFO - 2017-02-07 05:01:20 --> Router Class Initialized
INFO - 2017-02-07 05:01:20 --> Output Class Initialized
INFO - 2017-02-07 05:01:20 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:20 --> Input Class Initialized
INFO - 2017-02-07 05:01:20 --> Language Class Initialized
INFO - 2017-02-07 05:01:21 --> Loader Class Initialized
INFO - 2017-02-07 05:01:21 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:21 --> Controller Class Initialized
INFO - 2017-02-07 05:01:21 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:21 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:21 --> Total execution time: 0.6516
INFO - 2017-02-07 05:01:39 --> Config Class Initialized
INFO - 2017-02-07 05:01:39 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:01:39 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:01:39 --> Utf8 Class Initialized
INFO - 2017-02-07 05:01:39 --> URI Class Initialized
INFO - 2017-02-07 05:01:39 --> Router Class Initialized
INFO - 2017-02-07 05:01:39 --> Output Class Initialized
INFO - 2017-02-07 05:01:39 --> Security Class Initialized
DEBUG - 2017-02-07 05:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:01:39 --> Input Class Initialized
INFO - 2017-02-07 05:01:39 --> Language Class Initialized
INFO - 2017-02-07 05:01:39 --> Loader Class Initialized
INFO - 2017-02-07 05:01:39 --> Database Driver Class Initialized
INFO - 2017-02-07 05:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:01:39 --> Controller Class Initialized
INFO - 2017-02-07 05:01:39 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:01:39 --> Final output sent to browser
DEBUG - 2017-02-07 05:01:39 --> Total execution time: 0.6976
INFO - 2017-02-07 05:02:07 --> Config Class Initialized
INFO - 2017-02-07 05:02:07 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:02:07 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:02:07 --> Utf8 Class Initialized
INFO - 2017-02-07 05:02:07 --> URI Class Initialized
INFO - 2017-02-07 05:02:07 --> Router Class Initialized
INFO - 2017-02-07 05:02:07 --> Output Class Initialized
INFO - 2017-02-07 05:02:07 --> Security Class Initialized
DEBUG - 2017-02-07 05:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:02:07 --> Input Class Initialized
INFO - 2017-02-07 05:02:07 --> Language Class Initialized
INFO - 2017-02-07 05:02:07 --> Loader Class Initialized
INFO - 2017-02-07 05:02:07 --> Database Driver Class Initialized
INFO - 2017-02-07 05:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:02:07 --> Controller Class Initialized
INFO - 2017-02-07 05:02:07 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:02:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:02:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:02:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:02:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:02:08 --> Final output sent to browser
DEBUG - 2017-02-07 05:02:08 --> Total execution time: 0.6656
INFO - 2017-02-07 05:02:47 --> Config Class Initialized
INFO - 2017-02-07 05:02:47 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:02:47 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:02:47 --> Utf8 Class Initialized
INFO - 2017-02-07 05:02:47 --> URI Class Initialized
INFO - 2017-02-07 05:02:47 --> Router Class Initialized
INFO - 2017-02-07 05:02:47 --> Output Class Initialized
INFO - 2017-02-07 05:02:48 --> Security Class Initialized
DEBUG - 2017-02-07 05:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:02:48 --> Input Class Initialized
INFO - 2017-02-07 05:02:48 --> Language Class Initialized
INFO - 2017-02-07 05:02:48 --> Loader Class Initialized
INFO - 2017-02-07 05:02:48 --> Database Driver Class Initialized
INFO - 2017-02-07 05:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:02:48 --> Controller Class Initialized
INFO - 2017-02-07 05:02:48 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:02:48 --> Final output sent to browser
DEBUG - 2017-02-07 05:02:48 --> Total execution time: 0.7849
INFO - 2017-02-07 05:02:53 --> Config Class Initialized
INFO - 2017-02-07 05:02:53 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:02:53 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:02:53 --> Utf8 Class Initialized
INFO - 2017-02-07 05:02:53 --> URI Class Initialized
INFO - 2017-02-07 05:02:53 --> Router Class Initialized
INFO - 2017-02-07 05:02:53 --> Output Class Initialized
INFO - 2017-02-07 05:02:53 --> Security Class Initialized
DEBUG - 2017-02-07 05:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:02:53 --> Input Class Initialized
INFO - 2017-02-07 05:02:53 --> Language Class Initialized
INFO - 2017-02-07 05:02:53 --> Loader Class Initialized
INFO - 2017-02-07 05:02:54 --> Database Driver Class Initialized
INFO - 2017-02-07 05:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:02:54 --> Controller Class Initialized
INFO - 2017-02-07 05:02:54 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:02:54 --> Final output sent to browser
DEBUG - 2017-02-07 05:02:54 --> Total execution time: 0.6735
INFO - 2017-02-07 05:05:24 --> Config Class Initialized
INFO - 2017-02-07 05:05:24 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:05:24 --> Utf8 Class Initialized
INFO - 2017-02-07 05:05:24 --> URI Class Initialized
INFO - 2017-02-07 05:05:24 --> Router Class Initialized
INFO - 2017-02-07 05:05:24 --> Output Class Initialized
INFO - 2017-02-07 05:05:24 --> Security Class Initialized
DEBUG - 2017-02-07 05:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:05:24 --> Input Class Initialized
INFO - 2017-02-07 05:05:24 --> Language Class Initialized
INFO - 2017-02-07 05:05:24 --> Loader Class Initialized
INFO - 2017-02-07 05:05:24 --> Database Driver Class Initialized
INFO - 2017-02-07 05:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:05:25 --> Controller Class Initialized
INFO - 2017-02-07 05:05:25 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:05:25 --> Final output sent to browser
DEBUG - 2017-02-07 05:05:25 --> Total execution time: 0.9398
INFO - 2017-02-07 05:08:19 --> Config Class Initialized
INFO - 2017-02-07 05:08:19 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:08:19 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:08:19 --> Utf8 Class Initialized
INFO - 2017-02-07 05:08:19 --> URI Class Initialized
DEBUG - 2017-02-07 05:08:19 --> No URI present. Default controller set.
INFO - 2017-02-07 05:08:19 --> Router Class Initialized
INFO - 2017-02-07 05:08:19 --> Output Class Initialized
INFO - 2017-02-07 05:08:19 --> Security Class Initialized
DEBUG - 2017-02-07 05:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:08:19 --> Input Class Initialized
INFO - 2017-02-07 05:08:19 --> Language Class Initialized
INFO - 2017-02-07 05:08:19 --> Loader Class Initialized
INFO - 2017-02-07 05:08:19 --> Database Driver Class Initialized
INFO - 2017-02-07 05:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:08:19 --> Controller Class Initialized
INFO - 2017-02-07 05:08:19 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:08:19 --> Final output sent to browser
DEBUG - 2017-02-07 05:08:19 --> Total execution time: 0.6425
INFO - 2017-02-07 05:08:29 --> Config Class Initialized
INFO - 2017-02-07 05:08:29 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:08:29 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:08:29 --> Utf8 Class Initialized
INFO - 2017-02-07 05:08:29 --> URI Class Initialized
INFO - 2017-02-07 05:08:29 --> Router Class Initialized
INFO - 2017-02-07 05:08:29 --> Output Class Initialized
INFO - 2017-02-07 05:08:29 --> Security Class Initialized
DEBUG - 2017-02-07 05:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:08:29 --> Input Class Initialized
INFO - 2017-02-07 05:08:29 --> Language Class Initialized
INFO - 2017-02-07 05:08:29 --> Loader Class Initialized
INFO - 2017-02-07 05:08:30 --> Database Driver Class Initialized
INFO - 2017-02-07 05:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:08:30 --> Controller Class Initialized
INFO - 2017-02-07 05:08:30 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:08:30 --> Final output sent to browser
DEBUG - 2017-02-07 05:08:30 --> Total execution time: 0.5989
INFO - 2017-02-07 05:11:06 --> Config Class Initialized
INFO - 2017-02-07 05:11:06 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:11:06 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:11:06 --> Utf8 Class Initialized
INFO - 2017-02-07 05:11:06 --> URI Class Initialized
DEBUG - 2017-02-07 05:11:06 --> No URI present. Default controller set.
INFO - 2017-02-07 05:11:06 --> Router Class Initialized
INFO - 2017-02-07 05:11:06 --> Output Class Initialized
INFO - 2017-02-07 05:11:06 --> Security Class Initialized
DEBUG - 2017-02-07 05:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:11:06 --> Input Class Initialized
INFO - 2017-02-07 05:11:06 --> Language Class Initialized
INFO - 2017-02-07 05:11:06 --> Loader Class Initialized
INFO - 2017-02-07 05:11:06 --> Database Driver Class Initialized
INFO - 2017-02-07 05:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:11:06 --> Controller Class Initialized
INFO - 2017-02-07 05:11:06 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:11:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:11:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:11:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:11:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:11:06 --> Final output sent to browser
DEBUG - 2017-02-07 05:11:06 --> Total execution time: 0.5736
INFO - 2017-02-07 05:11:33 --> Config Class Initialized
INFO - 2017-02-07 05:11:33 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:11:33 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:11:33 --> Utf8 Class Initialized
INFO - 2017-02-07 05:11:33 --> URI Class Initialized
INFO - 2017-02-07 05:11:33 --> Router Class Initialized
INFO - 2017-02-07 05:11:33 --> Output Class Initialized
INFO - 2017-02-07 05:11:33 --> Security Class Initialized
DEBUG - 2017-02-07 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:11:33 --> Input Class Initialized
INFO - 2017-02-07 05:11:33 --> Language Class Initialized
INFO - 2017-02-07 05:11:33 --> Loader Class Initialized
INFO - 2017-02-07 05:11:33 --> Database Driver Class Initialized
INFO - 2017-02-07 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:11:33 --> Controller Class Initialized
INFO - 2017-02-07 05:11:33 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:11:37 --> Config Class Initialized
INFO - 2017-02-07 05:11:37 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:11:37 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:11:37 --> Utf8 Class Initialized
INFO - 2017-02-07 05:11:37 --> URI Class Initialized
INFO - 2017-02-07 05:11:37 --> Router Class Initialized
INFO - 2017-02-07 05:11:37 --> Output Class Initialized
INFO - 2017-02-07 05:11:37 --> Security Class Initialized
DEBUG - 2017-02-07 05:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:11:37 --> Input Class Initialized
INFO - 2017-02-07 05:11:37 --> Language Class Initialized
INFO - 2017-02-07 05:11:38 --> Loader Class Initialized
INFO - 2017-02-07 05:11:38 --> Database Driver Class Initialized
INFO - 2017-02-07 05:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:11:38 --> Controller Class Initialized
INFO - 2017-02-07 05:11:38 --> Helper loaded: date_helper
DEBUG - 2017-02-07 05:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:11:38 --> Helper loaded: url_helper
INFO - 2017-02-07 05:11:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:11:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 05:11:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 05:11:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 05:11:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:11:38 --> Final output sent to browser
DEBUG - 2017-02-07 05:11:38 --> Total execution time: 0.5966
INFO - 2017-02-07 05:27:22 --> Config Class Initialized
INFO - 2017-02-07 05:27:22 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:27:22 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:27:22 --> Utf8 Class Initialized
INFO - 2017-02-07 05:27:22 --> URI Class Initialized
DEBUG - 2017-02-07 05:27:23 --> No URI present. Default controller set.
INFO - 2017-02-07 05:27:23 --> Router Class Initialized
INFO - 2017-02-07 05:27:23 --> Output Class Initialized
INFO - 2017-02-07 05:27:23 --> Security Class Initialized
DEBUG - 2017-02-07 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:27:23 --> Input Class Initialized
INFO - 2017-02-07 05:27:23 --> Language Class Initialized
INFO - 2017-02-07 05:27:23 --> Loader Class Initialized
INFO - 2017-02-07 05:27:23 --> Database Driver Class Initialized
INFO - 2017-02-07 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:27:23 --> Controller Class Initialized
INFO - 2017-02-07 05:27:23 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:27:24 --> Final output sent to browser
DEBUG - 2017-02-07 05:27:24 --> Total execution time: 1.4928
INFO - 2017-02-07 05:27:43 --> Config Class Initialized
INFO - 2017-02-07 05:27:43 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:27:43 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:27:43 --> Utf8 Class Initialized
INFO - 2017-02-07 05:27:43 --> URI Class Initialized
INFO - 2017-02-07 05:27:43 --> Router Class Initialized
INFO - 2017-02-07 05:27:43 --> Output Class Initialized
INFO - 2017-02-07 05:27:43 --> Security Class Initialized
DEBUG - 2017-02-07 05:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:27:43 --> Input Class Initialized
INFO - 2017-02-07 05:27:43 --> Language Class Initialized
INFO - 2017-02-07 05:27:43 --> Loader Class Initialized
INFO - 2017-02-07 05:27:43 --> Database Driver Class Initialized
INFO - 2017-02-07 05:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:27:43 --> Controller Class Initialized
INFO - 2017-02-07 05:27:43 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:27:43 --> Final output sent to browser
DEBUG - 2017-02-07 05:27:43 --> Total execution time: 0.0138
INFO - 2017-02-07 05:28:34 --> Config Class Initialized
INFO - 2017-02-07 05:28:34 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:28:34 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:28:34 --> Utf8 Class Initialized
INFO - 2017-02-07 05:28:34 --> URI Class Initialized
INFO - 2017-02-07 05:28:34 --> Router Class Initialized
INFO - 2017-02-07 05:28:34 --> Output Class Initialized
INFO - 2017-02-07 05:28:34 --> Security Class Initialized
DEBUG - 2017-02-07 05:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:28:34 --> Input Class Initialized
INFO - 2017-02-07 05:28:34 --> Language Class Initialized
INFO - 2017-02-07 05:28:34 --> Loader Class Initialized
INFO - 2017-02-07 05:28:34 --> Database Driver Class Initialized
INFO - 2017-02-07 05:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:28:34 --> Controller Class Initialized
INFO - 2017-02-07 05:28:34 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:28:36 --> Config Class Initialized
INFO - 2017-02-07 05:28:36 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:28:36 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:28:36 --> Utf8 Class Initialized
INFO - 2017-02-07 05:28:36 --> URI Class Initialized
INFO - 2017-02-07 05:28:36 --> Router Class Initialized
INFO - 2017-02-07 05:28:36 --> Output Class Initialized
INFO - 2017-02-07 05:28:36 --> Security Class Initialized
DEBUG - 2017-02-07 05:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:28:36 --> Input Class Initialized
INFO - 2017-02-07 05:28:36 --> Language Class Initialized
INFO - 2017-02-07 05:28:36 --> Loader Class Initialized
INFO - 2017-02-07 05:28:36 --> Database Driver Class Initialized
INFO - 2017-02-07 05:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:28:36 --> Controller Class Initialized
INFO - 2017-02-07 05:28:36 --> Helper loaded: date_helper
DEBUG - 2017-02-07 05:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:28:36 --> Helper loaded: url_helper
INFO - 2017-02-07 05:28:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:28:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 05:28:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 05:28:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 05:28:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:28:36 --> Final output sent to browser
DEBUG - 2017-02-07 05:28:36 --> Total execution time: 0.0986
INFO - 2017-02-07 05:28:43 --> Config Class Initialized
INFO - 2017-02-07 05:28:43 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:28:43 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:28:43 --> Utf8 Class Initialized
INFO - 2017-02-07 05:28:43 --> URI Class Initialized
DEBUG - 2017-02-07 05:28:43 --> No URI present. Default controller set.
INFO - 2017-02-07 05:28:43 --> Router Class Initialized
INFO - 2017-02-07 05:28:43 --> Output Class Initialized
INFO - 2017-02-07 05:28:43 --> Security Class Initialized
DEBUG - 2017-02-07 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:28:43 --> Input Class Initialized
INFO - 2017-02-07 05:28:43 --> Language Class Initialized
INFO - 2017-02-07 05:28:43 --> Loader Class Initialized
INFO - 2017-02-07 05:28:43 --> Database Driver Class Initialized
INFO - 2017-02-07 05:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:28:43 --> Controller Class Initialized
INFO - 2017-02-07 05:28:43 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:28:43 --> Final output sent to browser
DEBUG - 2017-02-07 05:28:43 --> Total execution time: 0.0132
INFO - 2017-02-07 05:29:54 --> Config Class Initialized
INFO - 2017-02-07 05:29:54 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:29:54 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:29:54 --> Utf8 Class Initialized
INFO - 2017-02-07 05:29:54 --> URI Class Initialized
INFO - 2017-02-07 05:29:54 --> Router Class Initialized
INFO - 2017-02-07 05:29:54 --> Output Class Initialized
INFO - 2017-02-07 05:29:54 --> Security Class Initialized
DEBUG - 2017-02-07 05:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:29:54 --> Input Class Initialized
INFO - 2017-02-07 05:29:54 --> Language Class Initialized
INFO - 2017-02-07 05:29:54 --> Loader Class Initialized
INFO - 2017-02-07 05:29:54 --> Database Driver Class Initialized
INFO - 2017-02-07 05:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:29:54 --> Controller Class Initialized
INFO - 2017-02-07 05:29:54 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:29:54 --> Final output sent to browser
DEBUG - 2017-02-07 05:29:54 --> Total execution time: 0.0174
INFO - 2017-02-07 05:29:58 --> Config Class Initialized
INFO - 2017-02-07 05:29:58 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:29:58 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:29:58 --> Utf8 Class Initialized
INFO - 2017-02-07 05:29:58 --> URI Class Initialized
INFO - 2017-02-07 05:29:58 --> Router Class Initialized
INFO - 2017-02-07 05:29:58 --> Output Class Initialized
INFO - 2017-02-07 05:29:58 --> Security Class Initialized
DEBUG - 2017-02-07 05:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:29:58 --> Input Class Initialized
INFO - 2017-02-07 05:29:58 --> Language Class Initialized
INFO - 2017-02-07 05:29:58 --> Loader Class Initialized
INFO - 2017-02-07 05:29:58 --> Database Driver Class Initialized
INFO - 2017-02-07 05:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:29:58 --> Controller Class Initialized
INFO - 2017-02-07 05:29:58 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:29:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:29:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:29:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:29:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:29:58 --> Final output sent to browser
DEBUG - 2017-02-07 05:29:58 --> Total execution time: 0.0137
INFO - 2017-02-07 05:30:01 --> Config Class Initialized
INFO - 2017-02-07 05:30:01 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:30:01 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:30:01 --> Utf8 Class Initialized
INFO - 2017-02-07 05:30:01 --> URI Class Initialized
INFO - 2017-02-07 05:30:01 --> Router Class Initialized
INFO - 2017-02-07 05:30:01 --> Output Class Initialized
INFO - 2017-02-07 05:30:01 --> Security Class Initialized
DEBUG - 2017-02-07 05:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:30:01 --> Input Class Initialized
INFO - 2017-02-07 05:30:01 --> Language Class Initialized
INFO - 2017-02-07 05:30:01 --> Loader Class Initialized
INFO - 2017-02-07 05:30:01 --> Database Driver Class Initialized
INFO - 2017-02-07 05:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:30:01 --> Controller Class Initialized
INFO - 2017-02-07 05:30:01 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:30:01 --> Final output sent to browser
DEBUG - 2017-02-07 05:30:01 --> Total execution time: 0.0142
INFO - 2017-02-07 05:30:04 --> Config Class Initialized
INFO - 2017-02-07 05:30:04 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:30:04 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:30:04 --> Utf8 Class Initialized
INFO - 2017-02-07 05:30:04 --> URI Class Initialized
INFO - 2017-02-07 05:30:04 --> Router Class Initialized
INFO - 2017-02-07 05:30:04 --> Output Class Initialized
INFO - 2017-02-07 05:30:04 --> Security Class Initialized
DEBUG - 2017-02-07 05:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:30:04 --> Input Class Initialized
INFO - 2017-02-07 05:30:04 --> Language Class Initialized
INFO - 2017-02-07 05:30:04 --> Loader Class Initialized
INFO - 2017-02-07 05:30:04 --> Database Driver Class Initialized
INFO - 2017-02-07 05:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:30:04 --> Controller Class Initialized
INFO - 2017-02-07 05:30:04 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:30:04 --> Final output sent to browser
DEBUG - 2017-02-07 05:30:04 --> Total execution time: 0.0134
INFO - 2017-02-07 05:30:19 --> Config Class Initialized
INFO - 2017-02-07 05:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:30:19 --> Utf8 Class Initialized
INFO - 2017-02-07 05:30:19 --> URI Class Initialized
INFO - 2017-02-07 05:30:19 --> Router Class Initialized
INFO - 2017-02-07 05:30:19 --> Output Class Initialized
INFO - 2017-02-07 05:30:19 --> Security Class Initialized
DEBUG - 2017-02-07 05:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:30:19 --> Input Class Initialized
INFO - 2017-02-07 05:30:19 --> Language Class Initialized
INFO - 2017-02-07 05:30:19 --> Loader Class Initialized
INFO - 2017-02-07 05:30:19 --> Database Driver Class Initialized
INFO - 2017-02-07 05:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:30:19 --> Controller Class Initialized
INFO - 2017-02-07 05:30:19 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:30:19 --> Final output sent to browser
DEBUG - 2017-02-07 05:30:19 --> Total execution time: 0.0137
INFO - 2017-02-07 05:30:23 --> Config Class Initialized
INFO - 2017-02-07 05:30:23 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:30:23 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:30:23 --> Utf8 Class Initialized
INFO - 2017-02-07 05:30:23 --> URI Class Initialized
INFO - 2017-02-07 05:30:23 --> Router Class Initialized
INFO - 2017-02-07 05:30:23 --> Output Class Initialized
INFO - 2017-02-07 05:30:23 --> Security Class Initialized
DEBUG - 2017-02-07 05:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:30:23 --> Input Class Initialized
INFO - 2017-02-07 05:30:23 --> Language Class Initialized
INFO - 2017-02-07 05:30:23 --> Loader Class Initialized
INFO - 2017-02-07 05:30:23 --> Database Driver Class Initialized
INFO - 2017-02-07 05:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:30:23 --> Controller Class Initialized
INFO - 2017-02-07 05:30:23 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:30:25 --> Config Class Initialized
INFO - 2017-02-07 05:30:25 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:30:25 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:30:25 --> Utf8 Class Initialized
INFO - 2017-02-07 05:30:25 --> URI Class Initialized
INFO - 2017-02-07 05:30:25 --> Router Class Initialized
INFO - 2017-02-07 05:30:25 --> Output Class Initialized
INFO - 2017-02-07 05:30:25 --> Security Class Initialized
DEBUG - 2017-02-07 05:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:30:25 --> Input Class Initialized
INFO - 2017-02-07 05:30:25 --> Language Class Initialized
INFO - 2017-02-07 05:30:25 --> Loader Class Initialized
INFO - 2017-02-07 05:30:25 --> Database Driver Class Initialized
INFO - 2017-02-07 05:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:30:25 --> Controller Class Initialized
INFO - 2017-02-07 05:30:25 --> Helper loaded: date_helper
DEBUG - 2017-02-07 05:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:30:25 --> Helper loaded: url_helper
INFO - 2017-02-07 05:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 05:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 05:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 05:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:30:25 --> Final output sent to browser
DEBUG - 2017-02-07 05:30:25 --> Total execution time: 0.0141
INFO - 2017-02-07 05:31:29 --> Config Class Initialized
INFO - 2017-02-07 05:31:29 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:31:29 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:31:29 --> Utf8 Class Initialized
INFO - 2017-02-07 05:31:29 --> URI Class Initialized
DEBUG - 2017-02-07 05:31:29 --> No URI present. Default controller set.
INFO - 2017-02-07 05:31:29 --> Router Class Initialized
INFO - 2017-02-07 05:31:29 --> Output Class Initialized
INFO - 2017-02-07 05:31:29 --> Security Class Initialized
DEBUG - 2017-02-07 05:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:31:29 --> Input Class Initialized
INFO - 2017-02-07 05:31:29 --> Language Class Initialized
INFO - 2017-02-07 05:31:29 --> Loader Class Initialized
INFO - 2017-02-07 05:31:29 --> Database Driver Class Initialized
INFO - 2017-02-07 05:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:31:29 --> Controller Class Initialized
INFO - 2017-02-07 05:31:29 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:31:29 --> Final output sent to browser
DEBUG - 2017-02-07 05:31:29 --> Total execution time: 0.0136
INFO - 2017-02-07 05:31:36 --> Config Class Initialized
INFO - 2017-02-07 05:31:36 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:31:36 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:31:36 --> Utf8 Class Initialized
INFO - 2017-02-07 05:31:36 --> URI Class Initialized
INFO - 2017-02-07 05:31:36 --> Router Class Initialized
INFO - 2017-02-07 05:31:36 --> Output Class Initialized
INFO - 2017-02-07 05:31:36 --> Security Class Initialized
DEBUG - 2017-02-07 05:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:31:36 --> Input Class Initialized
INFO - 2017-02-07 05:31:36 --> Language Class Initialized
INFO - 2017-02-07 05:31:36 --> Loader Class Initialized
INFO - 2017-02-07 05:31:36 --> Database Driver Class Initialized
INFO - 2017-02-07 05:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:31:36 --> Controller Class Initialized
INFO - 2017-02-07 05:31:36 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:31:36 --> Final output sent to browser
DEBUG - 2017-02-07 05:31:36 --> Total execution time: 0.0132
INFO - 2017-02-07 05:31:39 --> Config Class Initialized
INFO - 2017-02-07 05:31:39 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:31:39 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:31:39 --> Utf8 Class Initialized
INFO - 2017-02-07 05:31:39 --> URI Class Initialized
INFO - 2017-02-07 05:31:39 --> Router Class Initialized
INFO - 2017-02-07 05:31:39 --> Output Class Initialized
INFO - 2017-02-07 05:31:39 --> Security Class Initialized
DEBUG - 2017-02-07 05:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:31:39 --> Input Class Initialized
INFO - 2017-02-07 05:31:39 --> Language Class Initialized
INFO - 2017-02-07 05:31:39 --> Loader Class Initialized
INFO - 2017-02-07 05:31:39 --> Database Driver Class Initialized
INFO - 2017-02-07 05:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:31:39 --> Controller Class Initialized
INFO - 2017-02-07 05:31:39 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:31:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:31:39 --> Final output sent to browser
DEBUG - 2017-02-07 05:31:39 --> Total execution time: 0.0140
INFO - 2017-02-07 05:31:48 --> Config Class Initialized
INFO - 2017-02-07 05:31:48 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:31:48 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:31:48 --> Utf8 Class Initialized
INFO - 2017-02-07 05:31:48 --> URI Class Initialized
INFO - 2017-02-07 05:31:48 --> Router Class Initialized
INFO - 2017-02-07 05:31:48 --> Output Class Initialized
INFO - 2017-02-07 05:31:48 --> Security Class Initialized
DEBUG - 2017-02-07 05:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:31:48 --> Input Class Initialized
INFO - 2017-02-07 05:31:48 --> Language Class Initialized
INFO - 2017-02-07 05:31:48 --> Loader Class Initialized
INFO - 2017-02-07 05:31:48 --> Database Driver Class Initialized
INFO - 2017-02-07 05:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:31:48 --> Controller Class Initialized
INFO - 2017-02-07 05:31:48 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:31:49 --> Config Class Initialized
INFO - 2017-02-07 05:31:49 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:31:49 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:31:49 --> Utf8 Class Initialized
INFO - 2017-02-07 05:31:49 --> URI Class Initialized
INFO - 2017-02-07 05:31:49 --> Router Class Initialized
INFO - 2017-02-07 05:31:49 --> Output Class Initialized
INFO - 2017-02-07 05:31:49 --> Security Class Initialized
DEBUG - 2017-02-07 05:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:31:49 --> Input Class Initialized
INFO - 2017-02-07 05:31:49 --> Language Class Initialized
INFO - 2017-02-07 05:31:49 --> Loader Class Initialized
INFO - 2017-02-07 05:31:49 --> Database Driver Class Initialized
INFO - 2017-02-07 05:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:31:49 --> Controller Class Initialized
INFO - 2017-02-07 05:31:49 --> Helper loaded: date_helper
DEBUG - 2017-02-07 05:31:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:31:49 --> Helper loaded: url_helper
INFO - 2017-02-07 05:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 05:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 05:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 05:31:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:31:49 --> Final output sent to browser
DEBUG - 2017-02-07 05:31:49 --> Total execution time: 0.0134
INFO - 2017-02-07 05:33:45 --> Config Class Initialized
INFO - 2017-02-07 05:33:45 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:33:45 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:33:45 --> Utf8 Class Initialized
INFO - 2017-02-07 05:33:45 --> URI Class Initialized
DEBUG - 2017-02-07 05:33:45 --> No URI present. Default controller set.
INFO - 2017-02-07 05:33:45 --> Router Class Initialized
INFO - 2017-02-07 05:33:45 --> Output Class Initialized
INFO - 2017-02-07 05:33:45 --> Security Class Initialized
DEBUG - 2017-02-07 05:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:33:45 --> Input Class Initialized
INFO - 2017-02-07 05:33:45 --> Language Class Initialized
INFO - 2017-02-07 05:33:45 --> Loader Class Initialized
INFO - 2017-02-07 05:33:45 --> Database Driver Class Initialized
INFO - 2017-02-07 05:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:33:45 --> Controller Class Initialized
INFO - 2017-02-07 05:33:45 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:33:45 --> Final output sent to browser
DEBUG - 2017-02-07 05:33:45 --> Total execution time: 0.0130
INFO - 2017-02-07 05:33:51 --> Config Class Initialized
INFO - 2017-02-07 05:33:51 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:33:51 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:33:51 --> Utf8 Class Initialized
INFO - 2017-02-07 05:33:51 --> URI Class Initialized
INFO - 2017-02-07 05:33:51 --> Router Class Initialized
INFO - 2017-02-07 05:33:51 --> Output Class Initialized
INFO - 2017-02-07 05:33:51 --> Security Class Initialized
DEBUG - 2017-02-07 05:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:33:51 --> Input Class Initialized
INFO - 2017-02-07 05:33:51 --> Language Class Initialized
INFO - 2017-02-07 05:33:51 --> Loader Class Initialized
INFO - 2017-02-07 05:33:51 --> Database Driver Class Initialized
INFO - 2017-02-07 05:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:33:51 --> Controller Class Initialized
INFO - 2017-02-07 05:33:51 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:33:51 --> Final output sent to browser
DEBUG - 2017-02-07 05:33:51 --> Total execution time: 0.0132
INFO - 2017-02-07 05:33:54 --> Config Class Initialized
INFO - 2017-02-07 05:33:54 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:33:54 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:33:54 --> Utf8 Class Initialized
INFO - 2017-02-07 05:33:54 --> URI Class Initialized
INFO - 2017-02-07 05:33:54 --> Router Class Initialized
INFO - 2017-02-07 05:33:54 --> Output Class Initialized
INFO - 2017-02-07 05:33:54 --> Security Class Initialized
DEBUG - 2017-02-07 05:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:33:54 --> Input Class Initialized
INFO - 2017-02-07 05:33:54 --> Language Class Initialized
INFO - 2017-02-07 05:33:54 --> Loader Class Initialized
INFO - 2017-02-07 05:33:54 --> Database Driver Class Initialized
INFO - 2017-02-07 05:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:33:54 --> Controller Class Initialized
INFO - 2017-02-07 05:33:54 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:33:54 --> Final output sent to browser
DEBUG - 2017-02-07 05:33:54 --> Total execution time: 0.0130
INFO - 2017-02-07 05:34:00 --> Config Class Initialized
INFO - 2017-02-07 05:34:00 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:34:00 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:34:00 --> Utf8 Class Initialized
INFO - 2017-02-07 05:34:00 --> URI Class Initialized
INFO - 2017-02-07 05:34:00 --> Router Class Initialized
INFO - 2017-02-07 05:34:00 --> Output Class Initialized
INFO - 2017-02-07 05:34:00 --> Security Class Initialized
DEBUG - 2017-02-07 05:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:34:00 --> Input Class Initialized
INFO - 2017-02-07 05:34:00 --> Language Class Initialized
INFO - 2017-02-07 05:34:00 --> Loader Class Initialized
INFO - 2017-02-07 05:34:00 --> Database Driver Class Initialized
INFO - 2017-02-07 05:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:34:00 --> Controller Class Initialized
INFO - 2017-02-07 05:34:00 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:34:01 --> Config Class Initialized
INFO - 2017-02-07 05:34:01 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:34:01 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:34:01 --> Utf8 Class Initialized
INFO - 2017-02-07 05:34:01 --> URI Class Initialized
INFO - 2017-02-07 05:34:01 --> Router Class Initialized
INFO - 2017-02-07 05:34:01 --> Output Class Initialized
INFO - 2017-02-07 05:34:01 --> Security Class Initialized
DEBUG - 2017-02-07 05:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:34:01 --> Input Class Initialized
INFO - 2017-02-07 05:34:01 --> Language Class Initialized
INFO - 2017-02-07 05:34:01 --> Loader Class Initialized
INFO - 2017-02-07 05:34:01 --> Database Driver Class Initialized
INFO - 2017-02-07 05:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:34:01 --> Controller Class Initialized
INFO - 2017-02-07 05:34:01 --> Helper loaded: date_helper
DEBUG - 2017-02-07 05:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:34:01 --> Helper loaded: url_helper
INFO - 2017-02-07 05:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 05:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 05:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 05:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:34:01 --> Final output sent to browser
DEBUG - 2017-02-07 05:34:01 --> Total execution time: 0.0659
INFO - 2017-02-07 05:34:11 --> Config Class Initialized
INFO - 2017-02-07 05:34:11 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:34:11 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:34:11 --> Utf8 Class Initialized
INFO - 2017-02-07 05:34:11 --> URI Class Initialized
DEBUG - 2017-02-07 05:34:11 --> No URI present. Default controller set.
INFO - 2017-02-07 05:34:11 --> Router Class Initialized
INFO - 2017-02-07 05:34:11 --> Output Class Initialized
INFO - 2017-02-07 05:34:11 --> Security Class Initialized
DEBUG - 2017-02-07 05:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:34:11 --> Input Class Initialized
INFO - 2017-02-07 05:34:11 --> Language Class Initialized
INFO - 2017-02-07 05:34:11 --> Loader Class Initialized
INFO - 2017-02-07 05:34:11 --> Database Driver Class Initialized
INFO - 2017-02-07 05:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:34:11 --> Controller Class Initialized
INFO - 2017-02-07 05:34:11 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:34:11 --> Final output sent to browser
DEBUG - 2017-02-07 05:34:11 --> Total execution time: 0.0133
INFO - 2017-02-07 05:34:40 --> Config Class Initialized
INFO - 2017-02-07 05:34:40 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:34:40 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:34:40 --> Utf8 Class Initialized
INFO - 2017-02-07 05:34:40 --> URI Class Initialized
INFO - 2017-02-07 05:34:40 --> Router Class Initialized
INFO - 2017-02-07 05:34:40 --> Output Class Initialized
INFO - 2017-02-07 05:34:40 --> Security Class Initialized
DEBUG - 2017-02-07 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:34:40 --> Input Class Initialized
INFO - 2017-02-07 05:34:40 --> Language Class Initialized
INFO - 2017-02-07 05:34:40 --> Loader Class Initialized
INFO - 2017-02-07 05:34:40 --> Database Driver Class Initialized
INFO - 2017-02-07 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:34:40 --> Controller Class Initialized
INFO - 2017-02-07 05:34:40 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:34:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:34:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:34:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:34:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:34:40 --> Final output sent to browser
DEBUG - 2017-02-07 05:34:40 --> Total execution time: 0.0150
INFO - 2017-02-07 05:34:46 --> Config Class Initialized
INFO - 2017-02-07 05:34:46 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:34:46 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:34:46 --> Utf8 Class Initialized
INFO - 2017-02-07 05:34:46 --> URI Class Initialized
INFO - 2017-02-07 05:34:46 --> Router Class Initialized
INFO - 2017-02-07 05:34:46 --> Output Class Initialized
INFO - 2017-02-07 05:34:46 --> Security Class Initialized
DEBUG - 2017-02-07 05:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:34:46 --> Input Class Initialized
INFO - 2017-02-07 05:34:46 --> Language Class Initialized
INFO - 2017-02-07 05:34:46 --> Loader Class Initialized
INFO - 2017-02-07 05:34:46 --> Database Driver Class Initialized
INFO - 2017-02-07 05:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:34:46 --> Controller Class Initialized
INFO - 2017-02-07 05:34:46 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:34:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:34:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:34:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:34:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:34:46 --> Final output sent to browser
DEBUG - 2017-02-07 05:34:46 --> Total execution time: 0.0133
INFO - 2017-02-07 05:36:22 --> Config Class Initialized
INFO - 2017-02-07 05:36:22 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:36:22 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:36:22 --> Utf8 Class Initialized
INFO - 2017-02-07 05:36:22 --> URI Class Initialized
INFO - 2017-02-07 05:36:22 --> Router Class Initialized
INFO - 2017-02-07 05:36:22 --> Output Class Initialized
INFO - 2017-02-07 05:36:22 --> Security Class Initialized
DEBUG - 2017-02-07 05:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:36:22 --> Input Class Initialized
INFO - 2017-02-07 05:36:22 --> Language Class Initialized
INFO - 2017-02-07 05:36:22 --> Loader Class Initialized
INFO - 2017-02-07 05:36:22 --> Database Driver Class Initialized
INFO - 2017-02-07 05:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:36:22 --> Controller Class Initialized
INFO - 2017-02-07 05:36:22 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:36:22 --> Final output sent to browser
DEBUG - 2017-02-07 05:36:22 --> Total execution time: 0.0135
INFO - 2017-02-07 05:36:25 --> Config Class Initialized
INFO - 2017-02-07 05:36:25 --> Hooks Class Initialized
DEBUG - 2017-02-07 05:36:25 --> UTF-8 Support Enabled
INFO - 2017-02-07 05:36:25 --> Utf8 Class Initialized
INFO - 2017-02-07 05:36:25 --> URI Class Initialized
INFO - 2017-02-07 05:36:25 --> Router Class Initialized
INFO - 2017-02-07 05:36:25 --> Output Class Initialized
INFO - 2017-02-07 05:36:25 --> Security Class Initialized
DEBUG - 2017-02-07 05:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 05:36:25 --> Input Class Initialized
INFO - 2017-02-07 05:36:25 --> Language Class Initialized
INFO - 2017-02-07 05:36:25 --> Loader Class Initialized
INFO - 2017-02-07 05:36:25 --> Database Driver Class Initialized
INFO - 2017-02-07 05:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 05:36:25 --> Controller Class Initialized
INFO - 2017-02-07 05:36:25 --> Helper loaded: url_helper
DEBUG - 2017-02-07 05:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 05:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 05:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 05:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 05:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 05:36:25 --> Final output sent to browser
DEBUG - 2017-02-07 05:36:25 --> Total execution time: 0.0137
INFO - 2017-02-07 06:21:02 --> Config Class Initialized
INFO - 2017-02-07 06:21:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 06:21:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 06:21:02 --> Utf8 Class Initialized
INFO - 2017-02-07 06:21:02 --> URI Class Initialized
DEBUG - 2017-02-07 06:21:02 --> No URI present. Default controller set.
INFO - 2017-02-07 06:21:02 --> Router Class Initialized
INFO - 2017-02-07 06:21:02 --> Output Class Initialized
INFO - 2017-02-07 06:21:02 --> Security Class Initialized
DEBUG - 2017-02-07 06:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 06:21:02 --> Input Class Initialized
INFO - 2017-02-07 06:21:02 --> Language Class Initialized
INFO - 2017-02-07 06:21:02 --> Loader Class Initialized
INFO - 2017-02-07 06:21:02 --> Database Driver Class Initialized
INFO - 2017-02-07 06:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 06:21:02 --> Controller Class Initialized
INFO - 2017-02-07 06:21:02 --> Helper loaded: url_helper
DEBUG - 2017-02-07 06:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 06:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 06:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 06:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 06:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 06:21:02 --> Final output sent to browser
DEBUG - 2017-02-07 06:21:02 --> Total execution time: 0.4514
INFO - 2017-02-07 06:21:29 --> Config Class Initialized
INFO - 2017-02-07 06:21:29 --> Hooks Class Initialized
DEBUG - 2017-02-07 06:21:29 --> UTF-8 Support Enabled
INFO - 2017-02-07 06:21:29 --> Utf8 Class Initialized
INFO - 2017-02-07 06:21:29 --> URI Class Initialized
INFO - 2017-02-07 06:21:29 --> Router Class Initialized
INFO - 2017-02-07 06:21:29 --> Output Class Initialized
INFO - 2017-02-07 06:21:29 --> Security Class Initialized
DEBUG - 2017-02-07 06:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 06:21:29 --> Input Class Initialized
INFO - 2017-02-07 06:21:29 --> Language Class Initialized
INFO - 2017-02-07 06:21:29 --> Loader Class Initialized
INFO - 2017-02-07 06:21:29 --> Database Driver Class Initialized
INFO - 2017-02-07 06:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 06:21:29 --> Controller Class Initialized
INFO - 2017-02-07 06:21:29 --> Helper loaded: url_helper
DEBUG - 2017-02-07 06:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 06:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 06:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 06:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 06:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 06:21:29 --> Final output sent to browser
DEBUG - 2017-02-07 06:21:29 --> Total execution time: 0.0132
INFO - 2017-02-07 07:34:56 --> Config Class Initialized
INFO - 2017-02-07 07:34:56 --> Hooks Class Initialized
DEBUG - 2017-02-07 07:34:56 --> UTF-8 Support Enabled
INFO - 2017-02-07 07:34:56 --> Utf8 Class Initialized
INFO - 2017-02-07 07:34:56 --> URI Class Initialized
DEBUG - 2017-02-07 07:34:56 --> No URI present. Default controller set.
INFO - 2017-02-07 07:34:56 --> Router Class Initialized
INFO - 2017-02-07 07:34:56 --> Output Class Initialized
INFO - 2017-02-07 07:34:56 --> Security Class Initialized
DEBUG - 2017-02-07 07:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 07:34:56 --> Input Class Initialized
INFO - 2017-02-07 07:34:56 --> Language Class Initialized
INFO - 2017-02-07 07:34:56 --> Loader Class Initialized
INFO - 2017-02-07 07:34:57 --> Database Driver Class Initialized
INFO - 2017-02-07 07:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 07:34:57 --> Controller Class Initialized
INFO - 2017-02-07 07:34:57 --> Helper loaded: url_helper
DEBUG - 2017-02-07 07:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 07:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 07:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 07:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 07:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 07:34:57 --> Final output sent to browser
DEBUG - 2017-02-07 07:34:57 --> Total execution time: 1.4928
INFO - 2017-02-07 07:35:09 --> Config Class Initialized
INFO - 2017-02-07 07:35:09 --> Hooks Class Initialized
DEBUG - 2017-02-07 07:35:09 --> UTF-8 Support Enabled
INFO - 2017-02-07 07:35:09 --> Utf8 Class Initialized
INFO - 2017-02-07 07:35:09 --> URI Class Initialized
INFO - 2017-02-07 07:35:09 --> Router Class Initialized
INFO - 2017-02-07 07:35:09 --> Output Class Initialized
INFO - 2017-02-07 07:35:09 --> Security Class Initialized
DEBUG - 2017-02-07 07:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 07:35:09 --> Input Class Initialized
INFO - 2017-02-07 07:35:09 --> Language Class Initialized
INFO - 2017-02-07 07:35:09 --> Loader Class Initialized
INFO - 2017-02-07 07:35:09 --> Database Driver Class Initialized
INFO - 2017-02-07 07:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 07:35:09 --> Controller Class Initialized
INFO - 2017-02-07 07:35:09 --> Helper loaded: url_helper
DEBUG - 2017-02-07 07:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 07:35:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 07:35:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 07:35:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 07:35:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 07:35:09 --> Final output sent to browser
DEBUG - 2017-02-07 07:35:09 --> Total execution time: 0.0147
INFO - 2017-02-07 07:44:01 --> Config Class Initialized
INFO - 2017-02-07 07:44:01 --> Hooks Class Initialized
DEBUG - 2017-02-07 07:44:01 --> UTF-8 Support Enabled
INFO - 2017-02-07 07:44:01 --> Utf8 Class Initialized
INFO - 2017-02-07 07:44:01 --> URI Class Initialized
DEBUG - 2017-02-07 07:44:01 --> No URI present. Default controller set.
INFO - 2017-02-07 07:44:01 --> Router Class Initialized
INFO - 2017-02-07 07:44:01 --> Output Class Initialized
INFO - 2017-02-07 07:44:01 --> Security Class Initialized
DEBUG - 2017-02-07 07:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 07:44:01 --> Input Class Initialized
INFO - 2017-02-07 07:44:01 --> Language Class Initialized
INFO - 2017-02-07 07:44:01 --> Loader Class Initialized
INFO - 2017-02-07 07:44:01 --> Database Driver Class Initialized
INFO - 2017-02-07 07:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 07:44:01 --> Controller Class Initialized
INFO - 2017-02-07 07:44:01 --> Helper loaded: url_helper
DEBUG - 2017-02-07 07:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 07:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 07:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 07:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 07:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 07:44:01 --> Final output sent to browser
DEBUG - 2017-02-07 07:44:01 --> Total execution time: 0.0694
INFO - 2017-02-07 07:44:06 --> Config Class Initialized
INFO - 2017-02-07 07:44:06 --> Hooks Class Initialized
DEBUG - 2017-02-07 07:44:06 --> UTF-8 Support Enabled
INFO - 2017-02-07 07:44:06 --> Utf8 Class Initialized
INFO - 2017-02-07 07:44:06 --> URI Class Initialized
INFO - 2017-02-07 07:44:06 --> Router Class Initialized
INFO - 2017-02-07 07:44:06 --> Output Class Initialized
INFO - 2017-02-07 07:44:06 --> Security Class Initialized
DEBUG - 2017-02-07 07:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 07:44:06 --> Input Class Initialized
INFO - 2017-02-07 07:44:06 --> Language Class Initialized
INFO - 2017-02-07 07:44:06 --> Loader Class Initialized
INFO - 2017-02-07 07:44:06 --> Database Driver Class Initialized
INFO - 2017-02-07 07:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 07:44:06 --> Controller Class Initialized
INFO - 2017-02-07 07:44:06 --> Helper loaded: url_helper
DEBUG - 2017-02-07 07:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 07:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 07:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 07:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 07:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 07:44:06 --> Final output sent to browser
DEBUG - 2017-02-07 07:44:06 --> Total execution time: 0.0131
INFO - 2017-02-07 07:55:36 --> Config Class Initialized
INFO - 2017-02-07 07:55:36 --> Hooks Class Initialized
DEBUG - 2017-02-07 07:55:36 --> UTF-8 Support Enabled
INFO - 2017-02-07 07:55:36 --> Utf8 Class Initialized
INFO - 2017-02-07 07:55:36 --> URI Class Initialized
DEBUG - 2017-02-07 07:55:36 --> No URI present. Default controller set.
INFO - 2017-02-07 07:55:36 --> Router Class Initialized
INFO - 2017-02-07 07:55:36 --> Output Class Initialized
INFO - 2017-02-07 07:55:36 --> Security Class Initialized
DEBUG - 2017-02-07 07:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 07:55:36 --> Input Class Initialized
INFO - 2017-02-07 07:55:36 --> Language Class Initialized
INFO - 2017-02-07 07:55:36 --> Loader Class Initialized
INFO - 2017-02-07 07:55:36 --> Database Driver Class Initialized
INFO - 2017-02-07 07:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 07:55:36 --> Controller Class Initialized
INFO - 2017-02-07 07:55:36 --> Helper loaded: url_helper
DEBUG - 2017-02-07 07:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 07:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 07:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 07:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 07:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 07:55:36 --> Final output sent to browser
DEBUG - 2017-02-07 07:55:36 --> Total execution time: 0.0134
INFO - 2017-02-07 07:55:55 --> Config Class Initialized
INFO - 2017-02-07 07:55:55 --> Hooks Class Initialized
DEBUG - 2017-02-07 07:55:55 --> UTF-8 Support Enabled
INFO - 2017-02-07 07:55:55 --> Utf8 Class Initialized
INFO - 2017-02-07 07:55:55 --> URI Class Initialized
INFO - 2017-02-07 07:55:55 --> Router Class Initialized
INFO - 2017-02-07 07:55:55 --> Output Class Initialized
INFO - 2017-02-07 07:55:55 --> Security Class Initialized
DEBUG - 2017-02-07 07:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 07:55:55 --> Input Class Initialized
INFO - 2017-02-07 07:55:55 --> Language Class Initialized
INFO - 2017-02-07 07:55:55 --> Loader Class Initialized
INFO - 2017-02-07 07:55:55 --> Database Driver Class Initialized
INFO - 2017-02-07 07:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 07:55:55 --> Controller Class Initialized
INFO - 2017-02-07 07:55:55 --> Helper loaded: url_helper
DEBUG - 2017-02-07 07:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 07:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 07:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 07:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 07:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 07:55:55 --> Final output sent to browser
DEBUG - 2017-02-07 07:55:55 --> Total execution time: 0.0133
INFO - 2017-02-07 08:05:30 --> Config Class Initialized
INFO - 2017-02-07 08:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:05:30 --> Utf8 Class Initialized
INFO - 2017-02-07 08:05:30 --> URI Class Initialized
DEBUG - 2017-02-07 08:05:30 --> No URI present. Default controller set.
INFO - 2017-02-07 08:05:30 --> Router Class Initialized
INFO - 2017-02-07 08:05:30 --> Output Class Initialized
INFO - 2017-02-07 08:05:30 --> Security Class Initialized
DEBUG - 2017-02-07 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:05:30 --> Input Class Initialized
INFO - 2017-02-07 08:05:30 --> Language Class Initialized
INFO - 2017-02-07 08:05:30 --> Loader Class Initialized
INFO - 2017-02-07 08:05:30 --> Database Driver Class Initialized
INFO - 2017-02-07 08:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:05:31 --> Controller Class Initialized
INFO - 2017-02-07 08:05:31 --> Helper loaded: url_helper
DEBUG - 2017-02-07 08:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 08:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 08:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 08:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 08:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 08:05:31 --> Final output sent to browser
DEBUG - 2017-02-07 08:05:31 --> Total execution time: 0.5992
INFO - 2017-02-07 08:40:07 --> Config Class Initialized
INFO - 2017-02-07 08:40:07 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:40:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:40:08 --> Utf8 Class Initialized
INFO - 2017-02-07 08:40:08 --> URI Class Initialized
INFO - 2017-02-07 08:40:08 --> Router Class Initialized
INFO - 2017-02-07 08:40:08 --> Output Class Initialized
INFO - 2017-02-07 08:40:08 --> Security Class Initialized
DEBUG - 2017-02-07 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:40:08 --> Input Class Initialized
INFO - 2017-02-07 08:40:08 --> Language Class Initialized
INFO - 2017-02-07 08:40:08 --> Loader Class Initialized
INFO - 2017-02-07 08:40:08 --> Database Driver Class Initialized
INFO - 2017-02-07 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:40:08 --> Controller Class Initialized
INFO - 2017-02-07 08:40:08 --> Helper loaded: url_helper
DEBUG - 2017-02-07 08:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 08:40:09 --> Final output sent to browser
DEBUG - 2017-02-07 08:40:09 --> Total execution time: 1.4844
INFO - 2017-02-07 08:40:09 --> Config Class Initialized
INFO - 2017-02-07 08:40:09 --> Hooks Class Initialized
DEBUG - 2017-02-07 08:40:09 --> UTF-8 Support Enabled
INFO - 2017-02-07 08:40:09 --> Utf8 Class Initialized
INFO - 2017-02-07 08:40:09 --> URI Class Initialized
DEBUG - 2017-02-07 08:40:09 --> No URI present. Default controller set.
INFO - 2017-02-07 08:40:09 --> Router Class Initialized
INFO - 2017-02-07 08:40:09 --> Output Class Initialized
INFO - 2017-02-07 08:40:09 --> Security Class Initialized
DEBUG - 2017-02-07 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 08:40:09 --> Input Class Initialized
INFO - 2017-02-07 08:40:09 --> Language Class Initialized
INFO - 2017-02-07 08:40:09 --> Loader Class Initialized
INFO - 2017-02-07 08:40:09 --> Database Driver Class Initialized
INFO - 2017-02-07 08:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 08:40:09 --> Controller Class Initialized
INFO - 2017-02-07 08:40:09 --> Helper loaded: url_helper
DEBUG - 2017-02-07 08:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 08:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 08:40:09 --> Final output sent to browser
DEBUG - 2017-02-07 08:40:09 --> Total execution time: 0.0131
INFO - 2017-02-07 11:53:24 --> Config Class Initialized
INFO - 2017-02-07 11:53:24 --> Hooks Class Initialized
DEBUG - 2017-02-07 11:53:25 --> UTF-8 Support Enabled
INFO - 2017-02-07 11:53:25 --> Utf8 Class Initialized
INFO - 2017-02-07 11:53:25 --> URI Class Initialized
INFO - 2017-02-07 11:53:25 --> Router Class Initialized
INFO - 2017-02-07 11:53:25 --> Output Class Initialized
INFO - 2017-02-07 11:53:25 --> Security Class Initialized
DEBUG - 2017-02-07 11:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 11:53:25 --> Input Class Initialized
INFO - 2017-02-07 11:53:25 --> Language Class Initialized
INFO - 2017-02-07 11:53:25 --> Loader Class Initialized
INFO - 2017-02-07 11:53:25 --> Database Driver Class Initialized
INFO - 2017-02-07 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 11:53:26 --> Controller Class Initialized
INFO - 2017-02-07 11:53:26 --> Helper loaded: url_helper
DEBUG - 2017-02-07 11:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 11:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 11:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 11:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 11:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 11:53:26 --> Final output sent to browser
DEBUG - 2017-02-07 11:53:26 --> Total execution time: 1.8171
INFO - 2017-02-07 11:53:26 --> Config Class Initialized
INFO - 2017-02-07 11:53:26 --> Hooks Class Initialized
DEBUG - 2017-02-07 11:53:26 --> UTF-8 Support Enabled
INFO - 2017-02-07 11:53:26 --> Utf8 Class Initialized
INFO - 2017-02-07 11:53:26 --> URI Class Initialized
DEBUG - 2017-02-07 11:53:26 --> No URI present. Default controller set.
INFO - 2017-02-07 11:53:27 --> Router Class Initialized
INFO - 2017-02-07 11:53:27 --> Output Class Initialized
INFO - 2017-02-07 11:53:27 --> Security Class Initialized
DEBUG - 2017-02-07 11:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 11:53:27 --> Input Class Initialized
INFO - 2017-02-07 11:53:27 --> Language Class Initialized
INFO - 2017-02-07 11:53:27 --> Loader Class Initialized
INFO - 2017-02-07 11:53:27 --> Database Driver Class Initialized
INFO - 2017-02-07 11:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 11:53:27 --> Controller Class Initialized
INFO - 2017-02-07 11:53:27 --> Helper loaded: url_helper
DEBUG - 2017-02-07 11:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 11:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 11:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 11:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 11:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 11:53:27 --> Final output sent to browser
DEBUG - 2017-02-07 11:53:27 --> Total execution time: 0.5012
INFO - 2017-02-07 12:02:29 --> Config Class Initialized
INFO - 2017-02-07 12:02:29 --> Hooks Class Initialized
DEBUG - 2017-02-07 12:02:29 --> UTF-8 Support Enabled
INFO - 2017-02-07 12:02:29 --> Utf8 Class Initialized
INFO - 2017-02-07 12:02:29 --> URI Class Initialized
INFO - 2017-02-07 12:02:29 --> Router Class Initialized
INFO - 2017-02-07 12:02:29 --> Output Class Initialized
INFO - 2017-02-07 12:02:29 --> Security Class Initialized
DEBUG - 2017-02-07 12:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 12:02:29 --> Input Class Initialized
INFO - 2017-02-07 12:02:29 --> Language Class Initialized
INFO - 2017-02-07 12:02:29 --> Loader Class Initialized
INFO - 2017-02-07 12:02:30 --> Database Driver Class Initialized
INFO - 2017-02-07 12:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 12:02:30 --> Controller Class Initialized
INFO - 2017-02-07 12:02:30 --> Helper loaded: url_helper
DEBUG - 2017-02-07 12:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 12:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 12:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 12:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 12:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 12:02:30 --> Final output sent to browser
DEBUG - 2017-02-07 12:02:30 --> Total execution time: 1.7773
INFO - 2017-02-07 12:02:44 --> Config Class Initialized
INFO - 2017-02-07 12:02:44 --> Hooks Class Initialized
DEBUG - 2017-02-07 12:02:44 --> UTF-8 Support Enabled
INFO - 2017-02-07 12:02:44 --> Utf8 Class Initialized
INFO - 2017-02-07 12:02:44 --> URI Class Initialized
DEBUG - 2017-02-07 12:02:44 --> No URI present. Default controller set.
INFO - 2017-02-07 12:02:44 --> Router Class Initialized
INFO - 2017-02-07 12:02:44 --> Output Class Initialized
INFO - 2017-02-07 12:02:44 --> Security Class Initialized
DEBUG - 2017-02-07 12:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 12:02:44 --> Input Class Initialized
INFO - 2017-02-07 12:02:44 --> Language Class Initialized
INFO - 2017-02-07 12:02:44 --> Loader Class Initialized
INFO - 2017-02-07 12:02:45 --> Database Driver Class Initialized
INFO - 2017-02-07 12:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 12:02:46 --> Controller Class Initialized
INFO - 2017-02-07 12:02:46 --> Helper loaded: url_helper
DEBUG - 2017-02-07 12:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 12:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 12:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 12:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 12:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 12:02:46 --> Final output sent to browser
DEBUG - 2017-02-07 12:02:46 --> Total execution time: 2.8510
INFO - 2017-02-07 15:10:30 --> Config Class Initialized
INFO - 2017-02-07 15:10:30 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:10:30 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:10:30 --> Utf8 Class Initialized
INFO - 2017-02-07 15:10:30 --> URI Class Initialized
DEBUG - 2017-02-07 15:10:30 --> No URI present. Default controller set.
INFO - 2017-02-07 15:10:30 --> Router Class Initialized
INFO - 2017-02-07 15:10:30 --> Output Class Initialized
INFO - 2017-02-07 15:10:30 --> Security Class Initialized
DEBUG - 2017-02-07 15:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:10:30 --> Input Class Initialized
INFO - 2017-02-07 15:10:30 --> Language Class Initialized
INFO - 2017-02-07 15:10:31 --> Loader Class Initialized
INFO - 2017-02-07 15:10:31 --> Database Driver Class Initialized
INFO - 2017-02-07 15:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:10:31 --> Controller Class Initialized
INFO - 2017-02-07 15:10:31 --> Helper loaded: url_helper
DEBUG - 2017-02-07 15:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 15:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 15:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 15:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 15:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 15:10:32 --> Final output sent to browser
DEBUG - 2017-02-07 15:10:32 --> Total execution time: 1.7708
INFO - 2017-02-07 15:18:01 --> Config Class Initialized
INFO - 2017-02-07 15:18:01 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:18:01 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:18:01 --> Utf8 Class Initialized
INFO - 2017-02-07 15:18:01 --> URI Class Initialized
INFO - 2017-02-07 15:18:01 --> Router Class Initialized
INFO - 2017-02-07 15:18:02 --> Output Class Initialized
INFO - 2017-02-07 15:18:02 --> Security Class Initialized
DEBUG - 2017-02-07 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:18:02 --> Input Class Initialized
INFO - 2017-02-07 15:18:02 --> Language Class Initialized
INFO - 2017-02-07 15:18:02 --> Loader Class Initialized
INFO - 2017-02-07 15:18:02 --> Database Driver Class Initialized
INFO - 2017-02-07 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:18:02 --> Controller Class Initialized
INFO - 2017-02-07 15:18:02 --> Helper loaded: url_helper
DEBUG - 2017-02-07 15:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 15:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 15:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 15:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 15:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 15:18:03 --> Final output sent to browser
DEBUG - 2017-02-07 15:18:03 --> Total execution time: 1.6210
INFO - 2017-02-07 15:19:29 --> Config Class Initialized
INFO - 2017-02-07 15:19:29 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:19:29 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:19:29 --> Utf8 Class Initialized
INFO - 2017-02-07 15:19:29 --> URI Class Initialized
DEBUG - 2017-02-07 15:19:29 --> No URI present. Default controller set.
INFO - 2017-02-07 15:19:29 --> Router Class Initialized
INFO - 2017-02-07 15:19:29 --> Output Class Initialized
INFO - 2017-02-07 15:19:29 --> Security Class Initialized
DEBUG - 2017-02-07 15:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:19:29 --> Input Class Initialized
INFO - 2017-02-07 15:19:29 --> Language Class Initialized
INFO - 2017-02-07 15:19:29 --> Loader Class Initialized
INFO - 2017-02-07 15:19:30 --> Database Driver Class Initialized
INFO - 2017-02-07 15:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:19:30 --> Controller Class Initialized
INFO - 2017-02-07 15:19:30 --> Helper loaded: url_helper
DEBUG - 2017-02-07 15:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 15:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 15:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 15:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 15:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 15:19:30 --> Final output sent to browser
DEBUG - 2017-02-07 15:19:30 --> Total execution time: 1.4160
INFO - 2017-02-07 16:17:12 --> Config Class Initialized
INFO - 2017-02-07 16:17:12 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:17:12 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:17:12 --> Utf8 Class Initialized
INFO - 2017-02-07 16:17:12 --> URI Class Initialized
DEBUG - 2017-02-07 16:17:12 --> No URI present. Default controller set.
INFO - 2017-02-07 16:17:12 --> Router Class Initialized
INFO - 2017-02-07 16:17:12 --> Output Class Initialized
INFO - 2017-02-07 16:17:12 --> Security Class Initialized
DEBUG - 2017-02-07 16:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:17:12 --> Input Class Initialized
INFO - 2017-02-07 16:17:12 --> Language Class Initialized
INFO - 2017-02-07 16:17:12 --> Loader Class Initialized
INFO - 2017-02-07 16:17:13 --> Database Driver Class Initialized
INFO - 2017-02-07 16:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:17:18 --> Controller Class Initialized
INFO - 2017-02-07 16:17:18 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:17:18 --> Final output sent to browser
DEBUG - 2017-02-07 16:17:19 --> Total execution time: 6.9617
INFO - 2017-02-07 16:17:31 --> Config Class Initialized
INFO - 2017-02-07 16:17:31 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:17:31 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:17:31 --> Utf8 Class Initialized
INFO - 2017-02-07 16:17:31 --> URI Class Initialized
INFO - 2017-02-07 16:17:31 --> Router Class Initialized
INFO - 2017-02-07 16:17:31 --> Output Class Initialized
INFO - 2017-02-07 16:17:31 --> Security Class Initialized
DEBUG - 2017-02-07 16:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:17:31 --> Input Class Initialized
INFO - 2017-02-07 16:17:31 --> Language Class Initialized
INFO - 2017-02-07 16:17:31 --> Loader Class Initialized
INFO - 2017-02-07 16:17:31 --> Database Driver Class Initialized
INFO - 2017-02-07 16:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:17:32 --> Controller Class Initialized
INFO - 2017-02-07 16:17:32 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:17:32 --> Final output sent to browser
DEBUG - 2017-02-07 16:17:32 --> Total execution time: 1.6710
INFO - 2017-02-07 16:17:53 --> Config Class Initialized
INFO - 2017-02-07 16:17:53 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:17:53 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:17:53 --> Utf8 Class Initialized
INFO - 2017-02-07 16:17:53 --> URI Class Initialized
DEBUG - 2017-02-07 16:17:54 --> No URI present. Default controller set.
INFO - 2017-02-07 16:17:54 --> Router Class Initialized
INFO - 2017-02-07 16:17:54 --> Output Class Initialized
INFO - 2017-02-07 16:17:54 --> Security Class Initialized
DEBUG - 2017-02-07 16:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:17:54 --> Input Class Initialized
INFO - 2017-02-07 16:17:55 --> Language Class Initialized
INFO - 2017-02-07 16:17:55 --> Loader Class Initialized
INFO - 2017-02-07 16:17:57 --> Database Driver Class Initialized
INFO - 2017-02-07 16:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:18:02 --> Controller Class Initialized
INFO - 2017-02-07 16:18:02 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:18:09 --> Config Class Initialized
INFO - 2017-02-07 16:18:09 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:18:10 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:18:10 --> Utf8 Class Initialized
INFO - 2017-02-07 16:18:10 --> URI Class Initialized
DEBUG - 2017-02-07 16:18:10 --> No URI present. Default controller set.
INFO - 2017-02-07 16:18:10 --> Router Class Initialized
INFO - 2017-02-07 16:18:10 --> Output Class Initialized
INFO - 2017-02-07 16:18:10 --> Security Class Initialized
DEBUG - 2017-02-07 16:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:18:10 --> Input Class Initialized
INFO - 2017-02-07 16:18:10 --> Language Class Initialized
INFO - 2017-02-07 16:18:10 --> Loader Class Initialized
INFO - 2017-02-07 16:18:10 --> Database Driver Class Initialized
INFO - 2017-02-07 16:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:18:10 --> Controller Class Initialized
INFO - 2017-02-07 16:18:10 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:20:06 --> Config Class Initialized
INFO - 2017-02-07 16:20:06 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:20:06 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:20:06 --> Utf8 Class Initialized
INFO - 2017-02-07 16:20:06 --> URI Class Initialized
DEBUG - 2017-02-07 16:20:06 --> No URI present. Default controller set.
INFO - 2017-02-07 16:20:06 --> Router Class Initialized
INFO - 2017-02-07 16:20:06 --> Output Class Initialized
INFO - 2017-02-07 16:20:06 --> Security Class Initialized
DEBUG - 2017-02-07 16:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:20:06 --> Input Class Initialized
INFO - 2017-02-07 16:20:06 --> Language Class Initialized
INFO - 2017-02-07 16:20:06 --> Loader Class Initialized
INFO - 2017-02-07 16:20:07 --> Database Driver Class Initialized
INFO - 2017-02-07 16:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:20:07 --> Controller Class Initialized
INFO - 2017-02-07 16:20:07 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:20:07 --> Final output sent to browser
DEBUG - 2017-02-07 16:20:07 --> Total execution time: 2.0409
INFO - 2017-02-07 16:20:08 --> Config Class Initialized
INFO - 2017-02-07 16:20:08 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:20:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:20:08 --> Utf8 Class Initialized
INFO - 2017-02-07 16:20:08 --> URI Class Initialized
INFO - 2017-02-07 16:20:08 --> Router Class Initialized
INFO - 2017-02-07 16:20:08 --> Output Class Initialized
INFO - 2017-02-07 16:20:08 --> Security Class Initialized
DEBUG - 2017-02-07 16:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:20:08 --> Input Class Initialized
INFO - 2017-02-07 16:20:08 --> Language Class Initialized
INFO - 2017-02-07 16:20:08 --> Loader Class Initialized
INFO - 2017-02-07 16:20:08 --> Database Driver Class Initialized
INFO - 2017-02-07 16:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:20:08 --> Controller Class Initialized
INFO - 2017-02-07 16:20:08 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:20:08 --> Final output sent to browser
DEBUG - 2017-02-07 16:20:08 --> Total execution time: 0.0152
INFO - 2017-02-07 16:20:35 --> Config Class Initialized
INFO - 2017-02-07 16:20:35 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:20:35 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:20:35 --> Utf8 Class Initialized
INFO - 2017-02-07 16:20:35 --> URI Class Initialized
INFO - 2017-02-07 16:20:35 --> Router Class Initialized
INFO - 2017-02-07 16:20:35 --> Output Class Initialized
INFO - 2017-02-07 16:20:35 --> Security Class Initialized
DEBUG - 2017-02-07 16:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:20:35 --> Input Class Initialized
INFO - 2017-02-07 16:20:35 --> Language Class Initialized
INFO - 2017-02-07 16:20:36 --> Loader Class Initialized
INFO - 2017-02-07 16:20:36 --> Database Driver Class Initialized
INFO - 2017-02-07 16:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:20:36 --> Controller Class Initialized
INFO - 2017-02-07 16:20:36 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:20:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-07 16:20:39 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-07 16:20:39 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-07 16:20:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-07 16:20:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-07 16:20:41 --> Config Class Initialized
INFO - 2017-02-07 16:20:41 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:20:41 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:20:41 --> Utf8 Class Initialized
INFO - 2017-02-07 16:20:41 --> URI Class Initialized
INFO - 2017-02-07 16:20:41 --> Router Class Initialized
INFO - 2017-02-07 16:20:41 --> Output Class Initialized
INFO - 2017-02-07 16:20:41 --> Security Class Initialized
DEBUG - 2017-02-07 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:20:41 --> Input Class Initialized
INFO - 2017-02-07 16:20:41 --> Language Class Initialized
INFO - 2017-02-07 16:20:42 --> Loader Class Initialized
INFO - 2017-02-07 16:20:42 --> Database Driver Class Initialized
INFO - 2017-02-07 16:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:20:42 --> Controller Class Initialized
INFO - 2017-02-07 16:20:42 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:20:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:20:42 --> Final output sent to browser
DEBUG - 2017-02-07 16:20:42 --> Total execution time: 1.1476
INFO - 2017-02-07 16:20:50 --> Config Class Initialized
INFO - 2017-02-07 16:20:51 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:20:51 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:20:51 --> Utf8 Class Initialized
INFO - 2017-02-07 16:20:51 --> URI Class Initialized
INFO - 2017-02-07 16:20:51 --> Router Class Initialized
INFO - 2017-02-07 16:20:51 --> Output Class Initialized
INFO - 2017-02-07 16:20:51 --> Security Class Initialized
DEBUG - 2017-02-07 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:20:51 --> Input Class Initialized
INFO - 2017-02-07 16:20:51 --> Language Class Initialized
INFO - 2017-02-07 16:20:51 --> Loader Class Initialized
INFO - 2017-02-07 16:20:51 --> Database Driver Class Initialized
INFO - 2017-02-07 16:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:20:51 --> Controller Class Initialized
INFO - 2017-02-07 16:20:51 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:20:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-07 16:21:00 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-07 16:21:00 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-07 16:21:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-07 16:21:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-07 16:21:08 --> Config Class Initialized
INFO - 2017-02-07 16:21:08 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:21:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:21:08 --> Utf8 Class Initialized
INFO - 2017-02-07 16:21:08 --> URI Class Initialized
INFO - 2017-02-07 16:21:08 --> Router Class Initialized
INFO - 2017-02-07 16:21:08 --> Output Class Initialized
INFO - 2017-02-07 16:21:08 --> Security Class Initialized
DEBUG - 2017-02-07 16:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:21:08 --> Input Class Initialized
INFO - 2017-02-07 16:21:08 --> Language Class Initialized
INFO - 2017-02-07 16:21:08 --> Loader Class Initialized
INFO - 2017-02-07 16:21:09 --> Database Driver Class Initialized
INFO - 2017-02-07 16:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:21:09 --> Controller Class Initialized
INFO - 2017-02-07 16:21:09 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:21:09 --> Final output sent to browser
DEBUG - 2017-02-07 16:21:09 --> Total execution time: 3.3726
INFO - 2017-02-07 16:42:41 --> Config Class Initialized
INFO - 2017-02-07 16:42:41 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:42:41 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:42:41 --> Utf8 Class Initialized
INFO - 2017-02-07 16:42:41 --> URI Class Initialized
INFO - 2017-02-07 16:42:41 --> Router Class Initialized
INFO - 2017-02-07 16:42:41 --> Output Class Initialized
INFO - 2017-02-07 16:42:41 --> Security Class Initialized
DEBUG - 2017-02-07 16:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:42:41 --> Input Class Initialized
INFO - 2017-02-07 16:42:41 --> Language Class Initialized
INFO - 2017-02-07 16:42:41 --> Loader Class Initialized
INFO - 2017-02-07 16:42:42 --> Database Driver Class Initialized
INFO - 2017-02-07 16:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:42:42 --> Controller Class Initialized
INFO - 2017-02-07 16:42:42 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:42:42 --> Final output sent to browser
DEBUG - 2017-02-07 16:42:42 --> Total execution time: 1.2627
INFO - 2017-02-07 16:42:42 --> Config Class Initialized
INFO - 2017-02-07 16:42:42 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:42:42 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:42:42 --> Utf8 Class Initialized
INFO - 2017-02-07 16:42:42 --> URI Class Initialized
DEBUG - 2017-02-07 16:42:42 --> No URI present. Default controller set.
INFO - 2017-02-07 16:42:42 --> Router Class Initialized
INFO - 2017-02-07 16:42:42 --> Output Class Initialized
INFO - 2017-02-07 16:42:42 --> Security Class Initialized
DEBUG - 2017-02-07 16:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:42:42 --> Input Class Initialized
INFO - 2017-02-07 16:42:42 --> Language Class Initialized
INFO - 2017-02-07 16:42:42 --> Loader Class Initialized
INFO - 2017-02-07 16:42:42 --> Database Driver Class Initialized
INFO - 2017-02-07 16:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:42:42 --> Controller Class Initialized
INFO - 2017-02-07 16:42:42 --> Helper loaded: url_helper
DEBUG - 2017-02-07 16:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 16:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 16:42:42 --> Final output sent to browser
DEBUG - 2017-02-07 16:42:42 --> Total execution time: 0.0152
INFO - 2017-02-07 17:17:08 --> Config Class Initialized
INFO - 2017-02-07 17:17:08 --> Hooks Class Initialized
DEBUG - 2017-02-07 17:17:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 17:17:08 --> Utf8 Class Initialized
INFO - 2017-02-07 17:17:08 --> URI Class Initialized
INFO - 2017-02-07 17:17:08 --> Router Class Initialized
INFO - 2017-02-07 17:17:09 --> Output Class Initialized
INFO - 2017-02-07 17:17:09 --> Security Class Initialized
DEBUG - 2017-02-07 17:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 17:17:09 --> Input Class Initialized
INFO - 2017-02-07 17:17:09 --> Language Class Initialized
INFO - 2017-02-07 17:17:09 --> Loader Class Initialized
INFO - 2017-02-07 17:17:09 --> Database Driver Class Initialized
INFO - 2017-02-07 17:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 17:17:10 --> Controller Class Initialized
INFO - 2017-02-07 17:17:10 --> Helper loaded: url_helper
DEBUG - 2017-02-07 17:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 17:17:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 17:17:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 17:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 17:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 17:17:11 --> Final output sent to browser
DEBUG - 2017-02-07 17:17:11 --> Total execution time: 3.0625
INFO - 2017-02-07 17:17:12 --> Config Class Initialized
INFO - 2017-02-07 17:17:12 --> Hooks Class Initialized
DEBUG - 2017-02-07 17:17:12 --> UTF-8 Support Enabled
INFO - 2017-02-07 17:17:12 --> Utf8 Class Initialized
INFO - 2017-02-07 17:17:12 --> URI Class Initialized
DEBUG - 2017-02-07 17:17:12 --> No URI present. Default controller set.
INFO - 2017-02-07 17:17:12 --> Router Class Initialized
INFO - 2017-02-07 17:17:13 --> Output Class Initialized
INFO - 2017-02-07 17:17:13 --> Security Class Initialized
DEBUG - 2017-02-07 17:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 17:17:13 --> Input Class Initialized
INFO - 2017-02-07 17:17:13 --> Language Class Initialized
INFO - 2017-02-07 17:17:13 --> Loader Class Initialized
INFO - 2017-02-07 17:17:13 --> Database Driver Class Initialized
INFO - 2017-02-07 17:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 17:17:14 --> Controller Class Initialized
INFO - 2017-02-07 17:17:14 --> Helper loaded: url_helper
DEBUG - 2017-02-07 17:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 17:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 17:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 17:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 17:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 17:17:14 --> Final output sent to browser
DEBUG - 2017-02-07 17:17:14 --> Total execution time: 2.0142
INFO - 2017-02-07 17:18:15 --> Config Class Initialized
INFO - 2017-02-07 17:18:15 --> Hooks Class Initialized
INFO - 2017-02-07 17:18:15 --> Config Class Initialized
INFO - 2017-02-07 17:18:15 --> Hooks Class Initialized
DEBUG - 2017-02-07 17:18:15 --> UTF-8 Support Enabled
INFO - 2017-02-07 17:18:15 --> Utf8 Class Initialized
DEBUG - 2017-02-07 17:18:15 --> UTF-8 Support Enabled
INFO - 2017-02-07 17:18:15 --> URI Class Initialized
INFO - 2017-02-07 17:18:15 --> Utf8 Class Initialized
INFO - 2017-02-07 17:18:15 --> URI Class Initialized
DEBUG - 2017-02-07 17:18:15 --> No URI present. Default controller set.
INFO - 2017-02-07 17:18:15 --> Router Class Initialized
INFO - 2017-02-07 17:18:15 --> Router Class Initialized
INFO - 2017-02-07 17:18:15 --> Output Class Initialized
INFO - 2017-02-07 17:18:15 --> Output Class Initialized
INFO - 2017-02-07 17:18:16 --> Security Class Initialized
INFO - 2017-02-07 17:18:16 --> Security Class Initialized
DEBUG - 2017-02-07 17:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 17:18:16 --> Input Class Initialized
INFO - 2017-02-07 17:18:16 --> Language Class Initialized
DEBUG - 2017-02-07 17:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 17:18:16 --> Input Class Initialized
INFO - 2017-02-07 17:18:16 --> Language Class Initialized
INFO - 2017-02-07 17:18:16 --> Loader Class Initialized
INFO - 2017-02-07 17:18:16 --> Loader Class Initialized
INFO - 2017-02-07 17:18:16 --> Database Driver Class Initialized
INFO - 2017-02-07 17:18:16 --> Database Driver Class Initialized
INFO - 2017-02-07 17:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 17:18:17 --> Controller Class Initialized
INFO - 2017-02-07 17:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 17:18:17 --> Helper loaded: url_helper
INFO - 2017-02-07 17:18:17 --> Controller Class Initialized
DEBUG - 2017-02-07 17:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 17:18:17 --> Helper loaded: url_helper
DEBUG - 2017-02-07 17:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 17:18:17 --> Helper loaded: form_helper
INFO - 2017-02-07 17:18:17 --> Form Validation Class Initialized
INFO - 2017-02-07 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-07 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-07 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-07 17:18:17 --> Final output sent to browser
DEBUG - 2017-02-07 17:18:17 --> Total execution time: 2.4504
INFO - 2017-02-07 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 17:18:17 --> Final output sent to browser
DEBUG - 2017-02-07 17:18:17 --> Total execution time: 2.4526
INFO - 2017-02-07 17:18:18 --> Config Class Initialized
INFO - 2017-02-07 17:18:18 --> Hooks Class Initialized
DEBUG - 2017-02-07 17:18:18 --> UTF-8 Support Enabled
INFO - 2017-02-07 17:18:18 --> Utf8 Class Initialized
INFO - 2017-02-07 17:18:18 --> URI Class Initialized
INFO - 2017-02-07 17:18:18 --> Router Class Initialized
INFO - 2017-02-07 17:18:18 --> Output Class Initialized
INFO - 2017-02-07 17:18:18 --> Security Class Initialized
DEBUG - 2017-02-07 17:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 17:18:18 --> Input Class Initialized
INFO - 2017-02-07 17:18:18 --> Language Class Initialized
INFO - 2017-02-07 17:18:18 --> Loader Class Initialized
INFO - 2017-02-07 17:18:18 --> Database Driver Class Initialized
INFO - 2017-02-07 17:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 17:18:18 --> Controller Class Initialized
INFO - 2017-02-07 17:18:18 --> Helper loaded: url_helper
DEBUG - 2017-02-07 17:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 17:18:18 --> Final output sent to browser
DEBUG - 2017-02-07 17:18:18 --> Total execution time: 0.0142
INFO - 2017-02-07 17:44:22 --> Config Class Initialized
INFO - 2017-02-07 17:44:22 --> Hooks Class Initialized
INFO - 2017-02-07 17:44:22 --> Config Class Initialized
INFO - 2017-02-07 17:44:22 --> Hooks Class Initialized
DEBUG - 2017-02-07 17:44:22 --> UTF-8 Support Enabled
DEBUG - 2017-02-07 17:44:22 --> UTF-8 Support Enabled
INFO - 2017-02-07 17:44:22 --> Utf8 Class Initialized
INFO - 2017-02-07 17:44:22 --> Utf8 Class Initialized
INFO - 2017-02-07 17:44:22 --> URI Class Initialized
INFO - 2017-02-07 17:44:22 --> URI Class Initialized
INFO - 2017-02-07 17:44:22 --> Router Class Initialized
DEBUG - 2017-02-07 17:44:22 --> No URI present. Default controller set.
INFO - 2017-02-07 17:44:22 --> Router Class Initialized
INFO - 2017-02-07 17:44:22 --> Output Class Initialized
INFO - 2017-02-07 17:44:22 --> Security Class Initialized
INFO - 2017-02-07 17:44:22 --> Output Class Initialized
INFO - 2017-02-07 17:44:22 --> Security Class Initialized
DEBUG - 2017-02-07 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 17:44:22 --> Input Class Initialized
INFO - 2017-02-07 17:44:22 --> Language Class Initialized
DEBUG - 2017-02-07 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 17:44:22 --> Input Class Initialized
INFO - 2017-02-07 17:44:22 --> Language Class Initialized
INFO - 2017-02-07 17:44:22 --> Loader Class Initialized
INFO - 2017-02-07 17:44:22 --> Loader Class Initialized
INFO - 2017-02-07 17:44:22 --> Database Driver Class Initialized
INFO - 2017-02-07 17:44:22 --> Database Driver Class Initialized
INFO - 2017-02-07 17:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 17:44:23 --> Controller Class Initialized
INFO - 2017-02-07 17:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 17:44:23 --> Controller Class Initialized
INFO - 2017-02-07 17:44:23 --> Helper loaded: url_helper
INFO - 2017-02-07 17:44:23 --> Helper loaded: url_helper
DEBUG - 2017-02-07 17:44:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-02-07 17:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 17:44:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 17:44:23 --> Final output sent to browser
DEBUG - 2017-02-07 17:44:23 --> Total execution time: 1.4000
INFO - 2017-02-07 17:44:23 --> Final output sent to browser
DEBUG - 2017-02-07 17:44:23 --> Total execution time: 1.4000
INFO - 2017-02-07 18:32:16 --> Config Class Initialized
INFO - 2017-02-07 18:32:16 --> Hooks Class Initialized
DEBUG - 2017-02-07 18:32:16 --> UTF-8 Support Enabled
INFO - 2017-02-07 18:32:16 --> Utf8 Class Initialized
INFO - 2017-02-07 18:32:16 --> URI Class Initialized
INFO - 2017-02-07 18:32:16 --> Router Class Initialized
INFO - 2017-02-07 18:32:16 --> Output Class Initialized
INFO - 2017-02-07 18:32:16 --> Security Class Initialized
DEBUG - 2017-02-07 18:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 18:32:16 --> Input Class Initialized
INFO - 2017-02-07 18:32:16 --> Language Class Initialized
INFO - 2017-02-07 18:32:16 --> Loader Class Initialized
INFO - 2017-02-07 18:32:16 --> Database Driver Class Initialized
INFO - 2017-02-07 18:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 18:32:16 --> Controller Class Initialized
INFO - 2017-02-07 18:32:16 --> Helper loaded: url_helper
DEBUG - 2017-02-07 18:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 18:32:16 --> Final output sent to browser
DEBUG - 2017-02-07 18:32:16 --> Total execution time: 0.0155
INFO - 2017-02-07 18:32:16 --> Config Class Initialized
INFO - 2017-02-07 18:32:16 --> Hooks Class Initialized
DEBUG - 2017-02-07 18:32:16 --> UTF-8 Support Enabled
INFO - 2017-02-07 18:32:16 --> Utf8 Class Initialized
INFO - 2017-02-07 18:32:16 --> URI Class Initialized
DEBUG - 2017-02-07 18:32:16 --> No URI present. Default controller set.
INFO - 2017-02-07 18:32:16 --> Router Class Initialized
INFO - 2017-02-07 18:32:16 --> Output Class Initialized
INFO - 2017-02-07 18:32:16 --> Security Class Initialized
DEBUG - 2017-02-07 18:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 18:32:16 --> Input Class Initialized
INFO - 2017-02-07 18:32:16 --> Language Class Initialized
INFO - 2017-02-07 18:32:16 --> Loader Class Initialized
INFO - 2017-02-07 18:32:16 --> Database Driver Class Initialized
INFO - 2017-02-07 18:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 18:32:16 --> Controller Class Initialized
INFO - 2017-02-07 18:32:16 --> Helper loaded: url_helper
DEBUG - 2017-02-07 18:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 18:32:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 18:32:16 --> Final output sent to browser
DEBUG - 2017-02-07 18:32:16 --> Total execution time: 0.0386
INFO - 2017-02-07 18:36:44 --> Config Class Initialized
INFO - 2017-02-07 18:36:44 --> Hooks Class Initialized
DEBUG - 2017-02-07 18:36:44 --> UTF-8 Support Enabled
INFO - 2017-02-07 18:36:44 --> Utf8 Class Initialized
INFO - 2017-02-07 18:36:44 --> URI Class Initialized
DEBUG - 2017-02-07 18:36:44 --> No URI present. Default controller set.
INFO - 2017-02-07 18:36:44 --> Router Class Initialized
INFO - 2017-02-07 18:36:44 --> Output Class Initialized
INFO - 2017-02-07 18:36:44 --> Security Class Initialized
DEBUG - 2017-02-07 18:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 18:36:44 --> Input Class Initialized
INFO - 2017-02-07 18:36:44 --> Language Class Initialized
INFO - 2017-02-07 18:36:44 --> Loader Class Initialized
INFO - 2017-02-07 18:36:44 --> Database Driver Class Initialized
INFO - 2017-02-07 18:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 18:36:44 --> Controller Class Initialized
INFO - 2017-02-07 18:36:44 --> Helper loaded: url_helper
DEBUG - 2017-02-07 18:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 18:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 18:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 18:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 18:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 18:36:44 --> Final output sent to browser
DEBUG - 2017-02-07 18:36:44 --> Total execution time: 0.0145
INFO - 2017-02-07 19:50:43 --> Config Class Initialized
INFO - 2017-02-07 19:50:43 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:50:43 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:50:43 --> Utf8 Class Initialized
INFO - 2017-02-07 19:50:43 --> URI Class Initialized
DEBUG - 2017-02-07 19:50:43 --> No URI present. Default controller set.
INFO - 2017-02-07 19:50:43 --> Router Class Initialized
INFO - 2017-02-07 19:50:43 --> Output Class Initialized
INFO - 2017-02-07 19:50:43 --> Security Class Initialized
DEBUG - 2017-02-07 19:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:50:43 --> Input Class Initialized
INFO - 2017-02-07 19:50:43 --> Language Class Initialized
INFO - 2017-02-07 19:50:43 --> Loader Class Initialized
INFO - 2017-02-07 19:50:43 --> Database Driver Class Initialized
INFO - 2017-02-07 19:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:50:43 --> Controller Class Initialized
INFO - 2017-02-07 19:50:43 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:50:43 --> Final output sent to browser
DEBUG - 2017-02-07 19:50:43 --> Total execution time: 0.0209
INFO - 2017-02-07 19:50:46 --> Config Class Initialized
INFO - 2017-02-07 19:50:46 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:50:46 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:50:46 --> Utf8 Class Initialized
INFO - 2017-02-07 19:50:46 --> URI Class Initialized
INFO - 2017-02-07 19:50:46 --> Router Class Initialized
INFO - 2017-02-07 19:50:46 --> Output Class Initialized
INFO - 2017-02-07 19:50:46 --> Security Class Initialized
DEBUG - 2017-02-07 19:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:50:46 --> Input Class Initialized
INFO - 2017-02-07 19:50:46 --> Language Class Initialized
INFO - 2017-02-07 19:50:46 --> Loader Class Initialized
INFO - 2017-02-07 19:50:46 --> Database Driver Class Initialized
INFO - 2017-02-07 19:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:50:46 --> Controller Class Initialized
INFO - 2017-02-07 19:50:46 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:50:46 --> Final output sent to browser
DEBUG - 2017-02-07 19:50:46 --> Total execution time: 0.0135
INFO - 2017-02-07 19:51:50 --> Config Class Initialized
INFO - 2017-02-07 19:51:50 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:51:50 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:51:50 --> Utf8 Class Initialized
INFO - 2017-02-07 19:51:50 --> URI Class Initialized
INFO - 2017-02-07 19:51:50 --> Router Class Initialized
INFO - 2017-02-07 19:51:50 --> Output Class Initialized
INFO - 2017-02-07 19:51:50 --> Security Class Initialized
DEBUG - 2017-02-07 19:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:51:50 --> Input Class Initialized
INFO - 2017-02-07 19:51:50 --> Language Class Initialized
INFO - 2017-02-07 19:51:50 --> Loader Class Initialized
INFO - 2017-02-07 19:51:50 --> Database Driver Class Initialized
INFO - 2017-02-07 19:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:51:50 --> Controller Class Initialized
INFO - 2017-02-07 19:51:50 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:51:52 --> Config Class Initialized
INFO - 2017-02-07 19:51:52 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:51:52 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:51:52 --> Utf8 Class Initialized
INFO - 2017-02-07 19:51:52 --> URI Class Initialized
INFO - 2017-02-07 19:51:52 --> Router Class Initialized
INFO - 2017-02-07 19:51:52 --> Output Class Initialized
INFO - 2017-02-07 19:51:52 --> Security Class Initialized
DEBUG - 2017-02-07 19:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:51:52 --> Input Class Initialized
INFO - 2017-02-07 19:51:52 --> Language Class Initialized
INFO - 2017-02-07 19:51:52 --> Loader Class Initialized
INFO - 2017-02-07 19:51:52 --> Database Driver Class Initialized
INFO - 2017-02-07 19:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:51:52 --> Controller Class Initialized
INFO - 2017-02-07 19:51:52 --> Helper loaded: date_helper
DEBUG - 2017-02-07 19:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:51:52 --> Helper loaded: url_helper
INFO - 2017-02-07 19:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 19:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 19:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 19:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:51:52 --> Final output sent to browser
DEBUG - 2017-02-07 19:51:52 --> Total execution time: 0.1495
INFO - 2017-02-07 19:51:53 --> Config Class Initialized
INFO - 2017-02-07 19:51:53 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:51:53 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:51:53 --> Utf8 Class Initialized
INFO - 2017-02-07 19:51:53 --> URI Class Initialized
INFO - 2017-02-07 19:51:53 --> Router Class Initialized
INFO - 2017-02-07 19:51:53 --> Output Class Initialized
INFO - 2017-02-07 19:51:53 --> Security Class Initialized
DEBUG - 2017-02-07 19:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:51:53 --> Input Class Initialized
INFO - 2017-02-07 19:51:53 --> Language Class Initialized
INFO - 2017-02-07 19:51:53 --> Loader Class Initialized
INFO - 2017-02-07 19:51:53 --> Database Driver Class Initialized
INFO - 2017-02-07 19:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:51:53 --> Controller Class Initialized
INFO - 2017-02-07 19:51:53 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:51:53 --> Final output sent to browser
DEBUG - 2017-02-07 19:51:53 --> Total execution time: 0.0134
INFO - 2017-02-07 19:52:03 --> Config Class Initialized
INFO - 2017-02-07 19:52:03 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:52:03 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:52:03 --> Utf8 Class Initialized
INFO - 2017-02-07 19:52:03 --> URI Class Initialized
DEBUG - 2017-02-07 19:52:03 --> No URI present. Default controller set.
INFO - 2017-02-07 19:52:03 --> Router Class Initialized
INFO - 2017-02-07 19:52:03 --> Output Class Initialized
INFO - 2017-02-07 19:52:03 --> Security Class Initialized
DEBUG - 2017-02-07 19:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:52:03 --> Input Class Initialized
INFO - 2017-02-07 19:52:03 --> Language Class Initialized
INFO - 2017-02-07 19:52:03 --> Loader Class Initialized
INFO - 2017-02-07 19:52:03 --> Database Driver Class Initialized
INFO - 2017-02-07 19:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:52:03 --> Controller Class Initialized
INFO - 2017-02-07 19:52:03 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:52:03 --> Final output sent to browser
DEBUG - 2017-02-07 19:52:03 --> Total execution time: 0.0137
INFO - 2017-02-07 19:52:05 --> Config Class Initialized
INFO - 2017-02-07 19:52:05 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:52:05 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:52:05 --> Utf8 Class Initialized
INFO - 2017-02-07 19:52:05 --> URI Class Initialized
INFO - 2017-02-07 19:52:05 --> Router Class Initialized
INFO - 2017-02-07 19:52:05 --> Output Class Initialized
INFO - 2017-02-07 19:52:05 --> Security Class Initialized
DEBUG - 2017-02-07 19:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:52:05 --> Input Class Initialized
INFO - 2017-02-07 19:52:05 --> Language Class Initialized
INFO - 2017-02-07 19:52:05 --> Loader Class Initialized
INFO - 2017-02-07 19:52:05 --> Database Driver Class Initialized
INFO - 2017-02-07 19:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:52:05 --> Controller Class Initialized
INFO - 2017-02-07 19:52:05 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:52:05 --> Final output sent to browser
DEBUG - 2017-02-07 19:52:05 --> Total execution time: 0.0137
INFO - 2017-02-07 19:52:57 --> Config Class Initialized
INFO - 2017-02-07 19:52:57 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:52:57 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:52:57 --> Utf8 Class Initialized
INFO - 2017-02-07 19:52:57 --> URI Class Initialized
INFO - 2017-02-07 19:52:57 --> Router Class Initialized
INFO - 2017-02-07 19:52:57 --> Output Class Initialized
INFO - 2017-02-07 19:52:57 --> Security Class Initialized
DEBUG - 2017-02-07 19:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:52:57 --> Input Class Initialized
INFO - 2017-02-07 19:52:57 --> Language Class Initialized
INFO - 2017-02-07 19:52:57 --> Loader Class Initialized
INFO - 2017-02-07 19:52:57 --> Database Driver Class Initialized
INFO - 2017-02-07 19:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:52:57 --> Controller Class Initialized
INFO - 2017-02-07 19:52:57 --> Helper loaded: date_helper
DEBUG - 2017-02-07 19:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:52:57 --> Helper loaded: url_helper
INFO - 2017-02-07 19:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 19:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 19:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 19:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:52:57 --> Final output sent to browser
DEBUG - 2017-02-07 19:52:57 --> Total execution time: 0.0134
INFO - 2017-02-07 19:52:58 --> Config Class Initialized
INFO - 2017-02-07 19:52:58 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:52:58 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:52:58 --> Utf8 Class Initialized
INFO - 2017-02-07 19:52:58 --> URI Class Initialized
INFO - 2017-02-07 19:52:58 --> Router Class Initialized
INFO - 2017-02-07 19:52:58 --> Output Class Initialized
INFO - 2017-02-07 19:52:58 --> Security Class Initialized
DEBUG - 2017-02-07 19:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:52:58 --> Input Class Initialized
INFO - 2017-02-07 19:52:58 --> Language Class Initialized
INFO - 2017-02-07 19:52:58 --> Loader Class Initialized
INFO - 2017-02-07 19:52:58 --> Database Driver Class Initialized
INFO - 2017-02-07 19:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:52:58 --> Controller Class Initialized
INFO - 2017-02-07 19:52:58 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:52:58 --> Final output sent to browser
DEBUG - 2017-02-07 19:52:58 --> Total execution time: 0.0139
INFO - 2017-02-07 19:53:00 --> Config Class Initialized
INFO - 2017-02-07 19:53:00 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:00 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:00 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:00 --> URI Class Initialized
DEBUG - 2017-02-07 19:53:00 --> No URI present. Default controller set.
INFO - 2017-02-07 19:53:00 --> Router Class Initialized
INFO - 2017-02-07 19:53:00 --> Output Class Initialized
INFO - 2017-02-07 19:53:00 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:00 --> Input Class Initialized
INFO - 2017-02-07 19:53:00 --> Language Class Initialized
INFO - 2017-02-07 19:53:00 --> Loader Class Initialized
INFO - 2017-02-07 19:53:00 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:00 --> Controller Class Initialized
INFO - 2017-02-07 19:53:00 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:00 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:00 --> Total execution time: 0.0144
INFO - 2017-02-07 19:53:02 --> Config Class Initialized
INFO - 2017-02-07 19:53:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:02 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:02 --> URI Class Initialized
INFO - 2017-02-07 19:53:02 --> Router Class Initialized
INFO - 2017-02-07 19:53:02 --> Output Class Initialized
INFO - 2017-02-07 19:53:02 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:02 --> Input Class Initialized
INFO - 2017-02-07 19:53:02 --> Language Class Initialized
INFO - 2017-02-07 19:53:02 --> Loader Class Initialized
INFO - 2017-02-07 19:53:02 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:02 --> Controller Class Initialized
INFO - 2017-02-07 19:53:02 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:53:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:53:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:02 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:02 --> Total execution time: 0.0130
INFO - 2017-02-07 19:53:32 --> Config Class Initialized
INFO - 2017-02-07 19:53:32 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:32 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:32 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:32 --> URI Class Initialized
INFO - 2017-02-07 19:53:32 --> Router Class Initialized
INFO - 2017-02-07 19:53:32 --> Output Class Initialized
INFO - 2017-02-07 19:53:32 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:32 --> Input Class Initialized
INFO - 2017-02-07 19:53:32 --> Language Class Initialized
INFO - 2017-02-07 19:53:32 --> Loader Class Initialized
INFO - 2017-02-07 19:53:32 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:32 --> Controller Class Initialized
INFO - 2017-02-07 19:53:32 --> Helper loaded: date_helper
DEBUG - 2017-02-07 19:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:32 --> Helper loaded: url_helper
INFO - 2017-02-07 19:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 19:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 19:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 19:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:32 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:32 --> Total execution time: 0.0134
INFO - 2017-02-07 19:53:33 --> Config Class Initialized
INFO - 2017-02-07 19:53:33 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:33 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:33 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:33 --> URI Class Initialized
INFO - 2017-02-07 19:53:33 --> Router Class Initialized
INFO - 2017-02-07 19:53:33 --> Output Class Initialized
INFO - 2017-02-07 19:53:33 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:33 --> Input Class Initialized
INFO - 2017-02-07 19:53:33 --> Language Class Initialized
INFO - 2017-02-07 19:53:33 --> Loader Class Initialized
INFO - 2017-02-07 19:53:33 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:33 --> Controller Class Initialized
INFO - 2017-02-07 19:53:33 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:33 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:33 --> Total execution time: 0.0160
INFO - 2017-02-07 19:53:35 --> Config Class Initialized
INFO - 2017-02-07 19:53:35 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:35 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:35 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:35 --> URI Class Initialized
INFO - 2017-02-07 19:53:35 --> Router Class Initialized
INFO - 2017-02-07 19:53:35 --> Output Class Initialized
INFO - 2017-02-07 19:53:35 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:35 --> Input Class Initialized
INFO - 2017-02-07 19:53:35 --> Language Class Initialized
INFO - 2017-02-07 19:53:35 --> Loader Class Initialized
INFO - 2017-02-07 19:53:35 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:35 --> Controller Class Initialized
INFO - 2017-02-07 19:53:35 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:36 --> Config Class Initialized
INFO - 2017-02-07 19:53:36 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:36 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:36 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:36 --> URI Class Initialized
INFO - 2017-02-07 19:53:36 --> Router Class Initialized
INFO - 2017-02-07 19:53:36 --> Output Class Initialized
INFO - 2017-02-07 19:53:36 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:36 --> Input Class Initialized
INFO - 2017-02-07 19:53:36 --> Language Class Initialized
INFO - 2017-02-07 19:53:36 --> Loader Class Initialized
INFO - 2017-02-07 19:53:36 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:36 --> Controller Class Initialized
INFO - 2017-02-07 19:53:36 --> Helper loaded: date_helper
DEBUG - 2017-02-07 19:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:36 --> Helper loaded: url_helper
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:36 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:36 --> Total execution time: 0.0134
INFO - 2017-02-07 19:53:36 --> Config Class Initialized
INFO - 2017-02-07 19:53:36 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:36 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:36 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:36 --> URI Class Initialized
INFO - 2017-02-07 19:53:36 --> Router Class Initialized
INFO - 2017-02-07 19:53:36 --> Output Class Initialized
INFO - 2017-02-07 19:53:36 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:36 --> Input Class Initialized
INFO - 2017-02-07 19:53:36 --> Language Class Initialized
INFO - 2017-02-07 19:53:36 --> Loader Class Initialized
INFO - 2017-02-07 19:53:36 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:36 --> Controller Class Initialized
INFO - 2017-02-07 19:53:36 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:36 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:36 --> Total execution time: 0.0135
INFO - 2017-02-07 19:53:37 --> Config Class Initialized
INFO - 2017-02-07 19:53:37 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:37 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:37 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:37 --> URI Class Initialized
DEBUG - 2017-02-07 19:53:37 --> No URI present. Default controller set.
INFO - 2017-02-07 19:53:37 --> Router Class Initialized
INFO - 2017-02-07 19:53:37 --> Output Class Initialized
INFO - 2017-02-07 19:53:37 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:37 --> Input Class Initialized
INFO - 2017-02-07 19:53:37 --> Language Class Initialized
INFO - 2017-02-07 19:53:37 --> Loader Class Initialized
INFO - 2017-02-07 19:53:37 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:37 --> Controller Class Initialized
INFO - 2017-02-07 19:53:37 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:37 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:37 --> Total execution time: 0.0135
INFO - 2017-02-07 19:53:39 --> Config Class Initialized
INFO - 2017-02-07 19:53:39 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:53:39 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:53:39 --> Utf8 Class Initialized
INFO - 2017-02-07 19:53:39 --> URI Class Initialized
INFO - 2017-02-07 19:53:39 --> Router Class Initialized
INFO - 2017-02-07 19:53:39 --> Output Class Initialized
INFO - 2017-02-07 19:53:39 --> Security Class Initialized
DEBUG - 2017-02-07 19:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:53:39 --> Input Class Initialized
INFO - 2017-02-07 19:53:39 --> Language Class Initialized
INFO - 2017-02-07 19:53:39 --> Loader Class Initialized
INFO - 2017-02-07 19:53:39 --> Database Driver Class Initialized
INFO - 2017-02-07 19:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:53:39 --> Controller Class Initialized
INFO - 2017-02-07 19:53:39 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:53:39 --> Final output sent to browser
DEBUG - 2017-02-07 19:53:39 --> Total execution time: 0.0135
INFO - 2017-02-07 19:54:00 --> Config Class Initialized
INFO - 2017-02-07 19:54:00 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:54:00 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:54:00 --> Utf8 Class Initialized
INFO - 2017-02-07 19:54:00 --> URI Class Initialized
DEBUG - 2017-02-07 19:54:00 --> No URI present. Default controller set.
INFO - 2017-02-07 19:54:00 --> Router Class Initialized
INFO - 2017-02-07 19:54:00 --> Output Class Initialized
INFO - 2017-02-07 19:54:00 --> Security Class Initialized
DEBUG - 2017-02-07 19:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:54:00 --> Input Class Initialized
INFO - 2017-02-07 19:54:00 --> Language Class Initialized
INFO - 2017-02-07 19:54:00 --> Loader Class Initialized
INFO - 2017-02-07 19:54:00 --> Database Driver Class Initialized
INFO - 2017-02-07 19:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:54:00 --> Controller Class Initialized
INFO - 2017-02-07 19:54:00 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:54:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:54:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:54:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:54:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:54:00 --> Final output sent to browser
DEBUG - 2017-02-07 19:54:00 --> Total execution time: 0.0129
INFO - 2017-02-07 19:54:02 --> Config Class Initialized
INFO - 2017-02-07 19:54:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:54:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:54:02 --> Utf8 Class Initialized
INFO - 2017-02-07 19:54:02 --> URI Class Initialized
INFO - 2017-02-07 19:54:02 --> Router Class Initialized
INFO - 2017-02-07 19:54:02 --> Output Class Initialized
INFO - 2017-02-07 19:54:02 --> Security Class Initialized
DEBUG - 2017-02-07 19:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:54:02 --> Input Class Initialized
INFO - 2017-02-07 19:54:02 --> Language Class Initialized
INFO - 2017-02-07 19:54:02 --> Loader Class Initialized
INFO - 2017-02-07 19:54:02 --> Database Driver Class Initialized
INFO - 2017-02-07 19:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:54:02 --> Controller Class Initialized
INFO - 2017-02-07 19:54:02 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:54:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:54:02 --> Final output sent to browser
DEBUG - 2017-02-07 19:54:02 --> Total execution time: 0.0129
INFO - 2017-02-07 19:54:39 --> Config Class Initialized
INFO - 2017-02-07 19:54:39 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:54:39 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:54:39 --> Utf8 Class Initialized
INFO - 2017-02-07 19:54:39 --> URI Class Initialized
INFO - 2017-02-07 19:54:39 --> Router Class Initialized
INFO - 2017-02-07 19:54:39 --> Output Class Initialized
INFO - 2017-02-07 19:54:39 --> Security Class Initialized
DEBUG - 2017-02-07 19:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:54:39 --> Input Class Initialized
INFO - 2017-02-07 19:54:39 --> Language Class Initialized
INFO - 2017-02-07 19:54:39 --> Loader Class Initialized
INFO - 2017-02-07 19:54:39 --> Database Driver Class Initialized
INFO - 2017-02-07 19:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:54:39 --> Controller Class Initialized
INFO - 2017-02-07 19:54:39 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:54:40 --> Config Class Initialized
INFO - 2017-02-07 19:54:40 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:54:40 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:54:40 --> Utf8 Class Initialized
INFO - 2017-02-07 19:54:40 --> URI Class Initialized
INFO - 2017-02-07 19:54:40 --> Router Class Initialized
INFO - 2017-02-07 19:54:40 --> Output Class Initialized
INFO - 2017-02-07 19:54:40 --> Security Class Initialized
DEBUG - 2017-02-07 19:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:54:40 --> Input Class Initialized
INFO - 2017-02-07 19:54:40 --> Language Class Initialized
INFO - 2017-02-07 19:54:40 --> Loader Class Initialized
INFO - 2017-02-07 19:54:40 --> Database Driver Class Initialized
INFO - 2017-02-07 19:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:54:40 --> Controller Class Initialized
INFO - 2017-02-07 19:54:40 --> Helper loaded: date_helper
DEBUG - 2017-02-07 19:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:54:40 --> Helper loaded: url_helper
INFO - 2017-02-07 19:54:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:54:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 19:54:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 19:54:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 19:54:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:54:40 --> Final output sent to browser
DEBUG - 2017-02-07 19:54:40 --> Total execution time: 0.0140
INFO - 2017-02-07 19:54:41 --> Config Class Initialized
INFO - 2017-02-07 19:54:41 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:54:41 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:54:41 --> Utf8 Class Initialized
INFO - 2017-02-07 19:54:41 --> URI Class Initialized
INFO - 2017-02-07 19:54:41 --> Router Class Initialized
INFO - 2017-02-07 19:54:41 --> Output Class Initialized
INFO - 2017-02-07 19:54:41 --> Security Class Initialized
DEBUG - 2017-02-07 19:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:54:41 --> Input Class Initialized
INFO - 2017-02-07 19:54:41 --> Language Class Initialized
INFO - 2017-02-07 19:54:41 --> Loader Class Initialized
INFO - 2017-02-07 19:54:41 --> Database Driver Class Initialized
INFO - 2017-02-07 19:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:54:41 --> Controller Class Initialized
INFO - 2017-02-07 19:54:41 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:54:41 --> Final output sent to browser
DEBUG - 2017-02-07 19:54:41 --> Total execution time: 0.0144
INFO - 2017-02-07 19:54:43 --> Config Class Initialized
INFO - 2017-02-07 19:54:43 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:54:43 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:54:43 --> Utf8 Class Initialized
INFO - 2017-02-07 19:54:43 --> URI Class Initialized
DEBUG - 2017-02-07 19:54:43 --> No URI present. Default controller set.
INFO - 2017-02-07 19:54:43 --> Router Class Initialized
INFO - 2017-02-07 19:54:43 --> Output Class Initialized
INFO - 2017-02-07 19:54:43 --> Security Class Initialized
DEBUG - 2017-02-07 19:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:54:43 --> Input Class Initialized
INFO - 2017-02-07 19:54:43 --> Language Class Initialized
INFO - 2017-02-07 19:54:43 --> Loader Class Initialized
INFO - 2017-02-07 19:54:43 --> Database Driver Class Initialized
INFO - 2017-02-07 19:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:54:43 --> Controller Class Initialized
INFO - 2017-02-07 19:54:43 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:54:43 --> Final output sent to browser
DEBUG - 2017-02-07 19:54:43 --> Total execution time: 0.0130
INFO - 2017-02-07 19:54:44 --> Config Class Initialized
INFO - 2017-02-07 19:54:44 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:54:44 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:54:44 --> Utf8 Class Initialized
INFO - 2017-02-07 19:54:44 --> URI Class Initialized
INFO - 2017-02-07 19:54:44 --> Router Class Initialized
INFO - 2017-02-07 19:54:44 --> Output Class Initialized
INFO - 2017-02-07 19:54:44 --> Security Class Initialized
DEBUG - 2017-02-07 19:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:54:44 --> Input Class Initialized
INFO - 2017-02-07 19:54:44 --> Language Class Initialized
INFO - 2017-02-07 19:54:44 --> Loader Class Initialized
INFO - 2017-02-07 19:54:44 --> Database Driver Class Initialized
INFO - 2017-02-07 19:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:54:44 --> Controller Class Initialized
INFO - 2017-02-07 19:54:44 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:54:44 --> Final output sent to browser
DEBUG - 2017-02-07 19:54:44 --> Total execution time: 0.0143
INFO - 2017-02-07 19:59:44 --> Config Class Initialized
INFO - 2017-02-07 19:59:44 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:59:44 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:59:44 --> Utf8 Class Initialized
INFO - 2017-02-07 19:59:44 --> URI Class Initialized
INFO - 2017-02-07 19:59:44 --> Router Class Initialized
INFO - 2017-02-07 19:59:44 --> Output Class Initialized
INFO - 2017-02-07 19:59:44 --> Security Class Initialized
DEBUG - 2017-02-07 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:59:44 --> Input Class Initialized
INFO - 2017-02-07 19:59:44 --> Language Class Initialized
INFO - 2017-02-07 19:59:44 --> Loader Class Initialized
INFO - 2017-02-07 19:59:44 --> Database Driver Class Initialized
INFO - 2017-02-07 19:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:59:44 --> Controller Class Initialized
INFO - 2017-02-07 19:59:44 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:59:44 --> Final output sent to browser
DEBUG - 2017-02-07 19:59:44 --> Total execution time: 0.0137
INFO - 2017-02-07 19:59:44 --> Config Class Initialized
INFO - 2017-02-07 19:59:44 --> Hooks Class Initialized
DEBUG - 2017-02-07 19:59:44 --> UTF-8 Support Enabled
INFO - 2017-02-07 19:59:44 --> Utf8 Class Initialized
INFO - 2017-02-07 19:59:44 --> URI Class Initialized
DEBUG - 2017-02-07 19:59:44 --> No URI present. Default controller set.
INFO - 2017-02-07 19:59:44 --> Router Class Initialized
INFO - 2017-02-07 19:59:44 --> Output Class Initialized
INFO - 2017-02-07 19:59:44 --> Security Class Initialized
DEBUG - 2017-02-07 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 19:59:44 --> Input Class Initialized
INFO - 2017-02-07 19:59:44 --> Language Class Initialized
INFO - 2017-02-07 19:59:44 --> Loader Class Initialized
INFO - 2017-02-07 19:59:44 --> Database Driver Class Initialized
INFO - 2017-02-07 19:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 19:59:44 --> Controller Class Initialized
INFO - 2017-02-07 19:59:44 --> Helper loaded: url_helper
DEBUG - 2017-02-07 19:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 19:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 19:59:44 --> Final output sent to browser
DEBUG - 2017-02-07 19:59:44 --> Total execution time: 0.0134
INFO - 2017-02-07 20:29:55 --> Config Class Initialized
INFO - 2017-02-07 20:29:55 --> Hooks Class Initialized
DEBUG - 2017-02-07 20:29:55 --> UTF-8 Support Enabled
INFO - 2017-02-07 20:29:55 --> Utf8 Class Initialized
INFO - 2017-02-07 20:29:55 --> URI Class Initialized
DEBUG - 2017-02-07 20:29:55 --> No URI present. Default controller set.
INFO - 2017-02-07 20:29:55 --> Router Class Initialized
INFO - 2017-02-07 20:29:55 --> Output Class Initialized
INFO - 2017-02-07 20:29:55 --> Security Class Initialized
DEBUG - 2017-02-07 20:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 20:29:55 --> Input Class Initialized
INFO - 2017-02-07 20:29:55 --> Language Class Initialized
INFO - 2017-02-07 20:29:55 --> Loader Class Initialized
INFO - 2017-02-07 20:29:55 --> Database Driver Class Initialized
INFO - 2017-02-07 20:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 20:29:55 --> Controller Class Initialized
INFO - 2017-02-07 20:29:55 --> Helper loaded: url_helper
DEBUG - 2017-02-07 20:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 20:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 20:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 20:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 20:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 20:29:55 --> Final output sent to browser
DEBUG - 2017-02-07 20:29:55 --> Total execution time: 0.0129
INFO - 2017-02-07 22:22:33 --> Config Class Initialized
INFO - 2017-02-07 22:22:33 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:22:33 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:22:33 --> Utf8 Class Initialized
INFO - 2017-02-07 22:22:33 --> URI Class Initialized
INFO - 2017-02-07 22:22:33 --> Router Class Initialized
INFO - 2017-02-07 22:22:33 --> Output Class Initialized
INFO - 2017-02-07 22:22:33 --> Security Class Initialized
DEBUG - 2017-02-07 22:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:22:33 --> Input Class Initialized
INFO - 2017-02-07 22:22:33 --> Language Class Initialized
INFO - 2017-02-07 22:22:33 --> Loader Class Initialized
INFO - 2017-02-07 22:22:33 --> Database Driver Class Initialized
INFO - 2017-02-07 22:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:22:33 --> Controller Class Initialized
INFO - 2017-02-07 22:22:33 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:22:33 --> Final output sent to browser
DEBUG - 2017-02-07 22:22:33 --> Total execution time: 0.0139
INFO - 2017-02-07 22:22:33 --> Config Class Initialized
INFO - 2017-02-07 22:22:33 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:22:33 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:22:33 --> Utf8 Class Initialized
INFO - 2017-02-07 22:22:33 --> URI Class Initialized
DEBUG - 2017-02-07 22:22:33 --> No URI present. Default controller set.
INFO - 2017-02-07 22:22:33 --> Router Class Initialized
INFO - 2017-02-07 22:22:33 --> Output Class Initialized
INFO - 2017-02-07 22:22:33 --> Security Class Initialized
DEBUG - 2017-02-07 22:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:22:33 --> Input Class Initialized
INFO - 2017-02-07 22:22:33 --> Language Class Initialized
INFO - 2017-02-07 22:22:33 --> Loader Class Initialized
INFO - 2017-02-07 22:22:33 --> Database Driver Class Initialized
INFO - 2017-02-07 22:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:22:33 --> Controller Class Initialized
INFO - 2017-02-07 22:22:33 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 22:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:22:33 --> Final output sent to browser
DEBUG - 2017-02-07 22:22:33 --> Total execution time: 0.0139
INFO - 2017-02-07 22:23:30 --> Config Class Initialized
INFO - 2017-02-07 22:23:30 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:23:30 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:23:30 --> Utf8 Class Initialized
INFO - 2017-02-07 22:23:30 --> URI Class Initialized
INFO - 2017-02-07 22:23:30 --> Router Class Initialized
INFO - 2017-02-07 22:23:30 --> Output Class Initialized
INFO - 2017-02-07 22:23:30 --> Security Class Initialized
DEBUG - 2017-02-07 22:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:23:30 --> Input Class Initialized
INFO - 2017-02-07 22:23:30 --> Language Class Initialized
INFO - 2017-02-07 22:23:30 --> Loader Class Initialized
INFO - 2017-02-07 22:23:30 --> Database Driver Class Initialized
INFO - 2017-02-07 22:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:23:30 --> Controller Class Initialized
INFO - 2017-02-07 22:23:30 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:23:30 --> Helper loaded: form_helper
INFO - 2017-02-07 22:23:30 --> Form Validation Class Initialized
INFO - 2017-02-07 22:23:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-07 22:23:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-07 22:23:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-07 22:23:30 --> Final output sent to browser
DEBUG - 2017-02-07 22:23:30 --> Total execution time: 0.2003
INFO - 2017-02-07 22:23:31 --> Config Class Initialized
INFO - 2017-02-07 22:23:31 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:23:31 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:23:31 --> Utf8 Class Initialized
INFO - 2017-02-07 22:23:31 --> URI Class Initialized
INFO - 2017-02-07 22:23:31 --> Router Class Initialized
INFO - 2017-02-07 22:23:31 --> Output Class Initialized
INFO - 2017-02-07 22:23:31 --> Security Class Initialized
DEBUG - 2017-02-07 22:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:23:31 --> Input Class Initialized
INFO - 2017-02-07 22:23:31 --> Language Class Initialized
INFO - 2017-02-07 22:23:31 --> Loader Class Initialized
INFO - 2017-02-07 22:23:31 --> Database Driver Class Initialized
INFO - 2017-02-07 22:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:23:31 --> Controller Class Initialized
INFO - 2017-02-07 22:23:31 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 22:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 22:23:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:23:31 --> Final output sent to browser
DEBUG - 2017-02-07 22:23:31 --> Total execution time: 0.0132
INFO - 2017-02-07 22:25:17 --> Config Class Initialized
INFO - 2017-02-07 22:25:17 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:25:17 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:25:17 --> Utf8 Class Initialized
INFO - 2017-02-07 22:25:17 --> URI Class Initialized
INFO - 2017-02-07 22:25:17 --> Router Class Initialized
INFO - 2017-02-07 22:25:17 --> Output Class Initialized
INFO - 2017-02-07 22:25:17 --> Security Class Initialized
DEBUG - 2017-02-07 22:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:25:17 --> Input Class Initialized
INFO - 2017-02-07 22:25:17 --> Language Class Initialized
INFO - 2017-02-07 22:25:17 --> Loader Class Initialized
INFO - 2017-02-07 22:25:17 --> Database Driver Class Initialized
INFO - 2017-02-07 22:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:25:17 --> Controller Class Initialized
INFO - 2017-02-07 22:25:17 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:25:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:25:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 22:25:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 22:25:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:25:17 --> Final output sent to browser
DEBUG - 2017-02-07 22:25:17 --> Total execution time: 0.0158
INFO - 2017-02-07 22:25:18 --> Config Class Initialized
INFO - 2017-02-07 22:25:18 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:25:18 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:25:18 --> Utf8 Class Initialized
INFO - 2017-02-07 22:25:18 --> URI Class Initialized
DEBUG - 2017-02-07 22:25:18 --> No URI present. Default controller set.
INFO - 2017-02-07 22:25:18 --> Router Class Initialized
INFO - 2017-02-07 22:25:18 --> Output Class Initialized
INFO - 2017-02-07 22:25:18 --> Security Class Initialized
DEBUG - 2017-02-07 22:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:25:18 --> Input Class Initialized
INFO - 2017-02-07 22:25:18 --> Language Class Initialized
INFO - 2017-02-07 22:25:18 --> Loader Class Initialized
INFO - 2017-02-07 22:25:18 --> Database Driver Class Initialized
INFO - 2017-02-07 22:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:25:18 --> Controller Class Initialized
INFO - 2017-02-07 22:25:18 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 22:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 22:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:25:18 --> Final output sent to browser
DEBUG - 2017-02-07 22:25:18 --> Total execution time: 0.0139
INFO - 2017-02-07 22:27:50 --> Config Class Initialized
INFO - 2017-02-07 22:27:50 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:27:50 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:27:50 --> Utf8 Class Initialized
INFO - 2017-02-07 22:27:50 --> URI Class Initialized
DEBUG - 2017-02-07 22:27:50 --> No URI present. Default controller set.
INFO - 2017-02-07 22:27:50 --> Router Class Initialized
INFO - 2017-02-07 22:27:50 --> Output Class Initialized
INFO - 2017-02-07 22:27:50 --> Security Class Initialized
DEBUG - 2017-02-07 22:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:27:50 --> Input Class Initialized
INFO - 2017-02-07 22:27:50 --> Language Class Initialized
INFO - 2017-02-07 22:27:50 --> Loader Class Initialized
INFO - 2017-02-07 22:27:50 --> Database Driver Class Initialized
INFO - 2017-02-07 22:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:27:50 --> Controller Class Initialized
INFO - 2017-02-07 22:27:50 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 22:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 22:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:27:50 --> Final output sent to browser
DEBUG - 2017-02-07 22:27:50 --> Total execution time: 0.0137
INFO - 2017-02-07 22:45:33 --> Config Class Initialized
INFO - 2017-02-07 22:45:33 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:45:33 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:45:33 --> Utf8 Class Initialized
INFO - 2017-02-07 22:45:33 --> URI Class Initialized
INFO - 2017-02-07 22:45:33 --> Router Class Initialized
INFO - 2017-02-07 22:45:33 --> Output Class Initialized
INFO - 2017-02-07 22:45:33 --> Security Class Initialized
DEBUG - 2017-02-07 22:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:45:33 --> Input Class Initialized
INFO - 2017-02-07 22:45:33 --> Language Class Initialized
INFO - 2017-02-07 22:45:33 --> Loader Class Initialized
INFO - 2017-02-07 22:45:33 --> Database Driver Class Initialized
INFO - 2017-02-07 22:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:45:34 --> Controller Class Initialized
INFO - 2017-02-07 22:45:34 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-07 22:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-07 22:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:45:34 --> Final output sent to browser
DEBUG - 2017-02-07 22:45:34 --> Total execution time: 1.2977
INFO - 2017-02-07 22:45:55 --> Config Class Initialized
INFO - 2017-02-07 22:45:55 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:45:55 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:45:55 --> Utf8 Class Initialized
INFO - 2017-02-07 22:45:55 --> URI Class Initialized
INFO - 2017-02-07 22:45:55 --> Router Class Initialized
INFO - 2017-02-07 22:45:55 --> Output Class Initialized
INFO - 2017-02-07 22:45:55 --> Security Class Initialized
DEBUG - 2017-02-07 22:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:45:55 --> Input Class Initialized
INFO - 2017-02-07 22:45:55 --> Language Class Initialized
INFO - 2017-02-07 22:45:55 --> Loader Class Initialized
INFO - 2017-02-07 22:45:55 --> Database Driver Class Initialized
INFO - 2017-02-07 22:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:45:55 --> Controller Class Initialized
INFO - 2017-02-07 22:45:55 --> Helper loaded: url_helper
DEBUG - 2017-02-07 22:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:45:56 --> Config Class Initialized
INFO - 2017-02-07 22:45:56 --> Hooks Class Initialized
DEBUG - 2017-02-07 22:45:56 --> UTF-8 Support Enabled
INFO - 2017-02-07 22:45:56 --> Utf8 Class Initialized
INFO - 2017-02-07 22:45:56 --> URI Class Initialized
INFO - 2017-02-07 22:45:56 --> Router Class Initialized
INFO - 2017-02-07 22:45:56 --> Output Class Initialized
INFO - 2017-02-07 22:45:56 --> Security Class Initialized
DEBUG - 2017-02-07 22:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 22:45:56 --> Input Class Initialized
INFO - 2017-02-07 22:45:56 --> Language Class Initialized
INFO - 2017-02-07 22:45:57 --> Loader Class Initialized
INFO - 2017-02-07 22:45:57 --> Database Driver Class Initialized
INFO - 2017-02-07 22:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 22:45:57 --> Controller Class Initialized
INFO - 2017-02-07 22:45:57 --> Helper loaded: date_helper
DEBUG - 2017-02-07 22:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-07 22:45:57 --> Helper loaded: url_helper
INFO - 2017-02-07 22:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-07 22:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-07 22:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-07 22:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-07 22:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-07 22:45:57 --> Final output sent to browser
DEBUG - 2017-02-07 22:45:57 --> Total execution time: 0.0974

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-13 00:09:55 --> Config Class Initialized
INFO - 2017-02-13 00:09:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:09:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:09:55 --> Utf8 Class Initialized
INFO - 2017-02-13 00:09:55 --> URI Class Initialized
INFO - 2017-02-13 00:09:55 --> Router Class Initialized
INFO - 2017-02-13 00:09:55 --> Output Class Initialized
INFO - 2017-02-13 00:09:55 --> Security Class Initialized
DEBUG - 2017-02-13 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:09:55 --> Input Class Initialized
INFO - 2017-02-13 00:09:55 --> Language Class Initialized
INFO - 2017-02-13 00:09:55 --> Loader Class Initialized
INFO - 2017-02-13 00:09:55 --> Database Driver Class Initialized
INFO - 2017-02-13 00:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:09:55 --> Controller Class Initialized
INFO - 2017-02-13 00:09:55 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:09:55 --> Final output sent to browser
DEBUG - 2017-02-13 00:09:55 --> Total execution time: 0.0137
INFO - 2017-02-13 00:09:55 --> Config Class Initialized
INFO - 2017-02-13 00:09:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:09:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:09:55 --> Utf8 Class Initialized
INFO - 2017-02-13 00:09:55 --> URI Class Initialized
DEBUG - 2017-02-13 00:09:55 --> No URI present. Default controller set.
INFO - 2017-02-13 00:09:55 --> Router Class Initialized
INFO - 2017-02-13 00:09:55 --> Output Class Initialized
INFO - 2017-02-13 00:09:55 --> Security Class Initialized
DEBUG - 2017-02-13 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:09:55 --> Input Class Initialized
INFO - 2017-02-13 00:09:55 --> Language Class Initialized
INFO - 2017-02-13 00:09:55 --> Loader Class Initialized
INFO - 2017-02-13 00:09:55 --> Database Driver Class Initialized
INFO - 2017-02-13 00:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:09:55 --> Controller Class Initialized
INFO - 2017-02-13 00:09:55 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:09:55 --> Final output sent to browser
DEBUG - 2017-02-13 00:09:55 --> Total execution time: 0.0137
INFO - 2017-02-13 00:11:45 --> Config Class Initialized
INFO - 2017-02-13 00:11:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:11:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:11:45 --> Utf8 Class Initialized
INFO - 2017-02-13 00:11:45 --> URI Class Initialized
INFO - 2017-02-13 00:11:45 --> Router Class Initialized
INFO - 2017-02-13 00:11:45 --> Output Class Initialized
INFO - 2017-02-13 00:11:45 --> Security Class Initialized
DEBUG - 2017-02-13 00:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:11:45 --> Input Class Initialized
INFO - 2017-02-13 00:11:45 --> Language Class Initialized
INFO - 2017-02-13 00:11:45 --> Loader Class Initialized
INFO - 2017-02-13 00:11:45 --> Database Driver Class Initialized
INFO - 2017-02-13 00:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:11:45 --> Controller Class Initialized
INFO - 2017-02-13 00:11:45 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:11:45 --> Final output sent to browser
DEBUG - 2017-02-13 00:11:45 --> Total execution time: 0.0148
INFO - 2017-02-13 00:11:45 --> Config Class Initialized
INFO - 2017-02-13 00:11:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:11:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:11:45 --> Utf8 Class Initialized
INFO - 2017-02-13 00:11:45 --> URI Class Initialized
DEBUG - 2017-02-13 00:11:45 --> No URI present. Default controller set.
INFO - 2017-02-13 00:11:45 --> Router Class Initialized
INFO - 2017-02-13 00:11:45 --> Output Class Initialized
INFO - 2017-02-13 00:11:45 --> Security Class Initialized
DEBUG - 2017-02-13 00:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:11:45 --> Input Class Initialized
INFO - 2017-02-13 00:11:45 --> Language Class Initialized
INFO - 2017-02-13 00:11:45 --> Loader Class Initialized
INFO - 2017-02-13 00:11:45 --> Database Driver Class Initialized
INFO - 2017-02-13 00:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:11:45 --> Controller Class Initialized
INFO - 2017-02-13 00:11:45 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:11:45 --> Final output sent to browser
DEBUG - 2017-02-13 00:11:45 --> Total execution time: 0.0140
INFO - 2017-02-13 00:18:44 --> Config Class Initialized
INFO - 2017-02-13 00:18:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:18:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:18:44 --> Utf8 Class Initialized
INFO - 2017-02-13 00:18:44 --> URI Class Initialized
DEBUG - 2017-02-13 00:18:44 --> No URI present. Default controller set.
INFO - 2017-02-13 00:18:44 --> Router Class Initialized
INFO - 2017-02-13 00:18:44 --> Output Class Initialized
INFO - 2017-02-13 00:18:44 --> Security Class Initialized
DEBUG - 2017-02-13 00:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:18:44 --> Input Class Initialized
INFO - 2017-02-13 00:18:44 --> Language Class Initialized
INFO - 2017-02-13 00:18:44 --> Loader Class Initialized
INFO - 2017-02-13 00:18:44 --> Database Driver Class Initialized
INFO - 2017-02-13 00:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:18:44 --> Controller Class Initialized
INFO - 2017-02-13 00:18:44 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:18:44 --> Final output sent to browser
DEBUG - 2017-02-13 00:18:44 --> Total execution time: 0.0136
INFO - 2017-02-13 00:19:00 --> Config Class Initialized
INFO - 2017-02-13 00:19:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:19:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:19:00 --> Utf8 Class Initialized
INFO - 2017-02-13 00:19:00 --> URI Class Initialized
INFO - 2017-02-13 00:19:00 --> Router Class Initialized
INFO - 2017-02-13 00:19:00 --> Output Class Initialized
INFO - 2017-02-13 00:19:00 --> Security Class Initialized
DEBUG - 2017-02-13 00:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:19:00 --> Input Class Initialized
INFO - 2017-02-13 00:19:00 --> Language Class Initialized
INFO - 2017-02-13 00:19:00 --> Loader Class Initialized
INFO - 2017-02-13 00:19:00 --> Database Driver Class Initialized
INFO - 2017-02-13 00:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:19:00 --> Controller Class Initialized
INFO - 2017-02-13 00:19:00 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:19:00 --> Final output sent to browser
DEBUG - 2017-02-13 00:19:00 --> Total execution time: 0.0136
INFO - 2017-02-13 00:19:17 --> Config Class Initialized
INFO - 2017-02-13 00:19:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:19:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:19:17 --> Utf8 Class Initialized
INFO - 2017-02-13 00:19:17 --> URI Class Initialized
INFO - 2017-02-13 00:19:17 --> Router Class Initialized
INFO - 2017-02-13 00:19:17 --> Output Class Initialized
INFO - 2017-02-13 00:19:17 --> Security Class Initialized
DEBUG - 2017-02-13 00:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:19:17 --> Input Class Initialized
INFO - 2017-02-13 00:19:17 --> Language Class Initialized
INFO - 2017-02-13 00:19:17 --> Loader Class Initialized
INFO - 2017-02-13 00:19:17 --> Database Driver Class Initialized
INFO - 2017-02-13 00:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:19:17 --> Controller Class Initialized
INFO - 2017-02-13 00:19:17 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:19:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-13 00:19:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-13 00:19:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-13 00:19:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-13 00:19:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:19:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:19:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:19:17 --> Final output sent to browser
DEBUG - 2017-02-13 00:19:17 --> Total execution time: 0.0142
INFO - 2017-02-13 00:19:18 --> Config Class Initialized
INFO - 2017-02-13 00:19:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:19:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:19:18 --> Utf8 Class Initialized
INFO - 2017-02-13 00:19:18 --> URI Class Initialized
INFO - 2017-02-13 00:19:18 --> Router Class Initialized
INFO - 2017-02-13 00:19:18 --> Output Class Initialized
INFO - 2017-02-13 00:19:18 --> Security Class Initialized
DEBUG - 2017-02-13 00:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:19:18 --> Input Class Initialized
INFO - 2017-02-13 00:19:18 --> Language Class Initialized
INFO - 2017-02-13 00:19:18 --> Loader Class Initialized
INFO - 2017-02-13 00:19:18 --> Database Driver Class Initialized
INFO - 2017-02-13 00:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:19:18 --> Controller Class Initialized
INFO - 2017-02-13 00:19:18 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:19:18 --> Final output sent to browser
DEBUG - 2017-02-13 00:19:18 --> Total execution time: 0.0137
INFO - 2017-02-13 00:19:54 --> Config Class Initialized
INFO - 2017-02-13 00:19:54 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:19:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:19:54 --> Utf8 Class Initialized
INFO - 2017-02-13 00:19:54 --> URI Class Initialized
INFO - 2017-02-13 00:19:54 --> Router Class Initialized
INFO - 2017-02-13 00:19:54 --> Output Class Initialized
INFO - 2017-02-13 00:19:54 --> Security Class Initialized
DEBUG - 2017-02-13 00:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:19:54 --> Input Class Initialized
INFO - 2017-02-13 00:19:54 --> Language Class Initialized
INFO - 2017-02-13 00:19:54 --> Loader Class Initialized
INFO - 2017-02-13 00:19:54 --> Database Driver Class Initialized
INFO - 2017-02-13 00:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:19:54 --> Controller Class Initialized
INFO - 2017-02-13 00:19:54 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:19:54 --> Final output sent to browser
DEBUG - 2017-02-13 00:19:54 --> Total execution time: 0.0146
INFO - 2017-02-13 00:19:56 --> Config Class Initialized
INFO - 2017-02-13 00:19:56 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:19:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:19:56 --> Utf8 Class Initialized
INFO - 2017-02-13 00:19:56 --> URI Class Initialized
INFO - 2017-02-13 00:19:56 --> Router Class Initialized
INFO - 2017-02-13 00:19:56 --> Output Class Initialized
INFO - 2017-02-13 00:19:56 --> Security Class Initialized
DEBUG - 2017-02-13 00:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:19:56 --> Input Class Initialized
INFO - 2017-02-13 00:19:56 --> Language Class Initialized
INFO - 2017-02-13 00:19:56 --> Loader Class Initialized
INFO - 2017-02-13 00:19:56 --> Database Driver Class Initialized
INFO - 2017-02-13 00:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:19:56 --> Controller Class Initialized
INFO - 2017-02-13 00:19:56 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:19:56 --> Final output sent to browser
DEBUG - 2017-02-13 00:19:56 --> Total execution time: 0.0135
INFO - 2017-02-13 00:20:07 --> Config Class Initialized
INFO - 2017-02-13 00:20:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:20:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:20:07 --> Utf8 Class Initialized
INFO - 2017-02-13 00:20:07 --> URI Class Initialized
INFO - 2017-02-13 00:20:07 --> Router Class Initialized
INFO - 2017-02-13 00:20:07 --> Output Class Initialized
INFO - 2017-02-13 00:20:07 --> Security Class Initialized
DEBUG - 2017-02-13 00:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:20:07 --> Input Class Initialized
INFO - 2017-02-13 00:20:07 --> Language Class Initialized
INFO - 2017-02-13 00:20:07 --> Loader Class Initialized
INFO - 2017-02-13 00:20:07 --> Database Driver Class Initialized
INFO - 2017-02-13 00:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:20:07 --> Controller Class Initialized
INFO - 2017-02-13 00:20:07 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:20:07 --> Final output sent to browser
DEBUG - 2017-02-13 00:20:07 --> Total execution time: 0.0145
INFO - 2017-02-13 00:20:08 --> Config Class Initialized
INFO - 2017-02-13 00:20:08 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:20:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:20:08 --> Utf8 Class Initialized
INFO - 2017-02-13 00:20:08 --> URI Class Initialized
INFO - 2017-02-13 00:20:08 --> Router Class Initialized
INFO - 2017-02-13 00:20:08 --> Output Class Initialized
INFO - 2017-02-13 00:20:08 --> Security Class Initialized
DEBUG - 2017-02-13 00:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:20:08 --> Input Class Initialized
INFO - 2017-02-13 00:20:08 --> Language Class Initialized
INFO - 2017-02-13 00:20:08 --> Loader Class Initialized
INFO - 2017-02-13 00:20:08 --> Database Driver Class Initialized
INFO - 2017-02-13 00:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:20:08 --> Controller Class Initialized
INFO - 2017-02-13 00:20:08 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:20:08 --> Final output sent to browser
DEBUG - 2017-02-13 00:20:08 --> Total execution time: 0.0452
INFO - 2017-02-13 00:20:48 --> Config Class Initialized
INFO - 2017-02-13 00:20:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:20:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:20:48 --> Utf8 Class Initialized
INFO - 2017-02-13 00:20:48 --> URI Class Initialized
INFO - 2017-02-13 00:20:48 --> Router Class Initialized
INFO - 2017-02-13 00:20:48 --> Output Class Initialized
INFO - 2017-02-13 00:20:48 --> Security Class Initialized
DEBUG - 2017-02-13 00:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:20:48 --> Input Class Initialized
INFO - 2017-02-13 00:20:48 --> Language Class Initialized
INFO - 2017-02-13 00:20:48 --> Loader Class Initialized
INFO - 2017-02-13 00:20:48 --> Database Driver Class Initialized
INFO - 2017-02-13 00:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:20:48 --> Controller Class Initialized
INFO - 2017-02-13 00:20:48 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:20:48 --> Config Class Initialized
INFO - 2017-02-13 00:20:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:20:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:20:48 --> Utf8 Class Initialized
INFO - 2017-02-13 00:20:48 --> URI Class Initialized
INFO - 2017-02-13 00:20:48 --> Router Class Initialized
INFO - 2017-02-13 00:20:48 --> Output Class Initialized
INFO - 2017-02-13 00:20:48 --> Security Class Initialized
DEBUG - 2017-02-13 00:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:20:48 --> Input Class Initialized
INFO - 2017-02-13 00:20:48 --> Language Class Initialized
INFO - 2017-02-13 00:20:48 --> Loader Class Initialized
INFO - 2017-02-13 00:20:48 --> Database Driver Class Initialized
INFO - 2017-02-13 00:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:20:48 --> Controller Class Initialized
INFO - 2017-02-13 00:20:48 --> Helper loaded: date_helper
DEBUG - 2017-02-13 00:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:20:48 --> Helper loaded: url_helper
INFO - 2017-02-13 00:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:20:49 --> Final output sent to browser
DEBUG - 2017-02-13 00:20:49 --> Total execution time: 0.0376
INFO - 2017-02-13 00:20:50 --> Config Class Initialized
INFO - 2017-02-13 00:20:50 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:20:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:20:50 --> Utf8 Class Initialized
INFO - 2017-02-13 00:20:50 --> URI Class Initialized
INFO - 2017-02-13 00:20:50 --> Router Class Initialized
INFO - 2017-02-13 00:20:50 --> Output Class Initialized
INFO - 2017-02-13 00:20:50 --> Security Class Initialized
DEBUG - 2017-02-13 00:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:20:50 --> Input Class Initialized
INFO - 2017-02-13 00:20:50 --> Language Class Initialized
INFO - 2017-02-13 00:20:50 --> Loader Class Initialized
INFO - 2017-02-13 00:20:50 --> Database Driver Class Initialized
INFO - 2017-02-13 00:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:20:50 --> Controller Class Initialized
INFO - 2017-02-13 00:20:50 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:20:50 --> Final output sent to browser
DEBUG - 2017-02-13 00:20:50 --> Total execution time: 0.0142
INFO - 2017-02-13 00:22:13 --> Config Class Initialized
INFO - 2017-02-13 00:22:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:22:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:22:13 --> Utf8 Class Initialized
INFO - 2017-02-13 00:22:13 --> URI Class Initialized
DEBUG - 2017-02-13 00:22:13 --> No URI present. Default controller set.
INFO - 2017-02-13 00:22:13 --> Router Class Initialized
INFO - 2017-02-13 00:22:13 --> Output Class Initialized
INFO - 2017-02-13 00:22:13 --> Security Class Initialized
DEBUG - 2017-02-13 00:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:22:13 --> Input Class Initialized
INFO - 2017-02-13 00:22:13 --> Language Class Initialized
INFO - 2017-02-13 00:22:13 --> Loader Class Initialized
INFO - 2017-02-13 00:22:13 --> Database Driver Class Initialized
INFO - 2017-02-13 00:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:22:13 --> Controller Class Initialized
INFO - 2017-02-13 00:22:13 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:22:13 --> Final output sent to browser
DEBUG - 2017-02-13 00:22:13 --> Total execution time: 0.0134
INFO - 2017-02-13 00:22:18 --> Config Class Initialized
INFO - 2017-02-13 00:22:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:22:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:22:18 --> Utf8 Class Initialized
INFO - 2017-02-13 00:22:18 --> URI Class Initialized
INFO - 2017-02-13 00:22:18 --> Router Class Initialized
INFO - 2017-02-13 00:22:18 --> Output Class Initialized
INFO - 2017-02-13 00:22:18 --> Security Class Initialized
DEBUG - 2017-02-13 00:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:22:18 --> Input Class Initialized
INFO - 2017-02-13 00:22:18 --> Language Class Initialized
INFO - 2017-02-13 00:22:18 --> Loader Class Initialized
INFO - 2017-02-13 00:22:18 --> Database Driver Class Initialized
INFO - 2017-02-13 00:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:22:18 --> Controller Class Initialized
INFO - 2017-02-13 00:22:18 --> Helper loaded: url_helper
DEBUG - 2017-02-13 00:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 00:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 00:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:22:18 --> Final output sent to browser
DEBUG - 2017-02-13 00:22:18 --> Total execution time: 0.0135
INFO - 2017-02-13 00:24:02 --> Config Class Initialized
INFO - 2017-02-13 00:24:02 --> Hooks Class Initialized
DEBUG - 2017-02-13 00:24:02 --> UTF-8 Support Enabled
INFO - 2017-02-13 00:24:02 --> Utf8 Class Initialized
INFO - 2017-02-13 00:24:02 --> URI Class Initialized
INFO - 2017-02-13 00:24:02 --> Router Class Initialized
INFO - 2017-02-13 00:24:02 --> Output Class Initialized
INFO - 2017-02-13 00:24:02 --> Security Class Initialized
DEBUG - 2017-02-13 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 00:24:02 --> Input Class Initialized
INFO - 2017-02-13 00:24:02 --> Language Class Initialized
INFO - 2017-02-13 00:24:02 --> Loader Class Initialized
INFO - 2017-02-13 00:24:02 --> Database Driver Class Initialized
INFO - 2017-02-13 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 00:24:02 --> Controller Class Initialized
INFO - 2017-02-13 00:24:02 --> Helper loaded: date_helper
DEBUG - 2017-02-13 00:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 00:24:02 --> Helper loaded: url_helper
INFO - 2017-02-13 00:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 00:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 00:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-13 00:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 00:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 00:24:02 --> Final output sent to browser
DEBUG - 2017-02-13 00:24:02 --> Total execution time: 0.0156
INFO - 2017-02-13 02:22:02 --> Config Class Initialized
INFO - 2017-02-13 02:22:02 --> Hooks Class Initialized
DEBUG - 2017-02-13 02:22:02 --> UTF-8 Support Enabled
INFO - 2017-02-13 02:22:02 --> Utf8 Class Initialized
INFO - 2017-02-13 02:22:02 --> URI Class Initialized
DEBUG - 2017-02-13 02:22:02 --> No URI present. Default controller set.
INFO - 2017-02-13 02:22:02 --> Router Class Initialized
INFO - 2017-02-13 02:22:02 --> Output Class Initialized
INFO - 2017-02-13 02:22:02 --> Security Class Initialized
DEBUG - 2017-02-13 02:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 02:22:02 --> Input Class Initialized
INFO - 2017-02-13 02:22:02 --> Language Class Initialized
INFO - 2017-02-13 02:22:02 --> Loader Class Initialized
INFO - 2017-02-13 02:22:02 --> Database Driver Class Initialized
INFO - 2017-02-13 02:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 02:22:02 --> Controller Class Initialized
INFO - 2017-02-13 02:22:02 --> Helper loaded: url_helper
DEBUG - 2017-02-13 02:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 02:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 02:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 02:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 02:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 02:22:02 --> Final output sent to browser
DEBUG - 2017-02-13 02:22:02 --> Total execution time: 0.0133
INFO - 2017-02-13 02:22:09 --> Config Class Initialized
INFO - 2017-02-13 02:22:09 --> Hooks Class Initialized
DEBUG - 2017-02-13 02:22:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 02:22:09 --> Utf8 Class Initialized
INFO - 2017-02-13 02:22:09 --> URI Class Initialized
INFO - 2017-02-13 02:22:09 --> Router Class Initialized
INFO - 2017-02-13 02:22:09 --> Output Class Initialized
INFO - 2017-02-13 02:22:09 --> Security Class Initialized
DEBUG - 2017-02-13 02:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 02:22:09 --> Input Class Initialized
INFO - 2017-02-13 02:22:09 --> Language Class Initialized
INFO - 2017-02-13 02:22:09 --> Loader Class Initialized
INFO - 2017-02-13 02:22:09 --> Database Driver Class Initialized
INFO - 2017-02-13 02:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 02:22:09 --> Controller Class Initialized
INFO - 2017-02-13 02:22:09 --> Helper loaded: url_helper
DEBUG - 2017-02-13 02:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 02:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 02:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 02:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 02:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 02:22:09 --> Final output sent to browser
DEBUG - 2017-02-13 02:22:09 --> Total execution time: 0.0135
INFO - 2017-02-13 03:44:15 --> Config Class Initialized
INFO - 2017-02-13 03:44:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 03:44:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 03:44:15 --> Utf8 Class Initialized
INFO - 2017-02-13 03:44:15 --> URI Class Initialized
DEBUG - 2017-02-13 03:44:15 --> No URI present. Default controller set.
INFO - 2017-02-13 03:44:15 --> Router Class Initialized
INFO - 2017-02-13 03:44:15 --> Output Class Initialized
INFO - 2017-02-13 03:44:15 --> Security Class Initialized
DEBUG - 2017-02-13 03:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 03:44:15 --> Input Class Initialized
INFO - 2017-02-13 03:44:15 --> Language Class Initialized
INFO - 2017-02-13 03:44:15 --> Loader Class Initialized
INFO - 2017-02-13 03:44:15 --> Database Driver Class Initialized
INFO - 2017-02-13 03:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 03:44:15 --> Controller Class Initialized
INFO - 2017-02-13 03:44:15 --> Helper loaded: url_helper
DEBUG - 2017-02-13 03:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 03:44:15 --> Final output sent to browser
DEBUG - 2017-02-13 03:44:15 --> Total execution time: 0.0137
INFO - 2017-02-13 04:04:56 --> Config Class Initialized
INFO - 2017-02-13 04:04:56 --> Hooks Class Initialized
DEBUG - 2017-02-13 04:04:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 04:04:56 --> Utf8 Class Initialized
INFO - 2017-02-13 04:04:56 --> URI Class Initialized
INFO - 2017-02-13 04:04:56 --> Router Class Initialized
INFO - 2017-02-13 04:04:56 --> Output Class Initialized
INFO - 2017-02-13 04:04:56 --> Security Class Initialized
DEBUG - 2017-02-13 04:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 04:04:56 --> Input Class Initialized
INFO - 2017-02-13 04:04:56 --> Language Class Initialized
INFO - 2017-02-13 04:04:56 --> Loader Class Initialized
INFO - 2017-02-13 04:04:56 --> Database Driver Class Initialized
INFO - 2017-02-13 04:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 04:04:56 --> Controller Class Initialized
INFO - 2017-02-13 04:04:56 --> Helper loaded: date_helper
DEBUG - 2017-02-13 04:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 04:04:56 --> Helper loaded: url_helper
INFO - 2017-02-13 04:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 04:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 04:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 04:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 04:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 04:04:56 --> Final output sent to browser
DEBUG - 2017-02-13 04:04:56 --> Total execution time: 0.1207
INFO - 2017-02-13 04:05:01 --> Config Class Initialized
INFO - 2017-02-13 04:05:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 04:05:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 04:05:01 --> Utf8 Class Initialized
INFO - 2017-02-13 04:05:01 --> URI Class Initialized
INFO - 2017-02-13 04:05:01 --> Router Class Initialized
INFO - 2017-02-13 04:05:01 --> Output Class Initialized
INFO - 2017-02-13 04:05:01 --> Security Class Initialized
DEBUG - 2017-02-13 04:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 04:05:01 --> Input Class Initialized
INFO - 2017-02-13 04:05:01 --> Language Class Initialized
INFO - 2017-02-13 04:05:01 --> Loader Class Initialized
INFO - 2017-02-13 04:05:01 --> Database Driver Class Initialized
INFO - 2017-02-13 04:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 04:05:01 --> Controller Class Initialized
INFO - 2017-02-13 04:05:01 --> Helper loaded: url_helper
DEBUG - 2017-02-13 04:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 04:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 04:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 04:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 04:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 04:05:01 --> Final output sent to browser
DEBUG - 2017-02-13 04:05:01 --> Total execution time: 0.0130
INFO - 2017-02-13 11:01:27 --> Config Class Initialized
INFO - 2017-02-13 11:01:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 11:01:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 11:01:27 --> Utf8 Class Initialized
INFO - 2017-02-13 11:01:27 --> URI Class Initialized
INFO - 2017-02-13 11:01:27 --> Router Class Initialized
INFO - 2017-02-13 11:01:27 --> Output Class Initialized
INFO - 2017-02-13 11:01:27 --> Security Class Initialized
DEBUG - 2017-02-13 11:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 11:01:27 --> Input Class Initialized
INFO - 2017-02-13 11:01:27 --> Language Class Initialized
INFO - 2017-02-13 11:01:27 --> Loader Class Initialized
INFO - 2017-02-13 11:01:27 --> Database Driver Class Initialized
INFO - 2017-02-13 11:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 11:01:27 --> Controller Class Initialized
INFO - 2017-02-13 11:01:27 --> Helper loaded: url_helper
DEBUG - 2017-02-13 11:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 11:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 11:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 11:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 11:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 11:01:27 --> Final output sent to browser
DEBUG - 2017-02-13 11:01:27 --> Total execution time: 0.0196
INFO - 2017-02-13 11:39:18 --> Config Class Initialized
INFO - 2017-02-13 11:39:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 11:39:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 11:39:18 --> Utf8 Class Initialized
INFO - 2017-02-13 11:39:18 --> URI Class Initialized
INFO - 2017-02-13 11:39:18 --> Router Class Initialized
INFO - 2017-02-13 11:39:18 --> Output Class Initialized
INFO - 2017-02-13 11:39:18 --> Security Class Initialized
DEBUG - 2017-02-13 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 11:39:18 --> Input Class Initialized
INFO - 2017-02-13 11:39:18 --> Language Class Initialized
INFO - 2017-02-13 11:39:18 --> Loader Class Initialized
INFO - 2017-02-13 11:39:18 --> Database Driver Class Initialized
INFO - 2017-02-13 11:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 11:39:18 --> Controller Class Initialized
INFO - 2017-02-13 11:39:18 --> Helper loaded: url_helper
DEBUG - 2017-02-13 11:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 11:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 11:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 11:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 11:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 11:39:18 --> Final output sent to browser
DEBUG - 2017-02-13 11:39:18 --> Total execution time: 0.0228
INFO - 2017-02-13 16:44:31 --> Config Class Initialized
INFO - 2017-02-13 16:44:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:44:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:44:31 --> Utf8 Class Initialized
INFO - 2017-02-13 16:44:31 --> URI Class Initialized
DEBUG - 2017-02-13 16:44:31 --> No URI present. Default controller set.
INFO - 2017-02-13 16:44:31 --> Router Class Initialized
INFO - 2017-02-13 16:44:31 --> Output Class Initialized
INFO - 2017-02-13 16:44:31 --> Security Class Initialized
DEBUG - 2017-02-13 16:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:44:31 --> Input Class Initialized
INFO - 2017-02-13 16:44:31 --> Language Class Initialized
INFO - 2017-02-13 16:44:31 --> Loader Class Initialized
INFO - 2017-02-13 16:44:31 --> Database Driver Class Initialized
INFO - 2017-02-13 16:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:44:31 --> Controller Class Initialized
INFO - 2017-02-13 16:44:31 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 16:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 16:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:44:31 --> Final output sent to browser
DEBUG - 2017-02-13 16:44:31 --> Total execution time: 0.0411
INFO - 2017-02-13 16:44:36 --> Config Class Initialized
INFO - 2017-02-13 16:44:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:44:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:44:36 --> Utf8 Class Initialized
INFO - 2017-02-13 16:44:36 --> URI Class Initialized
INFO - 2017-02-13 16:44:36 --> Router Class Initialized
INFO - 2017-02-13 16:44:36 --> Output Class Initialized
INFO - 2017-02-13 16:44:36 --> Security Class Initialized
DEBUG - 2017-02-13 16:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:44:36 --> Input Class Initialized
INFO - 2017-02-13 16:44:36 --> Language Class Initialized
INFO - 2017-02-13 16:44:36 --> Loader Class Initialized
INFO - 2017-02-13 16:44:36 --> Database Driver Class Initialized
INFO - 2017-02-13 16:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:44:36 --> Controller Class Initialized
INFO - 2017-02-13 16:44:36 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:44:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:44:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:44:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 16:44:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 16:44:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:44:36 --> Final output sent to browser
DEBUG - 2017-02-13 16:44:36 --> Total execution time: 0.0134
INFO - 2017-02-13 16:44:44 --> Config Class Initialized
INFO - 2017-02-13 16:44:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:44:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:44:44 --> Utf8 Class Initialized
INFO - 2017-02-13 16:44:44 --> URI Class Initialized
INFO - 2017-02-13 16:44:44 --> Router Class Initialized
INFO - 2017-02-13 16:44:44 --> Output Class Initialized
INFO - 2017-02-13 16:44:44 --> Security Class Initialized
DEBUG - 2017-02-13 16:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:44:44 --> Input Class Initialized
INFO - 2017-02-13 16:44:44 --> Language Class Initialized
INFO - 2017-02-13 16:44:44 --> Loader Class Initialized
INFO - 2017-02-13 16:44:44 --> Database Driver Class Initialized
INFO - 2017-02-13 16:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:44:44 --> Controller Class Initialized
INFO - 2017-02-13 16:44:44 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:44:46 --> Config Class Initialized
INFO - 2017-02-13 16:44:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:44:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:44:46 --> Utf8 Class Initialized
INFO - 2017-02-13 16:44:46 --> URI Class Initialized
INFO - 2017-02-13 16:44:47 --> Router Class Initialized
INFO - 2017-02-13 16:44:47 --> Output Class Initialized
INFO - 2017-02-13 16:44:47 --> Security Class Initialized
DEBUG - 2017-02-13 16:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:44:47 --> Input Class Initialized
INFO - 2017-02-13 16:44:47 --> Language Class Initialized
INFO - 2017-02-13 16:44:47 --> Loader Class Initialized
INFO - 2017-02-13 16:44:47 --> Database Driver Class Initialized
INFO - 2017-02-13 16:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:44:47 --> Controller Class Initialized
INFO - 2017-02-13 16:44:47 --> Helper loaded: date_helper
DEBUG - 2017-02-13 16:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:44:47 --> Helper loaded: url_helper
INFO - 2017-02-13 16:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 16:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-13 16:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 16:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:44:47 --> Final output sent to browser
DEBUG - 2017-02-13 16:44:47 --> Total execution time: 0.2177
INFO - 2017-02-13 16:44:49 --> Config Class Initialized
INFO - 2017-02-13 16:44:49 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:44:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:44:49 --> Utf8 Class Initialized
INFO - 2017-02-13 16:44:49 --> URI Class Initialized
INFO - 2017-02-13 16:44:49 --> Router Class Initialized
INFO - 2017-02-13 16:44:49 --> Output Class Initialized
INFO - 2017-02-13 16:44:49 --> Security Class Initialized
DEBUG - 2017-02-13 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:44:49 --> Input Class Initialized
INFO - 2017-02-13 16:44:49 --> Language Class Initialized
INFO - 2017-02-13 16:44:49 --> Loader Class Initialized
INFO - 2017-02-13 16:44:49 --> Database Driver Class Initialized
INFO - 2017-02-13 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:44:49 --> Controller Class Initialized
INFO - 2017-02-13 16:44:49 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 16:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 16:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:44:49 --> Final output sent to browser
DEBUG - 2017-02-13 16:44:49 --> Total execution time: 0.0140
INFO - 2017-02-13 16:45:23 --> Config Class Initialized
INFO - 2017-02-13 16:45:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:45:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:45:23 --> Utf8 Class Initialized
INFO - 2017-02-13 16:45:23 --> URI Class Initialized
INFO - 2017-02-13 16:45:23 --> Router Class Initialized
INFO - 2017-02-13 16:45:23 --> Output Class Initialized
INFO - 2017-02-13 16:45:23 --> Security Class Initialized
DEBUG - 2017-02-13 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:45:23 --> Input Class Initialized
INFO - 2017-02-13 16:45:23 --> Language Class Initialized
INFO - 2017-02-13 16:45:23 --> Loader Class Initialized
INFO - 2017-02-13 16:45:23 --> Database Driver Class Initialized
INFO - 2017-02-13 16:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:45:23 --> Controller Class Initialized
INFO - 2017-02-13 16:45:23 --> Helper loaded: date_helper
DEBUG - 2017-02-13 16:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:45:23 --> Helper loaded: url_helper
INFO - 2017-02-13 16:45:23 --> Helper loaded: download_helper
INFO - 2017-02-13 16:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 16:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-13 16:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-13 16:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:45:23 --> Final output sent to browser
DEBUG - 2017-02-13 16:45:23 --> Total execution time: 0.1382
INFO - 2017-02-13 16:45:25 --> Config Class Initialized
INFO - 2017-02-13 16:45:25 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:45:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:45:25 --> Utf8 Class Initialized
INFO - 2017-02-13 16:45:25 --> URI Class Initialized
INFO - 2017-02-13 16:45:25 --> Router Class Initialized
INFO - 2017-02-13 16:45:25 --> Output Class Initialized
INFO - 2017-02-13 16:45:25 --> Security Class Initialized
DEBUG - 2017-02-13 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:45:25 --> Input Class Initialized
INFO - 2017-02-13 16:45:25 --> Language Class Initialized
INFO - 2017-02-13 16:45:25 --> Loader Class Initialized
INFO - 2017-02-13 16:45:25 --> Database Driver Class Initialized
INFO - 2017-02-13 16:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:45:25 --> Controller Class Initialized
INFO - 2017-02-13 16:45:25 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 16:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 16:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:45:25 --> Final output sent to browser
DEBUG - 2017-02-13 16:45:25 --> Total execution time: 0.0135
INFO - 2017-02-13 16:47:24 --> Config Class Initialized
INFO - 2017-02-13 16:47:24 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:47:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:47:24 --> Utf8 Class Initialized
INFO - 2017-02-13 16:47:24 --> URI Class Initialized
INFO - 2017-02-13 16:47:24 --> Router Class Initialized
INFO - 2017-02-13 16:47:24 --> Output Class Initialized
INFO - 2017-02-13 16:47:24 --> Security Class Initialized
DEBUG - 2017-02-13 16:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:47:24 --> Input Class Initialized
INFO - 2017-02-13 16:47:24 --> Language Class Initialized
INFO - 2017-02-13 16:47:24 --> Loader Class Initialized
INFO - 2017-02-13 16:47:24 --> Database Driver Class Initialized
INFO - 2017-02-13 16:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:47:24 --> Controller Class Initialized
INFO - 2017-02-13 16:47:24 --> Helper loaded: date_helper
DEBUG - 2017-02-13 16:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:47:24 --> Helper loaded: url_helper
INFO - 2017-02-13 16:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-13 16:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 16:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-13 16:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-13 16:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:47:24 --> Final output sent to browser
DEBUG - 2017-02-13 16:47:24 --> Total execution time: 0.0614
INFO - 2017-02-13 16:47:25 --> Config Class Initialized
INFO - 2017-02-13 16:47:25 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:47:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:47:25 --> Utf8 Class Initialized
INFO - 2017-02-13 16:47:25 --> URI Class Initialized
INFO - 2017-02-13 16:47:25 --> Router Class Initialized
INFO - 2017-02-13 16:47:25 --> Output Class Initialized
INFO - 2017-02-13 16:47:25 --> Security Class Initialized
DEBUG - 2017-02-13 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:47:25 --> Input Class Initialized
INFO - 2017-02-13 16:47:25 --> Language Class Initialized
INFO - 2017-02-13 16:47:25 --> Loader Class Initialized
INFO - 2017-02-13 16:47:25 --> Database Driver Class Initialized
INFO - 2017-02-13 16:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:47:25 --> Controller Class Initialized
INFO - 2017-02-13 16:47:25 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 16:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 16:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:47:25 --> Final output sent to browser
DEBUG - 2017-02-13 16:47:25 --> Total execution time: 0.0129
INFO - 2017-02-13 16:47:32 --> Config Class Initialized
INFO - 2017-02-13 16:47:32 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:47:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:47:32 --> Utf8 Class Initialized
INFO - 2017-02-13 16:47:32 --> URI Class Initialized
INFO - 2017-02-13 16:47:32 --> Router Class Initialized
INFO - 2017-02-13 16:47:32 --> Output Class Initialized
INFO - 2017-02-13 16:47:32 --> Security Class Initialized
DEBUG - 2017-02-13 16:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:47:32 --> Input Class Initialized
INFO - 2017-02-13 16:47:32 --> Language Class Initialized
INFO - 2017-02-13 16:47:32 --> Loader Class Initialized
INFO - 2017-02-13 16:47:32 --> Database Driver Class Initialized
INFO - 2017-02-13 16:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:47:32 --> Controller Class Initialized
INFO - 2017-02-13 16:47:32 --> Upload Class Initialized
INFO - 2017-02-13 16:47:32 --> Helper loaded: date_helper
DEBUG - 2017-02-13 16:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:47:32 --> Helper loaded: url_helper
INFO - 2017-02-13 16:47:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:47:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:47:33 --> Final output sent to browser
DEBUG - 2017-02-13 16:47:33 --> Total execution time: 0.3473
INFO - 2017-02-13 16:47:33 --> Config Class Initialized
INFO - 2017-02-13 16:47:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:47:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:47:33 --> Utf8 Class Initialized
INFO - 2017-02-13 16:47:33 --> URI Class Initialized
INFO - 2017-02-13 16:47:33 --> Router Class Initialized
INFO - 2017-02-13 16:47:33 --> Output Class Initialized
INFO - 2017-02-13 16:47:33 --> Security Class Initialized
DEBUG - 2017-02-13 16:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:47:33 --> Input Class Initialized
INFO - 2017-02-13 16:47:33 --> Language Class Initialized
INFO - 2017-02-13 16:47:33 --> Loader Class Initialized
INFO - 2017-02-13 16:47:33 --> Database Driver Class Initialized
INFO - 2017-02-13 16:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:47:33 --> Controller Class Initialized
INFO - 2017-02-13 16:47:33 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 16:47:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:47:33 --> Final output sent to browser
DEBUG - 2017-02-13 16:47:33 --> Total execution time: 0.0145
INFO - 2017-02-13 16:47:40 --> Config Class Initialized
INFO - 2017-02-13 16:47:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:47:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:47:40 --> Utf8 Class Initialized
INFO - 2017-02-13 16:47:40 --> URI Class Initialized
INFO - 2017-02-13 16:47:40 --> Router Class Initialized
INFO - 2017-02-13 16:47:40 --> Output Class Initialized
INFO - 2017-02-13 16:47:40 --> Security Class Initialized
DEBUG - 2017-02-13 16:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:47:40 --> Input Class Initialized
INFO - 2017-02-13 16:47:40 --> Language Class Initialized
INFO - 2017-02-13 16:47:40 --> Loader Class Initialized
INFO - 2017-02-13 16:47:40 --> Database Driver Class Initialized
INFO - 2017-02-13 16:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:47:40 --> Controller Class Initialized
INFO - 2017-02-13 16:47:40 --> Helper loaded: date_helper
DEBUG - 2017-02-13 16:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:47:40 --> Helper loaded: url_helper
INFO - 2017-02-13 16:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 16:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-13 16:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 16:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:47:40 --> Final output sent to browser
DEBUG - 2017-02-13 16:47:40 --> Total execution time: 0.0147
INFO - 2017-02-13 16:47:41 --> Config Class Initialized
INFO - 2017-02-13 16:47:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:47:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:47:41 --> Utf8 Class Initialized
INFO - 2017-02-13 16:47:41 --> URI Class Initialized
INFO - 2017-02-13 16:47:41 --> Router Class Initialized
INFO - 2017-02-13 16:47:41 --> Output Class Initialized
INFO - 2017-02-13 16:47:41 --> Security Class Initialized
DEBUG - 2017-02-13 16:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:47:41 --> Input Class Initialized
INFO - 2017-02-13 16:47:41 --> Language Class Initialized
INFO - 2017-02-13 16:47:41 --> Loader Class Initialized
INFO - 2017-02-13 16:47:41 --> Database Driver Class Initialized
INFO - 2017-02-13 16:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:47:41 --> Controller Class Initialized
INFO - 2017-02-13 16:47:41 --> Helper loaded: url_helper
DEBUG - 2017-02-13 16:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 16:47:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 16:47:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 16:47:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 16:47:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 16:47:41 --> Final output sent to browser
DEBUG - 2017-02-13 16:47:41 --> Total execution time: 0.0134
INFO - 2017-02-13 18:02:01 --> Config Class Initialized
INFO - 2017-02-13 18:02:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 18:02:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 18:02:01 --> Utf8 Class Initialized
INFO - 2017-02-13 18:02:01 --> URI Class Initialized
DEBUG - 2017-02-13 18:02:01 --> No URI present. Default controller set.
INFO - 2017-02-13 18:02:01 --> Router Class Initialized
INFO - 2017-02-13 18:02:01 --> Output Class Initialized
INFO - 2017-02-13 18:02:01 --> Security Class Initialized
DEBUG - 2017-02-13 18:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 18:02:01 --> Input Class Initialized
INFO - 2017-02-13 18:02:01 --> Language Class Initialized
INFO - 2017-02-13 18:02:01 --> Loader Class Initialized
INFO - 2017-02-13 18:02:01 --> Database Driver Class Initialized
INFO - 2017-02-13 18:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 18:02:01 --> Controller Class Initialized
INFO - 2017-02-13 18:02:01 --> Helper loaded: url_helper
DEBUG - 2017-02-13 18:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 18:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 18:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 18:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 18:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 18:02:01 --> Final output sent to browser
DEBUG - 2017-02-13 18:02:01 --> Total execution time: 0.0169
INFO - 2017-02-13 18:50:13 --> Config Class Initialized
INFO - 2017-02-13 18:50:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 18:50:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 18:50:13 --> Utf8 Class Initialized
INFO - 2017-02-13 18:50:13 --> URI Class Initialized
INFO - 2017-02-13 18:50:13 --> Router Class Initialized
INFO - 2017-02-13 18:50:13 --> Output Class Initialized
INFO - 2017-02-13 18:50:13 --> Security Class Initialized
DEBUG - 2017-02-13 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 18:50:13 --> Input Class Initialized
INFO - 2017-02-13 18:50:13 --> Language Class Initialized
INFO - 2017-02-13 18:50:13 --> Loader Class Initialized
INFO - 2017-02-13 18:50:13 --> Database Driver Class Initialized
INFO - 2017-02-13 18:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 18:50:13 --> Controller Class Initialized
INFO - 2017-02-13 18:50:13 --> Helper loaded: date_helper
DEBUG - 2017-02-13 18:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 18:50:13 --> Helper loaded: url_helper
INFO - 2017-02-13 18:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 18:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 18:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 18:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 18:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 18:50:13 --> Final output sent to browser
DEBUG - 2017-02-13 18:50:13 --> Total execution time: 0.0302
INFO - 2017-02-13 18:50:17 --> Config Class Initialized
INFO - 2017-02-13 18:50:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 18:50:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 18:50:17 --> Utf8 Class Initialized
INFO - 2017-02-13 18:50:17 --> URI Class Initialized
INFO - 2017-02-13 18:50:17 --> Router Class Initialized
INFO - 2017-02-13 18:50:17 --> Output Class Initialized
INFO - 2017-02-13 18:50:17 --> Security Class Initialized
DEBUG - 2017-02-13 18:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 18:50:17 --> Input Class Initialized
INFO - 2017-02-13 18:50:17 --> Language Class Initialized
INFO - 2017-02-13 18:50:17 --> Loader Class Initialized
INFO - 2017-02-13 18:50:17 --> Database Driver Class Initialized
INFO - 2017-02-13 18:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 18:50:17 --> Controller Class Initialized
INFO - 2017-02-13 18:50:17 --> Helper loaded: url_helper
DEBUG - 2017-02-13 18:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 18:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 18:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 18:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 18:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 18:50:17 --> Final output sent to browser
DEBUG - 2017-02-13 18:50:17 --> Total execution time: 0.0131
INFO - 2017-02-13 19:04:40 --> Config Class Initialized
INFO - 2017-02-13 19:04:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:04:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:04:40 --> Utf8 Class Initialized
INFO - 2017-02-13 19:04:40 --> URI Class Initialized
INFO - 2017-02-13 19:04:40 --> Router Class Initialized
INFO - 2017-02-13 19:04:40 --> Output Class Initialized
INFO - 2017-02-13 19:04:40 --> Security Class Initialized
DEBUG - 2017-02-13 19:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:04:40 --> Input Class Initialized
INFO - 2017-02-13 19:04:40 --> Language Class Initialized
INFO - 2017-02-13 19:04:40 --> Loader Class Initialized
INFO - 2017-02-13 19:04:40 --> Database Driver Class Initialized
INFO - 2017-02-13 19:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:04:40 --> Controller Class Initialized
INFO - 2017-02-13 19:04:40 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:04:40 --> Config Class Initialized
INFO - 2017-02-13 19:04:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:04:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:04:40 --> Utf8 Class Initialized
INFO - 2017-02-13 19:04:40 --> URI Class Initialized
DEBUG - 2017-02-13 19:04:40 --> No URI present. Default controller set.
INFO - 2017-02-13 19:04:40 --> Router Class Initialized
INFO - 2017-02-13 19:04:40 --> Output Class Initialized
INFO - 2017-02-13 19:04:40 --> Security Class Initialized
DEBUG - 2017-02-13 19:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:04:40 --> Input Class Initialized
INFO - 2017-02-13 19:04:40 --> Language Class Initialized
INFO - 2017-02-13 19:04:40 --> Loader Class Initialized
INFO - 2017-02-13 19:04:40 --> Database Driver Class Initialized
INFO - 2017-02-13 19:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:04:40 --> Controller Class Initialized
INFO - 2017-02-13 19:04:40 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:04:40 --> Final output sent to browser
DEBUG - 2017-02-13 19:04:40 --> Total execution time: 0.0133
INFO - 2017-02-13 19:04:40 --> Config Class Initialized
INFO - 2017-02-13 19:04:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:04:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:04:40 --> Utf8 Class Initialized
INFO - 2017-02-13 19:04:40 --> URI Class Initialized
INFO - 2017-02-13 19:04:40 --> Router Class Initialized
INFO - 2017-02-13 19:04:40 --> Output Class Initialized
INFO - 2017-02-13 19:04:40 --> Security Class Initialized
DEBUG - 2017-02-13 19:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:04:40 --> Input Class Initialized
INFO - 2017-02-13 19:04:40 --> Language Class Initialized
INFO - 2017-02-13 19:04:40 --> Loader Class Initialized
INFO - 2017-02-13 19:04:40 --> Database Driver Class Initialized
INFO - 2017-02-13 19:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:04:40 --> Controller Class Initialized
INFO - 2017-02-13 19:04:40 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 19:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:04:40 --> Final output sent to browser
DEBUG - 2017-02-13 19:04:40 --> Total execution time: 0.0138
INFO - 2017-02-13 19:04:42 --> Config Class Initialized
INFO - 2017-02-13 19:04:42 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:04:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:04:42 --> Utf8 Class Initialized
INFO - 2017-02-13 19:04:42 --> URI Class Initialized
INFO - 2017-02-13 19:04:42 --> Router Class Initialized
INFO - 2017-02-13 19:04:42 --> Output Class Initialized
INFO - 2017-02-13 19:04:42 --> Security Class Initialized
DEBUG - 2017-02-13 19:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:04:42 --> Input Class Initialized
INFO - 2017-02-13 19:04:42 --> Language Class Initialized
INFO - 2017-02-13 19:04:42 --> Loader Class Initialized
INFO - 2017-02-13 19:04:42 --> Database Driver Class Initialized
INFO - 2017-02-13 19:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:04:42 --> Controller Class Initialized
INFO - 2017-02-13 19:04:42 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 19:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 19:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:04:42 --> Final output sent to browser
DEBUG - 2017-02-13 19:04:42 --> Total execution time: 0.0143
INFO - 2017-02-13 19:16:10 --> Config Class Initialized
INFO - 2017-02-13 19:16:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:16:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:16:10 --> Utf8 Class Initialized
INFO - 2017-02-13 19:16:10 --> URI Class Initialized
DEBUG - 2017-02-13 19:16:10 --> No URI present. Default controller set.
INFO - 2017-02-13 19:16:10 --> Router Class Initialized
INFO - 2017-02-13 19:16:10 --> Output Class Initialized
INFO - 2017-02-13 19:16:10 --> Security Class Initialized
DEBUG - 2017-02-13 19:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:16:10 --> Input Class Initialized
INFO - 2017-02-13 19:16:10 --> Language Class Initialized
INFO - 2017-02-13 19:16:10 --> Loader Class Initialized
INFO - 2017-02-13 19:16:10 --> Database Driver Class Initialized
INFO - 2017-02-13 19:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:16:10 --> Controller Class Initialized
INFO - 2017-02-13 19:16:10 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 19:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 19:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:16:10 --> Final output sent to browser
DEBUG - 2017-02-13 19:16:10 --> Total execution time: 0.0137
INFO - 2017-02-13 19:16:18 --> Config Class Initialized
INFO - 2017-02-13 19:16:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:16:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:16:18 --> Utf8 Class Initialized
INFO - 2017-02-13 19:16:18 --> URI Class Initialized
INFO - 2017-02-13 19:16:18 --> Router Class Initialized
INFO - 2017-02-13 19:16:18 --> Output Class Initialized
INFO - 2017-02-13 19:16:18 --> Security Class Initialized
DEBUG - 2017-02-13 19:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:16:18 --> Input Class Initialized
INFO - 2017-02-13 19:16:18 --> Language Class Initialized
INFO - 2017-02-13 19:16:18 --> Loader Class Initialized
INFO - 2017-02-13 19:16:18 --> Database Driver Class Initialized
INFO - 2017-02-13 19:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:16:18 --> Controller Class Initialized
INFO - 2017-02-13 19:16:18 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 19:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 19:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:16:18 --> Final output sent to browser
DEBUG - 2017-02-13 19:16:18 --> Total execution time: 0.0141
INFO - 2017-02-13 19:16:30 --> Config Class Initialized
INFO - 2017-02-13 19:16:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:16:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:16:30 --> Utf8 Class Initialized
INFO - 2017-02-13 19:16:30 --> URI Class Initialized
INFO - 2017-02-13 19:16:30 --> Router Class Initialized
INFO - 2017-02-13 19:16:30 --> Output Class Initialized
INFO - 2017-02-13 19:16:30 --> Security Class Initialized
DEBUG - 2017-02-13 19:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:16:30 --> Input Class Initialized
INFO - 2017-02-13 19:16:30 --> Language Class Initialized
INFO - 2017-02-13 19:16:30 --> Loader Class Initialized
INFO - 2017-02-13 19:16:30 --> Database Driver Class Initialized
INFO - 2017-02-13 19:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:16:30 --> Controller Class Initialized
INFO - 2017-02-13 19:16:30 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:16:30 --> Config Class Initialized
INFO - 2017-02-13 19:16:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:16:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:16:30 --> Utf8 Class Initialized
INFO - 2017-02-13 19:16:30 --> URI Class Initialized
INFO - 2017-02-13 19:16:30 --> Router Class Initialized
INFO - 2017-02-13 19:16:30 --> Output Class Initialized
INFO - 2017-02-13 19:16:30 --> Security Class Initialized
DEBUG - 2017-02-13 19:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:16:30 --> Input Class Initialized
INFO - 2017-02-13 19:16:30 --> Language Class Initialized
INFO - 2017-02-13 19:16:30 --> Loader Class Initialized
INFO - 2017-02-13 19:16:30 --> Database Driver Class Initialized
INFO - 2017-02-13 19:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:16:30 --> Controller Class Initialized
INFO - 2017-02-13 19:16:30 --> Helper loaded: date_helper
DEBUG - 2017-02-13 19:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:16:30 --> Helper loaded: url_helper
INFO - 2017-02-13 19:16:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:16:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 19:16:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 19:16:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 19:16:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:16:30 --> Final output sent to browser
DEBUG - 2017-02-13 19:16:30 --> Total execution time: 0.0140
INFO - 2017-02-13 19:16:32 --> Config Class Initialized
INFO - 2017-02-13 19:16:32 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:16:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:16:32 --> Utf8 Class Initialized
INFO - 2017-02-13 19:16:32 --> URI Class Initialized
INFO - 2017-02-13 19:16:32 --> Router Class Initialized
INFO - 2017-02-13 19:16:32 --> Output Class Initialized
INFO - 2017-02-13 19:16:32 --> Security Class Initialized
DEBUG - 2017-02-13 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:16:32 --> Input Class Initialized
INFO - 2017-02-13 19:16:32 --> Language Class Initialized
INFO - 2017-02-13 19:16:32 --> Loader Class Initialized
INFO - 2017-02-13 19:16:32 --> Database Driver Class Initialized
INFO - 2017-02-13 19:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:16:32 --> Controller Class Initialized
INFO - 2017-02-13 19:16:32 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 19:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 19:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:16:32 --> Final output sent to browser
DEBUG - 2017-02-13 19:16:32 --> Total execution time: 0.0134
INFO - 2017-02-13 19:53:27 --> Config Class Initialized
INFO - 2017-02-13 19:53:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:53:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:53:27 --> Utf8 Class Initialized
INFO - 2017-02-13 19:53:27 --> URI Class Initialized
INFO - 2017-02-13 19:53:27 --> Router Class Initialized
INFO - 2017-02-13 19:53:27 --> Output Class Initialized
INFO - 2017-02-13 19:53:27 --> Security Class Initialized
DEBUG - 2017-02-13 19:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:53:27 --> Input Class Initialized
INFO - 2017-02-13 19:53:27 --> Language Class Initialized
INFO - 2017-02-13 19:53:27 --> Loader Class Initialized
INFO - 2017-02-13 19:53:27 --> Database Driver Class Initialized
INFO - 2017-02-13 19:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:53:27 --> Controller Class Initialized
INFO - 2017-02-13 19:53:27 --> Helper loaded: date_helper
DEBUG - 2017-02-13 19:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:53:27 --> Helper loaded: url_helper
INFO - 2017-02-13 19:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 19:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 19:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 19:53:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:53:27 --> Final output sent to browser
DEBUG - 2017-02-13 19:53:27 --> Total execution time: 0.0141
INFO - 2017-02-13 19:53:33 --> Config Class Initialized
INFO - 2017-02-13 19:53:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 19:53:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 19:53:33 --> Utf8 Class Initialized
INFO - 2017-02-13 19:53:33 --> URI Class Initialized
INFO - 2017-02-13 19:53:33 --> Router Class Initialized
INFO - 2017-02-13 19:53:33 --> Output Class Initialized
INFO - 2017-02-13 19:53:33 --> Security Class Initialized
DEBUG - 2017-02-13 19:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 19:53:33 --> Input Class Initialized
INFO - 2017-02-13 19:53:33 --> Language Class Initialized
INFO - 2017-02-13 19:53:33 --> Loader Class Initialized
INFO - 2017-02-13 19:53:33 --> Database Driver Class Initialized
INFO - 2017-02-13 19:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 19:53:33 --> Controller Class Initialized
INFO - 2017-02-13 19:53:33 --> Helper loaded: url_helper
DEBUG - 2017-02-13 19:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 19:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 19:53:33 --> Final output sent to browser
DEBUG - 2017-02-13 19:53:33 --> Total execution time: 0.0138
INFO - 2017-02-13 22:47:51 --> Config Class Initialized
INFO - 2017-02-13 22:47:51 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:47:51 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:47:51 --> Utf8 Class Initialized
INFO - 2017-02-13 22:47:51 --> URI Class Initialized
DEBUG - 2017-02-13 22:47:51 --> No URI present. Default controller set.
INFO - 2017-02-13 22:47:51 --> Router Class Initialized
INFO - 2017-02-13 22:47:51 --> Output Class Initialized
INFO - 2017-02-13 22:47:51 --> Security Class Initialized
DEBUG - 2017-02-13 22:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:47:51 --> Input Class Initialized
INFO - 2017-02-13 22:47:51 --> Language Class Initialized
INFO - 2017-02-13 22:47:51 --> Loader Class Initialized
INFO - 2017-02-13 22:47:51 --> Database Driver Class Initialized
INFO - 2017-02-13 22:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:47:51 --> Controller Class Initialized
INFO - 2017-02-13 22:47:51 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:47:51 --> Final output sent to browser
DEBUG - 2017-02-13 22:47:51 --> Total execution time: 0.0138
INFO - 2017-02-13 22:47:59 --> Config Class Initialized
INFO - 2017-02-13 22:47:59 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:47:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:47:59 --> Utf8 Class Initialized
INFO - 2017-02-13 22:47:59 --> URI Class Initialized
INFO - 2017-02-13 22:47:59 --> Router Class Initialized
INFO - 2017-02-13 22:47:59 --> Output Class Initialized
INFO - 2017-02-13 22:47:59 --> Security Class Initialized
DEBUG - 2017-02-13 22:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:47:59 --> Input Class Initialized
INFO - 2017-02-13 22:47:59 --> Language Class Initialized
INFO - 2017-02-13 22:47:59 --> Loader Class Initialized
INFO - 2017-02-13 22:47:59 --> Database Driver Class Initialized
INFO - 2017-02-13 22:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:47:59 --> Controller Class Initialized
INFO - 2017-02-13 22:47:59 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:47:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:47:59 --> Final output sent to browser
DEBUG - 2017-02-13 22:47:59 --> Total execution time: 0.0135
INFO - 2017-02-13 22:48:32 --> Config Class Initialized
INFO - 2017-02-13 22:48:32 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:48:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:48:32 --> Utf8 Class Initialized
INFO - 2017-02-13 22:48:32 --> URI Class Initialized
INFO - 2017-02-13 22:48:32 --> Router Class Initialized
INFO - 2017-02-13 22:48:32 --> Output Class Initialized
INFO - 2017-02-13 22:48:32 --> Security Class Initialized
DEBUG - 2017-02-13 22:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:48:32 --> Input Class Initialized
INFO - 2017-02-13 22:48:32 --> Language Class Initialized
INFO - 2017-02-13 22:48:32 --> Loader Class Initialized
INFO - 2017-02-13 22:48:32 --> Database Driver Class Initialized
INFO - 2017-02-13 22:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:48:32 --> Controller Class Initialized
INFO - 2017-02-13 22:48:32 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:48:32 --> Helper loaded: form_helper
INFO - 2017-02-13 22:48:32 --> Form Validation Class Initialized
INFO - 2017-02-13 22:48:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-13 22:48:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-13 22:48:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-13 22:48:33 --> Final output sent to browser
DEBUG - 2017-02-13 22:48:33 --> Total execution time: 0.2080
INFO - 2017-02-13 22:48:33 --> Config Class Initialized
INFO - 2017-02-13 22:48:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:48:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:48:33 --> Utf8 Class Initialized
INFO - 2017-02-13 22:48:33 --> URI Class Initialized
INFO - 2017-02-13 22:48:33 --> Router Class Initialized
INFO - 2017-02-13 22:48:33 --> Output Class Initialized
INFO - 2017-02-13 22:48:33 --> Security Class Initialized
DEBUG - 2017-02-13 22:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:48:33 --> Input Class Initialized
INFO - 2017-02-13 22:48:33 --> Language Class Initialized
INFO - 2017-02-13 22:48:33 --> Loader Class Initialized
INFO - 2017-02-13 22:48:33 --> Database Driver Class Initialized
INFO - 2017-02-13 22:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:48:33 --> Controller Class Initialized
INFO - 2017-02-13 22:48:33 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:48:33 --> Final output sent to browser
DEBUG - 2017-02-13 22:48:33 --> Total execution time: 0.0149
INFO - 2017-02-13 22:48:39 --> Config Class Initialized
INFO - 2017-02-13 22:48:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:48:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:48:39 --> Utf8 Class Initialized
INFO - 2017-02-13 22:48:39 --> URI Class Initialized
INFO - 2017-02-13 22:48:39 --> Router Class Initialized
INFO - 2017-02-13 22:48:39 --> Output Class Initialized
INFO - 2017-02-13 22:48:39 --> Security Class Initialized
DEBUG - 2017-02-13 22:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:48:39 --> Input Class Initialized
INFO - 2017-02-13 22:48:39 --> Language Class Initialized
INFO - 2017-02-13 22:48:39 --> Loader Class Initialized
INFO - 2017-02-13 22:48:39 --> Database Driver Class Initialized
INFO - 2017-02-13 22:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:48:39 --> Controller Class Initialized
INFO - 2017-02-13 22:48:39 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:48:39 --> Helper loaded: form_helper
INFO - 2017-02-13 22:48:39 --> Form Validation Class Initialized
INFO - 2017-02-13 22:48:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-13 22:48:39 --> Config Class Initialized
INFO - 2017-02-13 22:48:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:48:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:48:39 --> Utf8 Class Initialized
INFO - 2017-02-13 22:48:39 --> URI Class Initialized
INFO - 2017-02-13 22:48:39 --> Router Class Initialized
INFO - 2017-02-13 22:48:39 --> Output Class Initialized
INFO - 2017-02-13 22:48:39 --> Security Class Initialized
DEBUG - 2017-02-13 22:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:48:39 --> Input Class Initialized
INFO - 2017-02-13 22:48:39 --> Language Class Initialized
INFO - 2017-02-13 22:48:39 --> Loader Class Initialized
INFO - 2017-02-13 22:48:39 --> Database Driver Class Initialized
INFO - 2017-02-13 22:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:48:39 --> Controller Class Initialized
INFO - 2017-02-13 22:48:39 --> Helper loaded: date_helper
INFO - 2017-02-13 22:48:39 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:48:39 --> Helper loaded: form_helper
INFO - 2017-02-13 22:48:39 --> Form Validation Class Initialized
INFO - 2017-02-13 22:48:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-13 22:48:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-13 22:48:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-02-13 22:48:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-02-13 22:48:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-13 22:48:39 --> Final output sent to browser
DEBUG - 2017-02-13 22:48:39 --> Total execution time: 0.0756
INFO - 2017-02-13 22:48:40 --> Config Class Initialized
INFO - 2017-02-13 22:48:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:48:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:48:40 --> Utf8 Class Initialized
INFO - 2017-02-13 22:48:40 --> URI Class Initialized
INFO - 2017-02-13 22:48:40 --> Router Class Initialized
INFO - 2017-02-13 22:48:40 --> Output Class Initialized
INFO - 2017-02-13 22:48:40 --> Security Class Initialized
DEBUG - 2017-02-13 22:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:48:40 --> Input Class Initialized
INFO - 2017-02-13 22:48:40 --> Language Class Initialized
INFO - 2017-02-13 22:48:40 --> Loader Class Initialized
INFO - 2017-02-13 22:48:40 --> Database Driver Class Initialized
INFO - 2017-02-13 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:48:40 --> Controller Class Initialized
INFO - 2017-02-13 22:48:40 --> Helper loaded: date_helper
INFO - 2017-02-13 22:48:40 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:48:40 --> Helper loaded: form_helper
INFO - 2017-02-13 22:48:40 --> Form Validation Class Initialized
INFO - 2017-02-13 22:48:40 --> Final output sent to browser
DEBUG - 2017-02-13 22:48:40 --> Total execution time: 0.0151
INFO - 2017-02-13 22:48:41 --> Config Class Initialized
INFO - 2017-02-13 22:48:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:48:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:48:41 --> Utf8 Class Initialized
INFO - 2017-02-13 22:48:41 --> URI Class Initialized
INFO - 2017-02-13 22:48:41 --> Router Class Initialized
INFO - 2017-02-13 22:48:41 --> Output Class Initialized
INFO - 2017-02-13 22:48:41 --> Security Class Initialized
DEBUG - 2017-02-13 22:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:48:41 --> Input Class Initialized
INFO - 2017-02-13 22:48:41 --> Language Class Initialized
INFO - 2017-02-13 22:48:41 --> Loader Class Initialized
INFO - 2017-02-13 22:48:41 --> Database Driver Class Initialized
INFO - 2017-02-13 22:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:48:41 --> Controller Class Initialized
INFO - 2017-02-13 22:48:41 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:48:41 --> Final output sent to browser
DEBUG - 2017-02-13 22:48:41 --> Total execution time: 0.0131
INFO - 2017-02-13 22:49:14 --> Config Class Initialized
INFO - 2017-02-13 22:49:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:49:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:49:14 --> Utf8 Class Initialized
INFO - 2017-02-13 22:49:14 --> URI Class Initialized
INFO - 2017-02-13 22:49:14 --> Router Class Initialized
INFO - 2017-02-13 22:49:14 --> Output Class Initialized
INFO - 2017-02-13 22:49:14 --> Security Class Initialized
DEBUG - 2017-02-13 22:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:49:14 --> Input Class Initialized
INFO - 2017-02-13 22:49:14 --> Language Class Initialized
INFO - 2017-02-13 22:49:14 --> Loader Class Initialized
INFO - 2017-02-13 22:49:14 --> Database Driver Class Initialized
INFO - 2017-02-13 22:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:49:14 --> Controller Class Initialized
INFO - 2017-02-13 22:49:14 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:49:14 --> Config Class Initialized
INFO - 2017-02-13 22:49:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:49:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:49:14 --> Utf8 Class Initialized
INFO - 2017-02-13 22:49:14 --> URI Class Initialized
INFO - 2017-02-13 22:49:14 --> Router Class Initialized
INFO - 2017-02-13 22:49:14 --> Output Class Initialized
INFO - 2017-02-13 22:49:14 --> Security Class Initialized
DEBUG - 2017-02-13 22:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:49:14 --> Input Class Initialized
INFO - 2017-02-13 22:49:14 --> Language Class Initialized
INFO - 2017-02-13 22:49:14 --> Loader Class Initialized
INFO - 2017-02-13 22:49:14 --> Database Driver Class Initialized
INFO - 2017-02-13 22:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:49:14 --> Controller Class Initialized
INFO - 2017-02-13 22:49:14 --> Helper loaded: date_helper
DEBUG - 2017-02-13 22:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:49:14 --> Helper loaded: url_helper
INFO - 2017-02-13 22:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 22:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-13 22:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 22:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:49:14 --> Final output sent to browser
DEBUG - 2017-02-13 22:49:14 --> Total execution time: 0.0145
INFO - 2017-02-13 22:49:16 --> Config Class Initialized
INFO - 2017-02-13 22:49:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:49:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:49:16 --> Utf8 Class Initialized
INFO - 2017-02-13 22:49:16 --> URI Class Initialized
INFO - 2017-02-13 22:49:16 --> Router Class Initialized
INFO - 2017-02-13 22:49:16 --> Output Class Initialized
INFO - 2017-02-13 22:49:16 --> Security Class Initialized
DEBUG - 2017-02-13 22:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:49:16 --> Input Class Initialized
INFO - 2017-02-13 22:49:16 --> Language Class Initialized
INFO - 2017-02-13 22:49:16 --> Loader Class Initialized
INFO - 2017-02-13 22:49:16 --> Database Driver Class Initialized
INFO - 2017-02-13 22:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:49:16 --> Controller Class Initialized
INFO - 2017-02-13 22:49:16 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:49:16 --> Final output sent to browser
DEBUG - 2017-02-13 22:49:16 --> Total execution time: 0.0135
INFO - 2017-02-13 22:49:35 --> Config Class Initialized
INFO - 2017-02-13 22:49:35 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:49:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:49:35 --> Utf8 Class Initialized
INFO - 2017-02-13 22:49:35 --> URI Class Initialized
INFO - 2017-02-13 22:49:35 --> Router Class Initialized
INFO - 2017-02-13 22:49:35 --> Output Class Initialized
INFO - 2017-02-13 22:49:35 --> Security Class Initialized
DEBUG - 2017-02-13 22:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:49:35 --> Input Class Initialized
INFO - 2017-02-13 22:49:35 --> Language Class Initialized
INFO - 2017-02-13 22:49:35 --> Loader Class Initialized
INFO - 2017-02-13 22:49:35 --> Database Driver Class Initialized
INFO - 2017-02-13 22:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:49:35 --> Controller Class Initialized
INFO - 2017-02-13 22:49:35 --> Helper loaded: date_helper
DEBUG - 2017-02-13 22:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:49:35 --> Helper loaded: url_helper
INFO - 2017-02-13 22:49:35 --> Helper loaded: download_helper
INFO - 2017-02-13 22:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 22:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-13 22:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-13 22:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:49:35 --> Final output sent to browser
DEBUG - 2017-02-13 22:49:35 --> Total execution time: 0.0781
INFO - 2017-02-13 22:49:37 --> Config Class Initialized
INFO - 2017-02-13 22:49:37 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:49:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:49:37 --> Utf8 Class Initialized
INFO - 2017-02-13 22:49:37 --> URI Class Initialized
INFO - 2017-02-13 22:49:37 --> Router Class Initialized
INFO - 2017-02-13 22:49:37 --> Output Class Initialized
INFO - 2017-02-13 22:49:37 --> Security Class Initialized
DEBUG - 2017-02-13 22:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:49:37 --> Input Class Initialized
INFO - 2017-02-13 22:49:37 --> Language Class Initialized
INFO - 2017-02-13 22:49:37 --> Loader Class Initialized
INFO - 2017-02-13 22:49:37 --> Database Driver Class Initialized
INFO - 2017-02-13 22:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:49:37 --> Controller Class Initialized
INFO - 2017-02-13 22:49:37 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:49:37 --> Final output sent to browser
DEBUG - 2017-02-13 22:49:37 --> Total execution time: 0.0143
INFO - 2017-02-13 22:50:09 --> Config Class Initialized
INFO - 2017-02-13 22:50:09 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:50:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:50:09 --> Utf8 Class Initialized
INFO - 2017-02-13 22:50:09 --> URI Class Initialized
INFO - 2017-02-13 22:50:09 --> Router Class Initialized
INFO - 2017-02-13 22:50:09 --> Output Class Initialized
INFO - 2017-02-13 22:50:09 --> Security Class Initialized
DEBUG - 2017-02-13 22:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:50:09 --> Input Class Initialized
INFO - 2017-02-13 22:50:09 --> Language Class Initialized
INFO - 2017-02-13 22:50:09 --> Loader Class Initialized
INFO - 2017-02-13 22:50:09 --> Database Driver Class Initialized
INFO - 2017-02-13 22:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:50:09 --> Controller Class Initialized
INFO - 2017-02-13 22:50:09 --> Upload Class Initialized
INFO - 2017-02-13 22:50:09 --> Helper loaded: date_helper
INFO - 2017-02-13 22:50:09 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:50:09 --> Helper loaded: form_helper
INFO - 2017-02-13 22:50:09 --> Form Validation Class Initialized
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-13 22:50:09 --> Final output sent to browser
DEBUG - 2017-02-13 22:50:09 --> Total execution time: 0.1008
INFO - 2017-02-13 22:50:09 --> Config Class Initialized
INFO - 2017-02-13 22:50:09 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:50:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:50:09 --> Utf8 Class Initialized
INFO - 2017-02-13 22:50:09 --> URI Class Initialized
INFO - 2017-02-13 22:50:09 --> Router Class Initialized
INFO - 2017-02-13 22:50:09 --> Output Class Initialized
INFO - 2017-02-13 22:50:09 --> Security Class Initialized
DEBUG - 2017-02-13 22:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:50:09 --> Input Class Initialized
INFO - 2017-02-13 22:50:09 --> Language Class Initialized
INFO - 2017-02-13 22:50:09 --> Loader Class Initialized
INFO - 2017-02-13 22:50:09 --> Database Driver Class Initialized
INFO - 2017-02-13 22:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:50:09 --> Controller Class Initialized
INFO - 2017-02-13 22:50:09 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:50:09 --> Final output sent to browser
DEBUG - 2017-02-13 22:50:09 --> Total execution time: 0.0139
INFO - 2017-02-13 22:50:19 --> Config Class Initialized
INFO - 2017-02-13 22:50:19 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:50:19 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:50:19 --> Utf8 Class Initialized
INFO - 2017-02-13 22:50:19 --> URI Class Initialized
INFO - 2017-02-13 22:50:19 --> Router Class Initialized
INFO - 2017-02-13 22:50:19 --> Output Class Initialized
INFO - 2017-02-13 22:50:19 --> Security Class Initialized
DEBUG - 2017-02-13 22:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:50:19 --> Input Class Initialized
INFO - 2017-02-13 22:50:19 --> Language Class Initialized
INFO - 2017-02-13 22:50:19 --> Loader Class Initialized
INFO - 2017-02-13 22:50:19 --> Database Driver Class Initialized
INFO - 2017-02-13 22:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:50:19 --> Controller Class Initialized
INFO - 2017-02-13 22:50:19 --> Helper loaded: date_helper
INFO - 2017-02-13 22:50:19 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:50:19 --> Helper loaded: form_helper
INFO - 2017-02-13 22:50:19 --> Form Validation Class Initialized
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-13 22:50:19 --> Final output sent to browser
DEBUG - 2017-02-13 22:50:19 --> Total execution time: 0.0154
INFO - 2017-02-13 22:50:19 --> Config Class Initialized
INFO - 2017-02-13 22:50:19 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:50:19 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:50:19 --> Utf8 Class Initialized
INFO - 2017-02-13 22:50:19 --> URI Class Initialized
INFO - 2017-02-13 22:50:19 --> Router Class Initialized
INFO - 2017-02-13 22:50:19 --> Output Class Initialized
INFO - 2017-02-13 22:50:19 --> Security Class Initialized
DEBUG - 2017-02-13 22:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:50:19 --> Input Class Initialized
INFO - 2017-02-13 22:50:19 --> Language Class Initialized
INFO - 2017-02-13 22:50:19 --> Loader Class Initialized
INFO - 2017-02-13 22:50:19 --> Database Driver Class Initialized
INFO - 2017-02-13 22:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:50:19 --> Controller Class Initialized
INFO - 2017-02-13 22:50:19 --> Helper loaded: date_helper
INFO - 2017-02-13 22:50:19 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:50:19 --> Helper loaded: form_helper
INFO - 2017-02-13 22:50:19 --> Form Validation Class Initialized
INFO - 2017-02-13 22:50:19 --> Final output sent to browser
DEBUG - 2017-02-13 22:50:19 --> Total execution time: 0.0142
INFO - 2017-02-13 22:50:19 --> Config Class Initialized
INFO - 2017-02-13 22:50:19 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:50:19 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:50:19 --> Utf8 Class Initialized
INFO - 2017-02-13 22:50:19 --> URI Class Initialized
INFO - 2017-02-13 22:50:19 --> Router Class Initialized
INFO - 2017-02-13 22:50:19 --> Output Class Initialized
INFO - 2017-02-13 22:50:19 --> Security Class Initialized
DEBUG - 2017-02-13 22:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:50:19 --> Input Class Initialized
INFO - 2017-02-13 22:50:19 --> Language Class Initialized
INFO - 2017-02-13 22:50:19 --> Loader Class Initialized
INFO - 2017-02-13 22:50:19 --> Database Driver Class Initialized
INFO - 2017-02-13 22:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:50:19 --> Controller Class Initialized
INFO - 2017-02-13 22:50:19 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:50:19 --> Final output sent to browser
DEBUG - 2017-02-13 22:50:19 --> Total execution time: 0.0316
INFO - 2017-02-13 22:50:23 --> Config Class Initialized
INFO - 2017-02-13 22:50:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:50:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:50:23 --> Utf8 Class Initialized
INFO - 2017-02-13 22:50:23 --> URI Class Initialized
INFO - 2017-02-13 22:50:23 --> Router Class Initialized
INFO - 2017-02-13 22:50:23 --> Output Class Initialized
INFO - 2017-02-13 22:50:23 --> Security Class Initialized
DEBUG - 2017-02-13 22:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:50:23 --> Input Class Initialized
INFO - 2017-02-13 22:50:23 --> Language Class Initialized
INFO - 2017-02-13 22:50:23 --> Loader Class Initialized
INFO - 2017-02-13 22:50:23 --> Config Class Initialized
INFO - 2017-02-13 22:50:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:50:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:50:23 --> Utf8 Class Initialized
INFO - 2017-02-13 22:50:23 --> URI Class Initialized
INFO - 2017-02-13 22:50:23 --> Router Class Initialized
INFO - 2017-02-13 22:50:23 --> Database Driver Class Initialized
INFO - 2017-02-13 22:50:23 --> Output Class Initialized
INFO - 2017-02-13 22:50:23 --> Security Class Initialized
DEBUG - 2017-02-13 22:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:50:23 --> Input Class Initialized
INFO - 2017-02-13 22:50:23 --> Language Class Initialized
INFO - 2017-02-13 22:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:50:23 --> Controller Class Initialized
INFO - 2017-02-13 22:50:23 --> Helper loaded: date_helper
INFO - 2017-02-13 22:50:23 --> Loader Class Initialized
INFO - 2017-02-13 22:50:23 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:50:23 --> Helper loaded: form_helper
INFO - 2017-02-13 22:50:23 --> Form Validation Class Initialized
INFO - 2017-02-13 22:50:23 --> Database Driver Class Initialized
INFO - 2017-02-13 22:50:23 --> Final output sent to browser
DEBUG - 2017-02-13 22:50:23 --> Total execution time: 0.0165
INFO - 2017-02-13 22:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:50:23 --> Controller Class Initialized
INFO - 2017-02-13 22:50:23 --> Helper loaded: date_helper
INFO - 2017-02-13 22:50:23 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:50:23 --> Helper loaded: form_helper
INFO - 2017-02-13 22:50:23 --> Form Validation Class Initialized
INFO - 2017-02-13 22:50:23 --> Final output sent to browser
DEBUG - 2017-02-13 22:50:23 --> Total execution time: 0.0884
INFO - 2017-02-13 22:51:27 --> Config Class Initialized
INFO - 2017-02-13 22:51:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:51:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:51:27 --> Utf8 Class Initialized
INFO - 2017-02-13 22:51:27 --> URI Class Initialized
INFO - 2017-02-13 22:51:27 --> Router Class Initialized
INFO - 2017-02-13 22:51:27 --> Output Class Initialized
INFO - 2017-02-13 22:51:27 --> Security Class Initialized
DEBUG - 2017-02-13 22:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:51:27 --> Input Class Initialized
INFO - 2017-02-13 22:51:27 --> Language Class Initialized
INFO - 2017-02-13 22:51:27 --> Loader Class Initialized
INFO - 2017-02-13 22:51:27 --> Database Driver Class Initialized
INFO - 2017-02-13 22:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:51:28 --> Controller Class Initialized
INFO - 2017-02-13 22:51:28 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:51:28 --> Final output sent to browser
DEBUG - 2017-02-13 22:51:28 --> Total execution time: 0.0707
INFO - 2017-02-13 22:54:10 --> Config Class Initialized
INFO - 2017-02-13 22:54:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:54:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:54:10 --> Utf8 Class Initialized
INFO - 2017-02-13 22:54:10 --> URI Class Initialized
INFO - 2017-02-13 22:54:10 --> Router Class Initialized
INFO - 2017-02-13 22:54:10 --> Config Class Initialized
INFO - 2017-02-13 22:54:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:54:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:54:10 --> Utf8 Class Initialized
INFO - 2017-02-13 22:54:10 --> URI Class Initialized
INFO - 2017-02-13 22:54:10 --> Router Class Initialized
INFO - 2017-02-13 22:54:10 --> Output Class Initialized
INFO - 2017-02-13 22:54:10 --> Security Class Initialized
DEBUG - 2017-02-13 22:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:54:10 --> Input Class Initialized
INFO - 2017-02-13 22:54:10 --> Language Class Initialized
INFO - 2017-02-13 22:54:10 --> Loader Class Initialized
INFO - 2017-02-13 22:54:10 --> Database Driver Class Initialized
INFO - 2017-02-13 22:54:10 --> Output Class Initialized
INFO - 2017-02-13 22:54:10 --> Security Class Initialized
DEBUG - 2017-02-13 22:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:54:10 --> Input Class Initialized
INFO - 2017-02-13 22:54:10 --> Language Class Initialized
INFO - 2017-02-13 22:54:10 --> Loader Class Initialized
INFO - 2017-02-13 22:54:10 --> Database Driver Class Initialized
INFO - 2017-02-13 22:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:54:10 --> Controller Class Initialized
INFO - 2017-02-13 22:54:10 --> Helper loaded: date_helper
INFO - 2017-02-13 22:54:10 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:54:10 --> Helper loaded: form_helper
INFO - 2017-02-13 22:54:10 --> Form Validation Class Initialized
INFO - 2017-02-13 22:54:10 --> Final output sent to browser
DEBUG - 2017-02-13 22:54:10 --> Total execution time: 0.0214
INFO - 2017-02-13 22:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:54:10 --> Controller Class Initialized
INFO - 2017-02-13 22:54:10 --> Helper loaded: date_helper
INFO - 2017-02-13 22:54:10 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:54:10 --> Helper loaded: form_helper
INFO - 2017-02-13 22:54:10 --> Form Validation Class Initialized
INFO - 2017-02-13 22:54:10 --> Final output sent to browser
DEBUG - 2017-02-13 22:54:10 --> Total execution time: 0.0383
INFO - 2017-02-13 22:55:52 --> Config Class Initialized
INFO - 2017-02-13 22:55:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:55:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:55:52 --> Utf8 Class Initialized
INFO - 2017-02-13 22:55:52 --> URI Class Initialized
INFO - 2017-02-13 22:55:52 --> Router Class Initialized
INFO - 2017-02-13 22:55:52 --> Output Class Initialized
INFO - 2017-02-13 22:55:52 --> Security Class Initialized
DEBUG - 2017-02-13 22:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:55:52 --> Input Class Initialized
INFO - 2017-02-13 22:55:52 --> Language Class Initialized
INFO - 2017-02-13 22:55:52 --> Loader Class Initialized
INFO - 2017-02-13 22:55:52 --> Database Driver Class Initialized
INFO - 2017-02-13 22:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:55:52 --> Controller Class Initialized
INFO - 2017-02-13 22:55:52 --> Helper loaded: date_helper
DEBUG - 2017-02-13 22:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:55:52 --> Helper loaded: url_helper
INFO - 2017-02-13 22:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-13 22:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 22:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-13 22:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-13 22:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:55:52 --> Final output sent to browser
DEBUG - 2017-02-13 22:55:52 --> Total execution time: 0.0442
INFO - 2017-02-13 22:55:53 --> Config Class Initialized
INFO - 2017-02-13 22:55:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:55:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:55:53 --> Utf8 Class Initialized
INFO - 2017-02-13 22:55:53 --> URI Class Initialized
INFO - 2017-02-13 22:55:53 --> Router Class Initialized
INFO - 2017-02-13 22:55:53 --> Output Class Initialized
INFO - 2017-02-13 22:55:53 --> Security Class Initialized
DEBUG - 2017-02-13 22:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:55:53 --> Input Class Initialized
INFO - 2017-02-13 22:55:53 --> Language Class Initialized
INFO - 2017-02-13 22:55:53 --> Loader Class Initialized
INFO - 2017-02-13 22:55:53 --> Database Driver Class Initialized
INFO - 2017-02-13 22:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:55:53 --> Controller Class Initialized
INFO - 2017-02-13 22:55:53 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:55:53 --> Final output sent to browser
DEBUG - 2017-02-13 22:55:53 --> Total execution time: 0.0134
INFO - 2017-02-13 22:55:53 --> Config Class Initialized
INFO - 2017-02-13 22:55:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:55:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:55:53 --> Utf8 Class Initialized
INFO - 2017-02-13 22:55:53 --> URI Class Initialized
INFO - 2017-02-13 22:55:53 --> Router Class Initialized
INFO - 2017-02-13 22:55:53 --> Output Class Initialized
INFO - 2017-02-13 22:55:53 --> Security Class Initialized
DEBUG - 2017-02-13 22:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:55:53 --> Input Class Initialized
INFO - 2017-02-13 22:55:53 --> Language Class Initialized
INFO - 2017-02-13 22:55:53 --> Loader Class Initialized
INFO - 2017-02-13 22:55:53 --> Database Driver Class Initialized
INFO - 2017-02-13 22:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:55:53 --> Controller Class Initialized
INFO - 2017-02-13 22:55:53 --> Helper loaded: date_helper
DEBUG - 2017-02-13 22:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:55:53 --> Helper loaded: url_helper
INFO - 2017-02-13 22:55:53 --> Helper loaded: download_helper
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:55:53 --> Final output sent to browser
DEBUG - 2017-02-13 22:55:53 --> Total execution time: 0.0195
INFO - 2017-02-13 22:55:53 --> Config Class Initialized
INFO - 2017-02-13 22:55:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:55:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:55:53 --> Utf8 Class Initialized
INFO - 2017-02-13 22:55:53 --> URI Class Initialized
INFO - 2017-02-13 22:55:53 --> Router Class Initialized
INFO - 2017-02-13 22:55:53 --> Output Class Initialized
INFO - 2017-02-13 22:55:53 --> Security Class Initialized
DEBUG - 2017-02-13 22:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:55:53 --> Input Class Initialized
INFO - 2017-02-13 22:55:53 --> Language Class Initialized
INFO - 2017-02-13 22:55:53 --> Loader Class Initialized
INFO - 2017-02-13 22:55:53 --> Database Driver Class Initialized
INFO - 2017-02-13 22:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:55:53 --> Controller Class Initialized
INFO - 2017-02-13 22:55:53 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:55:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:55:53 --> Final output sent to browser
DEBUG - 2017-02-13 22:55:53 --> Total execution time: 0.0137
INFO - 2017-02-13 22:56:28 --> Config Class Initialized
INFO - 2017-02-13 22:56:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:56:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:56:28 --> Utf8 Class Initialized
INFO - 2017-02-13 22:56:28 --> URI Class Initialized
DEBUG - 2017-02-13 22:56:28 --> No URI present. Default controller set.
INFO - 2017-02-13 22:56:28 --> Router Class Initialized
INFO - 2017-02-13 22:56:28 --> Output Class Initialized
INFO - 2017-02-13 22:56:28 --> Security Class Initialized
DEBUG - 2017-02-13 22:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:56:28 --> Input Class Initialized
INFO - 2017-02-13 22:56:28 --> Language Class Initialized
INFO - 2017-02-13 22:56:28 --> Loader Class Initialized
INFO - 2017-02-13 22:56:28 --> Database Driver Class Initialized
INFO - 2017-02-13 22:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:56:28 --> Controller Class Initialized
INFO - 2017-02-13 22:56:28 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:56:28 --> Final output sent to browser
DEBUG - 2017-02-13 22:56:28 --> Total execution time: 0.0358
INFO - 2017-02-13 22:56:33 --> Config Class Initialized
INFO - 2017-02-13 22:56:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:56:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:56:33 --> Utf8 Class Initialized
INFO - 2017-02-13 22:56:33 --> URI Class Initialized
INFO - 2017-02-13 22:56:33 --> Router Class Initialized
INFO - 2017-02-13 22:56:33 --> Output Class Initialized
INFO - 2017-02-13 22:56:33 --> Security Class Initialized
DEBUG - 2017-02-13 22:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:56:33 --> Input Class Initialized
INFO - 2017-02-13 22:56:33 --> Language Class Initialized
INFO - 2017-02-13 22:56:33 --> Loader Class Initialized
INFO - 2017-02-13 22:56:33 --> Database Driver Class Initialized
INFO - 2017-02-13 22:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:56:33 --> Controller Class Initialized
INFO - 2017-02-13 22:56:33 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:56:33 --> Final output sent to browser
DEBUG - 2017-02-13 22:56:33 --> Total execution time: 0.0135
INFO - 2017-02-13 22:56:48 --> Config Class Initialized
INFO - 2017-02-13 22:56:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:56:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:56:48 --> Utf8 Class Initialized
INFO - 2017-02-13 22:56:48 --> URI Class Initialized
INFO - 2017-02-13 22:56:48 --> Router Class Initialized
INFO - 2017-02-13 22:56:48 --> Output Class Initialized
INFO - 2017-02-13 22:56:48 --> Security Class Initialized
DEBUG - 2017-02-13 22:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:56:48 --> Input Class Initialized
INFO - 2017-02-13 22:56:48 --> Language Class Initialized
INFO - 2017-02-13 22:56:48 --> Loader Class Initialized
INFO - 2017-02-13 22:56:48 --> Database Driver Class Initialized
INFO - 2017-02-13 22:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:56:48 --> Controller Class Initialized
INFO - 2017-02-13 22:56:48 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:56:48 --> Final output sent to browser
DEBUG - 2017-02-13 22:56:48 --> Total execution time: 0.0150
INFO - 2017-02-13 22:56:49 --> Config Class Initialized
INFO - 2017-02-13 22:56:49 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:56:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:56:49 --> Utf8 Class Initialized
INFO - 2017-02-13 22:56:49 --> URI Class Initialized
INFO - 2017-02-13 22:56:49 --> Router Class Initialized
INFO - 2017-02-13 22:56:49 --> Output Class Initialized
INFO - 2017-02-13 22:56:49 --> Security Class Initialized
DEBUG - 2017-02-13 22:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:56:49 --> Input Class Initialized
INFO - 2017-02-13 22:56:49 --> Language Class Initialized
INFO - 2017-02-13 22:56:49 --> Loader Class Initialized
INFO - 2017-02-13 22:56:49 --> Database Driver Class Initialized
INFO - 2017-02-13 22:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:56:49 --> Controller Class Initialized
INFO - 2017-02-13 22:56:49 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:56:49 --> Final output sent to browser
DEBUG - 2017-02-13 22:56:49 --> Total execution time: 0.0134
INFO - 2017-02-13 22:57:00 --> Config Class Initialized
INFO - 2017-02-13 22:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:57:00 --> Utf8 Class Initialized
INFO - 2017-02-13 22:57:00 --> URI Class Initialized
INFO - 2017-02-13 22:57:00 --> Router Class Initialized
INFO - 2017-02-13 22:57:00 --> Output Class Initialized
INFO - 2017-02-13 22:57:00 --> Security Class Initialized
DEBUG - 2017-02-13 22:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:57:00 --> Input Class Initialized
INFO - 2017-02-13 22:57:00 --> Language Class Initialized
INFO - 2017-02-13 22:57:00 --> Loader Class Initialized
INFO - 2017-02-13 22:57:00 --> Database Driver Class Initialized
INFO - 2017-02-13 22:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:57:00 --> Controller Class Initialized
INFO - 2017-02-13 22:57:00 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:57:01 --> Config Class Initialized
INFO - 2017-02-13 22:57:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:57:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:57:01 --> Utf8 Class Initialized
INFO - 2017-02-13 22:57:01 --> URI Class Initialized
INFO - 2017-02-13 22:57:01 --> Router Class Initialized
INFO - 2017-02-13 22:57:01 --> Output Class Initialized
INFO - 2017-02-13 22:57:01 --> Security Class Initialized
DEBUG - 2017-02-13 22:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:57:01 --> Input Class Initialized
INFO - 2017-02-13 22:57:01 --> Language Class Initialized
INFO - 2017-02-13 22:57:01 --> Loader Class Initialized
INFO - 2017-02-13 22:57:01 --> Database Driver Class Initialized
INFO - 2017-02-13 22:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:57:01 --> Controller Class Initialized
INFO - 2017-02-13 22:57:01 --> Helper loaded: date_helper
DEBUG - 2017-02-13 22:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:57:01 --> Helper loaded: url_helper
INFO - 2017-02-13 22:57:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:57:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 22:57:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-13 22:57:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 22:57:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:57:01 --> Final output sent to browser
DEBUG - 2017-02-13 22:57:01 --> Total execution time: 0.0146
INFO - 2017-02-13 22:57:03 --> Config Class Initialized
INFO - 2017-02-13 22:57:03 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:57:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:57:03 --> Utf8 Class Initialized
INFO - 2017-02-13 22:57:03 --> URI Class Initialized
INFO - 2017-02-13 22:57:03 --> Router Class Initialized
INFO - 2017-02-13 22:57:03 --> Output Class Initialized
INFO - 2017-02-13 22:57:03 --> Security Class Initialized
DEBUG - 2017-02-13 22:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:57:03 --> Input Class Initialized
INFO - 2017-02-13 22:57:03 --> Language Class Initialized
INFO - 2017-02-13 22:57:03 --> Loader Class Initialized
INFO - 2017-02-13 22:57:03 --> Database Driver Class Initialized
INFO - 2017-02-13 22:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:57:03 --> Controller Class Initialized
INFO - 2017-02-13 22:57:03 --> Helper loaded: date_helper
DEBUG - 2017-02-13 22:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:57:03 --> Helper loaded: url_helper
INFO - 2017-02-13 22:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-13 22:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 22:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-13 22:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-13 22:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:57:03 --> Final output sent to browser
DEBUG - 2017-02-13 22:57:03 --> Total execution time: 0.0137
INFO - 2017-02-13 22:57:04 --> Config Class Initialized
INFO - 2017-02-13 22:57:04 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:57:04 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:57:04 --> Utf8 Class Initialized
INFO - 2017-02-13 22:57:04 --> URI Class Initialized
INFO - 2017-02-13 22:57:04 --> Router Class Initialized
INFO - 2017-02-13 22:57:04 --> Output Class Initialized
INFO - 2017-02-13 22:57:04 --> Security Class Initialized
DEBUG - 2017-02-13 22:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:57:04 --> Input Class Initialized
INFO - 2017-02-13 22:57:04 --> Language Class Initialized
INFO - 2017-02-13 22:57:04 --> Loader Class Initialized
INFO - 2017-02-13 22:57:04 --> Database Driver Class Initialized
INFO - 2017-02-13 22:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:57:04 --> Controller Class Initialized
INFO - 2017-02-13 22:57:04 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:57:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:57:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:57:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:57:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:57:04 --> Final output sent to browser
DEBUG - 2017-02-13 22:57:04 --> Total execution time: 0.0141
INFO - 2017-02-13 22:57:05 --> Config Class Initialized
INFO - 2017-02-13 22:57:05 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:57:05 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:57:05 --> Utf8 Class Initialized
INFO - 2017-02-13 22:57:05 --> URI Class Initialized
INFO - 2017-02-13 22:57:05 --> Router Class Initialized
INFO - 2017-02-13 22:57:05 --> Output Class Initialized
INFO - 2017-02-13 22:57:05 --> Security Class Initialized
DEBUG - 2017-02-13 22:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:57:05 --> Input Class Initialized
INFO - 2017-02-13 22:57:05 --> Language Class Initialized
INFO - 2017-02-13 22:57:05 --> Loader Class Initialized
INFO - 2017-02-13 22:57:05 --> Database Driver Class Initialized
INFO - 2017-02-13 22:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:57:05 --> Controller Class Initialized
INFO - 2017-02-13 22:57:05 --> Helper loaded: date_helper
DEBUG - 2017-02-13 22:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:57:05 --> Helper loaded: url_helper
INFO - 2017-02-13 22:57:05 --> Helper loaded: download_helper
INFO - 2017-02-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:57:05 --> Final output sent to browser
DEBUG - 2017-02-13 22:57:05 --> Total execution time: 0.0193
INFO - 2017-02-13 22:57:08 --> Config Class Initialized
INFO - 2017-02-13 22:57:08 --> Hooks Class Initialized
DEBUG - 2017-02-13 22:57:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 22:57:08 --> Utf8 Class Initialized
INFO - 2017-02-13 22:57:08 --> URI Class Initialized
INFO - 2017-02-13 22:57:08 --> Router Class Initialized
INFO - 2017-02-13 22:57:08 --> Output Class Initialized
INFO - 2017-02-13 22:57:08 --> Security Class Initialized
DEBUG - 2017-02-13 22:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 22:57:08 --> Input Class Initialized
INFO - 2017-02-13 22:57:08 --> Language Class Initialized
INFO - 2017-02-13 22:57:08 --> Loader Class Initialized
INFO - 2017-02-13 22:57:08 --> Database Driver Class Initialized
INFO - 2017-02-13 22:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 22:57:08 --> Controller Class Initialized
INFO - 2017-02-13 22:57:08 --> Helper loaded: url_helper
DEBUG - 2017-02-13 22:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 22:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 22:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 22:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 22:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 22:57:08 --> Final output sent to browser
DEBUG - 2017-02-13 22:57:08 --> Total execution time: 0.0150
INFO - 2017-02-13 23:00:47 --> Config Class Initialized
INFO - 2017-02-13 23:00:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:00:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:00:47 --> Utf8 Class Initialized
INFO - 2017-02-13 23:00:47 --> URI Class Initialized
INFO - 2017-02-13 23:00:47 --> Router Class Initialized
INFO - 2017-02-13 23:00:47 --> Output Class Initialized
INFO - 2017-02-13 23:00:47 --> Security Class Initialized
DEBUG - 2017-02-13 23:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:00:47 --> Input Class Initialized
INFO - 2017-02-13 23:00:47 --> Language Class Initialized
INFO - 2017-02-13 23:00:47 --> Loader Class Initialized
INFO - 2017-02-13 23:00:47 --> Database Driver Class Initialized
INFO - 2017-02-13 23:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:00:47 --> Controller Class Initialized
INFO - 2017-02-13 23:00:47 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:00:47 --> Helper loaded: url_helper
INFO - 2017-02-13 23:00:47 --> Helper loaded: download_helper
INFO - 2017-02-13 23:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 23:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-13 23:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-13 23:00:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:00:47 --> Final output sent to browser
DEBUG - 2017-02-13 23:00:47 --> Total execution time: 0.0194
INFO - 2017-02-13 23:00:48 --> Config Class Initialized
INFO - 2017-02-13 23:00:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:00:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:00:48 --> Utf8 Class Initialized
INFO - 2017-02-13 23:00:48 --> URI Class Initialized
INFO - 2017-02-13 23:00:48 --> Router Class Initialized
INFO - 2017-02-13 23:00:48 --> Output Class Initialized
INFO - 2017-02-13 23:00:48 --> Security Class Initialized
DEBUG - 2017-02-13 23:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:00:48 --> Input Class Initialized
INFO - 2017-02-13 23:00:48 --> Language Class Initialized
INFO - 2017-02-13 23:00:48 --> Loader Class Initialized
INFO - 2017-02-13 23:00:48 --> Database Driver Class Initialized
INFO - 2017-02-13 23:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:00:48 --> Controller Class Initialized
INFO - 2017-02-13 23:00:48 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:00:48 --> Final output sent to browser
DEBUG - 2017-02-13 23:00:48 --> Total execution time: 0.0136
INFO - 2017-02-13 23:00:57 --> Config Class Initialized
INFO - 2017-02-13 23:00:57 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:00:57 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:00:57 --> Utf8 Class Initialized
INFO - 2017-02-13 23:00:57 --> URI Class Initialized
INFO - 2017-02-13 23:00:57 --> Router Class Initialized
INFO - 2017-02-13 23:00:57 --> Output Class Initialized
INFO - 2017-02-13 23:00:57 --> Security Class Initialized
DEBUG - 2017-02-13 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:00:57 --> Input Class Initialized
INFO - 2017-02-13 23:00:57 --> Language Class Initialized
ERROR - 2017-02-13 23:00:57 --> 404 Page Not Found: Templates/usuario
INFO - 2017-02-13 23:08:28 --> Config Class Initialized
INFO - 2017-02-13 23:08:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:08:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:08:28 --> Utf8 Class Initialized
INFO - 2017-02-13 23:08:28 --> URI Class Initialized
INFO - 2017-02-13 23:08:28 --> Router Class Initialized
INFO - 2017-02-13 23:08:28 --> Output Class Initialized
INFO - 2017-02-13 23:08:28 --> Security Class Initialized
DEBUG - 2017-02-13 23:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:08:28 --> Input Class Initialized
INFO - 2017-02-13 23:08:28 --> Language Class Initialized
INFO - 2017-02-13 23:08:28 --> Loader Class Initialized
INFO - 2017-02-13 23:08:28 --> Database Driver Class Initialized
INFO - 2017-02-13 23:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:08:28 --> Controller Class Initialized
INFO - 2017-02-13 23:08:28 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:08:28 --> Helper loaded: url_helper
INFO - 2017-02-13 23:08:28 --> Helper loaded: download_helper
INFO - 2017-02-13 23:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2017-02-13 23:08:28 --> Query error: Unknown column 'tbl_graduacion_productos' in 'where clause' - Invalid query: SELECT `tbl_productos`.`nombre`, `tbl_productos`.`imagen`, `tbl_productos`.`descripcion`, `tbl_categoria`.`nombre` AS `categoria`
FROM `tbl_graduacion_productos`
JOIN `tbl_productos` ON `tbl_productos`.`id_producto` = `tbl_graduacion_productos`.`id_producto`
JOIN `tbl_categoria` ON `tbl_categoria`.`id_categoria` = `tbl_productos`.`id_categoria`
WHERE `tbl_productos`.`id_categoria` = 1 AND `tbl_graduacion_productos` = 31
INFO - 2017-02-13 23:08:28 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-13 23:08:28 --> Config Class Initialized
INFO - 2017-02-13 23:08:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:08:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:08:28 --> Utf8 Class Initialized
INFO - 2017-02-13 23:08:28 --> URI Class Initialized
INFO - 2017-02-13 23:08:28 --> Router Class Initialized
INFO - 2017-02-13 23:08:28 --> Output Class Initialized
INFO - 2017-02-13 23:08:28 --> Security Class Initialized
DEBUG - 2017-02-13 23:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:08:28 --> Input Class Initialized
INFO - 2017-02-13 23:08:28 --> Language Class Initialized
INFO - 2017-02-13 23:08:28 --> Loader Class Initialized
INFO - 2017-02-13 23:08:28 --> Database Driver Class Initialized
INFO - 2017-02-13 23:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:08:28 --> Controller Class Initialized
INFO - 2017-02-13 23:08:28 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:08:28 --> Final output sent to browser
DEBUG - 2017-02-13 23:08:28 --> Total execution time: 0.0143
INFO - 2017-02-13 23:09:06 --> Config Class Initialized
INFO - 2017-02-13 23:09:06 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:09:06 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:09:06 --> Utf8 Class Initialized
INFO - 2017-02-13 23:09:06 --> URI Class Initialized
INFO - 2017-02-13 23:09:06 --> Router Class Initialized
INFO - 2017-02-13 23:09:06 --> Output Class Initialized
INFO - 2017-02-13 23:09:06 --> Security Class Initialized
DEBUG - 2017-02-13 23:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:09:06 --> Input Class Initialized
INFO - 2017-02-13 23:09:06 --> Language Class Initialized
INFO - 2017-02-13 23:09:06 --> Loader Class Initialized
INFO - 2017-02-13 23:09:06 --> Database Driver Class Initialized
INFO - 2017-02-13 23:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:09:06 --> Controller Class Initialized
INFO - 2017-02-13 23:09:06 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:09:06 --> Helper loaded: url_helper
INFO - 2017-02-13 23:09:06 --> Helper loaded: download_helper
INFO - 2017-02-13 23:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 23:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-13 23:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-13 23:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:09:06 --> Final output sent to browser
DEBUG - 2017-02-13 23:09:06 --> Total execution time: 0.0208
INFO - 2017-02-13 23:09:07 --> Config Class Initialized
INFO - 2017-02-13 23:09:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:09:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:09:07 --> Utf8 Class Initialized
INFO - 2017-02-13 23:09:07 --> URI Class Initialized
INFO - 2017-02-13 23:09:07 --> Router Class Initialized
INFO - 2017-02-13 23:09:07 --> Output Class Initialized
INFO - 2017-02-13 23:09:07 --> Security Class Initialized
DEBUG - 2017-02-13 23:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:09:07 --> Input Class Initialized
INFO - 2017-02-13 23:09:07 --> Language Class Initialized
ERROR - 2017-02-13 23:09:07 --> 404 Page Not Found: Templates/usuario
INFO - 2017-02-13 23:09:08 --> Config Class Initialized
INFO - 2017-02-13 23:09:08 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:09:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:09:08 --> Utf8 Class Initialized
INFO - 2017-02-13 23:09:08 --> URI Class Initialized
INFO - 2017-02-13 23:09:08 --> Router Class Initialized
INFO - 2017-02-13 23:09:08 --> Output Class Initialized
INFO - 2017-02-13 23:09:08 --> Security Class Initialized
DEBUG - 2017-02-13 23:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:09:08 --> Input Class Initialized
INFO - 2017-02-13 23:09:08 --> Language Class Initialized
INFO - 2017-02-13 23:09:08 --> Loader Class Initialized
INFO - 2017-02-13 23:09:08 --> Database Driver Class Initialized
INFO - 2017-02-13 23:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:09:08 --> Controller Class Initialized
INFO - 2017-02-13 23:09:08 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:09:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:09:08 --> Final output sent to browser
DEBUG - 2017-02-13 23:09:08 --> Total execution time: 0.0135
INFO - 2017-02-13 23:10:27 --> Config Class Initialized
INFO - 2017-02-13 23:10:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:10:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:10:27 --> Utf8 Class Initialized
INFO - 2017-02-13 23:10:27 --> URI Class Initialized
INFO - 2017-02-13 23:10:27 --> Router Class Initialized
INFO - 2017-02-13 23:10:27 --> Output Class Initialized
INFO - 2017-02-13 23:10:27 --> Security Class Initialized
DEBUG - 2017-02-13 23:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:10:27 --> Input Class Initialized
INFO - 2017-02-13 23:10:27 --> Language Class Initialized
INFO - 2017-02-13 23:10:27 --> Loader Class Initialized
INFO - 2017-02-13 23:10:27 --> Config Class Initialized
INFO - 2017-02-13 23:10:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:10:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:10:27 --> Utf8 Class Initialized
INFO - 2017-02-13 23:10:27 --> URI Class Initialized
INFO - 2017-02-13 23:10:27 --> Router Class Initialized
INFO - 2017-02-13 23:10:27 --> Output Class Initialized
INFO - 2017-02-13 23:10:27 --> Security Class Initialized
DEBUG - 2017-02-13 23:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:10:27 --> Input Class Initialized
INFO - 2017-02-13 23:10:27 --> Language Class Initialized
INFO - 2017-02-13 23:10:27 --> Loader Class Initialized
INFO - 2017-02-13 23:10:27 --> Database Driver Class Initialized
INFO - 2017-02-13 23:10:27 --> Database Driver Class Initialized
INFO - 2017-02-13 23:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:10:27 --> Controller Class Initialized
INFO - 2017-02-13 23:10:27 --> Helper loaded: date_helper
INFO - 2017-02-13 23:10:27 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:10:27 --> Helper loaded: form_helper
INFO - 2017-02-13 23:10:27 --> Form Validation Class Initialized
INFO - 2017-02-13 23:10:27 --> Final output sent to browser
DEBUG - 2017-02-13 23:10:27 --> Total execution time: 0.0281
INFO - 2017-02-13 23:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:10:27 --> Controller Class Initialized
INFO - 2017-02-13 23:10:27 --> Helper loaded: date_helper
INFO - 2017-02-13 23:10:27 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:10:27 --> Helper loaded: form_helper
INFO - 2017-02-13 23:10:27 --> Form Validation Class Initialized
INFO - 2017-02-13 23:10:27 --> Final output sent to browser
DEBUG - 2017-02-13 23:10:27 --> Total execution time: 0.0391
INFO - 2017-02-13 23:10:30 --> Config Class Initialized
INFO - 2017-02-13 23:10:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:10:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:10:30 --> Utf8 Class Initialized
INFO - 2017-02-13 23:10:30 --> URI Class Initialized
INFO - 2017-02-13 23:10:30 --> Router Class Initialized
INFO - 2017-02-13 23:10:30 --> Output Class Initialized
INFO - 2017-02-13 23:10:30 --> Security Class Initialized
DEBUG - 2017-02-13 23:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:10:30 --> Input Class Initialized
INFO - 2017-02-13 23:10:30 --> Language Class Initialized
INFO - 2017-02-13 23:10:30 --> Loader Class Initialized
INFO - 2017-02-13 23:10:30 --> Database Driver Class Initialized
INFO - 2017-02-13 23:10:30 --> Config Class Initialized
INFO - 2017-02-13 23:10:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:10:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:10:30 --> Utf8 Class Initialized
INFO - 2017-02-13 23:10:30 --> URI Class Initialized
INFO - 2017-02-13 23:10:30 --> Router Class Initialized
INFO - 2017-02-13 23:10:30 --> Output Class Initialized
INFO - 2017-02-13 23:10:30 --> Security Class Initialized
DEBUG - 2017-02-13 23:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:10:30 --> Input Class Initialized
INFO - 2017-02-13 23:10:30 --> Language Class Initialized
INFO - 2017-02-13 23:10:30 --> Loader Class Initialized
INFO - 2017-02-13 23:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:10:30 --> Controller Class Initialized
INFO - 2017-02-13 23:10:30 --> Helper loaded: date_helper
INFO - 2017-02-13 23:10:30 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:10:30 --> Database Driver Class Initialized
INFO - 2017-02-13 23:10:30 --> Helper loaded: form_helper
INFO - 2017-02-13 23:10:30 --> Form Validation Class Initialized
INFO - 2017-02-13 23:10:30 --> Final output sent to browser
DEBUG - 2017-02-13 23:10:30 --> Total execution time: 0.0326
INFO - 2017-02-13 23:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:10:30 --> Controller Class Initialized
INFO - 2017-02-13 23:10:30 --> Helper loaded: date_helper
INFO - 2017-02-13 23:10:30 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:10:30 --> Helper loaded: form_helper
INFO - 2017-02-13 23:10:30 --> Form Validation Class Initialized
INFO - 2017-02-13 23:10:30 --> Final output sent to browser
DEBUG - 2017-02-13 23:10:30 --> Total execution time: 0.0824
INFO - 2017-02-13 23:10:34 --> Config Class Initialized
INFO - 2017-02-13 23:10:34 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:10:34 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:10:34 --> Config Class Initialized
INFO - 2017-02-13 23:10:34 --> Utf8 Class Initialized
INFO - 2017-02-13 23:10:34 --> Hooks Class Initialized
INFO - 2017-02-13 23:10:34 --> URI Class Initialized
DEBUG - 2017-02-13 23:10:34 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:10:34 --> Utf8 Class Initialized
INFO - 2017-02-13 23:10:34 --> URI Class Initialized
INFO - 2017-02-13 23:10:34 --> Router Class Initialized
INFO - 2017-02-13 23:10:34 --> Router Class Initialized
INFO - 2017-02-13 23:10:34 --> Output Class Initialized
INFO - 2017-02-13 23:10:34 --> Output Class Initialized
INFO - 2017-02-13 23:10:34 --> Security Class Initialized
DEBUG - 2017-02-13 23:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:10:34 --> Input Class Initialized
INFO - 2017-02-13 23:10:34 --> Security Class Initialized
INFO - 2017-02-13 23:10:34 --> Language Class Initialized
DEBUG - 2017-02-13 23:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:10:34 --> Input Class Initialized
INFO - 2017-02-13 23:10:34 --> Loader Class Initialized
INFO - 2017-02-13 23:10:34 --> Language Class Initialized
INFO - 2017-02-13 23:10:34 --> Loader Class Initialized
INFO - 2017-02-13 23:10:34 --> Database Driver Class Initialized
INFO - 2017-02-13 23:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:10:34 --> Controller Class Initialized
INFO - 2017-02-13 23:10:34 --> Helper loaded: date_helper
INFO - 2017-02-13 23:10:34 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:10:34 --> Database Driver Class Initialized
INFO - 2017-02-13 23:10:34 --> Helper loaded: form_helper
INFO - 2017-02-13 23:10:34 --> Form Validation Class Initialized
INFO - 2017-02-13 23:10:34 --> Final output sent to browser
DEBUG - 2017-02-13 23:10:34 --> Total execution time: 0.0143
INFO - 2017-02-13 23:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:10:34 --> Controller Class Initialized
INFO - 2017-02-13 23:10:34 --> Helper loaded: date_helper
INFO - 2017-02-13 23:10:34 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:10:34 --> Helper loaded: form_helper
INFO - 2017-02-13 23:10:34 --> Form Validation Class Initialized
INFO - 2017-02-13 23:10:34 --> Final output sent to browser
DEBUG - 2017-02-13 23:10:34 --> Total execution time: 0.0226
INFO - 2017-02-13 23:12:07 --> Config Class Initialized
INFO - 2017-02-13 23:12:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:07 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:07 --> URI Class Initialized
INFO - 2017-02-13 23:12:07 --> Router Class Initialized
INFO - 2017-02-13 23:12:07 --> Output Class Initialized
INFO - 2017-02-13 23:12:07 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:07 --> Input Class Initialized
INFO - 2017-02-13 23:12:07 --> Language Class Initialized
INFO - 2017-02-13 23:12:07 --> Loader Class Initialized
INFO - 2017-02-13 23:12:07 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:07 --> Controller Class Initialized
INFO - 2017-02-13 23:12:07 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:07 --> Config Class Initialized
INFO - 2017-02-13 23:12:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:07 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:07 --> URI Class Initialized
INFO - 2017-02-13 23:12:07 --> Router Class Initialized
INFO - 2017-02-13 23:12:07 --> Output Class Initialized
INFO - 2017-02-13 23:12:07 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:07 --> Input Class Initialized
INFO - 2017-02-13 23:12:07 --> Language Class Initialized
INFO - 2017-02-13 23:12:07 --> Loader Class Initialized
INFO - 2017-02-13 23:12:07 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:07 --> Controller Class Initialized
INFO - 2017-02-13 23:12:07 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:07 --> Helper loaded: form_helper
INFO - 2017-02-13 23:12:07 --> Form Validation Class Initialized
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-13 23:12:07 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:07 --> Total execution time: 0.0132
INFO - 2017-02-13 23:12:07 --> Config Class Initialized
INFO - 2017-02-13 23:12:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:07 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:07 --> URI Class Initialized
INFO - 2017-02-13 23:12:07 --> Router Class Initialized
INFO - 2017-02-13 23:12:07 --> Output Class Initialized
INFO - 2017-02-13 23:12:07 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:07 --> Input Class Initialized
INFO - 2017-02-13 23:12:07 --> Language Class Initialized
INFO - 2017-02-13 23:12:07 --> Loader Class Initialized
INFO - 2017-02-13 23:12:07 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:07 --> Controller Class Initialized
INFO - 2017-02-13 23:12:07 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:07 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:07 --> Total execution time: 0.0423
INFO - 2017-02-13 23:12:07 --> Config Class Initialized
INFO - 2017-02-13 23:12:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:07 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:07 --> URI Class Initialized
INFO - 2017-02-13 23:12:07 --> Router Class Initialized
INFO - 2017-02-13 23:12:07 --> Output Class Initialized
INFO - 2017-02-13 23:12:07 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:07 --> Input Class Initialized
INFO - 2017-02-13 23:12:07 --> Language Class Initialized
INFO - 2017-02-13 23:12:07 --> Loader Class Initialized
INFO - 2017-02-13 23:12:07 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:07 --> Controller Class Initialized
INFO - 2017-02-13 23:12:07 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:07 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:07 --> Total execution time: 0.0137
INFO - 2017-02-13 23:12:12 --> Config Class Initialized
INFO - 2017-02-13 23:12:12 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:12 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:12 --> URI Class Initialized
INFO - 2017-02-13 23:12:12 --> Router Class Initialized
INFO - 2017-02-13 23:12:12 --> Output Class Initialized
INFO - 2017-02-13 23:12:12 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:12 --> Input Class Initialized
INFO - 2017-02-13 23:12:12 --> Language Class Initialized
INFO - 2017-02-13 23:12:12 --> Loader Class Initialized
INFO - 2017-02-13 23:12:12 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:12 --> Controller Class Initialized
INFO - 2017-02-13 23:12:12 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:12 --> Config Class Initialized
INFO - 2017-02-13 23:12:12 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:12 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:12 --> URI Class Initialized
DEBUG - 2017-02-13 23:12:12 --> No URI present. Default controller set.
INFO - 2017-02-13 23:12:12 --> Router Class Initialized
INFO - 2017-02-13 23:12:12 --> Output Class Initialized
INFO - 2017-02-13 23:12:12 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:12 --> Input Class Initialized
INFO - 2017-02-13 23:12:12 --> Language Class Initialized
INFO - 2017-02-13 23:12:12 --> Loader Class Initialized
INFO - 2017-02-13 23:12:12 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:12 --> Controller Class Initialized
INFO - 2017-02-13 23:12:12 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:12 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:12 --> Total execution time: 0.0134
INFO - 2017-02-13 23:12:12 --> Config Class Initialized
INFO - 2017-02-13 23:12:12 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:12 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:12 --> URI Class Initialized
INFO - 2017-02-13 23:12:12 --> Router Class Initialized
INFO - 2017-02-13 23:12:12 --> Output Class Initialized
INFO - 2017-02-13 23:12:12 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:12 --> Input Class Initialized
INFO - 2017-02-13 23:12:12 --> Language Class Initialized
INFO - 2017-02-13 23:12:12 --> Loader Class Initialized
INFO - 2017-02-13 23:12:12 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:12 --> Controller Class Initialized
INFO - 2017-02-13 23:12:12 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:12 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:12 --> Total execution time: 0.0136
INFO - 2017-02-13 23:12:13 --> Config Class Initialized
INFO - 2017-02-13 23:12:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:13 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:13 --> URI Class Initialized
INFO - 2017-02-13 23:12:13 --> Router Class Initialized
INFO - 2017-02-13 23:12:13 --> Output Class Initialized
INFO - 2017-02-13 23:12:13 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:13 --> Input Class Initialized
INFO - 2017-02-13 23:12:13 --> Language Class Initialized
INFO - 2017-02-13 23:12:13 --> Loader Class Initialized
INFO - 2017-02-13 23:12:13 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:13 --> Controller Class Initialized
INFO - 2017-02-13 23:12:13 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:13 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:13 --> Total execution time: 0.0144
INFO - 2017-02-13 23:12:42 --> Config Class Initialized
INFO - 2017-02-13 23:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:42 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:42 --> URI Class Initialized
INFO - 2017-02-13 23:12:42 --> Router Class Initialized
INFO - 2017-02-13 23:12:42 --> Output Class Initialized
INFO - 2017-02-13 23:12:42 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:42 --> Input Class Initialized
INFO - 2017-02-13 23:12:42 --> Language Class Initialized
INFO - 2017-02-13 23:12:42 --> Loader Class Initialized
INFO - 2017-02-13 23:12:42 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:42 --> Controller Class Initialized
INFO - 2017-02-13 23:12:42 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:42 --> Config Class Initialized
INFO - 2017-02-13 23:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:42 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:42 --> URI Class Initialized
INFO - 2017-02-13 23:12:42 --> Router Class Initialized
INFO - 2017-02-13 23:12:42 --> Output Class Initialized
INFO - 2017-02-13 23:12:42 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:42 --> Input Class Initialized
INFO - 2017-02-13 23:12:42 --> Language Class Initialized
INFO - 2017-02-13 23:12:42 --> Loader Class Initialized
INFO - 2017-02-13 23:12:42 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:42 --> Controller Class Initialized
INFO - 2017-02-13 23:12:42 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:42 --> Helper loaded: url_helper
INFO - 2017-02-13 23:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 23:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-13 23:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 23:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:42 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:42 --> Total execution time: 0.0148
INFO - 2017-02-13 23:12:43 --> Config Class Initialized
INFO - 2017-02-13 23:12:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:43 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:43 --> URI Class Initialized
INFO - 2017-02-13 23:12:43 --> Router Class Initialized
INFO - 2017-02-13 23:12:43 --> Output Class Initialized
INFO - 2017-02-13 23:12:43 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:43 --> Input Class Initialized
INFO - 2017-02-13 23:12:43 --> Language Class Initialized
INFO - 2017-02-13 23:12:43 --> Loader Class Initialized
INFO - 2017-02-13 23:12:43 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:43 --> Controller Class Initialized
INFO - 2017-02-13 23:12:43 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:43 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:43 --> Total execution time: 0.0141
INFO - 2017-02-13 23:12:54 --> Config Class Initialized
INFO - 2017-02-13 23:12:54 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:54 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:54 --> URI Class Initialized
INFO - 2017-02-13 23:12:54 --> Router Class Initialized
INFO - 2017-02-13 23:12:54 --> Output Class Initialized
INFO - 2017-02-13 23:12:54 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:54 --> Input Class Initialized
INFO - 2017-02-13 23:12:54 --> Language Class Initialized
INFO - 2017-02-13 23:12:54 --> Loader Class Initialized
INFO - 2017-02-13 23:12:54 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:54 --> Controller Class Initialized
INFO - 2017-02-13 23:12:54 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:54 --> Helper loaded: url_helper
INFO - 2017-02-13 23:12:54 --> Helper loaded: download_helper
INFO - 2017-02-13 23:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-13 23:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-13 23:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-13 23:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:54 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:54 --> Total execution time: 0.0208
INFO - 2017-02-13 23:12:55 --> Config Class Initialized
INFO - 2017-02-13 23:12:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:12:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:12:55 --> Utf8 Class Initialized
INFO - 2017-02-13 23:12:55 --> URI Class Initialized
INFO - 2017-02-13 23:12:55 --> Router Class Initialized
INFO - 2017-02-13 23:12:55 --> Output Class Initialized
INFO - 2017-02-13 23:12:55 --> Security Class Initialized
DEBUG - 2017-02-13 23:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:12:55 --> Input Class Initialized
INFO - 2017-02-13 23:12:55 --> Language Class Initialized
INFO - 2017-02-13 23:12:55 --> Loader Class Initialized
INFO - 2017-02-13 23:12:55 --> Database Driver Class Initialized
INFO - 2017-02-13 23:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:12:55 --> Controller Class Initialized
INFO - 2017-02-13 23:12:55 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:12:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:12:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:12:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:12:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:12:55 --> Final output sent to browser
DEBUG - 2017-02-13 23:12:55 --> Total execution time: 0.0143
INFO - 2017-02-13 23:36:27 --> Config Class Initialized
INFO - 2017-02-13 23:36:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:36:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:36:27 --> Utf8 Class Initialized
INFO - 2017-02-13 23:36:27 --> URI Class Initialized
DEBUG - 2017-02-13 23:36:27 --> No URI present. Default controller set.
INFO - 2017-02-13 23:36:27 --> Router Class Initialized
INFO - 2017-02-13 23:36:27 --> Output Class Initialized
INFO - 2017-02-13 23:36:27 --> Security Class Initialized
DEBUG - 2017-02-13 23:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:36:27 --> Input Class Initialized
INFO - 2017-02-13 23:36:27 --> Language Class Initialized
INFO - 2017-02-13 23:36:27 --> Loader Class Initialized
INFO - 2017-02-13 23:36:27 --> Database Driver Class Initialized
INFO - 2017-02-13 23:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:36:27 --> Controller Class Initialized
INFO - 2017-02-13 23:36:27 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:36:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:36:27 --> Final output sent to browser
DEBUG - 2017-02-13 23:36:27 --> Total execution time: 0.0134
INFO - 2017-02-13 23:36:43 --> Config Class Initialized
INFO - 2017-02-13 23:36:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:36:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:36:43 --> Utf8 Class Initialized
INFO - 2017-02-13 23:36:43 --> URI Class Initialized
INFO - 2017-02-13 23:36:43 --> Router Class Initialized
INFO - 2017-02-13 23:36:43 --> Output Class Initialized
INFO - 2017-02-13 23:36:43 --> Security Class Initialized
DEBUG - 2017-02-13 23:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:36:43 --> Input Class Initialized
INFO - 2017-02-13 23:36:43 --> Language Class Initialized
INFO - 2017-02-13 23:36:43 --> Loader Class Initialized
INFO - 2017-02-13 23:36:43 --> Database Driver Class Initialized
INFO - 2017-02-13 23:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:36:43 --> Controller Class Initialized
INFO - 2017-02-13 23:36:43 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:36:43 --> Final output sent to browser
DEBUG - 2017-02-13 23:36:43 --> Total execution time: 0.0159
INFO - 2017-02-13 23:36:59 --> Config Class Initialized
INFO - 2017-02-13 23:36:59 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:36:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:36:59 --> Utf8 Class Initialized
INFO - 2017-02-13 23:36:59 --> URI Class Initialized
INFO - 2017-02-13 23:36:59 --> Router Class Initialized
INFO - 2017-02-13 23:36:59 --> Output Class Initialized
INFO - 2017-02-13 23:36:59 --> Security Class Initialized
DEBUG - 2017-02-13 23:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:36:59 --> Input Class Initialized
INFO - 2017-02-13 23:36:59 --> Language Class Initialized
INFO - 2017-02-13 23:36:59 --> Loader Class Initialized
INFO - 2017-02-13 23:36:59 --> Database Driver Class Initialized
INFO - 2017-02-13 23:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:36:59 --> Controller Class Initialized
INFO - 2017-02-13 23:36:59 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:36:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-13 23:37:00 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-13 23:37:00 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Berenice Marquez Acuña')
INFO - 2017-02-13 23:37:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-13 23:37:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-13 23:37:01 --> Config Class Initialized
INFO - 2017-02-13 23:37:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:37:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:37:01 --> Utf8 Class Initialized
INFO - 2017-02-13 23:37:01 --> URI Class Initialized
INFO - 2017-02-13 23:37:01 --> Router Class Initialized
INFO - 2017-02-13 23:37:01 --> Output Class Initialized
INFO - 2017-02-13 23:37:01 --> Security Class Initialized
DEBUG - 2017-02-13 23:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:37:01 --> Input Class Initialized
INFO - 2017-02-13 23:37:01 --> Language Class Initialized
INFO - 2017-02-13 23:37:01 --> Loader Class Initialized
INFO - 2017-02-13 23:37:01 --> Database Driver Class Initialized
INFO - 2017-02-13 23:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:37:01 --> Controller Class Initialized
INFO - 2017-02-13 23:37:01 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:37:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:37:01 --> Final output sent to browser
DEBUG - 2017-02-13 23:37:01 --> Total execution time: 0.0143
INFO - 2017-02-13 23:37:27 --> Config Class Initialized
INFO - 2017-02-13 23:37:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:37:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:37:27 --> Utf8 Class Initialized
INFO - 2017-02-13 23:37:27 --> URI Class Initialized
INFO - 2017-02-13 23:37:27 --> Router Class Initialized
INFO - 2017-02-13 23:37:27 --> Output Class Initialized
INFO - 2017-02-13 23:37:27 --> Security Class Initialized
DEBUG - 2017-02-13 23:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:37:27 --> Input Class Initialized
INFO - 2017-02-13 23:37:27 --> Language Class Initialized
INFO - 2017-02-13 23:37:27 --> Loader Class Initialized
INFO - 2017-02-13 23:37:27 --> Database Driver Class Initialized
INFO - 2017-02-13 23:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:37:27 --> Controller Class Initialized
INFO - 2017-02-13 23:37:27 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:37:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-13 23:37:27 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-13 23:37:27 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Berenice Marquez Acuña')
INFO - 2017-02-13 23:37:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-13 23:37:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-13 23:37:28 --> Config Class Initialized
INFO - 2017-02-13 23:37:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:37:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:37:28 --> Utf8 Class Initialized
INFO - 2017-02-13 23:37:28 --> URI Class Initialized
INFO - 2017-02-13 23:37:28 --> Router Class Initialized
INFO - 2017-02-13 23:37:28 --> Output Class Initialized
INFO - 2017-02-13 23:37:28 --> Security Class Initialized
DEBUG - 2017-02-13 23:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:37:28 --> Input Class Initialized
INFO - 2017-02-13 23:37:28 --> Language Class Initialized
INFO - 2017-02-13 23:37:28 --> Loader Class Initialized
INFO - 2017-02-13 23:37:28 --> Database Driver Class Initialized
INFO - 2017-02-13 23:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:37:28 --> Controller Class Initialized
INFO - 2017-02-13 23:37:28 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:37:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:37:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:37:28 --> Final output sent to browser
DEBUG - 2017-02-13 23:37:28 --> Total execution time: 0.0140
INFO - 2017-02-13 23:37:31 --> Config Class Initialized
INFO - 2017-02-13 23:37:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:37:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:37:31 --> Utf8 Class Initialized
INFO - 2017-02-13 23:37:31 --> URI Class Initialized
DEBUG - 2017-02-13 23:37:31 --> No URI present. Default controller set.
INFO - 2017-02-13 23:37:31 --> Router Class Initialized
INFO - 2017-02-13 23:37:31 --> Output Class Initialized
INFO - 2017-02-13 23:37:31 --> Security Class Initialized
DEBUG - 2017-02-13 23:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:37:31 --> Input Class Initialized
INFO - 2017-02-13 23:37:31 --> Language Class Initialized
INFO - 2017-02-13 23:37:31 --> Loader Class Initialized
INFO - 2017-02-13 23:37:31 --> Database Driver Class Initialized
INFO - 2017-02-13 23:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:37:31 --> Controller Class Initialized
INFO - 2017-02-13 23:37:31 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:37:31 --> Final output sent to browser
DEBUG - 2017-02-13 23:37:31 --> Total execution time: 0.0132
INFO - 2017-02-13 23:37:33 --> Config Class Initialized
INFO - 2017-02-13 23:37:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:37:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:37:33 --> Utf8 Class Initialized
INFO - 2017-02-13 23:37:33 --> URI Class Initialized
INFO - 2017-02-13 23:37:33 --> Router Class Initialized
INFO - 2017-02-13 23:37:33 --> Output Class Initialized
INFO - 2017-02-13 23:37:33 --> Security Class Initialized
DEBUG - 2017-02-13 23:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:37:33 --> Input Class Initialized
INFO - 2017-02-13 23:37:33 --> Language Class Initialized
INFO - 2017-02-13 23:37:33 --> Loader Class Initialized
INFO - 2017-02-13 23:37:33 --> Database Driver Class Initialized
INFO - 2017-02-13 23:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:37:33 --> Controller Class Initialized
INFO - 2017-02-13 23:37:33 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:37:33 --> Final output sent to browser
DEBUG - 2017-02-13 23:37:33 --> Total execution time: 0.0134
INFO - 2017-02-13 23:39:31 --> Config Class Initialized
INFO - 2017-02-13 23:39:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:39:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:39:31 --> Utf8 Class Initialized
INFO - 2017-02-13 23:39:31 --> URI Class Initialized
INFO - 2017-02-13 23:39:31 --> Router Class Initialized
INFO - 2017-02-13 23:39:31 --> Output Class Initialized
INFO - 2017-02-13 23:39:31 --> Security Class Initialized
DEBUG - 2017-02-13 23:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:39:31 --> Input Class Initialized
INFO - 2017-02-13 23:39:31 --> Language Class Initialized
INFO - 2017-02-13 23:39:31 --> Loader Class Initialized
INFO - 2017-02-13 23:39:31 --> Database Driver Class Initialized
INFO - 2017-02-13 23:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:39:31 --> Controller Class Initialized
INFO - 2017-02-13 23:39:31 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:39:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:39:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:39:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:39:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:39:31 --> Final output sent to browser
DEBUG - 2017-02-13 23:39:31 --> Total execution time: 0.0462
INFO - 2017-02-13 23:39:33 --> Config Class Initialized
INFO - 2017-02-13 23:39:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:39:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:39:33 --> Utf8 Class Initialized
INFO - 2017-02-13 23:39:33 --> URI Class Initialized
INFO - 2017-02-13 23:39:33 --> Router Class Initialized
INFO - 2017-02-13 23:39:33 --> Output Class Initialized
INFO - 2017-02-13 23:39:33 --> Security Class Initialized
DEBUG - 2017-02-13 23:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:39:33 --> Input Class Initialized
INFO - 2017-02-13 23:39:33 --> Language Class Initialized
INFO - 2017-02-13 23:39:33 --> Loader Class Initialized
INFO - 2017-02-13 23:39:33 --> Database Driver Class Initialized
INFO - 2017-02-13 23:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:39:33 --> Controller Class Initialized
INFO - 2017-02-13 23:39:33 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:39:33 --> Final output sent to browser
DEBUG - 2017-02-13 23:39:33 --> Total execution time: 0.0151
INFO - 2017-02-13 23:39:54 --> Config Class Initialized
INFO - 2017-02-13 23:39:54 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:39:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:39:54 --> Utf8 Class Initialized
INFO - 2017-02-13 23:39:54 --> URI Class Initialized
INFO - 2017-02-13 23:39:54 --> Router Class Initialized
INFO - 2017-02-13 23:39:54 --> Output Class Initialized
INFO - 2017-02-13 23:39:54 --> Security Class Initialized
DEBUG - 2017-02-13 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:39:54 --> Input Class Initialized
INFO - 2017-02-13 23:39:54 --> Language Class Initialized
INFO - 2017-02-13 23:39:54 --> Loader Class Initialized
INFO - 2017-02-13 23:39:54 --> Database Driver Class Initialized
INFO - 2017-02-13 23:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:39:54 --> Controller Class Initialized
INFO - 2017-02-13 23:39:54 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:39:54 --> Final output sent to browser
DEBUG - 2017-02-13 23:39:54 --> Total execution time: 0.0155
INFO - 2017-02-13 23:39:55 --> Config Class Initialized
INFO - 2017-02-13 23:39:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:39:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:39:55 --> Utf8 Class Initialized
INFO - 2017-02-13 23:39:55 --> URI Class Initialized
INFO - 2017-02-13 23:39:55 --> Router Class Initialized
INFO - 2017-02-13 23:39:55 --> Output Class Initialized
INFO - 2017-02-13 23:39:55 --> Security Class Initialized
DEBUG - 2017-02-13 23:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:39:55 --> Input Class Initialized
INFO - 2017-02-13 23:39:55 --> Language Class Initialized
INFO - 2017-02-13 23:39:55 --> Loader Class Initialized
INFO - 2017-02-13 23:39:55 --> Database Driver Class Initialized
INFO - 2017-02-13 23:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:39:55 --> Controller Class Initialized
INFO - 2017-02-13 23:39:55 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:39:55 --> Final output sent to browser
DEBUG - 2017-02-13 23:39:55 --> Total execution time: 0.0137
INFO - 2017-02-13 23:41:11 --> Config Class Initialized
INFO - 2017-02-13 23:41:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:11 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:11 --> URI Class Initialized
INFO - 2017-02-13 23:41:11 --> Router Class Initialized
INFO - 2017-02-13 23:41:11 --> Output Class Initialized
INFO - 2017-02-13 23:41:11 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:11 --> Input Class Initialized
INFO - 2017-02-13 23:41:11 --> Language Class Initialized
INFO - 2017-02-13 23:41:11 --> Loader Class Initialized
INFO - 2017-02-13 23:41:11 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:11 --> Controller Class Initialized
INFO - 2017-02-13 23:41:11 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-13 23:41:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-13 23:41:13 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Berenice Marquez Acuña')
INFO - 2017-02-13 23:41:13 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-13 23:41:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-13 23:41:13 --> Config Class Initialized
INFO - 2017-02-13 23:41:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:13 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:13 --> URI Class Initialized
INFO - 2017-02-13 23:41:13 --> Router Class Initialized
INFO - 2017-02-13 23:41:13 --> Output Class Initialized
INFO - 2017-02-13 23:41:13 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:13 --> Input Class Initialized
INFO - 2017-02-13 23:41:13 --> Language Class Initialized
INFO - 2017-02-13 23:41:13 --> Loader Class Initialized
INFO - 2017-02-13 23:41:13 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:13 --> Controller Class Initialized
INFO - 2017-02-13 23:41:13 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:41:13 --> Final output sent to browser
DEBUG - 2017-02-13 23:41:13 --> Total execution time: 0.0162
INFO - 2017-02-13 23:41:20 --> Config Class Initialized
INFO - 2017-02-13 23:41:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:20 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:20 --> URI Class Initialized
DEBUG - 2017-02-13 23:41:20 --> No URI present. Default controller set.
INFO - 2017-02-13 23:41:20 --> Router Class Initialized
INFO - 2017-02-13 23:41:20 --> Output Class Initialized
INFO - 2017-02-13 23:41:20 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:20 --> Input Class Initialized
INFO - 2017-02-13 23:41:20 --> Language Class Initialized
INFO - 2017-02-13 23:41:20 --> Loader Class Initialized
INFO - 2017-02-13 23:41:20 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:20 --> Controller Class Initialized
INFO - 2017-02-13 23:41:20 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:41:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:41:20 --> Final output sent to browser
DEBUG - 2017-02-13 23:41:20 --> Total execution time: 0.0134
INFO - 2017-02-13 23:41:22 --> Config Class Initialized
INFO - 2017-02-13 23:41:22 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:22 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:22 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:22 --> URI Class Initialized
INFO - 2017-02-13 23:41:22 --> Router Class Initialized
INFO - 2017-02-13 23:41:22 --> Output Class Initialized
INFO - 2017-02-13 23:41:22 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:22 --> Input Class Initialized
INFO - 2017-02-13 23:41:22 --> Language Class Initialized
INFO - 2017-02-13 23:41:22 --> Loader Class Initialized
INFO - 2017-02-13 23:41:22 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:22 --> Controller Class Initialized
INFO - 2017-02-13 23:41:22 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:41:22 --> Final output sent to browser
DEBUG - 2017-02-13 23:41:22 --> Total execution time: 0.0174
INFO - 2017-02-13 23:41:32 --> Config Class Initialized
INFO - 2017-02-13 23:41:32 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:32 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:32 --> URI Class Initialized
INFO - 2017-02-13 23:41:32 --> Router Class Initialized
INFO - 2017-02-13 23:41:32 --> Output Class Initialized
INFO - 2017-02-13 23:41:32 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:32 --> Input Class Initialized
INFO - 2017-02-13 23:41:32 --> Language Class Initialized
INFO - 2017-02-13 23:41:32 --> Loader Class Initialized
INFO - 2017-02-13 23:41:32 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:32 --> Controller Class Initialized
INFO - 2017-02-13 23:41:32 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:41:32 --> Final output sent to browser
DEBUG - 2017-02-13 23:41:32 --> Total execution time: 0.0217
INFO - 2017-02-13 23:41:34 --> Config Class Initialized
INFO - 2017-02-13 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:34 --> URI Class Initialized
INFO - 2017-02-13 23:41:34 --> Router Class Initialized
INFO - 2017-02-13 23:41:34 --> Output Class Initialized
INFO - 2017-02-13 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:34 --> Input Class Initialized
INFO - 2017-02-13 23:41:34 --> Language Class Initialized
INFO - 2017-02-13 23:41:34 --> Loader Class Initialized
INFO - 2017-02-13 23:41:34 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:34 --> Controller Class Initialized
INFO - 2017-02-13 23:41:34 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:41:34 --> Final output sent to browser
DEBUG - 2017-02-13 23:41:34 --> Total execution time: 0.0131
INFO - 2017-02-13 23:41:52 --> Config Class Initialized
INFO - 2017-02-13 23:41:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:52 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:52 --> URI Class Initialized
INFO - 2017-02-13 23:41:52 --> Router Class Initialized
INFO - 2017-02-13 23:41:52 --> Output Class Initialized
INFO - 2017-02-13 23:41:52 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:52 --> Input Class Initialized
INFO - 2017-02-13 23:41:52 --> Language Class Initialized
INFO - 2017-02-13 23:41:52 --> Loader Class Initialized
INFO - 2017-02-13 23:41:52 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:52 --> Controller Class Initialized
INFO - 2017-02-13 23:41:52 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:41:52 --> Final output sent to browser
DEBUG - 2017-02-13 23:41:52 --> Total execution time: 0.0155
INFO - 2017-02-13 23:41:53 --> Config Class Initialized
INFO - 2017-02-13 23:41:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:41:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:41:53 --> Utf8 Class Initialized
INFO - 2017-02-13 23:41:53 --> URI Class Initialized
INFO - 2017-02-13 23:41:53 --> Router Class Initialized
INFO - 2017-02-13 23:41:53 --> Output Class Initialized
INFO - 2017-02-13 23:41:53 --> Security Class Initialized
DEBUG - 2017-02-13 23:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:41:53 --> Input Class Initialized
INFO - 2017-02-13 23:41:53 --> Language Class Initialized
INFO - 2017-02-13 23:41:53 --> Loader Class Initialized
INFO - 2017-02-13 23:41:53 --> Database Driver Class Initialized
INFO - 2017-02-13 23:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:41:53 --> Controller Class Initialized
INFO - 2017-02-13 23:41:53 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:41:53 --> Final output sent to browser
DEBUG - 2017-02-13 23:41:53 --> Total execution time: 0.0157
INFO - 2017-02-13 23:42:34 --> Config Class Initialized
INFO - 2017-02-13 23:42:34 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:42:34 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:42:34 --> Utf8 Class Initialized
INFO - 2017-02-13 23:42:34 --> URI Class Initialized
INFO - 2017-02-13 23:42:34 --> Router Class Initialized
INFO - 2017-02-13 23:42:34 --> Output Class Initialized
INFO - 2017-02-13 23:42:34 --> Security Class Initialized
DEBUG - 2017-02-13 23:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:42:34 --> Input Class Initialized
INFO - 2017-02-13 23:42:34 --> Language Class Initialized
INFO - 2017-02-13 23:42:34 --> Loader Class Initialized
INFO - 2017-02-13 23:42:34 --> Database Driver Class Initialized
INFO - 2017-02-13 23:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:42:34 --> Controller Class Initialized
INFO - 2017-02-13 23:42:34 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:42:34 --> Final output sent to browser
DEBUG - 2017-02-13 23:42:34 --> Total execution time: 0.0141
INFO - 2017-02-13 23:42:35 --> Config Class Initialized
INFO - 2017-02-13 23:42:35 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:42:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:42:35 --> Utf8 Class Initialized
INFO - 2017-02-13 23:42:35 --> URI Class Initialized
INFO - 2017-02-13 23:42:35 --> Router Class Initialized
INFO - 2017-02-13 23:42:35 --> Output Class Initialized
INFO - 2017-02-13 23:42:35 --> Security Class Initialized
DEBUG - 2017-02-13 23:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:42:35 --> Input Class Initialized
INFO - 2017-02-13 23:42:35 --> Language Class Initialized
INFO - 2017-02-13 23:42:35 --> Loader Class Initialized
INFO - 2017-02-13 23:42:35 --> Database Driver Class Initialized
INFO - 2017-02-13 23:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:42:35 --> Controller Class Initialized
INFO - 2017-02-13 23:42:35 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:42:36 --> Final output sent to browser
DEBUG - 2017-02-13 23:42:36 --> Total execution time: 0.0133
INFO - 2017-02-13 23:43:54 --> Config Class Initialized
INFO - 2017-02-13 23:43:54 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:43:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:43:54 --> Utf8 Class Initialized
INFO - 2017-02-13 23:43:54 --> URI Class Initialized
INFO - 2017-02-13 23:43:54 --> Router Class Initialized
INFO - 2017-02-13 23:43:54 --> Output Class Initialized
INFO - 2017-02-13 23:43:54 --> Security Class Initialized
DEBUG - 2017-02-13 23:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:43:54 --> Input Class Initialized
INFO - 2017-02-13 23:43:54 --> Language Class Initialized
INFO - 2017-02-13 23:43:54 --> Loader Class Initialized
INFO - 2017-02-13 23:43:54 --> Database Driver Class Initialized
INFO - 2017-02-13 23:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:43:54 --> Controller Class Initialized
INFO - 2017-02-13 23:43:54 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:43:54 --> Final output sent to browser
DEBUG - 2017-02-13 23:43:54 --> Total execution time: 0.0141
INFO - 2017-02-13 23:43:55 --> Config Class Initialized
INFO - 2017-02-13 23:43:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:43:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:43:55 --> Utf8 Class Initialized
INFO - 2017-02-13 23:43:55 --> URI Class Initialized
INFO - 2017-02-13 23:43:55 --> Router Class Initialized
INFO - 2017-02-13 23:43:55 --> Output Class Initialized
INFO - 2017-02-13 23:43:55 --> Security Class Initialized
DEBUG - 2017-02-13 23:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:43:55 --> Input Class Initialized
INFO - 2017-02-13 23:43:55 --> Language Class Initialized
INFO - 2017-02-13 23:43:55 --> Loader Class Initialized
INFO - 2017-02-13 23:43:55 --> Database Driver Class Initialized
INFO - 2017-02-13 23:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:43:55 --> Controller Class Initialized
INFO - 2017-02-13 23:43:55 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:43:55 --> Final output sent to browser
DEBUG - 2017-02-13 23:43:55 --> Total execution time: 0.0147
INFO - 2017-02-13 23:44:00 --> Config Class Initialized
INFO - 2017-02-13 23:44:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:44:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:44:00 --> Utf8 Class Initialized
INFO - 2017-02-13 23:44:00 --> URI Class Initialized
INFO - 2017-02-13 23:44:00 --> Router Class Initialized
INFO - 2017-02-13 23:44:00 --> Output Class Initialized
INFO - 2017-02-13 23:44:00 --> Security Class Initialized
DEBUG - 2017-02-13 23:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:44:00 --> Input Class Initialized
INFO - 2017-02-13 23:44:00 --> Language Class Initialized
INFO - 2017-02-13 23:44:00 --> Loader Class Initialized
INFO - 2017-02-13 23:44:00 --> Database Driver Class Initialized
INFO - 2017-02-13 23:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:44:00 --> Controller Class Initialized
INFO - 2017-02-13 23:44:00 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:44:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-13 23:44:00 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-13 23:44:00 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Berenice Marquez Acuña')
INFO - 2017-02-13 23:44:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-13 23:44:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-13 23:44:00 --> Config Class Initialized
INFO - 2017-02-13 23:44:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:44:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:44:00 --> Utf8 Class Initialized
INFO - 2017-02-13 23:44:00 --> URI Class Initialized
INFO - 2017-02-13 23:44:00 --> Router Class Initialized
INFO - 2017-02-13 23:44:00 --> Output Class Initialized
INFO - 2017-02-13 23:44:00 --> Security Class Initialized
DEBUG - 2017-02-13 23:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:44:00 --> Input Class Initialized
INFO - 2017-02-13 23:44:00 --> Language Class Initialized
INFO - 2017-02-13 23:44:00 --> Loader Class Initialized
INFO - 2017-02-13 23:44:00 --> Database Driver Class Initialized
INFO - 2017-02-13 23:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:44:00 --> Controller Class Initialized
INFO - 2017-02-13 23:44:00 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:44:00 --> Final output sent to browser
DEBUG - 2017-02-13 23:44:00 --> Total execution time: 0.0138
INFO - 2017-02-13 23:44:30 --> Config Class Initialized
INFO - 2017-02-13 23:44:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:44:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:44:30 --> Utf8 Class Initialized
INFO - 2017-02-13 23:44:30 --> URI Class Initialized
DEBUG - 2017-02-13 23:44:30 --> No URI present. Default controller set.
INFO - 2017-02-13 23:44:30 --> Router Class Initialized
INFO - 2017-02-13 23:44:30 --> Output Class Initialized
INFO - 2017-02-13 23:44:30 --> Security Class Initialized
DEBUG - 2017-02-13 23:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:44:30 --> Input Class Initialized
INFO - 2017-02-13 23:44:30 --> Language Class Initialized
INFO - 2017-02-13 23:44:30 --> Loader Class Initialized
INFO - 2017-02-13 23:44:30 --> Database Driver Class Initialized
INFO - 2017-02-13 23:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:44:30 --> Controller Class Initialized
INFO - 2017-02-13 23:44:30 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:44:30 --> Final output sent to browser
DEBUG - 2017-02-13 23:44:30 --> Total execution time: 0.0188
INFO - 2017-02-13 23:44:33 --> Config Class Initialized
INFO - 2017-02-13 23:44:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:44:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:44:33 --> Utf8 Class Initialized
INFO - 2017-02-13 23:44:33 --> URI Class Initialized
INFO - 2017-02-13 23:44:33 --> Router Class Initialized
INFO - 2017-02-13 23:44:33 --> Output Class Initialized
INFO - 2017-02-13 23:44:33 --> Security Class Initialized
DEBUG - 2017-02-13 23:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:44:33 --> Input Class Initialized
INFO - 2017-02-13 23:44:33 --> Language Class Initialized
INFO - 2017-02-13 23:44:33 --> Loader Class Initialized
INFO - 2017-02-13 23:44:33 --> Database Driver Class Initialized
INFO - 2017-02-13 23:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:44:33 --> Controller Class Initialized
INFO - 2017-02-13 23:44:33 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:44:33 --> Final output sent to browser
DEBUG - 2017-02-13 23:44:33 --> Total execution time: 0.0133
INFO - 2017-02-13 23:45:00 --> Config Class Initialized
INFO - 2017-02-13 23:45:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:45:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:45:00 --> Utf8 Class Initialized
INFO - 2017-02-13 23:45:00 --> URI Class Initialized
INFO - 2017-02-13 23:45:00 --> Router Class Initialized
INFO - 2017-02-13 23:45:00 --> Output Class Initialized
INFO - 2017-02-13 23:45:00 --> Security Class Initialized
DEBUG - 2017-02-13 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:45:00 --> Input Class Initialized
INFO - 2017-02-13 23:45:00 --> Language Class Initialized
INFO - 2017-02-13 23:45:00 --> Loader Class Initialized
INFO - 2017-02-13 23:45:00 --> Database Driver Class Initialized
INFO - 2017-02-13 23:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:45:00 --> Controller Class Initialized
INFO - 2017-02-13 23:45:00 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:45:00 --> Final output sent to browser
DEBUG - 2017-02-13 23:45:00 --> Total execution time: 0.0140
INFO - 2017-02-13 23:45:01 --> Config Class Initialized
INFO - 2017-02-13 23:45:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:45:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:45:01 --> Utf8 Class Initialized
INFO - 2017-02-13 23:45:01 --> URI Class Initialized
INFO - 2017-02-13 23:45:01 --> Router Class Initialized
INFO - 2017-02-13 23:45:01 --> Output Class Initialized
INFO - 2017-02-13 23:45:01 --> Security Class Initialized
DEBUG - 2017-02-13 23:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:45:01 --> Input Class Initialized
INFO - 2017-02-13 23:45:01 --> Language Class Initialized
INFO - 2017-02-13 23:45:01 --> Loader Class Initialized
INFO - 2017-02-13 23:45:01 --> Database Driver Class Initialized
INFO - 2017-02-13 23:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:45:01 --> Controller Class Initialized
INFO - 2017-02-13 23:45:01 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:45:01 --> Final output sent to browser
DEBUG - 2017-02-13 23:45:01 --> Total execution time: 0.0130
INFO - 2017-02-13 23:46:15 --> Config Class Initialized
INFO - 2017-02-13 23:46:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:15 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:15 --> URI Class Initialized
INFO - 2017-02-13 23:46:15 --> Router Class Initialized
INFO - 2017-02-13 23:46:15 --> Output Class Initialized
INFO - 2017-02-13 23:46:15 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:15 --> Input Class Initialized
INFO - 2017-02-13 23:46:15 --> Language Class Initialized
INFO - 2017-02-13 23:46:15 --> Loader Class Initialized
INFO - 2017-02-13 23:46:15 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:15 --> Controller Class Initialized
INFO - 2017-02-13 23:46:15 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:15 --> Config Class Initialized
INFO - 2017-02-13 23:46:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:15 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:15 --> URI Class Initialized
INFO - 2017-02-13 23:46:15 --> Router Class Initialized
INFO - 2017-02-13 23:46:15 --> Output Class Initialized
INFO - 2017-02-13 23:46:15 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:15 --> Input Class Initialized
INFO - 2017-02-13 23:46:15 --> Language Class Initialized
INFO - 2017-02-13 23:46:15 --> Loader Class Initialized
INFO - 2017-02-13 23:46:15 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:15 --> Controller Class Initialized
INFO - 2017-02-13 23:46:15 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:15 --> Helper loaded: url_helper
INFO - 2017-02-13 23:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 23:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 23:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 23:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:46:15 --> Final output sent to browser
DEBUG - 2017-02-13 23:46:15 --> Total execution time: 0.0131
INFO - 2017-02-13 23:46:16 --> Config Class Initialized
INFO - 2017-02-13 23:46:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:16 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:16 --> URI Class Initialized
INFO - 2017-02-13 23:46:16 --> Router Class Initialized
INFO - 2017-02-13 23:46:16 --> Output Class Initialized
INFO - 2017-02-13 23:46:16 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:16 --> Input Class Initialized
INFO - 2017-02-13 23:46:16 --> Language Class Initialized
INFO - 2017-02-13 23:46:16 --> Loader Class Initialized
INFO - 2017-02-13 23:46:16 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:16 --> Controller Class Initialized
INFO - 2017-02-13 23:46:16 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:46:16 --> Final output sent to browser
DEBUG - 2017-02-13 23:46:16 --> Total execution time: 0.0146
INFO - 2017-02-13 23:46:29 --> Config Class Initialized
INFO - 2017-02-13 23:46:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:29 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:29 --> URI Class Initialized
DEBUG - 2017-02-13 23:46:29 --> No URI present. Default controller set.
INFO - 2017-02-13 23:46:29 --> Router Class Initialized
INFO - 2017-02-13 23:46:29 --> Output Class Initialized
INFO - 2017-02-13 23:46:29 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:29 --> Input Class Initialized
INFO - 2017-02-13 23:46:29 --> Language Class Initialized
INFO - 2017-02-13 23:46:29 --> Loader Class Initialized
INFO - 2017-02-13 23:46:29 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:29 --> Controller Class Initialized
INFO - 2017-02-13 23:46:29 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:46:29 --> Final output sent to browser
DEBUG - 2017-02-13 23:46:29 --> Total execution time: 0.0128
INFO - 2017-02-13 23:46:30 --> Config Class Initialized
INFO - 2017-02-13 23:46:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:30 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:30 --> URI Class Initialized
INFO - 2017-02-13 23:46:30 --> Router Class Initialized
INFO - 2017-02-13 23:46:30 --> Output Class Initialized
INFO - 2017-02-13 23:46:30 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:30 --> Input Class Initialized
INFO - 2017-02-13 23:46:30 --> Language Class Initialized
INFO - 2017-02-13 23:46:30 --> Loader Class Initialized
INFO - 2017-02-13 23:46:30 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:30 --> Controller Class Initialized
INFO - 2017-02-13 23:46:30 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:46:30 --> Final output sent to browser
DEBUG - 2017-02-13 23:46:30 --> Total execution time: 0.0155
INFO - 2017-02-13 23:46:52 --> Config Class Initialized
INFO - 2017-02-13 23:46:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:52 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:52 --> URI Class Initialized
INFO - 2017-02-13 23:46:52 --> Router Class Initialized
INFO - 2017-02-13 23:46:52 --> Output Class Initialized
INFO - 2017-02-13 23:46:52 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:52 --> Input Class Initialized
INFO - 2017-02-13 23:46:52 --> Language Class Initialized
INFO - 2017-02-13 23:46:52 --> Loader Class Initialized
INFO - 2017-02-13 23:46:52 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:52 --> Controller Class Initialized
INFO - 2017-02-13 23:46:52 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:52 --> Config Class Initialized
INFO - 2017-02-13 23:46:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:52 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:52 --> URI Class Initialized
INFO - 2017-02-13 23:46:52 --> Router Class Initialized
INFO - 2017-02-13 23:46:52 --> Output Class Initialized
INFO - 2017-02-13 23:46:52 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:52 --> Input Class Initialized
INFO - 2017-02-13 23:46:52 --> Language Class Initialized
INFO - 2017-02-13 23:46:52 --> Loader Class Initialized
INFO - 2017-02-13 23:46:52 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:52 --> Controller Class Initialized
INFO - 2017-02-13 23:46:52 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:52 --> Helper loaded: url_helper
INFO - 2017-02-13 23:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 23:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 23:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 23:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:46:52 --> Final output sent to browser
DEBUG - 2017-02-13 23:46:52 --> Total execution time: 0.0132
INFO - 2017-02-13 23:46:53 --> Config Class Initialized
INFO - 2017-02-13 23:46:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:53 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:53 --> URI Class Initialized
INFO - 2017-02-13 23:46:53 --> Router Class Initialized
INFO - 2017-02-13 23:46:53 --> Output Class Initialized
INFO - 2017-02-13 23:46:53 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:53 --> Input Class Initialized
INFO - 2017-02-13 23:46:53 --> Language Class Initialized
INFO - 2017-02-13 23:46:53 --> Loader Class Initialized
INFO - 2017-02-13 23:46:53 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:53 --> Controller Class Initialized
INFO - 2017-02-13 23:46:53 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:46:53 --> Final output sent to browser
DEBUG - 2017-02-13 23:46:53 --> Total execution time: 0.0147
INFO - 2017-02-13 23:46:59 --> Config Class Initialized
INFO - 2017-02-13 23:46:59 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:46:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:46:59 --> Utf8 Class Initialized
INFO - 2017-02-13 23:46:59 --> URI Class Initialized
DEBUG - 2017-02-13 23:46:59 --> No URI present. Default controller set.
INFO - 2017-02-13 23:46:59 --> Router Class Initialized
INFO - 2017-02-13 23:46:59 --> Output Class Initialized
INFO - 2017-02-13 23:46:59 --> Security Class Initialized
DEBUG - 2017-02-13 23:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:46:59 --> Input Class Initialized
INFO - 2017-02-13 23:46:59 --> Language Class Initialized
INFO - 2017-02-13 23:46:59 --> Loader Class Initialized
INFO - 2017-02-13 23:46:59 --> Database Driver Class Initialized
INFO - 2017-02-13 23:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:46:59 --> Controller Class Initialized
INFO - 2017-02-13 23:46:59 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:46:59 --> Final output sent to browser
DEBUG - 2017-02-13 23:46:59 --> Total execution time: 0.0136
INFO - 2017-02-13 23:47:03 --> Config Class Initialized
INFO - 2017-02-13 23:47:03 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:47:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:47:03 --> Utf8 Class Initialized
INFO - 2017-02-13 23:47:03 --> URI Class Initialized
INFO - 2017-02-13 23:47:03 --> Router Class Initialized
INFO - 2017-02-13 23:47:03 --> Output Class Initialized
INFO - 2017-02-13 23:47:03 --> Security Class Initialized
DEBUG - 2017-02-13 23:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:47:03 --> Input Class Initialized
INFO - 2017-02-13 23:47:03 --> Language Class Initialized
INFO - 2017-02-13 23:47:03 --> Loader Class Initialized
INFO - 2017-02-13 23:47:03 --> Database Driver Class Initialized
INFO - 2017-02-13 23:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:47:03 --> Controller Class Initialized
INFO - 2017-02-13 23:47:03 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:47:03 --> Final output sent to browser
DEBUG - 2017-02-13 23:47:03 --> Total execution time: 0.0133
INFO - 2017-02-13 23:48:11 --> Config Class Initialized
INFO - 2017-02-13 23:48:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:48:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:48:11 --> Utf8 Class Initialized
INFO - 2017-02-13 23:48:11 --> URI Class Initialized
INFO - 2017-02-13 23:48:11 --> Router Class Initialized
INFO - 2017-02-13 23:48:11 --> Output Class Initialized
INFO - 2017-02-13 23:48:11 --> Security Class Initialized
DEBUG - 2017-02-13 23:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:48:11 --> Input Class Initialized
INFO - 2017-02-13 23:48:11 --> Language Class Initialized
INFO - 2017-02-13 23:48:11 --> Loader Class Initialized
INFO - 2017-02-13 23:48:11 --> Database Driver Class Initialized
INFO - 2017-02-13 23:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:48:11 --> Controller Class Initialized
INFO - 2017-02-13 23:48:11 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:48:11 --> Final output sent to browser
DEBUG - 2017-02-13 23:48:11 --> Total execution time: 0.0141
INFO - 2017-02-13 23:48:14 --> Config Class Initialized
INFO - 2017-02-13 23:48:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:48:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:48:14 --> Utf8 Class Initialized
INFO - 2017-02-13 23:48:14 --> URI Class Initialized
INFO - 2017-02-13 23:48:14 --> Router Class Initialized
INFO - 2017-02-13 23:48:14 --> Output Class Initialized
INFO - 2017-02-13 23:48:14 --> Security Class Initialized
DEBUG - 2017-02-13 23:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:48:14 --> Input Class Initialized
INFO - 2017-02-13 23:48:14 --> Language Class Initialized
INFO - 2017-02-13 23:48:14 --> Loader Class Initialized
INFO - 2017-02-13 23:48:14 --> Database Driver Class Initialized
INFO - 2017-02-13 23:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:48:14 --> Controller Class Initialized
INFO - 2017-02-13 23:48:14 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:48:14 --> Final output sent to browser
DEBUG - 2017-02-13 23:48:14 --> Total execution time: 0.0128
INFO - 2017-02-13 23:48:26 --> Config Class Initialized
INFO - 2017-02-13 23:48:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:48:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:48:26 --> Utf8 Class Initialized
INFO - 2017-02-13 23:48:26 --> URI Class Initialized
INFO - 2017-02-13 23:48:26 --> Router Class Initialized
INFO - 2017-02-13 23:48:26 --> Output Class Initialized
INFO - 2017-02-13 23:48:26 --> Security Class Initialized
DEBUG - 2017-02-13 23:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:48:26 --> Input Class Initialized
INFO - 2017-02-13 23:48:26 --> Language Class Initialized
INFO - 2017-02-13 23:48:26 --> Loader Class Initialized
INFO - 2017-02-13 23:48:26 --> Database Driver Class Initialized
INFO - 2017-02-13 23:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:48:26 --> Controller Class Initialized
INFO - 2017-02-13 23:48:26 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:48:26 --> Config Class Initialized
INFO - 2017-02-13 23:48:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:48:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:48:26 --> Utf8 Class Initialized
INFO - 2017-02-13 23:48:26 --> URI Class Initialized
INFO - 2017-02-13 23:48:26 --> Router Class Initialized
INFO - 2017-02-13 23:48:26 --> Output Class Initialized
INFO - 2017-02-13 23:48:26 --> Security Class Initialized
DEBUG - 2017-02-13 23:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:48:26 --> Input Class Initialized
INFO - 2017-02-13 23:48:26 --> Language Class Initialized
INFO - 2017-02-13 23:48:26 --> Loader Class Initialized
INFO - 2017-02-13 23:48:26 --> Database Driver Class Initialized
INFO - 2017-02-13 23:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:48:26 --> Controller Class Initialized
INFO - 2017-02-13 23:48:26 --> Helper loaded: date_helper
DEBUG - 2017-02-13 23:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:48:26 --> Helper loaded: url_helper
INFO - 2017-02-13 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-13 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-13 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-13 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:48:26 --> Final output sent to browser
DEBUG - 2017-02-13 23:48:26 --> Total execution time: 0.0135
INFO - 2017-02-13 23:48:27 --> Config Class Initialized
INFO - 2017-02-13 23:48:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:48:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:48:27 --> Utf8 Class Initialized
INFO - 2017-02-13 23:48:27 --> URI Class Initialized
INFO - 2017-02-13 23:48:27 --> Router Class Initialized
INFO - 2017-02-13 23:48:27 --> Output Class Initialized
INFO - 2017-02-13 23:48:27 --> Security Class Initialized
DEBUG - 2017-02-13 23:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:48:27 --> Input Class Initialized
INFO - 2017-02-13 23:48:27 --> Language Class Initialized
INFO - 2017-02-13 23:48:27 --> Loader Class Initialized
INFO - 2017-02-13 23:48:27 --> Database Driver Class Initialized
INFO - 2017-02-13 23:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:48:27 --> Controller Class Initialized
INFO - 2017-02-13 23:48:27 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:48:27 --> Final output sent to browser
DEBUG - 2017-02-13 23:48:27 --> Total execution time: 0.0136
INFO - 2017-02-13 23:49:42 --> Config Class Initialized
INFO - 2017-02-13 23:49:42 --> Hooks Class Initialized
DEBUG - 2017-02-13 23:49:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 23:49:42 --> Utf8 Class Initialized
INFO - 2017-02-13 23:49:42 --> URI Class Initialized
DEBUG - 2017-02-13 23:49:42 --> No URI present. Default controller set.
INFO - 2017-02-13 23:49:42 --> Router Class Initialized
INFO - 2017-02-13 23:49:42 --> Output Class Initialized
INFO - 2017-02-13 23:49:42 --> Security Class Initialized
DEBUG - 2017-02-13 23:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 23:49:42 --> Input Class Initialized
INFO - 2017-02-13 23:49:42 --> Language Class Initialized
INFO - 2017-02-13 23:49:42 --> Loader Class Initialized
INFO - 2017-02-13 23:49:42 --> Database Driver Class Initialized
INFO - 2017-02-13 23:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 23:49:42 --> Controller Class Initialized
INFO - 2017-02-13 23:49:42 --> Helper loaded: url_helper
DEBUG - 2017-02-13 23:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-13 23:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-13 23:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-13 23:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-13 23:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-13 23:49:42 --> Final output sent to browser
DEBUG - 2017-02-13 23:49:42 --> Total execution time: 0.0131

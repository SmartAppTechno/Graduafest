<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-06 00:40:11 --> Config Class Initialized
INFO - 2017-01-06 00:40:11 --> Hooks Class Initialized
DEBUG - 2017-01-06 00:40:11 --> UTF-8 Support Enabled
INFO - 2017-01-06 00:40:11 --> Utf8 Class Initialized
INFO - 2017-01-06 00:40:11 --> URI Class Initialized
DEBUG - 2017-01-06 00:40:11 --> No URI present. Default controller set.
INFO - 2017-01-06 00:40:11 --> Router Class Initialized
INFO - 2017-01-06 00:40:11 --> Output Class Initialized
INFO - 2017-01-06 00:40:11 --> Security Class Initialized
DEBUG - 2017-01-06 00:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 00:40:11 --> Input Class Initialized
INFO - 2017-01-06 00:40:11 --> Language Class Initialized
INFO - 2017-01-06 00:40:11 --> Loader Class Initialized
INFO - 2017-01-06 00:40:12 --> Database Driver Class Initialized
INFO - 2017-01-06 00:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 00:40:12 --> Controller Class Initialized
INFO - 2017-01-06 00:40:12 --> Helper loaded: url_helper
DEBUG - 2017-01-06 00:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 00:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 00:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 00:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 00:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 00:40:12 --> Final output sent to browser
DEBUG - 2017-01-06 00:40:12 --> Total execution time: 2.0336
INFO - 2017-01-06 01:27:22 --> Config Class Initialized
INFO - 2017-01-06 01:27:22 --> Hooks Class Initialized
DEBUG - 2017-01-06 01:27:22 --> UTF-8 Support Enabled
INFO - 2017-01-06 01:27:22 --> Utf8 Class Initialized
INFO - 2017-01-06 01:27:22 --> URI Class Initialized
DEBUG - 2017-01-06 01:27:22 --> No URI present. Default controller set.
INFO - 2017-01-06 01:27:22 --> Router Class Initialized
INFO - 2017-01-06 01:27:22 --> Output Class Initialized
INFO - 2017-01-06 01:27:22 --> Security Class Initialized
DEBUG - 2017-01-06 01:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 01:27:22 --> Input Class Initialized
INFO - 2017-01-06 01:27:22 --> Language Class Initialized
INFO - 2017-01-06 01:27:22 --> Loader Class Initialized
INFO - 2017-01-06 01:27:23 --> Database Driver Class Initialized
INFO - 2017-01-06 01:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 01:27:23 --> Controller Class Initialized
INFO - 2017-01-06 01:27:23 --> Helper loaded: url_helper
DEBUG - 2017-01-06 01:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 01:27:23 --> Final output sent to browser
DEBUG - 2017-01-06 01:27:23 --> Total execution time: 1.7632
INFO - 2017-01-06 02:06:29 --> Config Class Initialized
INFO - 2017-01-06 02:06:29 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:06:29 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:06:29 --> Utf8 Class Initialized
INFO - 2017-01-06 02:06:29 --> URI Class Initialized
INFO - 2017-01-06 02:06:29 --> Router Class Initialized
INFO - 2017-01-06 02:06:29 --> Output Class Initialized
INFO - 2017-01-06 02:06:30 --> Security Class Initialized
DEBUG - 2017-01-06 02:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:06:30 --> Input Class Initialized
INFO - 2017-01-06 02:06:30 --> Language Class Initialized
INFO - 2017-01-06 02:06:30 --> Loader Class Initialized
INFO - 2017-01-06 02:06:30 --> Database Driver Class Initialized
INFO - 2017-01-06 02:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:06:30 --> Controller Class Initialized
INFO - 2017-01-06 02:06:30 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:06:31 --> Helper loaded: form_helper
INFO - 2017-01-06 02:06:31 --> Form Validation Class Initialized
INFO - 2017-01-06 02:06:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-06 02:06:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-06 02:06:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-06 02:06:31 --> Final output sent to browser
DEBUG - 2017-01-06 02:06:31 --> Total execution time: 2.1554
INFO - 2017-01-06 02:06:32 --> Config Class Initialized
INFO - 2017-01-06 02:06:32 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:06:32 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:06:32 --> Utf8 Class Initialized
INFO - 2017-01-06 02:06:32 --> URI Class Initialized
INFO - 2017-01-06 02:06:32 --> Router Class Initialized
INFO - 2017-01-06 02:06:32 --> Output Class Initialized
INFO - 2017-01-06 02:06:32 --> Security Class Initialized
DEBUG - 2017-01-06 02:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:06:32 --> Input Class Initialized
INFO - 2017-01-06 02:06:32 --> Language Class Initialized
INFO - 2017-01-06 02:06:32 --> Loader Class Initialized
INFO - 2017-01-06 02:06:32 --> Database Driver Class Initialized
INFO - 2017-01-06 02:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:06:32 --> Controller Class Initialized
INFO - 2017-01-06 02:06:32 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:06:32 --> Final output sent to browser
DEBUG - 2017-01-06 02:06:32 --> Total execution time: 0.2648
INFO - 2017-01-06 02:06:44 --> Config Class Initialized
INFO - 2017-01-06 02:06:44 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:06:44 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:06:44 --> Utf8 Class Initialized
INFO - 2017-01-06 02:06:44 --> URI Class Initialized
INFO - 2017-01-06 02:06:44 --> Router Class Initialized
INFO - 2017-01-06 02:06:44 --> Output Class Initialized
INFO - 2017-01-06 02:06:44 --> Security Class Initialized
DEBUG - 2017-01-06 02:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:06:44 --> Input Class Initialized
INFO - 2017-01-06 02:06:44 --> Language Class Initialized
INFO - 2017-01-06 02:06:44 --> Loader Class Initialized
INFO - 2017-01-06 02:06:44 --> Database Driver Class Initialized
INFO - 2017-01-06 02:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:06:44 --> Controller Class Initialized
INFO - 2017-01-06 02:06:44 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:06:44 --> Helper loaded: form_helper
INFO - 2017-01-06 02:06:44 --> Form Validation Class Initialized
INFO - 2017-01-06 02:06:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-06 02:06:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-06 02:06:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-06 02:06:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-06 02:06:44 --> Final output sent to browser
DEBUG - 2017-01-06 02:06:44 --> Total execution time: 0.1356
INFO - 2017-01-06 02:06:44 --> Config Class Initialized
INFO - 2017-01-06 02:06:44 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:06:44 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:06:44 --> Utf8 Class Initialized
INFO - 2017-01-06 02:06:44 --> URI Class Initialized
INFO - 2017-01-06 02:06:44 --> Router Class Initialized
INFO - 2017-01-06 02:06:44 --> Output Class Initialized
INFO - 2017-01-06 02:06:44 --> Security Class Initialized
DEBUG - 2017-01-06 02:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:06:44 --> Input Class Initialized
INFO - 2017-01-06 02:06:44 --> Language Class Initialized
INFO - 2017-01-06 02:06:44 --> Loader Class Initialized
INFO - 2017-01-06 02:06:44 --> Database Driver Class Initialized
INFO - 2017-01-06 02:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:06:44 --> Controller Class Initialized
INFO - 2017-01-06 02:06:44 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:06:44 --> Final output sent to browser
DEBUG - 2017-01-06 02:06:44 --> Total execution time: 0.0133
INFO - 2017-01-06 02:06:57 --> Config Class Initialized
INFO - 2017-01-06 02:06:57 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:06:57 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:06:57 --> Utf8 Class Initialized
INFO - 2017-01-06 02:06:57 --> URI Class Initialized
INFO - 2017-01-06 02:06:57 --> Router Class Initialized
INFO - 2017-01-06 02:06:57 --> Output Class Initialized
INFO - 2017-01-06 02:06:57 --> Security Class Initialized
DEBUG - 2017-01-06 02:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:06:57 --> Input Class Initialized
INFO - 2017-01-06 02:06:57 --> Language Class Initialized
INFO - 2017-01-06 02:06:57 --> Loader Class Initialized
INFO - 2017-01-06 02:06:57 --> Database Driver Class Initialized
INFO - 2017-01-06 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:06:57 --> Controller Class Initialized
INFO - 2017-01-06 02:06:57 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:06:57 --> Helper loaded: form_helper
INFO - 2017-01-06 02:06:57 --> Form Validation Class Initialized
INFO - 2017-01-06 02:06:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-06 02:06:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-06 02:06:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-06 02:06:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-06 02:06:57 --> Final output sent to browser
DEBUG - 2017-01-06 02:06:57 --> Total execution time: 0.0144
INFO - 2017-01-06 02:06:57 --> Config Class Initialized
INFO - 2017-01-06 02:06:57 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:06:57 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:06:57 --> Utf8 Class Initialized
INFO - 2017-01-06 02:06:57 --> URI Class Initialized
INFO - 2017-01-06 02:06:57 --> Router Class Initialized
INFO - 2017-01-06 02:06:57 --> Output Class Initialized
INFO - 2017-01-06 02:06:57 --> Security Class Initialized
DEBUG - 2017-01-06 02:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:06:57 --> Input Class Initialized
INFO - 2017-01-06 02:06:57 --> Language Class Initialized
INFO - 2017-01-06 02:06:57 --> Loader Class Initialized
INFO - 2017-01-06 02:06:57 --> Database Driver Class Initialized
INFO - 2017-01-06 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:06:57 --> Controller Class Initialized
INFO - 2017-01-06 02:06:57 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:06:57 --> Final output sent to browser
DEBUG - 2017-01-06 02:06:57 --> Total execution time: 0.0131
INFO - 2017-01-06 02:07:11 --> Config Class Initialized
INFO - 2017-01-06 02:07:11 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:07:11 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:07:11 --> Utf8 Class Initialized
INFO - 2017-01-06 02:07:11 --> URI Class Initialized
DEBUG - 2017-01-06 02:07:11 --> No URI present. Default controller set.
INFO - 2017-01-06 02:07:11 --> Router Class Initialized
INFO - 2017-01-06 02:07:11 --> Output Class Initialized
INFO - 2017-01-06 02:07:11 --> Security Class Initialized
DEBUG - 2017-01-06 02:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:07:11 --> Input Class Initialized
INFO - 2017-01-06 02:07:11 --> Language Class Initialized
INFO - 2017-01-06 02:07:11 --> Loader Class Initialized
INFO - 2017-01-06 02:07:11 --> Database Driver Class Initialized
INFO - 2017-01-06 02:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:07:11 --> Controller Class Initialized
INFO - 2017-01-06 02:07:11 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:07:11 --> Final output sent to browser
DEBUG - 2017-01-06 02:07:11 --> Total execution time: 0.0137
INFO - 2017-01-06 02:07:11 --> Config Class Initialized
INFO - 2017-01-06 02:07:11 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:07:11 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:07:11 --> Utf8 Class Initialized
INFO - 2017-01-06 02:07:11 --> URI Class Initialized
INFO - 2017-01-06 02:07:11 --> Router Class Initialized
INFO - 2017-01-06 02:07:11 --> Output Class Initialized
INFO - 2017-01-06 02:07:11 --> Security Class Initialized
DEBUG - 2017-01-06 02:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:07:11 --> Input Class Initialized
INFO - 2017-01-06 02:07:11 --> Language Class Initialized
INFO - 2017-01-06 02:07:11 --> Loader Class Initialized
INFO - 2017-01-06 02:07:11 --> Database Driver Class Initialized
INFO - 2017-01-06 02:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:07:11 --> Controller Class Initialized
INFO - 2017-01-06 02:07:11 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:07:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:07:11 --> Final output sent to browser
DEBUG - 2017-01-06 02:07:11 --> Total execution time: 0.0133
INFO - 2017-01-06 02:11:23 --> Config Class Initialized
INFO - 2017-01-06 02:11:23 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:11:23 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:11:23 --> Utf8 Class Initialized
INFO - 2017-01-06 02:11:23 --> URI Class Initialized
DEBUG - 2017-01-06 02:11:23 --> No URI present. Default controller set.
INFO - 2017-01-06 02:11:23 --> Router Class Initialized
INFO - 2017-01-06 02:11:23 --> Output Class Initialized
INFO - 2017-01-06 02:11:23 --> Security Class Initialized
DEBUG - 2017-01-06 02:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:11:23 --> Input Class Initialized
INFO - 2017-01-06 02:11:23 --> Language Class Initialized
INFO - 2017-01-06 02:11:23 --> Loader Class Initialized
INFO - 2017-01-06 02:11:24 --> Database Driver Class Initialized
INFO - 2017-01-06 02:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:11:24 --> Controller Class Initialized
INFO - 2017-01-06 02:11:24 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:11:24 --> Final output sent to browser
DEBUG - 2017-01-06 02:11:24 --> Total execution time: 1.4947
INFO - 2017-01-06 02:12:01 --> Config Class Initialized
INFO - 2017-01-06 02:12:01 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:12:01 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:12:01 --> Utf8 Class Initialized
INFO - 2017-01-06 02:12:01 --> URI Class Initialized
INFO - 2017-01-06 02:12:01 --> Router Class Initialized
INFO - 2017-01-06 02:12:01 --> Output Class Initialized
INFO - 2017-01-06 02:12:01 --> Security Class Initialized
DEBUG - 2017-01-06 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:12:01 --> Input Class Initialized
INFO - 2017-01-06 02:12:01 --> Language Class Initialized
INFO - 2017-01-06 02:12:01 --> Loader Class Initialized
INFO - 2017-01-06 02:12:01 --> Database Driver Class Initialized
INFO - 2017-01-06 02:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:12:01 --> Controller Class Initialized
INFO - 2017-01-06 02:12:01 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:12:01 --> Helper loaded: form_helper
INFO - 2017-01-06 02:12:01 --> Form Validation Class Initialized
INFO - 2017-01-06 02:12:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-06 02:12:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-06 02:12:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-06 02:12:01 --> Final output sent to browser
DEBUG - 2017-01-06 02:12:01 --> Total execution time: 0.1543
INFO - 2017-01-06 02:12:22 --> Config Class Initialized
INFO - 2017-01-06 02:12:22 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:12:22 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:12:22 --> Utf8 Class Initialized
INFO - 2017-01-06 02:12:22 --> URI Class Initialized
INFO - 2017-01-06 02:12:22 --> Router Class Initialized
INFO - 2017-01-06 02:12:22 --> Output Class Initialized
INFO - 2017-01-06 02:12:22 --> Security Class Initialized
DEBUG - 2017-01-06 02:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:12:22 --> Input Class Initialized
INFO - 2017-01-06 02:12:22 --> Language Class Initialized
INFO - 2017-01-06 02:12:22 --> Loader Class Initialized
INFO - 2017-01-06 02:12:23 --> Database Driver Class Initialized
INFO - 2017-01-06 02:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:12:23 --> Controller Class Initialized
INFO - 2017-01-06 02:12:23 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:12:23 --> Helper loaded: form_helper
INFO - 2017-01-06 02:12:23 --> Form Validation Class Initialized
INFO - 2017-01-06 02:12:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-06 02:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-06 02:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-06 02:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-06 02:12:23 --> Final output sent to browser
DEBUG - 2017-01-06 02:12:23 --> Total execution time: 1.3921
INFO - 2017-01-06 02:12:24 --> Config Class Initialized
INFO - 2017-01-06 02:12:24 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:12:24 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:12:24 --> Utf8 Class Initialized
INFO - 2017-01-06 02:12:24 --> URI Class Initialized
INFO - 2017-01-06 02:12:24 --> Router Class Initialized
INFO - 2017-01-06 02:12:24 --> Output Class Initialized
INFO - 2017-01-06 02:12:24 --> Security Class Initialized
DEBUG - 2017-01-06 02:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:12:24 --> Input Class Initialized
INFO - 2017-01-06 02:12:24 --> Language Class Initialized
INFO - 2017-01-06 02:12:24 --> Loader Class Initialized
INFO - 2017-01-06 02:12:24 --> Database Driver Class Initialized
INFO - 2017-01-06 02:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:12:24 --> Controller Class Initialized
INFO - 2017-01-06 02:12:24 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:12:24 --> Final output sent to browser
DEBUG - 2017-01-06 02:12:24 --> Total execution time: 0.5705
INFO - 2017-01-06 02:13:41 --> Config Class Initialized
INFO - 2017-01-06 02:13:41 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:13:41 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:13:41 --> Utf8 Class Initialized
INFO - 2017-01-06 02:13:41 --> URI Class Initialized
DEBUG - 2017-01-06 02:13:41 --> No URI present. Default controller set.
INFO - 2017-01-06 02:13:41 --> Router Class Initialized
INFO - 2017-01-06 02:13:41 --> Output Class Initialized
INFO - 2017-01-06 02:13:41 --> Security Class Initialized
DEBUG - 2017-01-06 02:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:13:41 --> Input Class Initialized
INFO - 2017-01-06 02:13:41 --> Language Class Initialized
INFO - 2017-01-06 02:13:41 --> Loader Class Initialized
INFO - 2017-01-06 02:13:41 --> Database Driver Class Initialized
INFO - 2017-01-06 02:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:13:42 --> Controller Class Initialized
INFO - 2017-01-06 02:13:42 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:13:42 --> Final output sent to browser
DEBUG - 2017-01-06 02:13:42 --> Total execution time: 0.0252
INFO - 2017-01-06 02:17:26 --> Config Class Initialized
INFO - 2017-01-06 02:17:26 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:17:26 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:17:26 --> Utf8 Class Initialized
INFO - 2017-01-06 02:17:26 --> URI Class Initialized
DEBUG - 2017-01-06 02:17:27 --> No URI present. Default controller set.
INFO - 2017-01-06 02:17:27 --> Router Class Initialized
INFO - 2017-01-06 02:17:27 --> Output Class Initialized
INFO - 2017-01-06 02:17:27 --> Security Class Initialized
DEBUG - 2017-01-06 02:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:17:27 --> Input Class Initialized
INFO - 2017-01-06 02:17:27 --> Language Class Initialized
INFO - 2017-01-06 02:17:27 --> Loader Class Initialized
INFO - 2017-01-06 02:17:27 --> Database Driver Class Initialized
INFO - 2017-01-06 02:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:17:27 --> Controller Class Initialized
INFO - 2017-01-06 02:17:27 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:17:28 --> Final output sent to browser
DEBUG - 2017-01-06 02:17:28 --> Total execution time: 1.7433
INFO - 2017-01-06 02:17:29 --> Config Class Initialized
INFO - 2017-01-06 02:17:29 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:17:29 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:17:29 --> Utf8 Class Initialized
INFO - 2017-01-06 02:17:29 --> URI Class Initialized
INFO - 2017-01-06 02:17:29 --> Router Class Initialized
INFO - 2017-01-06 02:17:29 --> Output Class Initialized
INFO - 2017-01-06 02:17:29 --> Security Class Initialized
DEBUG - 2017-01-06 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:17:29 --> Input Class Initialized
INFO - 2017-01-06 02:17:29 --> Language Class Initialized
INFO - 2017-01-06 02:17:29 --> Loader Class Initialized
INFO - 2017-01-06 02:17:29 --> Database Driver Class Initialized
INFO - 2017-01-06 02:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:17:29 --> Controller Class Initialized
INFO - 2017-01-06 02:17:29 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:17:29 --> Final output sent to browser
DEBUG - 2017-01-06 02:17:29 --> Total execution time: 0.0134
INFO - 2017-01-06 02:18:14 --> Config Class Initialized
INFO - 2017-01-06 02:18:14 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:14 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:14 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:14 --> URI Class Initialized
INFO - 2017-01-06 02:18:14 --> Router Class Initialized
INFO - 2017-01-06 02:18:14 --> Output Class Initialized
INFO - 2017-01-06 02:18:14 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:14 --> Input Class Initialized
INFO - 2017-01-06 02:18:14 --> Language Class Initialized
INFO - 2017-01-06 02:18:14 --> Loader Class Initialized
INFO - 2017-01-06 02:18:14 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:14 --> Controller Class Initialized
INFO - 2017-01-06 02:18:14 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:17 --> Config Class Initialized
INFO - 2017-01-06 02:18:17 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:17 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:17 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:17 --> URI Class Initialized
INFO - 2017-01-06 02:18:17 --> Router Class Initialized
INFO - 2017-01-06 02:18:17 --> Output Class Initialized
INFO - 2017-01-06 02:18:17 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:17 --> Input Class Initialized
INFO - 2017-01-06 02:18:17 --> Language Class Initialized
INFO - 2017-01-06 02:18:17 --> Loader Class Initialized
INFO - 2017-01-06 02:18:17 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:17 --> Controller Class Initialized
INFO - 2017-01-06 02:18:18 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:18 --> Helper loaded: url_helper
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:18 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:18 --> Total execution time: 0.4096
INFO - 2017-01-06 02:18:18 --> Config Class Initialized
INFO - 2017-01-06 02:18:18 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:18 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:18 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:18 --> URI Class Initialized
INFO - 2017-01-06 02:18:18 --> Router Class Initialized
INFO - 2017-01-06 02:18:18 --> Output Class Initialized
INFO - 2017-01-06 02:18:18 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:18 --> Input Class Initialized
INFO - 2017-01-06 02:18:18 --> Language Class Initialized
INFO - 2017-01-06 02:18:18 --> Loader Class Initialized
INFO - 2017-01-06 02:18:18 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:18 --> Controller Class Initialized
INFO - 2017-01-06 02:18:18 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:18 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:18 --> Total execution time: 0.0136
INFO - 2017-01-06 02:18:21 --> Config Class Initialized
INFO - 2017-01-06 02:18:21 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:21 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:21 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:21 --> URI Class Initialized
INFO - 2017-01-06 02:18:21 --> Router Class Initialized
INFO - 2017-01-06 02:18:21 --> Output Class Initialized
INFO - 2017-01-06 02:18:21 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:21 --> Input Class Initialized
INFO - 2017-01-06 02:18:21 --> Language Class Initialized
INFO - 2017-01-06 02:18:21 --> Loader Class Initialized
INFO - 2017-01-06 02:18:21 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:21 --> Controller Class Initialized
INFO - 2017-01-06 02:18:21 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:21 --> Helper loaded: url_helper
INFO - 2017-01-06 02:18:21 --> Helper loaded: download_helper
INFO - 2017-01-06 02:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-06 02:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-06 02:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-06 02:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:21 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:21 --> Total execution time: 0.1508
INFO - 2017-01-06 02:18:22 --> Config Class Initialized
INFO - 2017-01-06 02:18:22 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:22 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:22 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:22 --> URI Class Initialized
INFO - 2017-01-06 02:18:22 --> Router Class Initialized
INFO - 2017-01-06 02:18:22 --> Output Class Initialized
INFO - 2017-01-06 02:18:22 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:22 --> Input Class Initialized
INFO - 2017-01-06 02:18:22 --> Language Class Initialized
INFO - 2017-01-06 02:18:22 --> Loader Class Initialized
INFO - 2017-01-06 02:18:22 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:22 --> Controller Class Initialized
INFO - 2017-01-06 02:18:22 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:22 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:22 --> Total execution time: 0.0137
INFO - 2017-01-06 02:18:26 --> Config Class Initialized
INFO - 2017-01-06 02:18:26 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:26 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:26 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:26 --> URI Class Initialized
INFO - 2017-01-06 02:18:26 --> Router Class Initialized
INFO - 2017-01-06 02:18:26 --> Output Class Initialized
INFO - 2017-01-06 02:18:26 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:26 --> Input Class Initialized
INFO - 2017-01-06 02:18:26 --> Language Class Initialized
INFO - 2017-01-06 02:18:26 --> Loader Class Initialized
INFO - 2017-01-06 02:18:26 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:26 --> Controller Class Initialized
INFO - 2017-01-06 02:18:26 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:26 --> Helper loaded: url_helper
INFO - 2017-01-06 02:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-06 02:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-06 02:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-06 02:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-06 02:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:26 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:26 --> Total execution time: 0.0708
INFO - 2017-01-06 02:18:27 --> Config Class Initialized
INFO - 2017-01-06 02:18:27 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:27 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:27 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:27 --> URI Class Initialized
INFO - 2017-01-06 02:18:27 --> Router Class Initialized
INFO - 2017-01-06 02:18:27 --> Output Class Initialized
INFO - 2017-01-06 02:18:27 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:27 --> Input Class Initialized
INFO - 2017-01-06 02:18:27 --> Language Class Initialized
INFO - 2017-01-06 02:18:27 --> Loader Class Initialized
INFO - 2017-01-06 02:18:27 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:27 --> Controller Class Initialized
INFO - 2017-01-06 02:18:27 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:27 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:27 --> Total execution time: 0.2749
INFO - 2017-01-06 02:18:30 --> Config Class Initialized
INFO - 2017-01-06 02:18:30 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:30 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:30 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:30 --> URI Class Initialized
INFO - 2017-01-06 02:18:30 --> Router Class Initialized
INFO - 2017-01-06 02:18:30 --> Output Class Initialized
INFO - 2017-01-06 02:18:30 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:30 --> Input Class Initialized
INFO - 2017-01-06 02:18:30 --> Language Class Initialized
INFO - 2017-01-06 02:18:30 --> Loader Class Initialized
INFO - 2017-01-06 02:18:30 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:30 --> Controller Class Initialized
INFO - 2017-01-06 02:18:30 --> Upload Class Initialized
INFO - 2017-01-06 02:18:30 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:30 --> Helper loaded: url_helper
INFO - 2017-01-06 02:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-06 02:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-06 02:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-06 02:18:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-06 02:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:30 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:30 --> Total execution time: 0.2019
INFO - 2017-01-06 02:18:31 --> Config Class Initialized
INFO - 2017-01-06 02:18:31 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:31 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:31 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:31 --> URI Class Initialized
INFO - 2017-01-06 02:18:31 --> Router Class Initialized
INFO - 2017-01-06 02:18:31 --> Output Class Initialized
INFO - 2017-01-06 02:18:31 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:31 --> Input Class Initialized
INFO - 2017-01-06 02:18:31 --> Language Class Initialized
INFO - 2017-01-06 02:18:31 --> Loader Class Initialized
INFO - 2017-01-06 02:18:31 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:31 --> Controller Class Initialized
INFO - 2017-01-06 02:18:31 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:18:31 --> Final output sent to browser
DEBUG - 2017-01-06 02:18:31 --> Total execution time: 0.0137
INFO - 2017-01-06 02:18:34 --> Config Class Initialized
INFO - 2017-01-06 02:18:34 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:18:34 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:18:34 --> Utf8 Class Initialized
INFO - 2017-01-06 02:18:34 --> URI Class Initialized
INFO - 2017-01-06 02:18:34 --> Router Class Initialized
INFO - 2017-01-06 02:18:34 --> Output Class Initialized
INFO - 2017-01-06 02:18:34 --> Security Class Initialized
DEBUG - 2017-01-06 02:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:18:34 --> Input Class Initialized
INFO - 2017-01-06 02:18:34 --> Language Class Initialized
INFO - 2017-01-06 02:18:34 --> Loader Class Initialized
INFO - 2017-01-06 02:18:34 --> Database Driver Class Initialized
INFO - 2017-01-06 02:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:18:34 --> Controller Class Initialized
INFO - 2017-01-06 02:18:34 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:18:34 --> Helper loaded: url_helper
INFO - 2017-01-06 02:18:34 --> Helper loaded: download_helper
INFO - 2017-01-06 02:38:44 --> Config Class Initialized
INFO - 2017-01-06 02:38:44 --> Config Class Initialized
INFO - 2017-01-06 02:38:44 --> Hooks Class Initialized
INFO - 2017-01-06 02:38:44 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:38:44 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:38:44 --> Utf8 Class Initialized
DEBUG - 2017-01-06 02:38:44 --> UTF-8 Support Enabled
INFO - 2017-01-06 02:38:44 --> Utf8 Class Initialized
INFO - 2017-01-06 02:38:44 --> URI Class Initialized
INFO - 2017-01-06 02:38:44 --> URI Class Initialized
INFO - 2017-01-06 02:38:44 --> Router Class Initialized
DEBUG - 2017-01-06 02:38:44 --> No URI present. Default controller set.
INFO - 2017-01-06 02:38:44 --> Router Class Initialized
INFO - 2017-01-06 02:38:44 --> Output Class Initialized
INFO - 2017-01-06 02:38:44 --> Output Class Initialized
INFO - 2017-01-06 02:38:44 --> Security Class Initialized
INFO - 2017-01-06 02:38:44 --> Security Class Initialized
DEBUG - 2017-01-06 02:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:38:44 --> Input Class Initialized
INFO - 2017-01-06 02:38:44 --> Language Class Initialized
DEBUG - 2017-01-06 02:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 02:38:44 --> Input Class Initialized
INFO - 2017-01-06 02:38:44 --> Language Class Initialized
INFO - 2017-01-06 02:38:44 --> Loader Class Initialized
INFO - 2017-01-06 02:38:44 --> Loader Class Initialized
INFO - 2017-01-06 02:38:45 --> Database Driver Class Initialized
INFO - 2017-01-06 02:38:45 --> Database Driver Class Initialized
INFO - 2017-01-06 02:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:38:45 --> Controller Class Initialized
INFO - 2017-01-06 02:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 02:38:45 --> Helper loaded: url_helper
INFO - 2017-01-06 02:38:45 --> Controller Class Initialized
INFO - 2017-01-06 02:38:45 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-01-06 02:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 02:38:45 --> Final output sent to browser
DEBUG - 2017-01-06 02:38:45 --> Total execution time: 1.8334
INFO - 2017-01-06 02:38:45 --> Final output sent to browser
DEBUG - 2017-01-06 02:38:45 --> Total execution time: 1.8334
INFO - 2017-01-06 12:26:14 --> Config Class Initialized
INFO - 2017-01-06 12:26:15 --> Hooks Class Initialized
DEBUG - 2017-01-06 12:26:15 --> UTF-8 Support Enabled
INFO - 2017-01-06 12:26:15 --> Utf8 Class Initialized
INFO - 2017-01-06 12:26:15 --> URI Class Initialized
DEBUG - 2017-01-06 12:26:15 --> No URI present. Default controller set.
INFO - 2017-01-06 12:26:15 --> Router Class Initialized
INFO - 2017-01-06 12:26:15 --> Output Class Initialized
INFO - 2017-01-06 12:26:15 --> Security Class Initialized
DEBUG - 2017-01-06 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 12:26:15 --> Input Class Initialized
INFO - 2017-01-06 12:26:15 --> Language Class Initialized
INFO - 2017-01-06 12:26:15 --> Loader Class Initialized
INFO - 2017-01-06 12:26:15 --> Database Driver Class Initialized
INFO - 2017-01-06 12:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 12:26:16 --> Controller Class Initialized
INFO - 2017-01-06 12:26:16 --> Helper loaded: url_helper
DEBUG - 2017-01-06 12:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 12:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 12:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 12:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 12:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 12:26:16 --> Final output sent to browser
DEBUG - 2017-01-06 12:26:16 --> Total execution time: 1.6625
INFO - 2017-01-06 15:25:38 --> Config Class Initialized
INFO - 2017-01-06 15:25:38 --> Hooks Class Initialized
DEBUG - 2017-01-06 15:25:38 --> UTF-8 Support Enabled
INFO - 2017-01-06 15:25:38 --> Utf8 Class Initialized
INFO - 2017-01-06 15:25:38 --> URI Class Initialized
DEBUG - 2017-01-06 15:25:38 --> No URI present. Default controller set.
INFO - 2017-01-06 15:25:38 --> Router Class Initialized
INFO - 2017-01-06 15:25:38 --> Output Class Initialized
INFO - 2017-01-06 15:25:38 --> Security Class Initialized
DEBUG - 2017-01-06 15:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 15:25:38 --> Input Class Initialized
INFO - 2017-01-06 15:25:38 --> Language Class Initialized
INFO - 2017-01-06 15:25:38 --> Loader Class Initialized
INFO - 2017-01-06 15:25:39 --> Database Driver Class Initialized
INFO - 2017-01-06 15:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 15:25:39 --> Controller Class Initialized
INFO - 2017-01-06 15:25:39 --> Helper loaded: url_helper
DEBUG - 2017-01-06 15:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 15:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 15:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 15:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 15:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 15:25:40 --> Final output sent to browser
DEBUG - 2017-01-06 15:25:40 --> Total execution time: 1.8209
INFO - 2017-01-06 16:26:19 --> Config Class Initialized
INFO - 2017-01-06 16:26:19 --> Hooks Class Initialized
DEBUG - 2017-01-06 16:26:19 --> UTF-8 Support Enabled
INFO - 2017-01-06 16:26:19 --> Utf8 Class Initialized
INFO - 2017-01-06 16:26:19 --> URI Class Initialized
DEBUG - 2017-01-06 16:26:19 --> No URI present. Default controller set.
INFO - 2017-01-06 16:26:19 --> Router Class Initialized
INFO - 2017-01-06 16:26:19 --> Output Class Initialized
INFO - 2017-01-06 16:26:19 --> Security Class Initialized
DEBUG - 2017-01-06 16:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 16:26:19 --> Input Class Initialized
INFO - 2017-01-06 16:26:19 --> Language Class Initialized
INFO - 2017-01-06 16:26:19 --> Loader Class Initialized
INFO - 2017-01-06 16:26:20 --> Database Driver Class Initialized
INFO - 2017-01-06 16:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 16:26:20 --> Controller Class Initialized
INFO - 2017-01-06 16:26:20 --> Helper loaded: url_helper
DEBUG - 2017-01-06 16:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 16:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 16:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 16:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 16:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 16:26:20 --> Final output sent to browser
DEBUG - 2017-01-06 16:26:20 --> Total execution time: 1.7454
INFO - 2017-01-06 17:13:49 --> Config Class Initialized
INFO - 2017-01-06 17:13:49 --> Hooks Class Initialized
DEBUG - 2017-01-06 17:13:49 --> UTF-8 Support Enabled
INFO - 2017-01-06 17:13:49 --> Utf8 Class Initialized
INFO - 2017-01-06 17:13:49 --> URI Class Initialized
DEBUG - 2017-01-06 17:13:49 --> No URI present. Default controller set.
INFO - 2017-01-06 17:13:49 --> Router Class Initialized
INFO - 2017-01-06 17:13:50 --> Output Class Initialized
INFO - 2017-01-06 17:13:50 --> Security Class Initialized
DEBUG - 2017-01-06 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 17:13:50 --> Input Class Initialized
INFO - 2017-01-06 17:13:50 --> Language Class Initialized
INFO - 2017-01-06 17:13:50 --> Loader Class Initialized
INFO - 2017-01-06 17:13:50 --> Database Driver Class Initialized
INFO - 2017-01-06 17:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 17:13:50 --> Controller Class Initialized
INFO - 2017-01-06 17:13:50 --> Helper loaded: url_helper
DEBUG - 2017-01-06 17:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 17:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 17:13:50 --> Final output sent to browser
DEBUG - 2017-01-06 17:13:50 --> Total execution time: 1.4759
INFO - 2017-01-06 18:18:00 --> Config Class Initialized
INFO - 2017-01-06 18:18:00 --> Hooks Class Initialized
DEBUG - 2017-01-06 18:18:01 --> UTF-8 Support Enabled
INFO - 2017-01-06 18:18:01 --> Config Class Initialized
INFO - 2017-01-06 18:18:01 --> Utf8 Class Initialized
INFO - 2017-01-06 18:18:01 --> Hooks Class Initialized
INFO - 2017-01-06 18:18:01 --> URI Class Initialized
DEBUG - 2017-01-06 18:18:01 --> UTF-8 Support Enabled
INFO - 2017-01-06 18:18:01 --> Utf8 Class Initialized
INFO - 2017-01-06 18:18:01 --> URI Class Initialized
DEBUG - 2017-01-06 18:18:01 --> No URI present. Default controller set.
INFO - 2017-01-06 18:18:01 --> Router Class Initialized
DEBUG - 2017-01-06 18:18:01 --> No URI present. Default controller set.
INFO - 2017-01-06 18:18:01 --> Router Class Initialized
INFO - 2017-01-06 18:18:01 --> Output Class Initialized
INFO - 2017-01-06 18:18:01 --> Output Class Initialized
INFO - 2017-01-06 18:18:01 --> Security Class Initialized
INFO - 2017-01-06 18:18:01 --> Security Class Initialized
DEBUG - 2017-01-06 18:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-06 18:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 18:18:01 --> Input Class Initialized
INFO - 2017-01-06 18:18:01 --> Input Class Initialized
INFO - 2017-01-06 18:18:01 --> Language Class Initialized
INFO - 2017-01-06 18:18:01 --> Language Class Initialized
INFO - 2017-01-06 18:18:01 --> Loader Class Initialized
INFO - 2017-01-06 18:18:01 --> Loader Class Initialized
INFO - 2017-01-06 18:18:01 --> Database Driver Class Initialized
INFO - 2017-01-06 18:18:01 --> Database Driver Class Initialized
INFO - 2017-01-06 18:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 18:18:02 --> Controller Class Initialized
INFO - 2017-01-06 18:18:02 --> Helper loaded: url_helper
INFO - 2017-01-06 18:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 18:18:02 --> Controller Class Initialized
INFO - 2017-01-06 18:18:02 --> Helper loaded: url_helper
DEBUG - 2017-01-06 18:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-01-06 18:18:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 18:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 18:18:02 --> Final output sent to browser
DEBUG - 2017-01-06 18:18:02 --> Total execution time: 1.7793
INFO - 2017-01-06 18:18:02 --> Final output sent to browser
DEBUG - 2017-01-06 18:18:02 --> Total execution time: 1.7792
INFO - 2017-01-06 20:41:01 --> Config Class Initialized
INFO - 2017-01-06 20:41:01 --> Hooks Class Initialized
DEBUG - 2017-01-06 20:41:02 --> UTF-8 Support Enabled
INFO - 2017-01-06 20:41:02 --> Utf8 Class Initialized
INFO - 2017-01-06 20:41:02 --> URI Class Initialized
INFO - 2017-01-06 20:41:02 --> Router Class Initialized
INFO - 2017-01-06 20:41:02 --> Output Class Initialized
INFO - 2017-01-06 20:41:02 --> Security Class Initialized
DEBUG - 2017-01-06 20:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 20:41:02 --> Input Class Initialized
INFO - 2017-01-06 20:41:02 --> Language Class Initialized
INFO - 2017-01-06 20:41:02 --> Loader Class Initialized
INFO - 2017-01-06 20:41:02 --> Database Driver Class Initialized
INFO - 2017-01-06 20:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 20:41:03 --> Controller Class Initialized
INFO - 2017-01-06 20:41:03 --> Helper loaded: url_helper
DEBUG - 2017-01-06 20:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 20:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 20:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 20:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 20:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 20:41:04 --> Final output sent to browser
DEBUG - 2017-01-06 20:41:04 --> Total execution time: 2.1510
INFO - 2017-01-06 20:41:04 --> Config Class Initialized
INFO - 2017-01-06 20:41:04 --> Hooks Class Initialized
DEBUG - 2017-01-06 20:41:04 --> UTF-8 Support Enabled
INFO - 2017-01-06 20:41:04 --> Utf8 Class Initialized
INFO - 2017-01-06 20:41:04 --> URI Class Initialized
DEBUG - 2017-01-06 20:41:04 --> No URI present. Default controller set.
INFO - 2017-01-06 20:41:04 --> Router Class Initialized
INFO - 2017-01-06 20:41:04 --> Output Class Initialized
INFO - 2017-01-06 20:41:04 --> Security Class Initialized
DEBUG - 2017-01-06 20:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 20:41:04 --> Input Class Initialized
INFO - 2017-01-06 20:41:04 --> Language Class Initialized
INFO - 2017-01-06 20:41:04 --> Loader Class Initialized
INFO - 2017-01-06 20:41:04 --> Database Driver Class Initialized
INFO - 2017-01-06 20:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 20:41:04 --> Controller Class Initialized
INFO - 2017-01-06 20:41:04 --> Helper loaded: url_helper
DEBUG - 2017-01-06 20:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 20:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 20:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 20:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 20:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 20:41:04 --> Final output sent to browser
DEBUG - 2017-01-06 20:41:04 --> Total execution time: 0.0621
INFO - 2017-01-06 22:25:56 --> Config Class Initialized
INFO - 2017-01-06 22:25:56 --> Hooks Class Initialized
DEBUG - 2017-01-06 22:25:56 --> UTF-8 Support Enabled
INFO - 2017-01-06 22:25:56 --> Utf8 Class Initialized
INFO - 2017-01-06 22:25:56 --> URI Class Initialized
DEBUG - 2017-01-06 22:25:56 --> No URI present. Default controller set.
INFO - 2017-01-06 22:25:56 --> Router Class Initialized
INFO - 2017-01-06 22:25:57 --> Output Class Initialized
INFO - 2017-01-06 22:25:57 --> Security Class Initialized
DEBUG - 2017-01-06 22:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 22:25:57 --> Input Class Initialized
INFO - 2017-01-06 22:25:57 --> Language Class Initialized
INFO - 2017-01-06 22:25:57 --> Loader Class Initialized
INFO - 2017-01-06 22:25:57 --> Database Driver Class Initialized
INFO - 2017-01-06 22:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 22:25:57 --> Controller Class Initialized
INFO - 2017-01-06 22:25:57 --> Helper loaded: url_helper
DEBUG - 2017-01-06 22:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 22:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 22:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 22:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 22:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 22:25:58 --> Final output sent to browser
DEBUG - 2017-01-06 22:25:58 --> Total execution time: 1.4572
INFO - 2017-01-06 22:27:13 --> Config Class Initialized
INFO - 2017-01-06 22:27:13 --> Hooks Class Initialized
DEBUG - 2017-01-06 22:27:13 --> UTF-8 Support Enabled
INFO - 2017-01-06 22:27:13 --> Utf8 Class Initialized
INFO - 2017-01-06 22:27:13 --> URI Class Initialized
INFO - 2017-01-06 22:27:13 --> Router Class Initialized
INFO - 2017-01-06 22:27:13 --> Output Class Initialized
INFO - 2017-01-06 22:27:13 --> Security Class Initialized
DEBUG - 2017-01-06 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 22:27:13 --> Input Class Initialized
INFO - 2017-01-06 22:27:13 --> Language Class Initialized
INFO - 2017-01-06 22:27:13 --> Loader Class Initialized
INFO - 2017-01-06 22:27:14 --> Database Driver Class Initialized
INFO - 2017-01-06 22:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 22:27:14 --> Controller Class Initialized
INFO - 2017-01-06 22:27:14 --> Helper loaded: url_helper
DEBUG - 2017-01-06 22:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 22:27:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-06 22:27:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-06 22:27:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-06 22:27:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-06 22:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 22:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 22:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 22:27:15 --> Final output sent to browser
DEBUG - 2017-01-06 22:27:15 --> Total execution time: 1.6902
INFO - 2017-01-06 22:29:01 --> Config Class Initialized
INFO - 2017-01-06 22:29:01 --> Hooks Class Initialized
DEBUG - 2017-01-06 22:29:01 --> UTF-8 Support Enabled
INFO - 2017-01-06 22:29:01 --> Utf8 Class Initialized
INFO - 2017-01-06 22:29:01 --> URI Class Initialized
INFO - 2017-01-06 22:29:01 --> Router Class Initialized
INFO - 2017-01-06 22:29:01 --> Output Class Initialized
INFO - 2017-01-06 22:29:01 --> Security Class Initialized
DEBUG - 2017-01-06 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 22:29:01 --> Input Class Initialized
INFO - 2017-01-06 22:29:01 --> Language Class Initialized
INFO - 2017-01-06 22:29:01 --> Loader Class Initialized
INFO - 2017-01-06 22:29:02 --> Database Driver Class Initialized
INFO - 2017-01-06 22:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 22:29:02 --> Controller Class Initialized
INFO - 2017-01-06 22:29:02 --> Helper loaded: url_helper
DEBUG - 2017-01-06 22:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-06 22:29:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-06 22:29:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-06 22:29:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-06 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 22:29:02 --> Final output sent to browser
DEBUG - 2017-01-06 22:29:02 --> Total execution time: 1.0704
INFO - 2017-01-06 23:12:14 --> Config Class Initialized
INFO - 2017-01-06 23:12:14 --> Hooks Class Initialized
DEBUG - 2017-01-06 23:12:14 --> UTF-8 Support Enabled
INFO - 2017-01-06 23:12:14 --> Utf8 Class Initialized
INFO - 2017-01-06 23:12:14 --> URI Class Initialized
INFO - 2017-01-06 23:12:14 --> Router Class Initialized
INFO - 2017-01-06 23:12:15 --> Output Class Initialized
INFO - 2017-01-06 23:12:15 --> Security Class Initialized
DEBUG - 2017-01-06 23:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 23:12:15 --> Input Class Initialized
INFO - 2017-01-06 23:12:15 --> Language Class Initialized
INFO - 2017-01-06 23:12:15 --> Loader Class Initialized
INFO - 2017-01-06 23:12:15 --> Database Driver Class Initialized
INFO - 2017-01-06 23:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 23:12:15 --> Controller Class Initialized
INFO - 2017-01-06 23:12:15 --> Helper loaded: url_helper
DEBUG - 2017-01-06 23:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 23:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 23:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 23:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 23:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 23:12:15 --> Final output sent to browser
DEBUG - 2017-01-06 23:12:15 --> Total execution time: 0.9527
INFO - 2017-01-06 23:12:18 --> Config Class Initialized
INFO - 2017-01-06 23:12:18 --> Hooks Class Initialized
DEBUG - 2017-01-06 23:12:19 --> UTF-8 Support Enabled
INFO - 2017-01-06 23:12:19 --> Utf8 Class Initialized
INFO - 2017-01-06 23:12:19 --> URI Class Initialized
DEBUG - 2017-01-06 23:12:19 --> No URI present. Default controller set.
INFO - 2017-01-06 23:12:19 --> Router Class Initialized
INFO - 2017-01-06 23:12:19 --> Output Class Initialized
INFO - 2017-01-06 23:12:19 --> Security Class Initialized
DEBUG - 2017-01-06 23:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 23:12:19 --> Input Class Initialized
INFO - 2017-01-06 23:12:19 --> Language Class Initialized
INFO - 2017-01-06 23:12:19 --> Loader Class Initialized
INFO - 2017-01-06 23:12:19 --> Database Driver Class Initialized
INFO - 2017-01-06 23:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 23:12:19 --> Controller Class Initialized
INFO - 2017-01-06 23:12:19 --> Helper loaded: url_helper
DEBUG - 2017-01-06 23:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 23:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 23:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 23:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 23:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 23:12:19 --> Final output sent to browser
DEBUG - 2017-01-06 23:12:19 --> Total execution time: 0.8443
INFO - 2017-01-06 23:24:32 --> Config Class Initialized
INFO - 2017-01-06 23:24:32 --> Hooks Class Initialized
DEBUG - 2017-01-06 23:24:33 --> UTF-8 Support Enabled
INFO - 2017-01-06 23:24:33 --> Utf8 Class Initialized
INFO - 2017-01-06 23:24:33 --> URI Class Initialized
INFO - 2017-01-06 23:24:33 --> Router Class Initialized
INFO - 2017-01-06 23:24:33 --> Output Class Initialized
INFO - 2017-01-06 23:24:33 --> Security Class Initialized
DEBUG - 2017-01-06 23:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-06 23:24:33 --> Input Class Initialized
INFO - 2017-01-06 23:24:33 --> Language Class Initialized
INFO - 2017-01-06 23:24:33 --> Loader Class Initialized
INFO - 2017-01-06 23:24:33 --> Database Driver Class Initialized
INFO - 2017-01-06 23:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-06 23:24:33 --> Controller Class Initialized
INFO - 2017-01-06 23:24:33 --> Helper loaded: url_helper
DEBUG - 2017-01-06 23:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-06 23:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-06 23:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-06 23:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-06 23:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-06 23:24:33 --> Final output sent to browser
DEBUG - 2017-01-06 23:24:33 --> Total execution time: 0.8315

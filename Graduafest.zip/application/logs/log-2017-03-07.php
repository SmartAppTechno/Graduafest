<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-07 00:07:46 --> Config Class Initialized
INFO - 2017-03-07 00:07:46 --> Hooks Class Initialized
DEBUG - 2017-03-07 00:07:46 --> UTF-8 Support Enabled
INFO - 2017-03-07 00:07:46 --> Utf8 Class Initialized
INFO - 2017-03-07 00:07:46 --> URI Class Initialized
INFO - 2017-03-07 00:07:46 --> Router Class Initialized
INFO - 2017-03-07 00:07:46 --> Output Class Initialized
INFO - 2017-03-07 00:07:47 --> Security Class Initialized
DEBUG - 2017-03-07 00:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 00:07:47 --> Input Class Initialized
INFO - 2017-03-07 00:07:47 --> Language Class Initialized
INFO - 2017-03-07 00:07:47 --> Loader Class Initialized
INFO - 2017-03-07 00:07:47 --> Database Driver Class Initialized
INFO - 2017-03-07 00:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 00:07:47 --> Controller Class Initialized
INFO - 2017-03-07 00:07:47 --> Helper loaded: url_helper
DEBUG - 2017-03-07 00:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 00:07:48 --> Final output sent to browser
DEBUG - 2017-03-07 00:07:48 --> Total execution time: 2.3304
INFO - 2017-03-07 00:07:52 --> Config Class Initialized
INFO - 2017-03-07 00:07:52 --> Hooks Class Initialized
DEBUG - 2017-03-07 00:07:52 --> UTF-8 Support Enabled
INFO - 2017-03-07 00:07:52 --> Utf8 Class Initialized
INFO - 2017-03-07 00:07:52 --> URI Class Initialized
DEBUG - 2017-03-07 00:07:52 --> No URI present. Default controller set.
INFO - 2017-03-07 00:07:52 --> Router Class Initialized
INFO - 2017-03-07 00:07:53 --> Output Class Initialized
INFO - 2017-03-07 00:07:53 --> Security Class Initialized
DEBUG - 2017-03-07 00:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 00:07:53 --> Input Class Initialized
INFO - 2017-03-07 00:07:53 --> Language Class Initialized
INFO - 2017-03-07 00:07:53 --> Loader Class Initialized
INFO - 2017-03-07 00:07:53 --> Database Driver Class Initialized
INFO - 2017-03-07 00:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 00:07:53 --> Controller Class Initialized
INFO - 2017-03-07 00:07:53 --> Helper loaded: url_helper
DEBUG - 2017-03-07 00:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 00:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 00:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 00:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 00:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 00:07:54 --> Final output sent to browser
DEBUG - 2017-03-07 00:07:54 --> Total execution time: 1.5003
INFO - 2017-03-07 00:36:58 --> Config Class Initialized
INFO - 2017-03-07 00:36:58 --> Hooks Class Initialized
DEBUG - 2017-03-07 00:36:58 --> UTF-8 Support Enabled
INFO - 2017-03-07 00:36:58 --> Utf8 Class Initialized
INFO - 2017-03-07 00:36:58 --> URI Class Initialized
DEBUG - 2017-03-07 00:36:58 --> No URI present. Default controller set.
INFO - 2017-03-07 00:36:58 --> Router Class Initialized
INFO - 2017-03-07 00:36:58 --> Output Class Initialized
INFO - 2017-03-07 00:36:58 --> Security Class Initialized
DEBUG - 2017-03-07 00:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 00:36:58 --> Input Class Initialized
INFO - 2017-03-07 00:36:58 --> Language Class Initialized
INFO - 2017-03-07 00:36:58 --> Loader Class Initialized
INFO - 2017-03-07 00:36:59 --> Database Driver Class Initialized
INFO - 2017-03-07 00:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 00:36:59 --> Controller Class Initialized
INFO - 2017-03-07 00:36:59 --> Helper loaded: url_helper
DEBUG - 2017-03-07 00:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 00:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 00:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 00:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 00:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 00:36:59 --> Final output sent to browser
DEBUG - 2017-03-07 00:36:59 --> Total execution time: 1.4749
INFO - 2017-03-07 00:37:09 --> Config Class Initialized
INFO - 2017-03-07 00:37:09 --> Hooks Class Initialized
DEBUG - 2017-03-07 00:37:09 --> UTF-8 Support Enabled
INFO - 2017-03-07 00:37:09 --> Utf8 Class Initialized
INFO - 2017-03-07 00:37:09 --> URI Class Initialized
INFO - 2017-03-07 00:37:09 --> Router Class Initialized
INFO - 2017-03-07 00:37:09 --> Output Class Initialized
INFO - 2017-03-07 00:37:09 --> Security Class Initialized
DEBUG - 2017-03-07 00:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 00:37:09 --> Input Class Initialized
INFO - 2017-03-07 00:37:09 --> Language Class Initialized
INFO - 2017-03-07 00:37:09 --> Loader Class Initialized
INFO - 2017-03-07 00:37:10 --> Database Driver Class Initialized
INFO - 2017-03-07 00:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 00:37:10 --> Controller Class Initialized
INFO - 2017-03-07 00:37:10 --> Helper loaded: url_helper
DEBUG - 2017-03-07 00:37:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-07 00:37:11 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-07 00:37:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kenia Diaz')
INFO - 2017-03-07 00:37:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-07 00:37:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-07 00:38:57 --> Config Class Initialized
INFO - 2017-03-07 00:38:57 --> Hooks Class Initialized
DEBUG - 2017-03-07 00:38:57 --> UTF-8 Support Enabled
INFO - 2017-03-07 00:38:57 --> Utf8 Class Initialized
INFO - 2017-03-07 00:38:57 --> URI Class Initialized
DEBUG - 2017-03-07 00:38:57 --> No URI present. Default controller set.
INFO - 2017-03-07 00:38:57 --> Router Class Initialized
INFO - 2017-03-07 00:38:57 --> Output Class Initialized
INFO - 2017-03-07 00:38:57 --> Security Class Initialized
DEBUG - 2017-03-07 00:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 00:38:57 --> Input Class Initialized
INFO - 2017-03-07 00:38:57 --> Language Class Initialized
INFO - 2017-03-07 00:38:58 --> Loader Class Initialized
INFO - 2017-03-07 00:38:58 --> Database Driver Class Initialized
INFO - 2017-03-07 00:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 00:38:58 --> Controller Class Initialized
INFO - 2017-03-07 00:38:58 --> Helper loaded: url_helper
DEBUG - 2017-03-07 00:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 00:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 00:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 00:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 00:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 00:38:58 --> Final output sent to browser
DEBUG - 2017-03-07 00:38:58 --> Total execution time: 1.2200
INFO - 2017-03-07 00:53:21 --> Config Class Initialized
INFO - 2017-03-07 00:53:21 --> Hooks Class Initialized
DEBUG - 2017-03-07 00:53:21 --> UTF-8 Support Enabled
INFO - 2017-03-07 00:53:21 --> Utf8 Class Initialized
INFO - 2017-03-07 00:53:21 --> URI Class Initialized
DEBUG - 2017-03-07 00:53:21 --> No URI present. Default controller set.
INFO - 2017-03-07 00:53:21 --> Router Class Initialized
INFO - 2017-03-07 00:53:21 --> Output Class Initialized
INFO - 2017-03-07 00:53:21 --> Security Class Initialized
DEBUG - 2017-03-07 00:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 00:53:22 --> Input Class Initialized
INFO - 2017-03-07 00:53:22 --> Language Class Initialized
INFO - 2017-03-07 00:53:22 --> Loader Class Initialized
INFO - 2017-03-07 00:53:22 --> Database Driver Class Initialized
INFO - 2017-03-07 00:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 00:53:22 --> Controller Class Initialized
INFO - 2017-03-07 00:53:22 --> Helper loaded: url_helper
DEBUG - 2017-03-07 00:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 00:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 00:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 00:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 00:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 00:53:23 --> Final output sent to browser
DEBUG - 2017-03-07 00:53:23 --> Total execution time: 1.2441
INFO - 2017-03-07 00:53:27 --> Config Class Initialized
INFO - 2017-03-07 00:53:27 --> Hooks Class Initialized
DEBUG - 2017-03-07 00:53:27 --> UTF-8 Support Enabled
INFO - 2017-03-07 00:53:27 --> Utf8 Class Initialized
INFO - 2017-03-07 00:53:27 --> URI Class Initialized
INFO - 2017-03-07 00:53:27 --> Router Class Initialized
INFO - 2017-03-07 00:53:27 --> Output Class Initialized
INFO - 2017-03-07 00:53:27 --> Security Class Initialized
DEBUG - 2017-03-07 00:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 00:53:27 --> Input Class Initialized
INFO - 2017-03-07 00:53:27 --> Language Class Initialized
INFO - 2017-03-07 00:53:27 --> Loader Class Initialized
INFO - 2017-03-07 00:53:27 --> Database Driver Class Initialized
INFO - 2017-03-07 00:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 00:53:27 --> Controller Class Initialized
INFO - 2017-03-07 00:53:27 --> Helper loaded: url_helper
DEBUG - 2017-03-07 00:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 00:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 00:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 00:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 00:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 00:53:28 --> Final output sent to browser
DEBUG - 2017-03-07 00:53:28 --> Total execution time: 1.2579
INFO - 2017-03-07 01:37:30 --> Config Class Initialized
INFO - 2017-03-07 01:37:30 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:37:30 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:37:31 --> Utf8 Class Initialized
INFO - 2017-03-07 01:37:31 --> URI Class Initialized
DEBUG - 2017-03-07 01:37:31 --> No URI present. Default controller set.
INFO - 2017-03-07 01:37:31 --> Router Class Initialized
INFO - 2017-03-07 01:37:31 --> Output Class Initialized
INFO - 2017-03-07 01:37:31 --> Security Class Initialized
DEBUG - 2017-03-07 01:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:37:31 --> Input Class Initialized
INFO - 2017-03-07 01:37:31 --> Language Class Initialized
INFO - 2017-03-07 01:37:31 --> Loader Class Initialized
INFO - 2017-03-07 01:37:31 --> Database Driver Class Initialized
INFO - 2017-03-07 01:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:37:32 --> Controller Class Initialized
INFO - 2017-03-07 01:37:32 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:37:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:37:33 --> Final output sent to browser
DEBUG - 2017-03-07 01:37:33 --> Total execution time: 2.6001
INFO - 2017-03-07 01:37:40 --> Config Class Initialized
INFO - 2017-03-07 01:37:40 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:37:40 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:37:40 --> Utf8 Class Initialized
INFO - 2017-03-07 01:37:40 --> URI Class Initialized
INFO - 2017-03-07 01:37:40 --> Router Class Initialized
INFO - 2017-03-07 01:37:40 --> Output Class Initialized
INFO - 2017-03-07 01:37:40 --> Security Class Initialized
DEBUG - 2017-03-07 01:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:37:40 --> Input Class Initialized
INFO - 2017-03-07 01:37:40 --> Language Class Initialized
INFO - 2017-03-07 01:37:40 --> Loader Class Initialized
INFO - 2017-03-07 01:37:41 --> Database Driver Class Initialized
INFO - 2017-03-07 01:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:37:41 --> Controller Class Initialized
INFO - 2017-03-07 01:37:41 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:37:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:37:41 --> Final output sent to browser
DEBUG - 2017-03-07 01:37:42 --> Total execution time: 1.9676
INFO - 2017-03-07 01:43:59 --> Config Class Initialized
INFO - 2017-03-07 01:43:59 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:43:59 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:43:59 --> Utf8 Class Initialized
INFO - 2017-03-07 01:43:59 --> URI Class Initialized
DEBUG - 2017-03-07 01:43:59 --> No URI present. Default controller set.
INFO - 2017-03-07 01:43:59 --> Router Class Initialized
INFO - 2017-03-07 01:43:59 --> Output Class Initialized
INFO - 2017-03-07 01:43:59 --> Security Class Initialized
DEBUG - 2017-03-07 01:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:43:59 --> Input Class Initialized
INFO - 2017-03-07 01:43:59 --> Language Class Initialized
INFO - 2017-03-07 01:43:59 --> Loader Class Initialized
INFO - 2017-03-07 01:44:00 --> Database Driver Class Initialized
INFO - 2017-03-07 01:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:44:00 --> Controller Class Initialized
INFO - 2017-03-07 01:44:00 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:44:00 --> Final output sent to browser
DEBUG - 2017-03-07 01:44:00 --> Total execution time: 1.4841
INFO - 2017-03-07 01:44:04 --> Config Class Initialized
INFO - 2017-03-07 01:44:04 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:44:04 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:44:04 --> Utf8 Class Initialized
INFO - 2017-03-07 01:44:04 --> URI Class Initialized
INFO - 2017-03-07 01:44:04 --> Router Class Initialized
INFO - 2017-03-07 01:44:04 --> Output Class Initialized
INFO - 2017-03-07 01:44:04 --> Security Class Initialized
DEBUG - 2017-03-07 01:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:44:04 --> Input Class Initialized
INFO - 2017-03-07 01:44:04 --> Language Class Initialized
INFO - 2017-03-07 01:44:04 --> Loader Class Initialized
INFO - 2017-03-07 01:44:04 --> Database Driver Class Initialized
INFO - 2017-03-07 01:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:44:04 --> Controller Class Initialized
INFO - 2017-03-07 01:44:04 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:44:04 --> Final output sent to browser
DEBUG - 2017-03-07 01:44:04 --> Total execution time: 0.0145
INFO - 2017-03-07 01:44:14 --> Config Class Initialized
INFO - 2017-03-07 01:44:14 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:44:14 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:44:14 --> Utf8 Class Initialized
INFO - 2017-03-07 01:44:14 --> URI Class Initialized
INFO - 2017-03-07 01:44:14 --> Router Class Initialized
INFO - 2017-03-07 01:44:14 --> Output Class Initialized
INFO - 2017-03-07 01:44:14 --> Security Class Initialized
DEBUG - 2017-03-07 01:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:44:14 --> Input Class Initialized
INFO - 2017-03-07 01:44:14 --> Language Class Initialized
INFO - 2017-03-07 01:44:14 --> Loader Class Initialized
INFO - 2017-03-07 01:44:14 --> Database Driver Class Initialized
INFO - 2017-03-07 01:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:44:14 --> Controller Class Initialized
INFO - 2017-03-07 01:44:14 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:44:16 --> Config Class Initialized
INFO - 2017-03-07 01:44:16 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:44:16 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:44:16 --> Utf8 Class Initialized
INFO - 2017-03-07 01:44:16 --> URI Class Initialized
INFO - 2017-03-07 01:44:16 --> Router Class Initialized
INFO - 2017-03-07 01:44:16 --> Output Class Initialized
INFO - 2017-03-07 01:44:16 --> Security Class Initialized
DEBUG - 2017-03-07 01:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:44:16 --> Input Class Initialized
INFO - 2017-03-07 01:44:16 --> Language Class Initialized
INFO - 2017-03-07 01:44:16 --> Loader Class Initialized
INFO - 2017-03-07 01:44:16 --> Database Driver Class Initialized
INFO - 2017-03-07 01:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:44:16 --> Controller Class Initialized
INFO - 2017-03-07 01:44:16 --> Helper loaded: date_helper
DEBUG - 2017-03-07 01:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:44:16 --> Helper loaded: url_helper
INFO - 2017-03-07 01:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 01:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 01:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 01:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:44:16 --> Final output sent to browser
DEBUG - 2017-03-07 01:44:16 --> Total execution time: 0.1594
INFO - 2017-03-07 01:44:17 --> Config Class Initialized
INFO - 2017-03-07 01:44:17 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:44:17 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:44:17 --> Utf8 Class Initialized
INFO - 2017-03-07 01:44:17 --> URI Class Initialized
INFO - 2017-03-07 01:44:17 --> Router Class Initialized
INFO - 2017-03-07 01:44:17 --> Output Class Initialized
INFO - 2017-03-07 01:44:17 --> Security Class Initialized
DEBUG - 2017-03-07 01:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:44:17 --> Input Class Initialized
INFO - 2017-03-07 01:44:17 --> Language Class Initialized
INFO - 2017-03-07 01:44:17 --> Loader Class Initialized
INFO - 2017-03-07 01:44:17 --> Database Driver Class Initialized
INFO - 2017-03-07 01:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:44:17 --> Controller Class Initialized
INFO - 2017-03-07 01:44:17 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:44:17 --> Final output sent to browser
DEBUG - 2017-03-07 01:44:17 --> Total execution time: 0.0134
INFO - 2017-03-07 01:44:19 --> Config Class Initialized
INFO - 2017-03-07 01:44:19 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:44:19 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:44:19 --> Utf8 Class Initialized
INFO - 2017-03-07 01:44:19 --> URI Class Initialized
DEBUG - 2017-03-07 01:44:19 --> No URI present. Default controller set.
INFO - 2017-03-07 01:44:19 --> Router Class Initialized
INFO - 2017-03-07 01:44:19 --> Output Class Initialized
INFO - 2017-03-07 01:44:19 --> Security Class Initialized
DEBUG - 2017-03-07 01:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:44:19 --> Input Class Initialized
INFO - 2017-03-07 01:44:19 --> Language Class Initialized
INFO - 2017-03-07 01:44:19 --> Loader Class Initialized
INFO - 2017-03-07 01:44:19 --> Database Driver Class Initialized
INFO - 2017-03-07 01:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:44:19 --> Controller Class Initialized
INFO - 2017-03-07 01:44:19 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:44:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:44:19 --> Final output sent to browser
DEBUG - 2017-03-07 01:44:19 --> Total execution time: 0.0132
INFO - 2017-03-07 01:44:20 --> Config Class Initialized
INFO - 2017-03-07 01:44:20 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:44:20 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:44:20 --> Utf8 Class Initialized
INFO - 2017-03-07 01:44:20 --> URI Class Initialized
INFO - 2017-03-07 01:44:20 --> Router Class Initialized
INFO - 2017-03-07 01:44:20 --> Output Class Initialized
INFO - 2017-03-07 01:44:20 --> Security Class Initialized
DEBUG - 2017-03-07 01:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:44:20 --> Input Class Initialized
INFO - 2017-03-07 01:44:20 --> Language Class Initialized
INFO - 2017-03-07 01:44:20 --> Loader Class Initialized
INFO - 2017-03-07 01:44:20 --> Database Driver Class Initialized
INFO - 2017-03-07 01:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:44:20 --> Controller Class Initialized
INFO - 2017-03-07 01:44:20 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:44:20 --> Final output sent to browser
DEBUG - 2017-03-07 01:44:20 --> Total execution time: 0.0134
INFO - 2017-03-07 01:50:35 --> Config Class Initialized
INFO - 2017-03-07 01:50:35 --> Hooks Class Initialized
DEBUG - 2017-03-07 01:50:35 --> UTF-8 Support Enabled
INFO - 2017-03-07 01:50:35 --> Utf8 Class Initialized
INFO - 2017-03-07 01:50:35 --> URI Class Initialized
DEBUG - 2017-03-07 01:50:35 --> No URI present. Default controller set.
INFO - 2017-03-07 01:50:35 --> Router Class Initialized
INFO - 2017-03-07 01:50:35 --> Output Class Initialized
INFO - 2017-03-07 01:50:35 --> Security Class Initialized
DEBUG - 2017-03-07 01:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 01:50:35 --> Input Class Initialized
INFO - 2017-03-07 01:50:36 --> Language Class Initialized
INFO - 2017-03-07 01:50:36 --> Loader Class Initialized
INFO - 2017-03-07 01:50:36 --> Database Driver Class Initialized
INFO - 2017-03-07 01:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 01:50:36 --> Controller Class Initialized
INFO - 2017-03-07 01:50:36 --> Helper loaded: url_helper
DEBUG - 2017-03-07 01:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 01:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 01:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 01:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 01:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 01:50:36 --> Final output sent to browser
DEBUG - 2017-03-07 01:50:36 --> Total execution time: 1.7842
INFO - 2017-03-07 02:25:49 --> Config Class Initialized
INFO - 2017-03-07 02:25:49 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:25:49 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:25:49 --> Utf8 Class Initialized
INFO - 2017-03-07 02:25:49 --> URI Class Initialized
INFO - 2017-03-07 02:25:49 --> Router Class Initialized
INFO - 2017-03-07 02:25:49 --> Output Class Initialized
INFO - 2017-03-07 02:25:49 --> Security Class Initialized
DEBUG - 2017-03-07 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:25:49 --> Input Class Initialized
INFO - 2017-03-07 02:25:49 --> Language Class Initialized
INFO - 2017-03-07 02:25:49 --> Loader Class Initialized
INFO - 2017-03-07 02:25:50 --> Database Driver Class Initialized
INFO - 2017-03-07 02:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:25:50 --> Controller Class Initialized
INFO - 2017-03-07 02:25:50 --> Helper loaded: date_helper
DEBUG - 2017-03-07 02:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:25:50 --> Helper loaded: url_helper
INFO - 2017-03-07 02:25:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 02:25:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 02:25:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 02:25:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 02:25:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:25:50 --> Final output sent to browser
DEBUG - 2017-03-07 02:25:50 --> Total execution time: 1.6593
INFO - 2017-03-07 02:25:52 --> Config Class Initialized
INFO - 2017-03-07 02:25:52 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:25:52 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:25:52 --> Utf8 Class Initialized
INFO - 2017-03-07 02:25:52 --> URI Class Initialized
INFO - 2017-03-07 02:25:52 --> Router Class Initialized
INFO - 2017-03-07 02:25:52 --> Output Class Initialized
INFO - 2017-03-07 02:25:52 --> Security Class Initialized
DEBUG - 2017-03-07 02:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:25:52 --> Input Class Initialized
INFO - 2017-03-07 02:25:52 --> Language Class Initialized
INFO - 2017-03-07 02:25:52 --> Loader Class Initialized
INFO - 2017-03-07 02:25:52 --> Database Driver Class Initialized
INFO - 2017-03-07 02:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:25:52 --> Controller Class Initialized
INFO - 2017-03-07 02:25:52 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:25:52 --> Final output sent to browser
DEBUG - 2017-03-07 02:25:52 --> Total execution time: 0.3768
INFO - 2017-03-07 02:29:10 --> Config Class Initialized
INFO - 2017-03-07 02:29:10 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:29:11 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:29:11 --> Utf8 Class Initialized
INFO - 2017-03-07 02:29:11 --> URI Class Initialized
DEBUG - 2017-03-07 02:29:11 --> No URI present. Default controller set.
INFO - 2017-03-07 02:29:12 --> Router Class Initialized
INFO - 2017-03-07 02:29:12 --> Output Class Initialized
INFO - 2017-03-07 02:29:12 --> Security Class Initialized
DEBUG - 2017-03-07 02:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:29:12 --> Input Class Initialized
INFO - 2017-03-07 02:29:12 --> Language Class Initialized
INFO - 2017-03-07 02:29:12 --> Loader Class Initialized
INFO - 2017-03-07 02:29:12 --> Database Driver Class Initialized
INFO - 2017-03-07 02:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:29:12 --> Controller Class Initialized
INFO - 2017-03-07 02:29:12 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 02:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 02:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 02:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:29:13 --> Final output sent to browser
DEBUG - 2017-03-07 02:29:13 --> Total execution time: 3.4874
INFO - 2017-03-07 02:29:37 --> Config Class Initialized
INFO - 2017-03-07 02:29:37 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:29:37 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:29:37 --> Utf8 Class Initialized
INFO - 2017-03-07 02:29:37 --> URI Class Initialized
INFO - 2017-03-07 02:29:37 --> Router Class Initialized
INFO - 2017-03-07 02:29:38 --> Output Class Initialized
INFO - 2017-03-07 02:29:38 --> Security Class Initialized
DEBUG - 2017-03-07 02:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:29:38 --> Input Class Initialized
INFO - 2017-03-07 02:29:38 --> Language Class Initialized
INFO - 2017-03-07 02:29:38 --> Loader Class Initialized
INFO - 2017-03-07 02:29:38 --> Database Driver Class Initialized
INFO - 2017-03-07 02:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:29:38 --> Controller Class Initialized
INFO - 2017-03-07 02:29:38 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:29:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 02:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 02:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 02:29:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:29:39 --> Final output sent to browser
DEBUG - 2017-03-07 02:29:39 --> Total execution time: 1.4732
INFO - 2017-03-07 02:29:57 --> Config Class Initialized
INFO - 2017-03-07 02:29:57 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:29:58 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:29:58 --> Utf8 Class Initialized
INFO - 2017-03-07 02:29:58 --> URI Class Initialized
INFO - 2017-03-07 02:29:58 --> Router Class Initialized
INFO - 2017-03-07 02:29:58 --> Output Class Initialized
INFO - 2017-03-07 02:29:58 --> Security Class Initialized
DEBUG - 2017-03-07 02:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:29:58 --> Input Class Initialized
INFO - 2017-03-07 02:29:58 --> Language Class Initialized
INFO - 2017-03-07 02:29:58 --> Loader Class Initialized
INFO - 2017-03-07 02:29:58 --> Database Driver Class Initialized
INFO - 2017-03-07 02:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:29:59 --> Controller Class Initialized
INFO - 2017-03-07 02:29:59 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-07 02:29:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-07 02:29:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-07 02:29:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-07 02:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 02:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 02:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:29:59 --> Final output sent to browser
DEBUG - 2017-03-07 02:29:59 --> Total execution time: 1.7675
INFO - 2017-03-07 02:30:09 --> Config Class Initialized
INFO - 2017-03-07 02:30:09 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:30:09 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:30:09 --> Utf8 Class Initialized
INFO - 2017-03-07 02:30:09 --> URI Class Initialized
INFO - 2017-03-07 02:30:09 --> Router Class Initialized
INFO - 2017-03-07 02:30:09 --> Output Class Initialized
INFO - 2017-03-07 02:30:09 --> Security Class Initialized
DEBUG - 2017-03-07 02:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:30:09 --> Input Class Initialized
INFO - 2017-03-07 02:30:09 --> Language Class Initialized
INFO - 2017-03-07 02:30:09 --> Loader Class Initialized
INFO - 2017-03-07 02:30:10 --> Database Driver Class Initialized
INFO - 2017-03-07 02:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:30:10 --> Controller Class Initialized
INFO - 2017-03-07 02:30:10 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 02:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 02:30:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 02:30:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:30:11 --> Final output sent to browser
DEBUG - 2017-03-07 02:30:11 --> Total execution time: 1.8090
INFO - 2017-03-07 02:30:18 --> Config Class Initialized
INFO - 2017-03-07 02:30:18 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:30:18 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:30:18 --> Utf8 Class Initialized
INFO - 2017-03-07 02:30:18 --> URI Class Initialized
INFO - 2017-03-07 02:30:18 --> Router Class Initialized
INFO - 2017-03-07 02:30:19 --> Output Class Initialized
INFO - 2017-03-07 02:30:19 --> Security Class Initialized
DEBUG - 2017-03-07 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:30:19 --> Input Class Initialized
INFO - 2017-03-07 02:30:19 --> Language Class Initialized
INFO - 2017-03-07 02:30:19 --> Loader Class Initialized
INFO - 2017-03-07 02:30:19 --> Database Driver Class Initialized
INFO - 2017-03-07 02:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:30:19 --> Controller Class Initialized
INFO - 2017-03-07 02:30:19 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:30:30 --> Config Class Initialized
INFO - 2017-03-07 02:30:30 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:30:31 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:30:31 --> Utf8 Class Initialized
INFO - 2017-03-07 02:30:31 --> URI Class Initialized
INFO - 2017-03-07 02:30:31 --> Router Class Initialized
INFO - 2017-03-07 02:30:31 --> Output Class Initialized
INFO - 2017-03-07 02:30:31 --> Security Class Initialized
DEBUG - 2017-03-07 02:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:30:31 --> Input Class Initialized
INFO - 2017-03-07 02:30:31 --> Language Class Initialized
INFO - 2017-03-07 02:30:31 --> Loader Class Initialized
INFO - 2017-03-07 02:30:31 --> Database Driver Class Initialized
INFO - 2017-03-07 02:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:30:31 --> Controller Class Initialized
INFO - 2017-03-07 02:30:31 --> Helper loaded: date_helper
DEBUG - 2017-03-07 02:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:30:31 --> Helper loaded: url_helper
INFO - 2017-03-07 02:30:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 02:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 02:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 02:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 02:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:30:32 --> Final output sent to browser
DEBUG - 2017-03-07 02:30:32 --> Total execution time: 1.3510
INFO - 2017-03-07 02:30:33 --> Config Class Initialized
INFO - 2017-03-07 02:30:33 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:30:33 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:30:33 --> Utf8 Class Initialized
INFO - 2017-03-07 02:30:33 --> URI Class Initialized
INFO - 2017-03-07 02:30:33 --> Router Class Initialized
INFO - 2017-03-07 02:30:33 --> Output Class Initialized
INFO - 2017-03-07 02:30:33 --> Security Class Initialized
DEBUG - 2017-03-07 02:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:30:33 --> Input Class Initialized
INFO - 2017-03-07 02:30:33 --> Language Class Initialized
INFO - 2017-03-07 02:30:34 --> Loader Class Initialized
INFO - 2017-03-07 02:30:34 --> Database Driver Class Initialized
INFO - 2017-03-07 02:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:30:34 --> Controller Class Initialized
INFO - 2017-03-07 02:30:34 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 02:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 02:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 02:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 02:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 02:30:34 --> Final output sent to browser
DEBUG - 2017-03-07 02:30:34 --> Total execution time: 0.4445
INFO - 2017-03-07 02:30:38 --> Config Class Initialized
INFO - 2017-03-07 02:30:38 --> Hooks Class Initialized
DEBUG - 2017-03-07 02:30:38 --> UTF-8 Support Enabled
INFO - 2017-03-07 02:30:38 --> Utf8 Class Initialized
INFO - 2017-03-07 02:30:38 --> URI Class Initialized
INFO - 2017-03-07 02:30:38 --> Router Class Initialized
INFO - 2017-03-07 02:30:38 --> Output Class Initialized
INFO - 2017-03-07 02:30:38 --> Security Class Initialized
DEBUG - 2017-03-07 02:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 02:30:38 --> Input Class Initialized
INFO - 2017-03-07 02:30:38 --> Language Class Initialized
INFO - 2017-03-07 02:30:38 --> Loader Class Initialized
INFO - 2017-03-07 02:30:38 --> Database Driver Class Initialized
INFO - 2017-03-07 02:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 02:30:39 --> Controller Class Initialized
INFO - 2017-03-07 02:30:39 --> Helper loaded: url_helper
DEBUG - 2017-03-07 02:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:37:35 --> Config Class Initialized
INFO - 2017-03-07 03:37:35 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:37:36 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:37:36 --> Utf8 Class Initialized
INFO - 2017-03-07 03:37:36 --> URI Class Initialized
DEBUG - 2017-03-07 03:37:36 --> No URI present. Default controller set.
INFO - 2017-03-07 03:37:36 --> Router Class Initialized
INFO - 2017-03-07 03:37:36 --> Output Class Initialized
INFO - 2017-03-07 03:37:36 --> Security Class Initialized
DEBUG - 2017-03-07 03:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:37:36 --> Input Class Initialized
INFO - 2017-03-07 03:37:36 --> Language Class Initialized
INFO - 2017-03-07 03:37:36 --> Loader Class Initialized
INFO - 2017-03-07 03:37:36 --> Database Driver Class Initialized
INFO - 2017-03-07 03:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:37:37 --> Controller Class Initialized
INFO - 2017-03-07 03:37:37 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:37:37 --> Final output sent to browser
DEBUG - 2017-03-07 03:37:37 --> Total execution time: 1.8863
INFO - 2017-03-07 03:37:44 --> Config Class Initialized
INFO - 2017-03-07 03:37:44 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:37:44 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:37:44 --> Utf8 Class Initialized
INFO - 2017-03-07 03:37:44 --> URI Class Initialized
INFO - 2017-03-07 03:37:44 --> Router Class Initialized
INFO - 2017-03-07 03:37:44 --> Output Class Initialized
INFO - 2017-03-07 03:37:44 --> Security Class Initialized
DEBUG - 2017-03-07 03:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:37:44 --> Input Class Initialized
INFO - 2017-03-07 03:37:44 --> Language Class Initialized
INFO - 2017-03-07 03:37:45 --> Loader Class Initialized
INFO - 2017-03-07 03:37:45 --> Database Driver Class Initialized
INFO - 2017-03-07 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:37:45 --> Controller Class Initialized
INFO - 2017-03-07 03:37:45 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:37:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:37:45 --> Final output sent to browser
DEBUG - 2017-03-07 03:37:45 --> Total execution time: 1.2577
INFO - 2017-03-07 03:37:50 --> Config Class Initialized
INFO - 2017-03-07 03:37:50 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:37:50 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:37:50 --> Utf8 Class Initialized
INFO - 2017-03-07 03:37:50 --> URI Class Initialized
INFO - 2017-03-07 03:37:51 --> Router Class Initialized
INFO - 2017-03-07 03:37:51 --> Output Class Initialized
INFO - 2017-03-07 03:37:51 --> Security Class Initialized
DEBUG - 2017-03-07 03:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:37:51 --> Input Class Initialized
INFO - 2017-03-07 03:37:51 --> Language Class Initialized
INFO - 2017-03-07 03:37:51 --> Loader Class Initialized
INFO - 2017-03-07 03:37:51 --> Database Driver Class Initialized
INFO - 2017-03-07 03:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:37:51 --> Controller Class Initialized
INFO - 2017-03-07 03:37:51 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:37:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-07 03:37:53 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-07 03:37:53 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-03-07 03:37:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-07 03:37:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-07 03:37:54 --> Config Class Initialized
INFO - 2017-03-07 03:37:54 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:37:54 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:37:54 --> Utf8 Class Initialized
INFO - 2017-03-07 03:37:54 --> URI Class Initialized
INFO - 2017-03-07 03:37:54 --> Router Class Initialized
INFO - 2017-03-07 03:37:54 --> Output Class Initialized
INFO - 2017-03-07 03:37:54 --> Security Class Initialized
DEBUG - 2017-03-07 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:37:54 --> Input Class Initialized
INFO - 2017-03-07 03:37:54 --> Language Class Initialized
INFO - 2017-03-07 03:37:54 --> Loader Class Initialized
INFO - 2017-03-07 03:37:54 --> Database Driver Class Initialized
INFO - 2017-03-07 03:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:37:54 --> Controller Class Initialized
INFO - 2017-03-07 03:37:54 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:37:55 --> Final output sent to browser
DEBUG - 2017-03-07 03:37:55 --> Total execution time: 1.2820
INFO - 2017-03-07 03:47:44 --> Config Class Initialized
INFO - 2017-03-07 03:47:44 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:47:44 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:47:44 --> Utf8 Class Initialized
INFO - 2017-03-07 03:47:44 --> URI Class Initialized
DEBUG - 2017-03-07 03:47:44 --> No URI present. Default controller set.
INFO - 2017-03-07 03:47:44 --> Router Class Initialized
INFO - 2017-03-07 03:47:44 --> Output Class Initialized
INFO - 2017-03-07 03:47:44 --> Security Class Initialized
DEBUG - 2017-03-07 03:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:47:44 --> Input Class Initialized
INFO - 2017-03-07 03:47:44 --> Language Class Initialized
INFO - 2017-03-07 03:47:44 --> Loader Class Initialized
INFO - 2017-03-07 03:47:45 --> Database Driver Class Initialized
INFO - 2017-03-07 03:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:47:45 --> Controller Class Initialized
INFO - 2017-03-07 03:47:45 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:47:46 --> Final output sent to browser
DEBUG - 2017-03-07 03:47:46 --> Total execution time: 3.0733
INFO - 2017-03-07 03:48:10 --> Config Class Initialized
INFO - 2017-03-07 03:48:10 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:48:11 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:48:11 --> Utf8 Class Initialized
INFO - 2017-03-07 03:48:11 --> URI Class Initialized
INFO - 2017-03-07 03:48:11 --> Router Class Initialized
INFO - 2017-03-07 03:48:11 --> Output Class Initialized
INFO - 2017-03-07 03:48:11 --> Security Class Initialized
DEBUG - 2017-03-07 03:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:48:11 --> Input Class Initialized
INFO - 2017-03-07 03:48:11 --> Language Class Initialized
INFO - 2017-03-07 03:48:11 --> Loader Class Initialized
INFO - 2017-03-07 03:48:11 --> Database Driver Class Initialized
INFO - 2017-03-07 03:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:48:11 --> Controller Class Initialized
INFO - 2017-03-07 03:48:11 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:48:13 --> Config Class Initialized
INFO - 2017-03-07 03:48:13 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:48:13 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:48:13 --> Utf8 Class Initialized
INFO - 2017-03-07 03:48:13 --> URI Class Initialized
INFO - 2017-03-07 03:48:13 --> Router Class Initialized
INFO - 2017-03-07 03:48:13 --> Output Class Initialized
INFO - 2017-03-07 03:48:13 --> Security Class Initialized
DEBUG - 2017-03-07 03:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:48:13 --> Input Class Initialized
INFO - 2017-03-07 03:48:13 --> Language Class Initialized
INFO - 2017-03-07 03:48:13 --> Loader Class Initialized
INFO - 2017-03-07 03:48:13 --> Database Driver Class Initialized
INFO - 2017-03-07 03:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:48:13 --> Controller Class Initialized
INFO - 2017-03-07 03:48:13 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:48:13 --> Final output sent to browser
DEBUG - 2017-03-07 03:48:13 --> Total execution time: 0.2794
INFO - 2017-03-07 03:48:14 --> Config Class Initialized
INFO - 2017-03-07 03:48:14 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:48:14 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:48:14 --> Utf8 Class Initialized
INFO - 2017-03-07 03:48:14 --> URI Class Initialized
INFO - 2017-03-07 03:48:14 --> Router Class Initialized
INFO - 2017-03-07 03:48:14 --> Output Class Initialized
INFO - 2017-03-07 03:48:14 --> Security Class Initialized
DEBUG - 2017-03-07 03:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:48:14 --> Input Class Initialized
INFO - 2017-03-07 03:48:14 --> Language Class Initialized
INFO - 2017-03-07 03:48:14 --> Loader Class Initialized
INFO - 2017-03-07 03:48:14 --> Database Driver Class Initialized
INFO - 2017-03-07 03:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:48:14 --> Controller Class Initialized
INFO - 2017-03-07 03:48:14 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:48:17 --> Config Class Initialized
INFO - 2017-03-07 03:48:17 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:48:17 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:48:17 --> Utf8 Class Initialized
INFO - 2017-03-07 03:48:17 --> URI Class Initialized
INFO - 2017-03-07 03:48:17 --> Router Class Initialized
INFO - 2017-03-07 03:48:17 --> Output Class Initialized
INFO - 2017-03-07 03:48:17 --> Security Class Initialized
DEBUG - 2017-03-07 03:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:48:17 --> Input Class Initialized
INFO - 2017-03-07 03:48:17 --> Language Class Initialized
INFO - 2017-03-07 03:48:17 --> Loader Class Initialized
INFO - 2017-03-07 03:48:17 --> Database Driver Class Initialized
INFO - 2017-03-07 03:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:48:17 --> Controller Class Initialized
INFO - 2017-03-07 03:48:17 --> Helper loaded: date_helper
DEBUG - 2017-03-07 03:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:48:17 --> Helper loaded: url_helper
INFO - 2017-03-07 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 03:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:48:17 --> Final output sent to browser
DEBUG - 2017-03-07 03:48:17 --> Total execution time: 0.1261
INFO - 2017-03-07 03:48:28 --> Config Class Initialized
INFO - 2017-03-07 03:48:28 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:48:29 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:48:29 --> Utf8 Class Initialized
INFO - 2017-03-07 03:48:29 --> URI Class Initialized
INFO - 2017-03-07 03:48:29 --> Router Class Initialized
INFO - 2017-03-07 03:48:29 --> Output Class Initialized
INFO - 2017-03-07 03:48:29 --> Security Class Initialized
DEBUG - 2017-03-07 03:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:48:29 --> Input Class Initialized
INFO - 2017-03-07 03:48:29 --> Language Class Initialized
INFO - 2017-03-07 03:48:29 --> Loader Class Initialized
INFO - 2017-03-07 03:48:29 --> Database Driver Class Initialized
INFO - 2017-03-07 03:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:48:29 --> Controller Class Initialized
INFO - 2017-03-07 03:48:29 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:48:29 --> Final output sent to browser
DEBUG - 2017-03-07 03:48:29 --> Total execution time: 0.4095
INFO - 2017-03-07 03:48:45 --> Config Class Initialized
INFO - 2017-03-07 03:48:45 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:48:45 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:48:45 --> Utf8 Class Initialized
INFO - 2017-03-07 03:48:45 --> URI Class Initialized
DEBUG - 2017-03-07 03:48:45 --> No URI present. Default controller set.
INFO - 2017-03-07 03:48:45 --> Router Class Initialized
INFO - 2017-03-07 03:48:45 --> Output Class Initialized
INFO - 2017-03-07 03:48:45 --> Security Class Initialized
DEBUG - 2017-03-07 03:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:48:45 --> Input Class Initialized
INFO - 2017-03-07 03:48:45 --> Language Class Initialized
INFO - 2017-03-07 03:48:46 --> Loader Class Initialized
INFO - 2017-03-07 03:48:46 --> Database Driver Class Initialized
INFO - 2017-03-07 03:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:48:46 --> Controller Class Initialized
INFO - 2017-03-07 03:48:46 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:48:46 --> Final output sent to browser
DEBUG - 2017-03-07 03:48:46 --> Total execution time: 1.4706
INFO - 2017-03-07 03:53:05 --> Config Class Initialized
INFO - 2017-03-07 03:53:05 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:53:06 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:53:06 --> Utf8 Class Initialized
INFO - 2017-03-07 03:53:06 --> URI Class Initialized
DEBUG - 2017-03-07 03:53:06 --> No URI present. Default controller set.
INFO - 2017-03-07 03:53:06 --> Router Class Initialized
INFO - 2017-03-07 03:53:06 --> Output Class Initialized
INFO - 2017-03-07 03:53:06 --> Security Class Initialized
DEBUG - 2017-03-07 03:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:53:06 --> Input Class Initialized
INFO - 2017-03-07 03:53:06 --> Language Class Initialized
INFO - 2017-03-07 03:53:06 --> Loader Class Initialized
INFO - 2017-03-07 03:53:06 --> Database Driver Class Initialized
INFO - 2017-03-07 03:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:53:07 --> Controller Class Initialized
INFO - 2017-03-07 03:53:07 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:53:07 --> Final output sent to browser
DEBUG - 2017-03-07 03:53:07 --> Total execution time: 1.7454
INFO - 2017-03-07 03:53:32 --> Config Class Initialized
INFO - 2017-03-07 03:53:32 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:53:32 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:53:32 --> Utf8 Class Initialized
INFO - 2017-03-07 03:53:32 --> URI Class Initialized
INFO - 2017-03-07 03:53:32 --> Router Class Initialized
INFO - 2017-03-07 03:53:32 --> Output Class Initialized
INFO - 2017-03-07 03:53:32 --> Security Class Initialized
DEBUG - 2017-03-07 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:53:32 --> Input Class Initialized
INFO - 2017-03-07 03:53:32 --> Language Class Initialized
INFO - 2017-03-07 03:53:32 --> Loader Class Initialized
INFO - 2017-03-07 03:53:32 --> Database Driver Class Initialized
INFO - 2017-03-07 03:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:53:32 --> Controller Class Initialized
INFO - 2017-03-07 03:53:32 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:53:32 --> Final output sent to browser
DEBUG - 2017-03-07 03:53:32 --> Total execution time: 0.0134
INFO - 2017-03-07 03:54:41 --> Config Class Initialized
INFO - 2017-03-07 03:54:41 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:54:41 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:54:41 --> Utf8 Class Initialized
INFO - 2017-03-07 03:54:41 --> URI Class Initialized
INFO - 2017-03-07 03:54:41 --> Router Class Initialized
INFO - 2017-03-07 03:54:41 --> Output Class Initialized
INFO - 2017-03-07 03:54:41 --> Security Class Initialized
DEBUG - 2017-03-07 03:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:54:41 --> Input Class Initialized
INFO - 2017-03-07 03:54:41 --> Language Class Initialized
INFO - 2017-03-07 03:54:41 --> Loader Class Initialized
INFO - 2017-03-07 03:54:41 --> Database Driver Class Initialized
INFO - 2017-03-07 03:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:54:41 --> Controller Class Initialized
INFO - 2017-03-07 03:54:41 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-07 03:54:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-07 03:54:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-07 03:54:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-07 03:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:54:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:54:42 --> Final output sent to browser
DEBUG - 2017-03-07 03:54:42 --> Total execution time: 0.5555
INFO - 2017-03-07 03:54:44 --> Config Class Initialized
INFO - 2017-03-07 03:54:44 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:54:44 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:54:44 --> Utf8 Class Initialized
INFO - 2017-03-07 03:54:44 --> URI Class Initialized
INFO - 2017-03-07 03:54:44 --> Router Class Initialized
INFO - 2017-03-07 03:54:44 --> Output Class Initialized
INFO - 2017-03-07 03:54:44 --> Security Class Initialized
DEBUG - 2017-03-07 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:54:44 --> Input Class Initialized
INFO - 2017-03-07 03:54:44 --> Language Class Initialized
INFO - 2017-03-07 03:54:44 --> Loader Class Initialized
INFO - 2017-03-07 03:54:44 --> Database Driver Class Initialized
INFO - 2017-03-07 03:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:54:44 --> Controller Class Initialized
INFO - 2017-03-07 03:54:44 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:54:44 --> Final output sent to browser
DEBUG - 2017-03-07 03:54:44 --> Total execution time: 0.0138
INFO - 2017-03-07 03:54:57 --> Config Class Initialized
INFO - 2017-03-07 03:54:57 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:54:57 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:54:57 --> Utf8 Class Initialized
INFO - 2017-03-07 03:54:57 --> URI Class Initialized
INFO - 2017-03-07 03:54:57 --> Router Class Initialized
INFO - 2017-03-07 03:54:57 --> Output Class Initialized
INFO - 2017-03-07 03:54:57 --> Security Class Initialized
DEBUG - 2017-03-07 03:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:54:57 --> Input Class Initialized
INFO - 2017-03-07 03:54:57 --> Language Class Initialized
INFO - 2017-03-07 03:54:57 --> Loader Class Initialized
INFO - 2017-03-07 03:54:57 --> Database Driver Class Initialized
INFO - 2017-03-07 03:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:54:57 --> Controller Class Initialized
INFO - 2017-03-07 03:54:57 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:54:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:54:59 --> Config Class Initialized
INFO - 2017-03-07 03:54:59 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:54:59 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:54:59 --> Utf8 Class Initialized
INFO - 2017-03-07 03:54:59 --> URI Class Initialized
INFO - 2017-03-07 03:54:59 --> Router Class Initialized
INFO - 2017-03-07 03:54:59 --> Output Class Initialized
INFO - 2017-03-07 03:54:59 --> Security Class Initialized
DEBUG - 2017-03-07 03:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:54:59 --> Input Class Initialized
INFO - 2017-03-07 03:54:59 --> Language Class Initialized
INFO - 2017-03-07 03:54:59 --> Loader Class Initialized
INFO - 2017-03-07 03:54:59 --> Database Driver Class Initialized
INFO - 2017-03-07 03:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:54:59 --> Controller Class Initialized
INFO - 2017-03-07 03:54:59 --> Helper loaded: date_helper
DEBUG - 2017-03-07 03:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:54:59 --> Helper loaded: url_helper
INFO - 2017-03-07 03:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 03:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 03:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 03:54:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:54:59 --> Final output sent to browser
DEBUG - 2017-03-07 03:54:59 --> Total execution time: 0.1086
INFO - 2017-03-07 03:55:00 --> Config Class Initialized
INFO - 2017-03-07 03:55:00 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:55:00 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:55:00 --> Utf8 Class Initialized
INFO - 2017-03-07 03:55:00 --> URI Class Initialized
INFO - 2017-03-07 03:55:00 --> Router Class Initialized
INFO - 2017-03-07 03:55:00 --> Output Class Initialized
INFO - 2017-03-07 03:55:00 --> Security Class Initialized
DEBUG - 2017-03-07 03:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:55:00 --> Input Class Initialized
INFO - 2017-03-07 03:55:00 --> Language Class Initialized
INFO - 2017-03-07 03:55:00 --> Loader Class Initialized
INFO - 2017-03-07 03:55:00 --> Database Driver Class Initialized
INFO - 2017-03-07 03:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:55:00 --> Controller Class Initialized
INFO - 2017-03-07 03:55:00 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:55:00 --> Final output sent to browser
DEBUG - 2017-03-07 03:55:00 --> Total execution time: 0.0139
INFO - 2017-03-07 03:55:09 --> Config Class Initialized
INFO - 2017-03-07 03:55:09 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:55:09 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:55:09 --> Utf8 Class Initialized
INFO - 2017-03-07 03:55:09 --> URI Class Initialized
DEBUG - 2017-03-07 03:55:09 --> No URI present. Default controller set.
INFO - 2017-03-07 03:55:09 --> Router Class Initialized
INFO - 2017-03-07 03:55:09 --> Output Class Initialized
INFO - 2017-03-07 03:55:09 --> Security Class Initialized
DEBUG - 2017-03-07 03:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:55:09 --> Input Class Initialized
INFO - 2017-03-07 03:55:09 --> Language Class Initialized
INFO - 2017-03-07 03:55:09 --> Loader Class Initialized
INFO - 2017-03-07 03:55:09 --> Database Driver Class Initialized
INFO - 2017-03-07 03:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:55:09 --> Controller Class Initialized
INFO - 2017-03-07 03:55:09 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:55:09 --> Final output sent to browser
DEBUG - 2017-03-07 03:55:09 --> Total execution time: 0.0134
INFO - 2017-03-07 03:55:10 --> Config Class Initialized
INFO - 2017-03-07 03:55:10 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:55:10 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:55:10 --> Utf8 Class Initialized
INFO - 2017-03-07 03:55:10 --> URI Class Initialized
INFO - 2017-03-07 03:55:10 --> Router Class Initialized
INFO - 2017-03-07 03:55:10 --> Output Class Initialized
INFO - 2017-03-07 03:55:10 --> Security Class Initialized
DEBUG - 2017-03-07 03:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:55:10 --> Input Class Initialized
INFO - 2017-03-07 03:55:10 --> Language Class Initialized
INFO - 2017-03-07 03:55:10 --> Loader Class Initialized
INFO - 2017-03-07 03:55:10 --> Database Driver Class Initialized
INFO - 2017-03-07 03:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:55:10 --> Controller Class Initialized
INFO - 2017-03-07 03:55:10 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:55:10 --> Final output sent to browser
DEBUG - 2017-03-07 03:55:10 --> Total execution time: 0.0143
INFO - 2017-03-07 03:55:17 --> Config Class Initialized
INFO - 2017-03-07 03:55:17 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:55:17 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:55:17 --> Utf8 Class Initialized
INFO - 2017-03-07 03:55:17 --> URI Class Initialized
INFO - 2017-03-07 03:55:17 --> Router Class Initialized
INFO - 2017-03-07 03:55:17 --> Output Class Initialized
INFO - 2017-03-07 03:55:17 --> Security Class Initialized
DEBUG - 2017-03-07 03:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:55:17 --> Input Class Initialized
INFO - 2017-03-07 03:55:17 --> Language Class Initialized
INFO - 2017-03-07 03:55:17 --> Loader Class Initialized
INFO - 2017-03-07 03:55:17 --> Database Driver Class Initialized
INFO - 2017-03-07 03:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:55:17 --> Controller Class Initialized
INFO - 2017-03-07 03:55:17 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:55:17 --> Final output sent to browser
DEBUG - 2017-03-07 03:55:17 --> Total execution time: 0.0146
INFO - 2017-03-07 03:55:19 --> Config Class Initialized
INFO - 2017-03-07 03:55:19 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:55:19 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:55:19 --> Utf8 Class Initialized
INFO - 2017-03-07 03:55:19 --> URI Class Initialized
INFO - 2017-03-07 03:55:19 --> Router Class Initialized
INFO - 2017-03-07 03:55:19 --> Output Class Initialized
INFO - 2017-03-07 03:55:19 --> Security Class Initialized
DEBUG - 2017-03-07 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:55:19 --> Input Class Initialized
INFO - 2017-03-07 03:55:19 --> Language Class Initialized
INFO - 2017-03-07 03:55:19 --> Loader Class Initialized
INFO - 2017-03-07 03:55:19 --> Database Driver Class Initialized
INFO - 2017-03-07 03:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:55:19 --> Controller Class Initialized
INFO - 2017-03-07 03:55:19 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:55:19 --> Final output sent to browser
DEBUG - 2017-03-07 03:55:19 --> Total execution time: 0.0134
INFO - 2017-03-07 03:55:23 --> Config Class Initialized
INFO - 2017-03-07 03:55:23 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:55:23 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:55:23 --> Utf8 Class Initialized
INFO - 2017-03-07 03:55:23 --> URI Class Initialized
INFO - 2017-03-07 03:55:23 --> Router Class Initialized
INFO - 2017-03-07 03:55:23 --> Output Class Initialized
INFO - 2017-03-07 03:55:23 --> Security Class Initialized
DEBUG - 2017-03-07 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:55:23 --> Input Class Initialized
INFO - 2017-03-07 03:55:23 --> Language Class Initialized
INFO - 2017-03-07 03:55:23 --> Loader Class Initialized
INFO - 2017-03-07 03:55:23 --> Database Driver Class Initialized
INFO - 2017-03-07 03:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:55:23 --> Controller Class Initialized
INFO - 2017-03-07 03:55:23 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:55:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:55:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:55:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:55:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:55:23 --> Final output sent to browser
DEBUG - 2017-03-07 03:55:23 --> Total execution time: 0.0146
INFO - 2017-03-07 03:55:24 --> Config Class Initialized
INFO - 2017-03-07 03:55:24 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:55:24 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:55:24 --> Utf8 Class Initialized
INFO - 2017-03-07 03:55:24 --> URI Class Initialized
INFO - 2017-03-07 03:55:24 --> Router Class Initialized
INFO - 2017-03-07 03:55:24 --> Output Class Initialized
INFO - 2017-03-07 03:55:24 --> Security Class Initialized
DEBUG - 2017-03-07 03:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:55:24 --> Input Class Initialized
INFO - 2017-03-07 03:55:24 --> Language Class Initialized
INFO - 2017-03-07 03:55:24 --> Loader Class Initialized
INFO - 2017-03-07 03:55:24 --> Database Driver Class Initialized
INFO - 2017-03-07 03:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:55:24 --> Controller Class Initialized
INFO - 2017-03-07 03:55:24 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:55:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:55:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:55:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:55:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:55:24 --> Final output sent to browser
DEBUG - 2017-03-07 03:55:24 --> Total execution time: 0.0141
INFO - 2017-03-07 03:56:09 --> Config Class Initialized
INFO - 2017-03-07 03:56:09 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:09 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:09 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:09 --> URI Class Initialized
INFO - 2017-03-07 03:56:09 --> Router Class Initialized
INFO - 2017-03-07 03:56:09 --> Output Class Initialized
INFO - 2017-03-07 03:56:09 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:10 --> Input Class Initialized
INFO - 2017-03-07 03:56:10 --> Language Class Initialized
INFO - 2017-03-07 03:56:10 --> Loader Class Initialized
INFO - 2017-03-07 03:56:10 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:10 --> Controller Class Initialized
INFO - 2017-03-07 03:56:10 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:56:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:10 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:10 --> Total execution time: 1.4758
INFO - 2017-03-07 03:56:13 --> Config Class Initialized
INFO - 2017-03-07 03:56:13 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:13 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:13 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:13 --> URI Class Initialized
INFO - 2017-03-07 03:56:13 --> Router Class Initialized
INFO - 2017-03-07 03:56:13 --> Output Class Initialized
INFO - 2017-03-07 03:56:13 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:13 --> Input Class Initialized
INFO - 2017-03-07 03:56:13 --> Language Class Initialized
INFO - 2017-03-07 03:56:13 --> Loader Class Initialized
INFO - 2017-03-07 03:56:13 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:13 --> Controller Class Initialized
INFO - 2017-03-07 03:56:13 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:13 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:13 --> Total execution time: 0.0139
INFO - 2017-03-07 03:56:17 --> Config Class Initialized
INFO - 2017-03-07 03:56:17 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:17 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:17 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:17 --> URI Class Initialized
INFO - 2017-03-07 03:56:17 --> Router Class Initialized
INFO - 2017-03-07 03:56:17 --> Output Class Initialized
INFO - 2017-03-07 03:56:17 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:17 --> Input Class Initialized
INFO - 2017-03-07 03:56:17 --> Language Class Initialized
INFO - 2017-03-07 03:56:17 --> Loader Class Initialized
INFO - 2017-03-07 03:56:17 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:17 --> Controller Class Initialized
INFO - 2017-03-07 03:56:17 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:17 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:17 --> Total execution time: 0.0144
INFO - 2017-03-07 03:56:18 --> Config Class Initialized
INFO - 2017-03-07 03:56:18 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:18 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:18 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:18 --> URI Class Initialized
INFO - 2017-03-07 03:56:18 --> Router Class Initialized
INFO - 2017-03-07 03:56:18 --> Output Class Initialized
INFO - 2017-03-07 03:56:18 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:18 --> Input Class Initialized
INFO - 2017-03-07 03:56:18 --> Language Class Initialized
INFO - 2017-03-07 03:56:18 --> Loader Class Initialized
INFO - 2017-03-07 03:56:18 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:18 --> Controller Class Initialized
INFO - 2017-03-07 03:56:18 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:18 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:18 --> Total execution time: 0.0138
INFO - 2017-03-07 03:56:21 --> Config Class Initialized
INFO - 2017-03-07 03:56:21 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:21 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:21 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:21 --> URI Class Initialized
INFO - 2017-03-07 03:56:21 --> Router Class Initialized
INFO - 2017-03-07 03:56:21 --> Output Class Initialized
INFO - 2017-03-07 03:56:21 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:21 --> Input Class Initialized
INFO - 2017-03-07 03:56:21 --> Language Class Initialized
INFO - 2017-03-07 03:56:21 --> Loader Class Initialized
INFO - 2017-03-07 03:56:21 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:21 --> Controller Class Initialized
INFO - 2017-03-07 03:56:21 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:22 --> Config Class Initialized
INFO - 2017-03-07 03:56:22 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:22 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:22 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:22 --> URI Class Initialized
INFO - 2017-03-07 03:56:22 --> Router Class Initialized
INFO - 2017-03-07 03:56:22 --> Output Class Initialized
INFO - 2017-03-07 03:56:22 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:22 --> Input Class Initialized
INFO - 2017-03-07 03:56:22 --> Language Class Initialized
INFO - 2017-03-07 03:56:22 --> Loader Class Initialized
INFO - 2017-03-07 03:56:22 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:22 --> Controller Class Initialized
INFO - 2017-03-07 03:56:22 --> Helper loaded: date_helper
DEBUG - 2017-03-07 03:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:22 --> Helper loaded: url_helper
INFO - 2017-03-07 03:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 03:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 03:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 03:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:22 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:22 --> Total execution time: 0.1026
INFO - 2017-03-07 03:56:23 --> Config Class Initialized
INFO - 2017-03-07 03:56:23 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:23 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:23 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:23 --> URI Class Initialized
INFO - 2017-03-07 03:56:23 --> Router Class Initialized
INFO - 2017-03-07 03:56:23 --> Output Class Initialized
INFO - 2017-03-07 03:56:23 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:23 --> Input Class Initialized
INFO - 2017-03-07 03:56:23 --> Language Class Initialized
INFO - 2017-03-07 03:56:23 --> Loader Class Initialized
INFO - 2017-03-07 03:56:23 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:23 --> Controller Class Initialized
INFO - 2017-03-07 03:56:23 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:56:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:56:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:23 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:23 --> Total execution time: 0.0134
INFO - 2017-03-07 03:56:36 --> Config Class Initialized
INFO - 2017-03-07 03:56:36 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:36 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:36 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:36 --> URI Class Initialized
DEBUG - 2017-03-07 03:56:36 --> No URI present. Default controller set.
INFO - 2017-03-07 03:56:36 --> Router Class Initialized
INFO - 2017-03-07 03:56:36 --> Output Class Initialized
INFO - 2017-03-07 03:56:36 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:37 --> Input Class Initialized
INFO - 2017-03-07 03:56:37 --> Language Class Initialized
INFO - 2017-03-07 03:56:37 --> Loader Class Initialized
INFO - 2017-03-07 03:56:37 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:37 --> Controller Class Initialized
INFO - 2017-03-07 03:56:37 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:37 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:37 --> Total execution time: 1.3076
INFO - 2017-03-07 03:56:39 --> Config Class Initialized
INFO - 2017-03-07 03:56:39 --> Hooks Class Initialized
DEBUG - 2017-03-07 03:56:39 --> UTF-8 Support Enabled
INFO - 2017-03-07 03:56:39 --> Utf8 Class Initialized
INFO - 2017-03-07 03:56:39 --> URI Class Initialized
INFO - 2017-03-07 03:56:39 --> Router Class Initialized
INFO - 2017-03-07 03:56:39 --> Output Class Initialized
INFO - 2017-03-07 03:56:39 --> Security Class Initialized
DEBUG - 2017-03-07 03:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 03:56:39 --> Input Class Initialized
INFO - 2017-03-07 03:56:39 --> Language Class Initialized
INFO - 2017-03-07 03:56:39 --> Loader Class Initialized
INFO - 2017-03-07 03:56:39 --> Database Driver Class Initialized
INFO - 2017-03-07 03:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 03:56:39 --> Controller Class Initialized
INFO - 2017-03-07 03:56:39 --> Helper loaded: url_helper
DEBUG - 2017-03-07 03:56:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 03:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 03:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 03:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 03:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 03:56:39 --> Final output sent to browser
DEBUG - 2017-03-07 03:56:39 --> Total execution time: 0.1398
INFO - 2017-03-07 04:06:07 --> Config Class Initialized
INFO - 2017-03-07 04:06:07 --> Hooks Class Initialized
DEBUG - 2017-03-07 04:06:08 --> UTF-8 Support Enabled
INFO - 2017-03-07 04:06:08 --> Utf8 Class Initialized
INFO - 2017-03-07 04:06:08 --> URI Class Initialized
DEBUG - 2017-03-07 04:06:08 --> No URI present. Default controller set.
INFO - 2017-03-07 04:06:08 --> Router Class Initialized
INFO - 2017-03-07 04:06:08 --> Output Class Initialized
INFO - 2017-03-07 04:06:08 --> Security Class Initialized
DEBUG - 2017-03-07 04:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 04:06:08 --> Input Class Initialized
INFO - 2017-03-07 04:06:08 --> Language Class Initialized
INFO - 2017-03-07 04:06:08 --> Loader Class Initialized
INFO - 2017-03-07 04:06:08 --> Database Driver Class Initialized
INFO - 2017-03-07 04:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 04:06:09 --> Controller Class Initialized
INFO - 2017-03-07 04:06:09 --> Helper loaded: url_helper
DEBUG - 2017-03-07 04:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 04:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 04:06:09 --> Final output sent to browser
DEBUG - 2017-03-07 04:06:09 --> Total execution time: 1.9842
INFO - 2017-03-07 04:06:16 --> Config Class Initialized
INFO - 2017-03-07 04:06:16 --> Hooks Class Initialized
DEBUG - 2017-03-07 04:06:16 --> UTF-8 Support Enabled
INFO - 2017-03-07 04:06:16 --> Utf8 Class Initialized
INFO - 2017-03-07 04:06:16 --> URI Class Initialized
INFO - 2017-03-07 04:06:16 --> Router Class Initialized
INFO - 2017-03-07 04:06:16 --> Output Class Initialized
INFO - 2017-03-07 04:06:16 --> Security Class Initialized
DEBUG - 2017-03-07 04:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 04:06:16 --> Input Class Initialized
INFO - 2017-03-07 04:06:16 --> Language Class Initialized
INFO - 2017-03-07 04:06:16 --> Loader Class Initialized
INFO - 2017-03-07 04:06:16 --> Database Driver Class Initialized
INFO - 2017-03-07 04:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 04:06:16 --> Controller Class Initialized
INFO - 2017-03-07 04:06:16 --> Helper loaded: url_helper
DEBUG - 2017-03-07 04:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 04:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 04:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 04:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 04:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 04:06:16 --> Final output sent to browser
DEBUG - 2017-03-07 04:06:16 --> Total execution time: 0.0133
INFO - 2017-03-07 04:08:22 --> Config Class Initialized
INFO - 2017-03-07 04:08:22 --> Hooks Class Initialized
DEBUG - 2017-03-07 04:08:22 --> UTF-8 Support Enabled
INFO - 2017-03-07 04:08:22 --> Utf8 Class Initialized
INFO - 2017-03-07 04:08:22 --> URI Class Initialized
INFO - 2017-03-07 04:08:22 --> Router Class Initialized
INFO - 2017-03-07 04:08:22 --> Output Class Initialized
INFO - 2017-03-07 04:08:22 --> Security Class Initialized
DEBUG - 2017-03-07 04:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 04:08:22 --> Input Class Initialized
INFO - 2017-03-07 04:08:22 --> Language Class Initialized
INFO - 2017-03-07 04:08:22 --> Loader Class Initialized
INFO - 2017-03-07 04:08:23 --> Database Driver Class Initialized
INFO - 2017-03-07 04:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 04:08:23 --> Controller Class Initialized
INFO - 2017-03-07 04:08:23 --> Helper loaded: url_helper
DEBUG - 2017-03-07 04:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 04:08:26 --> Config Class Initialized
INFO - 2017-03-07 04:08:26 --> Hooks Class Initialized
DEBUG - 2017-03-07 04:08:26 --> UTF-8 Support Enabled
INFO - 2017-03-07 04:08:26 --> Utf8 Class Initialized
INFO - 2017-03-07 04:08:27 --> URI Class Initialized
INFO - 2017-03-07 04:08:27 --> Router Class Initialized
INFO - 2017-03-07 04:08:27 --> Output Class Initialized
INFO - 2017-03-07 04:08:27 --> Security Class Initialized
DEBUG - 2017-03-07 04:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 04:08:27 --> Input Class Initialized
INFO - 2017-03-07 04:08:27 --> Language Class Initialized
INFO - 2017-03-07 04:08:27 --> Loader Class Initialized
INFO - 2017-03-07 04:08:27 --> Database Driver Class Initialized
INFO - 2017-03-07 04:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 04:08:27 --> Controller Class Initialized
INFO - 2017-03-07 04:08:27 --> Helper loaded: date_helper
DEBUG - 2017-03-07 04:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 04:08:27 --> Helper loaded: url_helper
INFO - 2017-03-07 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 04:08:27 --> Final output sent to browser
DEBUG - 2017-03-07 04:08:27 --> Total execution time: 1.0506
INFO - 2017-03-07 04:08:28 --> Config Class Initialized
INFO - 2017-03-07 04:08:28 --> Hooks Class Initialized
DEBUG - 2017-03-07 04:08:28 --> UTF-8 Support Enabled
INFO - 2017-03-07 04:08:28 --> Utf8 Class Initialized
INFO - 2017-03-07 04:08:28 --> URI Class Initialized
INFO - 2017-03-07 04:08:28 --> Router Class Initialized
INFO - 2017-03-07 04:08:28 --> Output Class Initialized
INFO - 2017-03-07 04:08:28 --> Security Class Initialized
DEBUG - 2017-03-07 04:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 04:08:28 --> Input Class Initialized
INFO - 2017-03-07 04:08:28 --> Language Class Initialized
INFO - 2017-03-07 04:08:28 --> Loader Class Initialized
INFO - 2017-03-07 04:08:28 --> Database Driver Class Initialized
INFO - 2017-03-07 04:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 04:08:28 --> Controller Class Initialized
INFO - 2017-03-07 04:08:28 --> Helper loaded: url_helper
DEBUG - 2017-03-07 04:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 04:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 04:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 04:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 04:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 04:08:28 --> Final output sent to browser
DEBUG - 2017-03-07 04:08:28 --> Total execution time: 0.2493
INFO - 2017-03-07 04:26:41 --> Config Class Initialized
INFO - 2017-03-07 04:26:41 --> Hooks Class Initialized
DEBUG - 2017-03-07 04:26:42 --> UTF-8 Support Enabled
INFO - 2017-03-07 04:26:42 --> Utf8 Class Initialized
INFO - 2017-03-07 04:26:42 --> URI Class Initialized
DEBUG - 2017-03-07 04:26:42 --> No URI present. Default controller set.
INFO - 2017-03-07 04:26:42 --> Router Class Initialized
INFO - 2017-03-07 04:26:42 --> Output Class Initialized
INFO - 2017-03-07 04:26:42 --> Security Class Initialized
DEBUG - 2017-03-07 04:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 04:26:42 --> Input Class Initialized
INFO - 2017-03-07 04:26:42 --> Language Class Initialized
INFO - 2017-03-07 04:26:42 --> Loader Class Initialized
INFO - 2017-03-07 04:26:42 --> Database Driver Class Initialized
INFO - 2017-03-07 04:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 04:26:43 --> Controller Class Initialized
INFO - 2017-03-07 04:26:43 --> Helper loaded: url_helper
DEBUG - 2017-03-07 04:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 04:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 04:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 04:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 04:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 04:26:43 --> Final output sent to browser
DEBUG - 2017-03-07 04:26:43 --> Total execution time: 1.7805
INFO - 2017-03-07 04:26:46 --> Config Class Initialized
INFO - 2017-03-07 04:26:46 --> Hooks Class Initialized
DEBUG - 2017-03-07 04:26:46 --> UTF-8 Support Enabled
INFO - 2017-03-07 04:26:46 --> Utf8 Class Initialized
INFO - 2017-03-07 04:26:46 --> URI Class Initialized
INFO - 2017-03-07 04:26:46 --> Router Class Initialized
INFO - 2017-03-07 04:26:46 --> Output Class Initialized
INFO - 2017-03-07 04:26:46 --> Security Class Initialized
DEBUG - 2017-03-07 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 04:26:46 --> Input Class Initialized
INFO - 2017-03-07 04:26:46 --> Language Class Initialized
INFO - 2017-03-07 04:26:46 --> Loader Class Initialized
INFO - 2017-03-07 04:26:46 --> Database Driver Class Initialized
INFO - 2017-03-07 04:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 04:26:46 --> Controller Class Initialized
INFO - 2017-03-07 04:26:46 --> Helper loaded: url_helper
DEBUG - 2017-03-07 04:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 04:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 04:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 04:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 04:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 04:26:46 --> Final output sent to browser
DEBUG - 2017-03-07 04:26:46 --> Total execution time: 0.0226
INFO - 2017-03-07 05:16:54 --> Config Class Initialized
INFO - 2017-03-07 05:16:54 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:16:54 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:16:54 --> Utf8 Class Initialized
INFO - 2017-03-07 05:16:54 --> URI Class Initialized
DEBUG - 2017-03-07 05:16:54 --> No URI present. Default controller set.
INFO - 2017-03-07 05:16:54 --> Router Class Initialized
INFO - 2017-03-07 05:16:54 --> Output Class Initialized
INFO - 2017-03-07 05:16:55 --> Security Class Initialized
DEBUG - 2017-03-07 05:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:16:55 --> Input Class Initialized
INFO - 2017-03-07 05:16:55 --> Language Class Initialized
INFO - 2017-03-07 05:16:55 --> Loader Class Initialized
INFO - 2017-03-07 05:16:55 --> Database Driver Class Initialized
INFO - 2017-03-07 05:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:16:56 --> Controller Class Initialized
INFO - 2017-03-07 05:16:56 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:16:56 --> Final output sent to browser
DEBUG - 2017-03-07 05:16:56 --> Total execution time: 1.7317
INFO - 2017-03-07 05:17:02 --> Config Class Initialized
INFO - 2017-03-07 05:17:02 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:17:02 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:17:02 --> Utf8 Class Initialized
INFO - 2017-03-07 05:17:02 --> URI Class Initialized
INFO - 2017-03-07 05:17:02 --> Router Class Initialized
INFO - 2017-03-07 05:17:02 --> Output Class Initialized
INFO - 2017-03-07 05:17:02 --> Security Class Initialized
DEBUG - 2017-03-07 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:17:02 --> Input Class Initialized
INFO - 2017-03-07 05:17:02 --> Language Class Initialized
INFO - 2017-03-07 05:17:02 --> Loader Class Initialized
INFO - 2017-03-07 05:17:02 --> Database Driver Class Initialized
INFO - 2017-03-07 05:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:17:02 --> Controller Class Initialized
INFO - 2017-03-07 05:17:02 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:17:02 --> Final output sent to browser
DEBUG - 2017-03-07 05:17:02 --> Total execution time: 0.0132
INFO - 2017-03-07 05:17:46 --> Config Class Initialized
INFO - 2017-03-07 05:17:46 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:17:46 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:17:46 --> Utf8 Class Initialized
INFO - 2017-03-07 05:17:46 --> URI Class Initialized
INFO - 2017-03-07 05:17:46 --> Router Class Initialized
INFO - 2017-03-07 05:17:46 --> Output Class Initialized
INFO - 2017-03-07 05:17:46 --> Security Class Initialized
DEBUG - 2017-03-07 05:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:17:46 --> Input Class Initialized
INFO - 2017-03-07 05:17:46 --> Language Class Initialized
INFO - 2017-03-07 05:17:46 --> Loader Class Initialized
INFO - 2017-03-07 05:17:46 --> Database Driver Class Initialized
INFO - 2017-03-07 05:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:17:46 --> Controller Class Initialized
INFO - 2017-03-07 05:17:46 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:17:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:17:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:17:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:17:47 --> Final output sent to browser
DEBUG - 2017-03-07 05:17:47 --> Total execution time: 0.0577
INFO - 2017-03-07 05:17:47 --> Config Class Initialized
INFO - 2017-03-07 05:17:47 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:17:47 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:17:47 --> Utf8 Class Initialized
INFO - 2017-03-07 05:17:47 --> URI Class Initialized
INFO - 2017-03-07 05:17:47 --> Router Class Initialized
INFO - 2017-03-07 05:17:47 --> Output Class Initialized
INFO - 2017-03-07 05:17:47 --> Security Class Initialized
DEBUG - 2017-03-07 05:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:17:47 --> Input Class Initialized
INFO - 2017-03-07 05:17:47 --> Language Class Initialized
INFO - 2017-03-07 05:17:47 --> Loader Class Initialized
INFO - 2017-03-07 05:17:47 --> Database Driver Class Initialized
INFO - 2017-03-07 05:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:17:47 --> Controller Class Initialized
INFO - 2017-03-07 05:17:47 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:17:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:17:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:17:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:17:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:17:47 --> Final output sent to browser
DEBUG - 2017-03-07 05:17:47 --> Total execution time: 0.0186
INFO - 2017-03-07 05:18:00 --> Config Class Initialized
INFO - 2017-03-07 05:18:00 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:00 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:00 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:00 --> URI Class Initialized
INFO - 2017-03-07 05:18:00 --> Router Class Initialized
INFO - 2017-03-07 05:18:00 --> Output Class Initialized
INFO - 2017-03-07 05:18:00 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:00 --> Input Class Initialized
INFO - 2017-03-07 05:18:00 --> Language Class Initialized
INFO - 2017-03-07 05:18:00 --> Loader Class Initialized
INFO - 2017-03-07 05:18:00 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:00 --> Controller Class Initialized
INFO - 2017-03-07 05:18:00 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:00 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:00 --> Total execution time: 0.0142
INFO - 2017-03-07 05:18:01 --> Config Class Initialized
INFO - 2017-03-07 05:18:01 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:01 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:01 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:01 --> URI Class Initialized
INFO - 2017-03-07 05:18:01 --> Router Class Initialized
INFO - 2017-03-07 05:18:01 --> Output Class Initialized
INFO - 2017-03-07 05:18:01 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:01 --> Input Class Initialized
INFO - 2017-03-07 05:18:01 --> Language Class Initialized
INFO - 2017-03-07 05:18:01 --> Loader Class Initialized
INFO - 2017-03-07 05:18:01 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:01 --> Controller Class Initialized
INFO - 2017-03-07 05:18:01 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:01 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:01 --> Total execution time: 0.0665
INFO - 2017-03-07 05:18:07 --> Config Class Initialized
INFO - 2017-03-07 05:18:07 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:07 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:07 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:07 --> URI Class Initialized
INFO - 2017-03-07 05:18:07 --> Router Class Initialized
INFO - 2017-03-07 05:18:07 --> Output Class Initialized
INFO - 2017-03-07 05:18:07 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:07 --> Input Class Initialized
INFO - 2017-03-07 05:18:07 --> Language Class Initialized
INFO - 2017-03-07 05:18:07 --> Loader Class Initialized
INFO - 2017-03-07 05:18:07 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:07 --> Controller Class Initialized
INFO - 2017-03-07 05:18:07 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:08 --> Config Class Initialized
INFO - 2017-03-07 05:18:08 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:08 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:08 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:08 --> URI Class Initialized
INFO - 2017-03-07 05:18:08 --> Router Class Initialized
INFO - 2017-03-07 05:18:08 --> Output Class Initialized
INFO - 2017-03-07 05:18:08 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:08 --> Input Class Initialized
INFO - 2017-03-07 05:18:08 --> Language Class Initialized
INFO - 2017-03-07 05:18:08 --> Loader Class Initialized
INFO - 2017-03-07 05:18:08 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:08 --> Config Class Initialized
INFO - 2017-03-07 05:18:08 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:08 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:08 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:08 --> URI Class Initialized
INFO - 2017-03-07 05:18:08 --> Router Class Initialized
INFO - 2017-03-07 05:18:08 --> Output Class Initialized
INFO - 2017-03-07 05:18:08 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:08 --> Input Class Initialized
INFO - 2017-03-07 05:18:08 --> Language Class Initialized
INFO - 2017-03-07 05:18:08 --> Loader Class Initialized
INFO - 2017-03-07 05:18:09 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:09 --> Controller Class Initialized
INFO - 2017-03-07 05:18:09 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:09 --> Controller Class Initialized
INFO - 2017-03-07 05:18:09 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:09 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:09 --> Total execution time: 1.1912
INFO - 2017-03-07 05:18:10 --> Config Class Initialized
INFO - 2017-03-07 05:18:10 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:10 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:10 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:10 --> URI Class Initialized
INFO - 2017-03-07 05:18:10 --> Router Class Initialized
INFO - 2017-03-07 05:18:10 --> Output Class Initialized
INFO - 2017-03-07 05:18:10 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:10 --> Input Class Initialized
INFO - 2017-03-07 05:18:10 --> Language Class Initialized
INFO - 2017-03-07 05:18:10 --> Loader Class Initialized
INFO - 2017-03-07 05:18:10 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:10 --> Controller Class Initialized
INFO - 2017-03-07 05:18:10 --> Helper loaded: date_helper
DEBUG - 2017-03-07 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:10 --> Helper loaded: url_helper
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:10 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:10 --> Total execution time: 0.1395
INFO - 2017-03-07 05:18:10 --> Config Class Initialized
INFO - 2017-03-07 05:18:10 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:10 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:10 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:10 --> URI Class Initialized
INFO - 2017-03-07 05:18:10 --> Router Class Initialized
INFO - 2017-03-07 05:18:10 --> Output Class Initialized
INFO - 2017-03-07 05:18:10 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:10 --> Input Class Initialized
INFO - 2017-03-07 05:18:10 --> Language Class Initialized
INFO - 2017-03-07 05:18:10 --> Loader Class Initialized
INFO - 2017-03-07 05:18:10 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:10 --> Controller Class Initialized
INFO - 2017-03-07 05:18:10 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:10 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:10 --> Total execution time: 0.0129
INFO - 2017-03-07 05:18:18 --> Config Class Initialized
INFO - 2017-03-07 05:18:18 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:18 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:18 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:18 --> URI Class Initialized
DEBUG - 2017-03-07 05:18:18 --> No URI present. Default controller set.
INFO - 2017-03-07 05:18:18 --> Router Class Initialized
INFO - 2017-03-07 05:18:18 --> Output Class Initialized
INFO - 2017-03-07 05:18:18 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:18 --> Input Class Initialized
INFO - 2017-03-07 05:18:18 --> Language Class Initialized
INFO - 2017-03-07 05:18:18 --> Loader Class Initialized
INFO - 2017-03-07 05:18:18 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:18 --> Controller Class Initialized
INFO - 2017-03-07 05:18:18 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:18 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:18 --> Total execution time: 0.0133
INFO - 2017-03-07 05:18:19 --> Config Class Initialized
INFO - 2017-03-07 05:18:19 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:19 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:19 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:19 --> URI Class Initialized
INFO - 2017-03-07 05:18:19 --> Router Class Initialized
INFO - 2017-03-07 05:18:19 --> Output Class Initialized
INFO - 2017-03-07 05:18:19 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:19 --> Input Class Initialized
INFO - 2017-03-07 05:18:19 --> Language Class Initialized
INFO - 2017-03-07 05:18:19 --> Loader Class Initialized
INFO - 2017-03-07 05:18:19 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:19 --> Controller Class Initialized
INFO - 2017-03-07 05:18:19 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:19 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:19 --> Total execution time: 0.0141
INFO - 2017-03-07 05:18:30 --> Config Class Initialized
INFO - 2017-03-07 05:18:30 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:30 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:30 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:30 --> URI Class Initialized
INFO - 2017-03-07 05:18:30 --> Router Class Initialized
INFO - 2017-03-07 05:18:30 --> Output Class Initialized
INFO - 2017-03-07 05:18:30 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:30 --> Input Class Initialized
INFO - 2017-03-07 05:18:30 --> Language Class Initialized
INFO - 2017-03-07 05:18:30 --> Loader Class Initialized
INFO - 2017-03-07 05:18:30 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:30 --> Controller Class Initialized
INFO - 2017-03-07 05:18:30 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:31 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:31 --> Total execution time: 0.0172
INFO - 2017-03-07 05:18:31 --> Config Class Initialized
INFO - 2017-03-07 05:18:31 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:31 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:31 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:31 --> URI Class Initialized
INFO - 2017-03-07 05:18:31 --> Router Class Initialized
INFO - 2017-03-07 05:18:31 --> Output Class Initialized
INFO - 2017-03-07 05:18:31 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:31 --> Input Class Initialized
INFO - 2017-03-07 05:18:31 --> Language Class Initialized
INFO - 2017-03-07 05:18:31 --> Loader Class Initialized
INFO - 2017-03-07 05:18:31 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:31 --> Controller Class Initialized
INFO - 2017-03-07 05:18:31 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:31 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:31 --> Total execution time: 0.0133
INFO - 2017-03-07 05:18:35 --> Config Class Initialized
INFO - 2017-03-07 05:18:35 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:35 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:35 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:35 --> URI Class Initialized
DEBUG - 2017-03-07 05:18:35 --> No URI present. Default controller set.
INFO - 2017-03-07 05:18:35 --> Router Class Initialized
INFO - 2017-03-07 05:18:35 --> Output Class Initialized
INFO - 2017-03-07 05:18:35 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:35 --> Input Class Initialized
INFO - 2017-03-07 05:18:35 --> Language Class Initialized
INFO - 2017-03-07 05:18:35 --> Loader Class Initialized
INFO - 2017-03-07 05:18:35 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:35 --> Controller Class Initialized
INFO - 2017-03-07 05:18:35 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:35 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:35 --> Total execution time: 0.0146
INFO - 2017-03-07 05:18:36 --> Config Class Initialized
INFO - 2017-03-07 05:18:36 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:36 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:36 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:36 --> URI Class Initialized
INFO - 2017-03-07 05:18:36 --> Router Class Initialized
INFO - 2017-03-07 05:18:36 --> Output Class Initialized
INFO - 2017-03-07 05:18:36 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:36 --> Input Class Initialized
INFO - 2017-03-07 05:18:36 --> Language Class Initialized
INFO - 2017-03-07 05:18:36 --> Loader Class Initialized
INFO - 2017-03-07 05:18:36 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:36 --> Controller Class Initialized
INFO - 2017-03-07 05:18:36 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:36 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:36 --> Total execution time: 0.0132
INFO - 2017-03-07 05:18:37 --> Config Class Initialized
INFO - 2017-03-07 05:18:37 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:37 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:37 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:37 --> URI Class Initialized
INFO - 2017-03-07 05:18:37 --> Router Class Initialized
INFO - 2017-03-07 05:18:37 --> Output Class Initialized
INFO - 2017-03-07 05:18:37 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:37 --> Input Class Initialized
INFO - 2017-03-07 05:18:37 --> Language Class Initialized
INFO - 2017-03-07 05:18:37 --> Loader Class Initialized
INFO - 2017-03-07 05:18:37 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:37 --> Controller Class Initialized
INFO - 2017-03-07 05:18:37 --> Helper loaded: date_helper
DEBUG - 2017-03-07 05:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:37 --> Helper loaded: url_helper
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:37 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:37 --> Total execution time: 0.0792
INFO - 2017-03-07 05:18:37 --> Config Class Initialized
INFO - 2017-03-07 05:18:37 --> Hooks Class Initialized
DEBUG - 2017-03-07 05:18:37 --> UTF-8 Support Enabled
INFO - 2017-03-07 05:18:37 --> Utf8 Class Initialized
INFO - 2017-03-07 05:18:37 --> URI Class Initialized
INFO - 2017-03-07 05:18:37 --> Router Class Initialized
INFO - 2017-03-07 05:18:37 --> Output Class Initialized
INFO - 2017-03-07 05:18:37 --> Security Class Initialized
DEBUG - 2017-03-07 05:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 05:18:37 --> Input Class Initialized
INFO - 2017-03-07 05:18:37 --> Language Class Initialized
INFO - 2017-03-07 05:18:37 --> Loader Class Initialized
INFO - 2017-03-07 05:18:37 --> Database Driver Class Initialized
INFO - 2017-03-07 05:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 05:18:37 --> Controller Class Initialized
INFO - 2017-03-07 05:18:37 --> Helper loaded: url_helper
DEBUG - 2017-03-07 05:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 05:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 05:18:37 --> Final output sent to browser
DEBUG - 2017-03-07 05:18:37 --> Total execution time: 0.0133
INFO - 2017-03-07 06:17:13 --> Config Class Initialized
INFO - 2017-03-07 06:17:13 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:17:13 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:17:13 --> Utf8 Class Initialized
INFO - 2017-03-07 06:17:13 --> URI Class Initialized
DEBUG - 2017-03-07 06:17:13 --> No URI present. Default controller set.
INFO - 2017-03-07 06:17:13 --> Router Class Initialized
INFO - 2017-03-07 06:17:13 --> Output Class Initialized
INFO - 2017-03-07 06:17:13 --> Security Class Initialized
DEBUG - 2017-03-07 06:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:17:13 --> Input Class Initialized
INFO - 2017-03-07 06:17:13 --> Language Class Initialized
INFO - 2017-03-07 06:17:13 --> Loader Class Initialized
INFO - 2017-03-07 06:17:14 --> Database Driver Class Initialized
INFO - 2017-03-07 06:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:17:14 --> Controller Class Initialized
INFO - 2017-03-07 06:17:14 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:17:15 --> Final output sent to browser
DEBUG - 2017-03-07 06:17:15 --> Total execution time: 2.0176
INFO - 2017-03-07 06:17:20 --> Config Class Initialized
INFO - 2017-03-07 06:17:20 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:17:20 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:17:20 --> Utf8 Class Initialized
INFO - 2017-03-07 06:17:20 --> URI Class Initialized
INFO - 2017-03-07 06:17:20 --> Router Class Initialized
INFO - 2017-03-07 06:17:20 --> Output Class Initialized
INFO - 2017-03-07 06:17:20 --> Security Class Initialized
DEBUG - 2017-03-07 06:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:17:20 --> Input Class Initialized
INFO - 2017-03-07 06:17:20 --> Language Class Initialized
INFO - 2017-03-07 06:17:20 --> Loader Class Initialized
INFO - 2017-03-07 06:17:20 --> Database Driver Class Initialized
INFO - 2017-03-07 06:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:17:20 --> Controller Class Initialized
INFO - 2017-03-07 06:17:20 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:17:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:17:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:17:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:17:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:17:20 --> Final output sent to browser
DEBUG - 2017-03-07 06:17:20 --> Total execution time: 0.2785
INFO - 2017-03-07 06:17:29 --> Config Class Initialized
INFO - 2017-03-07 06:17:29 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:17:29 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:17:29 --> Utf8 Class Initialized
INFO - 2017-03-07 06:17:29 --> URI Class Initialized
INFO - 2017-03-07 06:17:29 --> Router Class Initialized
INFO - 2017-03-07 06:17:29 --> Output Class Initialized
INFO - 2017-03-07 06:17:29 --> Security Class Initialized
DEBUG - 2017-03-07 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:17:29 --> Input Class Initialized
INFO - 2017-03-07 06:17:29 --> Language Class Initialized
INFO - 2017-03-07 06:17:29 --> Loader Class Initialized
INFO - 2017-03-07 06:17:29 --> Database Driver Class Initialized
INFO - 2017-03-07 06:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:17:29 --> Controller Class Initialized
INFO - 2017-03-07 06:17:29 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:17:32 --> Config Class Initialized
INFO - 2017-03-07 06:17:32 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:17:32 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:17:32 --> Utf8 Class Initialized
INFO - 2017-03-07 06:17:32 --> URI Class Initialized
INFO - 2017-03-07 06:17:32 --> Router Class Initialized
INFO - 2017-03-07 06:17:32 --> Output Class Initialized
INFO - 2017-03-07 06:17:32 --> Security Class Initialized
DEBUG - 2017-03-07 06:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:17:32 --> Input Class Initialized
INFO - 2017-03-07 06:17:32 --> Language Class Initialized
INFO - 2017-03-07 06:17:32 --> Loader Class Initialized
INFO - 2017-03-07 06:17:32 --> Database Driver Class Initialized
INFO - 2017-03-07 06:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:17:32 --> Controller Class Initialized
INFO - 2017-03-07 06:17:32 --> Helper loaded: date_helper
DEBUG - 2017-03-07 06:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:17:32 --> Helper loaded: url_helper
INFO - 2017-03-07 06:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 06:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 06:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 06:17:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:17:32 --> Final output sent to browser
DEBUG - 2017-03-07 06:17:32 --> Total execution time: 0.0982
INFO - 2017-03-07 06:17:33 --> Config Class Initialized
INFO - 2017-03-07 06:17:33 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:17:33 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:17:33 --> Utf8 Class Initialized
INFO - 2017-03-07 06:17:33 --> URI Class Initialized
INFO - 2017-03-07 06:17:33 --> Router Class Initialized
INFO - 2017-03-07 06:17:33 --> Output Class Initialized
INFO - 2017-03-07 06:17:33 --> Security Class Initialized
DEBUG - 2017-03-07 06:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:17:33 --> Input Class Initialized
INFO - 2017-03-07 06:17:33 --> Language Class Initialized
INFO - 2017-03-07 06:17:33 --> Loader Class Initialized
INFO - 2017-03-07 06:17:33 --> Database Driver Class Initialized
INFO - 2017-03-07 06:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:17:33 --> Controller Class Initialized
INFO - 2017-03-07 06:17:33 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:17:33 --> Final output sent to browser
DEBUG - 2017-03-07 06:17:33 --> Total execution time: 0.0133
INFO - 2017-03-07 06:17:40 --> Config Class Initialized
INFO - 2017-03-07 06:17:40 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:17:40 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:17:40 --> Utf8 Class Initialized
INFO - 2017-03-07 06:17:40 --> URI Class Initialized
DEBUG - 2017-03-07 06:17:40 --> No URI present. Default controller set.
INFO - 2017-03-07 06:17:40 --> Router Class Initialized
INFO - 2017-03-07 06:17:40 --> Output Class Initialized
INFO - 2017-03-07 06:17:40 --> Security Class Initialized
DEBUG - 2017-03-07 06:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:17:40 --> Input Class Initialized
INFO - 2017-03-07 06:17:40 --> Language Class Initialized
INFO - 2017-03-07 06:17:40 --> Loader Class Initialized
INFO - 2017-03-07 06:17:40 --> Database Driver Class Initialized
INFO - 2017-03-07 06:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:17:40 --> Controller Class Initialized
INFO - 2017-03-07 06:17:40 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:17:40 --> Final output sent to browser
DEBUG - 2017-03-07 06:17:40 --> Total execution time: 0.0138
INFO - 2017-03-07 06:17:42 --> Config Class Initialized
INFO - 2017-03-07 06:17:42 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:17:42 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:17:42 --> Utf8 Class Initialized
INFO - 2017-03-07 06:17:42 --> URI Class Initialized
INFO - 2017-03-07 06:17:42 --> Router Class Initialized
INFO - 2017-03-07 06:17:42 --> Output Class Initialized
INFO - 2017-03-07 06:17:42 --> Security Class Initialized
DEBUG - 2017-03-07 06:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:17:42 --> Input Class Initialized
INFO - 2017-03-07 06:17:42 --> Language Class Initialized
INFO - 2017-03-07 06:17:42 --> Loader Class Initialized
INFO - 2017-03-07 06:17:42 --> Database Driver Class Initialized
INFO - 2017-03-07 06:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:17:42 --> Controller Class Initialized
INFO - 2017-03-07 06:17:42 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:17:42 --> Final output sent to browser
DEBUG - 2017-03-07 06:17:42 --> Total execution time: 0.0134
INFO - 2017-03-07 06:18:19 --> Config Class Initialized
INFO - 2017-03-07 06:18:19 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:18:19 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:18:19 --> Utf8 Class Initialized
INFO - 2017-03-07 06:18:19 --> URI Class Initialized
INFO - 2017-03-07 06:18:19 --> Router Class Initialized
INFO - 2017-03-07 06:18:19 --> Output Class Initialized
INFO - 2017-03-07 06:18:19 --> Security Class Initialized
DEBUG - 2017-03-07 06:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:18:20 --> Input Class Initialized
INFO - 2017-03-07 06:18:20 --> Language Class Initialized
INFO - 2017-03-07 06:18:20 --> Loader Class Initialized
INFO - 2017-03-07 06:18:20 --> Database Driver Class Initialized
INFO - 2017-03-07 06:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:18:20 --> Controller Class Initialized
INFO - 2017-03-07 06:18:20 --> Helper loaded: date_helper
DEBUG - 2017-03-07 06:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:18:20 --> Helper loaded: url_helper
INFO - 2017-03-07 06:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 06:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 06:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 06:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:18:20 --> Final output sent to browser
DEBUG - 2017-03-07 06:18:20 --> Total execution time: 0.9824
INFO - 2017-03-07 06:18:21 --> Config Class Initialized
INFO - 2017-03-07 06:18:21 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:18:21 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:18:21 --> Utf8 Class Initialized
INFO - 2017-03-07 06:18:21 --> URI Class Initialized
INFO - 2017-03-07 06:18:21 --> Router Class Initialized
INFO - 2017-03-07 06:18:21 --> Output Class Initialized
INFO - 2017-03-07 06:18:21 --> Security Class Initialized
DEBUG - 2017-03-07 06:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:18:21 --> Input Class Initialized
INFO - 2017-03-07 06:18:21 --> Language Class Initialized
INFO - 2017-03-07 06:18:21 --> Loader Class Initialized
INFO - 2017-03-07 06:18:21 --> Database Driver Class Initialized
INFO - 2017-03-07 06:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:18:21 --> Controller Class Initialized
INFO - 2017-03-07 06:18:21 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:18:21 --> Final output sent to browser
DEBUG - 2017-03-07 06:18:21 --> Total execution time: 0.0275
INFO - 2017-03-07 06:18:28 --> Config Class Initialized
INFO - 2017-03-07 06:18:28 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:18:28 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:18:28 --> Utf8 Class Initialized
INFO - 2017-03-07 06:18:28 --> URI Class Initialized
INFO - 2017-03-07 06:18:28 --> Router Class Initialized
INFO - 2017-03-07 06:18:28 --> Output Class Initialized
INFO - 2017-03-07 06:18:28 --> Security Class Initialized
DEBUG - 2017-03-07 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:18:28 --> Input Class Initialized
INFO - 2017-03-07 06:18:28 --> Language Class Initialized
INFO - 2017-03-07 06:18:28 --> Loader Class Initialized
INFO - 2017-03-07 06:18:28 --> Database Driver Class Initialized
INFO - 2017-03-07 06:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:18:28 --> Controller Class Initialized
INFO - 2017-03-07 06:18:28 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:18:29 --> Config Class Initialized
INFO - 2017-03-07 06:18:29 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:18:29 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:18:29 --> Utf8 Class Initialized
INFO - 2017-03-07 06:18:29 --> URI Class Initialized
INFO - 2017-03-07 06:18:29 --> Router Class Initialized
INFO - 2017-03-07 06:18:29 --> Output Class Initialized
INFO - 2017-03-07 06:18:29 --> Security Class Initialized
DEBUG - 2017-03-07 06:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:18:29 --> Input Class Initialized
INFO - 2017-03-07 06:18:29 --> Language Class Initialized
INFO - 2017-03-07 06:18:29 --> Loader Class Initialized
INFO - 2017-03-07 06:18:29 --> Database Driver Class Initialized
INFO - 2017-03-07 06:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:18:29 --> Controller Class Initialized
INFO - 2017-03-07 06:18:29 --> Helper loaded: date_helper
DEBUG - 2017-03-07 06:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:18:29 --> Helper loaded: url_helper
INFO - 2017-03-07 06:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 06:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 06:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 06:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:18:29 --> Final output sent to browser
DEBUG - 2017-03-07 06:18:29 --> Total execution time: 0.0136
INFO - 2017-03-07 06:18:30 --> Config Class Initialized
INFO - 2017-03-07 06:18:30 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:18:30 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:18:30 --> Utf8 Class Initialized
INFO - 2017-03-07 06:18:30 --> URI Class Initialized
INFO - 2017-03-07 06:18:30 --> Router Class Initialized
INFO - 2017-03-07 06:18:30 --> Output Class Initialized
INFO - 2017-03-07 06:18:30 --> Security Class Initialized
DEBUG - 2017-03-07 06:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:18:30 --> Input Class Initialized
INFO - 2017-03-07 06:18:30 --> Language Class Initialized
INFO - 2017-03-07 06:18:30 --> Loader Class Initialized
INFO - 2017-03-07 06:18:30 --> Database Driver Class Initialized
INFO - 2017-03-07 06:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:18:30 --> Controller Class Initialized
INFO - 2017-03-07 06:18:30 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:18:30 --> Final output sent to browser
DEBUG - 2017-03-07 06:18:30 --> Total execution time: 0.0134
INFO - 2017-03-07 06:18:30 --> Config Class Initialized
INFO - 2017-03-07 06:18:30 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:18:30 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:18:30 --> Utf8 Class Initialized
INFO - 2017-03-07 06:18:30 --> URI Class Initialized
DEBUG - 2017-03-07 06:18:30 --> No URI present. Default controller set.
INFO - 2017-03-07 06:18:30 --> Router Class Initialized
INFO - 2017-03-07 06:18:30 --> Output Class Initialized
INFO - 2017-03-07 06:18:30 --> Security Class Initialized
DEBUG - 2017-03-07 06:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:18:30 --> Input Class Initialized
INFO - 2017-03-07 06:18:30 --> Language Class Initialized
INFO - 2017-03-07 06:18:30 --> Loader Class Initialized
INFO - 2017-03-07 06:18:30 --> Database Driver Class Initialized
INFO - 2017-03-07 06:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:18:30 --> Controller Class Initialized
INFO - 2017-03-07 06:18:30 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:18:30 --> Final output sent to browser
DEBUG - 2017-03-07 06:18:30 --> Total execution time: 0.0135
INFO - 2017-03-07 06:18:32 --> Config Class Initialized
INFO - 2017-03-07 06:18:32 --> Hooks Class Initialized
DEBUG - 2017-03-07 06:18:32 --> UTF-8 Support Enabled
INFO - 2017-03-07 06:18:32 --> Utf8 Class Initialized
INFO - 2017-03-07 06:18:32 --> URI Class Initialized
INFO - 2017-03-07 06:18:32 --> Router Class Initialized
INFO - 2017-03-07 06:18:32 --> Output Class Initialized
INFO - 2017-03-07 06:18:32 --> Security Class Initialized
DEBUG - 2017-03-07 06:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 06:18:32 --> Input Class Initialized
INFO - 2017-03-07 06:18:32 --> Language Class Initialized
INFO - 2017-03-07 06:18:32 --> Loader Class Initialized
INFO - 2017-03-07 06:18:32 --> Database Driver Class Initialized
INFO - 2017-03-07 06:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 06:18:32 --> Controller Class Initialized
INFO - 2017-03-07 06:18:32 --> Helper loaded: url_helper
DEBUG - 2017-03-07 06:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 06:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 06:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 06:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 06:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 06:18:32 --> Final output sent to browser
DEBUG - 2017-03-07 06:18:32 --> Total execution time: 0.0136
INFO - 2017-03-07 13:16:40 --> Config Class Initialized
INFO - 2017-03-07 13:16:40 --> Hooks Class Initialized
DEBUG - 2017-03-07 13:16:40 --> UTF-8 Support Enabled
INFO - 2017-03-07 13:16:40 --> Utf8 Class Initialized
INFO - 2017-03-07 13:16:40 --> URI Class Initialized
DEBUG - 2017-03-07 13:16:40 --> No URI present. Default controller set.
INFO - 2017-03-07 13:16:40 --> Router Class Initialized
INFO - 2017-03-07 13:16:40 --> Output Class Initialized
INFO - 2017-03-07 13:16:40 --> Security Class Initialized
DEBUG - 2017-03-07 13:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 13:16:40 --> Input Class Initialized
INFO - 2017-03-07 13:16:40 --> Language Class Initialized
INFO - 2017-03-07 13:16:41 --> Loader Class Initialized
INFO - 2017-03-07 13:16:41 --> Database Driver Class Initialized
INFO - 2017-03-07 13:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 13:16:41 --> Controller Class Initialized
INFO - 2017-03-07 13:16:41 --> Helper loaded: url_helper
DEBUG - 2017-03-07 13:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 13:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 13:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 13:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 13:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 13:16:42 --> Final output sent to browser
DEBUG - 2017-03-07 13:16:42 --> Total execution time: 1.5843
INFO - 2017-03-07 13:16:45 --> Config Class Initialized
INFO - 2017-03-07 13:16:45 --> Hooks Class Initialized
DEBUG - 2017-03-07 13:16:45 --> UTF-8 Support Enabled
INFO - 2017-03-07 13:16:45 --> Utf8 Class Initialized
INFO - 2017-03-07 13:16:45 --> URI Class Initialized
INFO - 2017-03-07 13:16:46 --> Router Class Initialized
INFO - 2017-03-07 13:16:46 --> Output Class Initialized
INFO - 2017-03-07 13:16:46 --> Security Class Initialized
DEBUG - 2017-03-07 13:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 13:16:46 --> Input Class Initialized
INFO - 2017-03-07 13:16:46 --> Language Class Initialized
INFO - 2017-03-07 13:16:46 --> Loader Class Initialized
INFO - 2017-03-07 13:16:46 --> Database Driver Class Initialized
INFO - 2017-03-07 13:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 13:16:46 --> Controller Class Initialized
INFO - 2017-03-07 13:16:46 --> Helper loaded: url_helper
DEBUG - 2017-03-07 13:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 13:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 13:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 13:16:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 13:16:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 13:16:47 --> Final output sent to browser
DEBUG - 2017-03-07 13:16:47 --> Total execution time: 1.2795
INFO - 2017-03-07 14:55:32 --> Config Class Initialized
INFO - 2017-03-07 14:55:32 --> Hooks Class Initialized
DEBUG - 2017-03-07 14:55:32 --> UTF-8 Support Enabled
INFO - 2017-03-07 14:55:32 --> Utf8 Class Initialized
INFO - 2017-03-07 14:55:32 --> URI Class Initialized
DEBUG - 2017-03-07 14:55:32 --> No URI present. Default controller set.
INFO - 2017-03-07 14:55:32 --> Router Class Initialized
INFO - 2017-03-07 14:55:32 --> Output Class Initialized
INFO - 2017-03-07 14:55:32 --> Security Class Initialized
DEBUG - 2017-03-07 14:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 14:55:32 --> Input Class Initialized
INFO - 2017-03-07 14:55:32 --> Language Class Initialized
INFO - 2017-03-07 14:55:32 --> Loader Class Initialized
INFO - 2017-03-07 14:55:33 --> Database Driver Class Initialized
INFO - 2017-03-07 14:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 14:55:33 --> Controller Class Initialized
INFO - 2017-03-07 14:55:33 --> Helper loaded: url_helper
DEBUG - 2017-03-07 14:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 14:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 14:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 14:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 14:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 14:55:34 --> Final output sent to browser
DEBUG - 2017-03-07 14:55:34 --> Total execution time: 1.9875
INFO - 2017-03-07 17:25:44 --> Config Class Initialized
INFO - 2017-03-07 17:25:44 --> Hooks Class Initialized
DEBUG - 2017-03-07 17:25:45 --> UTF-8 Support Enabled
INFO - 2017-03-07 17:25:45 --> Utf8 Class Initialized
INFO - 2017-03-07 17:25:45 --> URI Class Initialized
DEBUG - 2017-03-07 17:25:45 --> No URI present. Default controller set.
INFO - 2017-03-07 17:25:45 --> Router Class Initialized
INFO - 2017-03-07 17:25:45 --> Output Class Initialized
INFO - 2017-03-07 17:25:45 --> Security Class Initialized
DEBUG - 2017-03-07 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 17:25:46 --> Input Class Initialized
INFO - 2017-03-07 17:25:46 --> Language Class Initialized
INFO - 2017-03-07 17:25:46 --> Loader Class Initialized
INFO - 2017-03-07 17:25:46 --> Database Driver Class Initialized
INFO - 2017-03-07 17:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 17:25:47 --> Controller Class Initialized
INFO - 2017-03-07 17:25:47 --> Helper loaded: url_helper
DEBUG - 2017-03-07 17:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 17:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 17:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 17:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 17:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 17:25:48 --> Final output sent to browser
DEBUG - 2017-03-07 17:25:48 --> Total execution time: 5.1002
INFO - 2017-03-07 17:26:17 --> Config Class Initialized
INFO - 2017-03-07 17:26:17 --> Hooks Class Initialized
DEBUG - 2017-03-07 17:26:17 --> UTF-8 Support Enabled
INFO - 2017-03-07 17:26:17 --> Utf8 Class Initialized
INFO - 2017-03-07 17:26:17 --> URI Class Initialized
INFO - 2017-03-07 17:26:17 --> Router Class Initialized
INFO - 2017-03-07 17:26:18 --> Output Class Initialized
INFO - 2017-03-07 17:26:18 --> Security Class Initialized
DEBUG - 2017-03-07 17:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 17:26:18 --> Input Class Initialized
INFO - 2017-03-07 17:26:18 --> Language Class Initialized
INFO - 2017-03-07 17:26:18 --> Loader Class Initialized
INFO - 2017-03-07 17:26:18 --> Database Driver Class Initialized
INFO - 2017-03-07 17:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 17:26:19 --> Controller Class Initialized
INFO - 2017-03-07 17:26:19 --> Helper loaded: url_helper
DEBUG - 2017-03-07 17:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 17:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 17:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 17:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 17:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 17:26:20 --> Final output sent to browser
DEBUG - 2017-03-07 17:26:20 --> Total execution time: 3.1124
INFO - 2017-03-07 17:29:59 --> Config Class Initialized
INFO - 2017-03-07 17:29:59 --> Hooks Class Initialized
DEBUG - 2017-03-07 17:30:00 --> UTF-8 Support Enabled
INFO - 2017-03-07 17:30:00 --> Utf8 Class Initialized
INFO - 2017-03-07 17:30:00 --> URI Class Initialized
INFO - 2017-03-07 17:30:00 --> Router Class Initialized
INFO - 2017-03-07 17:30:00 --> Output Class Initialized
INFO - 2017-03-07 17:30:00 --> Security Class Initialized
DEBUG - 2017-03-07 17:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 17:30:00 --> Input Class Initialized
INFO - 2017-03-07 17:30:00 --> Language Class Initialized
INFO - 2017-03-07 17:30:00 --> Loader Class Initialized
INFO - 2017-03-07 17:30:00 --> Database Driver Class Initialized
INFO - 2017-03-07 17:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 17:30:00 --> Controller Class Initialized
INFO - 2017-03-07 17:30:00 --> Helper loaded: url_helper
DEBUG - 2017-03-07 17:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 17:30:01 --> Config Class Initialized
INFO - 2017-03-07 17:30:01 --> Hooks Class Initialized
DEBUG - 2017-03-07 17:30:01 --> UTF-8 Support Enabled
INFO - 2017-03-07 17:30:01 --> Utf8 Class Initialized
INFO - 2017-03-07 17:30:01 --> URI Class Initialized
INFO - 2017-03-07 17:30:01 --> Router Class Initialized
INFO - 2017-03-07 17:30:01 --> Output Class Initialized
INFO - 2017-03-07 17:30:01 --> Security Class Initialized
DEBUG - 2017-03-07 17:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 17:30:01 --> Input Class Initialized
INFO - 2017-03-07 17:30:01 --> Language Class Initialized
INFO - 2017-03-07 17:30:01 --> Loader Class Initialized
INFO - 2017-03-07 17:30:01 --> Database Driver Class Initialized
INFO - 2017-03-07 17:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 17:30:01 --> Controller Class Initialized
INFO - 2017-03-07 17:30:01 --> Helper loaded: date_helper
DEBUG - 2017-03-07 17:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 17:30:01 --> Helper loaded: url_helper
INFO - 2017-03-07 17:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 17:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 17:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 17:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 17:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 17:30:01 --> Final output sent to browser
DEBUG - 2017-03-07 17:30:01 --> Total execution time: 0.1774
INFO - 2017-03-07 17:30:12 --> Config Class Initialized
INFO - 2017-03-07 17:30:12 --> Hooks Class Initialized
DEBUG - 2017-03-07 17:30:12 --> UTF-8 Support Enabled
INFO - 2017-03-07 17:30:12 --> Utf8 Class Initialized
INFO - 2017-03-07 17:30:12 --> URI Class Initialized
INFO - 2017-03-07 17:30:12 --> Router Class Initialized
INFO - 2017-03-07 17:30:12 --> Output Class Initialized
INFO - 2017-03-07 17:30:12 --> Security Class Initialized
DEBUG - 2017-03-07 17:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 17:30:12 --> Input Class Initialized
INFO - 2017-03-07 17:30:12 --> Language Class Initialized
INFO - 2017-03-07 17:30:12 --> Loader Class Initialized
INFO - 2017-03-07 17:30:13 --> Database Driver Class Initialized
INFO - 2017-03-07 17:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 17:30:13 --> Controller Class Initialized
INFO - 2017-03-07 17:30:13 --> Helper loaded: url_helper
DEBUG - 2017-03-07 17:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 17:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 17:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 17:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 17:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 17:30:13 --> Final output sent to browser
DEBUG - 2017-03-07 17:30:13 --> Total execution time: 1.5588
INFO - 2017-03-07 17:46:59 --> Config Class Initialized
INFO - 2017-03-07 17:46:59 --> Hooks Class Initialized
DEBUG - 2017-03-07 17:46:59 --> UTF-8 Support Enabled
INFO - 2017-03-07 17:46:59 --> Utf8 Class Initialized
INFO - 2017-03-07 17:46:59 --> URI Class Initialized
DEBUG - 2017-03-07 17:47:00 --> No URI present. Default controller set.
INFO - 2017-03-07 17:47:00 --> Router Class Initialized
INFO - 2017-03-07 17:47:00 --> Output Class Initialized
INFO - 2017-03-07 17:47:00 --> Security Class Initialized
DEBUG - 2017-03-07 17:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 17:47:00 --> Input Class Initialized
INFO - 2017-03-07 17:47:00 --> Language Class Initialized
INFO - 2017-03-07 17:47:00 --> Loader Class Initialized
INFO - 2017-03-07 17:47:00 --> Database Driver Class Initialized
INFO - 2017-03-07 17:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 17:47:00 --> Controller Class Initialized
INFO - 2017-03-07 17:47:00 --> Helper loaded: url_helper
DEBUG - 2017-03-07 17:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 17:47:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 17:47:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 17:47:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 17:47:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 17:47:01 --> Final output sent to browser
DEBUG - 2017-03-07 17:47:01 --> Total execution time: 1.5051
INFO - 2017-03-07 17:47:12 --> Config Class Initialized
INFO - 2017-03-07 17:47:12 --> Hooks Class Initialized
DEBUG - 2017-03-07 17:47:12 --> UTF-8 Support Enabled
INFO - 2017-03-07 17:47:13 --> Utf8 Class Initialized
INFO - 2017-03-07 17:47:13 --> URI Class Initialized
INFO - 2017-03-07 17:47:13 --> Router Class Initialized
INFO - 2017-03-07 17:47:13 --> Output Class Initialized
INFO - 2017-03-07 17:47:13 --> Security Class Initialized
DEBUG - 2017-03-07 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 17:47:13 --> Input Class Initialized
INFO - 2017-03-07 17:47:13 --> Language Class Initialized
INFO - 2017-03-07 17:47:13 --> Loader Class Initialized
INFO - 2017-03-07 17:47:13 --> Database Driver Class Initialized
INFO - 2017-03-07 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 17:47:13 --> Controller Class Initialized
INFO - 2017-03-07 17:47:13 --> Helper loaded: url_helper
DEBUG - 2017-03-07 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 17:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 17:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 17:47:14 --> Final output sent to browser
DEBUG - 2017-03-07 17:47:14 --> Total execution time: 1.6895
INFO - 2017-03-07 19:56:30 --> Config Class Initialized
INFO - 2017-03-07 19:56:30 --> Hooks Class Initialized
DEBUG - 2017-03-07 19:56:31 --> UTF-8 Support Enabled
INFO - 2017-03-07 19:56:31 --> Utf8 Class Initialized
INFO - 2017-03-07 19:56:31 --> URI Class Initialized
INFO - 2017-03-07 19:56:31 --> Router Class Initialized
INFO - 2017-03-07 19:56:31 --> Output Class Initialized
INFO - 2017-03-07 19:56:31 --> Security Class Initialized
DEBUG - 2017-03-07 19:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 19:56:31 --> Input Class Initialized
INFO - 2017-03-07 19:56:31 --> Language Class Initialized
INFO - 2017-03-07 19:56:31 --> Loader Class Initialized
INFO - 2017-03-07 19:56:31 --> Database Driver Class Initialized
INFO - 2017-03-07 19:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 19:56:32 --> Controller Class Initialized
INFO - 2017-03-07 19:56:32 --> Helper loaded: date_helper
DEBUG - 2017-03-07 19:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 19:56:32 --> Helper loaded: url_helper
INFO - 2017-03-07 19:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 19:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 19:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 19:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 19:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 19:56:33 --> Final output sent to browser
DEBUG - 2017-03-07 19:56:33 --> Total execution time: 2.5625
INFO - 2017-03-07 20:29:50 --> Config Class Initialized
INFO - 2017-03-07 20:29:50 --> Hooks Class Initialized
DEBUG - 2017-03-07 20:29:50 --> UTF-8 Support Enabled
INFO - 2017-03-07 20:29:50 --> Utf8 Class Initialized
INFO - 2017-03-07 20:29:50 --> URI Class Initialized
DEBUG - 2017-03-07 20:29:50 --> No URI present. Default controller set.
INFO - 2017-03-07 20:29:50 --> Router Class Initialized
INFO - 2017-03-07 20:29:50 --> Output Class Initialized
INFO - 2017-03-07 20:29:50 --> Security Class Initialized
DEBUG - 2017-03-07 20:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 20:29:50 --> Input Class Initialized
INFO - 2017-03-07 20:29:50 --> Language Class Initialized
INFO - 2017-03-07 20:29:50 --> Loader Class Initialized
INFO - 2017-03-07 20:29:51 --> Database Driver Class Initialized
INFO - 2017-03-07 20:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 20:29:51 --> Controller Class Initialized
INFO - 2017-03-07 20:29:51 --> Helper loaded: url_helper
DEBUG - 2017-03-07 20:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 20:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 20:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 20:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 20:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 20:29:52 --> Final output sent to browser
DEBUG - 2017-03-07 20:29:52 --> Total execution time: 2.1398
INFO - 2017-03-07 21:13:34 --> Config Class Initialized
INFO - 2017-03-07 21:13:34 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:13:34 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:13:34 --> Utf8 Class Initialized
INFO - 2017-03-07 21:13:34 --> URI Class Initialized
DEBUG - 2017-03-07 21:13:34 --> No URI present. Default controller set.
INFO - 2017-03-07 21:13:34 --> Router Class Initialized
INFO - 2017-03-07 21:13:34 --> Output Class Initialized
INFO - 2017-03-07 21:13:34 --> Security Class Initialized
DEBUG - 2017-03-07 21:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:13:34 --> Input Class Initialized
INFO - 2017-03-07 21:13:34 --> Language Class Initialized
INFO - 2017-03-07 21:13:34 --> Loader Class Initialized
INFO - 2017-03-07 21:13:35 --> Database Driver Class Initialized
INFO - 2017-03-07 21:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:13:36 --> Controller Class Initialized
INFO - 2017-03-07 21:13:36 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:13:36 --> Final output sent to browser
DEBUG - 2017-03-07 21:13:36 --> Total execution time: 2.3008
INFO - 2017-03-07 21:13:38 --> Config Class Initialized
INFO - 2017-03-07 21:13:38 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:13:39 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:13:39 --> Utf8 Class Initialized
INFO - 2017-03-07 21:13:39 --> URI Class Initialized
DEBUG - 2017-03-07 21:13:39 --> No URI present. Default controller set.
INFO - 2017-03-07 21:13:39 --> Router Class Initialized
INFO - 2017-03-07 21:13:39 --> Output Class Initialized
INFO - 2017-03-07 21:13:39 --> Security Class Initialized
DEBUG - 2017-03-07 21:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:13:39 --> Input Class Initialized
INFO - 2017-03-07 21:13:39 --> Language Class Initialized
INFO - 2017-03-07 21:13:39 --> Loader Class Initialized
INFO - 2017-03-07 21:13:39 --> Database Driver Class Initialized
INFO - 2017-03-07 21:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:13:40 --> Controller Class Initialized
INFO - 2017-03-07 21:13:40 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:13:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:13:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:13:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:13:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:13:41 --> Final output sent to browser
DEBUG - 2017-03-07 21:13:41 --> Total execution time: 2.6938
INFO - 2017-03-07 21:13:50 --> Config Class Initialized
INFO - 2017-03-07 21:13:50 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:13:50 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:13:50 --> Utf8 Class Initialized
INFO - 2017-03-07 21:13:50 --> URI Class Initialized
INFO - 2017-03-07 21:13:50 --> Router Class Initialized
INFO - 2017-03-07 21:13:50 --> Output Class Initialized
INFO - 2017-03-07 21:13:50 --> Security Class Initialized
DEBUG - 2017-03-07 21:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:13:50 --> Input Class Initialized
INFO - 2017-03-07 21:13:50 --> Language Class Initialized
INFO - 2017-03-07 21:13:51 --> Loader Class Initialized
INFO - 2017-03-07 21:13:51 --> Database Driver Class Initialized
INFO - 2017-03-07 21:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:13:51 --> Controller Class Initialized
INFO - 2017-03-07 21:13:51 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:13:52 --> Final output sent to browser
DEBUG - 2017-03-07 21:13:52 --> Total execution time: 1.7207
INFO - 2017-03-07 21:14:31 --> Config Class Initialized
INFO - 2017-03-07 21:14:31 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:14:31 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:14:31 --> Utf8 Class Initialized
INFO - 2017-03-07 21:14:31 --> URI Class Initialized
INFO - 2017-03-07 21:14:31 --> Router Class Initialized
INFO - 2017-03-07 21:14:31 --> Output Class Initialized
INFO - 2017-03-07 21:14:31 --> Security Class Initialized
DEBUG - 2017-03-07 21:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:14:31 --> Input Class Initialized
INFO - 2017-03-07 21:14:31 --> Language Class Initialized
INFO - 2017-03-07 21:14:31 --> Loader Class Initialized
INFO - 2017-03-07 21:14:32 --> Database Driver Class Initialized
INFO - 2017-03-07 21:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:14:32 --> Controller Class Initialized
INFO - 2017-03-07 21:14:32 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:14:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-07 21:14:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-07 21:14:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-07 21:14:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-07 21:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:14:45 --> Final output sent to browser
DEBUG - 2017-03-07 21:14:45 --> Total execution time: 13.9450
INFO - 2017-03-07 21:15:01 --> Config Class Initialized
INFO - 2017-03-07 21:15:01 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:15:01 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:15:01 --> Utf8 Class Initialized
INFO - 2017-03-07 21:15:01 --> URI Class Initialized
INFO - 2017-03-07 21:15:01 --> Router Class Initialized
INFO - 2017-03-07 21:15:01 --> Output Class Initialized
INFO - 2017-03-07 21:15:01 --> Security Class Initialized
DEBUG - 2017-03-07 21:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:15:01 --> Input Class Initialized
INFO - 2017-03-07 21:15:01 --> Language Class Initialized
INFO - 2017-03-07 21:15:01 --> Loader Class Initialized
INFO - 2017-03-07 21:15:01 --> Database Driver Class Initialized
INFO - 2017-03-07 21:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:15:02 --> Controller Class Initialized
INFO - 2017-03-07 21:15:02 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:15:03 --> Final output sent to browser
DEBUG - 2017-03-07 21:15:03 --> Total execution time: 2.1950
INFO - 2017-03-07 21:15:13 --> Config Class Initialized
INFO - 2017-03-07 21:15:13 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:15:13 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:15:13 --> Utf8 Class Initialized
INFO - 2017-03-07 21:15:13 --> URI Class Initialized
INFO - 2017-03-07 21:15:14 --> Router Class Initialized
INFO - 2017-03-07 21:15:14 --> Output Class Initialized
INFO - 2017-03-07 21:15:14 --> Security Class Initialized
DEBUG - 2017-03-07 21:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:15:14 --> Input Class Initialized
INFO - 2017-03-07 21:15:14 --> Language Class Initialized
INFO - 2017-03-07 21:15:14 --> Loader Class Initialized
INFO - 2017-03-07 21:15:14 --> Database Driver Class Initialized
INFO - 2017-03-07 21:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:15:15 --> Controller Class Initialized
INFO - 2017-03-07 21:15:15 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:15:42 --> Config Class Initialized
INFO - 2017-03-07 21:15:42 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:15:43 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:15:43 --> Utf8 Class Initialized
INFO - 2017-03-07 21:15:43 --> URI Class Initialized
INFO - 2017-03-07 21:15:43 --> Router Class Initialized
INFO - 2017-03-07 21:15:43 --> Output Class Initialized
INFO - 2017-03-07 21:15:43 --> Security Class Initialized
DEBUG - 2017-03-07 21:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:15:43 --> Input Class Initialized
INFO - 2017-03-07 21:15:43 --> Language Class Initialized
INFO - 2017-03-07 21:15:43 --> Loader Class Initialized
INFO - 2017-03-07 21:15:44 --> Database Driver Class Initialized
INFO - 2017-03-07 21:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:15:44 --> Controller Class Initialized
INFO - 2017-03-07 21:15:44 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:15:44 --> Helper loaded: url_helper
INFO - 2017-03-07 21:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 21:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 21:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 21:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:15:45 --> Final output sent to browser
DEBUG - 2017-03-07 21:15:45 --> Total execution time: 2.5175
INFO - 2017-03-07 21:16:02 --> Config Class Initialized
INFO - 2017-03-07 21:16:02 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:16:02 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:16:02 --> Utf8 Class Initialized
INFO - 2017-03-07 21:16:02 --> URI Class Initialized
INFO - 2017-03-07 21:16:02 --> Router Class Initialized
INFO - 2017-03-07 21:16:02 --> Output Class Initialized
INFO - 2017-03-07 21:16:03 --> Security Class Initialized
DEBUG - 2017-03-07 21:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:16:03 --> Input Class Initialized
INFO - 2017-03-07 21:16:03 --> Language Class Initialized
INFO - 2017-03-07 21:16:03 --> Loader Class Initialized
INFO - 2017-03-07 21:16:03 --> Database Driver Class Initialized
INFO - 2017-03-07 21:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:16:04 --> Controller Class Initialized
INFO - 2017-03-07 21:16:04 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:16:05 --> Final output sent to browser
DEBUG - 2017-03-07 21:16:05 --> Total execution time: 2.9736
INFO - 2017-03-07 21:16:06 --> Config Class Initialized
INFO - 2017-03-07 21:16:06 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:16:06 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:16:06 --> Utf8 Class Initialized
INFO - 2017-03-07 21:16:06 --> URI Class Initialized
INFO - 2017-03-07 21:16:07 --> Router Class Initialized
INFO - 2017-03-07 21:16:07 --> Output Class Initialized
INFO - 2017-03-07 21:16:07 --> Security Class Initialized
DEBUG - 2017-03-07 21:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:16:07 --> Input Class Initialized
INFO - 2017-03-07 21:16:07 --> Language Class Initialized
INFO - 2017-03-07 21:16:07 --> Loader Class Initialized
INFO - 2017-03-07 21:16:07 --> Database Driver Class Initialized
INFO - 2017-03-07 21:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:16:07 --> Controller Class Initialized
INFO - 2017-03-07 21:16:07 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:16:14 --> Config Class Initialized
INFO - 2017-03-07 21:16:14 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:16:14 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:16:14 --> Utf8 Class Initialized
INFO - 2017-03-07 21:16:14 --> URI Class Initialized
INFO - 2017-03-07 21:16:14 --> Router Class Initialized
INFO - 2017-03-07 21:16:14 --> Output Class Initialized
INFO - 2017-03-07 21:16:14 --> Security Class Initialized
DEBUG - 2017-03-07 21:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:16:14 --> Input Class Initialized
INFO - 2017-03-07 21:16:14 --> Language Class Initialized
INFO - 2017-03-07 21:16:14 --> Loader Class Initialized
INFO - 2017-03-07 21:16:15 --> Database Driver Class Initialized
INFO - 2017-03-07 21:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:16:15 --> Controller Class Initialized
INFO - 2017-03-07 21:16:15 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:16:15 --> Helper loaded: url_helper
INFO - 2017-03-07 21:16:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:16:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 21:16:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 21:16:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 21:16:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:16:15 --> Final output sent to browser
DEBUG - 2017-03-07 21:16:15 --> Total execution time: 1.2088
INFO - 2017-03-07 21:16:26 --> Config Class Initialized
INFO - 2017-03-07 21:16:26 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:16:26 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:16:26 --> Utf8 Class Initialized
INFO - 2017-03-07 21:16:26 --> URI Class Initialized
INFO - 2017-03-07 21:16:26 --> Router Class Initialized
INFO - 2017-03-07 21:16:27 --> Output Class Initialized
INFO - 2017-03-07 21:16:27 --> Security Class Initialized
DEBUG - 2017-03-07 21:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:16:27 --> Input Class Initialized
INFO - 2017-03-07 21:16:27 --> Language Class Initialized
INFO - 2017-03-07 21:16:27 --> Loader Class Initialized
INFO - 2017-03-07 21:16:27 --> Database Driver Class Initialized
INFO - 2017-03-07 21:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:16:28 --> Controller Class Initialized
INFO - 2017-03-07 21:16:28 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:16:28 --> Final output sent to browser
DEBUG - 2017-03-07 21:16:28 --> Total execution time: 1.8342
INFO - 2017-03-07 21:16:43 --> Config Class Initialized
INFO - 2017-03-07 21:16:43 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:16:43 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:16:43 --> Utf8 Class Initialized
INFO - 2017-03-07 21:16:43 --> URI Class Initialized
DEBUG - 2017-03-07 21:16:43 --> No URI present. Default controller set.
INFO - 2017-03-07 21:16:43 --> Router Class Initialized
INFO - 2017-03-07 21:16:43 --> Output Class Initialized
INFO - 2017-03-07 21:16:43 --> Security Class Initialized
DEBUG - 2017-03-07 21:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:16:43 --> Input Class Initialized
INFO - 2017-03-07 21:16:43 --> Language Class Initialized
INFO - 2017-03-07 21:16:44 --> Loader Class Initialized
INFO - 2017-03-07 21:16:44 --> Database Driver Class Initialized
INFO - 2017-03-07 21:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:16:44 --> Controller Class Initialized
INFO - 2017-03-07 21:16:44 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:16:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:16:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:16:45 --> Final output sent to browser
DEBUG - 2017-03-07 21:16:45 --> Total execution time: 1.7024
INFO - 2017-03-07 21:16:53 --> Config Class Initialized
INFO - 2017-03-07 21:16:53 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:16:53 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:16:53 --> Utf8 Class Initialized
INFO - 2017-03-07 21:16:53 --> URI Class Initialized
INFO - 2017-03-07 21:16:53 --> Router Class Initialized
INFO - 2017-03-07 21:16:53 --> Output Class Initialized
INFO - 2017-03-07 21:16:53 --> Security Class Initialized
DEBUG - 2017-03-07 21:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:16:53 --> Input Class Initialized
INFO - 2017-03-07 21:16:53 --> Language Class Initialized
INFO - 2017-03-07 21:16:53 --> Loader Class Initialized
INFO - 2017-03-07 21:16:54 --> Database Driver Class Initialized
INFO - 2017-03-07 21:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:16:54 --> Controller Class Initialized
INFO - 2017-03-07 21:16:54 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:16:54 --> Final output sent to browser
DEBUG - 2017-03-07 21:16:54 --> Total execution time: 1.4953
INFO - 2017-03-07 21:16:56 --> Config Class Initialized
INFO - 2017-03-07 21:16:56 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:16:56 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:16:56 --> Utf8 Class Initialized
INFO - 2017-03-07 21:16:56 --> URI Class Initialized
INFO - 2017-03-07 21:16:56 --> Router Class Initialized
INFO - 2017-03-07 21:16:56 --> Output Class Initialized
INFO - 2017-03-07 21:16:56 --> Security Class Initialized
DEBUG - 2017-03-07 21:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:16:56 --> Input Class Initialized
INFO - 2017-03-07 21:16:56 --> Language Class Initialized
INFO - 2017-03-07 21:16:56 --> Loader Class Initialized
INFO - 2017-03-07 21:16:56 --> Database Driver Class Initialized
INFO - 2017-03-07 21:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:16:56 --> Controller Class Initialized
INFO - 2017-03-07 21:16:56 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:17:10 --> Config Class Initialized
INFO - 2017-03-07 21:17:10 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:17:10 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:17:10 --> Utf8 Class Initialized
INFO - 2017-03-07 21:17:10 --> URI Class Initialized
INFO - 2017-03-07 21:17:10 --> Router Class Initialized
INFO - 2017-03-07 21:17:11 --> Output Class Initialized
INFO - 2017-03-07 21:17:11 --> Security Class Initialized
DEBUG - 2017-03-07 21:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:17:11 --> Input Class Initialized
INFO - 2017-03-07 21:17:11 --> Language Class Initialized
INFO - 2017-03-07 21:17:11 --> Loader Class Initialized
INFO - 2017-03-07 21:17:11 --> Database Driver Class Initialized
INFO - 2017-03-07 21:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:17:11 --> Controller Class Initialized
INFO - 2017-03-07 21:17:11 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:17:11 --> Helper loaded: url_helper
INFO - 2017-03-07 21:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 21:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 21:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 21:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:17:12 --> Final output sent to browser
DEBUG - 2017-03-07 21:17:12 --> Total execution time: 1.3089
INFO - 2017-03-07 21:17:22 --> Config Class Initialized
INFO - 2017-03-07 21:17:22 --> Config Class Initialized
INFO - 2017-03-07 21:17:22 --> Hooks Class Initialized
INFO - 2017-03-07 21:17:22 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:17:22 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:17:22 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:17:22 --> Utf8 Class Initialized
INFO - 2017-03-07 21:17:22 --> Utf8 Class Initialized
INFO - 2017-03-07 21:17:22 --> URI Class Initialized
INFO - 2017-03-07 21:17:22 --> URI Class Initialized
INFO - 2017-03-07 21:17:22 --> Router Class Initialized
INFO - 2017-03-07 21:17:22 --> Output Class Initialized
INFO - 2017-03-07 21:17:22 --> Security Class Initialized
DEBUG - 2017-03-07 21:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:17:22 --> Input Class Initialized
INFO - 2017-03-07 21:17:22 --> Language Class Initialized
DEBUG - 2017-03-07 21:17:22 --> No URI present. Default controller set.
INFO - 2017-03-07 21:17:22 --> Router Class Initialized
INFO - 2017-03-07 21:17:22 --> Loader Class Initialized
INFO - 2017-03-07 21:17:22 --> Output Class Initialized
INFO - 2017-03-07 21:17:22 --> Security Class Initialized
DEBUG - 2017-03-07 21:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:17:22 --> Input Class Initialized
INFO - 2017-03-07 21:17:22 --> Language Class Initialized
INFO - 2017-03-07 21:17:22 --> Loader Class Initialized
INFO - 2017-03-07 21:17:23 --> Database Driver Class Initialized
INFO - 2017-03-07 21:17:23 --> Database Driver Class Initialized
INFO - 2017-03-07 21:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:17:23 --> Controller Class Initialized
INFO - 2017-03-07 21:17:23 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:17:23 --> Final output sent to browser
DEBUG - 2017-03-07 21:17:24 --> Total execution time: 1.8079
INFO - 2017-03-07 21:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:17:24 --> Controller Class Initialized
INFO - 2017-03-07 21:17:24 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:17:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:17:24 --> Final output sent to browser
DEBUG - 2017-03-07 21:17:24 --> Total execution time: 2.5125
INFO - 2017-03-07 21:17:31 --> Config Class Initialized
INFO - 2017-03-07 21:17:31 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:17:32 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:17:32 --> Utf8 Class Initialized
INFO - 2017-03-07 21:17:32 --> URI Class Initialized
INFO - 2017-03-07 21:17:32 --> Router Class Initialized
INFO - 2017-03-07 21:17:32 --> Output Class Initialized
INFO - 2017-03-07 21:17:32 --> Security Class Initialized
DEBUG - 2017-03-07 21:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:17:32 --> Input Class Initialized
INFO - 2017-03-07 21:17:32 --> Language Class Initialized
INFO - 2017-03-07 21:17:32 --> Loader Class Initialized
INFO - 2017-03-07 21:17:32 --> Database Driver Class Initialized
INFO - 2017-03-07 21:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:17:33 --> Controller Class Initialized
INFO - 2017-03-07 21:17:33 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:17:33 --> Final output sent to browser
DEBUG - 2017-03-07 21:17:33 --> Total execution time: 1.5510
INFO - 2017-03-07 21:18:22 --> Config Class Initialized
INFO - 2017-03-07 21:18:22 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:18:22 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:18:22 --> Utf8 Class Initialized
INFO - 2017-03-07 21:18:22 --> URI Class Initialized
INFO - 2017-03-07 21:18:22 --> Router Class Initialized
INFO - 2017-03-07 21:18:22 --> Output Class Initialized
INFO - 2017-03-07 21:18:22 --> Security Class Initialized
DEBUG - 2017-03-07 21:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:18:22 --> Input Class Initialized
INFO - 2017-03-07 21:18:22 --> Language Class Initialized
INFO - 2017-03-07 21:18:22 --> Loader Class Initialized
INFO - 2017-03-07 21:18:23 --> Database Driver Class Initialized
INFO - 2017-03-07 21:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:18:23 --> Controller Class Initialized
INFO - 2017-03-07 21:18:23 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:18:23 --> Final output sent to browser
DEBUG - 2017-03-07 21:18:23 --> Total execution time: 1.6793
INFO - 2017-03-07 21:18:36 --> Config Class Initialized
INFO - 2017-03-07 21:18:36 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:18:36 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:18:36 --> Utf8 Class Initialized
INFO - 2017-03-07 21:18:36 --> URI Class Initialized
INFO - 2017-03-07 21:18:36 --> Router Class Initialized
INFO - 2017-03-07 21:18:36 --> Output Class Initialized
INFO - 2017-03-07 21:18:36 --> Security Class Initialized
DEBUG - 2017-03-07 21:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:18:36 --> Input Class Initialized
INFO - 2017-03-07 21:18:36 --> Language Class Initialized
INFO - 2017-03-07 21:18:36 --> Loader Class Initialized
INFO - 2017-03-07 21:18:37 --> Database Driver Class Initialized
INFO - 2017-03-07 21:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:18:37 --> Controller Class Initialized
INFO - 2017-03-07 21:18:37 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:18:38 --> Final output sent to browser
DEBUG - 2017-03-07 21:18:38 --> Total execution time: 1.9429
INFO - 2017-03-07 21:18:56 --> Config Class Initialized
INFO - 2017-03-07 21:18:56 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:18:56 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:18:56 --> Utf8 Class Initialized
INFO - 2017-03-07 21:18:56 --> URI Class Initialized
INFO - 2017-03-07 21:18:56 --> Router Class Initialized
INFO - 2017-03-07 21:18:56 --> Output Class Initialized
INFO - 2017-03-07 21:18:57 --> Security Class Initialized
DEBUG - 2017-03-07 21:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:18:57 --> Input Class Initialized
INFO - 2017-03-07 21:18:57 --> Language Class Initialized
INFO - 2017-03-07 21:18:57 --> Loader Class Initialized
INFO - 2017-03-07 21:18:57 --> Database Driver Class Initialized
INFO - 2017-03-07 21:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:18:58 --> Controller Class Initialized
INFO - 2017-03-07 21:18:58 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:18:58 --> Final output sent to browser
DEBUG - 2017-03-07 21:18:58 --> Total execution time: 1.9925
INFO - 2017-03-07 21:19:07 --> Config Class Initialized
INFO - 2017-03-07 21:19:07 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:19:07 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:19:07 --> Utf8 Class Initialized
INFO - 2017-03-07 21:19:07 --> URI Class Initialized
INFO - 2017-03-07 21:19:07 --> Router Class Initialized
INFO - 2017-03-07 21:19:07 --> Output Class Initialized
INFO - 2017-03-07 21:19:07 --> Security Class Initialized
DEBUG - 2017-03-07 21:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:19:07 --> Input Class Initialized
INFO - 2017-03-07 21:19:07 --> Language Class Initialized
INFO - 2017-03-07 21:19:07 --> Loader Class Initialized
INFO - 2017-03-07 21:19:08 --> Database Driver Class Initialized
INFO - 2017-03-07 21:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:19:08 --> Controller Class Initialized
INFO - 2017-03-07 21:19:08 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:19:08 --> Final output sent to browser
DEBUG - 2017-03-07 21:19:08 --> Total execution time: 1.4960
INFO - 2017-03-07 21:19:26 --> Config Class Initialized
INFO - 2017-03-07 21:19:26 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:19:26 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:19:26 --> Utf8 Class Initialized
INFO - 2017-03-07 21:19:26 --> URI Class Initialized
INFO - 2017-03-07 21:19:26 --> Router Class Initialized
INFO - 2017-03-07 21:19:26 --> Output Class Initialized
INFO - 2017-03-07 21:19:26 --> Security Class Initialized
DEBUG - 2017-03-07 21:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:19:26 --> Input Class Initialized
INFO - 2017-03-07 21:19:26 --> Language Class Initialized
INFO - 2017-03-07 21:19:26 --> Loader Class Initialized
INFO - 2017-03-07 21:19:26 --> Database Driver Class Initialized
INFO - 2017-03-07 21:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:19:27 --> Controller Class Initialized
INFO - 2017-03-07 21:19:27 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:19:27 --> Final output sent to browser
DEBUG - 2017-03-07 21:19:27 --> Total execution time: 1.7760
INFO - 2017-03-07 21:19:34 --> Config Class Initialized
INFO - 2017-03-07 21:19:34 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:19:34 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:19:34 --> Utf8 Class Initialized
INFO - 2017-03-07 21:19:34 --> URI Class Initialized
INFO - 2017-03-07 21:19:34 --> Router Class Initialized
INFO - 2017-03-07 21:19:34 --> Output Class Initialized
INFO - 2017-03-07 21:19:34 --> Security Class Initialized
DEBUG - 2017-03-07 21:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:19:34 --> Input Class Initialized
INFO - 2017-03-07 21:19:34 --> Language Class Initialized
INFO - 2017-03-07 21:19:34 --> Loader Class Initialized
INFO - 2017-03-07 21:19:35 --> Database Driver Class Initialized
INFO - 2017-03-07 21:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:19:35 --> Controller Class Initialized
INFO - 2017-03-07 21:19:35 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:19:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:19:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:19:36 --> Final output sent to browser
DEBUG - 2017-03-07 21:19:36 --> Total execution time: 1.5046
INFO - 2017-03-07 21:22:05 --> Config Class Initialized
INFO - 2017-03-07 21:22:05 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:22:05 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:22:05 --> Utf8 Class Initialized
INFO - 2017-03-07 21:22:05 --> URI Class Initialized
INFO - 2017-03-07 21:22:05 --> Router Class Initialized
INFO - 2017-03-07 21:22:05 --> Output Class Initialized
INFO - 2017-03-07 21:22:05 --> Security Class Initialized
DEBUG - 2017-03-07 21:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:22:05 --> Input Class Initialized
INFO - 2017-03-07 21:22:05 --> Language Class Initialized
INFO - 2017-03-07 21:22:05 --> Loader Class Initialized
INFO - 2017-03-07 21:22:06 --> Database Driver Class Initialized
INFO - 2017-03-07 21:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:22:07 --> Controller Class Initialized
INFO - 2017-03-07 21:22:07 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:22:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:22:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:22:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:22:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:22:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:22:07 --> Final output sent to browser
DEBUG - 2017-03-07 21:22:07 --> Total execution time: 1.8543
INFO - 2017-03-07 21:22:15 --> Config Class Initialized
INFO - 2017-03-07 21:22:15 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:22:15 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:22:15 --> Utf8 Class Initialized
INFO - 2017-03-07 21:22:16 --> URI Class Initialized
INFO - 2017-03-07 21:22:16 --> Router Class Initialized
INFO - 2017-03-07 21:22:16 --> Output Class Initialized
INFO - 2017-03-07 21:22:16 --> Security Class Initialized
DEBUG - 2017-03-07 21:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:22:16 --> Input Class Initialized
INFO - 2017-03-07 21:22:16 --> Language Class Initialized
INFO - 2017-03-07 21:22:16 --> Loader Class Initialized
INFO - 2017-03-07 21:22:16 --> Database Driver Class Initialized
INFO - 2017-03-07 21:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:22:16 --> Controller Class Initialized
INFO - 2017-03-07 21:22:16 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:22:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:22:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:22:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:22:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:22:17 --> Final output sent to browser
DEBUG - 2017-03-07 21:22:17 --> Total execution time: 1.6730
INFO - 2017-03-07 21:22:23 --> Config Class Initialized
INFO - 2017-03-07 21:22:23 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:22:23 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:22:23 --> Utf8 Class Initialized
INFO - 2017-03-07 21:22:23 --> URI Class Initialized
INFO - 2017-03-07 21:22:23 --> Router Class Initialized
INFO - 2017-03-07 21:22:23 --> Output Class Initialized
INFO - 2017-03-07 21:22:23 --> Security Class Initialized
DEBUG - 2017-03-07 21:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:22:23 --> Input Class Initialized
INFO - 2017-03-07 21:22:23 --> Language Class Initialized
INFO - 2017-03-07 21:22:24 --> Loader Class Initialized
INFO - 2017-03-07 21:22:24 --> Database Driver Class Initialized
INFO - 2017-03-07 21:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:22:24 --> Controller Class Initialized
INFO - 2017-03-07 21:22:24 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:22:25 --> Final output sent to browser
DEBUG - 2017-03-07 21:22:25 --> Total execution time: 1.5793
INFO - 2017-03-07 21:22:29 --> Config Class Initialized
INFO - 2017-03-07 21:22:29 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:22:29 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:22:29 --> Utf8 Class Initialized
INFO - 2017-03-07 21:22:29 --> URI Class Initialized
INFO - 2017-03-07 21:22:29 --> Router Class Initialized
INFO - 2017-03-07 21:22:29 --> Output Class Initialized
INFO - 2017-03-07 21:22:29 --> Security Class Initialized
DEBUG - 2017-03-07 21:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:22:29 --> Input Class Initialized
INFO - 2017-03-07 21:22:29 --> Language Class Initialized
INFO - 2017-03-07 21:22:29 --> Loader Class Initialized
INFO - 2017-03-07 21:22:29 --> Database Driver Class Initialized
INFO - 2017-03-07 21:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:22:30 --> Controller Class Initialized
INFO - 2017-03-07 21:22:30 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:22:30 --> Final output sent to browser
DEBUG - 2017-03-07 21:22:30 --> Total execution time: 1.5982
INFO - 2017-03-07 21:22:35 --> Config Class Initialized
INFO - 2017-03-07 21:22:35 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:22:35 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:22:35 --> Utf8 Class Initialized
INFO - 2017-03-07 21:22:35 --> URI Class Initialized
INFO - 2017-03-07 21:22:35 --> Router Class Initialized
INFO - 2017-03-07 21:22:36 --> Output Class Initialized
INFO - 2017-03-07 21:22:36 --> Security Class Initialized
DEBUG - 2017-03-07 21:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:22:36 --> Input Class Initialized
INFO - 2017-03-07 21:22:36 --> Language Class Initialized
INFO - 2017-03-07 21:22:36 --> Loader Class Initialized
INFO - 2017-03-07 21:22:36 --> Database Driver Class Initialized
INFO - 2017-03-07 21:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:22:37 --> Controller Class Initialized
INFO - 2017-03-07 21:22:37 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:22:54 --> Config Class Initialized
INFO - 2017-03-07 21:22:54 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:22:54 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:22:54 --> Utf8 Class Initialized
INFO - 2017-03-07 21:22:54 --> URI Class Initialized
INFO - 2017-03-07 21:22:54 --> Router Class Initialized
INFO - 2017-03-07 21:22:54 --> Output Class Initialized
INFO - 2017-03-07 21:22:54 --> Security Class Initialized
DEBUG - 2017-03-07 21:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:22:54 --> Input Class Initialized
INFO - 2017-03-07 21:22:54 --> Language Class Initialized
INFO - 2017-03-07 21:22:54 --> Loader Class Initialized
INFO - 2017-03-07 21:22:55 --> Database Driver Class Initialized
INFO - 2017-03-07 21:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:22:55 --> Controller Class Initialized
INFO - 2017-03-07 21:22:55 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:22:55 --> Helper loaded: url_helper
INFO - 2017-03-07 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:22:55 --> Final output sent to browser
DEBUG - 2017-03-07 21:22:55 --> Total execution time: 1.6676
INFO - 2017-03-07 21:23:02 --> Config Class Initialized
INFO - 2017-03-07 21:23:02 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:23:02 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:23:02 --> Utf8 Class Initialized
INFO - 2017-03-07 21:23:02 --> URI Class Initialized
INFO - 2017-03-07 21:23:02 --> Router Class Initialized
INFO - 2017-03-07 21:23:02 --> Output Class Initialized
INFO - 2017-03-07 21:23:02 --> Security Class Initialized
DEBUG - 2017-03-07 21:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:23:02 --> Input Class Initialized
INFO - 2017-03-07 21:23:02 --> Language Class Initialized
INFO - 2017-03-07 21:23:02 --> Loader Class Initialized
INFO - 2017-03-07 21:23:02 --> Database Driver Class Initialized
INFO - 2017-03-07 21:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:23:03 --> Controller Class Initialized
INFO - 2017-03-07 21:23:03 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:23:03 --> Final output sent to browser
DEBUG - 2017-03-07 21:23:03 --> Total execution time: 1.5842
INFO - 2017-03-07 21:32:53 --> Config Class Initialized
INFO - 2017-03-07 21:32:53 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:32:53 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:32:53 --> Utf8 Class Initialized
INFO - 2017-03-07 21:32:53 --> URI Class Initialized
DEBUG - 2017-03-07 21:32:53 --> No URI present. Default controller set.
INFO - 2017-03-07 21:32:53 --> Router Class Initialized
INFO - 2017-03-07 21:32:53 --> Output Class Initialized
INFO - 2017-03-07 21:32:53 --> Security Class Initialized
DEBUG - 2017-03-07 21:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:32:53 --> Input Class Initialized
INFO - 2017-03-07 21:32:53 --> Language Class Initialized
INFO - 2017-03-07 21:32:53 --> Loader Class Initialized
INFO - 2017-03-07 21:32:53 --> Database Driver Class Initialized
INFO - 2017-03-07 21:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:32:54 --> Controller Class Initialized
INFO - 2017-03-07 21:32:54 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:32:54 --> Final output sent to browser
DEBUG - 2017-03-07 21:32:54 --> Total execution time: 1.6677
INFO - 2017-03-07 21:33:01 --> Config Class Initialized
INFO - 2017-03-07 21:33:01 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:33:01 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:33:01 --> Utf8 Class Initialized
INFO - 2017-03-07 21:33:01 --> URI Class Initialized
INFO - 2017-03-07 21:33:01 --> Router Class Initialized
INFO - 2017-03-07 21:33:01 --> Output Class Initialized
INFO - 2017-03-07 21:33:01 --> Security Class Initialized
DEBUG - 2017-03-07 21:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:33:01 --> Input Class Initialized
INFO - 2017-03-07 21:33:01 --> Language Class Initialized
INFO - 2017-03-07 21:33:01 --> Loader Class Initialized
INFO - 2017-03-07 21:33:02 --> Database Driver Class Initialized
INFO - 2017-03-07 21:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:33:02 --> Controller Class Initialized
INFO - 2017-03-07 21:33:02 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:33:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:33:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:33:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:33:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:33:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:33:02 --> Final output sent to browser
DEBUG - 2017-03-07 21:33:02 --> Total execution time: 1.2844
INFO - 2017-03-07 21:33:14 --> Config Class Initialized
INFO - 2017-03-07 21:33:14 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:33:14 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:33:14 --> Utf8 Class Initialized
INFO - 2017-03-07 21:33:14 --> URI Class Initialized
INFO - 2017-03-07 21:33:15 --> Router Class Initialized
INFO - 2017-03-07 21:33:15 --> Output Class Initialized
INFO - 2017-03-07 21:33:15 --> Security Class Initialized
DEBUG - 2017-03-07 21:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:33:15 --> Input Class Initialized
INFO - 2017-03-07 21:33:15 --> Language Class Initialized
INFO - 2017-03-07 21:33:15 --> Loader Class Initialized
INFO - 2017-03-07 21:33:15 --> Database Driver Class Initialized
INFO - 2017-03-07 21:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:33:15 --> Controller Class Initialized
INFO - 2017-03-07 21:33:15 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:33:20 --> Config Class Initialized
INFO - 2017-03-07 21:33:20 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:33:20 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:33:20 --> Utf8 Class Initialized
INFO - 2017-03-07 21:33:20 --> URI Class Initialized
INFO - 2017-03-07 21:33:20 --> Router Class Initialized
INFO - 2017-03-07 21:33:20 --> Output Class Initialized
INFO - 2017-03-07 21:33:20 --> Security Class Initialized
DEBUG - 2017-03-07 21:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:33:20 --> Input Class Initialized
INFO - 2017-03-07 21:33:20 --> Language Class Initialized
INFO - 2017-03-07 21:33:20 --> Loader Class Initialized
INFO - 2017-03-07 21:33:20 --> Database Driver Class Initialized
INFO - 2017-03-07 21:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:33:20 --> Controller Class Initialized
INFO - 2017-03-07 21:33:20 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:33:20 --> Helper loaded: url_helper
INFO - 2017-03-07 21:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-07 21:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-07 21:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-07 21:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:33:20 --> Final output sent to browser
DEBUG - 2017-03-07 21:33:20 --> Total execution time: 0.1292
INFO - 2017-03-07 21:33:23 --> Config Class Initialized
INFO - 2017-03-07 21:33:23 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:33:23 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:33:23 --> Utf8 Class Initialized
INFO - 2017-03-07 21:33:23 --> URI Class Initialized
INFO - 2017-03-07 21:33:23 --> Router Class Initialized
INFO - 2017-03-07 21:33:23 --> Output Class Initialized
INFO - 2017-03-07 21:33:23 --> Security Class Initialized
DEBUG - 2017-03-07 21:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:33:23 --> Input Class Initialized
INFO - 2017-03-07 21:33:23 --> Language Class Initialized
INFO - 2017-03-07 21:33:23 --> Loader Class Initialized
INFO - 2017-03-07 21:33:23 --> Database Driver Class Initialized
INFO - 2017-03-07 21:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:33:23 --> Controller Class Initialized
INFO - 2017-03-07 21:33:23 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:33:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:33:23 --> Final output sent to browser
DEBUG - 2017-03-07 21:33:23 --> Total execution time: 0.0384
INFO - 2017-03-07 21:33:26 --> Config Class Initialized
INFO - 2017-03-07 21:33:26 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:33:26 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:33:26 --> Utf8 Class Initialized
INFO - 2017-03-07 21:33:26 --> URI Class Initialized
DEBUG - 2017-03-07 21:33:26 --> No URI present. Default controller set.
INFO - 2017-03-07 21:33:26 --> Router Class Initialized
INFO - 2017-03-07 21:33:26 --> Output Class Initialized
INFO - 2017-03-07 21:33:26 --> Security Class Initialized
DEBUG - 2017-03-07 21:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:33:26 --> Input Class Initialized
INFO - 2017-03-07 21:33:26 --> Language Class Initialized
INFO - 2017-03-07 21:33:26 --> Loader Class Initialized
INFO - 2017-03-07 21:33:26 --> Database Driver Class Initialized
INFO - 2017-03-07 21:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:33:26 --> Controller Class Initialized
INFO - 2017-03-07 21:33:26 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:33:26 --> Final output sent to browser
DEBUG - 2017-03-07 21:33:26 --> Total execution time: 0.0458
INFO - 2017-03-07 21:33:28 --> Config Class Initialized
INFO - 2017-03-07 21:33:28 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:33:28 --> UTF-8 Support Enabled
INFO - 2017-03-07 21:33:28 --> Utf8 Class Initialized
INFO - 2017-03-07 21:33:28 --> URI Class Initialized
INFO - 2017-03-07 21:33:28 --> Router Class Initialized
INFO - 2017-03-07 21:33:28 --> Output Class Initialized
INFO - 2017-03-07 21:33:28 --> Security Class Initialized
DEBUG - 2017-03-07 21:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-07 21:33:28 --> Input Class Initialized
INFO - 2017-03-07 21:33:28 --> Language Class Initialized
INFO - 2017-03-07 21:33:28 --> Loader Class Initialized
INFO - 2017-03-07 21:33:28 --> Database Driver Class Initialized
INFO - 2017-03-07 21:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-07 21:33:28 --> Controller Class Initialized
INFO - 2017-03-07 21:33:28 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-07 21:33:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-07 21:33:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-07 21:33:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-07 21:33:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-07 21:33:28 --> Final output sent to browser
DEBUG - 2017-03-07 21:33:28 --> Total execution time: 0.0134

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-12 01:30:00 --> Config Class Initialized
INFO - 2017-02-12 01:30:00 --> Hooks Class Initialized
DEBUG - 2017-02-12 01:30:00 --> UTF-8 Support Enabled
INFO - 2017-02-12 01:30:00 --> Utf8 Class Initialized
INFO - 2017-02-12 01:30:00 --> URI Class Initialized
DEBUG - 2017-02-12 01:30:00 --> No URI present. Default controller set.
INFO - 2017-02-12 01:30:00 --> Router Class Initialized
INFO - 2017-02-12 01:30:00 --> Output Class Initialized
INFO - 2017-02-12 01:30:00 --> Security Class Initialized
DEBUG - 2017-02-12 01:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 01:30:00 --> Input Class Initialized
INFO - 2017-02-12 01:30:00 --> Language Class Initialized
INFO - 2017-02-12 01:30:00 --> Loader Class Initialized
INFO - 2017-02-12 01:30:00 --> Database Driver Class Initialized
INFO - 2017-02-12 01:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 01:30:00 --> Controller Class Initialized
INFO - 2017-02-12 01:30:00 --> Helper loaded: url_helper
DEBUG - 2017-02-12 01:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 01:30:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 01:30:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 01:30:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 01:30:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 01:30:00 --> Final output sent to browser
DEBUG - 2017-02-12 01:30:00 --> Total execution time: 0.0608
INFO - 2017-02-12 01:30:25 --> Config Class Initialized
INFO - 2017-02-12 01:30:25 --> Hooks Class Initialized
DEBUG - 2017-02-12 01:30:25 --> UTF-8 Support Enabled
INFO - 2017-02-12 01:30:25 --> Utf8 Class Initialized
INFO - 2017-02-12 01:30:25 --> URI Class Initialized
INFO - 2017-02-12 01:30:25 --> Router Class Initialized
INFO - 2017-02-12 01:30:25 --> Output Class Initialized
INFO - 2017-02-12 01:30:25 --> Security Class Initialized
DEBUG - 2017-02-12 01:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 01:30:25 --> Input Class Initialized
INFO - 2017-02-12 01:30:25 --> Language Class Initialized
INFO - 2017-02-12 01:30:25 --> Loader Class Initialized
INFO - 2017-02-12 01:30:25 --> Database Driver Class Initialized
INFO - 2017-02-12 01:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 01:30:25 --> Controller Class Initialized
INFO - 2017-02-12 01:30:25 --> Helper loaded: url_helper
DEBUG - 2017-02-12 01:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 01:30:25 --> Config Class Initialized
INFO - 2017-02-12 01:30:25 --> Hooks Class Initialized
DEBUG - 2017-02-12 01:30:25 --> UTF-8 Support Enabled
INFO - 2017-02-12 01:30:25 --> Utf8 Class Initialized
INFO - 2017-02-12 01:30:25 --> URI Class Initialized
INFO - 2017-02-12 01:30:25 --> Router Class Initialized
INFO - 2017-02-12 01:30:25 --> Output Class Initialized
INFO - 2017-02-12 01:30:25 --> Security Class Initialized
DEBUG - 2017-02-12 01:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 01:30:25 --> Input Class Initialized
INFO - 2017-02-12 01:30:25 --> Language Class Initialized
INFO - 2017-02-12 01:30:25 --> Loader Class Initialized
INFO - 2017-02-12 01:30:25 --> Database Driver Class Initialized
INFO - 2017-02-12 01:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 01:30:25 --> Controller Class Initialized
INFO - 2017-02-12 01:30:25 --> Helper loaded: date_helper
DEBUG - 2017-02-12 01:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 01:30:25 --> Helper loaded: url_helper
INFO - 2017-02-12 01:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 01:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-12 01:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-12 01:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-12 01:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 01:30:25 --> Final output sent to browser
DEBUG - 2017-02-12 01:30:25 --> Total execution time: 0.0987
INFO - 2017-02-12 01:30:41 --> Config Class Initialized
INFO - 2017-02-12 01:30:41 --> Hooks Class Initialized
DEBUG - 2017-02-12 01:30:41 --> UTF-8 Support Enabled
INFO - 2017-02-12 01:30:41 --> Utf8 Class Initialized
INFO - 2017-02-12 01:30:41 --> URI Class Initialized
INFO - 2017-02-12 01:30:41 --> Router Class Initialized
INFO - 2017-02-12 01:30:41 --> Output Class Initialized
INFO - 2017-02-12 01:30:41 --> Security Class Initialized
DEBUG - 2017-02-12 01:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 01:30:41 --> Input Class Initialized
INFO - 2017-02-12 01:30:41 --> Language Class Initialized
INFO - 2017-02-12 01:30:41 --> Loader Class Initialized
INFO - 2017-02-12 01:30:41 --> Database Driver Class Initialized
INFO - 2017-02-12 01:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 01:30:41 --> Controller Class Initialized
INFO - 2017-02-12 01:30:41 --> Helper loaded: date_helper
DEBUG - 2017-02-12 01:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 01:30:41 --> Helper loaded: url_helper
INFO - 2017-02-12 01:30:41 --> Helper loaded: download_helper
INFO - 2017-02-12 01:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 01:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-12 01:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-12 01:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-12 01:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 01:30:41 --> Final output sent to browser
DEBUG - 2017-02-12 01:30:41 --> Total execution time: 0.1293
INFO - 2017-02-12 01:30:58 --> Config Class Initialized
INFO - 2017-02-12 01:30:58 --> Hooks Class Initialized
DEBUG - 2017-02-12 01:30:58 --> UTF-8 Support Enabled
INFO - 2017-02-12 01:30:58 --> Utf8 Class Initialized
INFO - 2017-02-12 01:30:58 --> URI Class Initialized
INFO - 2017-02-12 01:30:58 --> Router Class Initialized
INFO - 2017-02-12 01:30:58 --> Output Class Initialized
INFO - 2017-02-12 01:30:58 --> Security Class Initialized
DEBUG - 2017-02-12 01:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 01:30:58 --> Input Class Initialized
INFO - 2017-02-12 01:30:58 --> Language Class Initialized
INFO - 2017-02-12 01:30:58 --> Loader Class Initialized
INFO - 2017-02-12 01:30:58 --> Database Driver Class Initialized
INFO - 2017-02-12 01:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 01:30:58 --> Controller Class Initialized
INFO - 2017-02-12 01:30:58 --> Helper loaded: date_helper
DEBUG - 2017-02-12 01:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 01:30:58 --> Helper loaded: url_helper
INFO - 2017-02-12 01:30:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 01:30:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-12 01:30:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-12 01:30:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-12 01:30:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-12 01:30:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 01:30:58 --> Final output sent to browser
DEBUG - 2017-02-12 01:30:58 --> Total execution time: 0.0759
INFO - 2017-02-12 01:31:01 --> Config Class Initialized
INFO - 2017-02-12 01:31:01 --> Hooks Class Initialized
DEBUG - 2017-02-12 01:31:01 --> UTF-8 Support Enabled
INFO - 2017-02-12 01:31:01 --> Utf8 Class Initialized
INFO - 2017-02-12 01:31:01 --> URI Class Initialized
INFO - 2017-02-12 01:31:01 --> Router Class Initialized
INFO - 2017-02-12 01:31:01 --> Output Class Initialized
INFO - 2017-02-12 01:31:01 --> Security Class Initialized
DEBUG - 2017-02-12 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 01:31:01 --> Input Class Initialized
INFO - 2017-02-12 01:31:01 --> Language Class Initialized
INFO - 2017-02-12 01:31:01 --> Loader Class Initialized
INFO - 2017-02-12 01:31:01 --> Database Driver Class Initialized
INFO - 2017-02-12 01:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 01:31:01 --> Controller Class Initialized
INFO - 2017-02-12 01:31:01 --> Helper loaded: date_helper
DEBUG - 2017-02-12 01:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 01:31:01 --> Helper loaded: url_helper
INFO - 2017-02-12 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-12 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-12 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-12 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 01:31:01 --> Final output sent to browser
DEBUG - 2017-02-12 01:31:01 --> Total execution time: 0.0145
INFO - 2017-02-12 01:52:39 --> Config Class Initialized
INFO - 2017-02-12 01:52:39 --> Hooks Class Initialized
DEBUG - 2017-02-12 01:52:39 --> UTF-8 Support Enabled
INFO - 2017-02-12 01:52:39 --> Utf8 Class Initialized
INFO - 2017-02-12 01:52:39 --> URI Class Initialized
DEBUG - 2017-02-12 01:52:39 --> No URI present. Default controller set.
INFO - 2017-02-12 01:52:39 --> Router Class Initialized
INFO - 2017-02-12 01:52:39 --> Output Class Initialized
INFO - 2017-02-12 01:52:39 --> Security Class Initialized
DEBUG - 2017-02-12 01:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 01:52:39 --> Input Class Initialized
INFO - 2017-02-12 01:52:39 --> Language Class Initialized
INFO - 2017-02-12 01:52:39 --> Loader Class Initialized
INFO - 2017-02-12 01:52:39 --> Database Driver Class Initialized
INFO - 2017-02-12 01:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 01:52:39 --> Controller Class Initialized
INFO - 2017-02-12 01:52:39 --> Helper loaded: url_helper
DEBUG - 2017-02-12 01:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 01:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 01:52:39 --> Final output sent to browser
DEBUG - 2017-02-12 01:52:39 --> Total execution time: 0.0132
INFO - 2017-02-12 03:59:49 --> Config Class Initialized
INFO - 2017-02-12 03:59:49 --> Hooks Class Initialized
DEBUG - 2017-02-12 03:59:49 --> UTF-8 Support Enabled
INFO - 2017-02-12 03:59:49 --> Utf8 Class Initialized
INFO - 2017-02-12 03:59:49 --> URI Class Initialized
INFO - 2017-02-12 03:59:49 --> Router Class Initialized
INFO - 2017-02-12 03:59:49 --> Output Class Initialized
INFO - 2017-02-12 03:59:49 --> Security Class Initialized
DEBUG - 2017-02-12 03:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 03:59:49 --> Input Class Initialized
INFO - 2017-02-12 03:59:49 --> Language Class Initialized
INFO - 2017-02-12 03:59:49 --> Loader Class Initialized
INFO - 2017-02-12 03:59:49 --> Database Driver Class Initialized
INFO - 2017-02-12 03:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 03:59:49 --> Controller Class Initialized
INFO - 2017-02-12 03:59:49 --> Helper loaded: url_helper
DEBUG - 2017-02-12 03:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 03:59:49 --> Final output sent to browser
DEBUG - 2017-02-12 03:59:49 --> Total execution time: 0.0142
INFO - 2017-02-12 03:59:49 --> Config Class Initialized
INFO - 2017-02-12 03:59:49 --> Hooks Class Initialized
DEBUG - 2017-02-12 03:59:49 --> UTF-8 Support Enabled
INFO - 2017-02-12 03:59:49 --> Utf8 Class Initialized
INFO - 2017-02-12 03:59:49 --> URI Class Initialized
DEBUG - 2017-02-12 03:59:49 --> No URI present. Default controller set.
INFO - 2017-02-12 03:59:49 --> Router Class Initialized
INFO - 2017-02-12 03:59:49 --> Output Class Initialized
INFO - 2017-02-12 03:59:49 --> Security Class Initialized
DEBUG - 2017-02-12 03:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 03:59:49 --> Input Class Initialized
INFO - 2017-02-12 03:59:49 --> Language Class Initialized
INFO - 2017-02-12 03:59:49 --> Loader Class Initialized
INFO - 2017-02-12 03:59:49 --> Database Driver Class Initialized
INFO - 2017-02-12 03:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 03:59:49 --> Controller Class Initialized
INFO - 2017-02-12 03:59:49 --> Helper loaded: url_helper
DEBUG - 2017-02-12 03:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 03:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 03:59:49 --> Final output sent to browser
DEBUG - 2017-02-12 03:59:49 --> Total execution time: 0.0134
INFO - 2017-02-12 04:57:12 --> Config Class Initialized
INFO - 2017-02-12 04:57:12 --> Hooks Class Initialized
DEBUG - 2017-02-12 04:57:12 --> UTF-8 Support Enabled
INFO - 2017-02-12 04:57:12 --> Utf8 Class Initialized
INFO - 2017-02-12 04:57:12 --> URI Class Initialized
DEBUG - 2017-02-12 04:57:12 --> No URI present. Default controller set.
INFO - 2017-02-12 04:57:12 --> Router Class Initialized
INFO - 2017-02-12 04:57:12 --> Output Class Initialized
INFO - 2017-02-12 04:57:12 --> Security Class Initialized
DEBUG - 2017-02-12 04:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 04:57:12 --> Input Class Initialized
INFO - 2017-02-12 04:57:12 --> Language Class Initialized
INFO - 2017-02-12 04:57:12 --> Loader Class Initialized
INFO - 2017-02-12 04:57:12 --> Database Driver Class Initialized
INFO - 2017-02-12 04:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 04:57:12 --> Controller Class Initialized
INFO - 2017-02-12 04:57:12 --> Helper loaded: url_helper
DEBUG - 2017-02-12 04:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 04:57:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 04:57:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 04:57:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 04:57:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 04:57:12 --> Final output sent to browser
DEBUG - 2017-02-12 04:57:12 --> Total execution time: 0.0134
INFO - 2017-02-12 05:09:32 --> Config Class Initialized
INFO - 2017-02-12 05:09:32 --> Hooks Class Initialized
DEBUG - 2017-02-12 05:09:32 --> UTF-8 Support Enabled
INFO - 2017-02-12 05:09:32 --> Utf8 Class Initialized
INFO - 2017-02-12 05:09:32 --> URI Class Initialized
INFO - 2017-02-12 05:09:32 --> Router Class Initialized
INFO - 2017-02-12 05:09:32 --> Output Class Initialized
INFO - 2017-02-12 05:09:32 --> Security Class Initialized
DEBUG - 2017-02-12 05:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 05:09:32 --> Input Class Initialized
INFO - 2017-02-12 05:09:32 --> Language Class Initialized
INFO - 2017-02-12 05:09:32 --> Loader Class Initialized
INFO - 2017-02-12 05:09:32 --> Database Driver Class Initialized
INFO - 2017-02-12 05:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 05:09:32 --> Controller Class Initialized
INFO - 2017-02-12 05:09:32 --> Helper loaded: url_helper
DEBUG - 2017-02-12 05:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 05:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 05:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 05:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 05:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 05:09:32 --> Final output sent to browser
DEBUG - 2017-02-12 05:09:32 --> Total execution time: 0.0631
INFO - 2017-02-12 05:55:47 --> Config Class Initialized
INFO - 2017-02-12 05:55:47 --> Hooks Class Initialized
DEBUG - 2017-02-12 05:55:47 --> UTF-8 Support Enabled
INFO - 2017-02-12 05:55:47 --> Utf8 Class Initialized
INFO - 2017-02-12 05:55:47 --> URI Class Initialized
DEBUG - 2017-02-12 05:55:47 --> No URI present. Default controller set.
INFO - 2017-02-12 05:55:47 --> Router Class Initialized
INFO - 2017-02-12 05:55:47 --> Output Class Initialized
INFO - 2017-02-12 05:55:47 --> Security Class Initialized
DEBUG - 2017-02-12 05:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 05:55:47 --> Input Class Initialized
INFO - 2017-02-12 05:55:47 --> Language Class Initialized
INFO - 2017-02-12 05:55:47 --> Loader Class Initialized
INFO - 2017-02-12 05:55:47 --> Database Driver Class Initialized
INFO - 2017-02-12 05:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 05:55:47 --> Controller Class Initialized
INFO - 2017-02-12 05:55:47 --> Helper loaded: url_helper
DEBUG - 2017-02-12 05:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 05:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 05:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 05:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 05:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 05:55:47 --> Final output sent to browser
DEBUG - 2017-02-12 05:55:47 --> Total execution time: 0.0133
INFO - 2017-02-12 15:25:39 --> Config Class Initialized
INFO - 2017-02-12 15:25:39 --> Hooks Class Initialized
DEBUG - 2017-02-12 15:25:39 --> UTF-8 Support Enabled
INFO - 2017-02-12 15:25:39 --> Utf8 Class Initialized
INFO - 2017-02-12 15:25:39 --> URI Class Initialized
DEBUG - 2017-02-12 15:25:39 --> No URI present. Default controller set.
INFO - 2017-02-12 15:25:39 --> Router Class Initialized
INFO - 2017-02-12 15:25:39 --> Output Class Initialized
INFO - 2017-02-12 15:25:39 --> Security Class Initialized
DEBUG - 2017-02-12 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 15:25:39 --> Input Class Initialized
INFO - 2017-02-12 15:25:39 --> Language Class Initialized
INFO - 2017-02-12 15:25:39 --> Loader Class Initialized
INFO - 2017-02-12 15:25:39 --> Database Driver Class Initialized
INFO - 2017-02-12 15:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 15:25:39 --> Controller Class Initialized
INFO - 2017-02-12 15:25:39 --> Helper loaded: url_helper
DEBUG - 2017-02-12 15:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 15:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 15:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 15:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 15:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 15:25:39 --> Final output sent to browser
DEBUG - 2017-02-12 15:25:39 --> Total execution time: 0.0136
INFO - 2017-02-12 16:10:22 --> Config Class Initialized
INFO - 2017-02-12 16:10:22 --> Hooks Class Initialized
DEBUG - 2017-02-12 16:10:22 --> UTF-8 Support Enabled
INFO - 2017-02-12 16:10:22 --> Utf8 Class Initialized
INFO - 2017-02-12 16:10:22 --> URI Class Initialized
DEBUG - 2017-02-12 16:10:22 --> No URI present. Default controller set.
INFO - 2017-02-12 16:10:22 --> Router Class Initialized
INFO - 2017-02-12 16:10:22 --> Output Class Initialized
INFO - 2017-02-12 16:10:22 --> Security Class Initialized
DEBUG - 2017-02-12 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 16:10:22 --> Input Class Initialized
INFO - 2017-02-12 16:10:22 --> Language Class Initialized
INFO - 2017-02-12 16:10:22 --> Loader Class Initialized
INFO - 2017-02-12 16:10:22 --> Database Driver Class Initialized
INFO - 2017-02-12 16:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 16:10:22 --> Controller Class Initialized
INFO - 2017-02-12 16:10:22 --> Helper loaded: url_helper
DEBUG - 2017-02-12 16:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 16:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 16:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 16:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 16:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 16:10:22 --> Final output sent to browser
DEBUG - 2017-02-12 16:10:22 --> Total execution time: 0.0133
INFO - 2017-02-12 17:34:15 --> Config Class Initialized
INFO - 2017-02-12 17:34:15 --> Hooks Class Initialized
DEBUG - 2017-02-12 17:34:15 --> UTF-8 Support Enabled
INFO - 2017-02-12 17:34:15 --> Utf8 Class Initialized
INFO - 2017-02-12 17:34:15 --> URI Class Initialized
INFO - 2017-02-12 17:34:15 --> Router Class Initialized
INFO - 2017-02-12 17:34:15 --> Output Class Initialized
INFO - 2017-02-12 17:34:15 --> Security Class Initialized
DEBUG - 2017-02-12 17:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 17:34:15 --> Input Class Initialized
INFO - 2017-02-12 17:34:15 --> Language Class Initialized
INFO - 2017-02-12 17:34:15 --> Loader Class Initialized
INFO - 2017-02-12 17:34:15 --> Database Driver Class Initialized
INFO - 2017-02-12 17:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 17:34:15 --> Controller Class Initialized
INFO - 2017-02-12 17:34:15 --> Helper loaded: date_helper
DEBUG - 2017-02-12 17:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 17:34:15 --> Helper loaded: url_helper
INFO - 2017-02-12 17:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 17:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-12 17:34:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-12 17:34:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-12 17:34:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 17:34:16 --> Final output sent to browser
DEBUG - 2017-02-12 17:34:16 --> Total execution time: 0.4368
INFO - 2017-02-12 21:07:48 --> Config Class Initialized
INFO - 2017-02-12 21:07:48 --> Hooks Class Initialized
DEBUG - 2017-02-12 21:07:48 --> UTF-8 Support Enabled
INFO - 2017-02-12 21:07:48 --> Utf8 Class Initialized
INFO - 2017-02-12 21:07:48 --> URI Class Initialized
INFO - 2017-02-12 21:07:48 --> Router Class Initialized
INFO - 2017-02-12 21:07:48 --> Output Class Initialized
INFO - 2017-02-12 21:07:48 --> Security Class Initialized
DEBUG - 2017-02-12 21:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 21:07:48 --> Input Class Initialized
INFO - 2017-02-12 21:07:48 --> Language Class Initialized
INFO - 2017-02-12 21:07:48 --> Loader Class Initialized
INFO - 2017-02-12 21:07:48 --> Database Driver Class Initialized
INFO - 2017-02-12 21:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 21:07:48 --> Controller Class Initialized
INFO - 2017-02-12 21:07:48 --> Helper loaded: url_helper
DEBUG - 2017-02-12 21:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 21:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 21:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 21:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 21:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 21:07:48 --> Final output sent to browser
DEBUG - 2017-02-12 21:07:48 --> Total execution time: 0.0136
INFO - 2017-02-12 21:07:52 --> Config Class Initialized
INFO - 2017-02-12 21:07:52 --> Hooks Class Initialized
DEBUG - 2017-02-12 21:07:52 --> UTF-8 Support Enabled
INFO - 2017-02-12 21:07:52 --> Utf8 Class Initialized
INFO - 2017-02-12 21:07:52 --> URI Class Initialized
INFO - 2017-02-12 21:07:52 --> Router Class Initialized
INFO - 2017-02-12 21:07:52 --> Output Class Initialized
INFO - 2017-02-12 21:07:52 --> Security Class Initialized
DEBUG - 2017-02-12 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 21:07:52 --> Input Class Initialized
INFO - 2017-02-12 21:07:52 --> Language Class Initialized
INFO - 2017-02-12 21:07:52 --> Loader Class Initialized
INFO - 2017-02-12 21:07:52 --> Database Driver Class Initialized
INFO - 2017-02-12 21:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 21:07:52 --> Controller Class Initialized
INFO - 2017-02-12 21:07:52 --> Helper loaded: url_helper
DEBUG - 2017-02-12 21:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 21:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 21:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 21:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 21:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 21:07:52 --> Final output sent to browser
DEBUG - 2017-02-12 21:07:52 --> Total execution time: 0.0137
INFO - 2017-02-12 22:22:04 --> Config Class Initialized
INFO - 2017-02-12 22:22:04 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:22:04 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:22:04 --> Utf8 Class Initialized
INFO - 2017-02-12 22:22:04 --> URI Class Initialized
DEBUG - 2017-02-12 22:22:04 --> No URI present. Default controller set.
INFO - 2017-02-12 22:22:04 --> Router Class Initialized
INFO - 2017-02-12 22:22:04 --> Output Class Initialized
INFO - 2017-02-12 22:22:04 --> Security Class Initialized
DEBUG - 2017-02-12 22:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:22:04 --> Input Class Initialized
INFO - 2017-02-12 22:22:04 --> Language Class Initialized
INFO - 2017-02-12 22:22:04 --> Loader Class Initialized
INFO - 2017-02-12 22:22:04 --> Database Driver Class Initialized
INFO - 2017-02-12 22:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:22:04 --> Controller Class Initialized
INFO - 2017-02-12 22:22:04 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:22:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:22:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:22:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:22:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:22:04 --> Final output sent to browser
DEBUG - 2017-02-12 22:22:04 --> Total execution time: 0.0659
INFO - 2017-02-12 22:22:45 --> Config Class Initialized
INFO - 2017-02-12 22:22:45 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:22:45 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:22:45 --> Utf8 Class Initialized
INFO - 2017-02-12 22:22:45 --> URI Class Initialized
INFO - 2017-02-12 22:22:45 --> Router Class Initialized
INFO - 2017-02-12 22:22:45 --> Output Class Initialized
INFO - 2017-02-12 22:22:45 --> Security Class Initialized
DEBUG - 2017-02-12 22:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:22:45 --> Input Class Initialized
INFO - 2017-02-12 22:22:45 --> Language Class Initialized
INFO - 2017-02-12 22:22:45 --> Loader Class Initialized
INFO - 2017-02-12 22:22:45 --> Database Driver Class Initialized
INFO - 2017-02-12 22:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:22:45 --> Controller Class Initialized
INFO - 2017-02-12 22:22:45 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:22:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-12 22:22:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-12 22:22:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-12 22:22:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-12 22:22:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:22:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:22:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:22:45 --> Final output sent to browser
DEBUG - 2017-02-12 22:22:45 --> Total execution time: 0.0598
INFO - 2017-02-12 22:23:09 --> Config Class Initialized
INFO - 2017-02-12 22:23:09 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:23:09 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:23:09 --> Utf8 Class Initialized
INFO - 2017-02-12 22:23:09 --> URI Class Initialized
INFO - 2017-02-12 22:23:09 --> Router Class Initialized
INFO - 2017-02-12 22:23:09 --> Output Class Initialized
INFO - 2017-02-12 22:23:09 --> Security Class Initialized
DEBUG - 2017-02-12 22:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:23:09 --> Input Class Initialized
INFO - 2017-02-12 22:23:09 --> Language Class Initialized
INFO - 2017-02-12 22:23:09 --> Loader Class Initialized
INFO - 2017-02-12 22:23:09 --> Database Driver Class Initialized
INFO - 2017-02-12 22:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:23:09 --> Controller Class Initialized
INFO - 2017-02-12 22:23:09 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:23:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:23:09 --> Final output sent to browser
DEBUG - 2017-02-12 22:23:09 --> Total execution time: 0.0135
INFO - 2017-02-12 22:23:14 --> Config Class Initialized
INFO - 2017-02-12 22:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:23:14 --> Utf8 Class Initialized
INFO - 2017-02-12 22:23:14 --> URI Class Initialized
INFO - 2017-02-12 22:23:14 --> Router Class Initialized
INFO - 2017-02-12 22:23:14 --> Output Class Initialized
INFO - 2017-02-12 22:23:14 --> Security Class Initialized
DEBUG - 2017-02-12 22:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:23:14 --> Input Class Initialized
INFO - 2017-02-12 22:23:14 --> Language Class Initialized
INFO - 2017-02-12 22:23:14 --> Loader Class Initialized
INFO - 2017-02-12 22:23:14 --> Database Driver Class Initialized
INFO - 2017-02-12 22:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:23:14 --> Controller Class Initialized
INFO - 2017-02-12 22:23:14 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:23:14 --> Final output sent to browser
DEBUG - 2017-02-12 22:23:14 --> Total execution time: 0.0137
INFO - 2017-02-12 22:23:38 --> Config Class Initialized
INFO - 2017-02-12 22:23:38 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:23:38 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:23:38 --> Utf8 Class Initialized
INFO - 2017-02-12 22:23:38 --> URI Class Initialized
INFO - 2017-02-12 22:23:38 --> Router Class Initialized
INFO - 2017-02-12 22:23:38 --> Output Class Initialized
INFO - 2017-02-12 22:23:38 --> Security Class Initialized
DEBUG - 2017-02-12 22:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:23:38 --> Input Class Initialized
INFO - 2017-02-12 22:23:38 --> Language Class Initialized
INFO - 2017-02-12 22:23:38 --> Loader Class Initialized
INFO - 2017-02-12 22:23:38 --> Database Driver Class Initialized
INFO - 2017-02-12 22:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:23:38 --> Controller Class Initialized
INFO - 2017-02-12 22:23:38 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:23:38 --> Final output sent to browser
DEBUG - 2017-02-12 22:23:38 --> Total execution time: 0.0257
INFO - 2017-02-12 22:23:54 --> Config Class Initialized
INFO - 2017-02-12 22:23:54 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:23:54 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:23:54 --> Utf8 Class Initialized
INFO - 2017-02-12 22:23:54 --> URI Class Initialized
INFO - 2017-02-12 22:23:54 --> Router Class Initialized
INFO - 2017-02-12 22:23:54 --> Output Class Initialized
INFO - 2017-02-12 22:23:54 --> Security Class Initialized
DEBUG - 2017-02-12 22:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:23:54 --> Input Class Initialized
INFO - 2017-02-12 22:23:54 --> Language Class Initialized
INFO - 2017-02-12 22:23:54 --> Loader Class Initialized
INFO - 2017-02-12 22:23:54 --> Database Driver Class Initialized
INFO - 2017-02-12 22:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:23:54 --> Controller Class Initialized
INFO - 2017-02-12 22:23:54 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:23:54 --> Final output sent to browser
DEBUG - 2017-02-12 22:23:54 --> Total execution time: 0.0142
INFO - 2017-02-12 22:37:21 --> Config Class Initialized
INFO - 2017-02-12 22:37:21 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:37:21 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:37:21 --> Utf8 Class Initialized
INFO - 2017-02-12 22:37:21 --> URI Class Initialized
DEBUG - 2017-02-12 22:37:21 --> No URI present. Default controller set.
INFO - 2017-02-12 22:37:21 --> Router Class Initialized
INFO - 2017-02-12 22:37:21 --> Output Class Initialized
INFO - 2017-02-12 22:37:21 --> Security Class Initialized
DEBUG - 2017-02-12 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:37:21 --> Input Class Initialized
INFO - 2017-02-12 22:37:21 --> Language Class Initialized
INFO - 2017-02-12 22:37:21 --> Loader Class Initialized
INFO - 2017-02-12 22:37:21 --> Database Driver Class Initialized
INFO - 2017-02-12 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:37:21 --> Controller Class Initialized
INFO - 2017-02-12 22:37:21 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:37:21 --> Final output sent to browser
DEBUG - 2017-02-12 22:37:21 --> Total execution time: 0.0133
INFO - 2017-02-12 22:38:29 --> Config Class Initialized
INFO - 2017-02-12 22:38:29 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:38:29 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:38:29 --> Utf8 Class Initialized
INFO - 2017-02-12 22:38:29 --> URI Class Initialized
INFO - 2017-02-12 22:38:29 --> Router Class Initialized
INFO - 2017-02-12 22:38:29 --> Output Class Initialized
INFO - 2017-02-12 22:38:29 --> Security Class Initialized
DEBUG - 2017-02-12 22:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:38:29 --> Input Class Initialized
INFO - 2017-02-12 22:38:29 --> Language Class Initialized
INFO - 2017-02-12 22:38:29 --> Loader Class Initialized
INFO - 2017-02-12 22:38:29 --> Database Driver Class Initialized
INFO - 2017-02-12 22:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:38:29 --> Controller Class Initialized
INFO - 2017-02-12 22:38:29 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:38:29 --> Final output sent to browser
DEBUG - 2017-02-12 22:38:29 --> Total execution time: 0.0148
INFO - 2017-02-12 22:39:10 --> Config Class Initialized
INFO - 2017-02-12 22:39:10 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:39:10 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:39:10 --> Utf8 Class Initialized
INFO - 2017-02-12 22:39:10 --> URI Class Initialized
INFO - 2017-02-12 22:39:10 --> Router Class Initialized
INFO - 2017-02-12 22:39:10 --> Output Class Initialized
INFO - 2017-02-12 22:39:10 --> Security Class Initialized
DEBUG - 2017-02-12 22:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:39:10 --> Input Class Initialized
INFO - 2017-02-12 22:39:10 --> Language Class Initialized
INFO - 2017-02-12 22:39:10 --> Loader Class Initialized
INFO - 2017-02-12 22:39:10 --> Database Driver Class Initialized
INFO - 2017-02-12 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:39:10 --> Controller Class Initialized
INFO - 2017-02-12 22:39:10 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 22:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 22:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:39:10 --> Final output sent to browser
DEBUG - 2017-02-12 22:39:10 --> Total execution time: 0.0139
INFO - 2017-02-12 22:39:41 --> Config Class Initialized
INFO - 2017-02-12 22:39:41 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:39:41 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:39:41 --> Utf8 Class Initialized
INFO - 2017-02-12 22:39:41 --> URI Class Initialized
INFO - 2017-02-12 22:39:41 --> Router Class Initialized
INFO - 2017-02-12 22:39:41 --> Output Class Initialized
INFO - 2017-02-12 22:39:41 --> Security Class Initialized
DEBUG - 2017-02-12 22:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:39:41 --> Input Class Initialized
INFO - 2017-02-12 22:39:41 --> Language Class Initialized
INFO - 2017-02-12 22:39:41 --> Loader Class Initialized
INFO - 2017-02-12 22:39:41 --> Database Driver Class Initialized
INFO - 2017-02-12 22:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:39:41 --> Controller Class Initialized
INFO - 2017-02-12 22:39:41 --> Helper loaded: url_helper
DEBUG - 2017-02-12 22:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:39:42 --> Config Class Initialized
INFO - 2017-02-12 22:39:42 --> Hooks Class Initialized
DEBUG - 2017-02-12 22:39:42 --> UTF-8 Support Enabled
INFO - 2017-02-12 22:39:42 --> Utf8 Class Initialized
INFO - 2017-02-12 22:39:42 --> URI Class Initialized
INFO - 2017-02-12 22:39:42 --> Router Class Initialized
INFO - 2017-02-12 22:39:42 --> Output Class Initialized
INFO - 2017-02-12 22:39:42 --> Security Class Initialized
DEBUG - 2017-02-12 22:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 22:39:42 --> Input Class Initialized
INFO - 2017-02-12 22:39:42 --> Language Class Initialized
INFO - 2017-02-12 22:39:42 --> Loader Class Initialized
INFO - 2017-02-12 22:39:42 --> Database Driver Class Initialized
INFO - 2017-02-12 22:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 22:39:42 --> Controller Class Initialized
INFO - 2017-02-12 22:39:42 --> Helper loaded: date_helper
DEBUG - 2017-02-12 22:39:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 22:39:42 --> Helper loaded: url_helper
INFO - 2017-02-12 22:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 22:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-12 22:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-12 22:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-12 22:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 22:39:42 --> Final output sent to browser
DEBUG - 2017-02-12 22:39:42 --> Total execution time: 0.0279
INFO - 2017-02-12 23:36:56 --> Config Class Initialized
INFO - 2017-02-12 23:36:56 --> Hooks Class Initialized
DEBUG - 2017-02-12 23:36:56 --> UTF-8 Support Enabled
INFO - 2017-02-12 23:36:56 --> Utf8 Class Initialized
INFO - 2017-02-12 23:36:56 --> URI Class Initialized
INFO - 2017-02-12 23:36:56 --> Router Class Initialized
INFO - 2017-02-12 23:36:56 --> Output Class Initialized
INFO - 2017-02-12 23:36:56 --> Security Class Initialized
DEBUG - 2017-02-12 23:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-12 23:36:56 --> Input Class Initialized
INFO - 2017-02-12 23:36:56 --> Language Class Initialized
INFO - 2017-02-12 23:36:56 --> Loader Class Initialized
INFO - 2017-02-12 23:36:56 --> Database Driver Class Initialized
INFO - 2017-02-12 23:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-12 23:36:56 --> Controller Class Initialized
INFO - 2017-02-12 23:36:56 --> Helper loaded: url_helper
DEBUG - 2017-02-12 23:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-12 23:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-12 23:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-12 23:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-12 23:36:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-12 23:36:56 --> Final output sent to browser
DEBUG - 2017-02-12 23:36:56 --> Total execution time: 0.0133

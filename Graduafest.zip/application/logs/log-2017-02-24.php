<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-24 00:05:54 --> Config Class Initialized
INFO - 2017-02-24 00:05:54 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:05:54 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:05:54 --> Utf8 Class Initialized
INFO - 2017-02-24 00:05:54 --> URI Class Initialized
DEBUG - 2017-02-24 00:05:54 --> No URI present. Default controller set.
INFO - 2017-02-24 00:05:54 --> Router Class Initialized
INFO - 2017-02-24 00:05:54 --> Output Class Initialized
INFO - 2017-02-24 00:05:54 --> Security Class Initialized
DEBUG - 2017-02-24 00:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:05:54 --> Input Class Initialized
INFO - 2017-02-24 00:05:54 --> Language Class Initialized
INFO - 2017-02-24 00:05:54 --> Loader Class Initialized
INFO - 2017-02-24 00:05:55 --> Database Driver Class Initialized
INFO - 2017-02-24 00:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:05:55 --> Controller Class Initialized
INFO - 2017-02-24 00:05:55 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 00:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 00:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:05:55 --> Final output sent to browser
DEBUG - 2017-02-24 00:05:55 --> Total execution time: 1.9712
INFO - 2017-02-24 00:06:04 --> Config Class Initialized
INFO - 2017-02-24 00:06:04 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:06:05 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:06:05 --> Utf8 Class Initialized
INFO - 2017-02-24 00:06:05 --> URI Class Initialized
INFO - 2017-02-24 00:06:05 --> Router Class Initialized
INFO - 2017-02-24 00:06:05 --> Output Class Initialized
INFO - 2017-02-24 00:06:05 --> Security Class Initialized
DEBUG - 2017-02-24 00:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:06:05 --> Input Class Initialized
INFO - 2017-02-24 00:06:05 --> Language Class Initialized
INFO - 2017-02-24 00:06:05 --> Loader Class Initialized
INFO - 2017-02-24 00:06:05 --> Database Driver Class Initialized
INFO - 2017-02-24 00:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:06:05 --> Controller Class Initialized
INFO - 2017-02-24 00:06:05 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 00:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 00:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:06:06 --> Final output sent to browser
DEBUG - 2017-02-24 00:06:06 --> Total execution time: 1.2116
INFO - 2017-02-24 00:08:23 --> Config Class Initialized
INFO - 2017-02-24 00:08:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:08:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:08:23 --> Utf8 Class Initialized
INFO - 2017-02-24 00:08:23 --> URI Class Initialized
INFO - 2017-02-24 00:08:23 --> Router Class Initialized
INFO - 2017-02-24 00:08:23 --> Output Class Initialized
INFO - 2017-02-24 00:08:23 --> Security Class Initialized
DEBUG - 2017-02-24 00:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:08:23 --> Input Class Initialized
INFO - 2017-02-24 00:08:23 --> Language Class Initialized
INFO - 2017-02-24 00:08:23 --> Loader Class Initialized
INFO - 2017-02-24 00:08:24 --> Database Driver Class Initialized
INFO - 2017-02-24 00:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:08:24 --> Controller Class Initialized
INFO - 2017-02-24 00:08:24 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:08:24 --> Final output sent to browser
DEBUG - 2017-02-24 00:08:24 --> Total execution time: 0.9809
INFO - 2017-02-24 00:19:28 --> Config Class Initialized
INFO - 2017-02-24 00:19:28 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:19:28 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:19:28 --> Utf8 Class Initialized
INFO - 2017-02-24 00:19:28 --> URI Class Initialized
DEBUG - 2017-02-24 00:19:28 --> No URI present. Default controller set.
INFO - 2017-02-24 00:19:29 --> Router Class Initialized
INFO - 2017-02-24 00:19:29 --> Output Class Initialized
INFO - 2017-02-24 00:19:29 --> Security Class Initialized
DEBUG - 2017-02-24 00:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:19:29 --> Input Class Initialized
INFO - 2017-02-24 00:19:29 --> Language Class Initialized
INFO - 2017-02-24 00:19:29 --> Loader Class Initialized
INFO - 2017-02-24 00:19:29 --> Database Driver Class Initialized
INFO - 2017-02-24 00:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:19:29 --> Controller Class Initialized
INFO - 2017-02-24 00:19:29 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:19:30 --> Final output sent to browser
DEBUG - 2017-02-24 00:19:30 --> Total execution time: 1.5839
INFO - 2017-02-24 00:20:22 --> Config Class Initialized
INFO - 2017-02-24 00:20:22 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:20:22 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:20:22 --> Utf8 Class Initialized
INFO - 2017-02-24 00:20:22 --> URI Class Initialized
INFO - 2017-02-24 00:20:22 --> Router Class Initialized
INFO - 2017-02-24 00:20:22 --> Output Class Initialized
INFO - 2017-02-24 00:20:22 --> Security Class Initialized
DEBUG - 2017-02-24 00:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:20:22 --> Input Class Initialized
INFO - 2017-02-24 00:20:22 --> Language Class Initialized
INFO - 2017-02-24 00:20:22 --> Loader Class Initialized
INFO - 2017-02-24 00:20:22 --> Database Driver Class Initialized
INFO - 2017-02-24 00:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:20:22 --> Controller Class Initialized
INFO - 2017-02-24 00:20:22 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 00:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 00:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:20:22 --> Final output sent to browser
DEBUG - 2017-02-24 00:20:22 --> Total execution time: 0.3504
INFO - 2017-02-24 00:22:03 --> Config Class Initialized
INFO - 2017-02-24 00:22:03 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:22:04 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:22:04 --> Utf8 Class Initialized
INFO - 2017-02-24 00:22:04 --> URI Class Initialized
INFO - 2017-02-24 00:22:04 --> Router Class Initialized
INFO - 2017-02-24 00:22:04 --> Output Class Initialized
INFO - 2017-02-24 00:22:04 --> Security Class Initialized
DEBUG - 2017-02-24 00:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:22:04 --> Input Class Initialized
INFO - 2017-02-24 00:22:04 --> Language Class Initialized
INFO - 2017-02-24 00:22:04 --> Loader Class Initialized
INFO - 2017-02-24 00:22:04 --> Database Driver Class Initialized
INFO - 2017-02-24 00:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:22:04 --> Controller Class Initialized
INFO - 2017-02-24 00:22:04 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:22:06 --> Config Class Initialized
INFO - 2017-02-24 00:22:06 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:22:06 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:22:06 --> Utf8 Class Initialized
INFO - 2017-02-24 00:22:06 --> URI Class Initialized
INFO - 2017-02-24 00:22:06 --> Router Class Initialized
INFO - 2017-02-24 00:22:06 --> Output Class Initialized
INFO - 2017-02-24 00:22:06 --> Security Class Initialized
DEBUG - 2017-02-24 00:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:22:06 --> Input Class Initialized
INFO - 2017-02-24 00:22:06 --> Language Class Initialized
INFO - 2017-02-24 00:22:06 --> Loader Class Initialized
INFO - 2017-02-24 00:22:06 --> Database Driver Class Initialized
INFO - 2017-02-24 00:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:22:06 --> Controller Class Initialized
INFO - 2017-02-24 00:22:06 --> Config Class Initialized
INFO - 2017-02-24 00:22:06 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:22:06 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:22:06 --> Utf8 Class Initialized
INFO - 2017-02-24 00:22:06 --> URI Class Initialized
INFO - 2017-02-24 00:22:06 --> Router Class Initialized
INFO - 2017-02-24 00:22:06 --> Output Class Initialized
INFO - 2017-02-24 00:22:06 --> Security Class Initialized
DEBUG - 2017-02-24 00:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:22:06 --> Input Class Initialized
INFO - 2017-02-24 00:22:06 --> Language Class Initialized
INFO - 2017-02-24 00:22:06 --> Helper loaded: date_helper
DEBUG - 2017-02-24 00:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:22:06 --> Helper loaded: url_helper
INFO - 2017-02-24 00:22:06 --> Loader Class Initialized
INFO - 2017-02-24 00:22:06 --> Database Driver Class Initialized
INFO - 2017-02-24 00:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-24 00:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-24 00:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-24 00:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:22:06 --> Final output sent to browser
DEBUG - 2017-02-24 00:22:06 --> Total execution time: 0.7087
INFO - 2017-02-24 00:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:22:06 --> Controller Class Initialized
INFO - 2017-02-24 00:22:06 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:22:07 --> Config Class Initialized
INFO - 2017-02-24 00:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:22:07 --> Utf8 Class Initialized
INFO - 2017-02-24 00:22:07 --> URI Class Initialized
INFO - 2017-02-24 00:22:07 --> Router Class Initialized
INFO - 2017-02-24 00:22:07 --> Output Class Initialized
INFO - 2017-02-24 00:22:07 --> Security Class Initialized
DEBUG - 2017-02-24 00:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:22:07 --> Input Class Initialized
INFO - 2017-02-24 00:22:07 --> Language Class Initialized
INFO - 2017-02-24 00:22:07 --> Loader Class Initialized
INFO - 2017-02-24 00:22:07 --> Database Driver Class Initialized
INFO - 2017-02-24 00:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:22:08 --> Controller Class Initialized
INFO - 2017-02-24 00:22:08 --> Helper loaded: date_helper
DEBUG - 2017-02-24 00:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:22:08 --> Helper loaded: url_helper
INFO - 2017-02-24 00:22:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:22:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-24 00:22:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-24 00:22:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-24 00:22:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:22:08 --> Final output sent to browser
DEBUG - 2017-02-24 00:22:08 --> Total execution time: 1.0846
INFO - 2017-02-24 00:22:14 --> Config Class Initialized
INFO - 2017-02-24 00:22:14 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:22:14 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:22:14 --> Utf8 Class Initialized
INFO - 2017-02-24 00:22:14 --> URI Class Initialized
INFO - 2017-02-24 00:22:14 --> Router Class Initialized
INFO - 2017-02-24 00:22:14 --> Output Class Initialized
INFO - 2017-02-24 00:22:14 --> Security Class Initialized
DEBUG - 2017-02-24 00:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:22:14 --> Input Class Initialized
INFO - 2017-02-24 00:22:14 --> Language Class Initialized
INFO - 2017-02-24 00:22:14 --> Loader Class Initialized
INFO - 2017-02-24 00:22:15 --> Database Driver Class Initialized
INFO - 2017-02-24 00:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:22:15 --> Controller Class Initialized
INFO - 2017-02-24 00:22:15 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 00:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 00:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:22:15 --> Final output sent to browser
DEBUG - 2017-02-24 00:22:15 --> Total execution time: 1.1065
INFO - 2017-02-24 00:43:51 --> Config Class Initialized
INFO - 2017-02-24 00:43:51 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:43:52 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:43:52 --> Utf8 Class Initialized
INFO - 2017-02-24 00:43:52 --> URI Class Initialized
INFO - 2017-02-24 00:43:52 --> Router Class Initialized
INFO - 2017-02-24 00:43:52 --> Output Class Initialized
INFO - 2017-02-24 00:43:52 --> Security Class Initialized
DEBUG - 2017-02-24 00:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:43:52 --> Input Class Initialized
INFO - 2017-02-24 00:43:52 --> Language Class Initialized
INFO - 2017-02-24 00:43:52 --> Loader Class Initialized
INFO - 2017-02-24 00:43:52 --> Database Driver Class Initialized
INFO - 2017-02-24 00:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:43:53 --> Controller Class Initialized
INFO - 2017-02-24 00:43:53 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 00:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 00:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:43:53 --> Final output sent to browser
DEBUG - 2017-02-24 00:43:53 --> Total execution time: 1.5794
INFO - 2017-02-24 00:44:14 --> Config Class Initialized
INFO - 2017-02-24 00:44:14 --> Hooks Class Initialized
DEBUG - 2017-02-24 00:44:14 --> UTF-8 Support Enabled
INFO - 2017-02-24 00:44:14 --> Utf8 Class Initialized
INFO - 2017-02-24 00:44:14 --> URI Class Initialized
DEBUG - 2017-02-24 00:44:14 --> No URI present. Default controller set.
INFO - 2017-02-24 00:44:14 --> Router Class Initialized
INFO - 2017-02-24 00:44:14 --> Output Class Initialized
INFO - 2017-02-24 00:44:14 --> Security Class Initialized
DEBUG - 2017-02-24 00:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 00:44:14 --> Input Class Initialized
INFO - 2017-02-24 00:44:14 --> Language Class Initialized
INFO - 2017-02-24 00:44:14 --> Loader Class Initialized
INFO - 2017-02-24 00:44:14 --> Database Driver Class Initialized
INFO - 2017-02-24 00:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 00:44:14 --> Controller Class Initialized
INFO - 2017-02-24 00:44:14 --> Helper loaded: url_helper
DEBUG - 2017-02-24 00:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 00:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 00:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 00:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 00:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 00:44:14 --> Final output sent to browser
DEBUG - 2017-02-24 00:44:14 --> Total execution time: 0.0134
INFO - 2017-02-24 01:07:16 --> Config Class Initialized
INFO - 2017-02-24 01:07:16 --> Hooks Class Initialized
DEBUG - 2017-02-24 01:07:16 --> UTF-8 Support Enabled
INFO - 2017-02-24 01:07:16 --> Utf8 Class Initialized
INFO - 2017-02-24 01:07:16 --> URI Class Initialized
INFO - 2017-02-24 01:07:16 --> Router Class Initialized
INFO - 2017-02-24 01:07:16 --> Output Class Initialized
INFO - 2017-02-24 01:07:16 --> Security Class Initialized
DEBUG - 2017-02-24 01:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 01:07:16 --> Input Class Initialized
INFO - 2017-02-24 01:07:16 --> Language Class Initialized
INFO - 2017-02-24 01:07:16 --> Loader Class Initialized
INFO - 2017-02-24 01:07:16 --> Database Driver Class Initialized
INFO - 2017-02-24 01:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 01:07:17 --> Controller Class Initialized
INFO - 2017-02-24 01:07:17 --> Helper loaded: date_helper
DEBUG - 2017-02-24 01:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 01:07:17 --> Helper loaded: url_helper
INFO - 2017-02-24 01:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 01:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-24 01:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-24 01:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-24 01:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 01:07:17 --> Final output sent to browser
DEBUG - 2017-02-24 01:07:17 --> Total execution time: 1.0960
INFO - 2017-02-24 02:59:20 --> Config Class Initialized
INFO - 2017-02-24 02:59:20 --> Hooks Class Initialized
DEBUG - 2017-02-24 02:59:20 --> UTF-8 Support Enabled
INFO - 2017-02-24 02:59:20 --> Utf8 Class Initialized
INFO - 2017-02-24 02:59:20 --> URI Class Initialized
INFO - 2017-02-24 02:59:20 --> Router Class Initialized
INFO - 2017-02-24 02:59:20 --> Output Class Initialized
INFO - 2017-02-24 02:59:20 --> Security Class Initialized
DEBUG - 2017-02-24 02:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 02:59:20 --> Input Class Initialized
INFO - 2017-02-24 02:59:20 --> Language Class Initialized
INFO - 2017-02-24 02:59:20 --> Loader Class Initialized
INFO - 2017-02-24 02:59:20 --> Database Driver Class Initialized
INFO - 2017-02-24 02:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 02:59:20 --> Controller Class Initialized
INFO - 2017-02-24 02:59:20 --> Helper loaded: url_helper
DEBUG - 2017-02-24 02:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 02:59:21 --> Final output sent to browser
DEBUG - 2017-02-24 02:59:21 --> Total execution time: 1.2356
INFO - 2017-02-24 02:59:21 --> Config Class Initialized
INFO - 2017-02-24 02:59:21 --> Hooks Class Initialized
DEBUG - 2017-02-24 02:59:21 --> UTF-8 Support Enabled
INFO - 2017-02-24 02:59:21 --> Utf8 Class Initialized
INFO - 2017-02-24 02:59:21 --> URI Class Initialized
DEBUG - 2017-02-24 02:59:21 --> No URI present. Default controller set.
INFO - 2017-02-24 02:59:21 --> Router Class Initialized
INFO - 2017-02-24 02:59:21 --> Output Class Initialized
INFO - 2017-02-24 02:59:21 --> Security Class Initialized
DEBUG - 2017-02-24 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 02:59:21 --> Input Class Initialized
INFO - 2017-02-24 02:59:21 --> Language Class Initialized
INFO - 2017-02-24 02:59:21 --> Loader Class Initialized
INFO - 2017-02-24 02:59:21 --> Database Driver Class Initialized
INFO - 2017-02-24 02:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 02:59:21 --> Controller Class Initialized
INFO - 2017-02-24 02:59:21 --> Helper loaded: url_helper
DEBUG - 2017-02-24 02:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 02:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 02:59:21 --> Final output sent to browser
DEBUG - 2017-02-24 02:59:21 --> Total execution time: 0.0139
INFO - 2017-02-24 09:03:37 --> Config Class Initialized
INFO - 2017-02-24 09:03:37 --> Hooks Class Initialized
DEBUG - 2017-02-24 09:03:37 --> UTF-8 Support Enabled
INFO - 2017-02-24 09:03:37 --> Utf8 Class Initialized
INFO - 2017-02-24 09:03:37 --> URI Class Initialized
INFO - 2017-02-24 09:03:37 --> Router Class Initialized
INFO - 2017-02-24 09:03:37 --> Output Class Initialized
INFO - 2017-02-24 09:03:37 --> Security Class Initialized
DEBUG - 2017-02-24 09:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 09:03:37 --> Input Class Initialized
INFO - 2017-02-24 09:03:37 --> Language Class Initialized
INFO - 2017-02-24 09:03:37 --> Loader Class Initialized
INFO - 2017-02-24 09:03:38 --> Database Driver Class Initialized
INFO - 2017-02-24 09:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 09:03:38 --> Controller Class Initialized
INFO - 2017-02-24 09:03:38 --> Helper loaded: url_helper
DEBUG - 2017-02-24 09:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 09:03:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 09:03:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 09:03:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 09:03:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 09:03:39 --> Final output sent to browser
DEBUG - 2017-02-24 09:03:39 --> Total execution time: 2.0925
INFO - 2017-02-24 09:05:24 --> Config Class Initialized
INFO - 2017-02-24 09:05:24 --> Hooks Class Initialized
DEBUG - 2017-02-24 09:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 09:05:25 --> Utf8 Class Initialized
INFO - 2017-02-24 09:05:25 --> URI Class Initialized
DEBUG - 2017-02-24 09:05:25 --> No URI present. Default controller set.
INFO - 2017-02-24 09:05:25 --> Router Class Initialized
INFO - 2017-02-24 09:05:25 --> Output Class Initialized
INFO - 2017-02-24 09:05:25 --> Security Class Initialized
DEBUG - 2017-02-24 09:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 09:05:25 --> Input Class Initialized
INFO - 2017-02-24 09:05:25 --> Language Class Initialized
INFO - 2017-02-24 09:05:25 --> Loader Class Initialized
INFO - 2017-02-24 09:05:25 --> Database Driver Class Initialized
INFO - 2017-02-24 09:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 09:05:26 --> Controller Class Initialized
INFO - 2017-02-24 09:05:26 --> Helper loaded: url_helper
DEBUG - 2017-02-24 09:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 09:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 09:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 09:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 09:05:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 09:05:26 --> Final output sent to browser
DEBUG - 2017-02-24 09:05:26 --> Total execution time: 1.8081
INFO - 2017-02-24 09:09:24 --> Config Class Initialized
INFO - 2017-02-24 09:09:24 --> Hooks Class Initialized
DEBUG - 2017-02-24 09:09:24 --> UTF-8 Support Enabled
INFO - 2017-02-24 09:09:24 --> Utf8 Class Initialized
INFO - 2017-02-24 09:09:24 --> URI Class Initialized
INFO - 2017-02-24 09:09:24 --> Router Class Initialized
INFO - 2017-02-24 09:09:24 --> Output Class Initialized
INFO - 2017-02-24 09:09:24 --> Security Class Initialized
DEBUG - 2017-02-24 09:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 09:09:24 --> Input Class Initialized
INFO - 2017-02-24 09:09:24 --> Language Class Initialized
INFO - 2017-02-24 09:09:24 --> Loader Class Initialized
INFO - 2017-02-24 09:09:24 --> Database Driver Class Initialized
INFO - 2017-02-24 09:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 09:09:25 --> Controller Class Initialized
INFO - 2017-02-24 09:09:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 09:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 09:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 09:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 09:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 09:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 09:09:25 --> Final output sent to browser
DEBUG - 2017-02-24 09:09:25 --> Total execution time: 1.4344
INFO - 2017-02-24 09:09:31 --> Config Class Initialized
INFO - 2017-02-24 09:09:31 --> Hooks Class Initialized
DEBUG - 2017-02-24 09:09:31 --> UTF-8 Support Enabled
INFO - 2017-02-24 09:09:31 --> Utf8 Class Initialized
INFO - 2017-02-24 09:09:31 --> URI Class Initialized
DEBUG - 2017-02-24 09:09:31 --> No URI present. Default controller set.
INFO - 2017-02-24 09:09:31 --> Router Class Initialized
INFO - 2017-02-24 09:09:31 --> Output Class Initialized
INFO - 2017-02-24 09:09:31 --> Security Class Initialized
DEBUG - 2017-02-24 09:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 09:09:31 --> Input Class Initialized
INFO - 2017-02-24 09:09:31 --> Language Class Initialized
INFO - 2017-02-24 09:09:31 --> Loader Class Initialized
INFO - 2017-02-24 09:09:31 --> Database Driver Class Initialized
INFO - 2017-02-24 09:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 09:09:31 --> Controller Class Initialized
INFO - 2017-02-24 09:09:31 --> Helper loaded: url_helper
DEBUG - 2017-02-24 09:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 09:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 09:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 09:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 09:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 09:09:31 --> Final output sent to browser
DEBUG - 2017-02-24 09:09:31 --> Total execution time: 0.0140
INFO - 2017-02-24 15:41:29 --> Config Class Initialized
INFO - 2017-02-24 15:41:29 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:41:29 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:41:29 --> Utf8 Class Initialized
INFO - 2017-02-24 15:41:29 --> URI Class Initialized
DEBUG - 2017-02-24 15:41:29 --> No URI present. Default controller set.
INFO - 2017-02-24 15:41:29 --> Router Class Initialized
INFO - 2017-02-24 15:41:29 --> Output Class Initialized
INFO - 2017-02-24 15:41:29 --> Security Class Initialized
DEBUG - 2017-02-24 15:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:41:29 --> Input Class Initialized
INFO - 2017-02-24 15:41:29 --> Language Class Initialized
INFO - 2017-02-24 15:41:29 --> Loader Class Initialized
INFO - 2017-02-24 15:41:30 --> Database Driver Class Initialized
INFO - 2017-02-24 15:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:41:30 --> Controller Class Initialized
INFO - 2017-02-24 15:41:30 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:41:30 --> Final output sent to browser
DEBUG - 2017-02-24 15:41:30 --> Total execution time: 1.6070
INFO - 2017-02-24 15:41:34 --> Config Class Initialized
INFO - 2017-02-24 15:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:41:34 --> Utf8 Class Initialized
INFO - 2017-02-24 15:41:34 --> URI Class Initialized
INFO - 2017-02-24 15:41:34 --> Router Class Initialized
INFO - 2017-02-24 15:41:34 --> Output Class Initialized
INFO - 2017-02-24 15:41:34 --> Security Class Initialized
DEBUG - 2017-02-24 15:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:41:34 --> Input Class Initialized
INFO - 2017-02-24 15:41:34 --> Language Class Initialized
INFO - 2017-02-24 15:41:34 --> Loader Class Initialized
INFO - 2017-02-24 15:41:34 --> Database Driver Class Initialized
INFO - 2017-02-24 15:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:41:34 --> Controller Class Initialized
INFO - 2017-02-24 15:41:34 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:41:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:41:34 --> Final output sent to browser
DEBUG - 2017-02-24 15:41:34 --> Total execution time: 0.0142
INFO - 2017-02-24 15:41:54 --> Config Class Initialized
INFO - 2017-02-24 15:41:54 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:41:54 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:41:54 --> Utf8 Class Initialized
INFO - 2017-02-24 15:41:54 --> URI Class Initialized
DEBUG - 2017-02-24 15:41:54 --> No URI present. Default controller set.
INFO - 2017-02-24 15:41:54 --> Router Class Initialized
INFO - 2017-02-24 15:41:54 --> Output Class Initialized
INFO - 2017-02-24 15:41:54 --> Security Class Initialized
DEBUG - 2017-02-24 15:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:41:54 --> Input Class Initialized
INFO - 2017-02-24 15:41:54 --> Language Class Initialized
INFO - 2017-02-24 15:41:54 --> Loader Class Initialized
INFO - 2017-02-24 15:41:54 --> Database Driver Class Initialized
INFO - 2017-02-24 15:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:41:54 --> Controller Class Initialized
INFO - 2017-02-24 15:41:54 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:41:54 --> Final output sent to browser
DEBUG - 2017-02-24 15:41:54 --> Total execution time: 0.0135
INFO - 2017-02-24 15:41:56 --> Config Class Initialized
INFO - 2017-02-24 15:41:56 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:41:56 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:41:56 --> Utf8 Class Initialized
INFO - 2017-02-24 15:41:56 --> URI Class Initialized
INFO - 2017-02-24 15:41:56 --> Router Class Initialized
INFO - 2017-02-24 15:41:56 --> Output Class Initialized
INFO - 2017-02-24 15:41:56 --> Security Class Initialized
DEBUG - 2017-02-24 15:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:41:56 --> Input Class Initialized
INFO - 2017-02-24 15:41:56 --> Language Class Initialized
INFO - 2017-02-24 15:41:56 --> Loader Class Initialized
INFO - 2017-02-24 15:41:56 --> Database Driver Class Initialized
INFO - 2017-02-24 15:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:41:56 --> Controller Class Initialized
INFO - 2017-02-24 15:41:56 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:41:56 --> Final output sent to browser
DEBUG - 2017-02-24 15:41:56 --> Total execution time: 0.0142
INFO - 2017-02-24 15:43:10 --> Config Class Initialized
INFO - 2017-02-24 15:43:10 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:43:10 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:43:10 --> Utf8 Class Initialized
INFO - 2017-02-24 15:43:10 --> URI Class Initialized
INFO - 2017-02-24 15:43:10 --> Router Class Initialized
INFO - 2017-02-24 15:43:10 --> Output Class Initialized
INFO - 2017-02-24 15:43:10 --> Security Class Initialized
DEBUG - 2017-02-24 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:43:10 --> Input Class Initialized
INFO - 2017-02-24 15:43:10 --> Language Class Initialized
INFO - 2017-02-24 15:43:10 --> Loader Class Initialized
INFO - 2017-02-24 15:43:11 --> Database Driver Class Initialized
INFO - 2017-02-24 15:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:43:11 --> Controller Class Initialized
INFO - 2017-02-24 15:43:11 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:43:12 --> Final output sent to browser
DEBUG - 2017-02-24 15:43:12 --> Total execution time: 1.7945
INFO - 2017-02-24 15:43:15 --> Config Class Initialized
INFO - 2017-02-24 15:43:15 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:43:15 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:43:15 --> Utf8 Class Initialized
INFO - 2017-02-24 15:43:15 --> URI Class Initialized
INFO - 2017-02-24 15:43:15 --> Router Class Initialized
INFO - 2017-02-24 15:43:15 --> Output Class Initialized
INFO - 2017-02-24 15:43:15 --> Security Class Initialized
DEBUG - 2017-02-24 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:43:15 --> Input Class Initialized
INFO - 2017-02-24 15:43:15 --> Language Class Initialized
INFO - 2017-02-24 15:43:16 --> Loader Class Initialized
INFO - 2017-02-24 15:43:16 --> Database Driver Class Initialized
INFO - 2017-02-24 15:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:43:16 --> Controller Class Initialized
INFO - 2017-02-24 15:43:16 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:43:16 --> Final output sent to browser
DEBUG - 2017-02-24 15:43:16 --> Total execution time: 1.2109
INFO - 2017-02-24 15:43:28 --> Config Class Initialized
INFO - 2017-02-24 15:43:28 --> Config Class Initialized
INFO - 2017-02-24 15:43:28 --> Hooks Class Initialized
INFO - 2017-02-24 15:43:28 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:43:29 --> UTF-8 Support Enabled
DEBUG - 2017-02-24 15:43:29 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:43:29 --> Utf8 Class Initialized
INFO - 2017-02-24 15:43:29 --> Utf8 Class Initialized
INFO - 2017-02-24 15:43:29 --> URI Class Initialized
INFO - 2017-02-24 15:43:29 --> URI Class Initialized
INFO - 2017-02-24 15:43:29 --> Router Class Initialized
INFO - 2017-02-24 15:43:29 --> Router Class Initialized
INFO - 2017-02-24 15:43:29 --> Output Class Initialized
INFO - 2017-02-24 15:43:29 --> Output Class Initialized
INFO - 2017-02-24 15:43:29 --> Security Class Initialized
INFO - 2017-02-24 15:43:29 --> Security Class Initialized
DEBUG - 2017-02-24 15:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:43:29 --> Input Class Initialized
INFO - 2017-02-24 15:43:29 --> Language Class Initialized
DEBUG - 2017-02-24 15:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:43:29 --> Input Class Initialized
INFO - 2017-02-24 15:43:29 --> Language Class Initialized
INFO - 2017-02-24 15:43:29 --> Loader Class Initialized
INFO - 2017-02-24 15:43:29 --> Loader Class Initialized
INFO - 2017-02-24 15:43:29 --> Database Driver Class Initialized
INFO - 2017-02-24 15:43:29 --> Database Driver Class Initialized
INFO - 2017-02-24 15:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:43:29 --> Controller Class Initialized
INFO - 2017-02-24 15:43:29 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:43:30 --> Final output sent to browser
DEBUG - 2017-02-24 15:43:30 --> Total execution time: 1.5421
INFO - 2017-02-24 15:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:43:30 --> Controller Class Initialized
INFO - 2017-02-24 15:43:30 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:43:30 --> Final output sent to browser
DEBUG - 2017-02-24 15:43:30 --> Total execution time: 1.5701
INFO - 2017-02-24 15:43:32 --> Config Class Initialized
INFO - 2017-02-24 15:43:32 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:43:32 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:43:32 --> Utf8 Class Initialized
INFO - 2017-02-24 15:43:32 --> URI Class Initialized
INFO - 2017-02-24 15:43:32 --> Router Class Initialized
INFO - 2017-02-24 15:43:32 --> Output Class Initialized
INFO - 2017-02-24 15:43:33 --> Security Class Initialized
DEBUG - 2017-02-24 15:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:43:33 --> Input Class Initialized
INFO - 2017-02-24 15:43:33 --> Language Class Initialized
INFO - 2017-02-24 15:43:33 --> Loader Class Initialized
INFO - 2017-02-24 15:43:33 --> Database Driver Class Initialized
INFO - 2017-02-24 15:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:43:33 --> Controller Class Initialized
INFO - 2017-02-24 15:43:33 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:43:34 --> Final output sent to browser
DEBUG - 2017-02-24 15:43:34 --> Total execution time: 1.2274
INFO - 2017-02-24 15:43:52 --> Config Class Initialized
INFO - 2017-02-24 15:43:52 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:43:52 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:43:52 --> Utf8 Class Initialized
INFO - 2017-02-24 15:43:52 --> URI Class Initialized
INFO - 2017-02-24 15:43:52 --> Router Class Initialized
INFO - 2017-02-24 15:43:52 --> Output Class Initialized
INFO - 2017-02-24 15:43:52 --> Security Class Initialized
DEBUG - 2017-02-24 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:43:52 --> Input Class Initialized
INFO - 2017-02-24 15:43:52 --> Language Class Initialized
INFO - 2017-02-24 15:43:52 --> Loader Class Initialized
INFO - 2017-02-24 15:43:52 --> Database Driver Class Initialized
INFO - 2017-02-24 15:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:43:53 --> Controller Class Initialized
INFO - 2017-02-24 15:43:53 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:43:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:43:53 --> Final output sent to browser
DEBUG - 2017-02-24 15:43:53 --> Total execution time: 1.2445
INFO - 2017-02-24 15:43:55 --> Config Class Initialized
INFO - 2017-02-24 15:43:55 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:43:55 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:43:55 --> Utf8 Class Initialized
INFO - 2017-02-24 15:43:55 --> URI Class Initialized
INFO - 2017-02-24 15:43:55 --> Router Class Initialized
INFO - 2017-02-24 15:43:55 --> Output Class Initialized
INFO - 2017-02-24 15:43:55 --> Security Class Initialized
DEBUG - 2017-02-24 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:43:55 --> Input Class Initialized
INFO - 2017-02-24 15:43:55 --> Language Class Initialized
INFO - 2017-02-24 15:43:55 --> Loader Class Initialized
INFO - 2017-02-24 15:43:55 --> Database Driver Class Initialized
INFO - 2017-02-24 15:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:43:56 --> Controller Class Initialized
INFO - 2017-02-24 15:43:56 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:43:56 --> Final output sent to browser
DEBUG - 2017-02-24 15:43:56 --> Total execution time: 0.8260
INFO - 2017-02-24 15:44:12 --> Config Class Initialized
INFO - 2017-02-24 15:44:12 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:44:12 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:44:12 --> Utf8 Class Initialized
INFO - 2017-02-24 15:44:12 --> URI Class Initialized
INFO - 2017-02-24 15:44:12 --> Router Class Initialized
INFO - 2017-02-24 15:44:12 --> Output Class Initialized
INFO - 2017-02-24 15:44:12 --> Security Class Initialized
DEBUG - 2017-02-24 15:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:44:12 --> Input Class Initialized
INFO - 2017-02-24 15:44:12 --> Language Class Initialized
INFO - 2017-02-24 15:44:12 --> Loader Class Initialized
INFO - 2017-02-24 15:44:13 --> Database Driver Class Initialized
INFO - 2017-02-24 15:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:44:13 --> Controller Class Initialized
INFO - 2017-02-24 15:44:13 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:44:13 --> Final output sent to browser
DEBUG - 2017-02-24 15:44:13 --> Total execution time: 1.5260
INFO - 2017-02-24 15:44:16 --> Config Class Initialized
INFO - 2017-02-24 15:44:16 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:44:16 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:44:16 --> Utf8 Class Initialized
INFO - 2017-02-24 15:44:16 --> URI Class Initialized
INFO - 2017-02-24 15:44:16 --> Router Class Initialized
INFO - 2017-02-24 15:44:16 --> Output Class Initialized
INFO - 2017-02-24 15:44:16 --> Security Class Initialized
DEBUG - 2017-02-24 15:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:44:16 --> Input Class Initialized
INFO - 2017-02-24 15:44:16 --> Language Class Initialized
INFO - 2017-02-24 15:44:16 --> Loader Class Initialized
INFO - 2017-02-24 15:44:16 --> Database Driver Class Initialized
INFO - 2017-02-24 15:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:44:16 --> Controller Class Initialized
INFO - 2017-02-24 15:44:16 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:44:16 --> Final output sent to browser
DEBUG - 2017-02-24 15:44:16 --> Total execution time: 0.2342
INFO - 2017-02-24 15:44:45 --> Config Class Initialized
INFO - 2017-02-24 15:44:45 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:44:45 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:44:45 --> Utf8 Class Initialized
INFO - 2017-02-24 15:44:45 --> URI Class Initialized
INFO - 2017-02-24 15:44:45 --> Router Class Initialized
INFO - 2017-02-24 15:44:45 --> Output Class Initialized
INFO - 2017-02-24 15:44:45 --> Security Class Initialized
DEBUG - 2017-02-24 15:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:44:45 --> Input Class Initialized
INFO - 2017-02-24 15:44:45 --> Language Class Initialized
INFO - 2017-02-24 15:44:45 --> Loader Class Initialized
INFO - 2017-02-24 15:44:45 --> Database Driver Class Initialized
INFO - 2017-02-24 15:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:44:45 --> Controller Class Initialized
INFO - 2017-02-24 15:44:45 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:44:46 --> Final output sent to browser
DEBUG - 2017-02-24 15:44:46 --> Total execution time: 1.2657
INFO - 2017-02-24 15:44:47 --> Config Class Initialized
INFO - 2017-02-24 15:44:47 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:44:47 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:44:47 --> Utf8 Class Initialized
INFO - 2017-02-24 15:44:47 --> URI Class Initialized
INFO - 2017-02-24 15:44:47 --> Router Class Initialized
INFO - 2017-02-24 15:44:47 --> Output Class Initialized
INFO - 2017-02-24 15:44:47 --> Security Class Initialized
DEBUG - 2017-02-24 15:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:44:47 --> Input Class Initialized
INFO - 2017-02-24 15:44:47 --> Language Class Initialized
INFO - 2017-02-24 15:44:47 --> Loader Class Initialized
INFO - 2017-02-24 15:44:47 --> Database Driver Class Initialized
INFO - 2017-02-24 15:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:44:47 --> Controller Class Initialized
INFO - 2017-02-24 15:44:47 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:44:47 --> Final output sent to browser
DEBUG - 2017-02-24 15:44:47 --> Total execution time: 0.0141
INFO - 2017-02-24 15:45:36 --> Config Class Initialized
INFO - 2017-02-24 15:45:36 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:45:36 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:45:36 --> Utf8 Class Initialized
INFO - 2017-02-24 15:45:36 --> URI Class Initialized
INFO - 2017-02-24 15:45:36 --> Router Class Initialized
INFO - 2017-02-24 15:45:36 --> Output Class Initialized
INFO - 2017-02-24 15:45:36 --> Security Class Initialized
DEBUG - 2017-02-24 15:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:45:36 --> Input Class Initialized
INFO - 2017-02-24 15:45:36 --> Language Class Initialized
INFO - 2017-02-24 15:45:36 --> Loader Class Initialized
INFO - 2017-02-24 15:45:36 --> Database Driver Class Initialized
INFO - 2017-02-24 15:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:45:36 --> Controller Class Initialized
INFO - 2017-02-24 15:45:36 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:45:43 --> Config Class Initialized
INFO - 2017-02-24 15:45:43 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:45:45 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:45:45 --> Utf8 Class Initialized
INFO - 2017-02-24 15:45:45 --> URI Class Initialized
INFO - 2017-02-24 15:45:45 --> Router Class Initialized
INFO - 2017-02-24 15:45:45 --> Output Class Initialized
INFO - 2017-02-24 15:45:45 --> Security Class Initialized
DEBUG - 2017-02-24 15:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:45:45 --> Input Class Initialized
INFO - 2017-02-24 15:45:45 --> Language Class Initialized
INFO - 2017-02-24 15:45:45 --> Loader Class Initialized
INFO - 2017-02-24 15:45:45 --> Database Driver Class Initialized
INFO - 2017-02-24 15:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:45:45 --> Controller Class Initialized
INFO - 2017-02-24 15:45:45 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:45:50 --> Config Class Initialized
INFO - 2017-02-24 15:45:50 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:45:50 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:45:50 --> Utf8 Class Initialized
INFO - 2017-02-24 15:45:50 --> URI Class Initialized
INFO - 2017-02-24 15:45:50 --> Router Class Initialized
INFO - 2017-02-24 15:45:50 --> Output Class Initialized
INFO - 2017-02-24 15:45:50 --> Security Class Initialized
DEBUG - 2017-02-24 15:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:45:50 --> Input Class Initialized
INFO - 2017-02-24 15:45:50 --> Language Class Initialized
INFO - 2017-02-24 15:45:50 --> Loader Class Initialized
INFO - 2017-02-24 15:45:51 --> Database Driver Class Initialized
INFO - 2017-02-24 15:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:45:51 --> Controller Class Initialized
INFO - 2017-02-24 15:45:51 --> Helper loaded: date_helper
DEBUG - 2017-02-24 15:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:45:51 --> Helper loaded: url_helper
INFO - 2017-02-24 15:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-24 15:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-24 15:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-24 15:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:45:51 --> Final output sent to browser
DEBUG - 2017-02-24 15:45:51 --> Total execution time: 1.3938
INFO - 2017-02-24 15:45:53 --> Config Class Initialized
INFO - 2017-02-24 15:45:53 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:45:53 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:45:53 --> Utf8 Class Initialized
INFO - 2017-02-24 15:45:53 --> URI Class Initialized
INFO - 2017-02-24 15:45:53 --> Router Class Initialized
INFO - 2017-02-24 15:45:53 --> Output Class Initialized
INFO - 2017-02-24 15:45:53 --> Security Class Initialized
DEBUG - 2017-02-24 15:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:45:53 --> Input Class Initialized
INFO - 2017-02-24 15:45:53 --> Language Class Initialized
INFO - 2017-02-24 15:45:53 --> Loader Class Initialized
INFO - 2017-02-24 15:45:53 --> Database Driver Class Initialized
INFO - 2017-02-24 15:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:45:53 --> Controller Class Initialized
INFO - 2017-02-24 15:45:53 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:45:53 --> Final output sent to browser
DEBUG - 2017-02-24 15:45:53 --> Total execution time: 0.2609
INFO - 2017-02-24 15:46:01 --> Config Class Initialized
INFO - 2017-02-24 15:46:01 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:46:01 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:46:01 --> Utf8 Class Initialized
INFO - 2017-02-24 15:46:01 --> URI Class Initialized
DEBUG - 2017-02-24 15:46:01 --> No URI present. Default controller set.
INFO - 2017-02-24 15:46:01 --> Router Class Initialized
INFO - 2017-02-24 15:46:01 --> Output Class Initialized
INFO - 2017-02-24 15:46:01 --> Security Class Initialized
DEBUG - 2017-02-24 15:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:46:01 --> Input Class Initialized
INFO - 2017-02-24 15:46:01 --> Language Class Initialized
INFO - 2017-02-24 15:46:01 --> Loader Class Initialized
INFO - 2017-02-24 15:46:01 --> Database Driver Class Initialized
INFO - 2017-02-24 15:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:46:01 --> Controller Class Initialized
INFO - 2017-02-24 15:46:01 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:46:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:46:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:46:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:46:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:46:01 --> Final output sent to browser
DEBUG - 2017-02-24 15:46:01 --> Total execution time: 0.0136
INFO - 2017-02-24 15:46:03 --> Config Class Initialized
INFO - 2017-02-24 15:46:03 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:46:03 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:46:03 --> Utf8 Class Initialized
INFO - 2017-02-24 15:46:03 --> URI Class Initialized
INFO - 2017-02-24 15:46:03 --> Router Class Initialized
INFO - 2017-02-24 15:46:03 --> Output Class Initialized
INFO - 2017-02-24 15:46:03 --> Security Class Initialized
DEBUG - 2017-02-24 15:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:46:03 --> Input Class Initialized
INFO - 2017-02-24 15:46:03 --> Language Class Initialized
INFO - 2017-02-24 15:46:03 --> Loader Class Initialized
INFO - 2017-02-24 15:46:03 --> Database Driver Class Initialized
INFO - 2017-02-24 15:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:46:03 --> Controller Class Initialized
INFO - 2017-02-24 15:46:03 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:46:03 --> Final output sent to browser
DEBUG - 2017-02-24 15:46:03 --> Total execution time: 0.0654
INFO - 2017-02-24 15:46:20 --> Config Class Initialized
INFO - 2017-02-24 15:46:20 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:46:20 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:46:20 --> Utf8 Class Initialized
INFO - 2017-02-24 15:46:20 --> URI Class Initialized
INFO - 2017-02-24 15:46:20 --> Router Class Initialized
INFO - 2017-02-24 15:46:20 --> Output Class Initialized
INFO - 2017-02-24 15:46:20 --> Security Class Initialized
DEBUG - 2017-02-24 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:46:20 --> Input Class Initialized
INFO - 2017-02-24 15:46:20 --> Language Class Initialized
INFO - 2017-02-24 15:46:20 --> Loader Class Initialized
INFO - 2017-02-24 15:46:20 --> Database Driver Class Initialized
INFO - 2017-02-24 15:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:46:21 --> Controller Class Initialized
INFO - 2017-02-24 15:46:21 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:46:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:46:21 --> Final output sent to browser
DEBUG - 2017-02-24 15:46:21 --> Total execution time: 1.2572
INFO - 2017-02-24 15:46:22 --> Config Class Initialized
INFO - 2017-02-24 15:46:22 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:46:22 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:46:22 --> Utf8 Class Initialized
INFO - 2017-02-24 15:46:22 --> URI Class Initialized
INFO - 2017-02-24 15:46:22 --> Router Class Initialized
INFO - 2017-02-24 15:46:22 --> Output Class Initialized
INFO - 2017-02-24 15:46:22 --> Security Class Initialized
DEBUG - 2017-02-24 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:46:22 --> Input Class Initialized
INFO - 2017-02-24 15:46:22 --> Language Class Initialized
INFO - 2017-02-24 15:46:22 --> Loader Class Initialized
INFO - 2017-02-24 15:46:22 --> Database Driver Class Initialized
INFO - 2017-02-24 15:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:46:22 --> Controller Class Initialized
INFO - 2017-02-24 15:46:22 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:46:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:46:22 --> Final output sent to browser
DEBUG - 2017-02-24 15:46:22 --> Total execution time: 0.0147
INFO - 2017-02-24 15:47:08 --> Config Class Initialized
INFO - 2017-02-24 15:47:08 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:47:08 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:47:08 --> Utf8 Class Initialized
INFO - 2017-02-24 15:47:08 --> URI Class Initialized
INFO - 2017-02-24 15:47:08 --> Router Class Initialized
INFO - 2017-02-24 15:47:08 --> Output Class Initialized
INFO - 2017-02-24 15:47:08 --> Security Class Initialized
DEBUG - 2017-02-24 15:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:47:08 --> Input Class Initialized
INFO - 2017-02-24 15:47:08 --> Language Class Initialized
INFO - 2017-02-24 15:47:08 --> Loader Class Initialized
INFO - 2017-02-24 15:47:09 --> Database Driver Class Initialized
INFO - 2017-02-24 15:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:47:09 --> Controller Class Initialized
INFO - 2017-02-24 15:47:09 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:47:09 --> Final output sent to browser
DEBUG - 2017-02-24 15:47:09 --> Total execution time: 1.5105
INFO - 2017-02-24 15:47:11 --> Config Class Initialized
INFO - 2017-02-24 15:47:11 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:47:11 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:47:11 --> Utf8 Class Initialized
INFO - 2017-02-24 15:47:11 --> URI Class Initialized
INFO - 2017-02-24 15:47:11 --> Router Class Initialized
INFO - 2017-02-24 15:47:11 --> Output Class Initialized
INFO - 2017-02-24 15:47:11 --> Security Class Initialized
DEBUG - 2017-02-24 15:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:47:11 --> Input Class Initialized
INFO - 2017-02-24 15:47:11 --> Language Class Initialized
INFO - 2017-02-24 15:47:11 --> Loader Class Initialized
INFO - 2017-02-24 15:47:11 --> Database Driver Class Initialized
INFO - 2017-02-24 15:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:47:11 --> Controller Class Initialized
INFO - 2017-02-24 15:47:11 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:47:11 --> Final output sent to browser
DEBUG - 2017-02-24 15:47:11 --> Total execution time: 0.0136
INFO - 2017-02-24 15:47:52 --> Config Class Initialized
INFO - 2017-02-24 15:47:52 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:47:52 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:47:52 --> Utf8 Class Initialized
INFO - 2017-02-24 15:47:52 --> URI Class Initialized
INFO - 2017-02-24 15:47:52 --> Router Class Initialized
INFO - 2017-02-24 15:47:52 --> Output Class Initialized
INFO - 2017-02-24 15:47:52 --> Security Class Initialized
DEBUG - 2017-02-24 15:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:47:52 --> Input Class Initialized
INFO - 2017-02-24 15:47:52 --> Language Class Initialized
INFO - 2017-02-24 15:47:52 --> Loader Class Initialized
INFO - 2017-02-24 15:47:53 --> Database Driver Class Initialized
INFO - 2017-02-24 15:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:47:53 --> Controller Class Initialized
INFO - 2017-02-24 15:47:53 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:47:53 --> Final output sent to browser
DEBUG - 2017-02-24 15:47:53 --> Total execution time: 1.2710
INFO - 2017-02-24 15:47:57 --> Config Class Initialized
INFO - 2017-02-24 15:47:57 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:47:57 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:47:57 --> Utf8 Class Initialized
INFO - 2017-02-24 15:47:57 --> URI Class Initialized
INFO - 2017-02-24 15:47:57 --> Router Class Initialized
INFO - 2017-02-24 15:47:57 --> Output Class Initialized
INFO - 2017-02-24 15:47:57 --> Security Class Initialized
DEBUG - 2017-02-24 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:47:57 --> Input Class Initialized
INFO - 2017-02-24 15:47:57 --> Language Class Initialized
INFO - 2017-02-24 15:47:57 --> Loader Class Initialized
INFO - 2017-02-24 15:47:57 --> Database Driver Class Initialized
INFO - 2017-02-24 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:47:57 --> Controller Class Initialized
INFO - 2017-02-24 15:47:57 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:47:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:47:58 --> Final output sent to browser
DEBUG - 2017-02-24 15:47:58 --> Total execution time: 1.2108
INFO - 2017-02-24 15:48:24 --> Config Class Initialized
INFO - 2017-02-24 15:48:24 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:48:24 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:48:24 --> Utf8 Class Initialized
INFO - 2017-02-24 15:48:24 --> URI Class Initialized
INFO - 2017-02-24 15:48:25 --> Router Class Initialized
INFO - 2017-02-24 15:48:25 --> Output Class Initialized
INFO - 2017-02-24 15:48:25 --> Security Class Initialized
DEBUG - 2017-02-24 15:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:48:25 --> Input Class Initialized
INFO - 2017-02-24 15:48:25 --> Language Class Initialized
INFO - 2017-02-24 15:48:25 --> Loader Class Initialized
INFO - 2017-02-24 15:48:25 --> Database Driver Class Initialized
INFO - 2017-02-24 15:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:48:25 --> Controller Class Initialized
INFO - 2017-02-24 15:48:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:48:26 --> Final output sent to browser
DEBUG - 2017-02-24 15:48:26 --> Total execution time: 1.5932
INFO - 2017-02-24 15:48:28 --> Config Class Initialized
INFO - 2017-02-24 15:48:28 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:48:28 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:48:28 --> Utf8 Class Initialized
INFO - 2017-02-24 15:48:28 --> URI Class Initialized
INFO - 2017-02-24 15:48:28 --> Router Class Initialized
INFO - 2017-02-24 15:48:28 --> Output Class Initialized
INFO - 2017-02-24 15:48:28 --> Security Class Initialized
DEBUG - 2017-02-24 15:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:48:28 --> Input Class Initialized
INFO - 2017-02-24 15:48:28 --> Language Class Initialized
INFO - 2017-02-24 15:48:28 --> Loader Class Initialized
INFO - 2017-02-24 15:48:29 --> Database Driver Class Initialized
INFO - 2017-02-24 15:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:48:29 --> Controller Class Initialized
INFO - 2017-02-24 15:48:29 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:48:29 --> Final output sent to browser
DEBUG - 2017-02-24 15:48:29 --> Total execution time: 1.2650
INFO - 2017-02-24 15:48:47 --> Config Class Initialized
INFO - 2017-02-24 15:48:47 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:48:48 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:48:48 --> Utf8 Class Initialized
INFO - 2017-02-24 15:48:48 --> URI Class Initialized
INFO - 2017-02-24 15:48:48 --> Router Class Initialized
INFO - 2017-02-24 15:48:48 --> Output Class Initialized
INFO - 2017-02-24 15:48:48 --> Security Class Initialized
DEBUG - 2017-02-24 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:48:48 --> Input Class Initialized
INFO - 2017-02-24 15:48:48 --> Language Class Initialized
INFO - 2017-02-24 15:48:48 --> Loader Class Initialized
INFO - 2017-02-24 15:48:48 --> Database Driver Class Initialized
INFO - 2017-02-24 15:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:48:49 --> Controller Class Initialized
INFO - 2017-02-24 15:48:49 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:48:49 --> Final output sent to browser
DEBUG - 2017-02-24 15:48:49 --> Total execution time: 1.5376
INFO - 2017-02-24 15:48:51 --> Config Class Initialized
INFO - 2017-02-24 15:48:51 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:48:51 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:48:51 --> Utf8 Class Initialized
INFO - 2017-02-24 15:48:51 --> URI Class Initialized
INFO - 2017-02-24 15:48:51 --> Router Class Initialized
INFO - 2017-02-24 15:48:52 --> Output Class Initialized
INFO - 2017-02-24 15:48:52 --> Security Class Initialized
DEBUG - 2017-02-24 15:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:48:52 --> Input Class Initialized
INFO - 2017-02-24 15:48:52 --> Language Class Initialized
INFO - 2017-02-24 15:48:52 --> Loader Class Initialized
INFO - 2017-02-24 15:48:52 --> Database Driver Class Initialized
INFO - 2017-02-24 15:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:48:52 --> Controller Class Initialized
INFO - 2017-02-24 15:48:52 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:48:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:48:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:48:53 --> Final output sent to browser
DEBUG - 2017-02-24 15:48:53 --> Total execution time: 1.2861
INFO - 2017-02-24 15:48:59 --> Config Class Initialized
INFO - 2017-02-24 15:48:59 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:48:59 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:48:59 --> Utf8 Class Initialized
INFO - 2017-02-24 15:48:59 --> URI Class Initialized
INFO - 2017-02-24 15:48:59 --> Router Class Initialized
INFO - 2017-02-24 15:48:59 --> Output Class Initialized
INFO - 2017-02-24 15:48:59 --> Security Class Initialized
DEBUG - 2017-02-24 15:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:48:59 --> Input Class Initialized
INFO - 2017-02-24 15:48:59 --> Language Class Initialized
INFO - 2017-02-24 15:48:59 --> Loader Class Initialized
INFO - 2017-02-24 15:49:00 --> Database Driver Class Initialized
INFO - 2017-02-24 15:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:49:00 --> Controller Class Initialized
INFO - 2017-02-24 15:49:00 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:49:00 --> Final output sent to browser
DEBUG - 2017-02-24 15:49:00 --> Total execution time: 1.5309
INFO - 2017-02-24 15:49:04 --> Config Class Initialized
INFO - 2017-02-24 15:49:04 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:49:04 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:49:04 --> Utf8 Class Initialized
INFO - 2017-02-24 15:49:04 --> URI Class Initialized
INFO - 2017-02-24 15:49:04 --> Router Class Initialized
INFO - 2017-02-24 15:49:04 --> Output Class Initialized
INFO - 2017-02-24 15:49:04 --> Security Class Initialized
DEBUG - 2017-02-24 15:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:49:04 --> Input Class Initialized
INFO - 2017-02-24 15:49:04 --> Language Class Initialized
INFO - 2017-02-24 15:49:04 --> Loader Class Initialized
INFO - 2017-02-24 15:49:04 --> Database Driver Class Initialized
INFO - 2017-02-24 15:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:49:04 --> Controller Class Initialized
INFO - 2017-02-24 15:49:04 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:49:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:49:05 --> Final output sent to browser
DEBUG - 2017-02-24 15:49:05 --> Total execution time: 1.2259
INFO - 2017-02-24 15:49:24 --> Config Class Initialized
INFO - 2017-02-24 15:49:24 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:49:24 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:49:24 --> Utf8 Class Initialized
INFO - 2017-02-24 15:49:24 --> URI Class Initialized
INFO - 2017-02-24 15:49:24 --> Router Class Initialized
INFO - 2017-02-24 15:49:24 --> Output Class Initialized
INFO - 2017-02-24 15:49:24 --> Security Class Initialized
DEBUG - 2017-02-24 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:49:24 --> Input Class Initialized
INFO - 2017-02-24 15:49:24 --> Language Class Initialized
INFO - 2017-02-24 15:49:24 --> Loader Class Initialized
INFO - 2017-02-24 15:49:25 --> Database Driver Class Initialized
INFO - 2017-02-24 15:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:49:25 --> Controller Class Initialized
INFO - 2017-02-24 15:49:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:49:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:49:25 --> Final output sent to browser
DEBUG - 2017-02-24 15:49:25 --> Total execution time: 1.5126
INFO - 2017-02-24 15:49:27 --> Config Class Initialized
INFO - 2017-02-24 15:49:27 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:49:27 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:49:27 --> Utf8 Class Initialized
INFO - 2017-02-24 15:49:27 --> URI Class Initialized
INFO - 2017-02-24 15:49:27 --> Router Class Initialized
INFO - 2017-02-24 15:49:27 --> Output Class Initialized
INFO - 2017-02-24 15:49:27 --> Security Class Initialized
DEBUG - 2017-02-24 15:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:49:27 --> Input Class Initialized
INFO - 2017-02-24 15:49:27 --> Language Class Initialized
INFO - 2017-02-24 15:49:27 --> Loader Class Initialized
INFO - 2017-02-24 15:49:27 --> Database Driver Class Initialized
INFO - 2017-02-24 15:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:49:27 --> Controller Class Initialized
INFO - 2017-02-24 15:49:27 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:49:27 --> Final output sent to browser
DEBUG - 2017-02-24 15:49:27 --> Total execution time: 0.0142
INFO - 2017-02-24 15:50:12 --> Config Class Initialized
INFO - 2017-02-24 15:50:12 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:50:12 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:50:12 --> Utf8 Class Initialized
INFO - 2017-02-24 15:50:12 --> URI Class Initialized
INFO - 2017-02-24 15:50:12 --> Router Class Initialized
INFO - 2017-02-24 15:50:12 --> Output Class Initialized
INFO - 2017-02-24 15:50:12 --> Security Class Initialized
DEBUG - 2017-02-24 15:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:50:12 --> Input Class Initialized
INFO - 2017-02-24 15:50:12 --> Language Class Initialized
INFO - 2017-02-24 15:50:12 --> Loader Class Initialized
INFO - 2017-02-24 15:50:13 --> Database Driver Class Initialized
INFO - 2017-02-24 15:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:50:13 --> Controller Class Initialized
INFO - 2017-02-24 15:50:13 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:50:14 --> Final output sent to browser
DEBUG - 2017-02-24 15:50:14 --> Total execution time: 1.5093
INFO - 2017-02-24 15:50:15 --> Config Class Initialized
INFO - 2017-02-24 15:50:15 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:50:15 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:50:15 --> Utf8 Class Initialized
INFO - 2017-02-24 15:50:15 --> URI Class Initialized
INFO - 2017-02-24 15:50:15 --> Router Class Initialized
INFO - 2017-02-24 15:50:15 --> Output Class Initialized
INFO - 2017-02-24 15:50:15 --> Security Class Initialized
DEBUG - 2017-02-24 15:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:50:15 --> Input Class Initialized
INFO - 2017-02-24 15:50:15 --> Language Class Initialized
INFO - 2017-02-24 15:50:15 --> Loader Class Initialized
INFO - 2017-02-24 15:50:15 --> Database Driver Class Initialized
INFO - 2017-02-24 15:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:50:15 --> Controller Class Initialized
INFO - 2017-02-24 15:50:15 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:50:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:50:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:50:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:50:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:50:15 --> Final output sent to browser
DEBUG - 2017-02-24 15:50:15 --> Total execution time: 0.0152
INFO - 2017-02-24 15:51:23 --> Config Class Initialized
INFO - 2017-02-24 15:51:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:51:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:51:23 --> Utf8 Class Initialized
INFO - 2017-02-24 15:51:23 --> URI Class Initialized
INFO - 2017-02-24 15:51:23 --> Router Class Initialized
INFO - 2017-02-24 15:51:23 --> Output Class Initialized
INFO - 2017-02-24 15:51:23 --> Security Class Initialized
DEBUG - 2017-02-24 15:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:51:23 --> Input Class Initialized
INFO - 2017-02-24 15:51:23 --> Language Class Initialized
INFO - 2017-02-24 15:51:23 --> Loader Class Initialized
INFO - 2017-02-24 15:51:23 --> Database Driver Class Initialized
INFO - 2017-02-24 15:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:51:23 --> Controller Class Initialized
INFO - 2017-02-24 15:51:23 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:51:23 --> Final output sent to browser
DEBUG - 2017-02-24 15:51:23 --> Total execution time: 0.0145
INFO - 2017-02-24 15:51:25 --> Config Class Initialized
INFO - 2017-02-24 15:51:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:51:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:51:25 --> Utf8 Class Initialized
INFO - 2017-02-24 15:51:25 --> URI Class Initialized
INFO - 2017-02-24 15:51:25 --> Router Class Initialized
INFO - 2017-02-24 15:51:25 --> Output Class Initialized
INFO - 2017-02-24 15:51:25 --> Security Class Initialized
DEBUG - 2017-02-24 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:51:25 --> Input Class Initialized
INFO - 2017-02-24 15:51:25 --> Language Class Initialized
INFO - 2017-02-24 15:51:25 --> Loader Class Initialized
INFO - 2017-02-24 15:51:25 --> Database Driver Class Initialized
INFO - 2017-02-24 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:51:25 --> Controller Class Initialized
INFO - 2017-02-24 15:51:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:51:25 --> Final output sent to browser
DEBUG - 2017-02-24 15:51:25 --> Total execution time: 0.0142
INFO - 2017-02-24 15:51:27 --> Config Class Initialized
INFO - 2017-02-24 15:51:27 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:51:27 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:51:27 --> Utf8 Class Initialized
INFO - 2017-02-24 15:51:27 --> URI Class Initialized
INFO - 2017-02-24 15:51:27 --> Router Class Initialized
INFO - 2017-02-24 15:51:27 --> Output Class Initialized
INFO - 2017-02-24 15:51:27 --> Security Class Initialized
DEBUG - 2017-02-24 15:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:51:27 --> Input Class Initialized
INFO - 2017-02-24 15:51:27 --> Language Class Initialized
INFO - 2017-02-24 15:51:27 --> Loader Class Initialized
INFO - 2017-02-24 15:51:27 --> Database Driver Class Initialized
INFO - 2017-02-24 15:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:51:27 --> Controller Class Initialized
INFO - 2017-02-24 15:51:27 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:51:27 --> Final output sent to browser
DEBUG - 2017-02-24 15:51:27 --> Total execution time: 0.0150
INFO - 2017-02-24 15:51:28 --> Config Class Initialized
INFO - 2017-02-24 15:51:28 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:51:28 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:51:28 --> Utf8 Class Initialized
INFO - 2017-02-24 15:51:28 --> URI Class Initialized
INFO - 2017-02-24 15:51:28 --> Router Class Initialized
INFO - 2017-02-24 15:51:28 --> Output Class Initialized
INFO - 2017-02-24 15:51:28 --> Security Class Initialized
DEBUG - 2017-02-24 15:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:51:28 --> Input Class Initialized
INFO - 2017-02-24 15:51:28 --> Language Class Initialized
INFO - 2017-02-24 15:51:28 --> Loader Class Initialized
INFO - 2017-02-24 15:51:28 --> Database Driver Class Initialized
INFO - 2017-02-24 15:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:51:28 --> Controller Class Initialized
INFO - 2017-02-24 15:51:28 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:51:28 --> Final output sent to browser
DEBUG - 2017-02-24 15:51:28 --> Total execution time: 0.0139
INFO - 2017-02-24 15:51:31 --> Config Class Initialized
INFO - 2017-02-24 15:51:31 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:51:31 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:51:31 --> Utf8 Class Initialized
INFO - 2017-02-24 15:51:31 --> URI Class Initialized
INFO - 2017-02-24 15:51:31 --> Router Class Initialized
INFO - 2017-02-24 15:51:31 --> Output Class Initialized
INFO - 2017-02-24 15:51:31 --> Security Class Initialized
DEBUG - 2017-02-24 15:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:51:31 --> Input Class Initialized
INFO - 2017-02-24 15:51:31 --> Language Class Initialized
INFO - 2017-02-24 15:51:31 --> Loader Class Initialized
INFO - 2017-02-24 15:51:31 --> Database Driver Class Initialized
INFO - 2017-02-24 15:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:51:31 --> Controller Class Initialized
INFO - 2017-02-24 15:51:31 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:51:31 --> Final output sent to browser
DEBUG - 2017-02-24 15:51:31 --> Total execution time: 0.0155
INFO - 2017-02-24 15:51:32 --> Config Class Initialized
INFO - 2017-02-24 15:51:32 --> Hooks Class Initialized
DEBUG - 2017-02-24 15:51:32 --> UTF-8 Support Enabled
INFO - 2017-02-24 15:51:32 --> Utf8 Class Initialized
INFO - 2017-02-24 15:51:32 --> URI Class Initialized
INFO - 2017-02-24 15:51:32 --> Router Class Initialized
INFO - 2017-02-24 15:51:32 --> Output Class Initialized
INFO - 2017-02-24 15:51:32 --> Security Class Initialized
DEBUG - 2017-02-24 15:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 15:51:32 --> Input Class Initialized
INFO - 2017-02-24 15:51:32 --> Language Class Initialized
INFO - 2017-02-24 15:51:32 --> Loader Class Initialized
INFO - 2017-02-24 15:51:32 --> Database Driver Class Initialized
INFO - 2017-02-24 15:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 15:51:32 --> Controller Class Initialized
INFO - 2017-02-24 15:51:32 --> Helper loaded: url_helper
DEBUG - 2017-02-24 15:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 15:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 15:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 15:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 15:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 15:51:32 --> Final output sent to browser
DEBUG - 2017-02-24 15:51:32 --> Total execution time: 0.0146
INFO - 2017-02-24 18:48:52 --> Config Class Initialized
INFO - 2017-02-24 18:48:52 --> Hooks Class Initialized
DEBUG - 2017-02-24 18:48:52 --> UTF-8 Support Enabled
INFO - 2017-02-24 18:48:52 --> Utf8 Class Initialized
INFO - 2017-02-24 18:48:52 --> URI Class Initialized
DEBUG - 2017-02-24 18:48:53 --> No URI present. Default controller set.
INFO - 2017-02-24 18:48:53 --> Router Class Initialized
INFO - 2017-02-24 18:48:53 --> Output Class Initialized
INFO - 2017-02-24 18:48:53 --> Security Class Initialized
DEBUG - 2017-02-24 18:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 18:48:53 --> Input Class Initialized
INFO - 2017-02-24 18:48:53 --> Language Class Initialized
INFO - 2017-02-24 18:48:53 --> Loader Class Initialized
INFO - 2017-02-24 18:48:53 --> Database Driver Class Initialized
INFO - 2017-02-24 18:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 18:48:54 --> Controller Class Initialized
INFO - 2017-02-24 18:48:54 --> Helper loaded: url_helper
DEBUG - 2017-02-24 18:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 18:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 18:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 18:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 18:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 18:48:54 --> Final output sent to browser
DEBUG - 2017-02-24 18:48:54 --> Total execution time: 1.7750
INFO - 2017-02-24 18:48:57 --> Config Class Initialized
INFO - 2017-02-24 18:48:57 --> Hooks Class Initialized
DEBUG - 2017-02-24 18:48:57 --> UTF-8 Support Enabled
INFO - 2017-02-24 18:48:57 --> Utf8 Class Initialized
INFO - 2017-02-24 18:48:57 --> URI Class Initialized
INFO - 2017-02-24 18:48:57 --> Router Class Initialized
INFO - 2017-02-24 18:48:57 --> Output Class Initialized
INFO - 2017-02-24 18:48:57 --> Security Class Initialized
DEBUG - 2017-02-24 18:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 18:48:57 --> Input Class Initialized
INFO - 2017-02-24 18:48:57 --> Language Class Initialized
INFO - 2017-02-24 18:48:57 --> Loader Class Initialized
INFO - 2017-02-24 18:48:58 --> Database Driver Class Initialized
INFO - 2017-02-24 18:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 18:48:58 --> Controller Class Initialized
INFO - 2017-02-24 18:48:58 --> Helper loaded: url_helper
DEBUG - 2017-02-24 18:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 18:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 18:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 18:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 18:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 18:48:58 --> Final output sent to browser
DEBUG - 2017-02-24 18:48:58 --> Total execution time: 2.7082
INFO - 2017-02-24 19:40:14 --> Config Class Initialized
INFO - 2017-02-24 19:40:14 --> Hooks Class Initialized
DEBUG - 2017-02-24 19:40:14 --> UTF-8 Support Enabled
INFO - 2017-02-24 19:40:14 --> Utf8 Class Initialized
INFO - 2017-02-24 19:40:14 --> URI Class Initialized
DEBUG - 2017-02-24 19:40:14 --> No URI present. Default controller set.
INFO - 2017-02-24 19:40:14 --> Router Class Initialized
INFO - 2017-02-24 19:40:15 --> Output Class Initialized
INFO - 2017-02-24 19:40:15 --> Security Class Initialized
DEBUG - 2017-02-24 19:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 19:40:15 --> Input Class Initialized
INFO - 2017-02-24 19:40:15 --> Language Class Initialized
INFO - 2017-02-24 19:40:15 --> Loader Class Initialized
INFO - 2017-02-24 19:40:15 --> Database Driver Class Initialized
INFO - 2017-02-24 19:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 19:40:16 --> Controller Class Initialized
INFO - 2017-02-24 19:40:16 --> Helper loaded: url_helper
DEBUG - 2017-02-24 19:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 19:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 19:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 19:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 19:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 19:40:16 --> Final output sent to browser
DEBUG - 2017-02-24 19:40:16 --> Total execution time: 2.0321
INFO - 2017-02-24 20:26:48 --> Config Class Initialized
INFO - 2017-02-24 20:26:48 --> Hooks Class Initialized
DEBUG - 2017-02-24 20:26:48 --> UTF-8 Support Enabled
INFO - 2017-02-24 20:26:48 --> Utf8 Class Initialized
INFO - 2017-02-24 20:26:48 --> URI Class Initialized
DEBUG - 2017-02-24 20:26:48 --> No URI present. Default controller set.
INFO - 2017-02-24 20:26:48 --> Router Class Initialized
INFO - 2017-02-24 20:26:48 --> Output Class Initialized
INFO - 2017-02-24 20:26:48 --> Security Class Initialized
DEBUG - 2017-02-24 20:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 20:26:49 --> Input Class Initialized
INFO - 2017-02-24 20:26:49 --> Language Class Initialized
INFO - 2017-02-24 20:26:49 --> Loader Class Initialized
INFO - 2017-02-24 20:26:49 --> Database Driver Class Initialized
INFO - 2017-02-24 20:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 20:26:50 --> Controller Class Initialized
INFO - 2017-02-24 20:26:50 --> Helper loaded: url_helper
DEBUG - 2017-02-24 20:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 20:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 20:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 20:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 20:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 20:26:50 --> Final output sent to browser
DEBUG - 2017-02-24 20:26:50 --> Total execution time: 1.9177
INFO - 2017-02-24 20:27:48 --> Config Class Initialized
INFO - 2017-02-24 20:27:48 --> Hooks Class Initialized
DEBUG - 2017-02-24 20:27:48 --> UTF-8 Support Enabled
INFO - 2017-02-24 20:27:48 --> Utf8 Class Initialized
INFO - 2017-02-24 20:27:48 --> URI Class Initialized
DEBUG - 2017-02-24 20:27:48 --> No URI present. Default controller set.
INFO - 2017-02-24 20:27:48 --> Router Class Initialized
INFO - 2017-02-24 20:27:48 --> Output Class Initialized
INFO - 2017-02-24 20:27:48 --> Security Class Initialized
DEBUG - 2017-02-24 20:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 20:27:48 --> Input Class Initialized
INFO - 2017-02-24 20:27:48 --> Language Class Initialized
INFO - 2017-02-24 20:27:48 --> Loader Class Initialized
INFO - 2017-02-24 20:27:48 --> Database Driver Class Initialized
INFO - 2017-02-24 20:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 20:27:48 --> Controller Class Initialized
INFO - 2017-02-24 20:27:48 --> Helper loaded: url_helper
DEBUG - 2017-02-24 20:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 20:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 20:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 20:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 20:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 20:27:48 --> Final output sent to browser
DEBUG - 2017-02-24 20:27:48 --> Total execution time: 0.0301
INFO - 2017-02-24 20:33:31 --> Config Class Initialized
INFO - 2017-02-24 20:33:31 --> Hooks Class Initialized
DEBUG - 2017-02-24 20:33:31 --> UTF-8 Support Enabled
INFO - 2017-02-24 20:33:31 --> Utf8 Class Initialized
INFO - 2017-02-24 20:33:31 --> URI Class Initialized
DEBUG - 2017-02-24 20:33:32 --> No URI present. Default controller set.
INFO - 2017-02-24 20:33:32 --> Router Class Initialized
INFO - 2017-02-24 20:33:32 --> Output Class Initialized
INFO - 2017-02-24 20:33:32 --> Security Class Initialized
DEBUG - 2017-02-24 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 20:33:32 --> Input Class Initialized
INFO - 2017-02-24 20:33:32 --> Language Class Initialized
INFO - 2017-02-24 20:33:32 --> Loader Class Initialized
INFO - 2017-02-24 20:33:32 --> Database Driver Class Initialized
INFO - 2017-02-24 20:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 20:33:33 --> Controller Class Initialized
INFO - 2017-02-24 20:33:33 --> Helper loaded: url_helper
DEBUG - 2017-02-24 20:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 20:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 20:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 20:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 20:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 20:33:33 --> Final output sent to browser
DEBUG - 2017-02-24 20:33:33 --> Total execution time: 2.0927
INFO - 2017-02-24 21:15:20 --> Config Class Initialized
INFO - 2017-02-24 21:15:20 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:15:20 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:15:20 --> Utf8 Class Initialized
INFO - 2017-02-24 21:15:20 --> URI Class Initialized
INFO - 2017-02-24 21:15:20 --> Router Class Initialized
INFO - 2017-02-24 21:15:20 --> Output Class Initialized
INFO - 2017-02-24 21:15:20 --> Security Class Initialized
DEBUG - 2017-02-24 21:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:15:20 --> Input Class Initialized
INFO - 2017-02-24 21:15:20 --> Language Class Initialized
INFO - 2017-02-24 21:15:20 --> Loader Class Initialized
INFO - 2017-02-24 21:15:21 --> Database Driver Class Initialized
INFO - 2017-02-24 21:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:15:21 --> Controller Class Initialized
INFO - 2017-02-24 21:15:21 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:15:22 --> Final output sent to browser
DEBUG - 2017-02-24 21:15:22 --> Total execution time: 2.0021
INFO - 2017-02-24 21:15:25 --> Config Class Initialized
INFO - 2017-02-24 21:15:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:15:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:15:25 --> Utf8 Class Initialized
INFO - 2017-02-24 21:15:25 --> URI Class Initialized
INFO - 2017-02-24 21:15:25 --> Router Class Initialized
INFO - 2017-02-24 21:15:25 --> Output Class Initialized
INFO - 2017-02-24 21:15:25 --> Security Class Initialized
DEBUG - 2017-02-24 21:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:15:25 --> Input Class Initialized
INFO - 2017-02-24 21:15:25 --> Language Class Initialized
INFO - 2017-02-24 21:15:25 --> Loader Class Initialized
INFO - 2017-02-24 21:15:25 --> Database Driver Class Initialized
INFO - 2017-02-24 21:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:15:25 --> Controller Class Initialized
INFO - 2017-02-24 21:15:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:15:25 --> Final output sent to browser
DEBUG - 2017-02-24 21:15:25 --> Total execution time: 0.0412
INFO - 2017-02-24 21:15:39 --> Config Class Initialized
INFO - 2017-02-24 21:15:39 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:15:39 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:15:39 --> Utf8 Class Initialized
INFO - 2017-02-24 21:15:39 --> URI Class Initialized
INFO - 2017-02-24 21:15:39 --> Router Class Initialized
INFO - 2017-02-24 21:15:39 --> Output Class Initialized
INFO - 2017-02-24 21:15:39 --> Security Class Initialized
DEBUG - 2017-02-24 21:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:15:39 --> Input Class Initialized
INFO - 2017-02-24 21:15:39 --> Language Class Initialized
INFO - 2017-02-24 21:15:39 --> Loader Class Initialized
INFO - 2017-02-24 21:15:39 --> Database Driver Class Initialized
INFO - 2017-02-24 21:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:15:39 --> Controller Class Initialized
INFO - 2017-02-24 21:15:39 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:15:40 --> Config Class Initialized
INFO - 2017-02-24 21:15:40 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:15:40 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:15:40 --> Utf8 Class Initialized
INFO - 2017-02-24 21:15:40 --> URI Class Initialized
INFO - 2017-02-24 21:15:40 --> Router Class Initialized
INFO - 2017-02-24 21:15:40 --> Output Class Initialized
INFO - 2017-02-24 21:15:40 --> Security Class Initialized
DEBUG - 2017-02-24 21:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:15:40 --> Input Class Initialized
INFO - 2017-02-24 21:15:40 --> Language Class Initialized
INFO - 2017-02-24 21:15:40 --> Loader Class Initialized
INFO - 2017-02-24 21:15:40 --> Database Driver Class Initialized
INFO - 2017-02-24 21:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:15:40 --> Controller Class Initialized
INFO - 2017-02-24 21:15:40 --> Helper loaded: date_helper
DEBUG - 2017-02-24 21:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:15:40 --> Helper loaded: url_helper
INFO - 2017-02-24 21:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-24 21:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-24 21:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-24 21:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:15:40 --> Final output sent to browser
DEBUG - 2017-02-24 21:15:40 --> Total execution time: 0.1320
INFO - 2017-02-24 21:15:41 --> Config Class Initialized
INFO - 2017-02-24 21:15:41 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:15:41 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:15:41 --> Utf8 Class Initialized
INFO - 2017-02-24 21:15:41 --> URI Class Initialized
INFO - 2017-02-24 21:15:41 --> Router Class Initialized
INFO - 2017-02-24 21:15:41 --> Output Class Initialized
INFO - 2017-02-24 21:15:41 --> Security Class Initialized
DEBUG - 2017-02-24 21:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:15:41 --> Input Class Initialized
INFO - 2017-02-24 21:15:41 --> Language Class Initialized
INFO - 2017-02-24 21:15:41 --> Loader Class Initialized
INFO - 2017-02-24 21:15:41 --> Database Driver Class Initialized
INFO - 2017-02-24 21:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:15:41 --> Controller Class Initialized
INFO - 2017-02-24 21:15:41 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:15:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:15:41 --> Final output sent to browser
DEBUG - 2017-02-24 21:15:41 --> Total execution time: 0.0144
INFO - 2017-02-24 21:16:06 --> Config Class Initialized
INFO - 2017-02-24 21:16:06 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:06 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:06 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:06 --> URI Class Initialized
INFO - 2017-02-24 21:16:06 --> Router Class Initialized
INFO - 2017-02-24 21:16:06 --> Output Class Initialized
INFO - 2017-02-24 21:16:06 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:06 --> Input Class Initialized
INFO - 2017-02-24 21:16:06 --> Language Class Initialized
INFO - 2017-02-24 21:16:07 --> Loader Class Initialized
INFO - 2017-02-24 21:16:07 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:07 --> Controller Class Initialized
INFO - 2017-02-24 21:16:07 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:07 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:07 --> Total execution time: 1.4989
INFO - 2017-02-24 21:16:10 --> Config Class Initialized
INFO - 2017-02-24 21:16:10 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:10 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:10 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:10 --> URI Class Initialized
INFO - 2017-02-24 21:16:10 --> Router Class Initialized
INFO - 2017-02-24 21:16:10 --> Output Class Initialized
INFO - 2017-02-24 21:16:10 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:10 --> Input Class Initialized
INFO - 2017-02-24 21:16:10 --> Language Class Initialized
INFO - 2017-02-24 21:16:10 --> Loader Class Initialized
INFO - 2017-02-24 21:16:10 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:10 --> Controller Class Initialized
INFO - 2017-02-24 21:16:10 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:11 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:11 --> Total execution time: 1.2338
INFO - 2017-02-24 21:16:13 --> Config Class Initialized
INFO - 2017-02-24 21:16:13 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:13 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:13 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:13 --> URI Class Initialized
INFO - 2017-02-24 21:16:13 --> Router Class Initialized
INFO - 2017-02-24 21:16:13 --> Output Class Initialized
INFO - 2017-02-24 21:16:13 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:13 --> Input Class Initialized
INFO - 2017-02-24 21:16:13 --> Language Class Initialized
INFO - 2017-02-24 21:16:13 --> Loader Class Initialized
INFO - 2017-02-24 21:16:14 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:14 --> Controller Class Initialized
INFO - 2017-02-24 21:16:14 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:14 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:14 --> Total execution time: 1.5989
INFO - 2017-02-24 21:16:16 --> Config Class Initialized
INFO - 2017-02-24 21:16:16 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:16 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:16 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:16 --> URI Class Initialized
INFO - 2017-02-24 21:16:16 --> Router Class Initialized
INFO - 2017-02-24 21:16:16 --> Output Class Initialized
INFO - 2017-02-24 21:16:16 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:16 --> Input Class Initialized
INFO - 2017-02-24 21:16:16 --> Language Class Initialized
INFO - 2017-02-24 21:16:16 --> Loader Class Initialized
INFO - 2017-02-24 21:16:16 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:16 --> Controller Class Initialized
INFO - 2017-02-24 21:16:16 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:16 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:16 --> Total execution time: 0.0165
INFO - 2017-02-24 21:16:18 --> Config Class Initialized
INFO - 2017-02-24 21:16:18 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:18 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:18 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:18 --> URI Class Initialized
INFO - 2017-02-24 21:16:18 --> Router Class Initialized
INFO - 2017-02-24 21:16:18 --> Output Class Initialized
INFO - 2017-02-24 21:16:18 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:18 --> Input Class Initialized
INFO - 2017-02-24 21:16:18 --> Language Class Initialized
INFO - 2017-02-24 21:16:18 --> Loader Class Initialized
INFO - 2017-02-24 21:16:18 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:18 --> Controller Class Initialized
INFO - 2017-02-24 21:16:18 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:18 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:18 --> Total execution time: 0.0145
INFO - 2017-02-24 21:16:19 --> Config Class Initialized
INFO - 2017-02-24 21:16:19 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:19 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:19 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:19 --> URI Class Initialized
INFO - 2017-02-24 21:16:19 --> Router Class Initialized
INFO - 2017-02-24 21:16:19 --> Output Class Initialized
INFO - 2017-02-24 21:16:19 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:19 --> Input Class Initialized
INFO - 2017-02-24 21:16:19 --> Language Class Initialized
INFO - 2017-02-24 21:16:19 --> Loader Class Initialized
INFO - 2017-02-24 21:16:19 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:19 --> Controller Class Initialized
INFO - 2017-02-24 21:16:19 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:19 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:19 --> Total execution time: 0.0197
INFO - 2017-02-24 21:16:19 --> Config Class Initialized
INFO - 2017-02-24 21:16:19 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:19 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:19 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:19 --> URI Class Initialized
INFO - 2017-02-24 21:16:19 --> Router Class Initialized
INFO - 2017-02-24 21:16:19 --> Output Class Initialized
INFO - 2017-02-24 21:16:19 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:19 --> Input Class Initialized
INFO - 2017-02-24 21:16:19 --> Language Class Initialized
INFO - 2017-02-24 21:16:19 --> Loader Class Initialized
INFO - 2017-02-24 21:16:19 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:19 --> Controller Class Initialized
INFO - 2017-02-24 21:16:19 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:19 --> Config Class Initialized
INFO - 2017-02-24 21:16:19 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:19 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:19 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:19 --> URI Class Initialized
INFO - 2017-02-24 21:16:19 --> Router Class Initialized
INFO - 2017-02-24 21:16:19 --> Output Class Initialized
INFO - 2017-02-24 21:16:19 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:19 --> Input Class Initialized
INFO - 2017-02-24 21:16:19 --> Language Class Initialized
INFO - 2017-02-24 21:16:19 --> Loader Class Initialized
INFO - 2017-02-24 21:16:19 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:19 --> Total execution time: 0.0142
INFO - 2017-02-24 21:16:20 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:20 --> Controller Class Initialized
INFO - 2017-02-24 21:16:20 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:20 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:20 --> Total execution time: 0.6097
INFO - 2017-02-24 21:16:20 --> Config Class Initialized
INFO - 2017-02-24 21:16:20 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:20 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:20 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:20 --> URI Class Initialized
INFO - 2017-02-24 21:16:20 --> Router Class Initialized
INFO - 2017-02-24 21:16:20 --> Output Class Initialized
INFO - 2017-02-24 21:16:20 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:20 --> Input Class Initialized
INFO - 2017-02-24 21:16:20 --> Language Class Initialized
INFO - 2017-02-24 21:16:20 --> Loader Class Initialized
INFO - 2017-02-24 21:16:20 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:20 --> Controller Class Initialized
INFO - 2017-02-24 21:16:20 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:20 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:20 --> Total execution time: 0.0139
INFO - 2017-02-24 21:16:20 --> Config Class Initialized
INFO - 2017-02-24 21:16:20 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:20 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:20 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:20 --> URI Class Initialized
INFO - 2017-02-24 21:16:20 --> Router Class Initialized
INFO - 2017-02-24 21:16:20 --> Output Class Initialized
INFO - 2017-02-24 21:16:20 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:20 --> Input Class Initialized
INFO - 2017-02-24 21:16:20 --> Language Class Initialized
INFO - 2017-02-24 21:16:20 --> Loader Class Initialized
INFO - 2017-02-24 21:16:20 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:20 --> Controller Class Initialized
INFO - 2017-02-24 21:16:20 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:20 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:20 --> Total execution time: 0.0138
INFO - 2017-02-24 21:16:21 --> Config Class Initialized
INFO - 2017-02-24 21:16:21 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:21 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:21 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:21 --> URI Class Initialized
INFO - 2017-02-24 21:16:21 --> Router Class Initialized
INFO - 2017-02-24 21:16:21 --> Output Class Initialized
INFO - 2017-02-24 21:16:22 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:22 --> Input Class Initialized
INFO - 2017-02-24 21:16:22 --> Language Class Initialized
INFO - 2017-02-24 21:16:22 --> Loader Class Initialized
INFO - 2017-02-24 21:16:22 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:22 --> Controller Class Initialized
INFO - 2017-02-24 21:16:22 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:22 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:22 --> Total execution time: 0.0745
INFO - 2017-02-24 21:16:22 --> Config Class Initialized
INFO - 2017-02-24 21:16:22 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:22 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:22 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:22 --> URI Class Initialized
INFO - 2017-02-24 21:16:22 --> Router Class Initialized
INFO - 2017-02-24 21:16:22 --> Output Class Initialized
INFO - 2017-02-24 21:16:22 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:22 --> Input Class Initialized
INFO - 2017-02-24 21:16:22 --> Language Class Initialized
INFO - 2017-02-24 21:16:22 --> Loader Class Initialized
INFO - 2017-02-24 21:16:22 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:22 --> Controller Class Initialized
INFO - 2017-02-24 21:16:22 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:22 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:22 --> Total execution time: 0.0235
INFO - 2017-02-24 21:16:23 --> Config Class Initialized
INFO - 2017-02-24 21:16:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:23 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:23 --> URI Class Initialized
INFO - 2017-02-24 21:16:23 --> Router Class Initialized
INFO - 2017-02-24 21:16:23 --> Output Class Initialized
INFO - 2017-02-24 21:16:23 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:23 --> Input Class Initialized
INFO - 2017-02-24 21:16:23 --> Language Class Initialized
INFO - 2017-02-24 21:16:23 --> Loader Class Initialized
INFO - 2017-02-24 21:16:23 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:23 --> Config Class Initialized
INFO - 2017-02-24 21:16:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:23 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:23 --> URI Class Initialized
INFO - 2017-02-24 21:16:23 --> Router Class Initialized
INFO - 2017-02-24 21:16:23 --> Output Class Initialized
INFO - 2017-02-24 21:16:23 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:23 --> Input Class Initialized
INFO - 2017-02-24 21:16:23 --> Language Class Initialized
INFO - 2017-02-24 21:16:23 --> Loader Class Initialized
INFO - 2017-02-24 21:16:23 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:23 --> Controller Class Initialized
INFO - 2017-02-24 21:16:23 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:23 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:23 --> Total execution time: 0.0910
INFO - 2017-02-24 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:23 --> Controller Class Initialized
INFO - 2017-02-24 21:16:23 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:23 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:23 --> Total execution time: 0.0984
INFO - 2017-02-24 21:16:23 --> Config Class Initialized
INFO - 2017-02-24 21:16:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:23 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:23 --> URI Class Initialized
INFO - 2017-02-24 21:16:23 --> Router Class Initialized
INFO - 2017-02-24 21:16:23 --> Output Class Initialized
INFO - 2017-02-24 21:16:23 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:23 --> Input Class Initialized
INFO - 2017-02-24 21:16:23 --> Language Class Initialized
INFO - 2017-02-24 21:16:23 --> Loader Class Initialized
INFO - 2017-02-24 21:16:23 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:23 --> Controller Class Initialized
INFO - 2017-02-24 21:16:23 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:23 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:23 --> Total execution time: 0.0688
INFO - 2017-02-24 21:16:23 --> Config Class Initialized
INFO - 2017-02-24 21:16:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:23 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:23 --> URI Class Initialized
DEBUG - 2017-02-24 21:16:23 --> No URI present. Default controller set.
INFO - 2017-02-24 21:16:23 --> Router Class Initialized
INFO - 2017-02-24 21:16:23 --> Output Class Initialized
INFO - 2017-02-24 21:16:23 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:23 --> Input Class Initialized
INFO - 2017-02-24 21:16:23 --> Language Class Initialized
INFO - 2017-02-24 21:16:23 --> Loader Class Initialized
INFO - 2017-02-24 21:16:23 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:23 --> Controller Class Initialized
INFO - 2017-02-24 21:16:23 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:23 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:23 --> Total execution time: 0.0138
INFO - 2017-02-24 21:16:23 --> Config Class Initialized
INFO - 2017-02-24 21:16:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:23 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:23 --> URI Class Initialized
INFO - 2017-02-24 21:16:23 --> Router Class Initialized
INFO - 2017-02-24 21:16:23 --> Output Class Initialized
INFO - 2017-02-24 21:16:23 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:23 --> Input Class Initialized
INFO - 2017-02-24 21:16:23 --> Language Class Initialized
INFO - 2017-02-24 21:16:23 --> Loader Class Initialized
INFO - 2017-02-24 21:16:23 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:23 --> Config Class Initialized
INFO - 2017-02-24 21:16:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:23 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:23 --> URI Class Initialized
INFO - 2017-02-24 21:16:23 --> Router Class Initialized
INFO - 2017-02-24 21:16:23 --> Output Class Initialized
INFO - 2017-02-24 21:16:23 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:23 --> Input Class Initialized
INFO - 2017-02-24 21:16:23 --> Language Class Initialized
INFO - 2017-02-24 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:23 --> Controller Class Initialized
INFO - 2017-02-24 21:16:23 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:23 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:23 --> Total execution time: 0.0284
INFO - 2017-02-24 21:16:23 --> Loader Class Initialized
INFO - 2017-02-24 21:16:23 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:23 --> Controller Class Initialized
INFO - 2017-02-24 21:16:23 --> Helper loaded: date_helper
DEBUG - 2017-02-24 21:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:24 --> Helper loaded: url_helper
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:24 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:24 --> Total execution time: 0.1470
INFO - 2017-02-24 21:16:24 --> Config Class Initialized
INFO - 2017-02-24 21:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:24 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:24 --> URI Class Initialized
INFO - 2017-02-24 21:16:24 --> Router Class Initialized
INFO - 2017-02-24 21:16:24 --> Output Class Initialized
INFO - 2017-02-24 21:16:24 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:24 --> Input Class Initialized
INFO - 2017-02-24 21:16:24 --> Language Class Initialized
INFO - 2017-02-24 21:16:24 --> Loader Class Initialized
INFO - 2017-02-24 21:16:24 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:24 --> Controller Class Initialized
INFO - 2017-02-24 21:16:24 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:24 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:24 --> Total execution time: 0.0139
INFO - 2017-02-24 21:16:24 --> Config Class Initialized
INFO - 2017-02-24 21:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:24 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:24 --> URI Class Initialized
INFO - 2017-02-24 21:16:24 --> Router Class Initialized
INFO - 2017-02-24 21:16:24 --> Output Class Initialized
INFO - 2017-02-24 21:16:24 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:24 --> Input Class Initialized
INFO - 2017-02-24 21:16:24 --> Language Class Initialized
INFO - 2017-02-24 21:16:24 --> Loader Class Initialized
INFO - 2017-02-24 21:16:24 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:24 --> Controller Class Initialized
INFO - 2017-02-24 21:16:24 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:24 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:24 --> Total execution time: 0.0141
INFO - 2017-02-24 21:16:24 --> Config Class Initialized
INFO - 2017-02-24 21:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:24 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:24 --> URI Class Initialized
INFO - 2017-02-24 21:16:24 --> Router Class Initialized
INFO - 2017-02-24 21:16:24 --> Output Class Initialized
INFO - 2017-02-24 21:16:24 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:24 --> Input Class Initialized
INFO - 2017-02-24 21:16:24 --> Language Class Initialized
INFO - 2017-02-24 21:16:24 --> Loader Class Initialized
INFO - 2017-02-24 21:16:24 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:24 --> Controller Class Initialized
INFO - 2017-02-24 21:16:24 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:24 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:24 --> Total execution time: 0.0146
INFO - 2017-02-24 21:16:25 --> Config Class Initialized
INFO - 2017-02-24 21:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:25 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:25 --> URI Class Initialized
INFO - 2017-02-24 21:16:25 --> Router Class Initialized
INFO - 2017-02-24 21:16:25 --> Output Class Initialized
INFO - 2017-02-24 21:16:25 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:25 --> Input Class Initialized
INFO - 2017-02-24 21:16:25 --> Config Class Initialized
INFO - 2017-02-24 21:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:25 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:25 --> URI Class Initialized
INFO - 2017-02-24 21:16:25 --> Router Class Initialized
INFO - 2017-02-24 21:16:25 --> Output Class Initialized
INFO - 2017-02-24 21:16:25 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:25 --> Input Class Initialized
INFO - 2017-02-24 21:16:25 --> Language Class Initialized
INFO - 2017-02-24 21:16:25 --> Loader Class Initialized
INFO - 2017-02-24 21:16:25 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:25 --> Language Class Initialized
INFO - 2017-02-24 21:16:25 --> Loader Class Initialized
INFO - 2017-02-24 21:16:25 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:25 --> Controller Class Initialized
INFO - 2017-02-24 21:16:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:25 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:25 --> Total execution time: 0.0189
INFO - 2017-02-24 21:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:25 --> Controller Class Initialized
INFO - 2017-02-24 21:16:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:25 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:25 --> Total execution time: 0.0916
INFO - 2017-02-24 21:16:25 --> Config Class Initialized
INFO - 2017-02-24 21:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:25 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:25 --> URI Class Initialized
INFO - 2017-02-24 21:16:25 --> Router Class Initialized
INFO - 2017-02-24 21:16:25 --> Output Class Initialized
INFO - 2017-02-24 21:16:25 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:25 --> Input Class Initialized
INFO - 2017-02-24 21:16:25 --> Language Class Initialized
INFO - 2017-02-24 21:16:25 --> Loader Class Initialized
INFO - 2017-02-24 21:16:25 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:25 --> Controller Class Initialized
INFO - 2017-02-24 21:16:25 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:25 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:25 --> Total execution time: 0.0134
INFO - 2017-02-24 21:16:25 --> Config Class Initialized
INFO - 2017-02-24 21:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:25 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:25 --> URI Class Initialized
DEBUG - 2017-02-24 21:16:25 --> No URI present. Default controller set.
INFO - 2017-02-24 21:16:25 --> Router Class Initialized
INFO - 2017-02-24 21:16:25 --> Output Class Initialized
INFO - 2017-02-24 21:16:25 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:25 --> Input Class Initialized
INFO - 2017-02-24 21:16:25 --> Language Class Initialized
INFO - 2017-02-24 21:16:25 --> Loader Class Initialized
INFO - 2017-02-24 21:16:25 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:26 --> Controller Class Initialized
INFO - 2017-02-24 21:16:26 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:26 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:26 --> Total execution time: 0.2972
INFO - 2017-02-24 21:16:26 --> Config Class Initialized
INFO - 2017-02-24 21:16:26 --> Hooks Class Initialized
DEBUG - 2017-02-24 21:16:26 --> UTF-8 Support Enabled
INFO - 2017-02-24 21:16:26 --> Utf8 Class Initialized
INFO - 2017-02-24 21:16:26 --> URI Class Initialized
INFO - 2017-02-24 21:16:26 --> Router Class Initialized
INFO - 2017-02-24 21:16:26 --> Output Class Initialized
INFO - 2017-02-24 21:16:26 --> Security Class Initialized
DEBUG - 2017-02-24 21:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 21:16:26 --> Input Class Initialized
INFO - 2017-02-24 21:16:26 --> Language Class Initialized
INFO - 2017-02-24 21:16:26 --> Loader Class Initialized
INFO - 2017-02-24 21:16:26 --> Database Driver Class Initialized
INFO - 2017-02-24 21:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 21:16:26 --> Controller Class Initialized
INFO - 2017-02-24 21:16:26 --> Helper loaded: url_helper
DEBUG - 2017-02-24 21:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 21:16:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 21:16:26 --> Final output sent to browser
DEBUG - 2017-02-24 21:16:26 --> Total execution time: 0.0146
INFO - 2017-02-24 22:57:35 --> Config Class Initialized
INFO - 2017-02-24 22:57:35 --> Hooks Class Initialized
DEBUG - 2017-02-24 22:57:35 --> UTF-8 Support Enabled
INFO - 2017-02-24 22:57:35 --> Utf8 Class Initialized
INFO - 2017-02-24 22:57:35 --> URI Class Initialized
DEBUG - 2017-02-24 22:57:35 --> No URI present. Default controller set.
INFO - 2017-02-24 22:57:35 --> Router Class Initialized
INFO - 2017-02-24 22:57:35 --> Output Class Initialized
INFO - 2017-02-24 22:57:35 --> Security Class Initialized
DEBUG - 2017-02-24 22:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 22:57:36 --> Input Class Initialized
INFO - 2017-02-24 22:57:36 --> Language Class Initialized
INFO - 2017-02-24 22:57:36 --> Loader Class Initialized
INFO - 2017-02-24 22:57:36 --> Database Driver Class Initialized
INFO - 2017-02-24 22:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 22:57:37 --> Controller Class Initialized
INFO - 2017-02-24 22:57:37 --> Helper loaded: url_helper
DEBUG - 2017-02-24 22:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 22:57:37 --> Final output sent to browser
DEBUG - 2017-02-24 22:57:37 --> Total execution time: 2.0297
INFO - 2017-02-24 23:02:00 --> Config Class Initialized
INFO - 2017-02-24 23:02:00 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:02:01 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:02:01 --> Utf8 Class Initialized
INFO - 2017-02-24 23:02:01 --> URI Class Initialized
DEBUG - 2017-02-24 23:02:01 --> No URI present. Default controller set.
INFO - 2017-02-24 23:02:01 --> Router Class Initialized
INFO - 2017-02-24 23:02:01 --> Output Class Initialized
INFO - 2017-02-24 23:02:01 --> Security Class Initialized
DEBUG - 2017-02-24 23:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:02:01 --> Input Class Initialized
INFO - 2017-02-24 23:02:01 --> Language Class Initialized
INFO - 2017-02-24 23:02:01 --> Loader Class Initialized
INFO - 2017-02-24 23:02:01 --> Database Driver Class Initialized
INFO - 2017-02-24 23:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:02:02 --> Controller Class Initialized
INFO - 2017-02-24 23:02:02 --> Helper loaded: url_helper
DEBUG - 2017-02-24 23:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 23:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 23:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 23:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 23:02:02 --> Final output sent to browser
DEBUG - 2017-02-24 23:02:02 --> Total execution time: 2.1694
INFO - 2017-02-24 23:07:00 --> Config Class Initialized
INFO - 2017-02-24 23:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:07:00 --> Utf8 Class Initialized
INFO - 2017-02-24 23:07:00 --> URI Class Initialized
INFO - 2017-02-24 23:07:00 --> Router Class Initialized
INFO - 2017-02-24 23:07:00 --> Output Class Initialized
INFO - 2017-02-24 23:07:00 --> Security Class Initialized
DEBUG - 2017-02-24 23:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:07:00 --> Input Class Initialized
INFO - 2017-02-24 23:07:00 --> Language Class Initialized
INFO - 2017-02-24 23:07:00 --> Loader Class Initialized
INFO - 2017-02-24 23:07:01 --> Database Driver Class Initialized
INFO - 2017-02-24 23:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:07:01 --> Controller Class Initialized
INFO - 2017-02-24 23:07:01 --> Helper loaded: url_helper
DEBUG - 2017-02-24 23:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 23:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 23:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 23:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 23:07:02 --> Final output sent to browser
DEBUG - 2017-02-24 23:07:02 --> Total execution time: 1.5791
INFO - 2017-02-24 23:07:32 --> Config Class Initialized
INFO - 2017-02-24 23:07:32 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:07:32 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:07:32 --> Utf8 Class Initialized
INFO - 2017-02-24 23:07:32 --> URI Class Initialized
INFO - 2017-02-24 23:07:32 --> Router Class Initialized
INFO - 2017-02-24 23:07:32 --> Output Class Initialized
INFO - 2017-02-24 23:07:32 --> Security Class Initialized
DEBUG - 2017-02-24 23:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:07:32 --> Input Class Initialized
INFO - 2017-02-24 23:07:32 --> Language Class Initialized
INFO - 2017-02-24 23:07:32 --> Loader Class Initialized
INFO - 2017-02-24 23:07:33 --> Database Driver Class Initialized
INFO - 2017-02-24 23:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:07:33 --> Controller Class Initialized
INFO - 2017-02-24 23:07:33 --> Helper loaded: url_helper
DEBUG - 2017-02-24 23:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 23:07:33 --> Final output sent to browser
DEBUG - 2017-02-24 23:07:33 --> Total execution time: 1.2398
INFO - 2017-02-24 23:09:14 --> Config Class Initialized
INFO - 2017-02-24 23:09:14 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:09:14 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:09:15 --> Utf8 Class Initialized
INFO - 2017-02-24 23:09:15 --> URI Class Initialized
DEBUG - 2017-02-24 23:09:15 --> No URI present. Default controller set.
INFO - 2017-02-24 23:09:15 --> Router Class Initialized
INFO - 2017-02-24 23:09:15 --> Output Class Initialized
INFO - 2017-02-24 23:09:15 --> Security Class Initialized
DEBUG - 2017-02-24 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:09:15 --> Input Class Initialized
INFO - 2017-02-24 23:09:15 --> Language Class Initialized
INFO - 2017-02-24 23:09:15 --> Loader Class Initialized
INFO - 2017-02-24 23:09:16 --> Database Driver Class Initialized
INFO - 2017-02-24 23:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:09:16 --> Controller Class Initialized
INFO - 2017-02-24 23:09:16 --> Helper loaded: url_helper
DEBUG - 2017-02-24 23:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 23:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 23:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 23:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 23:09:17 --> Final output sent to browser
DEBUG - 2017-02-24 23:09:17 --> Total execution time: 2.5758
INFO - 2017-02-24 23:09:27 --> Config Class Initialized
INFO - 2017-02-24 23:09:27 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:09:27 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:09:27 --> Utf8 Class Initialized
INFO - 2017-02-24 23:09:27 --> URI Class Initialized
DEBUG - 2017-02-24 23:09:27 --> No URI present. Default controller set.
INFO - 2017-02-24 23:09:27 --> Router Class Initialized
INFO - 2017-02-24 23:09:28 --> Output Class Initialized
INFO - 2017-02-24 23:09:28 --> Security Class Initialized
DEBUG - 2017-02-24 23:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:09:28 --> Input Class Initialized
INFO - 2017-02-24 23:09:28 --> Language Class Initialized
INFO - 2017-02-24 23:09:28 --> Loader Class Initialized
INFO - 2017-02-24 23:09:28 --> Database Driver Class Initialized
INFO - 2017-02-24 23:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:09:28 --> Controller Class Initialized
INFO - 2017-02-24 23:09:28 --> Helper loaded: url_helper
DEBUG - 2017-02-24 23:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 23:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 23:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 23:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 23:09:28 --> Final output sent to browser
DEBUG - 2017-02-24 23:09:28 --> Total execution time: 0.2541
INFO - 2017-02-24 23:09:46 --> Config Class Initialized
INFO - 2017-02-24 23:09:46 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:09:46 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:09:46 --> Utf8 Class Initialized
INFO - 2017-02-24 23:09:46 --> URI Class Initialized
DEBUG - 2017-02-24 23:09:46 --> No URI present. Default controller set.
INFO - 2017-02-24 23:09:46 --> Router Class Initialized
INFO - 2017-02-24 23:09:46 --> Output Class Initialized
INFO - 2017-02-24 23:09:46 --> Security Class Initialized
DEBUG - 2017-02-24 23:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:09:46 --> Input Class Initialized
INFO - 2017-02-24 23:09:46 --> Language Class Initialized
INFO - 2017-02-24 23:09:46 --> Loader Class Initialized
INFO - 2017-02-24 23:09:46 --> Database Driver Class Initialized
INFO - 2017-02-24 23:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:09:46 --> Controller Class Initialized
INFO - 2017-02-24 23:09:46 --> Helper loaded: url_helper
DEBUG - 2017-02-24 23:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 23:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-24 23:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-24 23:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 23:09:46 --> Final output sent to browser
DEBUG - 2017-02-24 23:09:46 --> Total execution time: 0.0319
INFO - 2017-02-24 23:10:02 --> Config Class Initialized
INFO - 2017-02-24 23:10:02 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:10:02 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:10:02 --> Utf8 Class Initialized
INFO - 2017-02-24 23:10:02 --> URI Class Initialized
INFO - 2017-02-24 23:10:02 --> Router Class Initialized
INFO - 2017-02-24 23:10:02 --> Output Class Initialized
INFO - 2017-02-24 23:10:02 --> Security Class Initialized
DEBUG - 2017-02-24 23:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:10:02 --> Input Class Initialized
INFO - 2017-02-24 23:10:02 --> Language Class Initialized
INFO - 2017-02-24 23:10:02 --> Loader Class Initialized
INFO - 2017-02-24 23:10:02 --> Database Driver Class Initialized
INFO - 2017-02-24 23:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:10:02 --> Controller Class Initialized
INFO - 2017-02-24 23:10:02 --> Helper loaded: url_helper
DEBUG - 2017-02-24 23:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:10:04 --> Config Class Initialized
INFO - 2017-02-24 23:10:04 --> Hooks Class Initialized
DEBUG - 2017-02-24 23:10:04 --> UTF-8 Support Enabled
INFO - 2017-02-24 23:10:04 --> Utf8 Class Initialized
INFO - 2017-02-24 23:10:04 --> URI Class Initialized
INFO - 2017-02-24 23:10:04 --> Router Class Initialized
INFO - 2017-02-24 23:10:04 --> Output Class Initialized
INFO - 2017-02-24 23:10:04 --> Security Class Initialized
DEBUG - 2017-02-24 23:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 23:10:04 --> Input Class Initialized
INFO - 2017-02-24 23:10:04 --> Language Class Initialized
INFO - 2017-02-24 23:10:04 --> Loader Class Initialized
INFO - 2017-02-24 23:10:04 --> Database Driver Class Initialized
INFO - 2017-02-24 23:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 23:10:04 --> Controller Class Initialized
INFO - 2017-02-24 23:10:04 --> Helper loaded: date_helper
DEBUG - 2017-02-24 23:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-24 23:10:04 --> Helper loaded: url_helper
INFO - 2017-02-24 23:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-24 23:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-24 23:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-24 23:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-24 23:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-24 23:10:04 --> Final output sent to browser
DEBUG - 2017-02-24 23:10:04 --> Total execution time: 0.1149

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-23 00:02:00 --> Config Class Initialized
INFO - 2017-02-23 00:02:01 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:02:01 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:02:01 --> Utf8 Class Initialized
INFO - 2017-02-23 00:02:01 --> URI Class Initialized
DEBUG - 2017-02-23 00:02:01 --> No URI present. Default controller set.
INFO - 2017-02-23 00:02:01 --> Router Class Initialized
INFO - 2017-02-23 00:02:01 --> Output Class Initialized
INFO - 2017-02-23 00:02:01 --> Security Class Initialized
DEBUG - 2017-02-23 00:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:02:01 --> Input Class Initialized
INFO - 2017-02-23 00:02:01 --> Language Class Initialized
INFO - 2017-02-23 00:02:01 --> Loader Class Initialized
INFO - 2017-02-23 00:02:01 --> Database Driver Class Initialized
INFO - 2017-02-23 00:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:02:02 --> Controller Class Initialized
INFO - 2017-02-23 00:02:02 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:02:02 --> Final output sent to browser
DEBUG - 2017-02-23 00:02:02 --> Total execution time: 1.9875
INFO - 2017-02-23 00:02:07 --> Config Class Initialized
INFO - 2017-02-23 00:02:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:02:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:02:12 --> Utf8 Class Initialized
INFO - 2017-02-23 00:02:12 --> URI Class Initialized
DEBUG - 2017-02-23 00:02:12 --> No URI present. Default controller set.
INFO - 2017-02-23 00:02:12 --> Router Class Initialized
INFO - 2017-02-23 00:02:12 --> Output Class Initialized
INFO - 2017-02-23 00:02:12 --> Security Class Initialized
DEBUG - 2017-02-23 00:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:02:12 --> Input Class Initialized
INFO - 2017-02-23 00:02:12 --> Language Class Initialized
INFO - 2017-02-23 00:02:12 --> Loader Class Initialized
INFO - 2017-02-23 00:02:12 --> Database Driver Class Initialized
INFO - 2017-02-23 00:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:02:12 --> Controller Class Initialized
INFO - 2017-02-23 00:02:12 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:02:12 --> Final output sent to browser
DEBUG - 2017-02-23 00:02:12 --> Total execution time: 5.0616
INFO - 2017-02-23 00:02:12 --> Config Class Initialized
INFO - 2017-02-23 00:02:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:02:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:02:12 --> Utf8 Class Initialized
INFO - 2017-02-23 00:02:12 --> URI Class Initialized
DEBUG - 2017-02-23 00:02:12 --> No URI present. Default controller set.
INFO - 2017-02-23 00:02:12 --> Router Class Initialized
INFO - 2017-02-23 00:02:12 --> Output Class Initialized
INFO - 2017-02-23 00:02:12 --> Security Class Initialized
DEBUG - 2017-02-23 00:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:02:12 --> Input Class Initialized
INFO - 2017-02-23 00:02:12 --> Language Class Initialized
INFO - 2017-02-23 00:02:12 --> Loader Class Initialized
INFO - 2017-02-23 00:02:12 --> Database Driver Class Initialized
INFO - 2017-02-23 00:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:02:12 --> Controller Class Initialized
INFO - 2017-02-23 00:02:12 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:02:12 --> Final output sent to browser
DEBUG - 2017-02-23 00:02:12 --> Total execution time: 0.0648
INFO - 2017-02-23 00:02:15 --> Config Class Initialized
INFO - 2017-02-23 00:02:15 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:02:15 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:02:15 --> Utf8 Class Initialized
INFO - 2017-02-23 00:02:15 --> URI Class Initialized
DEBUG - 2017-02-23 00:02:15 --> No URI present. Default controller set.
INFO - 2017-02-23 00:02:15 --> Router Class Initialized
INFO - 2017-02-23 00:02:15 --> Output Class Initialized
INFO - 2017-02-23 00:02:15 --> Security Class Initialized
DEBUG - 2017-02-23 00:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:02:15 --> Input Class Initialized
INFO - 2017-02-23 00:02:15 --> Language Class Initialized
INFO - 2017-02-23 00:02:15 --> Loader Class Initialized
INFO - 2017-02-23 00:02:15 --> Database Driver Class Initialized
INFO - 2017-02-23 00:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:02:15 --> Controller Class Initialized
INFO - 2017-02-23 00:02:15 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:02:15 --> Final output sent to browser
DEBUG - 2017-02-23 00:02:15 --> Total execution time: 0.0137
INFO - 2017-02-23 00:03:11 --> Config Class Initialized
INFO - 2017-02-23 00:03:11 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:03:11 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:03:11 --> Utf8 Class Initialized
INFO - 2017-02-23 00:03:11 --> URI Class Initialized
INFO - 2017-02-23 00:03:11 --> Router Class Initialized
INFO - 2017-02-23 00:03:11 --> Output Class Initialized
INFO - 2017-02-23 00:03:11 --> Security Class Initialized
DEBUG - 2017-02-23 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:03:11 --> Input Class Initialized
INFO - 2017-02-23 00:03:11 --> Language Class Initialized
INFO - 2017-02-23 00:03:11 --> Loader Class Initialized
INFO - 2017-02-23 00:03:11 --> Database Driver Class Initialized
INFO - 2017-02-23 00:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:03:11 --> Controller Class Initialized
INFO - 2017-02-23 00:03:11 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:03:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:03:13 --> Config Class Initialized
INFO - 2017-02-23 00:03:13 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:03:13 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:03:13 --> Utf8 Class Initialized
INFO - 2017-02-23 00:03:13 --> URI Class Initialized
INFO - 2017-02-23 00:03:13 --> Router Class Initialized
INFO - 2017-02-23 00:03:13 --> Output Class Initialized
INFO - 2017-02-23 00:03:13 --> Security Class Initialized
DEBUG - 2017-02-23 00:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:03:13 --> Input Class Initialized
INFO - 2017-02-23 00:03:13 --> Language Class Initialized
INFO - 2017-02-23 00:03:13 --> Loader Class Initialized
INFO - 2017-02-23 00:03:13 --> Database Driver Class Initialized
INFO - 2017-02-23 00:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:03:13 --> Controller Class Initialized
INFO - 2017-02-23 00:03:13 --> Helper loaded: date_helper
DEBUG - 2017-02-23 00:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:03:13 --> Helper loaded: url_helper
INFO - 2017-02-23 00:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 00:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 00:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 00:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:03:13 --> Final output sent to browser
DEBUG - 2017-02-23 00:03:13 --> Total execution time: 0.1110
INFO - 2017-02-23 00:05:00 --> Config Class Initialized
INFO - 2017-02-23 00:05:00 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:05:00 --> Utf8 Class Initialized
INFO - 2017-02-23 00:05:00 --> URI Class Initialized
DEBUG - 2017-02-23 00:05:00 --> No URI present. Default controller set.
INFO - 2017-02-23 00:05:00 --> Router Class Initialized
INFO - 2017-02-23 00:05:00 --> Output Class Initialized
INFO - 2017-02-23 00:05:00 --> Security Class Initialized
DEBUG - 2017-02-23 00:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:05:00 --> Input Class Initialized
INFO - 2017-02-23 00:05:00 --> Language Class Initialized
INFO - 2017-02-23 00:05:00 --> Loader Class Initialized
INFO - 2017-02-23 00:05:01 --> Database Driver Class Initialized
INFO - 2017-02-23 00:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:05:01 --> Controller Class Initialized
INFO - 2017-02-23 00:05:01 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:05:01 --> Final output sent to browser
DEBUG - 2017-02-23 00:05:01 --> Total execution time: 1.8806
INFO - 2017-02-23 00:08:02 --> Config Class Initialized
INFO - 2017-02-23 00:08:02 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:08:03 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:08:03 --> Utf8 Class Initialized
INFO - 2017-02-23 00:08:03 --> URI Class Initialized
INFO - 2017-02-23 00:08:03 --> Router Class Initialized
INFO - 2017-02-23 00:08:03 --> Output Class Initialized
INFO - 2017-02-23 00:08:03 --> Security Class Initialized
DEBUG - 2017-02-23 00:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:08:03 --> Input Class Initialized
INFO - 2017-02-23 00:08:03 --> Language Class Initialized
INFO - 2017-02-23 00:08:03 --> Loader Class Initialized
INFO - 2017-02-23 00:08:03 --> Database Driver Class Initialized
INFO - 2017-02-23 00:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:08:04 --> Controller Class Initialized
INFO - 2017-02-23 00:08:04 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:08:04 --> Final output sent to browser
DEBUG - 2017-02-23 00:08:04 --> Total execution time: 1.7959
INFO - 2017-02-23 00:10:14 --> Config Class Initialized
INFO - 2017-02-23 00:10:14 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:10:15 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:10:15 --> Utf8 Class Initialized
INFO - 2017-02-23 00:10:15 --> URI Class Initialized
DEBUG - 2017-02-23 00:10:15 --> No URI present. Default controller set.
INFO - 2017-02-23 00:10:15 --> Router Class Initialized
INFO - 2017-02-23 00:10:15 --> Output Class Initialized
INFO - 2017-02-23 00:10:15 --> Security Class Initialized
DEBUG - 2017-02-23 00:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:10:15 --> Input Class Initialized
INFO - 2017-02-23 00:10:15 --> Language Class Initialized
INFO - 2017-02-23 00:10:15 --> Loader Class Initialized
INFO - 2017-02-23 00:10:16 --> Database Driver Class Initialized
INFO - 2017-02-23 00:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:10:17 --> Controller Class Initialized
INFO - 2017-02-23 00:10:17 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:10:17 --> Final output sent to browser
DEBUG - 2017-02-23 00:10:17 --> Total execution time: 3.2674
INFO - 2017-02-23 00:10:21 --> Config Class Initialized
INFO - 2017-02-23 00:10:21 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:10:21 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:10:21 --> Utf8 Class Initialized
INFO - 2017-02-23 00:10:21 --> URI Class Initialized
INFO - 2017-02-23 00:10:21 --> Router Class Initialized
INFO - 2017-02-23 00:10:21 --> Output Class Initialized
INFO - 2017-02-23 00:10:21 --> Security Class Initialized
DEBUG - 2017-02-23 00:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:10:21 --> Input Class Initialized
INFO - 2017-02-23 00:10:21 --> Language Class Initialized
INFO - 2017-02-23 00:10:21 --> Loader Class Initialized
INFO - 2017-02-23 00:10:22 --> Database Driver Class Initialized
INFO - 2017-02-23 00:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:10:22 --> Controller Class Initialized
INFO - 2017-02-23 00:10:22 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:10:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:10:22 --> Final output sent to browser
DEBUG - 2017-02-23 00:10:22 --> Total execution time: 1.6235
INFO - 2017-02-23 00:11:27 --> Config Class Initialized
INFO - 2017-02-23 00:11:27 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:11:27 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:11:27 --> Utf8 Class Initialized
INFO - 2017-02-23 00:11:27 --> URI Class Initialized
INFO - 2017-02-23 00:11:27 --> Router Class Initialized
INFO - 2017-02-23 00:11:27 --> Output Class Initialized
INFO - 2017-02-23 00:11:27 --> Security Class Initialized
DEBUG - 2017-02-23 00:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:11:27 --> Input Class Initialized
INFO - 2017-02-23 00:11:27 --> Language Class Initialized
INFO - 2017-02-23 00:11:28 --> Loader Class Initialized
INFO - 2017-02-23 00:11:28 --> Database Driver Class Initialized
INFO - 2017-02-23 00:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:11:28 --> Controller Class Initialized
INFO - 2017-02-23 00:11:28 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:11:28 --> Final output sent to browser
DEBUG - 2017-02-23 00:11:28 --> Total execution time: 1.5460
INFO - 2017-02-23 00:11:30 --> Config Class Initialized
INFO - 2017-02-23 00:11:30 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:11:30 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:11:30 --> Utf8 Class Initialized
INFO - 2017-02-23 00:11:30 --> URI Class Initialized
INFO - 2017-02-23 00:11:30 --> Router Class Initialized
INFO - 2017-02-23 00:11:30 --> Output Class Initialized
INFO - 2017-02-23 00:11:30 --> Security Class Initialized
DEBUG - 2017-02-23 00:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:11:31 --> Input Class Initialized
INFO - 2017-02-23 00:11:31 --> Language Class Initialized
INFO - 2017-02-23 00:11:31 --> Loader Class Initialized
INFO - 2017-02-23 00:11:31 --> Database Driver Class Initialized
INFO - 2017-02-23 00:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:11:31 --> Controller Class Initialized
INFO - 2017-02-23 00:11:31 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:11:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:11:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:11:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:11:32 --> Final output sent to browser
DEBUG - 2017-02-23 00:11:32 --> Total execution time: 1.9144
INFO - 2017-02-23 00:11:34 --> Config Class Initialized
INFO - 2017-02-23 00:11:34 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:11:34 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:11:34 --> Utf8 Class Initialized
INFO - 2017-02-23 00:11:34 --> URI Class Initialized
DEBUG - 2017-02-23 00:11:34 --> No URI present. Default controller set.
INFO - 2017-02-23 00:11:34 --> Router Class Initialized
INFO - 2017-02-23 00:11:34 --> Output Class Initialized
INFO - 2017-02-23 00:11:34 --> Security Class Initialized
DEBUG - 2017-02-23 00:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:11:35 --> Input Class Initialized
INFO - 2017-02-23 00:11:35 --> Language Class Initialized
INFO - 2017-02-23 00:11:35 --> Loader Class Initialized
INFO - 2017-02-23 00:11:35 --> Database Driver Class Initialized
INFO - 2017-02-23 00:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:11:35 --> Controller Class Initialized
INFO - 2017-02-23 00:11:35 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:11:35 --> Final output sent to browser
DEBUG - 2017-02-23 00:11:35 --> Total execution time: 0.7622
INFO - 2017-02-23 00:11:49 --> Config Class Initialized
INFO - 2017-02-23 00:11:49 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:11:49 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:11:49 --> Utf8 Class Initialized
INFO - 2017-02-23 00:11:49 --> URI Class Initialized
INFO - 2017-02-23 00:11:49 --> Router Class Initialized
INFO - 2017-02-23 00:11:49 --> Output Class Initialized
INFO - 2017-02-23 00:11:49 --> Security Class Initialized
DEBUG - 2017-02-23 00:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:11:49 --> Input Class Initialized
INFO - 2017-02-23 00:11:49 --> Language Class Initialized
INFO - 2017-02-23 00:11:49 --> Loader Class Initialized
INFO - 2017-02-23 00:11:50 --> Database Driver Class Initialized
INFO - 2017-02-23 00:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:11:50 --> Controller Class Initialized
INFO - 2017-02-23 00:11:50 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:11:51 --> Final output sent to browser
DEBUG - 2017-02-23 00:11:51 --> Total execution time: 2.0330
INFO - 2017-02-23 00:11:53 --> Config Class Initialized
INFO - 2017-02-23 00:11:53 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:11:53 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:11:53 --> Utf8 Class Initialized
INFO - 2017-02-23 00:11:53 --> URI Class Initialized
INFO - 2017-02-23 00:11:53 --> Router Class Initialized
INFO - 2017-02-23 00:11:53 --> Output Class Initialized
INFO - 2017-02-23 00:11:53 --> Security Class Initialized
DEBUG - 2017-02-23 00:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:11:53 --> Input Class Initialized
INFO - 2017-02-23 00:11:53 --> Language Class Initialized
INFO - 2017-02-23 00:11:53 --> Loader Class Initialized
INFO - 2017-02-23 00:11:53 --> Database Driver Class Initialized
INFO - 2017-02-23 00:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:11:53 --> Controller Class Initialized
INFO - 2017-02-23 00:11:53 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:11:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:11:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:11:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:11:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:11:53 --> Final output sent to browser
DEBUG - 2017-02-23 00:11:53 --> Total execution time: 0.7865
INFO - 2017-02-23 00:12:01 --> Config Class Initialized
INFO - 2017-02-23 00:12:01 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:12:01 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:12:01 --> Utf8 Class Initialized
INFO - 2017-02-23 00:12:01 --> URI Class Initialized
INFO - 2017-02-23 00:12:01 --> Router Class Initialized
INFO - 2017-02-23 00:12:01 --> Output Class Initialized
INFO - 2017-02-23 00:12:01 --> Security Class Initialized
DEBUG - 2017-02-23 00:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:12:01 --> Input Class Initialized
INFO - 2017-02-23 00:12:01 --> Language Class Initialized
INFO - 2017-02-23 00:12:01 --> Loader Class Initialized
INFO - 2017-02-23 00:12:02 --> Database Driver Class Initialized
INFO - 2017-02-23 00:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:12:02 --> Controller Class Initialized
INFO - 2017-02-23 00:12:02 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:12:06 --> Config Class Initialized
INFO - 2017-02-23 00:12:06 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:12:06 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:12:06 --> Utf8 Class Initialized
INFO - 2017-02-23 00:12:06 --> URI Class Initialized
INFO - 2017-02-23 00:12:06 --> Router Class Initialized
INFO - 2017-02-23 00:12:06 --> Output Class Initialized
INFO - 2017-02-23 00:12:06 --> Security Class Initialized
DEBUG - 2017-02-23 00:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:12:06 --> Input Class Initialized
INFO - 2017-02-23 00:12:06 --> Language Class Initialized
INFO - 2017-02-23 00:12:06 --> Loader Class Initialized
INFO - 2017-02-23 00:12:06 --> Database Driver Class Initialized
INFO - 2017-02-23 00:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:12:06 --> Controller Class Initialized
INFO - 2017-02-23 00:12:07 --> Helper loaded: date_helper
DEBUG - 2017-02-23 00:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:12:07 --> Helper loaded: url_helper
INFO - 2017-02-23 00:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 00:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 00:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 00:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:12:07 --> Final output sent to browser
DEBUG - 2017-02-23 00:12:07 --> Total execution time: 1.8110
INFO - 2017-02-23 00:12:18 --> Config Class Initialized
INFO - 2017-02-23 00:12:18 --> Hooks Class Initialized
DEBUG - 2017-02-23 00:12:18 --> UTF-8 Support Enabled
INFO - 2017-02-23 00:12:18 --> Utf8 Class Initialized
INFO - 2017-02-23 00:12:18 --> URI Class Initialized
INFO - 2017-02-23 00:12:18 --> Router Class Initialized
INFO - 2017-02-23 00:12:18 --> Output Class Initialized
INFO - 2017-02-23 00:12:18 --> Security Class Initialized
DEBUG - 2017-02-23 00:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 00:12:18 --> Input Class Initialized
INFO - 2017-02-23 00:12:18 --> Language Class Initialized
INFO - 2017-02-23 00:12:18 --> Loader Class Initialized
INFO - 2017-02-23 00:12:19 --> Database Driver Class Initialized
INFO - 2017-02-23 00:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 00:12:19 --> Controller Class Initialized
INFO - 2017-02-23 00:12:19 --> Helper loaded: url_helper
DEBUG - 2017-02-23 00:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 00:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 00:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 00:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 00:12:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 00:12:19 --> Final output sent to browser
DEBUG - 2017-02-23 00:12:19 --> Total execution time: 1.2127
INFO - 2017-02-23 02:19:52 --> Config Class Initialized
INFO - 2017-02-23 02:19:52 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:19:52 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:19:52 --> Utf8 Class Initialized
INFO - 2017-02-23 02:19:52 --> URI Class Initialized
DEBUG - 2017-02-23 02:19:52 --> No URI present. Default controller set.
INFO - 2017-02-23 02:19:52 --> Router Class Initialized
INFO - 2017-02-23 02:19:52 --> Output Class Initialized
INFO - 2017-02-23 02:19:52 --> Security Class Initialized
DEBUG - 2017-02-23 02:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:19:52 --> Input Class Initialized
INFO - 2017-02-23 02:19:52 --> Language Class Initialized
INFO - 2017-02-23 02:19:52 --> Loader Class Initialized
INFO - 2017-02-23 02:19:52 --> Database Driver Class Initialized
INFO - 2017-02-23 02:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:19:53 --> Controller Class Initialized
INFO - 2017-02-23 02:19:53 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:19:53 --> Final output sent to browser
DEBUG - 2017-02-23 02:19:53 --> Total execution time: 1.7842
INFO - 2017-02-23 02:20:02 --> Config Class Initialized
INFO - 2017-02-23 02:20:02 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:20:02 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:20:02 --> Utf8 Class Initialized
INFO - 2017-02-23 02:20:02 --> URI Class Initialized
INFO - 2017-02-23 02:20:02 --> Router Class Initialized
INFO - 2017-02-23 02:20:03 --> Output Class Initialized
INFO - 2017-02-23 02:20:03 --> Security Class Initialized
DEBUG - 2017-02-23 02:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:20:03 --> Input Class Initialized
INFO - 2017-02-23 02:20:03 --> Language Class Initialized
INFO - 2017-02-23 02:20:03 --> Loader Class Initialized
INFO - 2017-02-23 02:20:03 --> Database Driver Class Initialized
INFO - 2017-02-23 02:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:20:03 --> Controller Class Initialized
INFO - 2017-02-23 02:20:03 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:20:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:20:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:20:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:20:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:20:03 --> Final output sent to browser
DEBUG - 2017-02-23 02:20:03 --> Total execution time: 1.5148
INFO - 2017-02-23 02:21:04 --> Config Class Initialized
INFO - 2017-02-23 02:21:04 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:21:04 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:21:05 --> Utf8 Class Initialized
INFO - 2017-02-23 02:21:05 --> URI Class Initialized
INFO - 2017-02-23 02:21:05 --> Router Class Initialized
INFO - 2017-02-23 02:21:05 --> Output Class Initialized
INFO - 2017-02-23 02:21:05 --> Security Class Initialized
DEBUG - 2017-02-23 02:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:21:05 --> Input Class Initialized
INFO - 2017-02-23 02:21:05 --> Language Class Initialized
INFO - 2017-02-23 02:21:05 --> Loader Class Initialized
INFO - 2017-02-23 02:21:05 --> Database Driver Class Initialized
INFO - 2017-02-23 02:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:21:06 --> Controller Class Initialized
INFO - 2017-02-23 02:21:06 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:21:06 --> Final output sent to browser
DEBUG - 2017-02-23 02:21:06 --> Total execution time: 1.5343
INFO - 2017-02-23 02:21:11 --> Config Class Initialized
INFO - 2017-02-23 02:21:11 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:21:11 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:21:11 --> Utf8 Class Initialized
INFO - 2017-02-23 02:21:11 --> URI Class Initialized
INFO - 2017-02-23 02:21:11 --> Router Class Initialized
INFO - 2017-02-23 02:21:11 --> Output Class Initialized
INFO - 2017-02-23 02:21:11 --> Security Class Initialized
DEBUG - 2017-02-23 02:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:21:11 --> Input Class Initialized
INFO - 2017-02-23 02:21:11 --> Language Class Initialized
INFO - 2017-02-23 02:21:11 --> Loader Class Initialized
INFO - 2017-02-23 02:21:12 --> Database Driver Class Initialized
INFO - 2017-02-23 02:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:21:12 --> Controller Class Initialized
INFO - 2017-02-23 02:21:12 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:21:12 --> Final output sent to browser
DEBUG - 2017-02-23 02:21:12 --> Total execution time: 1.2374
INFO - 2017-02-23 02:21:55 --> Config Class Initialized
INFO - 2017-02-23 02:21:55 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:21:55 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:21:55 --> Utf8 Class Initialized
INFO - 2017-02-23 02:21:55 --> URI Class Initialized
INFO - 2017-02-23 02:21:56 --> Router Class Initialized
INFO - 2017-02-23 02:21:56 --> Output Class Initialized
INFO - 2017-02-23 02:21:56 --> Security Class Initialized
DEBUG - 2017-02-23 02:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:21:56 --> Input Class Initialized
INFO - 2017-02-23 02:21:56 --> Language Class Initialized
INFO - 2017-02-23 02:21:56 --> Loader Class Initialized
INFO - 2017-02-23 02:21:56 --> Database Driver Class Initialized
INFO - 2017-02-23 02:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:21:56 --> Controller Class Initialized
INFO - 2017-02-23 02:21:56 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:21:57 --> Config Class Initialized
INFO - 2017-02-23 02:21:57 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:21:57 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:21:57 --> Utf8 Class Initialized
INFO - 2017-02-23 02:21:57 --> URI Class Initialized
INFO - 2017-02-23 02:21:57 --> Router Class Initialized
INFO - 2017-02-23 02:21:57 --> Output Class Initialized
INFO - 2017-02-23 02:21:57 --> Security Class Initialized
DEBUG - 2017-02-23 02:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:21:57 --> Input Class Initialized
INFO - 2017-02-23 02:21:57 --> Language Class Initialized
INFO - 2017-02-23 02:21:57 --> Loader Class Initialized
INFO - 2017-02-23 02:21:57 --> Database Driver Class Initialized
INFO - 2017-02-23 02:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:21:57 --> Controller Class Initialized
INFO - 2017-02-23 02:21:57 --> Helper loaded: date_helper
DEBUG - 2017-02-23 02:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:21:57 --> Helper loaded: url_helper
INFO - 2017-02-23 02:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 02:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 02:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 02:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:21:57 --> Final output sent to browser
DEBUG - 2017-02-23 02:21:57 --> Total execution time: 0.1305
INFO - 2017-02-23 02:21:59 --> Config Class Initialized
INFO - 2017-02-23 02:21:59 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:21:59 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:21:59 --> Utf8 Class Initialized
INFO - 2017-02-23 02:21:59 --> URI Class Initialized
INFO - 2017-02-23 02:21:59 --> Router Class Initialized
INFO - 2017-02-23 02:21:59 --> Output Class Initialized
INFO - 2017-02-23 02:21:59 --> Security Class Initialized
DEBUG - 2017-02-23 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:21:59 --> Input Class Initialized
INFO - 2017-02-23 02:21:59 --> Language Class Initialized
INFO - 2017-02-23 02:21:59 --> Loader Class Initialized
INFO - 2017-02-23 02:21:59 --> Database Driver Class Initialized
INFO - 2017-02-23 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:21:59 --> Controller Class Initialized
INFO - 2017-02-23 02:21:59 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:21:59 --> Final output sent to browser
DEBUG - 2017-02-23 02:21:59 --> Total execution time: 0.0560
INFO - 2017-02-23 02:22:12 --> Config Class Initialized
INFO - 2017-02-23 02:22:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:12 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:12 --> URI Class Initialized
DEBUG - 2017-02-23 02:22:12 --> No URI present. Default controller set.
INFO - 2017-02-23 02:22:12 --> Router Class Initialized
INFO - 2017-02-23 02:22:12 --> Output Class Initialized
INFO - 2017-02-23 02:22:12 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:12 --> Input Class Initialized
INFO - 2017-02-23 02:22:12 --> Language Class Initialized
INFO - 2017-02-23 02:22:12 --> Loader Class Initialized
INFO - 2017-02-23 02:22:12 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:12 --> Controller Class Initialized
INFO - 2017-02-23 02:22:12 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:12 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:12 --> Total execution time: 0.0135
INFO - 2017-02-23 02:22:13 --> Config Class Initialized
INFO - 2017-02-23 02:22:13 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:13 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:13 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:13 --> URI Class Initialized
INFO - 2017-02-23 02:22:13 --> Router Class Initialized
INFO - 2017-02-23 02:22:13 --> Output Class Initialized
INFO - 2017-02-23 02:22:13 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:13 --> Input Class Initialized
INFO - 2017-02-23 02:22:13 --> Language Class Initialized
INFO - 2017-02-23 02:22:13 --> Loader Class Initialized
INFO - 2017-02-23 02:22:13 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:13 --> Controller Class Initialized
INFO - 2017-02-23 02:22:13 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:13 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:13 --> Total execution time: 0.0133
INFO - 2017-02-23 02:22:32 --> Config Class Initialized
INFO - 2017-02-23 02:22:32 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:32 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:32 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:32 --> URI Class Initialized
INFO - 2017-02-23 02:22:32 --> Router Class Initialized
INFO - 2017-02-23 02:22:32 --> Output Class Initialized
INFO - 2017-02-23 02:22:32 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:32 --> Input Class Initialized
INFO - 2017-02-23 02:22:32 --> Language Class Initialized
INFO - 2017-02-23 02:22:32 --> Loader Class Initialized
INFO - 2017-02-23 02:22:32 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:32 --> Controller Class Initialized
INFO - 2017-02-23 02:22:32 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:32 --> Config Class Initialized
INFO - 2017-02-23 02:22:32 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:32 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:32 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:32 --> URI Class Initialized
INFO - 2017-02-23 02:22:32 --> Router Class Initialized
INFO - 2017-02-23 02:22:32 --> Output Class Initialized
INFO - 2017-02-23 02:22:32 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:32 --> Input Class Initialized
INFO - 2017-02-23 02:22:32 --> Language Class Initialized
INFO - 2017-02-23 02:22:32 --> Loader Class Initialized
INFO - 2017-02-23 02:22:32 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:32 --> Controller Class Initialized
INFO - 2017-02-23 02:22:32 --> Helper loaded: date_helper
DEBUG - 2017-02-23 02:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:32 --> Helper loaded: url_helper
INFO - 2017-02-23 02:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 02:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 02:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 02:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:32 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:32 --> Total execution time: 0.0159
INFO - 2017-02-23 02:22:33 --> Config Class Initialized
INFO - 2017-02-23 02:22:33 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:33 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:33 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:33 --> URI Class Initialized
INFO - 2017-02-23 02:22:33 --> Router Class Initialized
INFO - 2017-02-23 02:22:33 --> Output Class Initialized
INFO - 2017-02-23 02:22:33 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:33 --> Input Class Initialized
INFO - 2017-02-23 02:22:33 --> Language Class Initialized
INFO - 2017-02-23 02:22:33 --> Loader Class Initialized
INFO - 2017-02-23 02:22:33 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:33 --> Controller Class Initialized
INFO - 2017-02-23 02:22:33 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:33 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:33 --> Total execution time: 0.0146
INFO - 2017-02-23 02:22:36 --> Config Class Initialized
INFO - 2017-02-23 02:22:36 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:36 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:36 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:36 --> URI Class Initialized
DEBUG - 2017-02-23 02:22:36 --> No URI present. Default controller set.
INFO - 2017-02-23 02:22:36 --> Router Class Initialized
INFO - 2017-02-23 02:22:36 --> Output Class Initialized
INFO - 2017-02-23 02:22:36 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:36 --> Input Class Initialized
INFO - 2017-02-23 02:22:36 --> Language Class Initialized
INFO - 2017-02-23 02:22:36 --> Loader Class Initialized
INFO - 2017-02-23 02:22:36 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:36 --> Controller Class Initialized
INFO - 2017-02-23 02:22:36 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:36 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:36 --> Total execution time: 0.0160
INFO - 2017-02-23 02:22:37 --> Config Class Initialized
INFO - 2017-02-23 02:22:37 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:37 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:37 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:37 --> URI Class Initialized
INFO - 2017-02-23 02:22:37 --> Router Class Initialized
INFO - 2017-02-23 02:22:37 --> Output Class Initialized
INFO - 2017-02-23 02:22:37 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:37 --> Input Class Initialized
INFO - 2017-02-23 02:22:37 --> Language Class Initialized
INFO - 2017-02-23 02:22:37 --> Loader Class Initialized
INFO - 2017-02-23 02:22:37 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:37 --> Controller Class Initialized
INFO - 2017-02-23 02:22:37 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:37 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:37 --> Total execution time: 0.0147
INFO - 2017-02-23 02:22:46 --> Config Class Initialized
INFO - 2017-02-23 02:22:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:46 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:46 --> URI Class Initialized
INFO - 2017-02-23 02:22:46 --> Router Class Initialized
INFO - 2017-02-23 02:22:46 --> Output Class Initialized
INFO - 2017-02-23 02:22:46 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:46 --> Input Class Initialized
INFO - 2017-02-23 02:22:46 --> Language Class Initialized
INFO - 2017-02-23 02:22:46 --> Loader Class Initialized
INFO - 2017-02-23 02:22:46 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:46 --> Controller Class Initialized
INFO - 2017-02-23 02:22:46 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:46 --> Config Class Initialized
INFO - 2017-02-23 02:22:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:46 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:46 --> URI Class Initialized
INFO - 2017-02-23 02:22:46 --> Router Class Initialized
INFO - 2017-02-23 02:22:46 --> Output Class Initialized
INFO - 2017-02-23 02:22:46 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:46 --> Input Class Initialized
INFO - 2017-02-23 02:22:46 --> Language Class Initialized
INFO - 2017-02-23 02:22:46 --> Loader Class Initialized
INFO - 2017-02-23 02:22:46 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:46 --> Controller Class Initialized
INFO - 2017-02-23 02:22:46 --> Helper loaded: date_helper
DEBUG - 2017-02-23 02:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:46 --> Helper loaded: url_helper
INFO - 2017-02-23 02:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 02:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 02:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 02:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:46 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:46 --> Total execution time: 0.0140
INFO - 2017-02-23 02:22:48 --> Config Class Initialized
INFO - 2017-02-23 02:22:48 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:48 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:48 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:48 --> URI Class Initialized
INFO - 2017-02-23 02:22:48 --> Router Class Initialized
INFO - 2017-02-23 02:22:48 --> Output Class Initialized
INFO - 2017-02-23 02:22:48 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:48 --> Input Class Initialized
INFO - 2017-02-23 02:22:48 --> Language Class Initialized
INFO - 2017-02-23 02:22:48 --> Loader Class Initialized
INFO - 2017-02-23 02:22:48 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:48 --> Controller Class Initialized
INFO - 2017-02-23 02:22:48 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:48 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:48 --> Total execution time: 0.0136
INFO - 2017-02-23 02:22:58 --> Config Class Initialized
INFO - 2017-02-23 02:22:58 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:58 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:58 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:58 --> URI Class Initialized
DEBUG - 2017-02-23 02:22:58 --> No URI present. Default controller set.
INFO - 2017-02-23 02:22:58 --> Router Class Initialized
INFO - 2017-02-23 02:22:58 --> Output Class Initialized
INFO - 2017-02-23 02:22:58 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:58 --> Input Class Initialized
INFO - 2017-02-23 02:22:58 --> Language Class Initialized
INFO - 2017-02-23 02:22:58 --> Loader Class Initialized
INFO - 2017-02-23 02:22:58 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:58 --> Controller Class Initialized
INFO - 2017-02-23 02:22:58 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:58 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:58 --> Total execution time: 0.0143
INFO - 2017-02-23 02:22:59 --> Config Class Initialized
INFO - 2017-02-23 02:22:59 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:22:59 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:22:59 --> Utf8 Class Initialized
INFO - 2017-02-23 02:22:59 --> URI Class Initialized
INFO - 2017-02-23 02:22:59 --> Router Class Initialized
INFO - 2017-02-23 02:22:59 --> Output Class Initialized
INFO - 2017-02-23 02:22:59 --> Security Class Initialized
DEBUG - 2017-02-23 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:22:59 --> Input Class Initialized
INFO - 2017-02-23 02:22:59 --> Language Class Initialized
INFO - 2017-02-23 02:22:59 --> Loader Class Initialized
INFO - 2017-02-23 02:22:59 --> Database Driver Class Initialized
INFO - 2017-02-23 02:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:22:59 --> Controller Class Initialized
INFO - 2017-02-23 02:22:59 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:22:59 --> Final output sent to browser
DEBUG - 2017-02-23 02:22:59 --> Total execution time: 0.0145
INFO - 2017-02-23 02:23:16 --> Config Class Initialized
INFO - 2017-02-23 02:23:16 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:23:16 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:23:16 --> Utf8 Class Initialized
INFO - 2017-02-23 02:23:16 --> URI Class Initialized
INFO - 2017-02-23 02:23:16 --> Router Class Initialized
INFO - 2017-02-23 02:23:16 --> Output Class Initialized
INFO - 2017-02-23 02:23:16 --> Security Class Initialized
DEBUG - 2017-02-23 02:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:23:16 --> Input Class Initialized
INFO - 2017-02-23 02:23:16 --> Language Class Initialized
INFO - 2017-02-23 02:23:16 --> Loader Class Initialized
INFO - 2017-02-23 02:23:16 --> Database Driver Class Initialized
INFO - 2017-02-23 02:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:23:16 --> Controller Class Initialized
INFO - 2017-02-23 02:23:16 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-23 02:23:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-23 02:23:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-23 02:23:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-23 02:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:23:17 --> Final output sent to browser
DEBUG - 2017-02-23 02:23:17 --> Total execution time: 0.5372
INFO - 2017-02-23 02:23:19 --> Config Class Initialized
INFO - 2017-02-23 02:23:19 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:23:19 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:23:19 --> Utf8 Class Initialized
INFO - 2017-02-23 02:23:19 --> URI Class Initialized
INFO - 2017-02-23 02:23:19 --> Router Class Initialized
INFO - 2017-02-23 02:23:19 --> Output Class Initialized
INFO - 2017-02-23 02:23:19 --> Security Class Initialized
DEBUG - 2017-02-23 02:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:23:19 --> Input Class Initialized
INFO - 2017-02-23 02:23:19 --> Language Class Initialized
INFO - 2017-02-23 02:23:19 --> Loader Class Initialized
INFO - 2017-02-23 02:23:19 --> Database Driver Class Initialized
INFO - 2017-02-23 02:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:23:19 --> Controller Class Initialized
INFO - 2017-02-23 02:23:19 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:23:19 --> Final output sent to browser
DEBUG - 2017-02-23 02:23:19 --> Total execution time: 0.0143
INFO - 2017-02-23 02:23:48 --> Config Class Initialized
INFO - 2017-02-23 02:23:48 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:23:48 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:23:48 --> Utf8 Class Initialized
INFO - 2017-02-23 02:23:48 --> URI Class Initialized
INFO - 2017-02-23 02:23:48 --> Router Class Initialized
INFO - 2017-02-23 02:23:48 --> Output Class Initialized
INFO - 2017-02-23 02:23:48 --> Security Class Initialized
DEBUG - 2017-02-23 02:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:23:49 --> Input Class Initialized
INFO - 2017-02-23 02:23:49 --> Language Class Initialized
INFO - 2017-02-23 02:23:49 --> Loader Class Initialized
INFO - 2017-02-23 02:23:49 --> Database Driver Class Initialized
INFO - 2017-02-23 02:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:23:49 --> Controller Class Initialized
INFO - 2017-02-23 02:23:49 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-23 02:23:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-23 02:23:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-23 02:23:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-23 02:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:23:50 --> Final output sent to browser
DEBUG - 2017-02-23 02:23:50 --> Total execution time: 1.5960
INFO - 2017-02-23 02:24:49 --> Config Class Initialized
INFO - 2017-02-23 02:24:49 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:24:49 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:24:49 --> Utf8 Class Initialized
INFO - 2017-02-23 02:24:49 --> URI Class Initialized
INFO - 2017-02-23 02:24:49 --> Router Class Initialized
INFO - 2017-02-23 02:24:49 --> Output Class Initialized
INFO - 2017-02-23 02:24:49 --> Security Class Initialized
DEBUG - 2017-02-23 02:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:24:50 --> Input Class Initialized
INFO - 2017-02-23 02:24:50 --> Language Class Initialized
INFO - 2017-02-23 02:24:50 --> Loader Class Initialized
INFO - 2017-02-23 02:24:50 --> Database Driver Class Initialized
INFO - 2017-02-23 02:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:24:50 --> Controller Class Initialized
INFO - 2017-02-23 02:24:50 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-23 02:24:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-23 02:24:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-23 02:24:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-23 02:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:24:50 --> Final output sent to browser
DEBUG - 2017-02-23 02:24:50 --> Total execution time: 1.4864
INFO - 2017-02-23 02:24:56 --> Config Class Initialized
INFO - 2017-02-23 02:24:56 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:24:56 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:24:56 --> Utf8 Class Initialized
INFO - 2017-02-23 02:24:56 --> URI Class Initialized
INFO - 2017-02-23 02:24:56 --> Router Class Initialized
INFO - 2017-02-23 02:24:56 --> Output Class Initialized
INFO - 2017-02-23 02:24:56 --> Security Class Initialized
DEBUG - 2017-02-23 02:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:24:56 --> Input Class Initialized
INFO - 2017-02-23 02:24:56 --> Language Class Initialized
INFO - 2017-02-23 02:24:56 --> Loader Class Initialized
INFO - 2017-02-23 02:24:56 --> Database Driver Class Initialized
INFO - 2017-02-23 02:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:24:57 --> Controller Class Initialized
INFO - 2017-02-23 02:24:57 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-23 02:24:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-23 02:24:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-23 02:24:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-23 02:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:24:57 --> Final output sent to browser
DEBUG - 2017-02-23 02:24:57 --> Total execution time: 0.2889
INFO - 2017-02-23 02:24:59 --> Config Class Initialized
INFO - 2017-02-23 02:24:59 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:24:59 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:24:59 --> Utf8 Class Initialized
INFO - 2017-02-23 02:24:59 --> URI Class Initialized
INFO - 2017-02-23 02:24:59 --> Router Class Initialized
INFO - 2017-02-23 02:24:59 --> Output Class Initialized
INFO - 2017-02-23 02:24:59 --> Security Class Initialized
DEBUG - 2017-02-23 02:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:24:59 --> Input Class Initialized
INFO - 2017-02-23 02:24:59 --> Language Class Initialized
INFO - 2017-02-23 02:24:59 --> Loader Class Initialized
INFO - 2017-02-23 02:24:59 --> Database Driver Class Initialized
INFO - 2017-02-23 02:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:24:59 --> Controller Class Initialized
INFO - 2017-02-23 02:24:59 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:24:59 --> Final output sent to browser
DEBUG - 2017-02-23 02:24:59 --> Total execution time: 0.0204
INFO - 2017-02-23 02:25:38 --> Config Class Initialized
INFO - 2017-02-23 02:25:38 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:25:38 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:25:38 --> Utf8 Class Initialized
INFO - 2017-02-23 02:25:38 --> URI Class Initialized
INFO - 2017-02-23 02:25:38 --> Router Class Initialized
INFO - 2017-02-23 02:25:38 --> Output Class Initialized
INFO - 2017-02-23 02:25:38 --> Security Class Initialized
DEBUG - 2017-02-23 02:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:25:38 --> Input Class Initialized
INFO - 2017-02-23 02:25:38 --> Language Class Initialized
INFO - 2017-02-23 02:25:38 --> Loader Class Initialized
INFO - 2017-02-23 02:25:38 --> Database Driver Class Initialized
INFO - 2017-02-23 02:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:25:38 --> Controller Class Initialized
INFO - 2017-02-23 02:25:38 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:25:38 --> Final output sent to browser
DEBUG - 2017-02-23 02:25:38 --> Total execution time: 0.0303
INFO - 2017-02-23 02:25:40 --> Config Class Initialized
INFO - 2017-02-23 02:25:40 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:25:40 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:25:40 --> Utf8 Class Initialized
INFO - 2017-02-23 02:25:40 --> URI Class Initialized
INFO - 2017-02-23 02:25:40 --> Router Class Initialized
INFO - 2017-02-23 02:25:40 --> Output Class Initialized
INFO - 2017-02-23 02:25:40 --> Security Class Initialized
DEBUG - 2017-02-23 02:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:25:40 --> Input Class Initialized
INFO - 2017-02-23 02:25:40 --> Language Class Initialized
INFO - 2017-02-23 02:25:40 --> Loader Class Initialized
INFO - 2017-02-23 02:25:40 --> Database Driver Class Initialized
INFO - 2017-02-23 02:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:25:40 --> Controller Class Initialized
INFO - 2017-02-23 02:25:40 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:25:40 --> Final output sent to browser
DEBUG - 2017-02-23 02:25:40 --> Total execution time: 0.0148
INFO - 2017-02-23 02:25:52 --> Config Class Initialized
INFO - 2017-02-23 02:25:52 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:25:52 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:25:52 --> Utf8 Class Initialized
INFO - 2017-02-23 02:25:52 --> URI Class Initialized
INFO - 2017-02-23 02:25:52 --> Router Class Initialized
INFO - 2017-02-23 02:25:52 --> Output Class Initialized
INFO - 2017-02-23 02:25:52 --> Security Class Initialized
DEBUG - 2017-02-23 02:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:25:52 --> Input Class Initialized
INFO - 2017-02-23 02:25:52 --> Language Class Initialized
INFO - 2017-02-23 02:25:52 --> Loader Class Initialized
INFO - 2017-02-23 02:25:52 --> Database Driver Class Initialized
INFO - 2017-02-23 02:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:25:52 --> Controller Class Initialized
INFO - 2017-02-23 02:25:52 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:25:53 --> Config Class Initialized
INFO - 2017-02-23 02:25:53 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:25:53 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:25:53 --> Utf8 Class Initialized
INFO - 2017-02-23 02:25:53 --> URI Class Initialized
INFO - 2017-02-23 02:25:53 --> Router Class Initialized
INFO - 2017-02-23 02:25:53 --> Output Class Initialized
INFO - 2017-02-23 02:25:53 --> Security Class Initialized
DEBUG - 2017-02-23 02:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:25:53 --> Input Class Initialized
INFO - 2017-02-23 02:25:53 --> Language Class Initialized
INFO - 2017-02-23 02:25:53 --> Loader Class Initialized
INFO - 2017-02-23 02:25:53 --> Database Driver Class Initialized
INFO - 2017-02-23 02:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:25:53 --> Controller Class Initialized
INFO - 2017-02-23 02:25:53 --> Helper loaded: date_helper
DEBUG - 2017-02-23 02:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:25:53 --> Helper loaded: url_helper
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:25:53 --> Final output sent to browser
DEBUG - 2017-02-23 02:25:53 --> Total execution time: 0.1017
INFO - 2017-02-23 02:25:53 --> Config Class Initialized
INFO - 2017-02-23 02:25:53 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:25:53 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:25:53 --> Utf8 Class Initialized
INFO - 2017-02-23 02:25:53 --> URI Class Initialized
INFO - 2017-02-23 02:25:53 --> Router Class Initialized
INFO - 2017-02-23 02:25:53 --> Output Class Initialized
INFO - 2017-02-23 02:25:53 --> Security Class Initialized
DEBUG - 2017-02-23 02:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:25:53 --> Input Class Initialized
INFO - 2017-02-23 02:25:53 --> Language Class Initialized
INFO - 2017-02-23 02:25:53 --> Loader Class Initialized
INFO - 2017-02-23 02:25:53 --> Database Driver Class Initialized
INFO - 2017-02-23 02:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:25:53 --> Controller Class Initialized
INFO - 2017-02-23 02:25:53 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:25:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:25:53 --> Final output sent to browser
DEBUG - 2017-02-23 02:25:53 --> Total execution time: 0.0141
INFO - 2017-02-23 02:26:12 --> Config Class Initialized
INFO - 2017-02-23 02:26:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:26:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:26:12 --> Utf8 Class Initialized
INFO - 2017-02-23 02:26:12 --> URI Class Initialized
INFO - 2017-02-23 02:26:12 --> Router Class Initialized
INFO - 2017-02-23 02:26:12 --> Output Class Initialized
INFO - 2017-02-23 02:26:12 --> Security Class Initialized
DEBUG - 2017-02-23 02:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:26:12 --> Input Class Initialized
INFO - 2017-02-23 02:26:12 --> Language Class Initialized
INFO - 2017-02-23 02:26:12 --> Loader Class Initialized
INFO - 2017-02-23 02:26:12 --> Database Driver Class Initialized
INFO - 2017-02-23 02:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:26:12 --> Controller Class Initialized
INFO - 2017-02-23 02:26:12 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-23 02:26:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-23 02:26:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-23 02:26:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-23 02:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:26:12 --> Final output sent to browser
DEBUG - 2017-02-23 02:26:12 --> Total execution time: 0.0143
INFO - 2017-02-23 02:26:13 --> Config Class Initialized
INFO - 2017-02-23 02:26:13 --> Hooks Class Initialized
DEBUG - 2017-02-23 02:26:13 --> UTF-8 Support Enabled
INFO - 2017-02-23 02:26:13 --> Utf8 Class Initialized
INFO - 2017-02-23 02:26:13 --> URI Class Initialized
INFO - 2017-02-23 02:26:13 --> Router Class Initialized
INFO - 2017-02-23 02:26:13 --> Output Class Initialized
INFO - 2017-02-23 02:26:13 --> Security Class Initialized
DEBUG - 2017-02-23 02:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 02:26:13 --> Input Class Initialized
INFO - 2017-02-23 02:26:13 --> Language Class Initialized
INFO - 2017-02-23 02:26:13 --> Loader Class Initialized
INFO - 2017-02-23 02:26:13 --> Database Driver Class Initialized
INFO - 2017-02-23 02:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 02:26:13 --> Controller Class Initialized
INFO - 2017-02-23 02:26:13 --> Helper loaded: url_helper
DEBUG - 2017-02-23 02:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 02:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 02:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 02:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 02:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 02:26:13 --> Final output sent to browser
DEBUG - 2017-02-23 02:26:13 --> Total execution time: 0.0141
INFO - 2017-02-23 03:39:24 --> Config Class Initialized
INFO - 2017-02-23 03:39:24 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:39:25 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:39:25 --> Utf8 Class Initialized
INFO - 2017-02-23 03:39:25 --> URI Class Initialized
DEBUG - 2017-02-23 03:39:25 --> No URI present. Default controller set.
INFO - 2017-02-23 03:39:25 --> Router Class Initialized
INFO - 2017-02-23 03:39:25 --> Output Class Initialized
INFO - 2017-02-23 03:39:25 --> Security Class Initialized
DEBUG - 2017-02-23 03:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:39:25 --> Input Class Initialized
INFO - 2017-02-23 03:39:25 --> Language Class Initialized
INFO - 2017-02-23 03:39:25 --> Loader Class Initialized
INFO - 2017-02-23 03:39:25 --> Database Driver Class Initialized
INFO - 2017-02-23 03:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:39:26 --> Controller Class Initialized
INFO - 2017-02-23 03:39:26 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:39:26 --> Final output sent to browser
DEBUG - 2017-02-23 03:39:26 --> Total execution time: 1.7536
INFO - 2017-02-23 03:39:39 --> Config Class Initialized
INFO - 2017-02-23 03:39:39 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:39:39 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:39:39 --> Utf8 Class Initialized
INFO - 2017-02-23 03:39:39 --> URI Class Initialized
DEBUG - 2017-02-23 03:39:39 --> No URI present. Default controller set.
INFO - 2017-02-23 03:39:39 --> Router Class Initialized
INFO - 2017-02-23 03:39:39 --> Output Class Initialized
INFO - 2017-02-23 03:39:39 --> Security Class Initialized
DEBUG - 2017-02-23 03:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:39:39 --> Input Class Initialized
INFO - 2017-02-23 03:39:39 --> Language Class Initialized
INFO - 2017-02-23 03:39:39 --> Loader Class Initialized
INFO - 2017-02-23 03:39:39 --> Database Driver Class Initialized
INFO - 2017-02-23 03:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:39:39 --> Controller Class Initialized
INFO - 2017-02-23 03:39:39 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:39:39 --> Final output sent to browser
DEBUG - 2017-02-23 03:39:39 --> Total execution time: 0.0139
INFO - 2017-02-23 03:39:45 --> Config Class Initialized
INFO - 2017-02-23 03:39:45 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:39:45 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:39:45 --> Utf8 Class Initialized
INFO - 2017-02-23 03:39:45 --> URI Class Initialized
INFO - 2017-02-23 03:39:45 --> Router Class Initialized
INFO - 2017-02-23 03:39:45 --> Output Class Initialized
INFO - 2017-02-23 03:39:45 --> Security Class Initialized
DEBUG - 2017-02-23 03:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:39:45 --> Input Class Initialized
INFO - 2017-02-23 03:39:45 --> Language Class Initialized
INFO - 2017-02-23 03:39:45 --> Loader Class Initialized
INFO - 2017-02-23 03:39:45 --> Database Driver Class Initialized
INFO - 2017-02-23 03:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:39:45 --> Controller Class Initialized
INFO - 2017-02-23 03:39:45 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:39:45 --> Final output sent to browser
DEBUG - 2017-02-23 03:39:45 --> Total execution time: 0.0141
INFO - 2017-02-23 03:39:48 --> Config Class Initialized
INFO - 2017-02-23 03:39:48 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:39:48 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:39:48 --> Utf8 Class Initialized
INFO - 2017-02-23 03:39:48 --> URI Class Initialized
INFO - 2017-02-23 03:39:48 --> Router Class Initialized
INFO - 2017-02-23 03:39:48 --> Output Class Initialized
INFO - 2017-02-23 03:39:48 --> Security Class Initialized
DEBUG - 2017-02-23 03:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:39:48 --> Input Class Initialized
INFO - 2017-02-23 03:39:48 --> Language Class Initialized
INFO - 2017-02-23 03:39:48 --> Loader Class Initialized
INFO - 2017-02-23 03:39:48 --> Database Driver Class Initialized
INFO - 2017-02-23 03:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:39:48 --> Controller Class Initialized
INFO - 2017-02-23 03:39:48 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:39:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:39:50 --> Config Class Initialized
INFO - 2017-02-23 03:39:50 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:39:50 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:39:50 --> Utf8 Class Initialized
INFO - 2017-02-23 03:39:50 --> URI Class Initialized
INFO - 2017-02-23 03:39:50 --> Router Class Initialized
INFO - 2017-02-23 03:39:50 --> Output Class Initialized
INFO - 2017-02-23 03:39:50 --> Security Class Initialized
DEBUG - 2017-02-23 03:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:39:50 --> Input Class Initialized
INFO - 2017-02-23 03:39:50 --> Language Class Initialized
INFO - 2017-02-23 03:39:50 --> Loader Class Initialized
INFO - 2017-02-23 03:39:50 --> Database Driver Class Initialized
INFO - 2017-02-23 03:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:39:50 --> Controller Class Initialized
INFO - 2017-02-23 03:39:50 --> Helper loaded: date_helper
DEBUG - 2017-02-23 03:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:39:50 --> Helper loaded: url_helper
INFO - 2017-02-23 03:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 03:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 03:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 03:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:39:50 --> Final output sent to browser
DEBUG - 2017-02-23 03:39:50 --> Total execution time: 0.1076
INFO - 2017-02-23 03:39:51 --> Config Class Initialized
INFO - 2017-02-23 03:39:51 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:39:51 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:39:51 --> Utf8 Class Initialized
INFO - 2017-02-23 03:39:51 --> URI Class Initialized
INFO - 2017-02-23 03:39:51 --> Router Class Initialized
INFO - 2017-02-23 03:39:51 --> Output Class Initialized
INFO - 2017-02-23 03:39:51 --> Security Class Initialized
DEBUG - 2017-02-23 03:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:39:51 --> Input Class Initialized
INFO - 2017-02-23 03:39:51 --> Language Class Initialized
INFO - 2017-02-23 03:39:51 --> Loader Class Initialized
INFO - 2017-02-23 03:39:51 --> Database Driver Class Initialized
INFO - 2017-02-23 03:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:39:51 --> Controller Class Initialized
INFO - 2017-02-23 03:39:51 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:39:51 --> Final output sent to browser
DEBUG - 2017-02-23 03:39:51 --> Total execution time: 0.0163
INFO - 2017-02-23 03:40:01 --> Config Class Initialized
INFO - 2017-02-23 03:40:01 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:40:01 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:40:01 --> Utf8 Class Initialized
INFO - 2017-02-23 03:40:01 --> URI Class Initialized
INFO - 2017-02-23 03:40:01 --> Router Class Initialized
INFO - 2017-02-23 03:40:01 --> Output Class Initialized
INFO - 2017-02-23 03:40:01 --> Security Class Initialized
DEBUG - 2017-02-23 03:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:40:01 --> Input Class Initialized
INFO - 2017-02-23 03:40:01 --> Language Class Initialized
INFO - 2017-02-23 03:40:01 --> Loader Class Initialized
INFO - 2017-02-23 03:40:01 --> Database Driver Class Initialized
INFO - 2017-02-23 03:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:40:01 --> Controller Class Initialized
INFO - 2017-02-23 03:40:01 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:40:02 --> Config Class Initialized
INFO - 2017-02-23 03:40:02 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:40:02 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:40:02 --> Utf8 Class Initialized
INFO - 2017-02-23 03:40:02 --> URI Class Initialized
INFO - 2017-02-23 03:40:02 --> Router Class Initialized
INFO - 2017-02-23 03:40:02 --> Output Class Initialized
INFO - 2017-02-23 03:40:02 --> Security Class Initialized
DEBUG - 2017-02-23 03:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:40:02 --> Input Class Initialized
INFO - 2017-02-23 03:40:02 --> Language Class Initialized
INFO - 2017-02-23 03:40:02 --> Loader Class Initialized
INFO - 2017-02-23 03:40:02 --> Database Driver Class Initialized
INFO - 2017-02-23 03:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:40:02 --> Controller Class Initialized
INFO - 2017-02-23 03:40:02 --> Helper loaded: date_helper
DEBUG - 2017-02-23 03:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:40:02 --> Helper loaded: url_helper
INFO - 2017-02-23 03:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 03:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 03:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 03:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:40:02 --> Final output sent to browser
DEBUG - 2017-02-23 03:40:02 --> Total execution time: 0.0154
INFO - 2017-02-23 03:40:03 --> Config Class Initialized
INFO - 2017-02-23 03:40:03 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:40:03 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:40:03 --> Utf8 Class Initialized
INFO - 2017-02-23 03:40:03 --> URI Class Initialized
INFO - 2017-02-23 03:40:03 --> Router Class Initialized
INFO - 2017-02-23 03:40:03 --> Output Class Initialized
INFO - 2017-02-23 03:40:03 --> Security Class Initialized
DEBUG - 2017-02-23 03:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:40:03 --> Input Class Initialized
INFO - 2017-02-23 03:40:03 --> Language Class Initialized
INFO - 2017-02-23 03:40:03 --> Loader Class Initialized
INFO - 2017-02-23 03:40:03 --> Database Driver Class Initialized
INFO - 2017-02-23 03:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:40:03 --> Controller Class Initialized
INFO - 2017-02-23 03:40:03 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:40:03 --> Final output sent to browser
DEBUG - 2017-02-23 03:40:03 --> Total execution time: 0.0152
INFO - 2017-02-23 03:40:09 --> Config Class Initialized
INFO - 2017-02-23 03:40:09 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:40:09 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:40:09 --> Utf8 Class Initialized
INFO - 2017-02-23 03:40:09 --> URI Class Initialized
DEBUG - 2017-02-23 03:40:09 --> No URI present. Default controller set.
INFO - 2017-02-23 03:40:09 --> Router Class Initialized
INFO - 2017-02-23 03:40:09 --> Output Class Initialized
INFO - 2017-02-23 03:40:09 --> Security Class Initialized
DEBUG - 2017-02-23 03:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:40:09 --> Input Class Initialized
INFO - 2017-02-23 03:40:09 --> Language Class Initialized
INFO - 2017-02-23 03:40:09 --> Loader Class Initialized
INFO - 2017-02-23 03:40:09 --> Database Driver Class Initialized
INFO - 2017-02-23 03:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:40:09 --> Controller Class Initialized
INFO - 2017-02-23 03:40:09 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:40:09 --> Final output sent to browser
DEBUG - 2017-02-23 03:40:09 --> Total execution time: 0.0135
INFO - 2017-02-23 03:40:12 --> Config Class Initialized
INFO - 2017-02-23 03:40:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:40:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:40:12 --> Utf8 Class Initialized
INFO - 2017-02-23 03:40:12 --> URI Class Initialized
INFO - 2017-02-23 03:40:12 --> Router Class Initialized
INFO - 2017-02-23 03:40:12 --> Output Class Initialized
INFO - 2017-02-23 03:40:12 --> Security Class Initialized
DEBUG - 2017-02-23 03:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:40:12 --> Input Class Initialized
INFO - 2017-02-23 03:40:12 --> Language Class Initialized
INFO - 2017-02-23 03:40:12 --> Loader Class Initialized
INFO - 2017-02-23 03:40:12 --> Database Driver Class Initialized
INFO - 2017-02-23 03:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:40:12 --> Controller Class Initialized
INFO - 2017-02-23 03:40:12 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:40:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:40:12 --> Final output sent to browser
DEBUG - 2017-02-23 03:40:12 --> Total execution time: 0.0142
INFO - 2017-02-23 03:42:51 --> Config Class Initialized
INFO - 2017-02-23 03:42:51 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:42:51 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:42:51 --> Utf8 Class Initialized
INFO - 2017-02-23 03:42:51 --> URI Class Initialized
INFO - 2017-02-23 03:42:51 --> Router Class Initialized
INFO - 2017-02-23 03:42:51 --> Output Class Initialized
INFO - 2017-02-23 03:42:51 --> Security Class Initialized
DEBUG - 2017-02-23 03:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:42:52 --> Input Class Initialized
INFO - 2017-02-23 03:42:52 --> Language Class Initialized
INFO - 2017-02-23 03:42:52 --> Loader Class Initialized
INFO - 2017-02-23 03:42:52 --> Database Driver Class Initialized
INFO - 2017-02-23 03:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:42:52 --> Controller Class Initialized
INFO - 2017-02-23 03:42:52 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:42:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:42:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:42:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:42:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:42:53 --> Final output sent to browser
DEBUG - 2017-02-23 03:42:53 --> Total execution time: 1.5210
INFO - 2017-02-23 03:42:55 --> Config Class Initialized
INFO - 2017-02-23 03:42:55 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:42:55 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:42:55 --> Utf8 Class Initialized
INFO - 2017-02-23 03:42:55 --> URI Class Initialized
INFO - 2017-02-23 03:42:55 --> Router Class Initialized
INFO - 2017-02-23 03:42:55 --> Output Class Initialized
INFO - 2017-02-23 03:42:55 --> Security Class Initialized
DEBUG - 2017-02-23 03:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:42:55 --> Input Class Initialized
INFO - 2017-02-23 03:42:55 --> Language Class Initialized
INFO - 2017-02-23 03:42:55 --> Loader Class Initialized
INFO - 2017-02-23 03:42:55 --> Database Driver Class Initialized
INFO - 2017-02-23 03:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:42:55 --> Controller Class Initialized
INFO - 2017-02-23 03:42:55 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:42:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:42:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:42:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:42:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:42:55 --> Final output sent to browser
DEBUG - 2017-02-23 03:42:55 --> Total execution time: 0.0141
INFO - 2017-02-23 03:43:41 --> Config Class Initialized
INFO - 2017-02-23 03:43:41 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:43:41 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:43:41 --> Utf8 Class Initialized
INFO - 2017-02-23 03:43:41 --> URI Class Initialized
DEBUG - 2017-02-23 03:43:41 --> No URI present. Default controller set.
INFO - 2017-02-23 03:43:41 --> Router Class Initialized
INFO - 2017-02-23 03:43:41 --> Output Class Initialized
INFO - 2017-02-23 03:43:41 --> Security Class Initialized
DEBUG - 2017-02-23 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:43:41 --> Input Class Initialized
INFO - 2017-02-23 03:43:41 --> Language Class Initialized
INFO - 2017-02-23 03:43:41 --> Loader Class Initialized
INFO - 2017-02-23 03:43:42 --> Database Driver Class Initialized
INFO - 2017-02-23 03:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:43:42 --> Controller Class Initialized
INFO - 2017-02-23 03:43:42 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:43:42 --> Final output sent to browser
DEBUG - 2017-02-23 03:43:42 --> Total execution time: 1.2093
INFO - 2017-02-23 03:43:43 --> Config Class Initialized
INFO - 2017-02-23 03:43:43 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:43:43 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:43:43 --> Utf8 Class Initialized
INFO - 2017-02-23 03:43:43 --> URI Class Initialized
INFO - 2017-02-23 03:43:43 --> Router Class Initialized
INFO - 2017-02-23 03:43:43 --> Output Class Initialized
INFO - 2017-02-23 03:43:43 --> Security Class Initialized
DEBUG - 2017-02-23 03:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:43:43 --> Input Class Initialized
INFO - 2017-02-23 03:43:43 --> Language Class Initialized
INFO - 2017-02-23 03:43:43 --> Loader Class Initialized
INFO - 2017-02-23 03:43:43 --> Database Driver Class Initialized
INFO - 2017-02-23 03:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:43:43 --> Controller Class Initialized
INFO - 2017-02-23 03:43:43 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:43:43 --> Final output sent to browser
DEBUG - 2017-02-23 03:43:43 --> Total execution time: 0.0147
INFO - 2017-02-23 03:44:03 --> Config Class Initialized
INFO - 2017-02-23 03:44:03 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:44:03 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:44:03 --> Utf8 Class Initialized
INFO - 2017-02-23 03:44:03 --> URI Class Initialized
DEBUG - 2017-02-23 03:44:03 --> No URI present. Default controller set.
INFO - 2017-02-23 03:44:03 --> Router Class Initialized
INFO - 2017-02-23 03:44:03 --> Output Class Initialized
INFO - 2017-02-23 03:44:03 --> Security Class Initialized
DEBUG - 2017-02-23 03:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:44:03 --> Input Class Initialized
INFO - 2017-02-23 03:44:03 --> Language Class Initialized
INFO - 2017-02-23 03:44:03 --> Loader Class Initialized
INFO - 2017-02-23 03:44:03 --> Database Driver Class Initialized
INFO - 2017-02-23 03:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:44:03 --> Controller Class Initialized
INFO - 2017-02-23 03:44:03 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:44:03 --> Final output sent to browser
DEBUG - 2017-02-23 03:44:03 --> Total execution time: 0.2965
INFO - 2017-02-23 03:44:08 --> Config Class Initialized
INFO - 2017-02-23 03:44:08 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:44:08 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:44:08 --> Utf8 Class Initialized
INFO - 2017-02-23 03:44:08 --> URI Class Initialized
DEBUG - 2017-02-23 03:44:08 --> No URI present. Default controller set.
INFO - 2017-02-23 03:44:08 --> Router Class Initialized
INFO - 2017-02-23 03:44:08 --> Output Class Initialized
INFO - 2017-02-23 03:44:08 --> Security Class Initialized
DEBUG - 2017-02-23 03:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:44:08 --> Input Class Initialized
INFO - 2017-02-23 03:44:08 --> Language Class Initialized
INFO - 2017-02-23 03:44:08 --> Loader Class Initialized
INFO - 2017-02-23 03:44:08 --> Database Driver Class Initialized
INFO - 2017-02-23 03:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:44:08 --> Controller Class Initialized
INFO - 2017-02-23 03:44:08 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:44:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:44:08 --> Final output sent to browser
DEBUG - 2017-02-23 03:44:08 --> Total execution time: 0.0138
INFO - 2017-02-23 03:44:10 --> Config Class Initialized
INFO - 2017-02-23 03:44:10 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:44:10 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:44:10 --> Utf8 Class Initialized
INFO - 2017-02-23 03:44:10 --> URI Class Initialized
INFO - 2017-02-23 03:44:10 --> Router Class Initialized
INFO - 2017-02-23 03:44:10 --> Output Class Initialized
INFO - 2017-02-23 03:44:10 --> Security Class Initialized
DEBUG - 2017-02-23 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:44:10 --> Input Class Initialized
INFO - 2017-02-23 03:44:10 --> Language Class Initialized
INFO - 2017-02-23 03:44:10 --> Loader Class Initialized
INFO - 2017-02-23 03:44:10 --> Database Driver Class Initialized
INFO - 2017-02-23 03:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:44:10 --> Controller Class Initialized
INFO - 2017-02-23 03:44:10 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:44:10 --> Final output sent to browser
DEBUG - 2017-02-23 03:44:10 --> Total execution time: 0.0141
INFO - 2017-02-23 03:44:46 --> Config Class Initialized
INFO - 2017-02-23 03:44:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:44:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:44:46 --> Utf8 Class Initialized
INFO - 2017-02-23 03:44:46 --> URI Class Initialized
INFO - 2017-02-23 03:44:46 --> Router Class Initialized
INFO - 2017-02-23 03:44:46 --> Output Class Initialized
INFO - 2017-02-23 03:44:46 --> Security Class Initialized
DEBUG - 2017-02-23 03:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:44:46 --> Input Class Initialized
INFO - 2017-02-23 03:44:46 --> Language Class Initialized
INFO - 2017-02-23 03:44:46 --> Loader Class Initialized
INFO - 2017-02-23 03:44:46 --> Database Driver Class Initialized
INFO - 2017-02-23 03:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:44:46 --> Controller Class Initialized
INFO - 2017-02-23 03:44:46 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:44:48 --> Config Class Initialized
INFO - 2017-02-23 03:44:48 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:44:48 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:44:48 --> Utf8 Class Initialized
INFO - 2017-02-23 03:44:48 --> URI Class Initialized
INFO - 2017-02-23 03:44:48 --> Router Class Initialized
INFO - 2017-02-23 03:44:48 --> Output Class Initialized
INFO - 2017-02-23 03:44:48 --> Security Class Initialized
DEBUG - 2017-02-23 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:44:48 --> Input Class Initialized
INFO - 2017-02-23 03:44:48 --> Language Class Initialized
INFO - 2017-02-23 03:44:48 --> Loader Class Initialized
INFO - 2017-02-23 03:44:48 --> Database Driver Class Initialized
INFO - 2017-02-23 03:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:44:48 --> Controller Class Initialized
INFO - 2017-02-23 03:44:48 --> Helper loaded: date_helper
DEBUG - 2017-02-23 03:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:44:48 --> Helper loaded: url_helper
INFO - 2017-02-23 03:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 03:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 03:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 03:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:44:48 --> Final output sent to browser
DEBUG - 2017-02-23 03:44:48 --> Total execution time: 0.1037
INFO - 2017-02-23 03:44:49 --> Config Class Initialized
INFO - 2017-02-23 03:44:49 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:44:49 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:44:49 --> Utf8 Class Initialized
INFO - 2017-02-23 03:44:49 --> URI Class Initialized
INFO - 2017-02-23 03:44:49 --> Router Class Initialized
INFO - 2017-02-23 03:44:49 --> Output Class Initialized
INFO - 2017-02-23 03:44:49 --> Security Class Initialized
DEBUG - 2017-02-23 03:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:44:49 --> Input Class Initialized
INFO - 2017-02-23 03:44:49 --> Language Class Initialized
INFO - 2017-02-23 03:44:49 --> Loader Class Initialized
INFO - 2017-02-23 03:44:49 --> Database Driver Class Initialized
INFO - 2017-02-23 03:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:44:49 --> Controller Class Initialized
INFO - 2017-02-23 03:44:49 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:44:49 --> Final output sent to browser
DEBUG - 2017-02-23 03:44:49 --> Total execution time: 0.0140
INFO - 2017-02-23 03:45:12 --> Config Class Initialized
INFO - 2017-02-23 03:45:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:45:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:45:13 --> Utf8 Class Initialized
INFO - 2017-02-23 03:45:13 --> URI Class Initialized
INFO - 2017-02-23 03:45:13 --> Router Class Initialized
INFO - 2017-02-23 03:45:13 --> Output Class Initialized
INFO - 2017-02-23 03:45:13 --> Security Class Initialized
DEBUG - 2017-02-23 03:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:45:13 --> Input Class Initialized
INFO - 2017-02-23 03:45:13 --> Language Class Initialized
INFO - 2017-02-23 03:45:13 --> Loader Class Initialized
INFO - 2017-02-23 03:45:13 --> Database Driver Class Initialized
INFO - 2017-02-23 03:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:45:13 --> Controller Class Initialized
INFO - 2017-02-23 03:45:13 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:45:13 --> Config Class Initialized
INFO - 2017-02-23 03:45:13 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:45:13 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:45:13 --> Utf8 Class Initialized
INFO - 2017-02-23 03:45:13 --> URI Class Initialized
DEBUG - 2017-02-23 03:45:13 --> No URI present. Default controller set.
INFO - 2017-02-23 03:45:13 --> Router Class Initialized
INFO - 2017-02-23 03:45:13 --> Output Class Initialized
INFO - 2017-02-23 03:45:13 --> Security Class Initialized
DEBUG - 2017-02-23 03:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:45:13 --> Input Class Initialized
INFO - 2017-02-23 03:45:13 --> Language Class Initialized
INFO - 2017-02-23 03:45:13 --> Loader Class Initialized
INFO - 2017-02-23 03:45:13 --> Database Driver Class Initialized
INFO - 2017-02-23 03:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:45:13 --> Controller Class Initialized
INFO - 2017-02-23 03:45:13 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:45:14 --> Final output sent to browser
DEBUG - 2017-02-23 03:45:14 --> Total execution time: 1.2821
INFO - 2017-02-23 03:45:14 --> Final output sent to browser
DEBUG - 2017-02-23 03:45:14 --> Total execution time: 0.6272
INFO - 2017-02-23 03:45:15 --> Config Class Initialized
INFO - 2017-02-23 03:45:15 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:45:15 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:45:15 --> Utf8 Class Initialized
INFO - 2017-02-23 03:45:15 --> URI Class Initialized
INFO - 2017-02-23 03:45:15 --> Router Class Initialized
INFO - 2017-02-23 03:45:15 --> Output Class Initialized
INFO - 2017-02-23 03:45:15 --> Security Class Initialized
DEBUG - 2017-02-23 03:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:45:15 --> Input Class Initialized
INFO - 2017-02-23 03:45:15 --> Language Class Initialized
INFO - 2017-02-23 03:45:15 --> Loader Class Initialized
INFO - 2017-02-23 03:45:15 --> Database Driver Class Initialized
INFO - 2017-02-23 03:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:45:15 --> Controller Class Initialized
INFO - 2017-02-23 03:45:15 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:45:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:45:15 --> Final output sent to browser
DEBUG - 2017-02-23 03:45:15 --> Total execution time: 0.0165
INFO - 2017-02-23 03:46:24 --> Config Class Initialized
INFO - 2017-02-23 03:46:24 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:46:24 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:46:24 --> Utf8 Class Initialized
INFO - 2017-02-23 03:46:24 --> URI Class Initialized
DEBUG - 2017-02-23 03:46:24 --> No URI present. Default controller set.
INFO - 2017-02-23 03:46:24 --> Router Class Initialized
INFO - 2017-02-23 03:46:24 --> Output Class Initialized
INFO - 2017-02-23 03:46:24 --> Security Class Initialized
DEBUG - 2017-02-23 03:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:46:24 --> Input Class Initialized
INFO - 2017-02-23 03:46:24 --> Language Class Initialized
INFO - 2017-02-23 03:46:24 --> Loader Class Initialized
INFO - 2017-02-23 03:46:25 --> Database Driver Class Initialized
INFO - 2017-02-23 03:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:46:25 --> Controller Class Initialized
INFO - 2017-02-23 03:46:25 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:46:25 --> Final output sent to browser
DEBUG - 2017-02-23 03:46:25 --> Total execution time: 1.2011
INFO - 2017-02-23 03:46:29 --> Config Class Initialized
INFO - 2017-02-23 03:46:29 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:46:29 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:46:29 --> Utf8 Class Initialized
INFO - 2017-02-23 03:46:29 --> URI Class Initialized
DEBUG - 2017-02-23 03:46:29 --> No URI present. Default controller set.
INFO - 2017-02-23 03:46:29 --> Router Class Initialized
INFO - 2017-02-23 03:46:29 --> Output Class Initialized
INFO - 2017-02-23 03:46:29 --> Security Class Initialized
DEBUG - 2017-02-23 03:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:46:29 --> Input Class Initialized
INFO - 2017-02-23 03:46:29 --> Language Class Initialized
INFO - 2017-02-23 03:46:29 --> Loader Class Initialized
INFO - 2017-02-23 03:46:29 --> Database Driver Class Initialized
INFO - 2017-02-23 03:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:46:29 --> Controller Class Initialized
INFO - 2017-02-23 03:46:29 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:46:29 --> Final output sent to browser
DEBUG - 2017-02-23 03:46:29 --> Total execution time: 0.0133
INFO - 2017-02-23 03:46:30 --> Config Class Initialized
INFO - 2017-02-23 03:46:30 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:46:30 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:46:30 --> Utf8 Class Initialized
INFO - 2017-02-23 03:46:30 --> URI Class Initialized
INFO - 2017-02-23 03:46:30 --> Router Class Initialized
INFO - 2017-02-23 03:46:30 --> Output Class Initialized
INFO - 2017-02-23 03:46:30 --> Security Class Initialized
DEBUG - 2017-02-23 03:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:46:30 --> Input Class Initialized
INFO - 2017-02-23 03:46:30 --> Language Class Initialized
INFO - 2017-02-23 03:46:31 --> Loader Class Initialized
INFO - 2017-02-23 03:46:31 --> Database Driver Class Initialized
INFO - 2017-02-23 03:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:46:31 --> Controller Class Initialized
INFO - 2017-02-23 03:46:31 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:46:31 --> Final output sent to browser
DEBUG - 2017-02-23 03:46:31 --> Total execution time: 0.0145
INFO - 2017-02-23 03:47:43 --> Config Class Initialized
INFO - 2017-02-23 03:47:43 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:47:43 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:47:43 --> Utf8 Class Initialized
INFO - 2017-02-23 03:47:43 --> URI Class Initialized
DEBUG - 2017-02-23 03:47:43 --> No URI present. Default controller set.
INFO - 2017-02-23 03:47:43 --> Router Class Initialized
INFO - 2017-02-23 03:47:43 --> Output Class Initialized
INFO - 2017-02-23 03:47:43 --> Security Class Initialized
DEBUG - 2017-02-23 03:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:47:43 --> Input Class Initialized
INFO - 2017-02-23 03:47:43 --> Language Class Initialized
INFO - 2017-02-23 03:47:43 --> Loader Class Initialized
INFO - 2017-02-23 03:47:43 --> Database Driver Class Initialized
INFO - 2017-02-23 03:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:47:44 --> Controller Class Initialized
INFO - 2017-02-23 03:47:44 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:47:44 --> Final output sent to browser
DEBUG - 2017-02-23 03:47:44 --> Total execution time: 1.2368
INFO - 2017-02-23 03:47:46 --> Config Class Initialized
INFO - 2017-02-23 03:47:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:47:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:47:46 --> Utf8 Class Initialized
INFO - 2017-02-23 03:47:46 --> URI Class Initialized
INFO - 2017-02-23 03:47:46 --> Router Class Initialized
INFO - 2017-02-23 03:47:46 --> Output Class Initialized
INFO - 2017-02-23 03:47:46 --> Security Class Initialized
DEBUG - 2017-02-23 03:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:47:46 --> Input Class Initialized
INFO - 2017-02-23 03:47:46 --> Language Class Initialized
INFO - 2017-02-23 03:47:46 --> Loader Class Initialized
INFO - 2017-02-23 03:47:46 --> Database Driver Class Initialized
INFO - 2017-02-23 03:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:47:46 --> Controller Class Initialized
INFO - 2017-02-23 03:47:46 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:47:46 --> Final output sent to browser
DEBUG - 2017-02-23 03:47:46 --> Total execution time: 0.0144
INFO - 2017-02-23 03:48:25 --> Config Class Initialized
INFO - 2017-02-23 03:48:25 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:48:25 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:48:25 --> Utf8 Class Initialized
INFO - 2017-02-23 03:48:25 --> URI Class Initialized
INFO - 2017-02-23 03:48:25 --> Router Class Initialized
INFO - 2017-02-23 03:48:25 --> Output Class Initialized
INFO - 2017-02-23 03:48:25 --> Security Class Initialized
DEBUG - 2017-02-23 03:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:48:25 --> Input Class Initialized
INFO - 2017-02-23 03:48:25 --> Language Class Initialized
INFO - 2017-02-23 03:48:25 --> Loader Class Initialized
INFO - 2017-02-23 03:48:25 --> Database Driver Class Initialized
INFO - 2017-02-23 03:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:48:25 --> Controller Class Initialized
INFO - 2017-02-23 03:48:25 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:48:26 --> Config Class Initialized
INFO - 2017-02-23 03:48:26 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:48:26 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:48:26 --> Utf8 Class Initialized
INFO - 2017-02-23 03:48:26 --> URI Class Initialized
INFO - 2017-02-23 03:48:26 --> Router Class Initialized
INFO - 2017-02-23 03:48:26 --> Output Class Initialized
INFO - 2017-02-23 03:48:26 --> Security Class Initialized
DEBUG - 2017-02-23 03:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:48:26 --> Input Class Initialized
INFO - 2017-02-23 03:48:26 --> Language Class Initialized
INFO - 2017-02-23 03:48:26 --> Loader Class Initialized
INFO - 2017-02-23 03:48:26 --> Database Driver Class Initialized
INFO - 2017-02-23 03:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:48:26 --> Controller Class Initialized
INFO - 2017-02-23 03:48:26 --> Helper loaded: date_helper
DEBUG - 2017-02-23 03:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:48:26 --> Helper loaded: url_helper
INFO - 2017-02-23 03:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 03:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 03:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 03:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:48:26 --> Final output sent to browser
DEBUG - 2017-02-23 03:48:26 --> Total execution time: 0.1006
INFO - 2017-02-23 03:48:27 --> Config Class Initialized
INFO - 2017-02-23 03:48:27 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:48:27 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:48:27 --> Utf8 Class Initialized
INFO - 2017-02-23 03:48:27 --> URI Class Initialized
INFO - 2017-02-23 03:48:27 --> Router Class Initialized
INFO - 2017-02-23 03:48:27 --> Output Class Initialized
INFO - 2017-02-23 03:48:27 --> Security Class Initialized
DEBUG - 2017-02-23 03:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:48:27 --> Input Class Initialized
INFO - 2017-02-23 03:48:27 --> Language Class Initialized
INFO - 2017-02-23 03:48:27 --> Loader Class Initialized
INFO - 2017-02-23 03:48:27 --> Database Driver Class Initialized
INFO - 2017-02-23 03:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:48:27 --> Controller Class Initialized
INFO - 2017-02-23 03:48:27 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:48:27 --> Final output sent to browser
DEBUG - 2017-02-23 03:48:27 --> Total execution time: 0.0140
INFO - 2017-02-23 03:52:50 --> Config Class Initialized
INFO - 2017-02-23 03:52:50 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:52:50 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:52:50 --> Utf8 Class Initialized
INFO - 2017-02-23 03:52:50 --> URI Class Initialized
DEBUG - 2017-02-23 03:52:51 --> No URI present. Default controller set.
INFO - 2017-02-23 03:52:51 --> Router Class Initialized
INFO - 2017-02-23 03:52:51 --> Output Class Initialized
INFO - 2017-02-23 03:52:51 --> Security Class Initialized
DEBUG - 2017-02-23 03:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:52:51 --> Input Class Initialized
INFO - 2017-02-23 03:52:51 --> Language Class Initialized
INFO - 2017-02-23 03:52:51 --> Loader Class Initialized
INFO - 2017-02-23 03:52:51 --> Database Driver Class Initialized
INFO - 2017-02-23 03:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:52:51 --> Controller Class Initialized
INFO - 2017-02-23 03:52:51 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:52:52 --> Final output sent to browser
DEBUG - 2017-02-23 03:52:52 --> Total execution time: 1.4960
INFO - 2017-02-23 03:52:54 --> Config Class Initialized
INFO - 2017-02-23 03:52:54 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:52:54 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:52:54 --> Utf8 Class Initialized
INFO - 2017-02-23 03:52:54 --> URI Class Initialized
INFO - 2017-02-23 03:52:54 --> Router Class Initialized
INFO - 2017-02-23 03:52:54 --> Output Class Initialized
INFO - 2017-02-23 03:52:54 --> Security Class Initialized
DEBUG - 2017-02-23 03:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:52:54 --> Input Class Initialized
INFO - 2017-02-23 03:52:54 --> Language Class Initialized
INFO - 2017-02-23 03:52:54 --> Loader Class Initialized
INFO - 2017-02-23 03:52:54 --> Database Driver Class Initialized
INFO - 2017-02-23 03:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:52:54 --> Controller Class Initialized
INFO - 2017-02-23 03:52:54 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:52:54 --> Final output sent to browser
DEBUG - 2017-02-23 03:52:54 --> Total execution time: 0.0165
INFO - 2017-02-23 03:58:14 --> Config Class Initialized
INFO - 2017-02-23 03:58:15 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:58:15 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:58:15 --> Utf8 Class Initialized
INFO - 2017-02-23 03:58:15 --> URI Class Initialized
DEBUG - 2017-02-23 03:58:15 --> No URI present. Default controller set.
INFO - 2017-02-23 03:58:15 --> Router Class Initialized
INFO - 2017-02-23 03:58:15 --> Output Class Initialized
INFO - 2017-02-23 03:58:15 --> Security Class Initialized
DEBUG - 2017-02-23 03:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:58:15 --> Input Class Initialized
INFO - 2017-02-23 03:58:15 --> Language Class Initialized
INFO - 2017-02-23 03:58:15 --> Loader Class Initialized
INFO - 2017-02-23 03:58:15 --> Database Driver Class Initialized
INFO - 2017-02-23 03:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:58:16 --> Controller Class Initialized
INFO - 2017-02-23 03:58:16 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:58:16 --> Final output sent to browser
DEBUG - 2017-02-23 03:58:16 --> Total execution time: 1.4835
INFO - 2017-02-23 03:58:19 --> Config Class Initialized
INFO - 2017-02-23 03:58:19 --> Hooks Class Initialized
DEBUG - 2017-02-23 03:58:19 --> UTF-8 Support Enabled
INFO - 2017-02-23 03:58:19 --> Utf8 Class Initialized
INFO - 2017-02-23 03:58:19 --> URI Class Initialized
INFO - 2017-02-23 03:58:19 --> Router Class Initialized
INFO - 2017-02-23 03:58:19 --> Output Class Initialized
INFO - 2017-02-23 03:58:19 --> Security Class Initialized
DEBUG - 2017-02-23 03:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 03:58:19 --> Input Class Initialized
INFO - 2017-02-23 03:58:19 --> Language Class Initialized
INFO - 2017-02-23 03:58:19 --> Loader Class Initialized
INFO - 2017-02-23 03:58:19 --> Database Driver Class Initialized
INFO - 2017-02-23 03:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 03:58:19 --> Controller Class Initialized
INFO - 2017-02-23 03:58:19 --> Helper loaded: url_helper
DEBUG - 2017-02-23 03:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 03:58:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 03:58:19 --> Final output sent to browser
DEBUG - 2017-02-23 03:58:19 --> Total execution time: 0.0138
INFO - 2017-02-23 04:13:26 --> Config Class Initialized
INFO - 2017-02-23 04:13:26 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:13:26 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:13:26 --> Utf8 Class Initialized
INFO - 2017-02-23 04:13:26 --> URI Class Initialized
DEBUG - 2017-02-23 04:13:26 --> No URI present. Default controller set.
INFO - 2017-02-23 04:13:26 --> Router Class Initialized
INFO - 2017-02-23 04:13:26 --> Output Class Initialized
INFO - 2017-02-23 04:13:26 --> Security Class Initialized
DEBUG - 2017-02-23 04:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:13:26 --> Input Class Initialized
INFO - 2017-02-23 04:13:26 --> Language Class Initialized
INFO - 2017-02-23 04:13:26 --> Loader Class Initialized
INFO - 2017-02-23 04:13:27 --> Database Driver Class Initialized
INFO - 2017-02-23 04:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:13:27 --> Controller Class Initialized
INFO - 2017-02-23 04:13:27 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 04:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 04:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:13:28 --> Final output sent to browser
DEBUG - 2017-02-23 04:13:28 --> Total execution time: 1.7175
INFO - 2017-02-23 04:26:47 --> Config Class Initialized
INFO - 2017-02-23 04:26:47 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:26:47 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:26:47 --> Utf8 Class Initialized
INFO - 2017-02-23 04:26:47 --> URI Class Initialized
DEBUG - 2017-02-23 04:26:47 --> No URI present. Default controller set.
INFO - 2017-02-23 04:26:47 --> Router Class Initialized
INFO - 2017-02-23 04:26:47 --> Output Class Initialized
INFO - 2017-02-23 04:26:47 --> Security Class Initialized
DEBUG - 2017-02-23 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:26:47 --> Input Class Initialized
INFO - 2017-02-23 04:26:47 --> Language Class Initialized
INFO - 2017-02-23 04:26:47 --> Loader Class Initialized
INFO - 2017-02-23 04:26:48 --> Database Driver Class Initialized
INFO - 2017-02-23 04:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:26:48 --> Controller Class Initialized
INFO - 2017-02-23 04:26:48 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 04:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 04:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:26:48 --> Final output sent to browser
DEBUG - 2017-02-23 04:26:48 --> Total execution time: 1.4916
INFO - 2017-02-23 04:26:52 --> Config Class Initialized
INFO - 2017-02-23 04:26:52 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:26:52 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:26:52 --> Utf8 Class Initialized
INFO - 2017-02-23 04:26:52 --> URI Class Initialized
INFO - 2017-02-23 04:26:52 --> Router Class Initialized
INFO - 2017-02-23 04:26:52 --> Output Class Initialized
INFO - 2017-02-23 04:26:52 --> Security Class Initialized
DEBUG - 2017-02-23 04:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:26:52 --> Input Class Initialized
INFO - 2017-02-23 04:26:52 --> Language Class Initialized
INFO - 2017-02-23 04:26:52 --> Loader Class Initialized
INFO - 2017-02-23 04:26:52 --> Database Driver Class Initialized
INFO - 2017-02-23 04:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:26:52 --> Controller Class Initialized
INFO - 2017-02-23 04:26:52 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 04:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 04:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:26:52 --> Final output sent to browser
DEBUG - 2017-02-23 04:26:52 --> Total execution time: 0.0142
INFO - 2017-02-23 04:27:02 --> Config Class Initialized
INFO - 2017-02-23 04:27:02 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:27:02 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:27:02 --> Utf8 Class Initialized
INFO - 2017-02-23 04:27:02 --> URI Class Initialized
INFO - 2017-02-23 04:27:02 --> Router Class Initialized
INFO - 2017-02-23 04:27:02 --> Output Class Initialized
INFO - 2017-02-23 04:27:02 --> Security Class Initialized
DEBUG - 2017-02-23 04:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:27:02 --> Input Class Initialized
INFO - 2017-02-23 04:27:02 --> Language Class Initialized
INFO - 2017-02-23 04:27:02 --> Loader Class Initialized
INFO - 2017-02-23 04:27:02 --> Database Driver Class Initialized
INFO - 2017-02-23 04:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:27:02 --> Controller Class Initialized
INFO - 2017-02-23 04:27:02 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 04:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 04:27:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:27:02 --> Final output sent to browser
DEBUG - 2017-02-23 04:27:02 --> Total execution time: 0.0549
INFO - 2017-02-23 04:27:03 --> Config Class Initialized
INFO - 2017-02-23 04:27:03 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:27:03 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:27:03 --> Utf8 Class Initialized
INFO - 2017-02-23 04:27:03 --> URI Class Initialized
INFO - 2017-02-23 04:27:03 --> Router Class Initialized
INFO - 2017-02-23 04:27:03 --> Output Class Initialized
INFO - 2017-02-23 04:27:03 --> Security Class Initialized
DEBUG - 2017-02-23 04:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:27:03 --> Input Class Initialized
INFO - 2017-02-23 04:27:03 --> Language Class Initialized
INFO - 2017-02-23 04:27:03 --> Loader Class Initialized
INFO - 2017-02-23 04:27:03 --> Database Driver Class Initialized
INFO - 2017-02-23 04:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:27:03 --> Controller Class Initialized
INFO - 2017-02-23 04:27:03 --> Helper loaded: date_helper
DEBUG - 2017-02-23 04:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:27:04 --> Helper loaded: url_helper
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:27:04 --> Final output sent to browser
DEBUG - 2017-02-23 04:27:04 --> Total execution time: 0.1509
INFO - 2017-02-23 04:27:04 --> Config Class Initialized
INFO - 2017-02-23 04:27:04 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:27:04 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:27:04 --> Utf8 Class Initialized
INFO - 2017-02-23 04:27:04 --> URI Class Initialized
INFO - 2017-02-23 04:27:04 --> Router Class Initialized
INFO - 2017-02-23 04:27:04 --> Output Class Initialized
INFO - 2017-02-23 04:27:04 --> Security Class Initialized
DEBUG - 2017-02-23 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:27:04 --> Input Class Initialized
INFO - 2017-02-23 04:27:04 --> Language Class Initialized
INFO - 2017-02-23 04:27:04 --> Loader Class Initialized
INFO - 2017-02-23 04:27:04 --> Database Driver Class Initialized
INFO - 2017-02-23 04:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:27:04 --> Controller Class Initialized
INFO - 2017-02-23 04:27:04 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 04:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:27:04 --> Final output sent to browser
DEBUG - 2017-02-23 04:27:04 --> Total execution time: 0.0136
INFO - 2017-02-23 04:27:08 --> Config Class Initialized
INFO - 2017-02-23 04:27:08 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:27:08 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:27:08 --> Utf8 Class Initialized
INFO - 2017-02-23 04:27:08 --> URI Class Initialized
INFO - 2017-02-23 04:27:08 --> Router Class Initialized
INFO - 2017-02-23 04:27:08 --> Output Class Initialized
INFO - 2017-02-23 04:27:08 --> Security Class Initialized
DEBUG - 2017-02-23 04:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:27:08 --> Input Class Initialized
INFO - 2017-02-23 04:27:08 --> Language Class Initialized
INFO - 2017-02-23 04:27:08 --> Loader Class Initialized
INFO - 2017-02-23 04:27:08 --> Database Driver Class Initialized
INFO - 2017-02-23 04:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:27:08 --> Controller Class Initialized
INFO - 2017-02-23 04:27:08 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:27:10 --> Config Class Initialized
INFO - 2017-02-23 04:27:10 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:27:10 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:27:10 --> Utf8 Class Initialized
INFO - 2017-02-23 04:27:10 --> URI Class Initialized
DEBUG - 2017-02-23 04:27:10 --> No URI present. Default controller set.
INFO - 2017-02-23 04:27:10 --> Router Class Initialized
INFO - 2017-02-23 04:27:10 --> Output Class Initialized
INFO - 2017-02-23 04:27:10 --> Security Class Initialized
DEBUG - 2017-02-23 04:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:27:10 --> Input Class Initialized
INFO - 2017-02-23 04:27:10 --> Language Class Initialized
INFO - 2017-02-23 04:27:10 --> Loader Class Initialized
INFO - 2017-02-23 04:27:10 --> Database Driver Class Initialized
INFO - 2017-02-23 04:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:27:10 --> Controller Class Initialized
INFO - 2017-02-23 04:27:10 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 04:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 04:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:27:10 --> Final output sent to browser
DEBUG - 2017-02-23 04:27:10 --> Total execution time: 0.2340
INFO - 2017-02-23 04:27:12 --> Config Class Initialized
INFO - 2017-02-23 04:27:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 04:27:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 04:27:12 --> Utf8 Class Initialized
INFO - 2017-02-23 04:27:12 --> URI Class Initialized
INFO - 2017-02-23 04:27:12 --> Router Class Initialized
INFO - 2017-02-23 04:27:12 --> Output Class Initialized
INFO - 2017-02-23 04:27:12 --> Security Class Initialized
DEBUG - 2017-02-23 04:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 04:27:12 --> Input Class Initialized
INFO - 2017-02-23 04:27:12 --> Language Class Initialized
INFO - 2017-02-23 04:27:12 --> Loader Class Initialized
INFO - 2017-02-23 04:27:12 --> Database Driver Class Initialized
INFO - 2017-02-23 04:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 04:27:12 --> Controller Class Initialized
INFO - 2017-02-23 04:27:12 --> Helper loaded: url_helper
DEBUG - 2017-02-23 04:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 04:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 04:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 04:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 04:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 04:27:13 --> Final output sent to browser
DEBUG - 2017-02-23 04:27:13 --> Total execution time: 1.2186
INFO - 2017-02-23 11:20:00 --> Config Class Initialized
INFO - 2017-02-23 11:20:00 --> Hooks Class Initialized
DEBUG - 2017-02-23 11:20:00 --> UTF-8 Support Enabled
INFO - 2017-02-23 11:20:00 --> Utf8 Class Initialized
INFO - 2017-02-23 11:20:00 --> URI Class Initialized
INFO - 2017-02-23 11:20:00 --> Router Class Initialized
INFO - 2017-02-23 11:20:00 --> Output Class Initialized
INFO - 2017-02-23 11:20:00 --> Security Class Initialized
DEBUG - 2017-02-23 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 11:20:00 --> Input Class Initialized
INFO - 2017-02-23 11:20:00 --> Language Class Initialized
INFO - 2017-02-23 11:20:00 --> Loader Class Initialized
INFO - 2017-02-23 11:20:01 --> Database Driver Class Initialized
INFO - 2017-02-23 11:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 11:20:01 --> Controller Class Initialized
INFO - 2017-02-23 11:20:01 --> Helper loaded: url_helper
DEBUG - 2017-02-23 11:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 11:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 11:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 11:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 11:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 11:20:02 --> Final output sent to browser
DEBUG - 2017-02-23 11:20:02 --> Total execution time: 1.4903
INFO - 2017-02-23 11:20:02 --> Config Class Initialized
INFO - 2017-02-23 11:20:02 --> Hooks Class Initialized
DEBUG - 2017-02-23 11:20:02 --> UTF-8 Support Enabled
INFO - 2017-02-23 11:20:02 --> Utf8 Class Initialized
INFO - 2017-02-23 11:20:02 --> URI Class Initialized
INFO - 2017-02-23 11:20:02 --> Router Class Initialized
INFO - 2017-02-23 11:20:02 --> Output Class Initialized
INFO - 2017-02-23 11:20:02 --> Security Class Initialized
DEBUG - 2017-02-23 11:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 11:20:02 --> Input Class Initialized
INFO - 2017-02-23 11:20:02 --> Language Class Initialized
INFO - 2017-02-23 11:20:02 --> Loader Class Initialized
INFO - 2017-02-23 11:20:02 --> Database Driver Class Initialized
INFO - 2017-02-23 11:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 11:20:02 --> Controller Class Initialized
INFO - 2017-02-23 11:20:02 --> Helper loaded: url_helper
DEBUG - 2017-02-23 11:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 11:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 11:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 11:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 11:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 11:20:02 --> Final output sent to browser
DEBUG - 2017-02-23 11:20:02 --> Total execution time: 0.0136
INFO - 2017-02-23 14:24:35 --> Config Class Initialized
INFO - 2017-02-23 14:24:35 --> Hooks Class Initialized
DEBUG - 2017-02-23 14:24:35 --> UTF-8 Support Enabled
INFO - 2017-02-23 14:24:35 --> Utf8 Class Initialized
INFO - 2017-02-23 14:24:35 --> URI Class Initialized
INFO - 2017-02-23 14:24:35 --> Router Class Initialized
INFO - 2017-02-23 14:24:35 --> Output Class Initialized
INFO - 2017-02-23 14:24:35 --> Security Class Initialized
DEBUG - 2017-02-23 14:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 14:24:35 --> Input Class Initialized
INFO - 2017-02-23 14:24:35 --> Language Class Initialized
INFO - 2017-02-23 14:24:35 --> Loader Class Initialized
INFO - 2017-02-23 14:24:36 --> Database Driver Class Initialized
INFO - 2017-02-23 14:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 14:24:36 --> Controller Class Initialized
INFO - 2017-02-23 14:24:36 --> Helper loaded: url_helper
DEBUG - 2017-02-23 14:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 14:24:36 --> Final output sent to browser
DEBUG - 2017-02-23 14:24:36 --> Total execution time: 1.0961
INFO - 2017-02-23 14:24:36 --> Config Class Initialized
INFO - 2017-02-23 14:24:36 --> Hooks Class Initialized
DEBUG - 2017-02-23 14:24:36 --> UTF-8 Support Enabled
INFO - 2017-02-23 14:24:36 --> Utf8 Class Initialized
INFO - 2017-02-23 14:24:36 --> URI Class Initialized
DEBUG - 2017-02-23 14:24:36 --> No URI present. Default controller set.
INFO - 2017-02-23 14:24:36 --> Router Class Initialized
INFO - 2017-02-23 14:24:36 --> Output Class Initialized
INFO - 2017-02-23 14:24:36 --> Security Class Initialized
DEBUG - 2017-02-23 14:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 14:24:36 --> Input Class Initialized
INFO - 2017-02-23 14:24:36 --> Language Class Initialized
INFO - 2017-02-23 14:24:36 --> Loader Class Initialized
INFO - 2017-02-23 14:24:36 --> Database Driver Class Initialized
INFO - 2017-02-23 14:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 14:24:36 --> Controller Class Initialized
INFO - 2017-02-23 14:24:36 --> Helper loaded: url_helper
DEBUG - 2017-02-23 14:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 14:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 14:24:36 --> Final output sent to browser
DEBUG - 2017-02-23 14:24:36 --> Total execution time: 0.0263
INFO - 2017-02-23 16:49:04 --> Config Class Initialized
INFO - 2017-02-23 16:49:05 --> Hooks Class Initialized
DEBUG - 2017-02-23 16:49:05 --> UTF-8 Support Enabled
INFO - 2017-02-23 16:49:05 --> Utf8 Class Initialized
INFO - 2017-02-23 16:49:05 --> URI Class Initialized
INFO - 2017-02-23 16:49:05 --> Router Class Initialized
INFO - 2017-02-23 16:49:05 --> Output Class Initialized
INFO - 2017-02-23 16:49:05 --> Security Class Initialized
DEBUG - 2017-02-23 16:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 16:49:05 --> Input Class Initialized
INFO - 2017-02-23 16:49:05 --> Language Class Initialized
INFO - 2017-02-23 16:49:05 --> Loader Class Initialized
INFO - 2017-02-23 16:49:05 --> Database Driver Class Initialized
INFO - 2017-02-23 16:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 16:49:06 --> Controller Class Initialized
INFO - 2017-02-23 16:49:06 --> Helper loaded: url_helper
DEBUG - 2017-02-23 16:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 16:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 16:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 16:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 16:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 16:49:06 --> Final output sent to browser
DEBUG - 2017-02-23 16:49:06 --> Total execution time: 1.6093
INFO - 2017-02-23 16:49:09 --> Config Class Initialized
INFO - 2017-02-23 16:49:09 --> Hooks Class Initialized
DEBUG - 2017-02-23 16:49:09 --> UTF-8 Support Enabled
INFO - 2017-02-23 16:49:09 --> Utf8 Class Initialized
INFO - 2017-02-23 16:49:09 --> URI Class Initialized
DEBUG - 2017-02-23 16:49:09 --> No URI present. Default controller set.
INFO - 2017-02-23 16:49:09 --> Router Class Initialized
INFO - 2017-02-23 16:49:09 --> Output Class Initialized
INFO - 2017-02-23 16:49:09 --> Security Class Initialized
DEBUG - 2017-02-23 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 16:49:09 --> Input Class Initialized
INFO - 2017-02-23 16:49:09 --> Language Class Initialized
INFO - 2017-02-23 16:49:09 --> Loader Class Initialized
INFO - 2017-02-23 16:49:09 --> Database Driver Class Initialized
INFO - 2017-02-23 16:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 16:49:09 --> Controller Class Initialized
INFO - 2017-02-23 16:49:09 --> Helper loaded: url_helper
DEBUG - 2017-02-23 16:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 16:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 16:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 16:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 16:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 16:49:09 --> Final output sent to browser
DEBUG - 2017-02-23 16:49:09 --> Total execution time: 0.0137
INFO - 2017-02-23 17:23:53 --> Config Class Initialized
INFO - 2017-02-23 17:23:53 --> Hooks Class Initialized
DEBUG - 2017-02-23 17:23:54 --> UTF-8 Support Enabled
INFO - 2017-02-23 17:23:54 --> Utf8 Class Initialized
INFO - 2017-02-23 17:23:54 --> URI Class Initialized
INFO - 2017-02-23 17:23:54 --> Router Class Initialized
INFO - 2017-02-23 17:23:54 --> Output Class Initialized
INFO - 2017-02-23 17:23:54 --> Security Class Initialized
DEBUG - 2017-02-23 17:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 17:23:54 --> Input Class Initialized
INFO - 2017-02-23 17:23:54 --> Language Class Initialized
INFO - 2017-02-23 17:23:54 --> Loader Class Initialized
INFO - 2017-02-23 17:23:54 --> Database Driver Class Initialized
INFO - 2017-02-23 17:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 17:23:54 --> Controller Class Initialized
INFO - 2017-02-23 17:23:54 --> Helper loaded: url_helper
DEBUG - 2017-02-23 17:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 17:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 17:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 17:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 17:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 17:23:55 --> Final output sent to browser
DEBUG - 2017-02-23 17:23:55 --> Total execution time: 1.4481
INFO - 2017-02-23 17:24:19 --> Config Class Initialized
INFO - 2017-02-23 17:24:19 --> Hooks Class Initialized
DEBUG - 2017-02-23 17:24:19 --> UTF-8 Support Enabled
INFO - 2017-02-23 17:24:19 --> Utf8 Class Initialized
INFO - 2017-02-23 17:24:19 --> URI Class Initialized
DEBUG - 2017-02-23 17:24:19 --> No URI present. Default controller set.
INFO - 2017-02-23 17:24:19 --> Router Class Initialized
INFO - 2017-02-23 17:24:19 --> Output Class Initialized
INFO - 2017-02-23 17:24:19 --> Security Class Initialized
DEBUG - 2017-02-23 17:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 17:24:19 --> Input Class Initialized
INFO - 2017-02-23 17:24:19 --> Language Class Initialized
INFO - 2017-02-23 17:24:19 --> Loader Class Initialized
INFO - 2017-02-23 17:24:20 --> Database Driver Class Initialized
INFO - 2017-02-23 17:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 17:24:20 --> Controller Class Initialized
INFO - 2017-02-23 17:24:20 --> Helper loaded: url_helper
DEBUG - 2017-02-23 17:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 17:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 17:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 17:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 17:24:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 17:24:20 --> Final output sent to browser
DEBUG - 2017-02-23 17:24:20 --> Total execution time: 1.5061
INFO - 2017-02-23 18:13:25 --> Config Class Initialized
INFO - 2017-02-23 18:13:25 --> Hooks Class Initialized
DEBUG - 2017-02-23 18:13:25 --> UTF-8 Support Enabled
INFO - 2017-02-23 18:13:25 --> Utf8 Class Initialized
INFO - 2017-02-23 18:13:25 --> URI Class Initialized
INFO - 2017-02-23 18:13:25 --> Router Class Initialized
INFO - 2017-02-23 18:13:25 --> Output Class Initialized
INFO - 2017-02-23 18:13:25 --> Security Class Initialized
DEBUG - 2017-02-23 18:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 18:13:25 --> Input Class Initialized
INFO - 2017-02-23 18:13:25 --> Language Class Initialized
INFO - 2017-02-23 18:13:25 --> Loader Class Initialized
INFO - 2017-02-23 18:13:25 --> Database Driver Class Initialized
INFO - 2017-02-23 18:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 18:13:25 --> Controller Class Initialized
INFO - 2017-02-23 18:13:25 --> Helper loaded: url_helper
DEBUG - 2017-02-23 18:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 18:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 18:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 18:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 18:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 18:13:26 --> Final output sent to browser
DEBUG - 2017-02-23 18:13:26 --> Total execution time: 1.2261
INFO - 2017-02-23 19:18:29 --> Config Class Initialized
INFO - 2017-02-23 19:18:29 --> Hooks Class Initialized
DEBUG - 2017-02-23 19:18:29 --> UTF-8 Support Enabled
INFO - 2017-02-23 19:18:29 --> Utf8 Class Initialized
INFO - 2017-02-23 19:18:29 --> URI Class Initialized
INFO - 2017-02-23 19:18:29 --> Router Class Initialized
INFO - 2017-02-23 19:18:29 --> Output Class Initialized
INFO - 2017-02-23 19:18:29 --> Security Class Initialized
DEBUG - 2017-02-23 19:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 19:18:29 --> Input Class Initialized
INFO - 2017-02-23 19:18:29 --> Language Class Initialized
INFO - 2017-02-23 19:18:29 --> Loader Class Initialized
INFO - 2017-02-23 19:18:30 --> Database Driver Class Initialized
INFO - 2017-02-23 19:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 19:18:30 --> Controller Class Initialized
INFO - 2017-02-23 19:18:30 --> Helper loaded: url_helper
DEBUG - 2017-02-23 19:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 19:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 19:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 19:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 19:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 19:18:31 --> Final output sent to browser
DEBUG - 2017-02-23 19:18:31 --> Total execution time: 1.7788
INFO - 2017-02-23 19:19:00 --> Config Class Initialized
INFO - 2017-02-23 19:19:00 --> Hooks Class Initialized
DEBUG - 2017-02-23 19:19:00 --> UTF-8 Support Enabled
INFO - 2017-02-23 19:19:00 --> Utf8 Class Initialized
INFO - 2017-02-23 19:19:00 --> URI Class Initialized
DEBUG - 2017-02-23 19:19:00 --> No URI present. Default controller set.
INFO - 2017-02-23 19:19:00 --> Router Class Initialized
INFO - 2017-02-23 19:19:00 --> Output Class Initialized
INFO - 2017-02-23 19:19:00 --> Security Class Initialized
DEBUG - 2017-02-23 19:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 19:19:00 --> Input Class Initialized
INFO - 2017-02-23 19:19:00 --> Language Class Initialized
INFO - 2017-02-23 19:19:00 --> Loader Class Initialized
INFO - 2017-02-23 19:19:00 --> Database Driver Class Initialized
INFO - 2017-02-23 19:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 19:19:01 --> Controller Class Initialized
INFO - 2017-02-23 19:19:01 --> Helper loaded: url_helper
DEBUG - 2017-02-23 19:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 19:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 19:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 19:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 19:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 19:19:01 --> Final output sent to browser
DEBUG - 2017-02-23 19:19:01 --> Total execution time: 1.7843
INFO - 2017-02-23 19:30:39 --> Config Class Initialized
INFO - 2017-02-23 19:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-23 19:30:40 --> UTF-8 Support Enabled
INFO - 2017-02-23 19:30:40 --> Utf8 Class Initialized
INFO - 2017-02-23 19:30:40 --> URI Class Initialized
INFO - 2017-02-23 19:30:40 --> Router Class Initialized
INFO - 2017-02-23 19:30:40 --> Output Class Initialized
INFO - 2017-02-23 19:30:40 --> Security Class Initialized
DEBUG - 2017-02-23 19:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 19:30:40 --> Input Class Initialized
INFO - 2017-02-23 19:30:40 --> Language Class Initialized
INFO - 2017-02-23 19:30:40 --> Loader Class Initialized
INFO - 2017-02-23 19:30:40 --> Database Driver Class Initialized
INFO - 2017-02-23 19:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 19:30:41 --> Controller Class Initialized
INFO - 2017-02-23 19:30:41 --> Helper loaded: url_helper
DEBUG - 2017-02-23 19:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 19:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 19:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 19:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 19:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 19:30:41 --> Final output sent to browser
DEBUG - 2017-02-23 19:30:41 --> Total execution time: 1.7342
INFO - 2017-02-23 19:30:45 --> Config Class Initialized
INFO - 2017-02-23 19:30:45 --> Hooks Class Initialized
DEBUG - 2017-02-23 19:30:45 --> UTF-8 Support Enabled
INFO - 2017-02-23 19:30:45 --> Utf8 Class Initialized
INFO - 2017-02-23 19:30:45 --> URI Class Initialized
DEBUG - 2017-02-23 19:30:45 --> No URI present. Default controller set.
INFO - 2017-02-23 19:30:45 --> Router Class Initialized
INFO - 2017-02-23 19:30:45 --> Output Class Initialized
INFO - 2017-02-23 19:30:45 --> Security Class Initialized
DEBUG - 2017-02-23 19:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 19:30:45 --> Input Class Initialized
INFO - 2017-02-23 19:30:45 --> Language Class Initialized
INFO - 2017-02-23 19:30:45 --> Loader Class Initialized
INFO - 2017-02-23 19:30:45 --> Database Driver Class Initialized
INFO - 2017-02-23 19:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 19:30:45 --> Controller Class Initialized
INFO - 2017-02-23 19:30:45 --> Helper loaded: url_helper
DEBUG - 2017-02-23 19:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 19:30:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 19:30:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 19:30:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 19:30:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 19:30:45 --> Final output sent to browser
DEBUG - 2017-02-23 19:30:45 --> Total execution time: 0.0144
INFO - 2017-02-23 20:53:20 --> Config Class Initialized
INFO - 2017-02-23 20:53:20 --> Hooks Class Initialized
DEBUG - 2017-02-23 20:53:20 --> UTF-8 Support Enabled
INFO - 2017-02-23 20:53:20 --> Utf8 Class Initialized
INFO - 2017-02-23 20:53:20 --> URI Class Initialized
DEBUG - 2017-02-23 20:53:21 --> No URI present. Default controller set.
INFO - 2017-02-23 20:53:21 --> Router Class Initialized
INFO - 2017-02-23 20:53:21 --> Output Class Initialized
INFO - 2017-02-23 20:53:21 --> Security Class Initialized
DEBUG - 2017-02-23 20:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 20:53:21 --> Input Class Initialized
INFO - 2017-02-23 20:53:21 --> Language Class Initialized
INFO - 2017-02-23 20:53:21 --> Loader Class Initialized
INFO - 2017-02-23 20:53:21 --> Database Driver Class Initialized
INFO - 2017-02-23 20:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 20:53:22 --> Controller Class Initialized
INFO - 2017-02-23 20:53:22 --> Helper loaded: url_helper
DEBUG - 2017-02-23 20:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 20:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 20:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 20:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 20:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 20:53:22 --> Final output sent to browser
DEBUG - 2017-02-23 20:53:22 --> Total execution time: 1.7490
INFO - 2017-02-23 21:34:41 --> Config Class Initialized
INFO - 2017-02-23 21:34:41 --> Hooks Class Initialized
DEBUG - 2017-02-23 21:34:41 --> UTF-8 Support Enabled
INFO - 2017-02-23 21:34:41 --> Utf8 Class Initialized
INFO - 2017-02-23 21:34:41 --> URI Class Initialized
INFO - 2017-02-23 21:34:41 --> Router Class Initialized
INFO - 2017-02-23 21:34:41 --> Output Class Initialized
INFO - 2017-02-23 21:34:41 --> Security Class Initialized
DEBUG - 2017-02-23 21:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 21:34:41 --> Input Class Initialized
INFO - 2017-02-23 21:34:41 --> Language Class Initialized
INFO - 2017-02-23 21:34:41 --> Loader Class Initialized
INFO - 2017-02-23 21:34:42 --> Database Driver Class Initialized
INFO - 2017-02-23 21:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 21:34:42 --> Controller Class Initialized
INFO - 2017-02-23 21:34:42 --> Helper loaded: url_helper
DEBUG - 2017-02-23 21:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 21:34:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 21:34:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 21:34:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 21:34:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 21:34:42 --> Final output sent to browser
DEBUG - 2017-02-23 21:34:42 --> Total execution time: 1.7157
INFO - 2017-02-23 21:34:52 --> Config Class Initialized
INFO - 2017-02-23 21:34:52 --> Hooks Class Initialized
DEBUG - 2017-02-23 21:34:52 --> UTF-8 Support Enabled
INFO - 2017-02-23 21:34:52 --> Utf8 Class Initialized
INFO - 2017-02-23 21:34:52 --> URI Class Initialized
DEBUG - 2017-02-23 21:34:52 --> No URI present. Default controller set.
INFO - 2017-02-23 21:34:52 --> Router Class Initialized
INFO - 2017-02-23 21:34:52 --> Output Class Initialized
INFO - 2017-02-23 21:34:52 --> Security Class Initialized
DEBUG - 2017-02-23 21:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 21:34:52 --> Input Class Initialized
INFO - 2017-02-23 21:34:52 --> Language Class Initialized
INFO - 2017-02-23 21:34:52 --> Loader Class Initialized
INFO - 2017-02-23 21:34:52 --> Database Driver Class Initialized
INFO - 2017-02-23 21:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 21:34:52 --> Controller Class Initialized
INFO - 2017-02-23 21:34:52 --> Helper loaded: url_helper
DEBUG - 2017-02-23 21:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 21:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 21:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 21:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 21:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 21:34:52 --> Final output sent to browser
DEBUG - 2017-02-23 21:34:52 --> Total execution time: 0.0135
INFO - 2017-02-23 22:31:36 --> Config Class Initialized
INFO - 2017-02-23 22:31:36 --> Hooks Class Initialized
DEBUG - 2017-02-23 22:31:36 --> UTF-8 Support Enabled
INFO - 2017-02-23 22:31:36 --> Utf8 Class Initialized
INFO - 2017-02-23 22:31:36 --> URI Class Initialized
DEBUG - 2017-02-23 22:31:36 --> No URI present. Default controller set.
INFO - 2017-02-23 22:31:36 --> Router Class Initialized
INFO - 2017-02-23 22:31:36 --> Output Class Initialized
INFO - 2017-02-23 22:31:36 --> Security Class Initialized
DEBUG - 2017-02-23 22:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 22:31:36 --> Input Class Initialized
INFO - 2017-02-23 22:31:36 --> Language Class Initialized
INFO - 2017-02-23 22:31:36 --> Loader Class Initialized
INFO - 2017-02-23 22:31:37 --> Database Driver Class Initialized
INFO - 2017-02-23 22:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 22:31:37 --> Controller Class Initialized
INFO - 2017-02-23 22:31:37 --> Helper loaded: url_helper
DEBUG - 2017-02-23 22:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 22:31:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 22:31:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 22:31:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 22:31:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 22:31:38 --> Final output sent to browser
DEBUG - 2017-02-23 22:31:38 --> Total execution time: 2.0597
INFO - 2017-02-23 23:57:44 --> Config Class Initialized
INFO - 2017-02-23 23:57:44 --> Hooks Class Initialized
DEBUG - 2017-02-23 23:57:45 --> UTF-8 Support Enabled
INFO - 2017-02-23 23:57:45 --> Utf8 Class Initialized
INFO - 2017-02-23 23:57:45 --> URI Class Initialized
INFO - 2017-02-23 23:57:45 --> Router Class Initialized
INFO - 2017-02-23 23:57:45 --> Output Class Initialized
INFO - 2017-02-23 23:57:45 --> Security Class Initialized
DEBUG - 2017-02-23 23:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 23:57:45 --> Input Class Initialized
INFO - 2017-02-23 23:57:45 --> Language Class Initialized
INFO - 2017-02-23 23:57:45 --> Loader Class Initialized
INFO - 2017-02-23 23:57:45 --> Database Driver Class Initialized
INFO - 2017-02-23 23:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 23:57:46 --> Controller Class Initialized
INFO - 2017-02-23 23:57:46 --> Helper loaded: url_helper
DEBUG - 2017-02-23 23:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 23:57:46 --> Final output sent to browser
DEBUG - 2017-02-23 23:57:46 --> Total execution time: 1.7407
INFO - 2017-02-23 23:57:46 --> Config Class Initialized
INFO - 2017-02-23 23:57:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 23:57:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 23:57:46 --> Utf8 Class Initialized
INFO - 2017-02-23 23:57:46 --> URI Class Initialized
INFO - 2017-02-23 23:57:46 --> Router Class Initialized
INFO - 2017-02-23 23:57:46 --> Output Class Initialized
INFO - 2017-02-23 23:57:46 --> Security Class Initialized
DEBUG - 2017-02-23 23:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 23:57:46 --> Input Class Initialized
INFO - 2017-02-23 23:57:46 --> Language Class Initialized
INFO - 2017-02-23 23:57:46 --> Loader Class Initialized
INFO - 2017-02-23 23:57:46 --> Database Driver Class Initialized
INFO - 2017-02-23 23:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 23:57:46 --> Controller Class Initialized
INFO - 2017-02-23 23:57:46 --> Helper loaded: url_helper
DEBUG - 2017-02-23 23:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-23 23:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-23 23:57:46 --> Final output sent to browser
DEBUG - 2017-02-23 23:57:46 --> Total execution time: 0.0141

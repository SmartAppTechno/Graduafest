<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-12 16:09:08 --> Config Class Initialized
INFO - 2017-01-12 16:09:08 --> Hooks Class Initialized
DEBUG - 2017-01-12 16:09:08 --> UTF-8 Support Enabled
INFO - 2017-01-12 16:09:08 --> Utf8 Class Initialized
INFO - 2017-01-12 16:09:08 --> URI Class Initialized
DEBUG - 2017-01-12 16:09:08 --> No URI present. Default controller set.
INFO - 2017-01-12 16:09:08 --> Router Class Initialized
INFO - 2017-01-12 16:09:08 --> Output Class Initialized
INFO - 2017-01-12 16:09:08 --> Security Class Initialized
DEBUG - 2017-01-12 16:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 16:09:08 --> Input Class Initialized
INFO - 2017-01-12 16:09:08 --> Language Class Initialized
INFO - 2017-01-12 16:09:08 --> Loader Class Initialized
INFO - 2017-01-12 16:09:08 --> Database Driver Class Initialized
INFO - 2017-01-12 16:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 16:09:09 --> Controller Class Initialized
INFO - 2017-01-12 16:09:09 --> Helper loaded: url_helper
DEBUG - 2017-01-12 16:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 16:09:09 --> Final output sent to browser
DEBUG - 2017-01-12 16:09:09 --> Total execution time: 1.6509
INFO - 2017-01-12 17:03:08 --> Config Class Initialized
INFO - 2017-01-12 17:03:08 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:03:08 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:03:08 --> Utf8 Class Initialized
INFO - 2017-01-12 17:03:08 --> URI Class Initialized
DEBUG - 2017-01-12 17:03:08 --> No URI present. Default controller set.
INFO - 2017-01-12 17:03:08 --> Router Class Initialized
INFO - 2017-01-12 17:03:08 --> Output Class Initialized
INFO - 2017-01-12 17:03:08 --> Security Class Initialized
DEBUG - 2017-01-12 17:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:03:08 --> Input Class Initialized
INFO - 2017-01-12 17:03:08 --> Language Class Initialized
INFO - 2017-01-12 17:03:08 --> Loader Class Initialized
INFO - 2017-01-12 17:03:09 --> Database Driver Class Initialized
INFO - 2017-01-12 17:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:03:09 --> Controller Class Initialized
INFO - 2017-01-12 17:03:09 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:03:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:03:09 --> Final output sent to browser
DEBUG - 2017-01-12 17:03:09 --> Total execution time: 1.5892
INFO - 2017-01-12 17:04:10 --> Config Class Initialized
INFO - 2017-01-12 17:04:10 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:04:10 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:04:10 --> Utf8 Class Initialized
INFO - 2017-01-12 17:04:10 --> URI Class Initialized
DEBUG - 2017-01-12 17:04:10 --> No URI present. Default controller set.
INFO - 2017-01-12 17:04:10 --> Router Class Initialized
INFO - 2017-01-12 17:04:10 --> Output Class Initialized
INFO - 2017-01-12 17:04:10 --> Security Class Initialized
DEBUG - 2017-01-12 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:04:10 --> Input Class Initialized
INFO - 2017-01-12 17:04:10 --> Language Class Initialized
INFO - 2017-01-12 17:04:10 --> Loader Class Initialized
INFO - 2017-01-12 17:04:10 --> Database Driver Class Initialized
INFO - 2017-01-12 17:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:04:10 --> Controller Class Initialized
INFO - 2017-01-12 17:04:10 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:04:10 --> Final output sent to browser
DEBUG - 2017-01-12 17:04:10 --> Total execution time: 0.0302
INFO - 2017-01-12 17:04:27 --> Config Class Initialized
INFO - 2017-01-12 17:04:27 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:04:27 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:04:27 --> Utf8 Class Initialized
INFO - 2017-01-12 17:04:27 --> URI Class Initialized
INFO - 2017-01-12 17:04:27 --> Router Class Initialized
INFO - 2017-01-12 17:04:27 --> Output Class Initialized
INFO - 2017-01-12 17:04:27 --> Security Class Initialized
DEBUG - 2017-01-12 17:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:04:27 --> Input Class Initialized
INFO - 2017-01-12 17:04:27 --> Language Class Initialized
INFO - 2017-01-12 17:04:27 --> Loader Class Initialized
INFO - 2017-01-12 17:04:27 --> Database Driver Class Initialized
INFO - 2017-01-12 17:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:04:27 --> Controller Class Initialized
INFO - 2017-01-12 17:04:27 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:04:27 --> Final output sent to browser
DEBUG - 2017-01-12 17:04:27 --> Total execution time: 0.0281
INFO - 2017-01-12 17:04:52 --> Config Class Initialized
INFO - 2017-01-12 17:04:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:04:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:04:52 --> Utf8 Class Initialized
INFO - 2017-01-12 17:04:52 --> URI Class Initialized
INFO - 2017-01-12 17:04:52 --> Router Class Initialized
INFO - 2017-01-12 17:04:52 --> Output Class Initialized
INFO - 2017-01-12 17:04:52 --> Security Class Initialized
DEBUG - 2017-01-12 17:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:04:52 --> Input Class Initialized
INFO - 2017-01-12 17:04:52 --> Language Class Initialized
INFO - 2017-01-12 17:04:52 --> Loader Class Initialized
INFO - 2017-01-12 17:04:52 --> Database Driver Class Initialized
INFO - 2017-01-12 17:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:04:52 --> Controller Class Initialized
INFO - 2017-01-12 17:04:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-12 17:04:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-12 17:04:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-12 17:04:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-12 17:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:04:53 --> Final output sent to browser
DEBUG - 2017-01-12 17:04:53 --> Total execution time: 0.3561
INFO - 2017-01-12 17:04:59 --> Config Class Initialized
INFO - 2017-01-12 17:04:59 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:04:59 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:04:59 --> Utf8 Class Initialized
INFO - 2017-01-12 17:04:59 --> URI Class Initialized
INFO - 2017-01-12 17:04:59 --> Router Class Initialized
INFO - 2017-01-12 17:04:59 --> Output Class Initialized
INFO - 2017-01-12 17:04:59 --> Security Class Initialized
DEBUG - 2017-01-12 17:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:04:59 --> Input Class Initialized
INFO - 2017-01-12 17:04:59 --> Language Class Initialized
INFO - 2017-01-12 17:04:59 --> Loader Class Initialized
INFO - 2017-01-12 17:04:59 --> Database Driver Class Initialized
INFO - 2017-01-12 17:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:04:59 --> Controller Class Initialized
INFO - 2017-01-12 17:04:59 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:04:59 --> Final output sent to browser
DEBUG - 2017-01-12 17:04:59 --> Total execution time: 0.0141
INFO - 2017-01-12 17:05:11 --> Config Class Initialized
INFO - 2017-01-12 17:05:11 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:05:11 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:05:11 --> Utf8 Class Initialized
INFO - 2017-01-12 17:05:11 --> URI Class Initialized
INFO - 2017-01-12 17:05:11 --> Router Class Initialized
INFO - 2017-01-12 17:05:11 --> Output Class Initialized
INFO - 2017-01-12 17:05:11 --> Security Class Initialized
DEBUG - 2017-01-12 17:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:05:11 --> Input Class Initialized
INFO - 2017-01-12 17:05:11 --> Language Class Initialized
INFO - 2017-01-12 17:05:11 --> Loader Class Initialized
INFO - 2017-01-12 17:05:11 --> Database Driver Class Initialized
INFO - 2017-01-12 17:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:05:11 --> Controller Class Initialized
INFO - 2017-01-12 17:05:11 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:05:14 --> Config Class Initialized
INFO - 2017-01-12 17:05:14 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:05:14 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:05:14 --> Utf8 Class Initialized
INFO - 2017-01-12 17:05:14 --> URI Class Initialized
INFO - 2017-01-12 17:05:14 --> Router Class Initialized
INFO - 2017-01-12 17:05:14 --> Output Class Initialized
INFO - 2017-01-12 17:05:14 --> Security Class Initialized
DEBUG - 2017-01-12 17:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:05:14 --> Input Class Initialized
INFO - 2017-01-12 17:05:14 --> Language Class Initialized
INFO - 2017-01-12 17:05:14 --> Loader Class Initialized
INFO - 2017-01-12 17:05:14 --> Database Driver Class Initialized
INFO - 2017-01-12 17:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:05:14 --> Controller Class Initialized
INFO - 2017-01-12 17:05:14 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:05:14 --> Helper loaded: url_helper
INFO - 2017-01-12 17:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-12 17:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-12 17:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:05:14 --> Final output sent to browser
DEBUG - 2017-01-12 17:05:14 --> Total execution time: 0.2868
INFO - 2017-01-12 17:05:16 --> Config Class Initialized
INFO - 2017-01-12 17:05:16 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:05:16 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:05:16 --> Utf8 Class Initialized
INFO - 2017-01-12 17:05:16 --> URI Class Initialized
INFO - 2017-01-12 17:05:16 --> Router Class Initialized
INFO - 2017-01-12 17:05:16 --> Output Class Initialized
INFO - 2017-01-12 17:05:16 --> Security Class Initialized
DEBUG - 2017-01-12 17:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:05:16 --> Input Class Initialized
INFO - 2017-01-12 17:05:16 --> Language Class Initialized
INFO - 2017-01-12 17:05:16 --> Loader Class Initialized
INFO - 2017-01-12 17:05:16 --> Database Driver Class Initialized
INFO - 2017-01-12 17:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:05:16 --> Controller Class Initialized
INFO - 2017-01-12 17:05:16 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:05:16 --> Final output sent to browser
DEBUG - 2017-01-12 17:05:16 --> Total execution time: 0.0154
INFO - 2017-01-12 17:07:39 --> Config Class Initialized
INFO - 2017-01-12 17:07:39 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:07:39 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:07:39 --> Utf8 Class Initialized
INFO - 2017-01-12 17:07:39 --> URI Class Initialized
DEBUG - 2017-01-12 17:07:39 --> No URI present. Default controller set.
INFO - 2017-01-12 17:07:39 --> Router Class Initialized
INFO - 2017-01-12 17:07:39 --> Output Class Initialized
INFO - 2017-01-12 17:07:39 --> Security Class Initialized
DEBUG - 2017-01-12 17:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:07:39 --> Input Class Initialized
INFO - 2017-01-12 17:07:39 --> Language Class Initialized
INFO - 2017-01-12 17:07:39 --> Loader Class Initialized
INFO - 2017-01-12 17:07:39 --> Database Driver Class Initialized
INFO - 2017-01-12 17:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:07:39 --> Controller Class Initialized
INFO - 2017-01-12 17:07:39 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:07:39 --> Final output sent to browser
DEBUG - 2017-01-12 17:07:39 --> Total execution time: 0.0238
INFO - 2017-01-12 17:07:46 --> Config Class Initialized
INFO - 2017-01-12 17:07:46 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:07:46 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:07:46 --> Utf8 Class Initialized
INFO - 2017-01-12 17:07:46 --> URI Class Initialized
INFO - 2017-01-12 17:07:46 --> Router Class Initialized
INFO - 2017-01-12 17:07:46 --> Output Class Initialized
INFO - 2017-01-12 17:07:46 --> Security Class Initialized
DEBUG - 2017-01-12 17:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:07:46 --> Input Class Initialized
INFO - 2017-01-12 17:07:46 --> Language Class Initialized
INFO - 2017-01-12 17:07:46 --> Loader Class Initialized
INFO - 2017-01-12 17:07:46 --> Database Driver Class Initialized
INFO - 2017-01-12 17:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:07:46 --> Controller Class Initialized
INFO - 2017-01-12 17:07:46 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:07:47 --> Config Class Initialized
INFO - 2017-01-12 17:07:47 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:07:47 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:07:47 --> Utf8 Class Initialized
INFO - 2017-01-12 17:07:47 --> URI Class Initialized
INFO - 2017-01-12 17:07:47 --> Router Class Initialized
INFO - 2017-01-12 17:07:47 --> Output Class Initialized
INFO - 2017-01-12 17:07:47 --> Security Class Initialized
DEBUG - 2017-01-12 17:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:07:47 --> Input Class Initialized
INFO - 2017-01-12 17:07:47 --> Language Class Initialized
INFO - 2017-01-12 17:07:47 --> Loader Class Initialized
INFO - 2017-01-12 17:07:47 --> Database Driver Class Initialized
INFO - 2017-01-12 17:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:07:47 --> Controller Class Initialized
INFO - 2017-01-12 17:07:47 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:07:47 --> Helper loaded: url_helper
INFO - 2017-01-12 17:07:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:07:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:07:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 17:07:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:07:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:07:47 --> Final output sent to browser
DEBUG - 2017-01-12 17:07:47 --> Total execution time: 0.0792
INFO - 2017-01-12 17:07:57 --> Config Class Initialized
INFO - 2017-01-12 17:07:57 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:07:57 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:07:57 --> Utf8 Class Initialized
INFO - 2017-01-12 17:07:57 --> URI Class Initialized
INFO - 2017-01-12 17:07:57 --> Router Class Initialized
INFO - 2017-01-12 17:07:57 --> Output Class Initialized
INFO - 2017-01-12 17:07:57 --> Security Class Initialized
DEBUG - 2017-01-12 17:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:07:57 --> Input Class Initialized
INFO - 2017-01-12 17:07:57 --> Language Class Initialized
INFO - 2017-01-12 17:07:57 --> Loader Class Initialized
INFO - 2017-01-12 17:07:57 --> Database Driver Class Initialized
INFO - 2017-01-12 17:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:07:58 --> Controller Class Initialized
INFO - 2017-01-12 17:07:58 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:07:58 --> Config Class Initialized
INFO - 2017-01-12 17:07:58 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:07:58 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:07:58 --> Utf8 Class Initialized
INFO - 2017-01-12 17:07:58 --> URI Class Initialized
DEBUG - 2017-01-12 17:07:58 --> No URI present. Default controller set.
INFO - 2017-01-12 17:07:58 --> Router Class Initialized
INFO - 2017-01-12 17:07:58 --> Output Class Initialized
INFO - 2017-01-12 17:07:58 --> Security Class Initialized
DEBUG - 2017-01-12 17:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:07:58 --> Input Class Initialized
INFO - 2017-01-12 17:07:58 --> Language Class Initialized
INFO - 2017-01-12 17:07:58 --> Loader Class Initialized
INFO - 2017-01-12 17:07:58 --> Database Driver Class Initialized
INFO - 2017-01-12 17:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:07:58 --> Controller Class Initialized
INFO - 2017-01-12 17:07:58 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:07:58 --> Final output sent to browser
DEBUG - 2017-01-12 17:07:58 --> Total execution time: 0.0140
INFO - 2017-01-12 17:08:02 --> Config Class Initialized
INFO - 2017-01-12 17:08:02 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:08:02 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:08:02 --> Utf8 Class Initialized
INFO - 2017-01-12 17:08:02 --> URI Class Initialized
INFO - 2017-01-12 17:08:02 --> Router Class Initialized
INFO - 2017-01-12 17:08:02 --> Output Class Initialized
INFO - 2017-01-12 17:08:02 --> Security Class Initialized
DEBUG - 2017-01-12 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:08:02 --> Input Class Initialized
INFO - 2017-01-12 17:08:02 --> Language Class Initialized
INFO - 2017-01-12 17:08:02 --> Loader Class Initialized
INFO - 2017-01-12 17:08:02 --> Database Driver Class Initialized
INFO - 2017-01-12 17:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:08:02 --> Controller Class Initialized
INFO - 2017-01-12 17:08:02 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:08:03 --> Config Class Initialized
INFO - 2017-01-12 17:08:03 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:08:03 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:08:03 --> Utf8 Class Initialized
INFO - 2017-01-12 17:08:03 --> URI Class Initialized
INFO - 2017-01-12 17:08:03 --> Router Class Initialized
INFO - 2017-01-12 17:08:03 --> Output Class Initialized
INFO - 2017-01-12 17:08:03 --> Security Class Initialized
DEBUG - 2017-01-12 17:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:08:03 --> Input Class Initialized
INFO - 2017-01-12 17:08:03 --> Language Class Initialized
INFO - 2017-01-12 17:08:03 --> Loader Class Initialized
INFO - 2017-01-12 17:08:03 --> Database Driver Class Initialized
INFO - 2017-01-12 17:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:08:03 --> Controller Class Initialized
INFO - 2017-01-12 17:08:03 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:08:03 --> Helper loaded: url_helper
INFO - 2017-01-12 17:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 17:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:08:03 --> Final output sent to browser
DEBUG - 2017-01-12 17:08:03 --> Total execution time: 0.0271
INFO - 2017-01-12 17:08:11 --> Config Class Initialized
INFO - 2017-01-12 17:08:11 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:08:11 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:08:11 --> Utf8 Class Initialized
INFO - 2017-01-12 17:08:11 --> URI Class Initialized
INFO - 2017-01-12 17:08:11 --> Router Class Initialized
INFO - 2017-01-12 17:08:11 --> Output Class Initialized
INFO - 2017-01-12 17:08:11 --> Security Class Initialized
DEBUG - 2017-01-12 17:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:08:11 --> Input Class Initialized
INFO - 2017-01-12 17:08:11 --> Language Class Initialized
INFO - 2017-01-12 17:08:11 --> Loader Class Initialized
INFO - 2017-01-12 17:08:11 --> Database Driver Class Initialized
INFO - 2017-01-12 17:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:08:11 --> Controller Class Initialized
INFO - 2017-01-12 17:08:11 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:08:11 --> Helper loaded: url_helper
INFO - 2017-01-12 17:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 17:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:08:11 --> Final output sent to browser
DEBUG - 2017-01-12 17:08:11 --> Total execution time: 0.0181
INFO - 2017-01-12 17:08:27 --> Config Class Initialized
INFO - 2017-01-12 17:08:27 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:08:27 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:08:27 --> Utf8 Class Initialized
INFO - 2017-01-12 17:08:27 --> URI Class Initialized
INFO - 2017-01-12 17:08:27 --> Router Class Initialized
INFO - 2017-01-12 17:08:27 --> Output Class Initialized
INFO - 2017-01-12 17:08:27 --> Security Class Initialized
DEBUG - 2017-01-12 17:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:08:27 --> Input Class Initialized
INFO - 2017-01-12 17:08:27 --> Language Class Initialized
INFO - 2017-01-12 17:08:27 --> Loader Class Initialized
INFO - 2017-01-12 17:08:27 --> Database Driver Class Initialized
INFO - 2017-01-12 17:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:08:27 --> Controller Class Initialized
INFO - 2017-01-12 17:08:27 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:08:27 --> Helper loaded: url_helper
INFO - 2017-01-12 17:08:27 --> Final output sent to browser
DEBUG - 2017-01-12 17:08:27 --> Total execution time: 0.0122
INFO - 2017-01-12 17:08:37 --> Config Class Initialized
INFO - 2017-01-12 17:08:37 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:08:37 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:08:37 --> Utf8 Class Initialized
INFO - 2017-01-12 17:08:37 --> URI Class Initialized
INFO - 2017-01-12 17:08:37 --> Router Class Initialized
INFO - 2017-01-12 17:08:37 --> Output Class Initialized
INFO - 2017-01-12 17:08:37 --> Security Class Initialized
DEBUG - 2017-01-12 17:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:08:37 --> Input Class Initialized
INFO - 2017-01-12 17:08:37 --> Language Class Initialized
INFO - 2017-01-12 17:08:37 --> Loader Class Initialized
INFO - 2017-01-12 17:08:37 --> Database Driver Class Initialized
INFO - 2017-01-12 17:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:08:37 --> Controller Class Initialized
INFO - 2017-01-12 17:08:37 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:08:37 --> Helper loaded: url_helper
INFO - 2017-01-12 17:08:37 --> Final output sent to browser
DEBUG - 2017-01-12 17:08:37 --> Total execution time: 0.0125
INFO - 2017-01-12 17:08:52 --> Config Class Initialized
INFO - 2017-01-12 17:08:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:08:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:08:52 --> Utf8 Class Initialized
INFO - 2017-01-12 17:08:52 --> URI Class Initialized
INFO - 2017-01-12 17:08:52 --> Router Class Initialized
INFO - 2017-01-12 17:08:52 --> Output Class Initialized
INFO - 2017-01-12 17:08:52 --> Security Class Initialized
DEBUG - 2017-01-12 17:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:08:52 --> Input Class Initialized
INFO - 2017-01-12 17:08:52 --> Language Class Initialized
INFO - 2017-01-12 17:08:52 --> Loader Class Initialized
INFO - 2017-01-12 17:08:52 --> Database Driver Class Initialized
INFO - 2017-01-12 17:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:08:52 --> Controller Class Initialized
INFO - 2017-01-12 17:08:52 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:08:52 --> Helper loaded: url_helper
INFO - 2017-01-12 17:08:52 --> Helper loaded: download_helper
INFO - 2017-01-12 17:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 17:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 17:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:08:52 --> Final output sent to browser
DEBUG - 2017-01-12 17:08:52 --> Total execution time: 0.1903
INFO - 2017-01-12 17:09:16 --> Config Class Initialized
INFO - 2017-01-12 17:09:16 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:09:16 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:09:16 --> Utf8 Class Initialized
INFO - 2017-01-12 17:09:16 --> URI Class Initialized
INFO - 2017-01-12 17:09:16 --> Router Class Initialized
INFO - 2017-01-12 17:09:16 --> Output Class Initialized
INFO - 2017-01-12 17:09:16 --> Security Class Initialized
DEBUG - 2017-01-12 17:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:09:16 --> Input Class Initialized
INFO - 2017-01-12 17:09:16 --> Language Class Initialized
INFO - 2017-01-12 17:09:16 --> Loader Class Initialized
INFO - 2017-01-12 17:09:16 --> Database Driver Class Initialized
INFO - 2017-01-12 17:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:09:16 --> Controller Class Initialized
INFO - 2017-01-12 17:09:16 --> Helper loaded: date_helper
INFO - 2017-01-12 17:09:16 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:09:17 --> Helper loaded: form_helper
INFO - 2017-01-12 17:09:17 --> Form Validation Class Initialized
INFO - 2017-01-12 17:09:17 --> Final output sent to browser
DEBUG - 2017-01-12 17:09:17 --> Total execution time: 0.1848
INFO - 2017-01-12 17:09:20 --> Config Class Initialized
INFO - 2017-01-12 17:09:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:09:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:09:20 --> Utf8 Class Initialized
INFO - 2017-01-12 17:09:20 --> URI Class Initialized
INFO - 2017-01-12 17:09:20 --> Router Class Initialized
INFO - 2017-01-12 17:09:20 --> Output Class Initialized
INFO - 2017-01-12 17:09:20 --> Security Class Initialized
DEBUG - 2017-01-12 17:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:09:20 --> Input Class Initialized
INFO - 2017-01-12 17:09:20 --> Language Class Initialized
INFO - 2017-01-12 17:09:20 --> Loader Class Initialized
INFO - 2017-01-12 17:09:20 --> Database Driver Class Initialized
INFO - 2017-01-12 17:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:09:20 --> Controller Class Initialized
INFO - 2017-01-12 17:09:20 --> Helper loaded: date_helper
INFO - 2017-01-12 17:09:20 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:09:20 --> Helper loaded: form_helper
INFO - 2017-01-12 17:09:20 --> Form Validation Class Initialized
INFO - 2017-01-12 17:09:20 --> Final output sent to browser
DEBUG - 2017-01-12 17:09:20 --> Total execution time: 0.0249
INFO - 2017-01-12 17:09:27 --> Config Class Initialized
INFO - 2017-01-12 17:09:27 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:09:27 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:09:27 --> Utf8 Class Initialized
INFO - 2017-01-12 17:09:27 --> URI Class Initialized
INFO - 2017-01-12 17:09:27 --> Router Class Initialized
INFO - 2017-01-12 17:09:27 --> Output Class Initialized
INFO - 2017-01-12 17:09:27 --> Security Class Initialized
DEBUG - 2017-01-12 17:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:09:27 --> Input Class Initialized
INFO - 2017-01-12 17:09:27 --> Language Class Initialized
INFO - 2017-01-12 17:09:27 --> Loader Class Initialized
INFO - 2017-01-12 17:09:27 --> Database Driver Class Initialized
INFO - 2017-01-12 17:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:09:27 --> Controller Class Initialized
INFO - 2017-01-12 17:09:27 --> Helper loaded: date_helper
INFO - 2017-01-12 17:09:27 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:09:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:09:27 --> Helper loaded: form_helper
INFO - 2017-01-12 17:09:27 --> Form Validation Class Initialized
INFO - 2017-01-12 17:09:27 --> Final output sent to browser
DEBUG - 2017-01-12 17:09:27 --> Total execution time: 0.0169
INFO - 2017-01-12 17:10:38 --> Config Class Initialized
INFO - 2017-01-12 17:10:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:10:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:10:38 --> Utf8 Class Initialized
INFO - 2017-01-12 17:10:38 --> URI Class Initialized
INFO - 2017-01-12 17:10:38 --> Router Class Initialized
INFO - 2017-01-12 17:10:38 --> Output Class Initialized
INFO - 2017-01-12 17:10:38 --> Security Class Initialized
DEBUG - 2017-01-12 17:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:10:38 --> Input Class Initialized
INFO - 2017-01-12 17:10:38 --> Language Class Initialized
INFO - 2017-01-12 17:10:38 --> Loader Class Initialized
INFO - 2017-01-12 17:10:38 --> Database Driver Class Initialized
INFO - 2017-01-12 17:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:10:38 --> Controller Class Initialized
INFO - 2017-01-12 17:10:38 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:10:38 --> Helper loaded: url_helper
INFO - 2017-01-12 17:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 17:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:10:38 --> Final output sent to browser
DEBUG - 2017-01-12 17:10:38 --> Total execution time: 0.0145
INFO - 2017-01-12 17:10:47 --> Config Class Initialized
INFO - 2017-01-12 17:10:47 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:10:47 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:10:47 --> Utf8 Class Initialized
INFO - 2017-01-12 17:10:47 --> URI Class Initialized
INFO - 2017-01-12 17:10:47 --> Router Class Initialized
INFO - 2017-01-12 17:10:47 --> Output Class Initialized
INFO - 2017-01-12 17:10:47 --> Security Class Initialized
DEBUG - 2017-01-12 17:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:10:47 --> Input Class Initialized
INFO - 2017-01-12 17:10:47 --> Language Class Initialized
INFO - 2017-01-12 17:10:47 --> Loader Class Initialized
INFO - 2017-01-12 17:10:47 --> Database Driver Class Initialized
INFO - 2017-01-12 17:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:10:47 --> Controller Class Initialized
INFO - 2017-01-12 17:10:47 --> Upload Class Initialized
INFO - 2017-01-12 17:10:47 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:10:47 --> Helper loaded: url_helper
INFO - 2017-01-12 17:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-12 17:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-12 17:10:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 17:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:10:47 --> Final output sent to browser
DEBUG - 2017-01-12 17:10:47 --> Total execution time: 0.1793
INFO - 2017-01-12 17:11:07 --> Config Class Initialized
INFO - 2017-01-12 17:11:07 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:11:07 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:11:07 --> Utf8 Class Initialized
INFO - 2017-01-12 17:11:07 --> URI Class Initialized
INFO - 2017-01-12 17:11:07 --> Router Class Initialized
INFO - 2017-01-12 17:11:07 --> Output Class Initialized
INFO - 2017-01-12 17:11:07 --> Security Class Initialized
DEBUG - 2017-01-12 17:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:11:07 --> Input Class Initialized
INFO - 2017-01-12 17:11:07 --> Language Class Initialized
INFO - 2017-01-12 17:11:07 --> Loader Class Initialized
INFO - 2017-01-12 17:11:07 --> Database Driver Class Initialized
INFO - 2017-01-12 17:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:11:07 --> Controller Class Initialized
INFO - 2017-01-12 17:11:07 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:11:07 --> Helper loaded: url_helper
INFO - 2017-01-12 17:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-12 17:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-12 17:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-12 17:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:11:07 --> Final output sent to browser
DEBUG - 2017-01-12 17:11:07 --> Total execution time: 0.0710
INFO - 2017-01-12 17:11:19 --> Config Class Initialized
INFO - 2017-01-12 17:11:19 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:11:19 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:11:19 --> Utf8 Class Initialized
INFO - 2017-01-12 17:11:19 --> URI Class Initialized
INFO - 2017-01-12 17:11:19 --> Router Class Initialized
INFO - 2017-01-12 17:11:19 --> Output Class Initialized
INFO - 2017-01-12 17:11:19 --> Security Class Initialized
DEBUG - 2017-01-12 17:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:11:19 --> Input Class Initialized
INFO - 2017-01-12 17:11:19 --> Language Class Initialized
INFO - 2017-01-12 17:11:19 --> Loader Class Initialized
INFO - 2017-01-12 17:11:19 --> Database Driver Class Initialized
INFO - 2017-01-12 17:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:11:19 --> Controller Class Initialized
INFO - 2017-01-12 17:11:19 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:11:19 --> Helper loaded: url_helper
INFO - 2017-01-12 17:11:19 --> Final output sent to browser
DEBUG - 2017-01-12 17:11:19 --> Total execution time: 0.0400
INFO - 2017-01-12 17:11:20 --> Config Class Initialized
INFO - 2017-01-12 17:11:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:11:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:11:20 --> Utf8 Class Initialized
INFO - 2017-01-12 17:11:20 --> URI Class Initialized
INFO - 2017-01-12 17:11:20 --> Router Class Initialized
INFO - 2017-01-12 17:11:20 --> Output Class Initialized
INFO - 2017-01-12 17:11:20 --> Security Class Initialized
DEBUG - 2017-01-12 17:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:11:20 --> Input Class Initialized
INFO - 2017-01-12 17:11:20 --> Language Class Initialized
INFO - 2017-01-12 17:11:20 --> Loader Class Initialized
INFO - 2017-01-12 17:11:20 --> Database Driver Class Initialized
INFO - 2017-01-12 17:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:11:20 --> Controller Class Initialized
INFO - 2017-01-12 17:11:20 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:11:20 --> Helper loaded: url_helper
INFO - 2017-01-12 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-12 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-12 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-12 17:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:11:20 --> Final output sent to browser
DEBUG - 2017-01-12 17:11:20 --> Total execution time: 0.0149
INFO - 2017-01-12 17:11:28 --> Config Class Initialized
INFO - 2017-01-12 17:11:28 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:11:28 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:11:28 --> Utf8 Class Initialized
INFO - 2017-01-12 17:11:28 --> URI Class Initialized
INFO - 2017-01-12 17:11:28 --> Router Class Initialized
INFO - 2017-01-12 17:11:28 --> Output Class Initialized
INFO - 2017-01-12 17:11:28 --> Security Class Initialized
DEBUG - 2017-01-12 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:11:28 --> Input Class Initialized
INFO - 2017-01-12 17:11:28 --> Language Class Initialized
INFO - 2017-01-12 17:11:28 --> Loader Class Initialized
INFO - 2017-01-12 17:11:28 --> Database Driver Class Initialized
INFO - 2017-01-12 17:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:11:28 --> Controller Class Initialized
INFO - 2017-01-12 17:11:28 --> Upload Class Initialized
INFO - 2017-01-12 17:11:28 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:11:28 --> Helper loaded: url_helper
INFO - 2017-01-12 17:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-12 17:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-12 17:11:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 17:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:11:28 --> Final output sent to browser
DEBUG - 2017-01-12 17:11:28 --> Total execution time: 0.0173
INFO - 2017-01-12 17:11:53 --> Config Class Initialized
INFO - 2017-01-12 17:11:53 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:11:53 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:11:53 --> Utf8 Class Initialized
INFO - 2017-01-12 17:11:53 --> URI Class Initialized
INFO - 2017-01-12 17:11:53 --> Router Class Initialized
INFO - 2017-01-12 17:11:53 --> Output Class Initialized
INFO - 2017-01-12 17:11:53 --> Security Class Initialized
DEBUG - 2017-01-12 17:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:11:53 --> Input Class Initialized
INFO - 2017-01-12 17:11:53 --> Language Class Initialized
INFO - 2017-01-12 17:11:53 --> Loader Class Initialized
INFO - 2017-01-12 17:11:53 --> Database Driver Class Initialized
INFO - 2017-01-12 17:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:11:53 --> Controller Class Initialized
INFO - 2017-01-12 17:11:53 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:11:54 --> Config Class Initialized
INFO - 2017-01-12 17:11:54 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:11:54 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:11:54 --> Utf8 Class Initialized
INFO - 2017-01-12 17:11:54 --> URI Class Initialized
DEBUG - 2017-01-12 17:11:54 --> No URI present. Default controller set.
INFO - 2017-01-12 17:11:54 --> Router Class Initialized
INFO - 2017-01-12 17:11:54 --> Output Class Initialized
INFO - 2017-01-12 17:11:54 --> Security Class Initialized
DEBUG - 2017-01-12 17:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:11:54 --> Input Class Initialized
INFO - 2017-01-12 17:11:54 --> Language Class Initialized
INFO - 2017-01-12 17:11:54 --> Loader Class Initialized
INFO - 2017-01-12 17:11:54 --> Database Driver Class Initialized
INFO - 2017-01-12 17:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:11:54 --> Controller Class Initialized
INFO - 2017-01-12 17:11:54 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:11:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:11:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:11:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:11:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:11:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:11:54 --> Final output sent to browser
DEBUG - 2017-01-12 17:11:54 --> Total execution time: 0.0429
INFO - 2017-01-12 17:12:01 --> Config Class Initialized
INFO - 2017-01-12 17:12:01 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:12:01 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:12:01 --> Utf8 Class Initialized
INFO - 2017-01-12 17:12:01 --> URI Class Initialized
INFO - 2017-01-12 17:12:01 --> Router Class Initialized
INFO - 2017-01-12 17:12:01 --> Output Class Initialized
INFO - 2017-01-12 17:12:01 --> Security Class Initialized
DEBUG - 2017-01-12 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:12:01 --> Input Class Initialized
INFO - 2017-01-12 17:12:01 --> Language Class Initialized
INFO - 2017-01-12 17:12:01 --> Loader Class Initialized
INFO - 2017-01-12 17:12:01 --> Database Driver Class Initialized
INFO - 2017-01-12 17:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:12:01 --> Controller Class Initialized
INFO - 2017-01-12 17:12:01 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:12:02 --> Config Class Initialized
INFO - 2017-01-12 17:12:02 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:12:02 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:12:02 --> Utf8 Class Initialized
INFO - 2017-01-12 17:12:02 --> URI Class Initialized
INFO - 2017-01-12 17:12:02 --> Router Class Initialized
INFO - 2017-01-12 17:12:02 --> Output Class Initialized
INFO - 2017-01-12 17:12:02 --> Security Class Initialized
DEBUG - 2017-01-12 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:12:02 --> Input Class Initialized
INFO - 2017-01-12 17:12:02 --> Language Class Initialized
INFO - 2017-01-12 17:12:02 --> Loader Class Initialized
INFO - 2017-01-12 17:12:02 --> Database Driver Class Initialized
INFO - 2017-01-12 17:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:12:02 --> Controller Class Initialized
INFO - 2017-01-12 17:12:02 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:12:02 --> Helper loaded: url_helper
INFO - 2017-01-12 17:12:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:12:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:12:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 17:12:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:12:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:12:02 --> Final output sent to browser
DEBUG - 2017-01-12 17:12:02 --> Total execution time: 0.0155
INFO - 2017-01-12 17:12:28 --> Config Class Initialized
INFO - 2017-01-12 17:12:28 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:12:28 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:12:28 --> Utf8 Class Initialized
INFO - 2017-01-12 17:12:28 --> URI Class Initialized
INFO - 2017-01-12 17:12:28 --> Router Class Initialized
INFO - 2017-01-12 17:12:28 --> Output Class Initialized
INFO - 2017-01-12 17:12:28 --> Security Class Initialized
DEBUG - 2017-01-12 17:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:12:28 --> Input Class Initialized
INFO - 2017-01-12 17:12:28 --> Language Class Initialized
INFO - 2017-01-12 17:12:28 --> Loader Class Initialized
INFO - 2017-01-12 17:12:28 --> Database Driver Class Initialized
INFO - 2017-01-12 17:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:12:28 --> Controller Class Initialized
INFO - 2017-01-12 17:12:28 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:12:28 --> Helper loaded: url_helper
INFO - 2017-01-12 17:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 17:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:12:28 --> Final output sent to browser
DEBUG - 2017-01-12 17:12:28 --> Total execution time: 0.0150
INFO - 2017-01-12 17:12:33 --> Config Class Initialized
INFO - 2017-01-12 17:12:33 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:12:33 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:12:33 --> Utf8 Class Initialized
INFO - 2017-01-12 17:12:33 --> URI Class Initialized
INFO - 2017-01-12 17:12:33 --> Router Class Initialized
INFO - 2017-01-12 17:12:33 --> Output Class Initialized
INFO - 2017-01-12 17:12:33 --> Security Class Initialized
DEBUG - 2017-01-12 17:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:12:33 --> Input Class Initialized
INFO - 2017-01-12 17:12:33 --> Language Class Initialized
INFO - 2017-01-12 17:12:33 --> Loader Class Initialized
INFO - 2017-01-12 17:12:33 --> Database Driver Class Initialized
INFO - 2017-01-12 17:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:12:33 --> Controller Class Initialized
INFO - 2017-01-12 17:12:33 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:12:33 --> Helper loaded: url_helper
INFO - 2017-01-12 17:12:33 --> Helper loaded: download_helper
INFO - 2017-01-12 17:12:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:12:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:12:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 17:12:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 17:12:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:12:33 --> Final output sent to browser
DEBUG - 2017-01-12 17:12:33 --> Total execution time: 0.0862
INFO - 2017-01-12 17:13:11 --> Config Class Initialized
INFO - 2017-01-12 17:13:11 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:13:11 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:13:11 --> Utf8 Class Initialized
INFO - 2017-01-12 17:13:11 --> URI Class Initialized
INFO - 2017-01-12 17:13:11 --> Router Class Initialized
INFO - 2017-01-12 17:13:11 --> Output Class Initialized
INFO - 2017-01-12 17:13:11 --> Security Class Initialized
DEBUG - 2017-01-12 17:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:13:11 --> Input Class Initialized
INFO - 2017-01-12 17:13:11 --> Language Class Initialized
INFO - 2017-01-12 17:13:11 --> Loader Class Initialized
INFO - 2017-01-12 17:13:11 --> Database Driver Class Initialized
INFO - 2017-01-12 17:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:13:11 --> Controller Class Initialized
INFO - 2017-01-12 17:13:11 --> Helper loaded: date_helper
DEBUG - 2017-01-12 17:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:13:11 --> Helper loaded: url_helper
INFO - 2017-01-12 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:13:11 --> Final output sent to browser
DEBUG - 2017-01-12 17:13:11 --> Total execution time: 0.0148
INFO - 2017-01-12 17:13:31 --> Config Class Initialized
INFO - 2017-01-12 17:13:31 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:13:31 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:13:31 --> Utf8 Class Initialized
INFO - 2017-01-12 17:13:31 --> URI Class Initialized
INFO - 2017-01-12 17:13:31 --> Router Class Initialized
INFO - 2017-01-12 17:13:31 --> Output Class Initialized
INFO - 2017-01-12 17:13:31 --> Security Class Initialized
DEBUG - 2017-01-12 17:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:13:31 --> Input Class Initialized
INFO - 2017-01-12 17:13:31 --> Language Class Initialized
INFO - 2017-01-12 17:13:31 --> Loader Class Initialized
INFO - 2017-01-12 17:13:31 --> Database Driver Class Initialized
INFO - 2017-01-12 17:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:13:31 --> Controller Class Initialized
INFO - 2017-01-12 17:13:31 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:13:31 --> Config Class Initialized
INFO - 2017-01-12 17:13:31 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:13:31 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:13:31 --> Utf8 Class Initialized
INFO - 2017-01-12 17:13:31 --> URI Class Initialized
DEBUG - 2017-01-12 17:13:31 --> No URI present. Default controller set.
INFO - 2017-01-12 17:13:31 --> Router Class Initialized
INFO - 2017-01-12 17:13:31 --> Output Class Initialized
INFO - 2017-01-12 17:13:31 --> Security Class Initialized
DEBUG - 2017-01-12 17:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:13:31 --> Input Class Initialized
INFO - 2017-01-12 17:13:31 --> Language Class Initialized
INFO - 2017-01-12 17:13:31 --> Loader Class Initialized
INFO - 2017-01-12 17:13:31 --> Database Driver Class Initialized
INFO - 2017-01-12 17:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:13:31 --> Controller Class Initialized
INFO - 2017-01-12 17:13:31 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:13:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:13:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:13:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:13:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:13:31 --> Final output sent to browser
DEBUG - 2017-01-12 17:13:31 --> Total execution time: 0.0391
INFO - 2017-01-12 17:13:32 --> Config Class Initialized
INFO - 2017-01-12 17:13:32 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:13:32 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:13:32 --> Utf8 Class Initialized
INFO - 2017-01-12 17:13:32 --> URI Class Initialized
DEBUG - 2017-01-12 17:13:32 --> No URI present. Default controller set.
INFO - 2017-01-12 17:13:32 --> Router Class Initialized
INFO - 2017-01-12 17:13:32 --> Output Class Initialized
INFO - 2017-01-12 17:13:32 --> Security Class Initialized
DEBUG - 2017-01-12 17:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:13:32 --> Input Class Initialized
INFO - 2017-01-12 17:13:32 --> Language Class Initialized
INFO - 2017-01-12 17:13:32 --> Loader Class Initialized
INFO - 2017-01-12 17:13:32 --> Database Driver Class Initialized
INFO - 2017-01-12 17:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:13:32 --> Controller Class Initialized
INFO - 2017-01-12 17:13:32 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 17:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 17:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 17:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 17:13:32 --> Final output sent to browser
DEBUG - 2017-01-12 17:13:32 --> Total execution time: 0.0133
INFO - 2017-01-12 17:13:35 --> Config Class Initialized
INFO - 2017-01-12 17:13:35 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:13:35 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:13:35 --> Utf8 Class Initialized
INFO - 2017-01-12 17:13:35 --> URI Class Initialized
INFO - 2017-01-12 17:13:35 --> Router Class Initialized
INFO - 2017-01-12 17:13:35 --> Output Class Initialized
INFO - 2017-01-12 17:13:35 --> Security Class Initialized
DEBUG - 2017-01-12 17:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:13:35 --> Input Class Initialized
INFO - 2017-01-12 17:13:35 --> Language Class Initialized
INFO - 2017-01-12 17:13:35 --> Loader Class Initialized
INFO - 2017-01-12 17:13:35 --> Database Driver Class Initialized
INFO - 2017-01-12 17:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:13:35 --> Controller Class Initialized
INFO - 2017-01-12 17:13:35 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:13:35 --> Helper loaded: form_helper
INFO - 2017-01-12 17:13:35 --> Form Validation Class Initialized
INFO - 2017-01-12 17:13:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 17:13:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 17:13:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 17:13:35 --> Final output sent to browser
DEBUG - 2017-01-12 17:13:35 --> Total execution time: 0.0637
INFO - 2017-01-12 17:14:03 --> Config Class Initialized
INFO - 2017-01-12 17:14:03 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:14:03 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:14:03 --> Utf8 Class Initialized
INFO - 2017-01-12 17:14:03 --> URI Class Initialized
INFO - 2017-01-12 17:14:03 --> Router Class Initialized
INFO - 2017-01-12 17:14:03 --> Output Class Initialized
INFO - 2017-01-12 17:14:03 --> Security Class Initialized
DEBUG - 2017-01-12 17:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:14:03 --> Input Class Initialized
INFO - 2017-01-12 17:14:03 --> Language Class Initialized
INFO - 2017-01-12 17:14:03 --> Loader Class Initialized
INFO - 2017-01-12 17:14:03 --> Database Driver Class Initialized
INFO - 2017-01-12 17:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:14:03 --> Controller Class Initialized
INFO - 2017-01-12 17:14:03 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:14:03 --> Helper loaded: form_helper
INFO - 2017-01-12 17:14:03 --> Form Validation Class Initialized
INFO - 2017-01-12 17:14:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 17:14:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 17:14:03 --> Final output sent to browser
DEBUG - 2017-01-12 17:14:03 --> Total execution time: 0.0689
INFO - 2017-01-12 17:15:01 --> Config Class Initialized
INFO - 2017-01-12 17:15:01 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:15:01 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:15:01 --> Utf8 Class Initialized
INFO - 2017-01-12 17:15:01 --> URI Class Initialized
INFO - 2017-01-12 17:15:01 --> Router Class Initialized
INFO - 2017-01-12 17:15:01 --> Output Class Initialized
INFO - 2017-01-12 17:15:01 --> Security Class Initialized
DEBUG - 2017-01-12 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:15:01 --> Input Class Initialized
INFO - 2017-01-12 17:15:01 --> Language Class Initialized
INFO - 2017-01-12 17:15:01 --> Loader Class Initialized
INFO - 2017-01-12 17:15:01 --> Database Driver Class Initialized
INFO - 2017-01-12 17:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:15:01 --> Controller Class Initialized
INFO - 2017-01-12 17:15:01 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:15:01 --> Helper loaded: form_helper
INFO - 2017-01-12 17:15:01 --> Form Validation Class Initialized
INFO - 2017-01-12 17:15:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 17:15:01 --> Config Class Initialized
INFO - 2017-01-12 17:15:01 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:15:01 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:15:01 --> Utf8 Class Initialized
INFO - 2017-01-12 17:15:01 --> URI Class Initialized
INFO - 2017-01-12 17:15:01 --> Router Class Initialized
INFO - 2017-01-12 17:15:01 --> Output Class Initialized
INFO - 2017-01-12 17:15:01 --> Security Class Initialized
DEBUG - 2017-01-12 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:15:01 --> Input Class Initialized
INFO - 2017-01-12 17:15:01 --> Language Class Initialized
INFO - 2017-01-12 17:15:01 --> Loader Class Initialized
INFO - 2017-01-12 17:15:01 --> Database Driver Class Initialized
INFO - 2017-01-12 17:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:15:01 --> Controller Class Initialized
INFO - 2017-01-12 17:15:01 --> Helper loaded: date_helper
INFO - 2017-01-12 17:15:01 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:15:01 --> Helper loaded: form_helper
INFO - 2017-01-12 17:15:01 --> Form Validation Class Initialized
INFO - 2017-01-12 17:15:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 17:15:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 17:15:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 17:15:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 17:15:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 17:15:01 --> Final output sent to browser
DEBUG - 2017-01-12 17:15:01 --> Total execution time: 0.1378
INFO - 2017-01-12 17:15:02 --> Config Class Initialized
INFO - 2017-01-12 17:15:02 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:15:02 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:15:02 --> Utf8 Class Initialized
INFO - 2017-01-12 17:15:02 --> URI Class Initialized
INFO - 2017-01-12 17:15:02 --> Router Class Initialized
INFO - 2017-01-12 17:15:02 --> Output Class Initialized
INFO - 2017-01-12 17:15:02 --> Security Class Initialized
DEBUG - 2017-01-12 17:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:15:02 --> Input Class Initialized
INFO - 2017-01-12 17:15:02 --> Language Class Initialized
INFO - 2017-01-12 17:15:02 --> Loader Class Initialized
INFO - 2017-01-12 17:15:02 --> Database Driver Class Initialized
INFO - 2017-01-12 17:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:15:02 --> Controller Class Initialized
INFO - 2017-01-12 17:15:02 --> Helper loaded: date_helper
INFO - 2017-01-12 17:15:02 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:15:02 --> Helper loaded: form_helper
INFO - 2017-01-12 17:15:02 --> Form Validation Class Initialized
INFO - 2017-01-12 17:15:02 --> Final output sent to browser
DEBUG - 2017-01-12 17:15:02 --> Total execution time: 0.0148
INFO - 2017-01-12 17:15:11 --> Config Class Initialized
INFO - 2017-01-12 17:15:11 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:15:11 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:15:11 --> Utf8 Class Initialized
INFO - 2017-01-12 17:15:11 --> URI Class Initialized
INFO - 2017-01-12 17:15:11 --> Router Class Initialized
INFO - 2017-01-12 17:15:11 --> Output Class Initialized
INFO - 2017-01-12 17:15:11 --> Security Class Initialized
DEBUG - 2017-01-12 17:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:15:11 --> Input Class Initialized
INFO - 2017-01-12 17:15:11 --> Language Class Initialized
INFO - 2017-01-12 17:15:11 --> Loader Class Initialized
INFO - 2017-01-12 17:15:11 --> Database Driver Class Initialized
INFO - 2017-01-12 17:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:15:11 --> Controller Class Initialized
INFO - 2017-01-12 17:15:11 --> Upload Class Initialized
INFO - 2017-01-12 17:15:11 --> Helper loaded: date_helper
INFO - 2017-01-12 17:15:11 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:15:11 --> Helper loaded: form_helper
INFO - 2017-01-12 17:15:11 --> Form Validation Class Initialized
INFO - 2017-01-12 17:15:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 17:15:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 17:15:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 17:15:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 17:15:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 17:15:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 17:15:11 --> Final output sent to browser
DEBUG - 2017-01-12 17:15:11 --> Total execution time: 0.0526
INFO - 2017-01-12 17:17:50 --> Config Class Initialized
INFO - 2017-01-12 17:17:50 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:17:50 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:17:50 --> Utf8 Class Initialized
INFO - 2017-01-12 17:17:50 --> URI Class Initialized
INFO - 2017-01-12 17:17:50 --> Router Class Initialized
INFO - 2017-01-12 17:17:50 --> Output Class Initialized
INFO - 2017-01-12 17:17:50 --> Security Class Initialized
DEBUG - 2017-01-12 17:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:17:50 --> Input Class Initialized
INFO - 2017-01-12 17:17:50 --> Language Class Initialized
INFO - 2017-01-12 17:17:50 --> Loader Class Initialized
INFO - 2017-01-12 17:17:50 --> Database Driver Class Initialized
INFO - 2017-01-12 17:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:17:50 --> Controller Class Initialized
INFO - 2017-01-12 17:17:50 --> Helper loaded: date_helper
INFO - 2017-01-12 17:17:50 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:17:50 --> Helper loaded: form_helper
INFO - 2017-01-12 17:17:50 --> Form Validation Class Initialized
INFO - 2017-01-12 17:17:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 17:17:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 17:17:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 17:17:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 17:17:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 17:17:50 --> Final output sent to browser
DEBUG - 2017-01-12 17:17:50 --> Total execution time: 0.0482
INFO - 2017-01-12 17:17:50 --> Config Class Initialized
INFO - 2017-01-12 17:17:50 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:17:50 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:17:50 --> Utf8 Class Initialized
INFO - 2017-01-12 17:17:50 --> URI Class Initialized
INFO - 2017-01-12 17:17:50 --> Router Class Initialized
INFO - 2017-01-12 17:17:50 --> Output Class Initialized
INFO - 2017-01-12 17:17:50 --> Security Class Initialized
DEBUG - 2017-01-12 17:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:17:50 --> Input Class Initialized
INFO - 2017-01-12 17:17:50 --> Language Class Initialized
INFO - 2017-01-12 17:17:50 --> Loader Class Initialized
INFO - 2017-01-12 17:17:50 --> Database Driver Class Initialized
INFO - 2017-01-12 17:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:17:50 --> Controller Class Initialized
INFO - 2017-01-12 17:17:50 --> Helper loaded: date_helper
INFO - 2017-01-12 17:17:50 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:17:50 --> Helper loaded: form_helper
INFO - 2017-01-12 17:17:50 --> Form Validation Class Initialized
INFO - 2017-01-12 17:17:50 --> Final output sent to browser
DEBUG - 2017-01-12 17:17:50 --> Total execution time: 0.0161
INFO - 2017-01-12 17:18:24 --> Config Class Initialized
INFO - 2017-01-12 17:18:24 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:18:24 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:18:24 --> Utf8 Class Initialized
INFO - 2017-01-12 17:18:24 --> URI Class Initialized
INFO - 2017-01-12 17:18:24 --> Router Class Initialized
INFO - 2017-01-12 17:18:24 --> Output Class Initialized
INFO - 2017-01-12 17:18:24 --> Security Class Initialized
DEBUG - 2017-01-12 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:18:24 --> Input Class Initialized
INFO - 2017-01-12 17:18:24 --> Language Class Initialized
INFO - 2017-01-12 17:18:24 --> Loader Class Initialized
INFO - 2017-01-12 17:18:24 --> Database Driver Class Initialized
INFO - 2017-01-12 17:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:18:24 --> Controller Class Initialized
INFO - 2017-01-12 17:18:24 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:18:24 --> Config Class Initialized
INFO - 2017-01-12 17:18:24 --> Hooks Class Initialized
DEBUG - 2017-01-12 17:18:24 --> UTF-8 Support Enabled
INFO - 2017-01-12 17:18:24 --> Utf8 Class Initialized
INFO - 2017-01-12 17:18:24 --> URI Class Initialized
INFO - 2017-01-12 17:18:24 --> Router Class Initialized
INFO - 2017-01-12 17:18:24 --> Output Class Initialized
INFO - 2017-01-12 17:18:24 --> Security Class Initialized
DEBUG - 2017-01-12 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 17:18:24 --> Input Class Initialized
INFO - 2017-01-12 17:18:24 --> Language Class Initialized
INFO - 2017-01-12 17:18:24 --> Loader Class Initialized
INFO - 2017-01-12 17:18:24 --> Database Driver Class Initialized
INFO - 2017-01-12 17:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 17:18:24 --> Controller Class Initialized
INFO - 2017-01-12 17:18:24 --> Helper loaded: url_helper
DEBUG - 2017-01-12 17:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 17:18:24 --> Helper loaded: form_helper
INFO - 2017-01-12 17:18:24 --> Form Validation Class Initialized
INFO - 2017-01-12 17:18:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 17:18:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 17:18:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 17:18:24 --> Final output sent to browser
DEBUG - 2017-01-12 17:18:24 --> Total execution time: 0.0137
INFO - 2017-01-12 18:29:24 --> Config Class Initialized
INFO - 2017-01-12 18:29:24 --> Hooks Class Initialized
DEBUG - 2017-01-12 18:29:24 --> UTF-8 Support Enabled
INFO - 2017-01-12 18:29:24 --> Utf8 Class Initialized
INFO - 2017-01-12 18:29:24 --> URI Class Initialized
DEBUG - 2017-01-12 18:29:24 --> No URI present. Default controller set.
INFO - 2017-01-12 18:29:24 --> Router Class Initialized
INFO - 2017-01-12 18:29:24 --> Output Class Initialized
INFO - 2017-01-12 18:29:24 --> Security Class Initialized
DEBUG - 2017-01-12 18:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 18:29:25 --> Input Class Initialized
INFO - 2017-01-12 18:29:25 --> Language Class Initialized
INFO - 2017-01-12 18:29:25 --> Loader Class Initialized
INFO - 2017-01-12 18:29:25 --> Database Driver Class Initialized
INFO - 2017-01-12 18:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 18:29:25 --> Controller Class Initialized
INFO - 2017-01-12 18:29:25 --> Helper loaded: url_helper
DEBUG - 2017-01-12 18:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 18:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 18:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 18:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 18:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 18:29:26 --> Final output sent to browser
DEBUG - 2017-01-12 18:29:26 --> Total execution time: 1.7293
INFO - 2017-01-12 18:41:37 --> Config Class Initialized
INFO - 2017-01-12 18:41:37 --> Hooks Class Initialized
DEBUG - 2017-01-12 18:41:37 --> UTF-8 Support Enabled
INFO - 2017-01-12 18:41:37 --> Utf8 Class Initialized
INFO - 2017-01-12 18:41:37 --> URI Class Initialized
DEBUG - 2017-01-12 18:41:37 --> No URI present. Default controller set.
INFO - 2017-01-12 18:41:37 --> Router Class Initialized
INFO - 2017-01-12 18:41:37 --> Output Class Initialized
INFO - 2017-01-12 18:41:37 --> Security Class Initialized
DEBUG - 2017-01-12 18:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 18:41:37 --> Input Class Initialized
INFO - 2017-01-12 18:41:37 --> Language Class Initialized
INFO - 2017-01-12 18:41:38 --> Loader Class Initialized
INFO - 2017-01-12 18:41:38 --> Database Driver Class Initialized
INFO - 2017-01-12 18:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 18:41:38 --> Controller Class Initialized
INFO - 2017-01-12 18:41:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 18:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 18:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 18:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 18:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 18:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 18:41:38 --> Final output sent to browser
DEBUG - 2017-01-12 18:41:38 --> Total execution time: 0.0357
INFO - 2017-01-12 19:56:58 --> Config Class Initialized
INFO - 2017-01-12 19:56:58 --> Hooks Class Initialized
DEBUG - 2017-01-12 19:56:58 --> UTF-8 Support Enabled
INFO - 2017-01-12 19:56:58 --> Utf8 Class Initialized
INFO - 2017-01-12 19:56:58 --> URI Class Initialized
INFO - 2017-01-12 19:56:58 --> Router Class Initialized
INFO - 2017-01-12 19:56:58 --> Output Class Initialized
INFO - 2017-01-12 19:56:58 --> Security Class Initialized
DEBUG - 2017-01-12 19:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 19:56:58 --> Input Class Initialized
INFO - 2017-01-12 19:56:58 --> Language Class Initialized
INFO - 2017-01-12 19:56:58 --> Loader Class Initialized
INFO - 2017-01-12 19:56:58 --> Database Driver Class Initialized
INFO - 2017-01-12 19:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 19:56:59 --> Controller Class Initialized
INFO - 2017-01-12 19:56:59 --> Helper loaded: url_helper
DEBUG - 2017-01-12 19:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 19:56:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-12 19:56:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-12 19:56:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-12 19:56:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-12 19:56:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 19:56:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 19:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 19:57:00 --> Final output sent to browser
DEBUG - 2017-01-12 19:57:00 --> Total execution time: 1.8398
INFO - 2017-01-12 21:21:17 --> Config Class Initialized
INFO - 2017-01-12 21:21:17 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:21:17 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:21:17 --> Utf8 Class Initialized
INFO - 2017-01-12 21:21:18 --> URI Class Initialized
DEBUG - 2017-01-12 21:21:18 --> No URI present. Default controller set.
INFO - 2017-01-12 21:21:18 --> Router Class Initialized
INFO - 2017-01-12 21:21:18 --> Output Class Initialized
INFO - 2017-01-12 21:21:18 --> Security Class Initialized
DEBUG - 2017-01-12 21:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:21:18 --> Input Class Initialized
INFO - 2017-01-12 21:21:18 --> Language Class Initialized
INFO - 2017-01-12 21:21:18 --> Loader Class Initialized
INFO - 2017-01-12 21:21:18 --> Database Driver Class Initialized
INFO - 2017-01-12 21:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:21:18 --> Controller Class Initialized
INFO - 2017-01-12 21:21:18 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:21:19 --> Final output sent to browser
DEBUG - 2017-01-12 21:21:19 --> Total execution time: 1.8225
INFO - 2017-01-12 21:21:21 --> Config Class Initialized
INFO - 2017-01-12 21:21:21 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:21:21 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:21:21 --> Utf8 Class Initialized
INFO - 2017-01-12 21:21:21 --> URI Class Initialized
INFO - 2017-01-12 21:21:21 --> Router Class Initialized
INFO - 2017-01-12 21:21:21 --> Output Class Initialized
INFO - 2017-01-12 21:21:21 --> Security Class Initialized
DEBUG - 2017-01-12 21:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:21:21 --> Input Class Initialized
INFO - 2017-01-12 21:21:21 --> Language Class Initialized
INFO - 2017-01-12 21:21:21 --> Loader Class Initialized
INFO - 2017-01-12 21:21:21 --> Database Driver Class Initialized
INFO - 2017-01-12 21:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:21:21 --> Controller Class Initialized
INFO - 2017-01-12 21:21:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:21:21 --> Final output sent to browser
DEBUG - 2017-01-12 21:21:21 --> Total execution time: 0.0142
INFO - 2017-01-12 21:21:27 --> Config Class Initialized
INFO - 2017-01-12 21:21:27 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:21:27 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:21:27 --> Utf8 Class Initialized
INFO - 2017-01-12 21:21:27 --> URI Class Initialized
INFO - 2017-01-12 21:21:27 --> Router Class Initialized
INFO - 2017-01-12 21:21:27 --> Output Class Initialized
INFO - 2017-01-12 21:21:27 --> Security Class Initialized
DEBUG - 2017-01-12 21:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:21:27 --> Input Class Initialized
INFO - 2017-01-12 21:21:27 --> Language Class Initialized
INFO - 2017-01-12 21:21:27 --> Loader Class Initialized
INFO - 2017-01-12 21:21:27 --> Database Driver Class Initialized
INFO - 2017-01-12 21:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:21:27 --> Controller Class Initialized
INFO - 2017-01-12 21:21:27 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:21:27 --> Helper loaded: form_helper
INFO - 2017-01-12 21:21:27 --> Form Validation Class Initialized
INFO - 2017-01-12 21:21:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:21:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 21:21:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:21:27 --> Final output sent to browser
DEBUG - 2017-01-12 21:21:27 --> Total execution time: 0.5000
INFO - 2017-01-12 21:21:28 --> Config Class Initialized
INFO - 2017-01-12 21:21:28 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:21:28 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:21:28 --> Utf8 Class Initialized
INFO - 2017-01-12 21:21:28 --> URI Class Initialized
INFO - 2017-01-12 21:21:28 --> Router Class Initialized
INFO - 2017-01-12 21:21:28 --> Output Class Initialized
INFO - 2017-01-12 21:21:28 --> Security Class Initialized
DEBUG - 2017-01-12 21:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:21:28 --> Input Class Initialized
INFO - 2017-01-12 21:21:28 --> Language Class Initialized
INFO - 2017-01-12 21:21:28 --> Loader Class Initialized
INFO - 2017-01-12 21:21:28 --> Database Driver Class Initialized
INFO - 2017-01-12 21:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:21:28 --> Controller Class Initialized
INFO - 2017-01-12 21:21:28 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:21:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:21:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:21:28 --> Final output sent to browser
DEBUG - 2017-01-12 21:21:28 --> Total execution time: 0.0131
INFO - 2017-01-12 21:21:58 --> Config Class Initialized
INFO - 2017-01-12 21:21:58 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:21:58 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:21:58 --> Utf8 Class Initialized
INFO - 2017-01-12 21:21:58 --> URI Class Initialized
INFO - 2017-01-12 21:21:58 --> Router Class Initialized
INFO - 2017-01-12 21:21:58 --> Output Class Initialized
INFO - 2017-01-12 21:21:58 --> Security Class Initialized
DEBUG - 2017-01-12 21:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:21:59 --> Input Class Initialized
INFO - 2017-01-12 21:21:59 --> Language Class Initialized
INFO - 2017-01-12 21:21:59 --> Loader Class Initialized
INFO - 2017-01-12 21:21:59 --> Database Driver Class Initialized
INFO - 2017-01-12 21:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:21:59 --> Controller Class Initialized
INFO - 2017-01-12 21:21:59 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:21:59 --> Helper loaded: form_helper
INFO - 2017-01-12 21:21:59 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 21:22:00 --> Config Class Initialized
INFO - 2017-01-12 21:22:00 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:00 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:00 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:00 --> URI Class Initialized
INFO - 2017-01-12 21:22:00 --> Router Class Initialized
INFO - 2017-01-12 21:22:00 --> Output Class Initialized
INFO - 2017-01-12 21:22:00 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:00 --> Input Class Initialized
INFO - 2017-01-12 21:22:00 --> Language Class Initialized
INFO - 2017-01-12 21:22:00 --> Loader Class Initialized
INFO - 2017-01-12 21:22:00 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:00 --> Controller Class Initialized
INFO - 2017-01-12 21:22:00 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:00 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:00 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:00 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:22:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:22:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 21:22:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 21:22:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:22:00 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:00 --> Total execution time: 0.2303
INFO - 2017-01-12 21:22:01 --> Config Class Initialized
INFO - 2017-01-12 21:22:01 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:01 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:01 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:01 --> URI Class Initialized
INFO - 2017-01-12 21:22:01 --> Router Class Initialized
INFO - 2017-01-12 21:22:01 --> Output Class Initialized
INFO - 2017-01-12 21:22:01 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:01 --> Input Class Initialized
INFO - 2017-01-12 21:22:01 --> Language Class Initialized
INFO - 2017-01-12 21:22:01 --> Loader Class Initialized
INFO - 2017-01-12 21:22:01 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:01 --> Controller Class Initialized
INFO - 2017-01-12 21:22:01 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:01 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:01 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:01 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:01 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:01 --> Total execution time: 0.0465
INFO - 2017-01-12 21:22:01 --> Config Class Initialized
INFO - 2017-01-12 21:22:01 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:01 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:01 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:01 --> URI Class Initialized
INFO - 2017-01-12 21:22:01 --> Router Class Initialized
INFO - 2017-01-12 21:22:01 --> Output Class Initialized
INFO - 2017-01-12 21:22:01 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:01 --> Input Class Initialized
INFO - 2017-01-12 21:22:01 --> Language Class Initialized
INFO - 2017-01-12 21:22:01 --> Loader Class Initialized
INFO - 2017-01-12 21:22:01 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:01 --> Controller Class Initialized
INFO - 2017-01-12 21:22:01 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:22:02 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:02 --> Total execution time: 0.3349
INFO - 2017-01-12 21:22:09 --> Config Class Initialized
INFO - 2017-01-12 21:22:09 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:09 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:09 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:09 --> URI Class Initialized
INFO - 2017-01-12 21:22:09 --> Router Class Initialized
INFO - 2017-01-12 21:22:09 --> Output Class Initialized
INFO - 2017-01-12 21:22:09 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:09 --> Input Class Initialized
INFO - 2017-01-12 21:22:09 --> Language Class Initialized
INFO - 2017-01-12 21:22:09 --> Loader Class Initialized
INFO - 2017-01-12 21:22:09 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:09 --> Controller Class Initialized
INFO - 2017-01-12 21:22:09 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:09 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:09 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:09 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:22:09 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:09 --> Total execution time: 0.1215
INFO - 2017-01-12 21:22:09 --> Config Class Initialized
INFO - 2017-01-12 21:22:09 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:09 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:09 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:09 --> URI Class Initialized
INFO - 2017-01-12 21:22:09 --> Router Class Initialized
INFO - 2017-01-12 21:22:09 --> Output Class Initialized
INFO - 2017-01-12 21:22:09 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:09 --> Input Class Initialized
INFO - 2017-01-12 21:22:09 --> Language Class Initialized
INFO - 2017-01-12 21:22:09 --> Loader Class Initialized
INFO - 2017-01-12 21:22:09 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:09 --> Controller Class Initialized
INFO - 2017-01-12 21:22:09 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:09 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:09 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:09 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:09 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:09 --> Total execution time: 0.0381
INFO - 2017-01-12 21:22:09 --> Config Class Initialized
INFO - 2017-01-12 21:22:09 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:09 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:09 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:09 --> URI Class Initialized
INFO - 2017-01-12 21:22:09 --> Router Class Initialized
INFO - 2017-01-12 21:22:09 --> Output Class Initialized
INFO - 2017-01-12 21:22:09 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:09 --> Input Class Initialized
INFO - 2017-01-12 21:22:09 --> Language Class Initialized
INFO - 2017-01-12 21:22:09 --> Loader Class Initialized
INFO - 2017-01-12 21:22:09 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:09 --> Controller Class Initialized
INFO - 2017-01-12 21:22:09 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:22:09 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:09 --> Total execution time: 0.0446
INFO - 2017-01-12 21:22:32 --> Config Class Initialized
INFO - 2017-01-12 21:22:32 --> Hooks Class Initialized
INFO - 2017-01-12 21:22:32 --> Config Class Initialized
INFO - 2017-01-12 21:22:32 --> Hooks Class Initialized
INFO - 2017-01-12 21:22:32 --> Config Class Initialized
INFO - 2017-01-12 21:22:32 --> Hooks Class Initialized
INFO - 2017-01-12 21:22:32 --> Config Class Initialized
INFO - 2017-01-12 21:22:32 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:33 --> UTF-8 Support Enabled
DEBUG - 2017-01-12 21:22:33 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:33 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:33 --> Utf8 Class Initialized
DEBUG - 2017-01-12 21:22:33 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:33 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:33 --> URI Class Initialized
INFO - 2017-01-12 21:22:33 --> URI Class Initialized
DEBUG - 2017-01-12 21:22:33 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:33 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:33 --> URI Class Initialized
INFO - 2017-01-12 21:22:33 --> URI Class Initialized
INFO - 2017-01-12 21:22:33 --> Router Class Initialized
INFO - 2017-01-12 21:22:33 --> Router Class Initialized
INFO - 2017-01-12 21:22:33 --> Router Class Initialized
INFO - 2017-01-12 21:22:33 --> Router Class Initialized
INFO - 2017-01-12 21:22:33 --> Output Class Initialized
INFO - 2017-01-12 21:22:33 --> Output Class Initialized
INFO - 2017-01-12 21:22:33 --> Output Class Initialized
INFO - 2017-01-12 21:22:33 --> Output Class Initialized
INFO - 2017-01-12 21:22:33 --> Security Class Initialized
INFO - 2017-01-12 21:22:33 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:33 --> Input Class Initialized
INFO - 2017-01-12 21:22:33 --> Language Class Initialized
INFO - 2017-01-12 21:22:33 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:33 --> Input Class Initialized
INFO - 2017-01-12 21:22:33 --> Language Class Initialized
INFO - 2017-01-12 21:22:33 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:33 --> Input Class Initialized
INFO - 2017-01-12 21:22:33 --> Language Class Initialized
DEBUG - 2017-01-12 21:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:33 --> Input Class Initialized
INFO - 2017-01-12 21:22:33 --> Language Class Initialized
INFO - 2017-01-12 21:22:33 --> Loader Class Initialized
INFO - 2017-01-12 21:22:33 --> Loader Class Initialized
INFO - 2017-01-12 21:22:33 --> Loader Class Initialized
INFO - 2017-01-12 21:22:33 --> Loader Class Initialized
INFO - 2017-01-12 21:22:33 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:34 --> Controller Class Initialized
INFO - 2017-01-12 21:22:34 --> Upload Class Initialized
INFO - 2017-01-12 21:22:34 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:22:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:34 --> Total execution time: 1.7823
INFO - 2017-01-12 21:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:34 --> Controller Class Initialized
INFO - 2017-01-12 21:22:34 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:22:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:34 --> Total execution time: 1.8215
INFO - 2017-01-12 21:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:34 --> Controller Class Initialized
INFO - 2017-01-12 21:22:34 --> Upload Class Initialized
INFO - 2017-01-12 21:22:34 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:22:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:34 --> Total execution time: 1.8282
INFO - 2017-01-12 21:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:34 --> Controller Class Initialized
INFO - 2017-01-12 21:22:34 --> Upload Class Initialized
INFO - 2017-01-12 21:22:34 --> Helper loaded: date_helper
INFO - 2017-01-12 21:22:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:22:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:22:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:34 --> Total execution time: 1.8399
INFO - 2017-01-12 21:22:35 --> Config Class Initialized
INFO - 2017-01-12 21:22:35 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:35 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:35 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:35 --> URI Class Initialized
INFO - 2017-01-12 21:22:35 --> Router Class Initialized
INFO - 2017-01-12 21:22:35 --> Output Class Initialized
INFO - 2017-01-12 21:22:35 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:35 --> Input Class Initialized
INFO - 2017-01-12 21:22:35 --> Language Class Initialized
INFO - 2017-01-12 21:22:35 --> Loader Class Initialized
INFO - 2017-01-12 21:22:35 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:35 --> Controller Class Initialized
INFO - 2017-01-12 21:22:35 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:22:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:22:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:22:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:22:35 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:35 --> Total execution time: 0.3015
INFO - 2017-01-12 21:22:54 --> Config Class Initialized
INFO - 2017-01-12 21:22:54 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:54 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:54 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:54 --> URI Class Initialized
INFO - 2017-01-12 21:22:54 --> Router Class Initialized
INFO - 2017-01-12 21:22:54 --> Output Class Initialized
INFO - 2017-01-12 21:22:54 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:54 --> Input Class Initialized
INFO - 2017-01-12 21:22:54 --> Language Class Initialized
INFO - 2017-01-12 21:22:54 --> Loader Class Initialized
INFO - 2017-01-12 21:22:54 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:54 --> Controller Class Initialized
INFO - 2017-01-12 21:22:54 --> Upload Class Initialized
INFO - 2017-01-12 21:22:54 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:54 --> Helper loaded: form_helper
INFO - 2017-01-12 21:22:54 --> Form Validation Class Initialized
INFO - 2017-01-12 21:22:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:22:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:22:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:22:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:22:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:22:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:22:54 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:54 --> Total execution time: 0.1386
INFO - 2017-01-12 21:22:55 --> Config Class Initialized
INFO - 2017-01-12 21:22:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:22:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:22:55 --> Utf8 Class Initialized
INFO - 2017-01-12 21:22:55 --> URI Class Initialized
INFO - 2017-01-12 21:22:55 --> Router Class Initialized
INFO - 2017-01-12 21:22:55 --> Output Class Initialized
INFO - 2017-01-12 21:22:55 --> Security Class Initialized
DEBUG - 2017-01-12 21:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:22:55 --> Input Class Initialized
INFO - 2017-01-12 21:22:55 --> Language Class Initialized
INFO - 2017-01-12 21:22:55 --> Loader Class Initialized
INFO - 2017-01-12 21:22:55 --> Database Driver Class Initialized
INFO - 2017-01-12 21:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:22:55 --> Controller Class Initialized
INFO - 2017-01-12 21:22:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:22:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:22:55 --> Final output sent to browser
DEBUG - 2017-01-12 21:22:55 --> Total execution time: 0.0148
INFO - 2017-01-12 21:23:07 --> Config Class Initialized
INFO - 2017-01-12 21:23:07 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:23:07 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:23:07 --> Utf8 Class Initialized
INFO - 2017-01-12 21:23:07 --> URI Class Initialized
INFO - 2017-01-12 21:23:07 --> Router Class Initialized
INFO - 2017-01-12 21:23:07 --> Output Class Initialized
INFO - 2017-01-12 21:23:07 --> Security Class Initialized
DEBUG - 2017-01-12 21:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:23:07 --> Input Class Initialized
INFO - 2017-01-12 21:23:07 --> Language Class Initialized
INFO - 2017-01-12 21:23:07 --> Loader Class Initialized
INFO - 2017-01-12 21:23:07 --> Database Driver Class Initialized
INFO - 2017-01-12 21:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:23:07 --> Controller Class Initialized
INFO - 2017-01-12 21:23:07 --> Upload Class Initialized
INFO - 2017-01-12 21:23:07 --> Helper loaded: date_helper
INFO - 2017-01-12 21:23:07 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:23:07 --> Helper loaded: form_helper
INFO - 2017-01-12 21:23:07 --> Form Validation Class Initialized
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:23:07 --> Final output sent to browser
DEBUG - 2017-01-12 21:23:07 --> Total execution time: 0.0163
INFO - 2017-01-12 21:23:07 --> Config Class Initialized
INFO - 2017-01-12 21:23:07 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:23:07 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:23:07 --> Utf8 Class Initialized
INFO - 2017-01-12 21:23:07 --> URI Class Initialized
INFO - 2017-01-12 21:23:07 --> Router Class Initialized
INFO - 2017-01-12 21:23:07 --> Output Class Initialized
INFO - 2017-01-12 21:23:07 --> Security Class Initialized
DEBUG - 2017-01-12 21:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:23:07 --> Input Class Initialized
INFO - 2017-01-12 21:23:07 --> Language Class Initialized
INFO - 2017-01-12 21:23:07 --> Loader Class Initialized
INFO - 2017-01-12 21:23:07 --> Database Driver Class Initialized
INFO - 2017-01-12 21:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:23:07 --> Controller Class Initialized
INFO - 2017-01-12 21:23:07 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:23:07 --> Final output sent to browser
DEBUG - 2017-01-12 21:23:07 --> Total execution time: 0.1221
INFO - 2017-01-12 21:23:12 --> Config Class Initialized
INFO - 2017-01-12 21:23:12 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:23:12 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:23:12 --> Utf8 Class Initialized
INFO - 2017-01-12 21:23:12 --> URI Class Initialized
INFO - 2017-01-12 21:23:12 --> Router Class Initialized
INFO - 2017-01-12 21:23:12 --> Output Class Initialized
INFO - 2017-01-12 21:23:12 --> Security Class Initialized
DEBUG - 2017-01-12 21:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:23:12 --> Input Class Initialized
INFO - 2017-01-12 21:23:12 --> Language Class Initialized
INFO - 2017-01-12 21:23:12 --> Loader Class Initialized
INFO - 2017-01-12 21:23:12 --> Database Driver Class Initialized
INFO - 2017-01-12 21:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:23:12 --> Controller Class Initialized
INFO - 2017-01-12 21:23:12 --> Upload Class Initialized
INFO - 2017-01-12 21:23:12 --> Helper loaded: date_helper
INFO - 2017-01-12 21:23:12 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:23:12 --> Helper loaded: form_helper
INFO - 2017-01-12 21:23:12 --> Form Validation Class Initialized
INFO - 2017-01-12 21:23:12 --> Final output sent to browser
DEBUG - 2017-01-12 21:23:12 --> Total execution time: 0.0154
INFO - 2017-01-12 21:23:40 --> Config Class Initialized
INFO - 2017-01-12 21:23:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:23:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:23:40 --> Utf8 Class Initialized
INFO - 2017-01-12 21:23:40 --> URI Class Initialized
INFO - 2017-01-12 21:23:40 --> Router Class Initialized
INFO - 2017-01-12 21:23:40 --> Output Class Initialized
INFO - 2017-01-12 21:23:40 --> Security Class Initialized
DEBUG - 2017-01-12 21:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:23:40 --> Input Class Initialized
INFO - 2017-01-12 21:23:40 --> Language Class Initialized
INFO - 2017-01-12 21:23:40 --> Loader Class Initialized
INFO - 2017-01-12 21:23:40 --> Database Driver Class Initialized
INFO - 2017-01-12 21:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:23:40 --> Controller Class Initialized
INFO - 2017-01-12 21:23:40 --> Upload Class Initialized
INFO - 2017-01-12 21:23:40 --> Helper loaded: date_helper
INFO - 2017-01-12 21:23:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:23:40 --> Helper loaded: form_helper
INFO - 2017-01-12 21:23:40 --> Form Validation Class Initialized
INFO - 2017-01-12 21:23:40 --> Final output sent to browser
DEBUG - 2017-01-12 21:23:40 --> Total execution time: 0.0162
INFO - 2017-01-12 21:23:45 --> Config Class Initialized
INFO - 2017-01-12 21:23:45 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:23:45 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:23:45 --> Utf8 Class Initialized
INFO - 2017-01-12 21:23:45 --> URI Class Initialized
INFO - 2017-01-12 21:23:45 --> Router Class Initialized
INFO - 2017-01-12 21:23:45 --> Output Class Initialized
INFO - 2017-01-12 21:23:45 --> Security Class Initialized
DEBUG - 2017-01-12 21:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:23:45 --> Input Class Initialized
INFO - 2017-01-12 21:23:45 --> Language Class Initialized
INFO - 2017-01-12 21:23:45 --> Loader Class Initialized
INFO - 2017-01-12 21:23:45 --> Database Driver Class Initialized
INFO - 2017-01-12 21:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:23:45 --> Controller Class Initialized
INFO - 2017-01-12 21:23:45 --> Upload Class Initialized
INFO - 2017-01-12 21:23:45 --> Helper loaded: date_helper
INFO - 2017-01-12 21:23:45 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:23:46 --> Helper loaded: form_helper
INFO - 2017-01-12 21:23:46 --> Form Validation Class Initialized
INFO - 2017-01-12 21:23:46 --> Final output sent to browser
DEBUG - 2017-01-12 21:23:46 --> Total execution time: 1.0836
INFO - 2017-01-12 21:25:38 --> Config Class Initialized
INFO - 2017-01-12 21:25:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:25:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:25:38 --> Utf8 Class Initialized
INFO - 2017-01-12 21:25:38 --> URI Class Initialized
INFO - 2017-01-12 21:25:38 --> Router Class Initialized
INFO - 2017-01-12 21:25:39 --> Output Class Initialized
INFO - 2017-01-12 21:25:39 --> Security Class Initialized
DEBUG - 2017-01-12 21:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:25:39 --> Input Class Initialized
INFO - 2017-01-12 21:25:39 --> Language Class Initialized
INFO - 2017-01-12 21:25:39 --> Loader Class Initialized
INFO - 2017-01-12 21:25:39 --> Database Driver Class Initialized
INFO - 2017-01-12 21:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:25:39 --> Controller Class Initialized
INFO - 2017-01-12 21:25:39 --> Upload Class Initialized
INFO - 2017-01-12 21:25:39 --> Helper loaded: date_helper
INFO - 2017-01-12 21:25:39 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:25:39 --> Helper loaded: form_helper
INFO - 2017-01-12 21:25:39 --> Form Validation Class Initialized
INFO - 2017-01-12 21:25:39 --> Final output sent to browser
DEBUG - 2017-01-12 21:25:39 --> Total execution time: 1.3410
INFO - 2017-01-12 21:25:50 --> Config Class Initialized
INFO - 2017-01-12 21:25:50 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:25:50 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:25:50 --> Utf8 Class Initialized
INFO - 2017-01-12 21:25:50 --> URI Class Initialized
INFO - 2017-01-12 21:25:50 --> Router Class Initialized
INFO - 2017-01-12 21:25:50 --> Output Class Initialized
INFO - 2017-01-12 21:25:50 --> Security Class Initialized
DEBUG - 2017-01-12 21:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:25:50 --> Input Class Initialized
INFO - 2017-01-12 21:25:50 --> Language Class Initialized
INFO - 2017-01-12 21:25:50 --> Loader Class Initialized
INFO - 2017-01-12 21:25:50 --> Database Driver Class Initialized
INFO - 2017-01-12 21:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:25:50 --> Controller Class Initialized
INFO - 2017-01-12 21:25:50 --> Upload Class Initialized
INFO - 2017-01-12 21:25:50 --> Helper loaded: date_helper
INFO - 2017-01-12 21:25:50 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:25:50 --> Helper loaded: form_helper
INFO - 2017-01-12 21:25:50 --> Form Validation Class Initialized
INFO - 2017-01-12 21:25:50 --> Final output sent to browser
DEBUG - 2017-01-12 21:25:50 --> Total execution time: 0.0156
INFO - 2017-01-12 21:26:03 --> Config Class Initialized
INFO - 2017-01-12 21:26:03 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:26:03 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:26:03 --> Utf8 Class Initialized
INFO - 2017-01-12 21:26:03 --> URI Class Initialized
INFO - 2017-01-12 21:26:03 --> Router Class Initialized
INFO - 2017-01-12 21:26:03 --> Output Class Initialized
INFO - 2017-01-12 21:26:03 --> Security Class Initialized
DEBUG - 2017-01-12 21:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:26:03 --> Input Class Initialized
INFO - 2017-01-12 21:26:03 --> Language Class Initialized
INFO - 2017-01-12 21:26:03 --> Loader Class Initialized
INFO - 2017-01-12 21:26:03 --> Database Driver Class Initialized
INFO - 2017-01-12 21:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:26:03 --> Controller Class Initialized
INFO - 2017-01-12 21:26:03 --> Helper loaded: date_helper
INFO - 2017-01-12 21:26:03 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:26:03 --> Helper loaded: form_helper
INFO - 2017-01-12 21:26:03 --> Form Validation Class Initialized
INFO - 2017-01-12 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:26:03 --> Final output sent to browser
DEBUG - 2017-01-12 21:26:03 --> Total execution time: 0.1546
INFO - 2017-01-12 21:26:04 --> Config Class Initialized
INFO - 2017-01-12 21:26:04 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:26:04 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:26:04 --> Utf8 Class Initialized
INFO - 2017-01-12 21:26:04 --> URI Class Initialized
INFO - 2017-01-12 21:26:04 --> Router Class Initialized
INFO - 2017-01-12 21:26:04 --> Output Class Initialized
INFO - 2017-01-12 21:26:04 --> Security Class Initialized
DEBUG - 2017-01-12 21:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:26:04 --> Input Class Initialized
INFO - 2017-01-12 21:26:04 --> Language Class Initialized
INFO - 2017-01-12 21:26:04 --> Loader Class Initialized
INFO - 2017-01-12 21:26:04 --> Database Driver Class Initialized
INFO - 2017-01-12 21:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:26:04 --> Controller Class Initialized
INFO - 2017-01-12 21:26:04 --> Helper loaded: date_helper
INFO - 2017-01-12 21:26:04 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:26:04 --> Helper loaded: form_helper
INFO - 2017-01-12 21:26:04 --> Form Validation Class Initialized
INFO - 2017-01-12 21:26:04 --> Final output sent to browser
DEBUG - 2017-01-12 21:26:04 --> Total execution time: 0.0148
INFO - 2017-01-12 21:26:04 --> Config Class Initialized
INFO - 2017-01-12 21:26:04 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:26:04 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:26:04 --> Utf8 Class Initialized
INFO - 2017-01-12 21:26:04 --> URI Class Initialized
INFO - 2017-01-12 21:26:04 --> Router Class Initialized
INFO - 2017-01-12 21:26:04 --> Output Class Initialized
INFO - 2017-01-12 21:26:04 --> Security Class Initialized
DEBUG - 2017-01-12 21:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:26:04 --> Input Class Initialized
INFO - 2017-01-12 21:26:04 --> Language Class Initialized
INFO - 2017-01-12 21:26:04 --> Loader Class Initialized
INFO - 2017-01-12 21:26:04 --> Database Driver Class Initialized
INFO - 2017-01-12 21:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:26:04 --> Controller Class Initialized
INFO - 2017-01-12 21:26:04 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:26:04 --> Final output sent to browser
DEBUG - 2017-01-12 21:26:04 --> Total execution time: 0.2634
INFO - 2017-01-12 21:26:40 --> Config Class Initialized
INFO - 2017-01-12 21:26:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:26:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:26:40 --> Utf8 Class Initialized
INFO - 2017-01-12 21:26:40 --> URI Class Initialized
INFO - 2017-01-12 21:26:40 --> Router Class Initialized
INFO - 2017-01-12 21:26:40 --> Output Class Initialized
INFO - 2017-01-12 21:26:40 --> Security Class Initialized
DEBUG - 2017-01-12 21:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:26:40 --> Input Class Initialized
INFO - 2017-01-12 21:26:40 --> Language Class Initialized
INFO - 2017-01-12 21:26:40 --> Loader Class Initialized
INFO - 2017-01-12 21:26:40 --> Database Driver Class Initialized
INFO - 2017-01-12 21:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:26:40 --> Controller Class Initialized
INFO - 2017-01-12 21:26:40 --> Helper loaded: date_helper
INFO - 2017-01-12 21:26:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:26:40 --> Helper loaded: form_helper
INFO - 2017-01-12 21:26:40 --> Form Validation Class Initialized
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:26:40 --> Final output sent to browser
DEBUG - 2017-01-12 21:26:40 --> Total execution time: 0.0159
INFO - 2017-01-12 21:26:40 --> Config Class Initialized
INFO - 2017-01-12 21:26:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:26:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:26:40 --> Utf8 Class Initialized
INFO - 2017-01-12 21:26:40 --> URI Class Initialized
INFO - 2017-01-12 21:26:40 --> Router Class Initialized
INFO - 2017-01-12 21:26:40 --> Output Class Initialized
INFO - 2017-01-12 21:26:40 --> Security Class Initialized
DEBUG - 2017-01-12 21:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:26:40 --> Input Class Initialized
INFO - 2017-01-12 21:26:40 --> Language Class Initialized
INFO - 2017-01-12 21:26:40 --> Loader Class Initialized
INFO - 2017-01-12 21:26:40 --> Database Driver Class Initialized
INFO - 2017-01-12 21:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:26:40 --> Controller Class Initialized
INFO - 2017-01-12 21:26:40 --> Helper loaded: date_helper
INFO - 2017-01-12 21:26:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:26:40 --> Helper loaded: form_helper
INFO - 2017-01-12 21:26:40 --> Form Validation Class Initialized
INFO - 2017-01-12 21:26:40 --> Final output sent to browser
DEBUG - 2017-01-12 21:26:40 --> Total execution time: 0.0146
INFO - 2017-01-12 21:26:40 --> Config Class Initialized
INFO - 2017-01-12 21:26:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:26:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:26:40 --> Utf8 Class Initialized
INFO - 2017-01-12 21:26:40 --> URI Class Initialized
INFO - 2017-01-12 21:26:40 --> Router Class Initialized
INFO - 2017-01-12 21:26:40 --> Output Class Initialized
INFO - 2017-01-12 21:26:40 --> Security Class Initialized
DEBUG - 2017-01-12 21:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:26:40 --> Input Class Initialized
INFO - 2017-01-12 21:26:40 --> Language Class Initialized
INFO - 2017-01-12 21:26:40 --> Loader Class Initialized
INFO - 2017-01-12 21:26:40 --> Database Driver Class Initialized
INFO - 2017-01-12 21:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:26:40 --> Controller Class Initialized
INFO - 2017-01-12 21:26:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:26:40 --> Final output sent to browser
DEBUG - 2017-01-12 21:26:40 --> Total execution time: 0.0133
INFO - 2017-01-12 21:27:48 --> Config Class Initialized
INFO - 2017-01-12 21:27:48 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:27:48 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:27:48 --> Utf8 Class Initialized
INFO - 2017-01-12 21:27:48 --> URI Class Initialized
DEBUG - 2017-01-12 21:27:48 --> No URI present. Default controller set.
INFO - 2017-01-12 21:27:48 --> Router Class Initialized
INFO - 2017-01-12 21:27:48 --> Output Class Initialized
INFO - 2017-01-12 21:27:48 --> Security Class Initialized
DEBUG - 2017-01-12 21:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:27:48 --> Input Class Initialized
INFO - 2017-01-12 21:27:48 --> Language Class Initialized
INFO - 2017-01-12 21:27:48 --> Loader Class Initialized
INFO - 2017-01-12 21:27:49 --> Database Driver Class Initialized
INFO - 2017-01-12 21:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:27:49 --> Controller Class Initialized
INFO - 2017-01-12 21:27:49 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:27:50 --> Final output sent to browser
DEBUG - 2017-01-12 21:27:50 --> Total execution time: 1.7459
INFO - 2017-01-12 21:27:52 --> Config Class Initialized
INFO - 2017-01-12 21:27:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:27:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:27:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:27:52 --> URI Class Initialized
INFO - 2017-01-12 21:27:52 --> Router Class Initialized
INFO - 2017-01-12 21:27:52 --> Output Class Initialized
INFO - 2017-01-12 21:27:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:27:52 --> Input Class Initialized
INFO - 2017-01-12 21:27:52 --> Language Class Initialized
INFO - 2017-01-12 21:27:52 --> Loader Class Initialized
INFO - 2017-01-12 21:27:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:27:52 --> Controller Class Initialized
INFO - 2017-01-12 21:27:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:27:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:27:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:27:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:27:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:27:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:27:52 --> Total execution time: 0.0142
INFO - 2017-01-12 21:27:55 --> Config Class Initialized
INFO - 2017-01-12 21:27:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:27:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:27:55 --> Utf8 Class Initialized
INFO - 2017-01-12 21:27:55 --> URI Class Initialized
INFO - 2017-01-12 21:27:55 --> Router Class Initialized
INFO - 2017-01-12 21:27:55 --> Output Class Initialized
INFO - 2017-01-12 21:27:55 --> Security Class Initialized
DEBUG - 2017-01-12 21:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:27:55 --> Input Class Initialized
INFO - 2017-01-12 21:27:55 --> Language Class Initialized
INFO - 2017-01-12 21:27:55 --> Loader Class Initialized
INFO - 2017-01-12 21:27:55 --> Database Driver Class Initialized
INFO - 2017-01-12 21:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:27:55 --> Controller Class Initialized
INFO - 2017-01-12 21:27:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:27:55 --> Helper loaded: form_helper
INFO - 2017-01-12 21:27:55 --> Form Validation Class Initialized
INFO - 2017-01-12 21:27:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:27:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 21:27:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:27:55 --> Final output sent to browser
DEBUG - 2017-01-12 21:27:55 --> Total execution time: 0.1603
INFO - 2017-01-12 21:27:55 --> Config Class Initialized
INFO - 2017-01-12 21:27:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:27:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:27:55 --> Utf8 Class Initialized
INFO - 2017-01-12 21:27:55 --> URI Class Initialized
INFO - 2017-01-12 21:27:55 --> Router Class Initialized
INFO - 2017-01-12 21:27:55 --> Output Class Initialized
INFO - 2017-01-12 21:27:55 --> Security Class Initialized
DEBUG - 2017-01-12 21:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:27:55 --> Input Class Initialized
INFO - 2017-01-12 21:27:55 --> Language Class Initialized
INFO - 2017-01-12 21:27:55 --> Loader Class Initialized
INFO - 2017-01-12 21:27:55 --> Database Driver Class Initialized
INFO - 2017-01-12 21:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:27:55 --> Controller Class Initialized
INFO - 2017-01-12 21:27:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:27:55 --> Helper loaded: form_helper
INFO - 2017-01-12 21:27:55 --> Form Validation Class Initialized
INFO - 2017-01-12 21:27:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:27:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 21:27:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:27:55 --> Final output sent to browser
DEBUG - 2017-01-12 21:27:55 --> Total execution time: 0.0687
INFO - 2017-01-12 21:27:56 --> Config Class Initialized
INFO - 2017-01-12 21:27:56 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:27:56 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:27:56 --> Utf8 Class Initialized
INFO - 2017-01-12 21:27:56 --> URI Class Initialized
INFO - 2017-01-12 21:27:56 --> Router Class Initialized
INFO - 2017-01-12 21:27:56 --> Output Class Initialized
INFO - 2017-01-12 21:27:56 --> Security Class Initialized
DEBUG - 2017-01-12 21:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:27:56 --> Input Class Initialized
INFO - 2017-01-12 21:27:56 --> Language Class Initialized
INFO - 2017-01-12 21:27:56 --> Loader Class Initialized
INFO - 2017-01-12 21:27:56 --> Database Driver Class Initialized
INFO - 2017-01-12 21:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:27:56 --> Controller Class Initialized
INFO - 2017-01-12 21:27:56 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:27:56 --> Final output sent to browser
DEBUG - 2017-01-12 21:27:56 --> Total execution time: 0.0136
INFO - 2017-01-12 21:27:56 --> Config Class Initialized
INFO - 2017-01-12 21:27:56 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:27:56 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:27:56 --> Utf8 Class Initialized
INFO - 2017-01-12 21:27:56 --> URI Class Initialized
INFO - 2017-01-12 21:27:56 --> Router Class Initialized
INFO - 2017-01-12 21:27:56 --> Output Class Initialized
INFO - 2017-01-12 21:27:56 --> Security Class Initialized
DEBUG - 2017-01-12 21:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:27:56 --> Input Class Initialized
INFO - 2017-01-12 21:27:56 --> Language Class Initialized
INFO - 2017-01-12 21:27:56 --> Loader Class Initialized
INFO - 2017-01-12 21:27:56 --> Database Driver Class Initialized
INFO - 2017-01-12 21:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:27:56 --> Controller Class Initialized
INFO - 2017-01-12 21:27:56 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:27:56 --> Final output sent to browser
DEBUG - 2017-01-12 21:27:56 --> Total execution time: 0.0142
INFO - 2017-01-12 21:28:20 --> Config Class Initialized
INFO - 2017-01-12 21:28:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:20 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:20 --> URI Class Initialized
INFO - 2017-01-12 21:28:20 --> Router Class Initialized
INFO - 2017-01-12 21:28:20 --> Output Class Initialized
INFO - 2017-01-12 21:28:20 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:20 --> Input Class Initialized
INFO - 2017-01-12 21:28:20 --> Language Class Initialized
INFO - 2017-01-12 21:28:20 --> Loader Class Initialized
INFO - 2017-01-12 21:28:21 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:21 --> Controller Class Initialized
INFO - 2017-01-12 21:28:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:21 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:21 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 21:28:22 --> Config Class Initialized
INFO - 2017-01-12 21:28:22 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:22 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:22 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:22 --> URI Class Initialized
INFO - 2017-01-12 21:28:22 --> Router Class Initialized
INFO - 2017-01-12 21:28:22 --> Output Class Initialized
INFO - 2017-01-12 21:28:22 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:22 --> Input Class Initialized
INFO - 2017-01-12 21:28:22 --> Language Class Initialized
INFO - 2017-01-12 21:28:22 --> Loader Class Initialized
INFO - 2017-01-12 21:28:22 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:22 --> Controller Class Initialized
INFO - 2017-01-12 21:28:22 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:22 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:22 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:22 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:28:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:28:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 21:28:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 21:28:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:28:22 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:22 --> Total execution time: 0.6021
INFO - 2017-01-12 21:28:23 --> Config Class Initialized
INFO - 2017-01-12 21:28:23 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:23 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:23 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:23 --> URI Class Initialized
INFO - 2017-01-12 21:28:23 --> Router Class Initialized
INFO - 2017-01-12 21:28:23 --> Output Class Initialized
INFO - 2017-01-12 21:28:23 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:23 --> Input Class Initialized
INFO - 2017-01-12 21:28:23 --> Language Class Initialized
INFO - 2017-01-12 21:28:23 --> Loader Class Initialized
INFO - 2017-01-12 21:28:23 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:23 --> Controller Class Initialized
INFO - 2017-01-12 21:28:23 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:23 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:23 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:23 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:23 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:23 --> Total execution time: 0.0160
INFO - 2017-01-12 21:28:23 --> Config Class Initialized
INFO - 2017-01-12 21:28:23 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:23 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:23 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:23 --> URI Class Initialized
INFO - 2017-01-12 21:28:23 --> Router Class Initialized
INFO - 2017-01-12 21:28:23 --> Output Class Initialized
INFO - 2017-01-12 21:28:23 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:23 --> Input Class Initialized
INFO - 2017-01-12 21:28:23 --> Language Class Initialized
INFO - 2017-01-12 21:28:23 --> Loader Class Initialized
INFO - 2017-01-12 21:28:23 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:23 --> Controller Class Initialized
INFO - 2017-01-12 21:28:23 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:28:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:28:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:28:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:28:24 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:24 --> Total execution time: 0.3092
INFO - 2017-01-12 21:28:26 --> Config Class Initialized
INFO - 2017-01-12 21:28:26 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:26 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:26 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:26 --> URI Class Initialized
DEBUG - 2017-01-12 21:28:26 --> No URI present. Default controller set.
INFO - 2017-01-12 21:28:26 --> Router Class Initialized
INFO - 2017-01-12 21:28:26 --> Output Class Initialized
INFO - 2017-01-12 21:28:26 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:26 --> Input Class Initialized
INFO - 2017-01-12 21:28:26 --> Language Class Initialized
INFO - 2017-01-12 21:28:26 --> Loader Class Initialized
INFO - 2017-01-12 21:28:26 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:26 --> Controller Class Initialized
INFO - 2017-01-12 21:28:26 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:28:26 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:26 --> Total execution time: 0.0361
INFO - 2017-01-12 21:28:26 --> Config Class Initialized
INFO - 2017-01-12 21:28:26 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:26 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:26 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:26 --> URI Class Initialized
INFO - 2017-01-12 21:28:26 --> Router Class Initialized
INFO - 2017-01-12 21:28:26 --> Output Class Initialized
INFO - 2017-01-12 21:28:26 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:26 --> Input Class Initialized
INFO - 2017-01-12 21:28:26 --> Language Class Initialized
INFO - 2017-01-12 21:28:26 --> Loader Class Initialized
INFO - 2017-01-12 21:28:26 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:26 --> Controller Class Initialized
INFO - 2017-01-12 21:28:26 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:26 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:26 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:26 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:28:26 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:26 --> Total execution time: 0.0832
INFO - 2017-01-12 21:28:26 --> Config Class Initialized
INFO - 2017-01-12 21:28:26 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:26 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:26 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:26 --> URI Class Initialized
INFO - 2017-01-12 21:28:26 --> Router Class Initialized
INFO - 2017-01-12 21:28:26 --> Output Class Initialized
INFO - 2017-01-12 21:28:26 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:26 --> Input Class Initialized
INFO - 2017-01-12 21:28:26 --> Language Class Initialized
INFO - 2017-01-12 21:28:26 --> Loader Class Initialized
INFO - 2017-01-12 21:28:26 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:26 --> Controller Class Initialized
INFO - 2017-01-12 21:28:26 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:28:26 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:26 --> Total execution time: 0.0247
INFO - 2017-01-12 21:28:27 --> Config Class Initialized
INFO - 2017-01-12 21:28:27 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:27 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:27 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:27 --> URI Class Initialized
INFO - 2017-01-12 21:28:27 --> Router Class Initialized
INFO - 2017-01-12 21:28:27 --> Output Class Initialized
INFO - 2017-01-12 21:28:27 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:27 --> Input Class Initialized
INFO - 2017-01-12 21:28:27 --> Language Class Initialized
INFO - 2017-01-12 21:28:27 --> Loader Class Initialized
INFO - 2017-01-12 21:28:27 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:27 --> Controller Class Initialized
INFO - 2017-01-12 21:28:27 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:27 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:27 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:27 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:27 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:27 --> Total execution time: 0.0194
INFO - 2017-01-12 21:28:29 --> Config Class Initialized
INFO - 2017-01-12 21:28:29 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:29 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:29 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:29 --> URI Class Initialized
INFO - 2017-01-12 21:28:29 --> Router Class Initialized
INFO - 2017-01-12 21:28:29 --> Output Class Initialized
INFO - 2017-01-12 21:28:29 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:29 --> Input Class Initialized
INFO - 2017-01-12 21:28:29 --> Language Class Initialized
INFO - 2017-01-12 21:28:29 --> Loader Class Initialized
INFO - 2017-01-12 21:28:29 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:29 --> Controller Class Initialized
INFO - 2017-01-12 21:28:29 --> Upload Class Initialized
INFO - 2017-01-12 21:28:29 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:29 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:29 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:29 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:28:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:28:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:28:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:28:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:28:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:28:29 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:29 --> Total execution time: 0.1165
INFO - 2017-01-12 21:28:30 --> Config Class Initialized
INFO - 2017-01-12 21:28:30 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:30 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:30 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:30 --> URI Class Initialized
INFO - 2017-01-12 21:28:30 --> Router Class Initialized
INFO - 2017-01-12 21:28:30 --> Output Class Initialized
INFO - 2017-01-12 21:28:30 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:30 --> Input Class Initialized
INFO - 2017-01-12 21:28:30 --> Language Class Initialized
INFO - 2017-01-12 21:28:30 --> Loader Class Initialized
INFO - 2017-01-12 21:28:30 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:30 --> Controller Class Initialized
INFO - 2017-01-12 21:28:30 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:34 --> Config Class Initialized
INFO - 2017-01-12 21:28:34 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:34 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:34 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:34 --> URI Class Initialized
INFO - 2017-01-12 21:28:34 --> Router Class Initialized
INFO - 2017-01-12 21:28:34 --> Output Class Initialized
INFO - 2017-01-12 21:28:34 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:34 --> Input Class Initialized
INFO - 2017-01-12 21:28:34 --> Language Class Initialized
INFO - 2017-01-12 21:28:34 --> Loader Class Initialized
INFO - 2017-01-12 21:28:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:34 --> Controller Class Initialized
INFO - 2017-01-12 21:28:34 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:34 --> Helper loaded: url_helper
INFO - 2017-01-12 21:28:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:28:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:28:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 21:28:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 21:28:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:28:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:34 --> Total execution time: 0.0969
INFO - 2017-01-12 21:28:35 --> Config Class Initialized
INFO - 2017-01-12 21:28:35 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:35 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:35 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:35 --> URI Class Initialized
INFO - 2017-01-12 21:28:35 --> Router Class Initialized
INFO - 2017-01-12 21:28:35 --> Output Class Initialized
INFO - 2017-01-12 21:28:35 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:35 --> Input Class Initialized
INFO - 2017-01-12 21:28:35 --> Language Class Initialized
INFO - 2017-01-12 21:28:35 --> Loader Class Initialized
INFO - 2017-01-12 21:28:35 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:35 --> Controller Class Initialized
INFO - 2017-01-12 21:28:35 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:28:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:28:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:28:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:28:35 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:35 --> Total execution time: 0.0137
INFO - 2017-01-12 21:28:42 --> Config Class Initialized
INFO - 2017-01-12 21:28:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:42 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:42 --> URI Class Initialized
INFO - 2017-01-12 21:28:42 --> Router Class Initialized
INFO - 2017-01-12 21:28:42 --> Output Class Initialized
INFO - 2017-01-12 21:28:42 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:42 --> Input Class Initialized
INFO - 2017-01-12 21:28:42 --> Language Class Initialized
INFO - 2017-01-12 21:28:42 --> Loader Class Initialized
INFO - 2017-01-12 21:28:42 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:42 --> Controller Class Initialized
INFO - 2017-01-12 21:28:42 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:42 --> Helper loaded: url_helper
INFO - 2017-01-12 21:28:42 --> Helper loaded: download_helper
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:28:42 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:42 --> Total execution time: 0.1010
INFO - 2017-01-12 21:28:42 --> Config Class Initialized
INFO - 2017-01-12 21:28:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:42 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:42 --> URI Class Initialized
INFO - 2017-01-12 21:28:42 --> Router Class Initialized
INFO - 2017-01-12 21:28:42 --> Output Class Initialized
INFO - 2017-01-12 21:28:42 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:42 --> Input Class Initialized
INFO - 2017-01-12 21:28:42 --> Language Class Initialized
INFO - 2017-01-12 21:28:42 --> Loader Class Initialized
INFO - 2017-01-12 21:28:42 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:42 --> Controller Class Initialized
INFO - 2017-01-12 21:28:42 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:28:42 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:42 --> Total execution time: 0.0386
INFO - 2017-01-12 21:28:43 --> Config Class Initialized
INFO - 2017-01-12 21:28:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:43 --> URI Class Initialized
INFO - 2017-01-12 21:28:43 --> Router Class Initialized
INFO - 2017-01-12 21:28:43 --> Output Class Initialized
INFO - 2017-01-12 21:28:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:43 --> Input Class Initialized
INFO - 2017-01-12 21:28:43 --> Language Class Initialized
INFO - 2017-01-12 21:28:43 --> Loader Class Initialized
INFO - 2017-01-12 21:28:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:43 --> Controller Class Initialized
INFO - 2017-01-12 21:28:43 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:43 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:43 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:28:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:28:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 21:28:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 21:28:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:28:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:43 --> Total execution time: 0.0160
INFO - 2017-01-12 21:28:43 --> Config Class Initialized
INFO - 2017-01-12 21:28:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:43 --> URI Class Initialized
INFO - 2017-01-12 21:28:43 --> Router Class Initialized
INFO - 2017-01-12 21:28:43 --> Output Class Initialized
INFO - 2017-01-12 21:28:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:43 --> Input Class Initialized
INFO - 2017-01-12 21:28:43 --> Language Class Initialized
INFO - 2017-01-12 21:28:43 --> Loader Class Initialized
INFO - 2017-01-12 21:28:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:43 --> Controller Class Initialized
INFO - 2017-01-12 21:28:43 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:43 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:43 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:43 --> Total execution time: 0.0156
INFO - 2017-01-12 21:28:55 --> Config Class Initialized
INFO - 2017-01-12 21:28:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:28:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:28:55 --> Utf8 Class Initialized
INFO - 2017-01-12 21:28:55 --> URI Class Initialized
INFO - 2017-01-12 21:28:55 --> Router Class Initialized
INFO - 2017-01-12 21:28:55 --> Output Class Initialized
INFO - 2017-01-12 21:28:55 --> Security Class Initialized
DEBUG - 2017-01-12 21:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:28:55 --> Input Class Initialized
INFO - 2017-01-12 21:28:55 --> Language Class Initialized
INFO - 2017-01-12 21:28:55 --> Loader Class Initialized
INFO - 2017-01-12 21:28:55 --> Database Driver Class Initialized
INFO - 2017-01-12 21:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:28:55 --> Controller Class Initialized
INFO - 2017-01-12 21:28:55 --> Upload Class Initialized
INFO - 2017-01-12 21:28:55 --> Helper loaded: date_helper
INFO - 2017-01-12 21:28:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:28:55 --> Helper loaded: form_helper
INFO - 2017-01-12 21:28:55 --> Form Validation Class Initialized
INFO - 2017-01-12 21:28:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:28:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:28:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:28:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:28:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:28:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:28:55 --> Final output sent to browser
DEBUG - 2017-01-12 21:28:55 --> Total execution time: 0.0164
INFO - 2017-01-12 21:29:05 --> Config Class Initialized
INFO - 2017-01-12 21:29:05 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:05 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:05 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:05 --> URI Class Initialized
INFO - 2017-01-12 21:29:05 --> Router Class Initialized
INFO - 2017-01-12 21:29:05 --> Output Class Initialized
INFO - 2017-01-12 21:29:05 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:05 --> Input Class Initialized
INFO - 2017-01-12 21:29:05 --> Language Class Initialized
INFO - 2017-01-12 21:29:05 --> Loader Class Initialized
INFO - 2017-01-12 21:29:05 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:05 --> Controller Class Initialized
INFO - 2017-01-12 21:29:05 --> Upload Class Initialized
INFO - 2017-01-12 21:29:06 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:06 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:06 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:06 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:06 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:06 --> Total execution time: 0.4667
INFO - 2017-01-12 21:29:08 --> Config Class Initialized
INFO - 2017-01-12 21:29:08 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:08 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:08 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:08 --> URI Class Initialized
INFO - 2017-01-12 21:29:08 --> Router Class Initialized
INFO - 2017-01-12 21:29:08 --> Output Class Initialized
INFO - 2017-01-12 21:29:08 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:08 --> Input Class Initialized
INFO - 2017-01-12 21:29:08 --> Language Class Initialized
INFO - 2017-01-12 21:29:08 --> Loader Class Initialized
INFO - 2017-01-12 21:29:08 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:08 --> Controller Class Initialized
INFO - 2017-01-12 21:29:08 --> Upload Class Initialized
INFO - 2017-01-12 21:29:08 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:08 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:08 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:08 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:08 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:08 --> Total execution time: 0.0240
INFO - 2017-01-12 21:29:09 --> Config Class Initialized
INFO - 2017-01-12 21:29:09 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:09 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:09 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:09 --> URI Class Initialized
INFO - 2017-01-12 21:29:09 --> Router Class Initialized
INFO - 2017-01-12 21:29:09 --> Output Class Initialized
INFO - 2017-01-12 21:29:09 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:09 --> Input Class Initialized
INFO - 2017-01-12 21:29:09 --> Language Class Initialized
INFO - 2017-01-12 21:29:09 --> Loader Class Initialized
INFO - 2017-01-12 21:29:09 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:09 --> Controller Class Initialized
INFO - 2017-01-12 21:29:09 --> Upload Class Initialized
INFO - 2017-01-12 21:29:09 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:09 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:09 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:09 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:09 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:09 --> Total execution time: 0.0151
INFO - 2017-01-12 21:29:13 --> Config Class Initialized
INFO - 2017-01-12 21:29:13 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:13 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:13 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:13 --> URI Class Initialized
INFO - 2017-01-12 21:29:13 --> Router Class Initialized
INFO - 2017-01-12 21:29:13 --> Output Class Initialized
INFO - 2017-01-12 21:29:13 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:13 --> Input Class Initialized
INFO - 2017-01-12 21:29:13 --> Language Class Initialized
INFO - 2017-01-12 21:29:13 --> Loader Class Initialized
INFO - 2017-01-12 21:29:13 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:13 --> Controller Class Initialized
INFO - 2017-01-12 21:29:13 --> Upload Class Initialized
INFO - 2017-01-12 21:29:13 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:13 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:13 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:13 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:13 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:13 --> Total execution time: 0.0153
INFO - 2017-01-12 21:29:45 --> Config Class Initialized
INFO - 2017-01-12 21:29:45 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:45 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:45 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:45 --> URI Class Initialized
INFO - 2017-01-12 21:29:45 --> Router Class Initialized
INFO - 2017-01-12 21:29:45 --> Output Class Initialized
INFO - 2017-01-12 21:29:45 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:45 --> Input Class Initialized
INFO - 2017-01-12 21:29:45 --> Language Class Initialized
INFO - 2017-01-12 21:29:45 --> Loader Class Initialized
INFO - 2017-01-12 21:29:45 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:45 --> Controller Class Initialized
INFO - 2017-01-12 21:29:45 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:45 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:45 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:45 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-12 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-12 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:29:45 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:45 --> Total execution time: 0.0437
INFO - 2017-01-12 21:29:45 --> Config Class Initialized
INFO - 2017-01-12 21:29:45 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:45 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:45 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:45 --> URI Class Initialized
INFO - 2017-01-12 21:29:45 --> Router Class Initialized
INFO - 2017-01-12 21:29:45 --> Output Class Initialized
INFO - 2017-01-12 21:29:45 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:45 --> Input Class Initialized
INFO - 2017-01-12 21:29:45 --> Language Class Initialized
INFO - 2017-01-12 21:29:45 --> Loader Class Initialized
INFO - 2017-01-12 21:29:45 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:45 --> Controller Class Initialized
INFO - 2017-01-12 21:29:45 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:45 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:45 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:45 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:45 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:45 --> Total execution time: 0.4079
INFO - 2017-01-12 21:29:51 --> Config Class Initialized
INFO - 2017-01-12 21:29:51 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:51 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:51 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:51 --> URI Class Initialized
INFO - 2017-01-12 21:29:51 --> Router Class Initialized
INFO - 2017-01-12 21:29:51 --> Output Class Initialized
INFO - 2017-01-12 21:29:51 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:51 --> Input Class Initialized
INFO - 2017-01-12 21:29:51 --> Language Class Initialized
INFO - 2017-01-12 21:29:51 --> Loader Class Initialized
INFO - 2017-01-12 21:29:51 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:51 --> Controller Class Initialized
INFO - 2017-01-12 21:29:51 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:51 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:51 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:51 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:51 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:51 --> Total execution time: 0.0148
INFO - 2017-01-12 21:29:55 --> Config Class Initialized
INFO - 2017-01-12 21:29:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:55 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:55 --> URI Class Initialized
INFO - 2017-01-12 21:29:55 --> Router Class Initialized
INFO - 2017-01-12 21:29:55 --> Output Class Initialized
INFO - 2017-01-12 21:29:55 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:55 --> Input Class Initialized
INFO - 2017-01-12 21:29:55 --> Language Class Initialized
INFO - 2017-01-12 21:29:55 --> Loader Class Initialized
INFO - 2017-01-12 21:29:55 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:55 --> Controller Class Initialized
INFO - 2017-01-12 21:29:55 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:55 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:55 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:55 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:55 --> Total execution time: 0.0153
INFO - 2017-01-12 21:29:56 --> Config Class Initialized
INFO - 2017-01-12 21:29:56 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:56 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:56 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:56 --> URI Class Initialized
INFO - 2017-01-12 21:29:56 --> Router Class Initialized
INFO - 2017-01-12 21:29:56 --> Output Class Initialized
INFO - 2017-01-12 21:29:56 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:56 --> Input Class Initialized
INFO - 2017-01-12 21:29:56 --> Language Class Initialized
INFO - 2017-01-12 21:29:56 --> Loader Class Initialized
INFO - 2017-01-12 21:29:56 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:56 --> Controller Class Initialized
INFO - 2017-01-12 21:29:56 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:56 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:56 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:56 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:56 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:56 --> Total execution time: 0.0156
INFO - 2017-01-12 21:29:57 --> Config Class Initialized
INFO - 2017-01-12 21:29:57 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:57 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:57 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:57 --> URI Class Initialized
INFO - 2017-01-12 21:29:57 --> Router Class Initialized
INFO - 2017-01-12 21:29:57 --> Output Class Initialized
INFO - 2017-01-12 21:29:57 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:57 --> Input Class Initialized
INFO - 2017-01-12 21:29:57 --> Language Class Initialized
INFO - 2017-01-12 21:29:57 --> Loader Class Initialized
INFO - 2017-01-12 21:29:57 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:57 --> Controller Class Initialized
INFO - 2017-01-12 21:29:57 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:57 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:57 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:57 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:57 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:57 --> Total execution time: 0.0154
INFO - 2017-01-12 21:29:58 --> Config Class Initialized
INFO - 2017-01-12 21:29:58 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:29:58 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:29:58 --> Utf8 Class Initialized
INFO - 2017-01-12 21:29:58 --> URI Class Initialized
INFO - 2017-01-12 21:29:58 --> Router Class Initialized
INFO - 2017-01-12 21:29:58 --> Output Class Initialized
INFO - 2017-01-12 21:29:58 --> Security Class Initialized
DEBUG - 2017-01-12 21:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:29:58 --> Input Class Initialized
INFO - 2017-01-12 21:29:58 --> Language Class Initialized
INFO - 2017-01-12 21:29:58 --> Loader Class Initialized
INFO - 2017-01-12 21:29:58 --> Database Driver Class Initialized
INFO - 2017-01-12 21:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:29:58 --> Controller Class Initialized
INFO - 2017-01-12 21:29:58 --> Helper loaded: date_helper
INFO - 2017-01-12 21:29:58 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:29:58 --> Helper loaded: form_helper
INFO - 2017-01-12 21:29:58 --> Form Validation Class Initialized
INFO - 2017-01-12 21:29:58 --> Final output sent to browser
DEBUG - 2017-01-12 21:29:58 --> Total execution time: 0.0145
INFO - 2017-01-12 21:30:14 --> Config Class Initialized
INFO - 2017-01-12 21:30:14 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:14 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:14 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:14 --> URI Class Initialized
INFO - 2017-01-12 21:30:14 --> Router Class Initialized
INFO - 2017-01-12 21:30:14 --> Output Class Initialized
INFO - 2017-01-12 21:30:14 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:14 --> Input Class Initialized
INFO - 2017-01-12 21:30:14 --> Language Class Initialized
INFO - 2017-01-12 21:30:14 --> Loader Class Initialized
INFO - 2017-01-12 21:30:14 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:14 --> Controller Class Initialized
INFO - 2017-01-12 21:30:14 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:14 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:14 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:14 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:14 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:14 --> Total execution time: 0.0150
INFO - 2017-01-12 21:30:15 --> Config Class Initialized
INFO - 2017-01-12 21:30:15 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:15 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:15 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:15 --> URI Class Initialized
INFO - 2017-01-12 21:30:15 --> Router Class Initialized
INFO - 2017-01-12 21:30:15 --> Output Class Initialized
INFO - 2017-01-12 21:30:15 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:15 --> Input Class Initialized
INFO - 2017-01-12 21:30:15 --> Language Class Initialized
INFO - 2017-01-12 21:30:15 --> Loader Class Initialized
INFO - 2017-01-12 21:30:15 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:15 --> Controller Class Initialized
INFO - 2017-01-12 21:30:15 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:15 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:15 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:15 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:15 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:15 --> Total execution time: 0.0154
INFO - 2017-01-12 21:30:20 --> Config Class Initialized
INFO - 2017-01-12 21:30:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:20 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:20 --> URI Class Initialized
INFO - 2017-01-12 21:30:20 --> Router Class Initialized
INFO - 2017-01-12 21:30:20 --> Output Class Initialized
INFO - 2017-01-12 21:30:20 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:20 --> Input Class Initialized
INFO - 2017-01-12 21:30:20 --> Language Class Initialized
INFO - 2017-01-12 21:30:20 --> Loader Class Initialized
INFO - 2017-01-12 21:30:20 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:20 --> Controller Class Initialized
INFO - 2017-01-12 21:30:20 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:20 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:20 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:20 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:20 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:20 --> Total execution time: 0.0241
INFO - 2017-01-12 21:30:20 --> Config Class Initialized
INFO - 2017-01-12 21:30:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:20 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:20 --> URI Class Initialized
INFO - 2017-01-12 21:30:20 --> Router Class Initialized
INFO - 2017-01-12 21:30:20 --> Output Class Initialized
INFO - 2017-01-12 21:30:20 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:20 --> Input Class Initialized
INFO - 2017-01-12 21:30:20 --> Language Class Initialized
INFO - 2017-01-12 21:30:20 --> Loader Class Initialized
INFO - 2017-01-12 21:30:20 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:20 --> Controller Class Initialized
INFO - 2017-01-12 21:30:20 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:20 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:20 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:20 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:20 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:20 --> Total execution time: 0.0142
INFO - 2017-01-12 21:30:21 --> Config Class Initialized
INFO - 2017-01-12 21:30:21 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:21 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:21 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:21 --> URI Class Initialized
INFO - 2017-01-12 21:30:21 --> Router Class Initialized
INFO - 2017-01-12 21:30:21 --> Output Class Initialized
INFO - 2017-01-12 21:30:21 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:21 --> Input Class Initialized
INFO - 2017-01-12 21:30:21 --> Language Class Initialized
INFO - 2017-01-12 21:30:21 --> Loader Class Initialized
INFO - 2017-01-12 21:30:21 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:21 --> Controller Class Initialized
INFO - 2017-01-12 21:30:21 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:21 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:21 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:21 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:21 --> Total execution time: 0.0140
INFO - 2017-01-12 21:30:32 --> Config Class Initialized
INFO - 2017-01-12 21:30:32 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:32 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:32 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:32 --> URI Class Initialized
INFO - 2017-01-12 21:30:32 --> Router Class Initialized
INFO - 2017-01-12 21:30:32 --> Output Class Initialized
INFO - 2017-01-12 21:30:32 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:32 --> Input Class Initialized
INFO - 2017-01-12 21:30:32 --> Language Class Initialized
INFO - 2017-01-12 21:30:32 --> Loader Class Initialized
INFO - 2017-01-12 21:30:32 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:32 --> Controller Class Initialized
INFO - 2017-01-12 21:30:32 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:32 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:32 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:32 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:32 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:32 --> Total execution time: 0.0140
INFO - 2017-01-12 21:30:38 --> Config Class Initialized
INFO - 2017-01-12 21:30:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:38 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:38 --> URI Class Initialized
INFO - 2017-01-12 21:30:38 --> Router Class Initialized
INFO - 2017-01-12 21:30:38 --> Output Class Initialized
INFO - 2017-01-12 21:30:38 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:38 --> Input Class Initialized
INFO - 2017-01-12 21:30:38 --> Language Class Initialized
INFO - 2017-01-12 21:30:38 --> Loader Class Initialized
INFO - 2017-01-12 21:30:38 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:38 --> Controller Class Initialized
INFO - 2017-01-12 21:30:38 --> Upload Class Initialized
INFO - 2017-01-12 21:30:38 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:38 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:38 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:30:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:30:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:30:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:30:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:30:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:30:38 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:38 --> Total execution time: 0.1942
INFO - 2017-01-12 21:30:38 --> Config Class Initialized
INFO - 2017-01-12 21:30:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:38 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:38 --> URI Class Initialized
INFO - 2017-01-12 21:30:38 --> Router Class Initialized
INFO - 2017-01-12 21:30:38 --> Output Class Initialized
INFO - 2017-01-12 21:30:38 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:38 --> Input Class Initialized
INFO - 2017-01-12 21:30:38 --> Language Class Initialized
INFO - 2017-01-12 21:30:38 --> Loader Class Initialized
INFO - 2017-01-12 21:30:38 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:38 --> Controller Class Initialized
INFO - 2017-01-12 21:30:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:30:39 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:39 --> Total execution time: 0.2881
INFO - 2017-01-12 21:30:41 --> Config Class Initialized
INFO - 2017-01-12 21:30:41 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:41 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:41 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:41 --> URI Class Initialized
INFO - 2017-01-12 21:30:41 --> Router Class Initialized
INFO - 2017-01-12 21:30:41 --> Output Class Initialized
INFO - 2017-01-12 21:30:41 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:41 --> Input Class Initialized
INFO - 2017-01-12 21:30:41 --> Language Class Initialized
INFO - 2017-01-12 21:30:41 --> Loader Class Initialized
INFO - 2017-01-12 21:30:41 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:41 --> Controller Class Initialized
INFO - 2017-01-12 21:30:41 --> Upload Class Initialized
INFO - 2017-01-12 21:30:41 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:41 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:41 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:41 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:41 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:41 --> Total execution time: 0.0155
INFO - 2017-01-12 21:30:44 --> Config Class Initialized
INFO - 2017-01-12 21:30:44 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:30:44 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:30:44 --> Utf8 Class Initialized
INFO - 2017-01-12 21:30:44 --> URI Class Initialized
INFO - 2017-01-12 21:30:44 --> Router Class Initialized
INFO - 2017-01-12 21:30:44 --> Output Class Initialized
INFO - 2017-01-12 21:30:44 --> Security Class Initialized
DEBUG - 2017-01-12 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:30:44 --> Input Class Initialized
INFO - 2017-01-12 21:30:44 --> Language Class Initialized
INFO - 2017-01-12 21:30:44 --> Loader Class Initialized
INFO - 2017-01-12 21:30:44 --> Database Driver Class Initialized
INFO - 2017-01-12 21:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:30:44 --> Controller Class Initialized
INFO - 2017-01-12 21:30:44 --> Upload Class Initialized
INFO - 2017-01-12 21:30:44 --> Helper loaded: date_helper
INFO - 2017-01-12 21:30:44 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:30:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:30:44 --> Helper loaded: form_helper
INFO - 2017-01-12 21:30:44 --> Form Validation Class Initialized
INFO - 2017-01-12 21:30:44 --> Final output sent to browser
DEBUG - 2017-01-12 21:30:44 --> Total execution time: 0.0155
INFO - 2017-01-12 21:31:01 --> Config Class Initialized
INFO - 2017-01-12 21:31:01 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:01 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:01 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:01 --> URI Class Initialized
INFO - 2017-01-12 21:31:01 --> Router Class Initialized
INFO - 2017-01-12 21:31:01 --> Output Class Initialized
INFO - 2017-01-12 21:31:01 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:01 --> Input Class Initialized
INFO - 2017-01-12 21:31:01 --> Language Class Initialized
INFO - 2017-01-12 21:31:01 --> Loader Class Initialized
INFO - 2017-01-12 21:31:01 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:02 --> Controller Class Initialized
INFO - 2017-01-12 21:31:02 --> Upload Class Initialized
INFO - 2017-01-12 21:31:02 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:02 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:02 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:02 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:02 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:02 --> Total execution time: 1.3995
INFO - 2017-01-12 21:31:25 --> Config Class Initialized
INFO - 2017-01-12 21:31:25 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:25 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:25 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:25 --> URI Class Initialized
INFO - 2017-01-12 21:31:25 --> Router Class Initialized
INFO - 2017-01-12 21:31:25 --> Output Class Initialized
INFO - 2017-01-12 21:31:25 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:25 --> Input Class Initialized
INFO - 2017-01-12 21:31:25 --> Language Class Initialized
INFO - 2017-01-12 21:31:25 --> Loader Class Initialized
INFO - 2017-01-12 21:31:25 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:25 --> Controller Class Initialized
INFO - 2017-01-12 21:31:25 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:25 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:25 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:25 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:31:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:31:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-12 21:31:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-12 21:31:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:31:25 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:25 --> Total execution time: 0.2206
INFO - 2017-01-12 21:31:25 --> Config Class Initialized
INFO - 2017-01-12 21:31:25 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:25 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:25 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:25 --> URI Class Initialized
INFO - 2017-01-12 21:31:25 --> Router Class Initialized
INFO - 2017-01-12 21:31:25 --> Output Class Initialized
INFO - 2017-01-12 21:31:25 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:25 --> Input Class Initialized
INFO - 2017-01-12 21:31:25 --> Language Class Initialized
INFO - 2017-01-12 21:31:25 --> Loader Class Initialized
INFO - 2017-01-12 21:31:25 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:25 --> Controller Class Initialized
INFO - 2017-01-12 21:31:25 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:25 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:25 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:25 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:25 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:25 --> Total execution time: 0.0141
INFO - 2017-01-12 21:31:26 --> Config Class Initialized
INFO - 2017-01-12 21:31:26 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:26 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:26 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:26 --> URI Class Initialized
INFO - 2017-01-12 21:31:26 --> Router Class Initialized
INFO - 2017-01-12 21:31:26 --> Output Class Initialized
INFO - 2017-01-12 21:31:26 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:26 --> Input Class Initialized
INFO - 2017-01-12 21:31:26 --> Language Class Initialized
INFO - 2017-01-12 21:31:26 --> Loader Class Initialized
INFO - 2017-01-12 21:31:26 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:26 --> Controller Class Initialized
INFO - 2017-01-12 21:31:26 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:26 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:26 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:26 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 21:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 21:31:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:31:27 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:27 --> Total execution time: 0.1021
INFO - 2017-01-12 21:31:27 --> Config Class Initialized
INFO - 2017-01-12 21:31:27 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:27 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:27 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:27 --> URI Class Initialized
INFO - 2017-01-12 21:31:27 --> Router Class Initialized
INFO - 2017-01-12 21:31:27 --> Output Class Initialized
INFO - 2017-01-12 21:31:27 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:27 --> Input Class Initialized
INFO - 2017-01-12 21:31:27 --> Language Class Initialized
INFO - 2017-01-12 21:31:27 --> Loader Class Initialized
INFO - 2017-01-12 21:31:27 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:27 --> Controller Class Initialized
INFO - 2017-01-12 21:31:27 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:27 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:27 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:27 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:27 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:27 --> Total execution time: 0.0153
INFO - 2017-01-12 21:31:34 --> Config Class Initialized
INFO - 2017-01-12 21:31:34 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:34 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:34 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:34 --> URI Class Initialized
INFO - 2017-01-12 21:31:34 --> Router Class Initialized
INFO - 2017-01-12 21:31:34 --> Output Class Initialized
INFO - 2017-01-12 21:31:34 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:34 --> Input Class Initialized
INFO - 2017-01-12 21:31:34 --> Language Class Initialized
INFO - 2017-01-12 21:31:34 --> Loader Class Initialized
INFO - 2017-01-12 21:31:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:34 --> Controller Class Initialized
INFO - 2017-01-12 21:31:34 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:31:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:31:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 21:31:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 21:31:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:31:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:34 --> Total execution time: 0.0814
INFO - 2017-01-12 21:31:34 --> Config Class Initialized
INFO - 2017-01-12 21:31:34 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:34 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:34 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:34 --> URI Class Initialized
INFO - 2017-01-12 21:31:34 --> Router Class Initialized
INFO - 2017-01-12 21:31:34 --> Output Class Initialized
INFO - 2017-01-12 21:31:34 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:34 --> Input Class Initialized
INFO - 2017-01-12 21:31:34 --> Language Class Initialized
INFO - 2017-01-12 21:31:34 --> Loader Class Initialized
INFO - 2017-01-12 21:31:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:34 --> Controller Class Initialized
INFO - 2017-01-12 21:31:34 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:34 --> Total execution time: 0.0660
INFO - 2017-01-12 21:31:37 --> Config Class Initialized
INFO - 2017-01-12 21:31:37 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:37 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:37 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:37 --> URI Class Initialized
INFO - 2017-01-12 21:31:37 --> Router Class Initialized
INFO - 2017-01-12 21:31:37 --> Output Class Initialized
INFO - 2017-01-12 21:31:37 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:37 --> Input Class Initialized
INFO - 2017-01-12 21:31:37 --> Language Class Initialized
INFO - 2017-01-12 21:31:37 --> Loader Class Initialized
INFO - 2017-01-12 21:31:37 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:37 --> Controller Class Initialized
INFO - 2017-01-12 21:31:37 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:37 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:37 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:37 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:31:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:31:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-12 21:31:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-12 21:31:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:31:37 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:37 --> Total execution time: 0.1047
INFO - 2017-01-12 21:31:38 --> Config Class Initialized
INFO - 2017-01-12 21:31:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:38 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:38 --> URI Class Initialized
INFO - 2017-01-12 21:31:38 --> Router Class Initialized
INFO - 2017-01-12 21:31:38 --> Output Class Initialized
INFO - 2017-01-12 21:31:38 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:38 --> Input Class Initialized
INFO - 2017-01-12 21:31:38 --> Language Class Initialized
INFO - 2017-01-12 21:31:38 --> Loader Class Initialized
INFO - 2017-01-12 21:31:38 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:38 --> Controller Class Initialized
INFO - 2017-01-12 21:31:38 --> Helper loaded: date_helper
INFO - 2017-01-12 21:31:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:38 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:38 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:38 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:38 --> Total execution time: 0.0150
INFO - 2017-01-12 21:31:41 --> Config Class Initialized
INFO - 2017-01-12 21:31:41 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:41 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:41 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:41 --> URI Class Initialized
INFO - 2017-01-12 21:31:41 --> Router Class Initialized
INFO - 2017-01-12 21:31:41 --> Output Class Initialized
INFO - 2017-01-12 21:31:41 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:41 --> Input Class Initialized
INFO - 2017-01-12 21:31:41 --> Language Class Initialized
INFO - 2017-01-12 21:31:41 --> Loader Class Initialized
INFO - 2017-01-12 21:31:41 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:41 --> Controller Class Initialized
INFO - 2017-01-12 21:31:41 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:41 --> Config Class Initialized
INFO - 2017-01-12 21:31:41 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:31:41 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:31:41 --> Utf8 Class Initialized
INFO - 2017-01-12 21:31:41 --> URI Class Initialized
INFO - 2017-01-12 21:31:41 --> Router Class Initialized
INFO - 2017-01-12 21:31:41 --> Output Class Initialized
INFO - 2017-01-12 21:31:41 --> Security Class Initialized
DEBUG - 2017-01-12 21:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:31:41 --> Input Class Initialized
INFO - 2017-01-12 21:31:41 --> Language Class Initialized
INFO - 2017-01-12 21:31:41 --> Loader Class Initialized
INFO - 2017-01-12 21:31:41 --> Database Driver Class Initialized
INFO - 2017-01-12 21:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:31:41 --> Controller Class Initialized
INFO - 2017-01-12 21:31:41 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:31:41 --> Helper loaded: form_helper
INFO - 2017-01-12 21:31:41 --> Form Validation Class Initialized
INFO - 2017-01-12 21:31:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:31:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 21:31:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:31:41 --> Final output sent to browser
DEBUG - 2017-01-12 21:31:41 --> Total execution time: 0.0223
INFO - 2017-01-12 21:38:43 --> Config Class Initialized
INFO - 2017-01-12 21:38:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:38:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:38:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:38:43 --> URI Class Initialized
DEBUG - 2017-01-12 21:38:43 --> No URI present. Default controller set.
INFO - 2017-01-12 21:38:43 --> Router Class Initialized
INFO - 2017-01-12 21:38:43 --> Output Class Initialized
INFO - 2017-01-12 21:38:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:38:43 --> Input Class Initialized
INFO - 2017-01-12 21:38:43 --> Language Class Initialized
INFO - 2017-01-12 21:38:43 --> Loader Class Initialized
INFO - 2017-01-12 21:38:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:38:44 --> Controller Class Initialized
INFO - 2017-01-12 21:38:44 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:38:44 --> Final output sent to browser
DEBUG - 2017-01-12 21:38:44 --> Total execution time: 1.2388
INFO - 2017-01-12 21:38:45 --> Config Class Initialized
INFO - 2017-01-12 21:38:45 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:38:45 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:38:45 --> Utf8 Class Initialized
INFO - 2017-01-12 21:38:45 --> URI Class Initialized
INFO - 2017-01-12 21:38:45 --> Router Class Initialized
INFO - 2017-01-12 21:38:45 --> Output Class Initialized
INFO - 2017-01-12 21:38:45 --> Security Class Initialized
DEBUG - 2017-01-12 21:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:38:45 --> Input Class Initialized
INFO - 2017-01-12 21:38:45 --> Language Class Initialized
INFO - 2017-01-12 21:38:45 --> Loader Class Initialized
INFO - 2017-01-12 21:38:45 --> Database Driver Class Initialized
INFO - 2017-01-12 21:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:38:45 --> Controller Class Initialized
INFO - 2017-01-12 21:38:45 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:38:45 --> Final output sent to browser
DEBUG - 2017-01-12 21:38:45 --> Total execution time: 0.0134
INFO - 2017-01-12 21:40:20 --> Config Class Initialized
INFO - 2017-01-12 21:40:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:20 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:20 --> URI Class Initialized
INFO - 2017-01-12 21:40:20 --> Router Class Initialized
INFO - 2017-01-12 21:40:21 --> Output Class Initialized
INFO - 2017-01-12 21:40:21 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:21 --> Input Class Initialized
INFO - 2017-01-12 21:40:21 --> Language Class Initialized
INFO - 2017-01-12 21:40:21 --> Loader Class Initialized
INFO - 2017-01-12 21:40:21 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:21 --> Controller Class Initialized
INFO - 2017-01-12 21:40:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:21 --> Helper loaded: form_helper
INFO - 2017-01-12 21:40:21 --> Form Validation Class Initialized
INFO - 2017-01-12 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:40:21 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:21 --> Total execution time: 0.8960
INFO - 2017-01-12 21:40:22 --> Config Class Initialized
INFO - 2017-01-12 21:40:22 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:22 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:22 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:22 --> URI Class Initialized
INFO - 2017-01-12 21:40:22 --> Router Class Initialized
INFO - 2017-01-12 21:40:22 --> Output Class Initialized
INFO - 2017-01-12 21:40:22 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:22 --> Input Class Initialized
INFO - 2017-01-12 21:40:22 --> Language Class Initialized
INFO - 2017-01-12 21:40:22 --> Loader Class Initialized
INFO - 2017-01-12 21:40:22 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:22 --> Controller Class Initialized
INFO - 2017-01-12 21:40:22 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:40:22 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:22 --> Total execution time: 0.0215
INFO - 2017-01-12 21:40:30 --> Config Class Initialized
INFO - 2017-01-12 21:40:30 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:30 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:30 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:30 --> URI Class Initialized
INFO - 2017-01-12 21:40:30 --> Router Class Initialized
INFO - 2017-01-12 21:40:30 --> Output Class Initialized
INFO - 2017-01-12 21:40:30 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:30 --> Input Class Initialized
INFO - 2017-01-12 21:40:30 --> Language Class Initialized
INFO - 2017-01-12 21:40:30 --> Loader Class Initialized
INFO - 2017-01-12 21:40:30 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:30 --> Controller Class Initialized
INFO - 2017-01-12 21:40:30 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:30 --> Helper loaded: form_helper
INFO - 2017-01-12 21:40:30 --> Form Validation Class Initialized
INFO - 2017-01-12 21:40:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 21:40:31 --> Config Class Initialized
INFO - 2017-01-12 21:40:31 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:31 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:31 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:31 --> URI Class Initialized
INFO - 2017-01-12 21:40:31 --> Router Class Initialized
INFO - 2017-01-12 21:40:31 --> Output Class Initialized
INFO - 2017-01-12 21:40:31 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:31 --> Input Class Initialized
INFO - 2017-01-12 21:40:31 --> Language Class Initialized
INFO - 2017-01-12 21:40:31 --> Loader Class Initialized
INFO - 2017-01-12 21:40:31 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:31 --> Controller Class Initialized
INFO - 2017-01-12 21:40:31 --> Helper loaded: date_helper
INFO - 2017-01-12 21:40:31 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:31 --> Helper loaded: form_helper
INFO - 2017-01-12 21:40:31 --> Form Validation Class Initialized
INFO - 2017-01-12 21:40:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:40:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:40:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 21:40:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 21:40:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:40:31 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:31 --> Total execution time: 0.1194
INFO - 2017-01-12 21:40:31 --> Config Class Initialized
INFO - 2017-01-12 21:40:31 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:31 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:31 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:31 --> URI Class Initialized
INFO - 2017-01-12 21:40:31 --> Router Class Initialized
INFO - 2017-01-12 21:40:31 --> Output Class Initialized
INFO - 2017-01-12 21:40:31 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:31 --> Input Class Initialized
INFO - 2017-01-12 21:40:31 --> Language Class Initialized
INFO - 2017-01-12 21:40:31 --> Loader Class Initialized
INFO - 2017-01-12 21:40:31 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:31 --> Controller Class Initialized
INFO - 2017-01-12 21:40:31 --> Helper loaded: date_helper
INFO - 2017-01-12 21:40:31 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:31 --> Helper loaded: form_helper
INFO - 2017-01-12 21:40:31 --> Form Validation Class Initialized
INFO - 2017-01-12 21:40:31 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:31 --> Total execution time: 0.0141
INFO - 2017-01-12 21:40:32 --> Config Class Initialized
INFO - 2017-01-12 21:40:32 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:32 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:32 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:32 --> URI Class Initialized
INFO - 2017-01-12 21:40:32 --> Router Class Initialized
INFO - 2017-01-12 21:40:32 --> Output Class Initialized
INFO - 2017-01-12 21:40:32 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:32 --> Input Class Initialized
INFO - 2017-01-12 21:40:32 --> Language Class Initialized
INFO - 2017-01-12 21:40:32 --> Loader Class Initialized
INFO - 2017-01-12 21:40:32 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:32 --> Controller Class Initialized
INFO - 2017-01-12 21:40:32 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:40:32 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:32 --> Total execution time: 0.0140
INFO - 2017-01-12 21:40:34 --> Config Class Initialized
INFO - 2017-01-12 21:40:34 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:34 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:34 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:34 --> URI Class Initialized
INFO - 2017-01-12 21:40:34 --> Router Class Initialized
INFO - 2017-01-12 21:40:34 --> Output Class Initialized
INFO - 2017-01-12 21:40:34 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:34 --> Input Class Initialized
INFO - 2017-01-12 21:40:34 --> Language Class Initialized
INFO - 2017-01-12 21:40:34 --> Loader Class Initialized
INFO - 2017-01-12 21:40:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:34 --> Controller Class Initialized
INFO - 2017-01-12 21:40:34 --> Upload Class Initialized
INFO - 2017-01-12 21:40:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:40:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:40:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:40:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:40:35 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:35 --> Total execution time: 0.1838
INFO - 2017-01-12 21:40:35 --> Config Class Initialized
INFO - 2017-01-12 21:40:35 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:35 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:35 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:35 --> URI Class Initialized
INFO - 2017-01-12 21:40:35 --> Router Class Initialized
INFO - 2017-01-12 21:40:35 --> Output Class Initialized
INFO - 2017-01-12 21:40:35 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:35 --> Input Class Initialized
INFO - 2017-01-12 21:40:35 --> Language Class Initialized
INFO - 2017-01-12 21:40:35 --> Loader Class Initialized
INFO - 2017-01-12 21:40:35 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:35 --> Controller Class Initialized
INFO - 2017-01-12 21:40:35 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:40:35 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:35 --> Total execution time: 0.0136
INFO - 2017-01-12 21:40:35 --> Config Class Initialized
INFO - 2017-01-12 21:40:35 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:35 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:35 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:35 --> URI Class Initialized
INFO - 2017-01-12 21:40:35 --> Router Class Initialized
INFO - 2017-01-12 21:40:35 --> Output Class Initialized
INFO - 2017-01-12 21:40:35 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:35 --> Input Class Initialized
INFO - 2017-01-12 21:40:35 --> Language Class Initialized
INFO - 2017-01-12 21:40:35 --> Loader Class Initialized
INFO - 2017-01-12 21:40:35 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:35 --> Controller Class Initialized
INFO - 2017-01-12 21:40:35 --> Upload Class Initialized
INFO - 2017-01-12 21:40:35 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:35 --> Helper loaded: form_helper
INFO - 2017-01-12 21:40:35 --> Form Validation Class Initialized
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:40:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:40:35 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:35 --> Total execution time: 0.0157
INFO - 2017-01-12 21:40:36 --> Config Class Initialized
INFO - 2017-01-12 21:40:36 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:40:36 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:40:36 --> Utf8 Class Initialized
INFO - 2017-01-12 21:40:36 --> URI Class Initialized
INFO - 2017-01-12 21:40:36 --> Router Class Initialized
INFO - 2017-01-12 21:40:36 --> Output Class Initialized
INFO - 2017-01-12 21:40:36 --> Security Class Initialized
DEBUG - 2017-01-12 21:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:40:36 --> Input Class Initialized
INFO - 2017-01-12 21:40:36 --> Language Class Initialized
INFO - 2017-01-12 21:40:36 --> Loader Class Initialized
INFO - 2017-01-12 21:40:36 --> Database Driver Class Initialized
INFO - 2017-01-12 21:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:40:36 --> Controller Class Initialized
INFO - 2017-01-12 21:40:36 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:40:36 --> Final output sent to browser
DEBUG - 2017-01-12 21:40:36 --> Total execution time: 0.0130
INFO - 2017-01-12 21:43:22 --> Config Class Initialized
INFO - 2017-01-12 21:43:22 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:22 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:22 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:22 --> URI Class Initialized
INFO - 2017-01-12 21:43:22 --> Router Class Initialized
INFO - 2017-01-12 21:43:22 --> Output Class Initialized
INFO - 2017-01-12 21:43:23 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:23 --> Input Class Initialized
INFO - 2017-01-12 21:43:23 --> Language Class Initialized
INFO - 2017-01-12 21:43:23 --> Loader Class Initialized
INFO - 2017-01-12 21:43:23 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:23 --> Controller Class Initialized
INFO - 2017-01-12 21:43:23 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:23 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:23 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 21:43:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:24 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:24 --> Total execution time: 2.0263
INFO - 2017-01-12 21:43:29 --> Config Class Initialized
INFO - 2017-01-12 21:43:29 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:29 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:29 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:29 --> URI Class Initialized
INFO - 2017-01-12 21:43:29 --> Router Class Initialized
INFO - 2017-01-12 21:43:29 --> Output Class Initialized
INFO - 2017-01-12 21:43:29 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:29 --> Input Class Initialized
INFO - 2017-01-12 21:43:29 --> Language Class Initialized
INFO - 2017-01-12 21:43:29 --> Loader Class Initialized
INFO - 2017-01-12 21:43:29 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:30 --> Controller Class Initialized
INFO - 2017-01-12 21:43:30 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:43:30 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:30 --> Total execution time: 1.3036
INFO - 2017-01-12 21:43:37 --> Config Class Initialized
INFO - 2017-01-12 21:43:37 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:37 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:37 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:37 --> URI Class Initialized
INFO - 2017-01-12 21:43:37 --> Router Class Initialized
INFO - 2017-01-12 21:43:37 --> Output Class Initialized
INFO - 2017-01-12 21:43:37 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:37 --> Input Class Initialized
INFO - 2017-01-12 21:43:37 --> Language Class Initialized
INFO - 2017-01-12 21:43:37 --> Loader Class Initialized
INFO - 2017-01-12 21:43:38 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:38 --> Controller Class Initialized
INFO - 2017-01-12 21:43:38 --> Upload Class Initialized
INFO - 2017-01-12 21:43:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:38 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:38 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:43:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:43:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:43:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:38 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:38 --> Total execution time: 0.9956
INFO - 2017-01-12 21:43:42 --> Config Class Initialized
INFO - 2017-01-12 21:43:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:42 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:42 --> Config Class Initialized
INFO - 2017-01-12 21:43:42 --> URI Class Initialized
INFO - 2017-01-12 21:43:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:42 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:42 --> Router Class Initialized
INFO - 2017-01-12 21:43:42 --> URI Class Initialized
INFO - 2017-01-12 21:43:42 --> Router Class Initialized
INFO - 2017-01-12 21:43:42 --> Output Class Initialized
INFO - 2017-01-12 21:43:42 --> Security Class Initialized
INFO - 2017-01-12 21:43:42 --> Output Class Initialized
INFO - 2017-01-12 21:43:42 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:42 --> Input Class Initialized
INFO - 2017-01-12 21:43:42 --> Language Class Initialized
DEBUG - 2017-01-12 21:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:42 --> Input Class Initialized
INFO - 2017-01-12 21:43:42 --> Language Class Initialized
INFO - 2017-01-12 21:43:42 --> Loader Class Initialized
INFO - 2017-01-12 21:43:42 --> Loader Class Initialized
INFO - 2017-01-12 21:43:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:43 --> Controller Class Initialized
INFO - 2017-01-12 21:43:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:43:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:43 --> Total execution time: 1.2377
INFO - 2017-01-12 21:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:43 --> Controller Class Initialized
INFO - 2017-01-12 21:43:43 --> Upload Class Initialized
INFO - 2017-01-12 21:43:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:43 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:43 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:43:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:43 --> Total execution time: 1.6426
INFO - 2017-01-12 21:43:48 --> Config Class Initialized
INFO - 2017-01-12 21:43:48 --> Hooks Class Initialized
INFO - 2017-01-12 21:43:48 --> Config Class Initialized
INFO - 2017-01-12 21:43:48 --> Hooks Class Initialized
INFO - 2017-01-12 21:43:48 --> Config Class Initialized
INFO - 2017-01-12 21:43:48 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:48 --> UTF-8 Support Enabled
DEBUG - 2017-01-12 21:43:48 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:48 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:48 --> Utf8 Class Initialized
DEBUG - 2017-01-12 21:43:48 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:48 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:48 --> URI Class Initialized
INFO - 2017-01-12 21:43:48 --> URI Class Initialized
INFO - 2017-01-12 21:43:48 --> URI Class Initialized
INFO - 2017-01-12 21:43:48 --> Router Class Initialized
INFO - 2017-01-12 21:43:48 --> Router Class Initialized
INFO - 2017-01-12 21:43:48 --> Router Class Initialized
INFO - 2017-01-12 21:43:48 --> Output Class Initialized
INFO - 2017-01-12 21:43:48 --> Output Class Initialized
INFO - 2017-01-12 21:43:48 --> Security Class Initialized
INFO - 2017-01-12 21:43:48 --> Output Class Initialized
INFO - 2017-01-12 21:43:48 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:48 --> Security Class Initialized
INFO - 2017-01-12 21:43:48 --> Input Class Initialized
INFO - 2017-01-12 21:43:48 --> Language Class Initialized
DEBUG - 2017-01-12 21:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-12 21:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:48 --> Input Class Initialized
INFO - 2017-01-12 21:43:48 --> Language Class Initialized
INFO - 2017-01-12 21:43:48 --> Input Class Initialized
INFO - 2017-01-12 21:43:48 --> Language Class Initialized
INFO - 2017-01-12 21:43:48 --> Loader Class Initialized
INFO - 2017-01-12 21:43:48 --> Loader Class Initialized
INFO - 2017-01-12 21:43:48 --> Loader Class Initialized
INFO - 2017-01-12 21:43:49 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:49 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:49 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:49 --> Controller Class Initialized
INFO - 2017-01-12 21:43:49 --> Upload Class Initialized
INFO - 2017-01-12 21:43:49 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:49 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:49 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:49 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:49 --> Total execution time: 1.3015
INFO - 2017-01-12 21:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:49 --> Controller Class Initialized
INFO - 2017-01-12 21:43:49 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:43:49 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:49 --> Total execution time: 1.5843
INFO - 2017-01-12 21:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:49 --> Controller Class Initialized
INFO - 2017-01-12 21:43:49 --> Upload Class Initialized
INFO - 2017-01-12 21:43:49 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:49 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:49 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:49 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:49 --> Total execution time: 1.6386
INFO - 2017-01-12 21:43:49 --> Config Class Initialized
INFO - 2017-01-12 21:43:49 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:49 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:49 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:49 --> URI Class Initialized
INFO - 2017-01-12 21:43:49 --> Router Class Initialized
INFO - 2017-01-12 21:43:49 --> Output Class Initialized
INFO - 2017-01-12 21:43:49 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:49 --> Input Class Initialized
INFO - 2017-01-12 21:43:49 --> Language Class Initialized
INFO - 2017-01-12 21:43:49 --> Loader Class Initialized
INFO - 2017-01-12 21:43:49 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:49 --> Controller Class Initialized
INFO - 2017-01-12 21:43:50 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:43:50 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:50 --> Total execution time: 0.0139
INFO - 2017-01-12 21:43:51 --> Config Class Initialized
INFO - 2017-01-12 21:43:51 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:51 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:51 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:51 --> URI Class Initialized
INFO - 2017-01-12 21:43:51 --> Router Class Initialized
INFO - 2017-01-12 21:43:51 --> Output Class Initialized
INFO - 2017-01-12 21:43:51 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:51 --> Input Class Initialized
INFO - 2017-01-12 21:43:51 --> Language Class Initialized
INFO - 2017-01-12 21:43:51 --> Loader Class Initialized
INFO - 2017-01-12 21:43:51 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:51 --> Controller Class Initialized
INFO - 2017-01-12 21:43:51 --> Upload Class Initialized
INFO - 2017-01-12 21:43:51 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:51 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:51 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:51 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:51 --> Total execution time: 0.0166
INFO - 2017-01-12 21:43:51 --> Config Class Initialized
INFO - 2017-01-12 21:43:51 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:51 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:51 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:51 --> URI Class Initialized
INFO - 2017-01-12 21:43:51 --> Router Class Initialized
INFO - 2017-01-12 21:43:51 --> Output Class Initialized
INFO - 2017-01-12 21:43:51 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:51 --> Input Class Initialized
INFO - 2017-01-12 21:43:51 --> Language Class Initialized
INFO - 2017-01-12 21:43:51 --> Loader Class Initialized
INFO - 2017-01-12 21:43:51 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:51 --> Controller Class Initialized
INFO - 2017-01-12 21:43:51 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:43:51 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:51 --> Total execution time: 0.0156
INFO - 2017-01-12 21:43:52 --> Config Class Initialized
INFO - 2017-01-12 21:43:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:52 --> URI Class Initialized
INFO - 2017-01-12 21:43:52 --> Router Class Initialized
INFO - 2017-01-12 21:43:52 --> Output Class Initialized
INFO - 2017-01-12 21:43:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:52 --> Input Class Initialized
INFO - 2017-01-12 21:43:52 --> Language Class Initialized
INFO - 2017-01-12 21:43:52 --> Loader Class Initialized
INFO - 2017-01-12 21:43:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:52 --> Controller Class Initialized
INFO - 2017-01-12 21:43:52 --> Upload Class Initialized
INFO - 2017-01-12 21:43:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:52 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:52 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:52 --> Total execution time: 0.0165
INFO - 2017-01-12 21:43:52 --> Config Class Initialized
INFO - 2017-01-12 21:43:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:52 --> URI Class Initialized
INFO - 2017-01-12 21:43:52 --> Router Class Initialized
INFO - 2017-01-12 21:43:52 --> Output Class Initialized
INFO - 2017-01-12 21:43:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:52 --> Input Class Initialized
INFO - 2017-01-12 21:43:52 --> Language Class Initialized
INFO - 2017-01-12 21:43:52 --> Loader Class Initialized
INFO - 2017-01-12 21:43:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:52 --> Controller Class Initialized
INFO - 2017-01-12 21:43:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:43:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:52 --> Total execution time: 0.0138
INFO - 2017-01-12 21:43:54 --> Config Class Initialized
INFO - 2017-01-12 21:43:54 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:54 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:54 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:54 --> URI Class Initialized
INFO - 2017-01-12 21:43:54 --> Router Class Initialized
INFO - 2017-01-12 21:43:54 --> Output Class Initialized
INFO - 2017-01-12 21:43:54 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:54 --> Input Class Initialized
INFO - 2017-01-12 21:43:54 --> Language Class Initialized
INFO - 2017-01-12 21:43:54 --> Loader Class Initialized
INFO - 2017-01-12 21:43:54 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:54 --> Controller Class Initialized
INFO - 2017-01-12 21:43:54 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:54 --> Config Class Initialized
INFO - 2017-01-12 21:43:54 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:54 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:54 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:54 --> URI Class Initialized
INFO - 2017-01-12 21:43:54 --> Router Class Initialized
INFO - 2017-01-12 21:43:54 --> Output Class Initialized
INFO - 2017-01-12 21:43:54 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:54 --> Input Class Initialized
INFO - 2017-01-12 21:43:54 --> Language Class Initialized
INFO - 2017-01-12 21:43:54 --> Loader Class Initialized
INFO - 2017-01-12 21:43:54 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:54 --> Controller Class Initialized
INFO - 2017-01-12 21:43:54 --> Helper loaded: date_helper
INFO - 2017-01-12 21:43:54 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:54 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:54 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 21:43:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 21:43:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:54 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:54 --> Total execution time: 0.1201
INFO - 2017-01-12 21:43:55 --> Config Class Initialized
INFO - 2017-01-12 21:43:55 --> Hooks Class Initialized
INFO - 2017-01-12 21:43:55 --> Config Class Initialized
INFO - 2017-01-12 21:43:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:55 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:55 --> URI Class Initialized
DEBUG - 2017-01-12 21:43:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:55 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:55 --> URI Class Initialized
INFO - 2017-01-12 21:43:55 --> Router Class Initialized
INFO - 2017-01-12 21:43:55 --> Router Class Initialized
INFO - 2017-01-12 21:43:55 --> Output Class Initialized
INFO - 2017-01-12 21:43:55 --> Security Class Initialized
INFO - 2017-01-12 21:43:55 --> Output Class Initialized
DEBUG - 2017-01-12 21:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:55 --> Input Class Initialized
INFO - 2017-01-12 21:43:55 --> Language Class Initialized
INFO - 2017-01-12 21:43:55 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:55 --> Input Class Initialized
INFO - 2017-01-12 21:43:55 --> Language Class Initialized
INFO - 2017-01-12 21:43:55 --> Loader Class Initialized
INFO - 2017-01-12 21:43:55 --> Loader Class Initialized
INFO - 2017-01-12 21:43:55 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:55 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:55 --> Controller Class Initialized
INFO - 2017-01-12 21:43:55 --> Helper loaded: date_helper
INFO - 2017-01-12 21:43:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:55 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:55 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:55 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:55 --> Total execution time: 0.2101
INFO - 2017-01-12 21:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:55 --> Controller Class Initialized
INFO - 2017-01-12 21:43:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:43:55 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:55 --> Total execution time: 0.1226
INFO - 2017-01-12 21:43:59 --> Config Class Initialized
INFO - 2017-01-12 21:43:59 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:43:59 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:43:59 --> Utf8 Class Initialized
INFO - 2017-01-12 21:43:59 --> URI Class Initialized
INFO - 2017-01-12 21:43:59 --> Router Class Initialized
INFO - 2017-01-12 21:43:59 --> Output Class Initialized
INFO - 2017-01-12 21:43:59 --> Security Class Initialized
DEBUG - 2017-01-12 21:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:43:59 --> Input Class Initialized
INFO - 2017-01-12 21:43:59 --> Language Class Initialized
INFO - 2017-01-12 21:43:59 --> Loader Class Initialized
INFO - 2017-01-12 21:43:59 --> Database Driver Class Initialized
INFO - 2017-01-12 21:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:43:59 --> Controller Class Initialized
INFO - 2017-01-12 21:43:59 --> Upload Class Initialized
INFO - 2017-01-12 21:43:59 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:43:59 --> Helper loaded: form_helper
INFO - 2017-01-12 21:43:59 --> Form Validation Class Initialized
INFO - 2017-01-12 21:43:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:43:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:43:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:43:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:43:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:43:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:43:59 --> Final output sent to browser
DEBUG - 2017-01-12 21:43:59 --> Total execution time: 0.4653
INFO - 2017-01-12 21:44:00 --> Config Class Initialized
INFO - 2017-01-12 21:44:00 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:44:00 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:44:00 --> Utf8 Class Initialized
INFO - 2017-01-12 21:44:00 --> URI Class Initialized
INFO - 2017-01-12 21:44:00 --> Router Class Initialized
INFO - 2017-01-12 21:44:00 --> Output Class Initialized
INFO - 2017-01-12 21:44:00 --> Security Class Initialized
DEBUG - 2017-01-12 21:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:44:00 --> Input Class Initialized
INFO - 2017-01-12 21:44:00 --> Language Class Initialized
INFO - 2017-01-12 21:44:00 --> Loader Class Initialized
INFO - 2017-01-12 21:44:00 --> Database Driver Class Initialized
INFO - 2017-01-12 21:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:44:00 --> Controller Class Initialized
INFO - 2017-01-12 21:44:00 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:44:00 --> Final output sent to browser
DEBUG - 2017-01-12 21:44:00 --> Total execution time: 0.0165
INFO - 2017-01-12 21:45:58 --> Config Class Initialized
INFO - 2017-01-12 21:45:58 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:45:58 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:45:58 --> Utf8 Class Initialized
INFO - 2017-01-12 21:45:58 --> URI Class Initialized
DEBUG - 2017-01-12 21:45:58 --> No URI present. Default controller set.
INFO - 2017-01-12 21:45:58 --> Router Class Initialized
INFO - 2017-01-12 21:45:58 --> Output Class Initialized
INFO - 2017-01-12 21:45:58 --> Security Class Initialized
DEBUG - 2017-01-12 21:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:45:58 --> Input Class Initialized
INFO - 2017-01-12 21:45:58 --> Language Class Initialized
INFO - 2017-01-12 21:45:58 --> Loader Class Initialized
INFO - 2017-01-12 21:45:58 --> Database Driver Class Initialized
INFO - 2017-01-12 21:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:45:58 --> Controller Class Initialized
INFO - 2017-01-12 21:45:58 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:45:58 --> Final output sent to browser
DEBUG - 2017-01-12 21:45:58 --> Total execution time: 0.0133
INFO - 2017-01-12 21:45:59 --> Config Class Initialized
INFO - 2017-01-12 21:45:59 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:45:59 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:45:59 --> Utf8 Class Initialized
INFO - 2017-01-12 21:45:59 --> URI Class Initialized
INFO - 2017-01-12 21:45:59 --> Router Class Initialized
INFO - 2017-01-12 21:45:59 --> Output Class Initialized
INFO - 2017-01-12 21:45:59 --> Security Class Initialized
DEBUG - 2017-01-12 21:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:45:59 --> Input Class Initialized
INFO - 2017-01-12 21:45:59 --> Language Class Initialized
INFO - 2017-01-12 21:45:59 --> Loader Class Initialized
INFO - 2017-01-12 21:45:59 --> Database Driver Class Initialized
INFO - 2017-01-12 21:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:45:59 --> Controller Class Initialized
INFO - 2017-01-12 21:45:59 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:45:59 --> Final output sent to browser
DEBUG - 2017-01-12 21:45:59 --> Total execution time: 0.0134
INFO - 2017-01-12 21:46:01 --> Config Class Initialized
INFO - 2017-01-12 21:46:01 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:46:01 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:46:01 --> Utf8 Class Initialized
INFO - 2017-01-12 21:46:01 --> URI Class Initialized
INFO - 2017-01-12 21:46:01 --> Router Class Initialized
INFO - 2017-01-12 21:46:01 --> Output Class Initialized
INFO - 2017-01-12 21:46:01 --> Security Class Initialized
DEBUG - 2017-01-12 21:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:46:01 --> Input Class Initialized
INFO - 2017-01-12 21:46:01 --> Language Class Initialized
INFO - 2017-01-12 21:46:01 --> Loader Class Initialized
INFO - 2017-01-12 21:46:01 --> Database Driver Class Initialized
INFO - 2017-01-12 21:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:46:01 --> Controller Class Initialized
INFO - 2017-01-12 21:46:01 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:46:03 --> Config Class Initialized
INFO - 2017-01-12 21:46:03 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:46:03 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:46:03 --> Utf8 Class Initialized
INFO - 2017-01-12 21:46:03 --> URI Class Initialized
INFO - 2017-01-12 21:46:03 --> Router Class Initialized
INFO - 2017-01-12 21:46:03 --> Output Class Initialized
INFO - 2017-01-12 21:46:03 --> Security Class Initialized
DEBUG - 2017-01-12 21:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:46:03 --> Input Class Initialized
INFO - 2017-01-12 21:46:03 --> Language Class Initialized
INFO - 2017-01-12 21:46:03 --> Loader Class Initialized
INFO - 2017-01-12 21:46:03 --> Database Driver Class Initialized
INFO - 2017-01-12 21:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:46:03 --> Controller Class Initialized
INFO - 2017-01-12 21:46:03 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:46:03 --> Helper loaded: url_helper
INFO - 2017-01-12 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-12 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:46:03 --> Final output sent to browser
DEBUG - 2017-01-12 21:46:03 --> Total execution time: 0.2926
INFO - 2017-01-12 21:46:05 --> Config Class Initialized
INFO - 2017-01-12 21:46:05 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:46:05 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:46:05 --> Utf8 Class Initialized
INFO - 2017-01-12 21:46:05 --> URI Class Initialized
INFO - 2017-01-12 21:46:05 --> Router Class Initialized
INFO - 2017-01-12 21:46:05 --> Output Class Initialized
INFO - 2017-01-12 21:46:05 --> Security Class Initialized
DEBUG - 2017-01-12 21:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:46:05 --> Input Class Initialized
INFO - 2017-01-12 21:46:05 --> Language Class Initialized
INFO - 2017-01-12 21:46:05 --> Loader Class Initialized
INFO - 2017-01-12 21:46:05 --> Database Driver Class Initialized
INFO - 2017-01-12 21:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:46:05 --> Controller Class Initialized
INFO - 2017-01-12 21:46:05 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:46:05 --> Final output sent to browser
DEBUG - 2017-01-12 21:46:05 --> Total execution time: 0.0135
INFO - 2017-01-12 21:46:06 --> Config Class Initialized
INFO - 2017-01-12 21:46:06 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:46:06 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:46:06 --> Utf8 Class Initialized
INFO - 2017-01-12 21:46:06 --> URI Class Initialized
INFO - 2017-01-12 21:46:06 --> Router Class Initialized
INFO - 2017-01-12 21:46:06 --> Output Class Initialized
INFO - 2017-01-12 21:46:06 --> Security Class Initialized
DEBUG - 2017-01-12 21:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:46:06 --> Input Class Initialized
INFO - 2017-01-12 21:46:06 --> Language Class Initialized
INFO - 2017-01-12 21:46:06 --> Loader Class Initialized
INFO - 2017-01-12 21:46:06 --> Database Driver Class Initialized
INFO - 2017-01-12 21:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:46:06 --> Controller Class Initialized
INFO - 2017-01-12 21:46:06 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:46:06 --> Helper loaded: url_helper
INFO - 2017-01-12 21:46:06 --> Helper loaded: download_helper
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:46:06 --> Final output sent to browser
DEBUG - 2017-01-12 21:46:06 --> Total execution time: 0.1525
INFO - 2017-01-12 21:46:06 --> Config Class Initialized
INFO - 2017-01-12 21:46:06 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:46:06 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:46:06 --> Utf8 Class Initialized
INFO - 2017-01-12 21:46:06 --> URI Class Initialized
INFO - 2017-01-12 21:46:06 --> Router Class Initialized
INFO - 2017-01-12 21:46:06 --> Output Class Initialized
INFO - 2017-01-12 21:46:06 --> Security Class Initialized
DEBUG - 2017-01-12 21:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:46:06 --> Input Class Initialized
INFO - 2017-01-12 21:46:06 --> Language Class Initialized
INFO - 2017-01-12 21:46:06 --> Loader Class Initialized
INFO - 2017-01-12 21:46:06 --> Database Driver Class Initialized
INFO - 2017-01-12 21:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:46:06 --> Controller Class Initialized
INFO - 2017-01-12 21:46:06 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:46:06 --> Final output sent to browser
DEBUG - 2017-01-12 21:46:06 --> Total execution time: 0.0140
INFO - 2017-01-12 21:47:10 --> Config Class Initialized
INFO - 2017-01-12 21:47:10 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:10 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:10 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:10 --> URI Class Initialized
INFO - 2017-01-12 21:47:10 --> Router Class Initialized
INFO - 2017-01-12 21:47:10 --> Output Class Initialized
INFO - 2017-01-12 21:47:10 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:10 --> Input Class Initialized
INFO - 2017-01-12 21:47:10 --> Language Class Initialized
INFO - 2017-01-12 21:47:10 --> Loader Class Initialized
INFO - 2017-01-12 21:47:10 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:10 --> Controller Class Initialized
INFO - 2017-01-12 21:47:10 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:10 --> Helper loaded: url_helper
INFO - 2017-01-12 21:47:10 --> Helper loaded: download_helper
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:10 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:10 --> Total execution time: 0.0350
INFO - 2017-01-12 21:47:10 --> Config Class Initialized
INFO - 2017-01-12 21:47:10 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:10 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:10 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:10 --> URI Class Initialized
INFO - 2017-01-12 21:47:10 --> Router Class Initialized
INFO - 2017-01-12 21:47:10 --> Output Class Initialized
INFO - 2017-01-12 21:47:10 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:10 --> Input Class Initialized
INFO - 2017-01-12 21:47:10 --> Language Class Initialized
INFO - 2017-01-12 21:47:10 --> Loader Class Initialized
INFO - 2017-01-12 21:47:10 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:10 --> Controller Class Initialized
INFO - 2017-01-12 21:47:10 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:47:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:10 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:10 --> Total execution time: 0.0135
INFO - 2017-01-12 21:47:18 --> Config Class Initialized
INFO - 2017-01-12 21:47:18 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:18 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:18 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:18 --> URI Class Initialized
INFO - 2017-01-12 21:47:18 --> Router Class Initialized
INFO - 2017-01-12 21:47:18 --> Output Class Initialized
INFO - 2017-01-12 21:47:18 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:18 --> Input Class Initialized
INFO - 2017-01-12 21:47:18 --> Language Class Initialized
INFO - 2017-01-12 21:47:18 --> Loader Class Initialized
INFO - 2017-01-12 21:47:18 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:18 --> Controller Class Initialized
INFO - 2017-01-12 21:47:18 --> Upload Class Initialized
INFO - 2017-01-12 21:47:18 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:18 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:18 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:22 --> Config Class Initialized
INFO - 2017-01-12 21:47:22 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:22 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:22 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:22 --> URI Class Initialized
INFO - 2017-01-12 21:47:22 --> Router Class Initialized
INFO - 2017-01-12 21:47:22 --> Output Class Initialized
INFO - 2017-01-12 21:47:22 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:22 --> Input Class Initialized
INFO - 2017-01-12 21:47:22 --> Language Class Initialized
INFO - 2017-01-12 21:47:22 --> Loader Class Initialized
INFO - 2017-01-12 21:47:22 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:22 --> Controller Class Initialized
INFO - 2017-01-12 21:47:22 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:22 --> Helper loaded: url_helper
INFO - 2017-01-12 21:47:22 --> Helper loaded: download_helper
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:22 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:22 --> Total execution time: 0.8765
INFO - 2017-01-12 21:47:22 --> Config Class Initialized
INFO - 2017-01-12 21:47:22 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:22 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:22 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:22 --> URI Class Initialized
INFO - 2017-01-12 21:47:22 --> Router Class Initialized
INFO - 2017-01-12 21:47:22 --> Output Class Initialized
INFO - 2017-01-12 21:47:22 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:22 --> Input Class Initialized
INFO - 2017-01-12 21:47:22 --> Language Class Initialized
INFO - 2017-01-12 21:47:22 --> Loader Class Initialized
INFO - 2017-01-12 21:47:22 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:22 --> Controller Class Initialized
INFO - 2017-01-12 21:47:22 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:22 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:22 --> Total execution time: 0.0146
INFO - 2017-01-12 21:47:24 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:24 --> Total execution time: 5.9347
INFO - 2017-01-12 21:47:24 --> Config Class Initialized
INFO - 2017-01-12 21:47:24 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:24 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:24 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:24 --> URI Class Initialized
INFO - 2017-01-12 21:47:24 --> Router Class Initialized
INFO - 2017-01-12 21:47:24 --> Output Class Initialized
INFO - 2017-01-12 21:47:24 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:24 --> Input Class Initialized
INFO - 2017-01-12 21:47:24 --> Language Class Initialized
INFO - 2017-01-12 21:47:24 --> Loader Class Initialized
INFO - 2017-01-12 21:47:24 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:24 --> Controller Class Initialized
INFO - 2017-01-12 21:47:24 --> Upload Class Initialized
INFO - 2017-01-12 21:47:24 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:24 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:24 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 21:47:24 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:24 --> Total execution time: 0.0241
INFO - 2017-01-12 21:47:32 --> Config Class Initialized
INFO - 2017-01-12 21:47:32 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:32 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:32 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:32 --> URI Class Initialized
INFO - 2017-01-12 21:47:32 --> Router Class Initialized
INFO - 2017-01-12 21:47:32 --> Output Class Initialized
INFO - 2017-01-12 21:47:32 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:32 --> Input Class Initialized
INFO - 2017-01-12 21:47:32 --> Language Class Initialized
INFO - 2017-01-12 21:47:32 --> Loader Class Initialized
INFO - 2017-01-12 21:47:32 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:32 --> Controller Class Initialized
INFO - 2017-01-12 21:47:32 --> Upload Class Initialized
INFO - 2017-01-12 21:47:32 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:32 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:32 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:32 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:32 --> Total execution time: 0.0146
INFO - 2017-01-12 21:47:33 --> Config Class Initialized
INFO - 2017-01-12 21:47:33 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:33 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:33 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:33 --> URI Class Initialized
INFO - 2017-01-12 21:47:33 --> Router Class Initialized
INFO - 2017-01-12 21:47:33 --> Output Class Initialized
INFO - 2017-01-12 21:47:33 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:33 --> Input Class Initialized
INFO - 2017-01-12 21:47:33 --> Language Class Initialized
INFO - 2017-01-12 21:47:33 --> Loader Class Initialized
INFO - 2017-01-12 21:47:33 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:33 --> Controller Class Initialized
INFO - 2017-01-12 21:47:33 --> Upload Class Initialized
INFO - 2017-01-12 21:47:33 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:33 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:33 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 21:47:33 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:33 --> Total execution time: 0.0156
INFO - 2017-01-12 21:47:40 --> Config Class Initialized
INFO - 2017-01-12 21:47:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:40 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:40 --> URI Class Initialized
INFO - 2017-01-12 21:47:40 --> Router Class Initialized
INFO - 2017-01-12 21:47:40 --> Output Class Initialized
INFO - 2017-01-12 21:47:40 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:40 --> Input Class Initialized
INFO - 2017-01-12 21:47:40 --> Language Class Initialized
INFO - 2017-01-12 21:47:40 --> Loader Class Initialized
INFO - 2017-01-12 21:47:40 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:40 --> Controller Class Initialized
INFO - 2017-01-12 21:47:40 --> Helper loaded: date_helper
INFO - 2017-01-12 21:47:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:40 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:40 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:47:40 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:40 --> Total execution time: 0.0777
INFO - 2017-01-12 21:47:40 --> Config Class Initialized
INFO - 2017-01-12 21:47:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:40 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:40 --> URI Class Initialized
INFO - 2017-01-12 21:47:40 --> Router Class Initialized
INFO - 2017-01-12 21:47:40 --> Output Class Initialized
INFO - 2017-01-12 21:47:40 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:40 --> Input Class Initialized
INFO - 2017-01-12 21:47:40 --> Language Class Initialized
INFO - 2017-01-12 21:47:40 --> Loader Class Initialized
INFO - 2017-01-12 21:47:40 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:40 --> Controller Class Initialized
INFO - 2017-01-12 21:47:40 --> Helper loaded: date_helper
INFO - 2017-01-12 21:47:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:40 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:40 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:40 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:40 --> Total execution time: 0.0145
INFO - 2017-01-12 21:47:40 --> Config Class Initialized
INFO - 2017-01-12 21:47:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:40 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:40 --> URI Class Initialized
INFO - 2017-01-12 21:47:40 --> Router Class Initialized
INFO - 2017-01-12 21:47:40 --> Output Class Initialized
INFO - 2017-01-12 21:47:40 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:40 --> Input Class Initialized
INFO - 2017-01-12 21:47:40 --> Language Class Initialized
INFO - 2017-01-12 21:47:40 --> Loader Class Initialized
INFO - 2017-01-12 21:47:40 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:40 --> Controller Class Initialized
INFO - 2017-01-12 21:47:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:47:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:40 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:40 --> Total execution time: 0.0136
INFO - 2017-01-12 21:47:43 --> Config Class Initialized
INFO - 2017-01-12 21:47:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:43 --> URI Class Initialized
INFO - 2017-01-12 21:47:43 --> Router Class Initialized
INFO - 2017-01-12 21:47:43 --> Output Class Initialized
INFO - 2017-01-12 21:47:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:43 --> Input Class Initialized
INFO - 2017-01-12 21:47:43 --> Language Class Initialized
INFO - 2017-01-12 21:47:43 --> Loader Class Initialized
INFO - 2017-01-12 21:47:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:43 --> Controller Class Initialized
INFO - 2017-01-12 21:47:43 --> Helper loaded: date_helper
INFO - 2017-01-12 21:47:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:43 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:43 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:47:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:43 --> Total execution time: 0.0791
INFO - 2017-01-12 21:47:43 --> Config Class Initialized
INFO - 2017-01-12 21:47:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:43 --> URI Class Initialized
INFO - 2017-01-12 21:47:43 --> Router Class Initialized
INFO - 2017-01-12 21:47:43 --> Output Class Initialized
INFO - 2017-01-12 21:47:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:43 --> Input Class Initialized
INFO - 2017-01-12 21:47:43 --> Language Class Initialized
INFO - 2017-01-12 21:47:43 --> Loader Class Initialized
INFO - 2017-01-12 21:47:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:43 --> Controller Class Initialized
INFO - 2017-01-12 21:47:43 --> Helper loaded: date_helper
INFO - 2017-01-12 21:47:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:43 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:43 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:43 --> Total execution time: 0.0141
INFO - 2017-01-12 21:47:43 --> Config Class Initialized
INFO - 2017-01-12 21:47:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:43 --> URI Class Initialized
INFO - 2017-01-12 21:47:43 --> Router Class Initialized
INFO - 2017-01-12 21:47:43 --> Output Class Initialized
INFO - 2017-01-12 21:47:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:43 --> Input Class Initialized
INFO - 2017-01-12 21:47:43 --> Language Class Initialized
INFO - 2017-01-12 21:47:43 --> Loader Class Initialized
INFO - 2017-01-12 21:47:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:43 --> Controller Class Initialized
INFO - 2017-01-12 21:47:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:43 --> Total execution time: 0.0140
INFO - 2017-01-12 21:47:45 --> Config Class Initialized
INFO - 2017-01-12 21:47:45 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:45 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:45 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:45 --> URI Class Initialized
INFO - 2017-01-12 21:47:45 --> Router Class Initialized
INFO - 2017-01-12 21:47:45 --> Output Class Initialized
INFO - 2017-01-12 21:47:45 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:45 --> Input Class Initialized
INFO - 2017-01-12 21:47:45 --> Language Class Initialized
INFO - 2017-01-12 21:47:45 --> Loader Class Initialized
INFO - 2017-01-12 21:47:45 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:45 --> Controller Class Initialized
INFO - 2017-01-12 21:47:45 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:45 --> Helper loaded: url_helper
INFO - 2017-01-12 21:47:45 --> Helper loaded: download_helper
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:45 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:45 --> Total execution time: 0.0175
INFO - 2017-01-12 21:47:45 --> Config Class Initialized
INFO - 2017-01-12 21:47:45 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:45 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:45 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:45 --> URI Class Initialized
INFO - 2017-01-12 21:47:45 --> Router Class Initialized
INFO - 2017-01-12 21:47:45 --> Output Class Initialized
INFO - 2017-01-12 21:47:45 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:45 --> Input Class Initialized
INFO - 2017-01-12 21:47:45 --> Language Class Initialized
INFO - 2017-01-12 21:47:45 --> Loader Class Initialized
INFO - 2017-01-12 21:47:45 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:45 --> Controller Class Initialized
INFO - 2017-01-12 21:47:45 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:45 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:45 --> Total execution time: 0.0145
INFO - 2017-01-12 21:47:46 --> Config Class Initialized
INFO - 2017-01-12 21:47:46 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:46 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:46 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:46 --> URI Class Initialized
INFO - 2017-01-12 21:47:46 --> Router Class Initialized
INFO - 2017-01-12 21:47:46 --> Output Class Initialized
INFO - 2017-01-12 21:47:46 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:46 --> Input Class Initialized
INFO - 2017-01-12 21:47:46 --> Language Class Initialized
INFO - 2017-01-12 21:47:46 --> Loader Class Initialized
INFO - 2017-01-12 21:47:46 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:46 --> Controller Class Initialized
INFO - 2017-01-12 21:47:46 --> Upload Class Initialized
INFO - 2017-01-12 21:47:46 --> Helper loaded: date_helper
INFO - 2017-01-12 21:47:46 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:46 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:46 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:47:46 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:46 --> Total execution time: 0.0467
INFO - 2017-01-12 21:47:46 --> Config Class Initialized
INFO - 2017-01-12 21:47:46 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:46 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:46 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:46 --> URI Class Initialized
INFO - 2017-01-12 21:47:46 --> Router Class Initialized
INFO - 2017-01-12 21:47:46 --> Output Class Initialized
INFO - 2017-01-12 21:47:46 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:46 --> Input Class Initialized
INFO - 2017-01-12 21:47:46 --> Language Class Initialized
INFO - 2017-01-12 21:47:46 --> Loader Class Initialized
INFO - 2017-01-12 21:47:46 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:46 --> Controller Class Initialized
INFO - 2017-01-12 21:47:46 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:47:46 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:46 --> Total execution time: 0.0140
INFO - 2017-01-12 21:47:48 --> Config Class Initialized
INFO - 2017-01-12 21:47:48 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:47:48 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:47:48 --> Utf8 Class Initialized
INFO - 2017-01-12 21:47:48 --> URI Class Initialized
INFO - 2017-01-12 21:47:48 --> Router Class Initialized
INFO - 2017-01-12 21:47:48 --> Output Class Initialized
INFO - 2017-01-12 21:47:48 --> Security Class Initialized
DEBUG - 2017-01-12 21:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:47:48 --> Input Class Initialized
INFO - 2017-01-12 21:47:48 --> Language Class Initialized
INFO - 2017-01-12 21:47:48 --> Loader Class Initialized
INFO - 2017-01-12 21:47:48 --> Database Driver Class Initialized
INFO - 2017-01-12 21:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:47:48 --> Controller Class Initialized
INFO - 2017-01-12 21:47:48 --> Upload Class Initialized
INFO - 2017-01-12 21:47:48 --> Helper loaded: date_helper
INFO - 2017-01-12 21:47:48 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:47:48 --> Helper loaded: form_helper
INFO - 2017-01-12 21:47:48 --> Form Validation Class Initialized
INFO - 2017-01-12 21:47:48 --> Final output sent to browser
DEBUG - 2017-01-12 21:47:48 --> Total execution time: 0.0153
INFO - 2017-01-12 21:48:04 --> Config Class Initialized
INFO - 2017-01-12 21:48:04 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:48:04 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:48:04 --> Utf8 Class Initialized
INFO - 2017-01-12 21:48:04 --> URI Class Initialized
INFO - 2017-01-12 21:48:04 --> Router Class Initialized
INFO - 2017-01-12 21:48:04 --> Output Class Initialized
INFO - 2017-01-12 21:48:04 --> Security Class Initialized
DEBUG - 2017-01-12 21:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:48:04 --> Input Class Initialized
INFO - 2017-01-12 21:48:04 --> Language Class Initialized
INFO - 2017-01-12 21:48:04 --> Loader Class Initialized
INFO - 2017-01-12 21:48:04 --> Database Driver Class Initialized
INFO - 2017-01-12 21:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:48:04 --> Controller Class Initialized
INFO - 2017-01-12 21:48:04 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:48:04 --> Helper loaded: url_helper
INFO - 2017-01-12 21:48:04 --> Helper loaded: download_helper
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:48:04 --> Final output sent to browser
DEBUG - 2017-01-12 21:48:04 --> Total execution time: 0.0173
INFO - 2017-01-12 21:48:04 --> Config Class Initialized
INFO - 2017-01-12 21:48:04 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:48:04 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:48:04 --> Utf8 Class Initialized
INFO - 2017-01-12 21:48:04 --> URI Class Initialized
INFO - 2017-01-12 21:48:04 --> Router Class Initialized
INFO - 2017-01-12 21:48:04 --> Output Class Initialized
INFO - 2017-01-12 21:48:04 --> Security Class Initialized
DEBUG - 2017-01-12 21:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:48:04 --> Input Class Initialized
INFO - 2017-01-12 21:48:04 --> Language Class Initialized
INFO - 2017-01-12 21:48:04 --> Loader Class Initialized
INFO - 2017-01-12 21:48:04 --> Database Driver Class Initialized
INFO - 2017-01-12 21:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:48:04 --> Controller Class Initialized
INFO - 2017-01-12 21:48:04 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:48:04 --> Final output sent to browser
DEBUG - 2017-01-12 21:48:04 --> Total execution time: 0.0143
INFO - 2017-01-12 21:48:46 --> Config Class Initialized
INFO - 2017-01-12 21:48:46 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:48:46 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:48:46 --> Utf8 Class Initialized
INFO - 2017-01-12 21:48:46 --> URI Class Initialized
INFO - 2017-01-12 21:48:46 --> Router Class Initialized
INFO - 2017-01-12 21:48:46 --> Output Class Initialized
INFO - 2017-01-12 21:48:46 --> Security Class Initialized
DEBUG - 2017-01-12 21:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:48:46 --> Input Class Initialized
INFO - 2017-01-12 21:48:46 --> Language Class Initialized
INFO - 2017-01-12 21:48:46 --> Loader Class Initialized
INFO - 2017-01-12 21:48:46 --> Database Driver Class Initialized
INFO - 2017-01-12 21:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:48:46 --> Controller Class Initialized
INFO - 2017-01-12 21:48:46 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:48:46 --> Helper loaded: url_helper
INFO - 2017-01-12 21:48:46 --> Helper loaded: download_helper
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:48:46 --> Final output sent to browser
DEBUG - 2017-01-12 21:48:46 --> Total execution time: 0.0171
INFO - 2017-01-12 21:48:46 --> Config Class Initialized
INFO - 2017-01-12 21:48:46 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:48:46 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:48:46 --> Utf8 Class Initialized
INFO - 2017-01-12 21:48:46 --> URI Class Initialized
INFO - 2017-01-12 21:48:46 --> Router Class Initialized
INFO - 2017-01-12 21:48:46 --> Output Class Initialized
INFO - 2017-01-12 21:48:46 --> Security Class Initialized
DEBUG - 2017-01-12 21:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:48:46 --> Input Class Initialized
INFO - 2017-01-12 21:48:46 --> Language Class Initialized
INFO - 2017-01-12 21:48:46 --> Loader Class Initialized
INFO - 2017-01-12 21:48:46 --> Database Driver Class Initialized
INFO - 2017-01-12 21:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:48:46 --> Controller Class Initialized
INFO - 2017-01-12 21:48:46 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:48:46 --> Final output sent to browser
DEBUG - 2017-01-12 21:48:46 --> Total execution time: 0.0136
INFO - 2017-01-12 21:48:52 --> Config Class Initialized
INFO - 2017-01-12 21:48:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:48:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:48:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:48:52 --> URI Class Initialized
INFO - 2017-01-12 21:48:52 --> Router Class Initialized
INFO - 2017-01-12 21:48:52 --> Output Class Initialized
INFO - 2017-01-12 21:48:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:48:52 --> Input Class Initialized
INFO - 2017-01-12 21:48:52 --> Language Class Initialized
INFO - 2017-01-12 21:48:52 --> Loader Class Initialized
INFO - 2017-01-12 21:48:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:48:52 --> Controller Class Initialized
INFO - 2017-01-12 21:48:52 --> Helper loaded: date_helper
DEBUG - 2017-01-12 21:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:48:52 --> Helper loaded: url_helper
INFO - 2017-01-12 21:48:52 --> Helper loaded: download_helper
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:48:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:48:52 --> Total execution time: 0.0168
INFO - 2017-01-12 21:48:52 --> Config Class Initialized
INFO - 2017-01-12 21:48:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:48:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:48:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:48:52 --> URI Class Initialized
INFO - 2017-01-12 21:48:52 --> Router Class Initialized
INFO - 2017-01-12 21:48:52 --> Output Class Initialized
INFO - 2017-01-12 21:48:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:48:52 --> Input Class Initialized
INFO - 2017-01-12 21:48:52 --> Language Class Initialized
INFO - 2017-01-12 21:48:52 --> Loader Class Initialized
INFO - 2017-01-12 21:48:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:48:52 --> Controller Class Initialized
INFO - 2017-01-12 21:48:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:48:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:48:52 --> Total execution time: 0.0133
INFO - 2017-01-12 21:49:08 --> Config Class Initialized
INFO - 2017-01-12 21:49:08 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:49:08 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:49:08 --> Utf8 Class Initialized
INFO - 2017-01-12 21:49:08 --> URI Class Initialized
INFO - 2017-01-12 21:49:08 --> Router Class Initialized
INFO - 2017-01-12 21:49:08 --> Output Class Initialized
INFO - 2017-01-12 21:49:08 --> Security Class Initialized
DEBUG - 2017-01-12 21:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:49:08 --> Input Class Initialized
INFO - 2017-01-12 21:49:08 --> Language Class Initialized
INFO - 2017-01-12 21:49:08 --> Loader Class Initialized
INFO - 2017-01-12 21:49:08 --> Database Driver Class Initialized
INFO - 2017-01-12 21:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:49:08 --> Controller Class Initialized
INFO - 2017-01-12 21:49:08 --> Upload Class Initialized
INFO - 2017-01-12 21:49:08 --> Helper loaded: date_helper
INFO - 2017-01-12 21:49:08 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:49:08 --> Helper loaded: form_helper
INFO - 2017-01-12 21:49:08 --> Form Validation Class Initialized
INFO - 2017-01-12 21:49:08 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-01-12 21:49:08 --> You did not select a file to upload.
INFO - 2017-01-12 21:49:08 --> Final output sent to browser
DEBUG - 2017-01-12 21:49:08 --> Total execution time: 0.0356
INFO - 2017-01-12 21:49:08 --> Config Class Initialized
INFO - 2017-01-12 21:49:08 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:49:08 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:49:08 --> Utf8 Class Initialized
INFO - 2017-01-12 21:49:08 --> URI Class Initialized
INFO - 2017-01-12 21:49:08 --> Router Class Initialized
INFO - 2017-01-12 21:49:08 --> Output Class Initialized
INFO - 2017-01-12 21:49:08 --> Security Class Initialized
DEBUG - 2017-01-12 21:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:49:08 --> Input Class Initialized
INFO - 2017-01-12 21:49:08 --> Language Class Initialized
INFO - 2017-01-12 21:49:08 --> Loader Class Initialized
INFO - 2017-01-12 21:49:08 --> Database Driver Class Initialized
INFO - 2017-01-12 21:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:49:08 --> Controller Class Initialized
INFO - 2017-01-12 21:49:08 --> Upload Class Initialized
INFO - 2017-01-12 21:49:08 --> Helper loaded: date_helper
INFO - 2017-01-12 21:49:08 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:49:08 --> Helper loaded: form_helper
INFO - 2017-01-12 21:49:08 --> Form Validation Class Initialized
INFO - 2017-01-12 21:49:08 --> Final output sent to browser
DEBUG - 2017-01-12 21:49:08 --> Total execution time: 0.0153
INFO - 2017-01-12 21:50:12 --> Config Class Initialized
INFO - 2017-01-12 21:50:12 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:12 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:12 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:12 --> URI Class Initialized
INFO - 2017-01-12 21:50:12 --> Router Class Initialized
INFO - 2017-01-12 21:50:12 --> Output Class Initialized
INFO - 2017-01-12 21:50:12 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:12 --> Input Class Initialized
INFO - 2017-01-12 21:50:12 --> Language Class Initialized
INFO - 2017-01-12 21:50:12 --> Loader Class Initialized
INFO - 2017-01-12 21:50:12 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:12 --> Controller Class Initialized
INFO - 2017-01-12 21:50:12 --> Upload Class Initialized
INFO - 2017-01-12 21:50:12 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:12 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:12 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:12 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:12 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-12 21:50:12 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2017-01-12 21:50:12 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:12 --> Total execution time: 0.0146
INFO - 2017-01-12 21:50:12 --> Config Class Initialized
INFO - 2017-01-12 21:50:12 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:12 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:12 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:12 --> URI Class Initialized
INFO - 2017-01-12 21:50:12 --> Router Class Initialized
INFO - 2017-01-12 21:50:12 --> Output Class Initialized
INFO - 2017-01-12 21:50:12 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:12 --> Input Class Initialized
INFO - 2017-01-12 21:50:12 --> Language Class Initialized
INFO - 2017-01-12 21:50:12 --> Loader Class Initialized
INFO - 2017-01-12 21:50:12 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:12 --> Controller Class Initialized
INFO - 2017-01-12 21:50:12 --> Upload Class Initialized
INFO - 2017-01-12 21:50:12 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:12 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:12 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:12 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:12 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:12 --> Total execution time: 0.0156
INFO - 2017-01-12 21:50:31 --> Config Class Initialized
INFO - 2017-01-12 21:50:31 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:31 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:31 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:31 --> URI Class Initialized
INFO - 2017-01-12 21:50:31 --> Router Class Initialized
INFO - 2017-01-12 21:50:31 --> Output Class Initialized
INFO - 2017-01-12 21:50:31 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:31 --> Input Class Initialized
INFO - 2017-01-12 21:50:31 --> Language Class Initialized
INFO - 2017-01-12 21:50:31 --> Loader Class Initialized
INFO - 2017-01-12 21:50:31 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:31 --> Controller Class Initialized
INFO - 2017-01-12 21:50:31 --> Upload Class Initialized
INFO - 2017-01-12 21:50:31 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:31 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:31 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:31 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:31 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-12 21:50:31 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2017-01-12 21:50:31 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:31 --> Total execution time: 0.0151
INFO - 2017-01-12 21:50:31 --> Config Class Initialized
INFO - 2017-01-12 21:50:31 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:31 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:31 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:31 --> URI Class Initialized
INFO - 2017-01-12 21:50:31 --> Router Class Initialized
INFO - 2017-01-12 21:50:31 --> Output Class Initialized
INFO - 2017-01-12 21:50:31 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:31 --> Input Class Initialized
INFO - 2017-01-12 21:50:31 --> Language Class Initialized
INFO - 2017-01-12 21:50:31 --> Loader Class Initialized
INFO - 2017-01-12 21:50:31 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:31 --> Controller Class Initialized
INFO - 2017-01-12 21:50:31 --> Upload Class Initialized
INFO - 2017-01-12 21:50:31 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:31 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:31 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:31 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:31 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:31 --> Total execution time: 0.0208
INFO - 2017-01-12 21:50:34 --> Config Class Initialized
INFO - 2017-01-12 21:50:34 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:34 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:34 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:34 --> URI Class Initialized
INFO - 2017-01-12 21:50:34 --> Router Class Initialized
INFO - 2017-01-12 21:50:34 --> Output Class Initialized
INFO - 2017-01-12 21:50:34 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:34 --> Input Class Initialized
INFO - 2017-01-12 21:50:34 --> Language Class Initialized
INFO - 2017-01-12 21:50:34 --> Loader Class Initialized
INFO - 2017-01-12 21:50:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:34 --> Controller Class Initialized
INFO - 2017-01-12 21:50:34 --> Upload Class Initialized
INFO - 2017-01-12 21:50:34 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:34 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:34 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:50:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:34 --> Total execution time: 0.0182
INFO - 2017-01-12 21:50:34 --> Config Class Initialized
INFO - 2017-01-12 21:50:34 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:34 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:34 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:34 --> URI Class Initialized
INFO - 2017-01-12 21:50:34 --> Router Class Initialized
INFO - 2017-01-12 21:50:34 --> Output Class Initialized
INFO - 2017-01-12 21:50:34 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:34 --> Input Class Initialized
INFO - 2017-01-12 21:50:34 --> Language Class Initialized
INFO - 2017-01-12 21:50:34 --> Loader Class Initialized
INFO - 2017-01-12 21:50:34 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:34 --> Controller Class Initialized
INFO - 2017-01-12 21:50:34 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:50:34 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:34 --> Total execution time: 0.0135
INFO - 2017-01-12 21:50:38 --> Config Class Initialized
INFO - 2017-01-12 21:50:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:38 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:38 --> URI Class Initialized
INFO - 2017-01-12 21:50:38 --> Router Class Initialized
INFO - 2017-01-12 21:50:38 --> Output Class Initialized
INFO - 2017-01-12 21:50:38 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:38 --> Input Class Initialized
INFO - 2017-01-12 21:50:38 --> Language Class Initialized
INFO - 2017-01-12 21:50:38 --> Loader Class Initialized
INFO - 2017-01-12 21:50:38 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:38 --> Controller Class Initialized
INFO - 2017-01-12 21:50:38 --> Upload Class Initialized
INFO - 2017-01-12 21:50:38 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:38 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:38 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:38 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:38 --> Total execution time: 0.0222
INFO - 2017-01-12 21:50:43 --> Config Class Initialized
INFO - 2017-01-12 21:50:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:43 --> URI Class Initialized
INFO - 2017-01-12 21:50:43 --> Router Class Initialized
INFO - 2017-01-12 21:50:43 --> Output Class Initialized
INFO - 2017-01-12 21:50:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:43 --> Input Class Initialized
INFO - 2017-01-12 21:50:43 --> Language Class Initialized
INFO - 2017-01-12 21:50:43 --> Loader Class Initialized
INFO - 2017-01-12 21:50:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:43 --> Controller Class Initialized
INFO - 2017-01-12 21:50:43 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:43 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:43 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:50:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:43 --> Total execution time: 0.0145
INFO - 2017-01-12 21:50:43 --> Config Class Initialized
INFO - 2017-01-12 21:50:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:43 --> URI Class Initialized
INFO - 2017-01-12 21:50:43 --> Router Class Initialized
INFO - 2017-01-12 21:50:43 --> Output Class Initialized
INFO - 2017-01-12 21:50:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:43 --> Input Class Initialized
INFO - 2017-01-12 21:50:43 --> Language Class Initialized
INFO - 2017-01-12 21:50:43 --> Loader Class Initialized
INFO - 2017-01-12 21:50:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:43 --> Controller Class Initialized
INFO - 2017-01-12 21:50:43 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:43 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:43 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:43 --> Total execution time: 0.0144
INFO - 2017-01-12 21:50:43 --> Config Class Initialized
INFO - 2017-01-12 21:50:43 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:43 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:43 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:43 --> URI Class Initialized
INFO - 2017-01-12 21:50:43 --> Router Class Initialized
INFO - 2017-01-12 21:50:43 --> Output Class Initialized
INFO - 2017-01-12 21:50:43 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:43 --> Input Class Initialized
INFO - 2017-01-12 21:50:43 --> Language Class Initialized
INFO - 2017-01-12 21:50:43 --> Loader Class Initialized
INFO - 2017-01-12 21:50:43 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:43 --> Controller Class Initialized
INFO - 2017-01-12 21:50:43 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:50:43 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:43 --> Total execution time: 0.0140
INFO - 2017-01-12 21:50:47 --> Config Class Initialized
INFO - 2017-01-12 21:50:47 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:47 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:47 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:47 --> URI Class Initialized
INFO - 2017-01-12 21:50:47 --> Router Class Initialized
INFO - 2017-01-12 21:50:47 --> Output Class Initialized
INFO - 2017-01-12 21:50:47 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:47 --> Input Class Initialized
INFO - 2017-01-12 21:50:47 --> Language Class Initialized
INFO - 2017-01-12 21:50:47 --> Loader Class Initialized
INFO - 2017-01-12 21:50:47 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:47 --> Controller Class Initialized
INFO - 2017-01-12 21:50:47 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:47 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:47 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:47 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:47 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:47 --> Total execution time: 0.0141
INFO - 2017-01-12 21:50:49 --> Config Class Initialized
INFO - 2017-01-12 21:50:49 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:49 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:49 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:49 --> URI Class Initialized
INFO - 2017-01-12 21:50:49 --> Router Class Initialized
INFO - 2017-01-12 21:50:49 --> Output Class Initialized
INFO - 2017-01-12 21:50:49 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:49 --> Input Class Initialized
INFO - 2017-01-12 21:50:49 --> Language Class Initialized
INFO - 2017-01-12 21:50:49 --> Loader Class Initialized
INFO - 2017-01-12 21:50:49 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:49 --> Controller Class Initialized
INFO - 2017-01-12 21:50:49 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:49 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:49 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:49 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:49 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:49 --> Total execution time: 0.0152
INFO - 2017-01-12 21:50:50 --> Config Class Initialized
INFO - 2017-01-12 21:50:50 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:50 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:50 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:50 --> URI Class Initialized
INFO - 2017-01-12 21:50:50 --> Router Class Initialized
INFO - 2017-01-12 21:50:50 --> Output Class Initialized
INFO - 2017-01-12 21:50:50 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:50 --> Input Class Initialized
INFO - 2017-01-12 21:50:50 --> Language Class Initialized
INFO - 2017-01-12 21:50:50 --> Loader Class Initialized
INFO - 2017-01-12 21:50:50 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:50 --> Controller Class Initialized
INFO - 2017-01-12 21:50:50 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:50 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:50 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:50 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:50 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:50 --> Total execution time: 0.0144
INFO - 2017-01-12 21:50:51 --> Config Class Initialized
INFO - 2017-01-12 21:50:51 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:51 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:51 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:51 --> URI Class Initialized
INFO - 2017-01-12 21:50:51 --> Router Class Initialized
INFO - 2017-01-12 21:50:51 --> Output Class Initialized
INFO - 2017-01-12 21:50:51 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:51 --> Input Class Initialized
INFO - 2017-01-12 21:50:51 --> Language Class Initialized
INFO - 2017-01-12 21:50:51 --> Loader Class Initialized
INFO - 2017-01-12 21:50:51 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:51 --> Controller Class Initialized
INFO - 2017-01-12 21:50:51 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:51 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:51 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:51 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:51 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:51 --> Total execution time: 0.0145
INFO - 2017-01-12 21:50:52 --> Config Class Initialized
INFO - 2017-01-12 21:50:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:52 --> URI Class Initialized
INFO - 2017-01-12 21:50:52 --> Router Class Initialized
INFO - 2017-01-12 21:50:52 --> Output Class Initialized
INFO - 2017-01-12 21:50:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:52 --> Input Class Initialized
INFO - 2017-01-12 21:50:52 --> Language Class Initialized
INFO - 2017-01-12 21:50:52 --> Loader Class Initialized
INFO - 2017-01-12 21:50:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:52 --> Controller Class Initialized
INFO - 2017-01-12 21:50:52 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:52 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:52 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:52 --> Total execution time: 0.0152
INFO - 2017-01-12 21:50:57 --> Config Class Initialized
INFO - 2017-01-12 21:50:57 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:57 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:57 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:57 --> URI Class Initialized
INFO - 2017-01-12 21:50:57 --> Router Class Initialized
INFO - 2017-01-12 21:50:57 --> Output Class Initialized
INFO - 2017-01-12 21:50:57 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:57 --> Input Class Initialized
INFO - 2017-01-12 21:50:57 --> Language Class Initialized
INFO - 2017-01-12 21:50:57 --> Loader Class Initialized
INFO - 2017-01-12 21:50:57 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:57 --> Controller Class Initialized
INFO - 2017-01-12 21:50:57 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:57 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:57 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:57 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:57 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:57 --> Total execution time: 0.0148
INFO - 2017-01-12 21:50:58 --> Config Class Initialized
INFO - 2017-01-12 21:50:58 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:50:58 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:50:58 --> Utf8 Class Initialized
INFO - 2017-01-12 21:50:58 --> URI Class Initialized
INFO - 2017-01-12 21:50:58 --> Router Class Initialized
INFO - 2017-01-12 21:50:58 --> Output Class Initialized
INFO - 2017-01-12 21:50:58 --> Security Class Initialized
DEBUG - 2017-01-12 21:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:50:58 --> Input Class Initialized
INFO - 2017-01-12 21:50:58 --> Language Class Initialized
INFO - 2017-01-12 21:50:58 --> Loader Class Initialized
INFO - 2017-01-12 21:50:58 --> Database Driver Class Initialized
INFO - 2017-01-12 21:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:50:58 --> Controller Class Initialized
INFO - 2017-01-12 21:50:58 --> Helper loaded: date_helper
INFO - 2017-01-12 21:50:58 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:50:58 --> Helper loaded: form_helper
INFO - 2017-01-12 21:50:58 --> Form Validation Class Initialized
INFO - 2017-01-12 21:50:58 --> Final output sent to browser
DEBUG - 2017-01-12 21:50:58 --> Total execution time: 0.0146
INFO - 2017-01-12 21:51:17 --> Config Class Initialized
INFO - 2017-01-12 21:51:17 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:51:17 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:51:17 --> Utf8 Class Initialized
INFO - 2017-01-12 21:51:17 --> URI Class Initialized
INFO - 2017-01-12 21:51:17 --> Router Class Initialized
INFO - 2017-01-12 21:51:17 --> Output Class Initialized
INFO - 2017-01-12 21:51:17 --> Security Class Initialized
DEBUG - 2017-01-12 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:51:17 --> Input Class Initialized
INFO - 2017-01-12 21:51:17 --> Language Class Initialized
INFO - 2017-01-12 21:51:17 --> Loader Class Initialized
INFO - 2017-01-12 21:51:17 --> Database Driver Class Initialized
INFO - 2017-01-12 21:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:51:17 --> Controller Class Initialized
INFO - 2017-01-12 21:51:17 --> Upload Class Initialized
INFO - 2017-01-12 21:51:17 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:51:17 --> Helper loaded: form_helper
INFO - 2017-01-12 21:51:17 --> Form Validation Class Initialized
INFO - 2017-01-12 21:51:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:51:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:51:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:51:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:51:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:51:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:51:17 --> Final output sent to browser
DEBUG - 2017-01-12 21:51:17 --> Total execution time: 0.0157
INFO - 2017-01-12 21:51:18 --> Config Class Initialized
INFO - 2017-01-12 21:51:18 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:51:18 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:51:18 --> Utf8 Class Initialized
INFO - 2017-01-12 21:51:18 --> URI Class Initialized
INFO - 2017-01-12 21:51:18 --> Router Class Initialized
INFO - 2017-01-12 21:51:18 --> Output Class Initialized
INFO - 2017-01-12 21:51:18 --> Security Class Initialized
DEBUG - 2017-01-12 21:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:51:18 --> Input Class Initialized
INFO - 2017-01-12 21:51:18 --> Language Class Initialized
INFO - 2017-01-12 21:51:18 --> Loader Class Initialized
INFO - 2017-01-12 21:51:18 --> Database Driver Class Initialized
INFO - 2017-01-12 21:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:51:18 --> Controller Class Initialized
INFO - 2017-01-12 21:51:18 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:51:18 --> Final output sent to browser
DEBUG - 2017-01-12 21:51:18 --> Total execution time: 0.0136
INFO - 2017-01-12 21:54:37 --> Config Class Initialized
INFO - 2017-01-12 21:54:37 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:54:37 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:54:37 --> Utf8 Class Initialized
INFO - 2017-01-12 21:54:37 --> URI Class Initialized
INFO - 2017-01-12 21:54:37 --> Router Class Initialized
INFO - 2017-01-12 21:54:37 --> Output Class Initialized
INFO - 2017-01-12 21:54:37 --> Security Class Initialized
DEBUG - 2017-01-12 21:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:54:37 --> Input Class Initialized
INFO - 2017-01-12 21:54:37 --> Language Class Initialized
INFO - 2017-01-12 21:54:37 --> Loader Class Initialized
INFO - 2017-01-12 21:54:37 --> Database Driver Class Initialized
INFO - 2017-01-12 21:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:54:37 --> Controller Class Initialized
INFO - 2017-01-12 21:54:37 --> Upload Class Initialized
INFO - 2017-01-12 21:54:37 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:54:37 --> Helper loaded: form_helper
INFO - 2017-01-12 21:54:37 --> Form Validation Class Initialized
INFO - 2017-01-12 21:54:37 --> Final output sent to browser
DEBUG - 2017-01-12 21:54:37 --> Total execution time: 0.0149
INFO - 2017-01-12 21:54:37 --> Config Class Initialized
INFO - 2017-01-12 21:54:37 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:54:37 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:54:37 --> Utf8 Class Initialized
INFO - 2017-01-12 21:54:37 --> URI Class Initialized
INFO - 2017-01-12 21:54:37 --> Router Class Initialized
INFO - 2017-01-12 21:54:37 --> Output Class Initialized
INFO - 2017-01-12 21:54:37 --> Security Class Initialized
DEBUG - 2017-01-12 21:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:54:37 --> Input Class Initialized
INFO - 2017-01-12 21:54:37 --> Language Class Initialized
INFO - 2017-01-12 21:54:37 --> Loader Class Initialized
INFO - 2017-01-12 21:54:37 --> Database Driver Class Initialized
INFO - 2017-01-12 21:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:54:37 --> Controller Class Initialized
INFO - 2017-01-12 21:54:37 --> Upload Class Initialized
INFO - 2017-01-12 21:54:37 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:54:37 --> Helper loaded: form_helper
INFO - 2017-01-12 21:54:37 --> Form Validation Class Initialized
INFO - 2017-01-12 21:54:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 21:54:37 --> Final output sent to browser
DEBUG - 2017-01-12 21:54:37 --> Total execution time: 0.0159
INFO - 2017-01-12 21:55:51 --> Config Class Initialized
INFO - 2017-01-12 21:55:51 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:55:51 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:55:51 --> Utf8 Class Initialized
INFO - 2017-01-12 21:55:51 --> URI Class Initialized
INFO - 2017-01-12 21:55:51 --> Router Class Initialized
INFO - 2017-01-12 21:55:51 --> Output Class Initialized
INFO - 2017-01-12 21:55:51 --> Security Class Initialized
DEBUG - 2017-01-12 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:55:51 --> Input Class Initialized
INFO - 2017-01-12 21:55:51 --> Language Class Initialized
INFO - 2017-01-12 21:55:51 --> Loader Class Initialized
INFO - 2017-01-12 21:55:51 --> Database Driver Class Initialized
INFO - 2017-01-12 21:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:55:51 --> Controller Class Initialized
INFO - 2017-01-12 21:55:51 --> Upload Class Initialized
INFO - 2017-01-12 21:55:51 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:55:51 --> Helper loaded: form_helper
INFO - 2017-01-12 21:55:51 --> Form Validation Class Initialized
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:55:51 --> Final output sent to browser
DEBUG - 2017-01-12 21:55:51 --> Total execution time: 0.0163
INFO - 2017-01-12 21:55:51 --> Config Class Initialized
INFO - 2017-01-12 21:55:51 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:55:51 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:55:51 --> Utf8 Class Initialized
INFO - 2017-01-12 21:55:51 --> URI Class Initialized
INFO - 2017-01-12 21:55:51 --> Router Class Initialized
INFO - 2017-01-12 21:55:51 --> Output Class Initialized
INFO - 2017-01-12 21:55:51 --> Security Class Initialized
DEBUG - 2017-01-12 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:55:51 --> Input Class Initialized
INFO - 2017-01-12 21:55:51 --> Language Class Initialized
INFO - 2017-01-12 21:55:51 --> Loader Class Initialized
INFO - 2017-01-12 21:55:51 --> Database Driver Class Initialized
INFO - 2017-01-12 21:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:55:51 --> Controller Class Initialized
INFO - 2017-01-12 21:55:51 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:55:51 --> Final output sent to browser
DEBUG - 2017-01-12 21:55:51 --> Total execution time: 0.0141
INFO - 2017-01-12 21:55:52 --> Config Class Initialized
INFO - 2017-01-12 21:55:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:55:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:55:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:55:52 --> URI Class Initialized
INFO - 2017-01-12 21:55:52 --> Router Class Initialized
INFO - 2017-01-12 21:55:52 --> Output Class Initialized
INFO - 2017-01-12 21:55:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:55:52 --> Input Class Initialized
INFO - 2017-01-12 21:55:52 --> Language Class Initialized
INFO - 2017-01-12 21:55:52 --> Loader Class Initialized
INFO - 2017-01-12 21:55:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:55:52 --> Controller Class Initialized
INFO - 2017-01-12 21:55:52 --> Upload Class Initialized
INFO - 2017-01-12 21:55:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:55:52 --> Helper loaded: form_helper
INFO - 2017-01-12 21:55:52 --> Form Validation Class Initialized
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 21:55:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:55:52 --> Total execution time: 0.0273
INFO - 2017-01-12 21:55:52 --> Config Class Initialized
INFO - 2017-01-12 21:55:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 21:55:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 21:55:52 --> Utf8 Class Initialized
INFO - 2017-01-12 21:55:52 --> URI Class Initialized
INFO - 2017-01-12 21:55:52 --> Router Class Initialized
INFO - 2017-01-12 21:55:52 --> Output Class Initialized
INFO - 2017-01-12 21:55:52 --> Security Class Initialized
DEBUG - 2017-01-12 21:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 21:55:52 --> Input Class Initialized
INFO - 2017-01-12 21:55:52 --> Language Class Initialized
INFO - 2017-01-12 21:55:52 --> Loader Class Initialized
INFO - 2017-01-12 21:55:52 --> Database Driver Class Initialized
INFO - 2017-01-12 21:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 21:55:52 --> Controller Class Initialized
INFO - 2017-01-12 21:55:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 21:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 21:55:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 21:55:52 --> Final output sent to browser
DEBUG - 2017-01-12 21:55:52 --> Total execution time: 0.0375
INFO - 2017-01-12 22:02:04 --> Config Class Initialized
INFO - 2017-01-12 22:02:04 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:02:04 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:02:04 --> Utf8 Class Initialized
INFO - 2017-01-12 22:02:04 --> URI Class Initialized
INFO - 2017-01-12 22:02:04 --> Router Class Initialized
INFO - 2017-01-12 22:02:04 --> Output Class Initialized
INFO - 2017-01-12 22:02:04 --> Security Class Initialized
DEBUG - 2017-01-12 22:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:02:04 --> Input Class Initialized
INFO - 2017-01-12 22:02:04 --> Language Class Initialized
INFO - 2017-01-12 22:02:04 --> Loader Class Initialized
INFO - 2017-01-12 22:02:05 --> Database Driver Class Initialized
INFO - 2017-01-12 22:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:02:05 --> Controller Class Initialized
INFO - 2017-01-12 22:02:05 --> Upload Class Initialized
INFO - 2017-01-12 22:02:05 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:02:05 --> Helper loaded: form_helper
INFO - 2017-01-12 22:02:05 --> Form Validation Class Initialized
INFO - 2017-01-12 22:02:09 --> Final output sent to browser
DEBUG - 2017-01-12 22:02:09 --> Total execution time: 4.5093
INFO - 2017-01-12 22:02:09 --> Config Class Initialized
INFO - 2017-01-12 22:02:09 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:02:09 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:02:09 --> Utf8 Class Initialized
INFO - 2017-01-12 22:02:09 --> URI Class Initialized
INFO - 2017-01-12 22:02:09 --> Router Class Initialized
INFO - 2017-01-12 22:02:09 --> Output Class Initialized
INFO - 2017-01-12 22:02:09 --> Security Class Initialized
DEBUG - 2017-01-12 22:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:02:09 --> Input Class Initialized
INFO - 2017-01-12 22:02:09 --> Language Class Initialized
INFO - 2017-01-12 22:02:09 --> Loader Class Initialized
INFO - 2017-01-12 22:02:09 --> Database Driver Class Initialized
INFO - 2017-01-12 22:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:02:09 --> Controller Class Initialized
INFO - 2017-01-12 22:02:09 --> Upload Class Initialized
INFO - 2017-01-12 22:02:09 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:02:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:02:09 --> Helper loaded: form_helper
INFO - 2017-01-12 22:02:09 --> Form Validation Class Initialized
INFO - 2017-01-12 22:02:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 22:02:09 --> Final output sent to browser
DEBUG - 2017-01-12 22:02:09 --> Total execution time: 0.0352
INFO - 2017-01-12 22:12:18 --> Config Class Initialized
INFO - 2017-01-12 22:12:18 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:12:18 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:12:18 --> Utf8 Class Initialized
INFO - 2017-01-12 22:12:18 --> URI Class Initialized
INFO - 2017-01-12 22:12:19 --> Router Class Initialized
INFO - 2017-01-12 22:12:19 --> Output Class Initialized
INFO - 2017-01-12 22:12:19 --> Security Class Initialized
DEBUG - 2017-01-12 22:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:12:19 --> Input Class Initialized
INFO - 2017-01-12 22:12:19 --> Language Class Initialized
INFO - 2017-01-12 22:12:19 --> Loader Class Initialized
INFO - 2017-01-12 22:12:19 --> Database Driver Class Initialized
INFO - 2017-01-12 22:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:12:19 --> Controller Class Initialized
INFO - 2017-01-12 22:12:19 --> Upload Class Initialized
INFO - 2017-01-12 22:12:19 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:12:19 --> Helper loaded: form_helper
INFO - 2017-01-12 22:12:19 --> Form Validation Class Initialized
INFO - 2017-01-12 22:12:27 --> Final output sent to browser
DEBUG - 2017-01-12 22:12:27 --> Total execution time: 8.3507
INFO - 2017-01-12 22:12:27 --> Config Class Initialized
INFO - 2017-01-12 22:12:27 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:12:27 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:12:27 --> Utf8 Class Initialized
INFO - 2017-01-12 22:12:27 --> URI Class Initialized
INFO - 2017-01-12 22:12:27 --> Router Class Initialized
INFO - 2017-01-12 22:12:27 --> Output Class Initialized
INFO - 2017-01-12 22:12:27 --> Security Class Initialized
DEBUG - 2017-01-12 22:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:12:27 --> Input Class Initialized
INFO - 2017-01-12 22:12:27 --> Language Class Initialized
INFO - 2017-01-12 22:12:27 --> Loader Class Initialized
INFO - 2017-01-12 22:12:27 --> Database Driver Class Initialized
INFO - 2017-01-12 22:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:12:27 --> Controller Class Initialized
INFO - 2017-01-12 22:12:27 --> Upload Class Initialized
INFO - 2017-01-12 22:12:27 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:12:27 --> Helper loaded: form_helper
INFO - 2017-01-12 22:12:27 --> Form Validation Class Initialized
INFO - 2017-01-12 22:12:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 22:12:27 --> Final output sent to browser
DEBUG - 2017-01-12 22:12:27 --> Total execution time: 0.0166
INFO - 2017-01-12 22:13:23 --> Config Class Initialized
INFO - 2017-01-12 22:13:23 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:13:23 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:13:23 --> Utf8 Class Initialized
INFO - 2017-01-12 22:13:23 --> URI Class Initialized
INFO - 2017-01-12 22:13:23 --> Router Class Initialized
INFO - 2017-01-12 22:13:23 --> Output Class Initialized
INFO - 2017-01-12 22:13:23 --> Security Class Initialized
DEBUG - 2017-01-12 22:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:13:23 --> Input Class Initialized
INFO - 2017-01-12 22:13:23 --> Language Class Initialized
INFO - 2017-01-12 22:13:23 --> Loader Class Initialized
INFO - 2017-01-12 22:13:23 --> Database Driver Class Initialized
INFO - 2017-01-12 22:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:13:23 --> Controller Class Initialized
INFO - 2017-01-12 22:13:23 --> Upload Class Initialized
INFO - 2017-01-12 22:13:23 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:13:23 --> Helper loaded: form_helper
INFO - 2017-01-12 22:13:23 --> Form Validation Class Initialized
INFO - 2017-01-12 22:13:23 --> Final output sent to browser
DEBUG - 2017-01-12 22:13:23 --> Total execution time: 0.0332
INFO - 2017-01-12 22:14:33 --> Config Class Initialized
INFO - 2017-01-12 22:14:33 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:14:33 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:14:33 --> Utf8 Class Initialized
INFO - 2017-01-12 22:14:33 --> URI Class Initialized
INFO - 2017-01-12 22:14:33 --> Router Class Initialized
INFO - 2017-01-12 22:14:33 --> Output Class Initialized
INFO - 2017-01-12 22:14:33 --> Security Class Initialized
DEBUG - 2017-01-12 22:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:14:33 --> Input Class Initialized
INFO - 2017-01-12 22:14:33 --> Language Class Initialized
INFO - 2017-01-12 22:14:33 --> Loader Class Initialized
INFO - 2017-01-12 22:14:33 --> Database Driver Class Initialized
INFO - 2017-01-12 22:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:14:33 --> Controller Class Initialized
INFO - 2017-01-12 22:14:33 --> Upload Class Initialized
INFO - 2017-01-12 22:14:33 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:14:33 --> Helper loaded: form_helper
INFO - 2017-01-12 22:14:33 --> Form Validation Class Initialized
INFO - 2017-01-12 22:14:33 --> Final output sent to browser
DEBUG - 2017-01-12 22:14:33 --> Total execution time: 0.0624
INFO - 2017-01-12 22:14:33 --> Config Class Initialized
INFO - 2017-01-12 22:14:33 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:14:33 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:14:33 --> Utf8 Class Initialized
INFO - 2017-01-12 22:14:33 --> URI Class Initialized
INFO - 2017-01-12 22:14:33 --> Router Class Initialized
INFO - 2017-01-12 22:14:33 --> Output Class Initialized
INFO - 2017-01-12 22:14:33 --> Security Class Initialized
DEBUG - 2017-01-12 22:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:14:33 --> Input Class Initialized
INFO - 2017-01-12 22:14:33 --> Language Class Initialized
INFO - 2017-01-12 22:14:33 --> Loader Class Initialized
INFO - 2017-01-12 22:14:33 --> Database Driver Class Initialized
INFO - 2017-01-12 22:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:14:33 --> Controller Class Initialized
INFO - 2017-01-12 22:14:33 --> Upload Class Initialized
INFO - 2017-01-12 22:14:33 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:14:33 --> Helper loaded: form_helper
INFO - 2017-01-12 22:14:33 --> Form Validation Class Initialized
INFO - 2017-01-12 22:14:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 22:14:33 --> Final output sent to browser
DEBUG - 2017-01-12 22:14:33 --> Total execution time: 0.0497
INFO - 2017-01-12 22:14:38 --> Config Class Initialized
INFO - 2017-01-12 22:14:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:14:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:14:38 --> Utf8 Class Initialized
INFO - 2017-01-12 22:14:38 --> URI Class Initialized
INFO - 2017-01-12 22:14:38 --> Router Class Initialized
INFO - 2017-01-12 22:14:38 --> Output Class Initialized
INFO - 2017-01-12 22:14:38 --> Security Class Initialized
DEBUG - 2017-01-12 22:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:14:38 --> Input Class Initialized
INFO - 2017-01-12 22:14:38 --> Language Class Initialized
INFO - 2017-01-12 22:14:38 --> Loader Class Initialized
INFO - 2017-01-12 22:14:38 --> Database Driver Class Initialized
INFO - 2017-01-12 22:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:14:38 --> Controller Class Initialized
INFO - 2017-01-12 22:14:38 --> Upload Class Initialized
INFO - 2017-01-12 22:14:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:14:38 --> Helper loaded: form_helper
INFO - 2017-01-12 22:14:38 --> Form Validation Class Initialized
INFO - 2017-01-12 22:14:38 --> Final output sent to browser
DEBUG - 2017-01-12 22:14:38 --> Total execution time: 0.0918
INFO - 2017-01-12 22:14:38 --> Config Class Initialized
INFO - 2017-01-12 22:14:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:14:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:14:38 --> Utf8 Class Initialized
INFO - 2017-01-12 22:14:38 --> URI Class Initialized
INFO - 2017-01-12 22:14:38 --> Router Class Initialized
INFO - 2017-01-12 22:14:38 --> Output Class Initialized
INFO - 2017-01-12 22:14:38 --> Security Class Initialized
DEBUG - 2017-01-12 22:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:14:38 --> Input Class Initialized
INFO - 2017-01-12 22:14:38 --> Language Class Initialized
INFO - 2017-01-12 22:14:38 --> Loader Class Initialized
INFO - 2017-01-12 22:14:38 --> Database Driver Class Initialized
INFO - 2017-01-12 22:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:14:38 --> Controller Class Initialized
INFO - 2017-01-12 22:14:38 --> Upload Class Initialized
INFO - 2017-01-12 22:14:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:14:38 --> Helper loaded: form_helper
INFO - 2017-01-12 22:14:38 --> Form Validation Class Initialized
INFO - 2017-01-12 22:14:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 22:14:38 --> Final output sent to browser
DEBUG - 2017-01-12 22:14:38 --> Total execution time: 0.0156
INFO - 2017-01-12 22:15:23 --> Config Class Initialized
INFO - 2017-01-12 22:15:23 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:15:23 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:15:23 --> Utf8 Class Initialized
INFO - 2017-01-12 22:15:23 --> URI Class Initialized
DEBUG - 2017-01-12 22:15:23 --> No URI present. Default controller set.
INFO - 2017-01-12 22:15:23 --> Router Class Initialized
INFO - 2017-01-12 22:15:23 --> Output Class Initialized
INFO - 2017-01-12 22:15:23 --> Security Class Initialized
DEBUG - 2017-01-12 22:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:15:23 --> Input Class Initialized
INFO - 2017-01-12 22:15:23 --> Language Class Initialized
INFO - 2017-01-12 22:15:23 --> Loader Class Initialized
INFO - 2017-01-12 22:15:23 --> Database Driver Class Initialized
INFO - 2017-01-12 22:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:15:23 --> Controller Class Initialized
INFO - 2017-01-12 22:15:23 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 22:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 22:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 22:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 22:15:23 --> Final output sent to browser
DEBUG - 2017-01-12 22:15:23 --> Total execution time: 0.0878
INFO - 2017-01-12 22:15:38 --> Config Class Initialized
INFO - 2017-01-12 22:15:38 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:15:38 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:15:38 --> Utf8 Class Initialized
INFO - 2017-01-12 22:15:38 --> URI Class Initialized
INFO - 2017-01-12 22:15:38 --> Router Class Initialized
INFO - 2017-01-12 22:15:38 --> Output Class Initialized
INFO - 2017-01-12 22:15:38 --> Security Class Initialized
DEBUG - 2017-01-12 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:15:38 --> Input Class Initialized
INFO - 2017-01-12 22:15:38 --> Language Class Initialized
INFO - 2017-01-12 22:15:38 --> Loader Class Initialized
INFO - 2017-01-12 22:15:38 --> Database Driver Class Initialized
INFO - 2017-01-12 22:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:15:38 --> Controller Class Initialized
INFO - 2017-01-12 22:15:38 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:15:40 --> Config Class Initialized
INFO - 2017-01-12 22:15:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:15:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:15:40 --> Utf8 Class Initialized
INFO - 2017-01-12 22:15:40 --> URI Class Initialized
INFO - 2017-01-12 22:15:40 --> Router Class Initialized
INFO - 2017-01-12 22:15:40 --> Output Class Initialized
INFO - 2017-01-12 22:15:40 --> Security Class Initialized
DEBUG - 2017-01-12 22:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:15:40 --> Input Class Initialized
INFO - 2017-01-12 22:15:40 --> Language Class Initialized
INFO - 2017-01-12 22:15:40 --> Loader Class Initialized
INFO - 2017-01-12 22:15:40 --> Database Driver Class Initialized
INFO - 2017-01-12 22:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:15:40 --> Controller Class Initialized
INFO - 2017-01-12 22:15:40 --> Helper loaded: date_helper
DEBUG - 2017-01-12 22:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:15:40 --> Helper loaded: url_helper
INFO - 2017-01-12 22:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 22:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-12 22:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-12 22:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-12 22:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 22:15:40 --> Final output sent to browser
DEBUG - 2017-01-12 22:15:40 --> Total execution time: 0.1025
INFO - 2017-01-12 22:15:59 --> Config Class Initialized
INFO - 2017-01-12 22:15:59 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:15:59 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:15:59 --> Utf8 Class Initialized
INFO - 2017-01-12 22:15:59 --> URI Class Initialized
INFO - 2017-01-12 22:15:59 --> Router Class Initialized
INFO - 2017-01-12 22:15:59 --> Output Class Initialized
INFO - 2017-01-12 22:15:59 --> Security Class Initialized
DEBUG - 2017-01-12 22:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:15:59 --> Input Class Initialized
INFO - 2017-01-12 22:15:59 --> Language Class Initialized
INFO - 2017-01-12 22:15:59 --> Loader Class Initialized
INFO - 2017-01-12 22:15:59 --> Database Driver Class Initialized
INFO - 2017-01-12 22:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:15:59 --> Controller Class Initialized
INFO - 2017-01-12 22:15:59 --> Upload Class Initialized
INFO - 2017-01-12 22:15:59 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:15:59 --> Helper loaded: form_helper
INFO - 2017-01-12 22:15:59 --> Form Validation Class Initialized
INFO - 2017-01-12 22:15:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 22:15:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 22:15:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 22:15:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 22:15:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 22:15:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 22:15:59 --> Final output sent to browser
DEBUG - 2017-01-12 22:15:59 --> Total execution time: 0.0893
INFO - 2017-01-12 22:16:00 --> Config Class Initialized
INFO - 2017-01-12 22:16:00 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:16:00 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:16:00 --> Utf8 Class Initialized
INFO - 2017-01-12 22:16:00 --> URI Class Initialized
INFO - 2017-01-12 22:16:00 --> Router Class Initialized
INFO - 2017-01-12 22:16:00 --> Output Class Initialized
INFO - 2017-01-12 22:16:00 --> Security Class Initialized
DEBUG - 2017-01-12 22:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:16:00 --> Input Class Initialized
INFO - 2017-01-12 22:16:00 --> Language Class Initialized
INFO - 2017-01-12 22:16:00 --> Loader Class Initialized
INFO - 2017-01-12 22:16:00 --> Database Driver Class Initialized
INFO - 2017-01-12 22:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:16:00 --> Controller Class Initialized
INFO - 2017-01-12 22:16:00 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 22:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 22:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 22:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 22:16:00 --> Final output sent to browser
DEBUG - 2017-01-12 22:16:00 --> Total execution time: 0.0207
INFO - 2017-01-12 22:17:21 --> Config Class Initialized
INFO - 2017-01-12 22:17:21 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:17:21 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:17:21 --> Utf8 Class Initialized
INFO - 2017-01-12 22:17:21 --> URI Class Initialized
INFO - 2017-01-12 22:17:21 --> Router Class Initialized
INFO - 2017-01-12 22:17:21 --> Output Class Initialized
INFO - 2017-01-12 22:17:21 --> Security Class Initialized
DEBUG - 2017-01-12 22:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:17:21 --> Input Class Initialized
INFO - 2017-01-12 22:17:21 --> Language Class Initialized
INFO - 2017-01-12 22:17:21 --> Loader Class Initialized
INFO - 2017-01-12 22:17:21 --> Database Driver Class Initialized
INFO - 2017-01-12 22:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:17:21 --> Controller Class Initialized
INFO - 2017-01-12 22:17:21 --> Upload Class Initialized
INFO - 2017-01-12 22:17:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:17:21 --> Helper loaded: form_helper
INFO - 2017-01-12 22:17:21 --> Form Validation Class Initialized
INFO - 2017-01-12 22:17:21 --> Final output sent to browser
DEBUG - 2017-01-12 22:17:21 --> Total execution time: 0.0154
INFO - 2017-01-12 22:17:21 --> Config Class Initialized
INFO - 2017-01-12 22:17:21 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:17:21 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:17:21 --> Utf8 Class Initialized
INFO - 2017-01-12 22:17:21 --> URI Class Initialized
INFO - 2017-01-12 22:17:21 --> Router Class Initialized
INFO - 2017-01-12 22:17:21 --> Output Class Initialized
INFO - 2017-01-12 22:17:21 --> Security Class Initialized
DEBUG - 2017-01-12 22:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:17:21 --> Input Class Initialized
INFO - 2017-01-12 22:17:21 --> Language Class Initialized
INFO - 2017-01-12 22:17:21 --> Loader Class Initialized
INFO - 2017-01-12 22:17:21 --> Database Driver Class Initialized
INFO - 2017-01-12 22:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:17:21 --> Controller Class Initialized
INFO - 2017-01-12 22:17:21 --> Upload Class Initialized
INFO - 2017-01-12 22:17:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:17:21 --> Helper loaded: form_helper
INFO - 2017-01-12 22:17:21 --> Form Validation Class Initialized
INFO - 2017-01-12 22:17:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 22:17:21 --> Final output sent to browser
DEBUG - 2017-01-12 22:17:21 --> Total execution time: 0.0148
INFO - 2017-01-12 22:17:42 --> Config Class Initialized
INFO - 2017-01-12 22:17:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:17:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:17:42 --> Utf8 Class Initialized
INFO - 2017-01-12 22:17:42 --> URI Class Initialized
INFO - 2017-01-12 22:17:42 --> Router Class Initialized
INFO - 2017-01-12 22:17:42 --> Output Class Initialized
INFO - 2017-01-12 22:17:42 --> Security Class Initialized
DEBUG - 2017-01-12 22:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:17:42 --> Input Class Initialized
INFO - 2017-01-12 22:17:42 --> Language Class Initialized
INFO - 2017-01-12 22:17:42 --> Loader Class Initialized
INFO - 2017-01-12 22:17:42 --> Database Driver Class Initialized
INFO - 2017-01-12 22:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:17:42 --> Controller Class Initialized
INFO - 2017-01-12 22:17:42 --> Upload Class Initialized
INFO - 2017-01-12 22:17:42 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:17:42 --> Helper loaded: form_helper
INFO - 2017-01-12 22:17:42 --> Form Validation Class Initialized
INFO - 2017-01-12 22:17:42 --> Final output sent to browser
DEBUG - 2017-01-12 22:17:42 --> Total execution time: 0.0472
INFO - 2017-01-12 22:17:42 --> Config Class Initialized
INFO - 2017-01-12 22:17:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:17:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:17:42 --> Utf8 Class Initialized
INFO - 2017-01-12 22:17:42 --> URI Class Initialized
INFO - 2017-01-12 22:17:42 --> Router Class Initialized
INFO - 2017-01-12 22:17:42 --> Output Class Initialized
INFO - 2017-01-12 22:17:42 --> Security Class Initialized
DEBUG - 2017-01-12 22:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:17:42 --> Input Class Initialized
INFO - 2017-01-12 22:17:42 --> Language Class Initialized
INFO - 2017-01-12 22:17:42 --> Loader Class Initialized
INFO - 2017-01-12 22:17:42 --> Database Driver Class Initialized
INFO - 2017-01-12 22:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:17:42 --> Controller Class Initialized
INFO - 2017-01-12 22:17:42 --> Upload Class Initialized
INFO - 2017-01-12 22:17:42 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:17:42 --> Helper loaded: form_helper
INFO - 2017-01-12 22:17:42 --> Form Validation Class Initialized
INFO - 2017-01-12 22:17:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-12 22:17:42 --> Final output sent to browser
DEBUG - 2017-01-12 22:17:42 --> Total execution time: 0.0173
INFO - 2017-01-12 22:19:28 --> Config Class Initialized
INFO - 2017-01-12 22:19:28 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:19:28 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:19:28 --> Utf8 Class Initialized
INFO - 2017-01-12 22:19:28 --> URI Class Initialized
INFO - 2017-01-12 22:19:28 --> Router Class Initialized
INFO - 2017-01-12 22:19:28 --> Output Class Initialized
INFO - 2017-01-12 22:19:28 --> Security Class Initialized
DEBUG - 2017-01-12 22:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:19:28 --> Input Class Initialized
INFO - 2017-01-12 22:19:28 --> Language Class Initialized
INFO - 2017-01-12 22:19:28 --> Loader Class Initialized
INFO - 2017-01-12 22:19:28 --> Database Driver Class Initialized
INFO - 2017-01-12 22:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:19:28 --> Controller Class Initialized
INFO - 2017-01-12 22:19:28 --> Upload Class Initialized
INFO - 2017-01-12 22:19:28 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:19:28 --> Helper loaded: form_helper
INFO - 2017-01-12 22:19:28 --> Form Validation Class Initialized
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 22:19:28 --> Final output sent to browser
DEBUG - 2017-01-12 22:19:28 --> Total execution time: 0.0162
INFO - 2017-01-12 22:19:28 --> Config Class Initialized
INFO - 2017-01-12 22:19:28 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:19:28 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:19:28 --> Utf8 Class Initialized
INFO - 2017-01-12 22:19:28 --> URI Class Initialized
INFO - 2017-01-12 22:19:28 --> Router Class Initialized
INFO - 2017-01-12 22:19:28 --> Output Class Initialized
INFO - 2017-01-12 22:19:28 --> Security Class Initialized
DEBUG - 2017-01-12 22:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:19:28 --> Input Class Initialized
INFO - 2017-01-12 22:19:28 --> Language Class Initialized
INFO - 2017-01-12 22:19:28 --> Loader Class Initialized
INFO - 2017-01-12 22:19:28 --> Database Driver Class Initialized
INFO - 2017-01-12 22:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:19:28 --> Controller Class Initialized
INFO - 2017-01-12 22:19:28 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 22:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 22:19:28 --> Final output sent to browser
DEBUG - 2017-01-12 22:19:28 --> Total execution time: 0.0133
INFO - 2017-01-12 22:35:20 --> Config Class Initialized
INFO - 2017-01-12 22:35:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:35:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:35:20 --> Utf8 Class Initialized
INFO - 2017-01-12 22:35:20 --> URI Class Initialized
INFO - 2017-01-12 22:35:20 --> Router Class Initialized
INFO - 2017-01-12 22:35:20 --> Output Class Initialized
INFO - 2017-01-12 22:35:20 --> Security Class Initialized
DEBUG - 2017-01-12 22:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:35:20 --> Input Class Initialized
INFO - 2017-01-12 22:35:20 --> Language Class Initialized
INFO - 2017-01-12 22:35:20 --> Loader Class Initialized
INFO - 2017-01-12 22:35:21 --> Database Driver Class Initialized
INFO - 2017-01-12 22:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:35:21 --> Controller Class Initialized
INFO - 2017-01-12 22:35:21 --> Upload Class Initialized
INFO - 2017-01-12 22:35:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:35:21 --> Helper loaded: form_helper
INFO - 2017-01-12 22:35:21 --> Form Validation Class Initialized
INFO - 2017-01-12 22:35:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 22:35:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 22:35:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 22:35:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 22:35:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 22:35:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 22:35:21 --> Final output sent to browser
DEBUG - 2017-01-12 22:35:21 --> Total execution time: 1.2887
INFO - 2017-01-12 22:35:22 --> Config Class Initialized
INFO - 2017-01-12 22:35:22 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:35:22 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:35:22 --> Utf8 Class Initialized
INFO - 2017-01-12 22:35:22 --> URI Class Initialized
INFO - 2017-01-12 22:35:22 --> Router Class Initialized
INFO - 2017-01-12 22:35:22 --> Output Class Initialized
INFO - 2017-01-12 22:35:22 --> Security Class Initialized
DEBUG - 2017-01-12 22:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:35:22 --> Input Class Initialized
INFO - 2017-01-12 22:35:22 --> Language Class Initialized
INFO - 2017-01-12 22:35:22 --> Loader Class Initialized
INFO - 2017-01-12 22:35:22 --> Database Driver Class Initialized
INFO - 2017-01-12 22:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:35:22 --> Controller Class Initialized
INFO - 2017-01-12 22:35:22 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 22:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 22:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 22:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 22:35:22 --> Final output sent to browser
DEBUG - 2017-01-12 22:35:22 --> Total execution time: 0.3039
INFO - 2017-01-12 22:35:23 --> Config Class Initialized
INFO - 2017-01-12 22:35:23 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:35:23 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:35:23 --> Utf8 Class Initialized
INFO - 2017-01-12 22:35:23 --> URI Class Initialized
INFO - 2017-01-12 22:35:23 --> Router Class Initialized
INFO - 2017-01-12 22:35:23 --> Output Class Initialized
INFO - 2017-01-12 22:35:23 --> Security Class Initialized
DEBUG - 2017-01-12 22:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:35:23 --> Input Class Initialized
INFO - 2017-01-12 22:35:23 --> Language Class Initialized
INFO - 2017-01-12 22:35:23 --> Loader Class Initialized
INFO - 2017-01-12 22:35:23 --> Database Driver Class Initialized
INFO - 2017-01-12 22:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:35:23 --> Controller Class Initialized
INFO - 2017-01-12 22:35:23 --> Upload Class Initialized
INFO - 2017-01-12 22:35:23 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:35:23 --> Helper loaded: form_helper
INFO - 2017-01-12 22:35:23 --> Form Validation Class Initialized
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 22:35:23 --> Final output sent to browser
DEBUG - 2017-01-12 22:35:23 --> Total execution time: 0.0631
INFO - 2017-01-12 22:35:23 --> Config Class Initialized
INFO - 2017-01-12 22:35:23 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:35:23 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:35:23 --> Utf8 Class Initialized
INFO - 2017-01-12 22:35:23 --> URI Class Initialized
INFO - 2017-01-12 22:35:23 --> Router Class Initialized
INFO - 2017-01-12 22:35:23 --> Output Class Initialized
INFO - 2017-01-12 22:35:23 --> Security Class Initialized
DEBUG - 2017-01-12 22:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:35:23 --> Input Class Initialized
INFO - 2017-01-12 22:35:23 --> Language Class Initialized
INFO - 2017-01-12 22:35:23 --> Loader Class Initialized
INFO - 2017-01-12 22:35:23 --> Database Driver Class Initialized
INFO - 2017-01-12 22:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:35:23 --> Controller Class Initialized
INFO - 2017-01-12 22:35:23 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 22:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 22:35:23 --> Final output sent to browser
DEBUG - 2017-01-12 22:35:23 --> Total execution time: 0.0436
INFO - 2017-01-12 22:35:25 --> Config Class Initialized
INFO - 2017-01-12 22:35:25 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:35:25 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:35:25 --> Utf8 Class Initialized
INFO - 2017-01-12 22:35:25 --> URI Class Initialized
INFO - 2017-01-12 22:35:25 --> Router Class Initialized
INFO - 2017-01-12 22:35:25 --> Output Class Initialized
INFO - 2017-01-12 22:35:25 --> Security Class Initialized
DEBUG - 2017-01-12 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:35:25 --> Input Class Initialized
INFO - 2017-01-12 22:35:25 --> Language Class Initialized
INFO - 2017-01-12 22:35:25 --> Loader Class Initialized
INFO - 2017-01-12 22:35:25 --> Database Driver Class Initialized
INFO - 2017-01-12 22:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:35:25 --> Controller Class Initialized
INFO - 2017-01-12 22:35:25 --> Upload Class Initialized
INFO - 2017-01-12 22:35:25 --> Helper loaded: date_helper
INFO - 2017-01-12 22:35:25 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:35:25 --> Helper loaded: form_helper
INFO - 2017-01-12 22:35:25 --> Form Validation Class Initialized
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 22:35:25 --> Final output sent to browser
DEBUG - 2017-01-12 22:35:25 --> Total execution time: 0.1016
INFO - 2017-01-12 22:35:25 --> Config Class Initialized
INFO - 2017-01-12 22:35:25 --> Hooks Class Initialized
DEBUG - 2017-01-12 22:35:25 --> UTF-8 Support Enabled
INFO - 2017-01-12 22:35:25 --> Utf8 Class Initialized
INFO - 2017-01-12 22:35:25 --> URI Class Initialized
INFO - 2017-01-12 22:35:25 --> Router Class Initialized
INFO - 2017-01-12 22:35:25 --> Output Class Initialized
INFO - 2017-01-12 22:35:25 --> Security Class Initialized
DEBUG - 2017-01-12 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 22:35:25 --> Input Class Initialized
INFO - 2017-01-12 22:35:25 --> Language Class Initialized
INFO - 2017-01-12 22:35:25 --> Loader Class Initialized
INFO - 2017-01-12 22:35:25 --> Database Driver Class Initialized
INFO - 2017-01-12 22:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 22:35:25 --> Controller Class Initialized
INFO - 2017-01-12 22:35:25 --> Helper loaded: url_helper
DEBUG - 2017-01-12 22:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 22:35:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 22:35:25 --> Final output sent to browser
DEBUG - 2017-01-12 22:35:25 --> Total execution time: 0.0151
INFO - 2017-01-12 23:12:20 --> Config Class Initialized
INFO - 2017-01-12 23:12:20 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:12:20 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:12:20 --> Utf8 Class Initialized
INFO - 2017-01-12 23:12:20 --> URI Class Initialized
INFO - 2017-01-12 23:12:20 --> Router Class Initialized
INFO - 2017-01-12 23:12:20 --> Output Class Initialized
INFO - 2017-01-12 23:12:21 --> Security Class Initialized
DEBUG - 2017-01-12 23:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:12:21 --> Input Class Initialized
INFO - 2017-01-12 23:12:21 --> Language Class Initialized
INFO - 2017-01-12 23:12:21 --> Loader Class Initialized
INFO - 2017-01-12 23:12:21 --> Database Driver Class Initialized
INFO - 2017-01-12 23:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:12:21 --> Controller Class Initialized
INFO - 2017-01-12 23:12:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:12:21 --> Final output sent to browser
DEBUG - 2017-01-12 23:12:21 --> Total execution time: 1.2794
INFO - 2017-01-12 23:12:22 --> Config Class Initialized
INFO - 2017-01-12 23:12:22 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:12:22 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:12:22 --> Utf8 Class Initialized
INFO - 2017-01-12 23:12:22 --> URI Class Initialized
DEBUG - 2017-01-12 23:12:22 --> No URI present. Default controller set.
INFO - 2017-01-12 23:12:22 --> Router Class Initialized
INFO - 2017-01-12 23:12:22 --> Output Class Initialized
INFO - 2017-01-12 23:12:22 --> Security Class Initialized
DEBUG - 2017-01-12 23:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:12:22 --> Input Class Initialized
INFO - 2017-01-12 23:12:22 --> Language Class Initialized
INFO - 2017-01-12 23:12:22 --> Loader Class Initialized
INFO - 2017-01-12 23:12:22 --> Database Driver Class Initialized
INFO - 2017-01-12 23:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:12:22 --> Controller Class Initialized
INFO - 2017-01-12 23:12:22 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:12:22 --> Final output sent to browser
DEBUG - 2017-01-12 23:12:22 --> Total execution time: 0.0145
INFO - 2017-01-12 23:57:39 --> Config Class Initialized
INFO - 2017-01-12 23:57:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:40 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:40 --> URI Class Initialized
INFO - 2017-01-12 23:57:40 --> Router Class Initialized
INFO - 2017-01-12 23:57:40 --> Output Class Initialized
INFO - 2017-01-12 23:57:40 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:40 --> Input Class Initialized
INFO - 2017-01-12 23:57:40 --> Language Class Initialized
INFO - 2017-01-12 23:57:40 --> Loader Class Initialized
INFO - 2017-01-12 23:57:40 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:40 --> Controller Class Initialized
INFO - 2017-01-12 23:57:40 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:41 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:41 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 23:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-12 23:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-12 23:57:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:57:41 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:41 --> Total execution time: 1.2521
INFO - 2017-01-12 23:57:42 --> Config Class Initialized
INFO - 2017-01-12 23:57:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:42 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:42 --> URI Class Initialized
INFO - 2017-01-12 23:57:42 --> Router Class Initialized
INFO - 2017-01-12 23:57:42 --> Output Class Initialized
INFO - 2017-01-12 23:57:42 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:42 --> Input Class Initialized
INFO - 2017-01-12 23:57:42 --> Language Class Initialized
INFO - 2017-01-12 23:57:42 --> Loader Class Initialized
INFO - 2017-01-12 23:57:42 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:42 --> Controller Class Initialized
INFO - 2017-01-12 23:57:42 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:42 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:42 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:42 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:42 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:42 --> Total execution time: 0.0146
INFO - 2017-01-12 23:57:42 --> Config Class Initialized
INFO - 2017-01-12 23:57:42 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:42 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:42 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:42 --> URI Class Initialized
INFO - 2017-01-12 23:57:42 --> Router Class Initialized
INFO - 2017-01-12 23:57:42 --> Output Class Initialized
INFO - 2017-01-12 23:57:42 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:42 --> Input Class Initialized
INFO - 2017-01-12 23:57:42 --> Language Class Initialized
INFO - 2017-01-12 23:57:42 --> Loader Class Initialized
INFO - 2017-01-12 23:57:42 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:42 --> Controller Class Initialized
INFO - 2017-01-12 23:57:42 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:57:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:57:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:57:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:57:43 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:43 --> Total execution time: 0.7636
INFO - 2017-01-12 23:57:48 --> Config Class Initialized
INFO - 2017-01-12 23:57:48 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:48 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:48 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:48 --> URI Class Initialized
INFO - 2017-01-12 23:57:48 --> Router Class Initialized
INFO - 2017-01-12 23:57:48 --> Output Class Initialized
INFO - 2017-01-12 23:57:48 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:48 --> Input Class Initialized
INFO - 2017-01-12 23:57:48 --> Language Class Initialized
INFO - 2017-01-12 23:57:48 --> Loader Class Initialized
INFO - 2017-01-12 23:57:48 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:48 --> Controller Class Initialized
INFO - 2017-01-12 23:57:48 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:48 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:48 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:48 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:48 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:48 --> Total execution time: 0.0145
INFO - 2017-01-12 23:57:49 --> Config Class Initialized
INFO - 2017-01-12 23:57:49 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:49 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:49 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:49 --> URI Class Initialized
INFO - 2017-01-12 23:57:49 --> Router Class Initialized
INFO - 2017-01-12 23:57:49 --> Output Class Initialized
INFO - 2017-01-12 23:57:49 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:49 --> Input Class Initialized
INFO - 2017-01-12 23:57:49 --> Language Class Initialized
INFO - 2017-01-12 23:57:49 --> Loader Class Initialized
INFO - 2017-01-12 23:57:49 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:49 --> Controller Class Initialized
INFO - 2017-01-12 23:57:49 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:49 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:49 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:49 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:49 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:49 --> Total execution time: 0.0158
INFO - 2017-01-12 23:57:52 --> Config Class Initialized
INFO - 2017-01-12 23:57:52 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:52 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:52 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:52 --> URI Class Initialized
INFO - 2017-01-12 23:57:52 --> Router Class Initialized
INFO - 2017-01-12 23:57:52 --> Output Class Initialized
INFO - 2017-01-12 23:57:52 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:52 --> Input Class Initialized
INFO - 2017-01-12 23:57:52 --> Language Class Initialized
INFO - 2017-01-12 23:57:52 --> Loader Class Initialized
INFO - 2017-01-12 23:57:52 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:52 --> Controller Class Initialized
INFO - 2017-01-12 23:57:52 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:52 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:52 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:52 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:52 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:52 --> Total execution time: 0.0645
INFO - 2017-01-12 23:57:53 --> Config Class Initialized
INFO - 2017-01-12 23:57:53 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:53 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:53 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:53 --> URI Class Initialized
INFO - 2017-01-12 23:57:53 --> Router Class Initialized
INFO - 2017-01-12 23:57:53 --> Output Class Initialized
INFO - 2017-01-12 23:57:53 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:53 --> Input Class Initialized
INFO - 2017-01-12 23:57:53 --> Language Class Initialized
INFO - 2017-01-12 23:57:53 --> Loader Class Initialized
INFO - 2017-01-12 23:57:53 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:53 --> Controller Class Initialized
INFO - 2017-01-12 23:57:53 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:53 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:53 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:53 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:53 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:53 --> Total execution time: 0.0240
INFO - 2017-01-12 23:57:55 --> Config Class Initialized
INFO - 2017-01-12 23:57:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:55 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:55 --> URI Class Initialized
INFO - 2017-01-12 23:57:55 --> Router Class Initialized
INFO - 2017-01-12 23:57:55 --> Output Class Initialized
INFO - 2017-01-12 23:57:55 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:55 --> Input Class Initialized
INFO - 2017-01-12 23:57:55 --> Language Class Initialized
INFO - 2017-01-12 23:57:55 --> Loader Class Initialized
INFO - 2017-01-12 23:57:55 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:55 --> Controller Class Initialized
INFO - 2017-01-12 23:57:55 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:55 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:55 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:55 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:55 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:55 --> Total execution time: 0.0144
INFO - 2017-01-12 23:57:56 --> Config Class Initialized
INFO - 2017-01-12 23:57:56 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:57:56 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:57:56 --> Utf8 Class Initialized
INFO - 2017-01-12 23:57:56 --> URI Class Initialized
INFO - 2017-01-12 23:57:56 --> Router Class Initialized
INFO - 2017-01-12 23:57:56 --> Output Class Initialized
INFO - 2017-01-12 23:57:56 --> Security Class Initialized
DEBUG - 2017-01-12 23:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:57:56 --> Input Class Initialized
INFO - 2017-01-12 23:57:56 --> Language Class Initialized
INFO - 2017-01-12 23:57:56 --> Loader Class Initialized
INFO - 2017-01-12 23:57:56 --> Database Driver Class Initialized
INFO - 2017-01-12 23:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:57:56 --> Controller Class Initialized
INFO - 2017-01-12 23:57:56 --> Helper loaded: date_helper
INFO - 2017-01-12 23:57:56 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:57:56 --> Helper loaded: form_helper
INFO - 2017-01-12 23:57:56 --> Form Validation Class Initialized
INFO - 2017-01-12 23:57:56 --> Final output sent to browser
DEBUG - 2017-01-12 23:57:56 --> Total execution time: 0.0147
INFO - 2017-01-12 23:58:04 --> Config Class Initialized
INFO - 2017-01-12 23:58:04 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:04 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:04 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:04 --> URI Class Initialized
INFO - 2017-01-12 23:58:04 --> Router Class Initialized
INFO - 2017-01-12 23:58:05 --> Output Class Initialized
INFO - 2017-01-12 23:58:05 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:05 --> Input Class Initialized
INFO - 2017-01-12 23:58:05 --> Language Class Initialized
INFO - 2017-01-12 23:58:05 --> Loader Class Initialized
INFO - 2017-01-12 23:58:05 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:05 --> Controller Class Initialized
INFO - 2017-01-12 23:58:05 --> Upload Class Initialized
INFO - 2017-01-12 23:58:05 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:05 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:05 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:05 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:58:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 23:58:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 23:58:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:58:06 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:06 --> Total execution time: 1.2648
INFO - 2017-01-12 23:58:06 --> Config Class Initialized
INFO - 2017-01-12 23:58:06 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:06 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:06 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:06 --> URI Class Initialized
INFO - 2017-01-12 23:58:06 --> Router Class Initialized
INFO - 2017-01-12 23:58:06 --> Output Class Initialized
INFO - 2017-01-12 23:58:06 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:06 --> Input Class Initialized
INFO - 2017-01-12 23:58:06 --> Language Class Initialized
INFO - 2017-01-12 23:58:06 --> Loader Class Initialized
INFO - 2017-01-12 23:58:06 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:06 --> Controller Class Initialized
INFO - 2017-01-12 23:58:06 --> Upload Class Initialized
INFO - 2017-01-12 23:58:06 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:06 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:06 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 23:58:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:58:06 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:06 --> Total execution time: 0.0586
INFO - 2017-01-12 23:58:07 --> Config Class Initialized
INFO - 2017-01-12 23:58:07 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:07 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:07 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:07 --> URI Class Initialized
INFO - 2017-01-12 23:58:07 --> Router Class Initialized
INFO - 2017-01-12 23:58:07 --> Output Class Initialized
INFO - 2017-01-12 23:58:07 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:07 --> Input Class Initialized
INFO - 2017-01-12 23:58:07 --> Language Class Initialized
INFO - 2017-01-12 23:58:07 --> Loader Class Initialized
INFO - 2017-01-12 23:58:07 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:07 --> Controller Class Initialized
INFO - 2017-01-12 23:58:07 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:58:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:58:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:58:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:58:07 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:07 --> Total execution time: 0.2724
INFO - 2017-01-12 23:58:11 --> Config Class Initialized
INFO - 2017-01-12 23:58:11 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:11 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:11 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:11 --> URI Class Initialized
INFO - 2017-01-12 23:58:11 --> Router Class Initialized
INFO - 2017-01-12 23:58:11 --> Output Class Initialized
INFO - 2017-01-12 23:58:11 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:11 --> Input Class Initialized
INFO - 2017-01-12 23:58:11 --> Language Class Initialized
INFO - 2017-01-12 23:58:11 --> Loader Class Initialized
INFO - 2017-01-12 23:58:11 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:11 --> Controller Class Initialized
INFO - 2017-01-12 23:58:11 --> Upload Class Initialized
INFO - 2017-01-12 23:58:11 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:11 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:11 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:11 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:58:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 23:58:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-12 23:58:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-12 23:58:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-12 23:58:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:58:11 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:11 --> Total execution time: 0.0167
INFO - 2017-01-12 23:58:12 --> Config Class Initialized
INFO - 2017-01-12 23:58:12 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:12 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:12 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:12 --> URI Class Initialized
INFO - 2017-01-12 23:58:12 --> Router Class Initialized
INFO - 2017-01-12 23:58:12 --> Output Class Initialized
INFO - 2017-01-12 23:58:12 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:12 --> Input Class Initialized
INFO - 2017-01-12 23:58:12 --> Language Class Initialized
INFO - 2017-01-12 23:58:12 --> Loader Class Initialized
INFO - 2017-01-12 23:58:12 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:12 --> Controller Class Initialized
INFO - 2017-01-12 23:58:12 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:58:12 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:12 --> Total execution time: 0.0551
INFO - 2017-01-12 23:58:14 --> Config Class Initialized
INFO - 2017-01-12 23:58:14 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:14 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:14 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:14 --> URI Class Initialized
INFO - 2017-01-12 23:58:14 --> Router Class Initialized
INFO - 2017-01-12 23:58:14 --> Output Class Initialized
INFO - 2017-01-12 23:58:14 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:14 --> Input Class Initialized
INFO - 2017-01-12 23:58:14 --> Language Class Initialized
INFO - 2017-01-12 23:58:14 --> Loader Class Initialized
INFO - 2017-01-12 23:58:14 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:14 --> Controller Class Initialized
INFO - 2017-01-12 23:58:14 --> Upload Class Initialized
INFO - 2017-01-12 23:58:14 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:14 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:14 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:14 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:14 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:14 --> Total execution time: 0.0190
INFO - 2017-01-12 23:58:21 --> Config Class Initialized
INFO - 2017-01-12 23:58:21 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:21 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:21 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:21 --> URI Class Initialized
INFO - 2017-01-12 23:58:21 --> Router Class Initialized
INFO - 2017-01-12 23:58:21 --> Output Class Initialized
INFO - 2017-01-12 23:58:21 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:21 --> Input Class Initialized
INFO - 2017-01-12 23:58:21 --> Language Class Initialized
INFO - 2017-01-12 23:58:21 --> Loader Class Initialized
INFO - 2017-01-12 23:58:21 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:21 --> Controller Class Initialized
INFO - 2017-01-12 23:58:21 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:21 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:21 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:58:21 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:21 --> Total execution time: 0.0872
INFO - 2017-01-12 23:58:21 --> Config Class Initialized
INFO - 2017-01-12 23:58:21 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:21 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:21 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:21 --> URI Class Initialized
INFO - 2017-01-12 23:58:21 --> Router Class Initialized
INFO - 2017-01-12 23:58:21 --> Output Class Initialized
INFO - 2017-01-12 23:58:21 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:21 --> Input Class Initialized
INFO - 2017-01-12 23:58:21 --> Language Class Initialized
INFO - 2017-01-12 23:58:21 --> Loader Class Initialized
INFO - 2017-01-12 23:58:21 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:21 --> Controller Class Initialized
INFO - 2017-01-12 23:58:21 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:21 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:21 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:21 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:21 --> Total execution time: 0.0152
INFO - 2017-01-12 23:58:21 --> Config Class Initialized
INFO - 2017-01-12 23:58:21 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:21 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:21 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:21 --> URI Class Initialized
INFO - 2017-01-12 23:58:21 --> Router Class Initialized
INFO - 2017-01-12 23:58:21 --> Output Class Initialized
INFO - 2017-01-12 23:58:21 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:21 --> Input Class Initialized
INFO - 2017-01-12 23:58:21 --> Language Class Initialized
INFO - 2017-01-12 23:58:21 --> Loader Class Initialized
INFO - 2017-01-12 23:58:21 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:21 --> Controller Class Initialized
INFO - 2017-01-12 23:58:21 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:58:21 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:21 --> Total execution time: 0.0280
INFO - 2017-01-12 23:58:23 --> Config Class Initialized
INFO - 2017-01-12 23:58:23 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:23 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:23 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:23 --> URI Class Initialized
INFO - 2017-01-12 23:58:23 --> Router Class Initialized
INFO - 2017-01-12 23:58:23 --> Output Class Initialized
INFO - 2017-01-12 23:58:23 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:23 --> Input Class Initialized
INFO - 2017-01-12 23:58:23 --> Language Class Initialized
INFO - 2017-01-12 23:58:24 --> Loader Class Initialized
INFO - 2017-01-12 23:58:24 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:24 --> Controller Class Initialized
INFO - 2017-01-12 23:58:24 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:24 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:24 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:24 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:58:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 23:58:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-12 23:58:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-12 23:58:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:58:24 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:24 --> Total execution time: 1.2274
INFO - 2017-01-12 23:58:25 --> Config Class Initialized
INFO - 2017-01-12 23:58:25 --> Hooks Class Initialized
INFO - 2017-01-12 23:58:25 --> Config Class Initialized
INFO - 2017-01-12 23:58:25 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:25 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:25 --> Utf8 Class Initialized
DEBUG - 2017-01-12 23:58:25 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:25 --> URI Class Initialized
INFO - 2017-01-12 23:58:25 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:25 --> URI Class Initialized
INFO - 2017-01-12 23:58:25 --> Router Class Initialized
INFO - 2017-01-12 23:58:25 --> Router Class Initialized
INFO - 2017-01-12 23:58:25 --> Output Class Initialized
INFO - 2017-01-12 23:58:25 --> Output Class Initialized
INFO - 2017-01-12 23:58:25 --> Security Class Initialized
INFO - 2017-01-12 23:58:25 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:25 --> Input Class Initialized
INFO - 2017-01-12 23:58:25 --> Language Class Initialized
DEBUG - 2017-01-12 23:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:25 --> Input Class Initialized
INFO - 2017-01-12 23:58:25 --> Language Class Initialized
INFO - 2017-01-12 23:58:25 --> Loader Class Initialized
INFO - 2017-01-12 23:58:25 --> Loader Class Initialized
INFO - 2017-01-12 23:58:26 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:26 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:26 --> Controller Class Initialized
INFO - 2017-01-12 23:58:26 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:26 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:26 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:26 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:26 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:26 --> Total execution time: 0.7862
INFO - 2017-01-12 23:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:26 --> Controller Class Initialized
INFO - 2017-01-12 23:58:26 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:58:26 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:26 --> Total execution time: 1.0468
INFO - 2017-01-12 23:58:29 --> Config Class Initialized
INFO - 2017-01-12 23:58:29 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:29 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:29 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:29 --> URI Class Initialized
INFO - 2017-01-12 23:58:29 --> Router Class Initialized
INFO - 2017-01-12 23:58:29 --> Output Class Initialized
INFO - 2017-01-12 23:58:29 --> Config Class Initialized
INFO - 2017-01-12 23:58:29 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:29 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:29 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:29 --> URI Class Initialized
INFO - 2017-01-12 23:58:29 --> Router Class Initialized
INFO - 2017-01-12 23:58:29 --> Security Class Initialized
INFO - 2017-01-12 23:58:29 --> Output Class Initialized
DEBUG - 2017-01-12 23:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:29 --> Input Class Initialized
INFO - 2017-01-12 23:58:29 --> Language Class Initialized
INFO - 2017-01-12 23:58:29 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:29 --> Input Class Initialized
INFO - 2017-01-12 23:58:29 --> Language Class Initialized
INFO - 2017-01-12 23:58:29 --> Loader Class Initialized
INFO - 2017-01-12 23:58:29 --> Loader Class Initialized
INFO - 2017-01-12 23:58:29 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:29 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:29 --> Controller Class Initialized
INFO - 2017-01-12 23:58:29 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:29 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:29 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:29 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:29 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:29 --> Total execution time: 0.0260
INFO - 2017-01-12 23:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:29 --> Controller Class Initialized
INFO - 2017-01-12 23:58:29 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:29 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:29 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:29 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:29 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:29 --> Total execution time: 0.0906
INFO - 2017-01-12 23:58:35 --> Config Class Initialized
INFO - 2017-01-12 23:58:35 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:35 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:35 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:35 --> URI Class Initialized
INFO - 2017-01-12 23:58:35 --> Router Class Initialized
INFO - 2017-01-12 23:58:35 --> Output Class Initialized
INFO - 2017-01-12 23:58:35 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:35 --> Input Class Initialized
INFO - 2017-01-12 23:58:35 --> Language Class Initialized
INFO - 2017-01-12 23:58:35 --> Loader Class Initialized
INFO - 2017-01-12 23:58:35 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:35 --> Controller Class Initialized
INFO - 2017-01-12 23:58:35 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:35 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:35 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:35 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:35 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:35 --> Total execution time: 0.0361
INFO - 2017-01-12 23:58:35 --> Config Class Initialized
INFO - 2017-01-12 23:58:35 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:35 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:35 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:35 --> URI Class Initialized
INFO - 2017-01-12 23:58:35 --> Router Class Initialized
INFO - 2017-01-12 23:58:35 --> Output Class Initialized
INFO - 2017-01-12 23:58:35 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:35 --> Input Class Initialized
INFO - 2017-01-12 23:58:35 --> Language Class Initialized
INFO - 2017-01-12 23:58:35 --> Loader Class Initialized
INFO - 2017-01-12 23:58:35 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:35 --> Controller Class Initialized
INFO - 2017-01-12 23:58:35 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:35 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:35 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:35 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:35 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:35 --> Total execution time: 0.0646
INFO - 2017-01-12 23:58:40 --> Config Class Initialized
INFO - 2017-01-12 23:58:40 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:40 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:40 --> URI Class Initialized
INFO - 2017-01-12 23:58:40 --> Router Class Initialized
INFO - 2017-01-12 23:58:40 --> Output Class Initialized
INFO - 2017-01-12 23:58:40 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:40 --> Input Class Initialized
INFO - 2017-01-12 23:58:40 --> Language Class Initialized
INFO - 2017-01-12 23:58:40 --> Loader Class Initialized
INFO - 2017-01-12 23:58:40 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:40 --> Config Class Initialized
INFO - 2017-01-12 23:58:40 --> Hooks Class Initialized
INFO - 2017-01-12 23:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:40 --> Controller Class Initialized
INFO - 2017-01-12 23:58:40 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:40 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:40 --> Form Validation Class Initialized
DEBUG - 2017-01-12 23:58:40 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:40 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:40 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:40 --> Total execution time: 0.0802
INFO - 2017-01-12 23:58:40 --> URI Class Initialized
INFO - 2017-01-12 23:58:40 --> Router Class Initialized
INFO - 2017-01-12 23:58:40 --> Output Class Initialized
INFO - 2017-01-12 23:58:40 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:40 --> Input Class Initialized
INFO - 2017-01-12 23:58:40 --> Language Class Initialized
INFO - 2017-01-12 23:58:40 --> Loader Class Initialized
INFO - 2017-01-12 23:58:40 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:40 --> Controller Class Initialized
INFO - 2017-01-12 23:58:40 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:40 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:40 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:40 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:40 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:40 --> Total execution time: 0.0767
INFO - 2017-01-12 23:58:55 --> Config Class Initialized
INFO - 2017-01-12 23:58:55 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:55 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:55 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:55 --> URI Class Initialized
INFO - 2017-01-12 23:58:55 --> Router Class Initialized
INFO - 2017-01-12 23:58:55 --> Output Class Initialized
INFO - 2017-01-12 23:58:55 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:55 --> Input Class Initialized
INFO - 2017-01-12 23:58:55 --> Language Class Initialized
INFO - 2017-01-12 23:58:55 --> Loader Class Initialized
INFO - 2017-01-12 23:58:55 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:55 --> Controller Class Initialized
INFO - 2017-01-12 23:58:55 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:56 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:56 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:56 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:58:56 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:56 --> Total execution time: 0.0782
INFO - 2017-01-12 23:58:56 --> Config Class Initialized
INFO - 2017-01-12 23:58:56 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:56 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:56 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:56 --> URI Class Initialized
INFO - 2017-01-12 23:58:56 --> Router Class Initialized
INFO - 2017-01-12 23:58:56 --> Output Class Initialized
INFO - 2017-01-12 23:58:56 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:56 --> Input Class Initialized
INFO - 2017-01-12 23:58:56 --> Language Class Initialized
INFO - 2017-01-12 23:58:56 --> Loader Class Initialized
INFO - 2017-01-12 23:58:56 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:56 --> Config Class Initialized
INFO - 2017-01-12 23:58:56 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:56 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:56 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:56 --> URI Class Initialized
INFO - 2017-01-12 23:58:56 --> Router Class Initialized
INFO - 2017-01-12 23:58:56 --> Output Class Initialized
INFO - 2017-01-12 23:58:56 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:56 --> Input Class Initialized
INFO - 2017-01-12 23:58:56 --> Language Class Initialized
INFO - 2017-01-12 23:58:56 --> Loader Class Initialized
INFO - 2017-01-12 23:58:56 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:56 --> Controller Class Initialized
INFO - 2017-01-12 23:58:56 --> Helper loaded: date_helper
INFO - 2017-01-12 23:58:56 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:56 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:56 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:56 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:56 --> Total execution time: 0.0380
INFO - 2017-01-12 23:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:56 --> Controller Class Initialized
INFO - 2017-01-12 23:58:56 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:58:56 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:56 --> Total execution time: 0.0758
INFO - 2017-01-12 23:58:57 --> Config Class Initialized
INFO - 2017-01-12 23:58:57 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:57 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:57 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:57 --> URI Class Initialized
INFO - 2017-01-12 23:58:57 --> Router Class Initialized
INFO - 2017-01-12 23:58:57 --> Output Class Initialized
INFO - 2017-01-12 23:58:57 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:57 --> Input Class Initialized
INFO - 2017-01-12 23:58:57 --> Language Class Initialized
INFO - 2017-01-12 23:58:57 --> Loader Class Initialized
INFO - 2017-01-12 23:58:57 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:57 --> Controller Class Initialized
INFO - 2017-01-12 23:58:57 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:57 --> Config Class Initialized
INFO - 2017-01-12 23:58:57 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:57 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:57 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:57 --> URI Class Initialized
INFO - 2017-01-12 23:58:57 --> Router Class Initialized
INFO - 2017-01-12 23:58:57 --> Output Class Initialized
INFO - 2017-01-12 23:58:57 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:57 --> Input Class Initialized
INFO - 2017-01-12 23:58:57 --> Language Class Initialized
INFO - 2017-01-12 23:58:57 --> Loader Class Initialized
INFO - 2017-01-12 23:58:57 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:57 --> Config Class Initialized
INFO - 2017-01-12 23:58:57 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:57 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:57 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:57 --> URI Class Initialized
INFO - 2017-01-12 23:58:57 --> Router Class Initialized
INFO - 2017-01-12 23:58:57 --> Output Class Initialized
INFO - 2017-01-12 23:58:57 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:57 --> Input Class Initialized
INFO - 2017-01-12 23:58:57 --> Language Class Initialized
INFO - 2017-01-12 23:58:57 --> Loader Class Initialized
INFO - 2017-01-12 23:58:57 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:57 --> Controller Class Initialized
INFO - 2017-01-12 23:58:57 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:57 --> Helper loaded: form_helper
INFO - 2017-01-12 23:58:57 --> Form Validation Class Initialized
INFO - 2017-01-12 23:58:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-12 23:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:57 --> Controller Class Initialized
INFO - 2017-01-12 23:58:57 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:58:57 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:57 --> Total execution time: 0.0172
INFO - 2017-01-12 23:58:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-12 23:58:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-12 23:58:57 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:57 --> Total execution time: 0.0282
INFO - 2017-01-12 23:58:58 --> Config Class Initialized
INFO - 2017-01-12 23:58:58 --> Hooks Class Initialized
DEBUG - 2017-01-12 23:58:58 --> UTF-8 Support Enabled
INFO - 2017-01-12 23:58:58 --> Utf8 Class Initialized
INFO - 2017-01-12 23:58:58 --> URI Class Initialized
INFO - 2017-01-12 23:58:58 --> Router Class Initialized
INFO - 2017-01-12 23:58:58 --> Output Class Initialized
INFO - 2017-01-12 23:58:58 --> Security Class Initialized
DEBUG - 2017-01-12 23:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-12 23:58:58 --> Input Class Initialized
INFO - 2017-01-12 23:58:58 --> Language Class Initialized
INFO - 2017-01-12 23:58:58 --> Loader Class Initialized
INFO - 2017-01-12 23:58:58 --> Database Driver Class Initialized
INFO - 2017-01-12 23:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-12 23:58:58 --> Controller Class Initialized
INFO - 2017-01-12 23:58:58 --> Helper loaded: url_helper
DEBUG - 2017-01-12 23:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-12 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-12 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-12 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-12 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-12 23:58:58 --> Final output sent to browser
DEBUG - 2017-01-12 23:58:58 --> Total execution time: 0.0149

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-10 00:17:22 --> Config Class Initialized
INFO - 2017-02-10 00:17:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:17:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:17:22 --> Utf8 Class Initialized
INFO - 2017-02-10 00:17:22 --> URI Class Initialized
DEBUG - 2017-02-10 00:17:22 --> No URI present. Default controller set.
INFO - 2017-02-10 00:17:22 --> Router Class Initialized
INFO - 2017-02-10 00:17:22 --> Output Class Initialized
INFO - 2017-02-10 00:17:22 --> Security Class Initialized
DEBUG - 2017-02-10 00:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:17:22 --> Input Class Initialized
INFO - 2017-02-10 00:17:22 --> Language Class Initialized
INFO - 2017-02-10 00:17:22 --> Loader Class Initialized
INFO - 2017-02-10 00:17:22 --> Database Driver Class Initialized
INFO - 2017-02-10 00:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:17:22 --> Controller Class Initialized
INFO - 2017-02-10 00:17:22 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:17:22 --> Final output sent to browser
DEBUG - 2017-02-10 00:17:22 --> Total execution time: 0.0134
INFO - 2017-02-10 00:17:25 --> Config Class Initialized
INFO - 2017-02-10 00:17:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:17:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:17:25 --> Utf8 Class Initialized
INFO - 2017-02-10 00:17:25 --> URI Class Initialized
INFO - 2017-02-10 00:17:25 --> Router Class Initialized
INFO - 2017-02-10 00:17:25 --> Output Class Initialized
INFO - 2017-02-10 00:17:25 --> Security Class Initialized
DEBUG - 2017-02-10 00:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:17:25 --> Input Class Initialized
INFO - 2017-02-10 00:17:25 --> Language Class Initialized
INFO - 2017-02-10 00:17:25 --> Loader Class Initialized
INFO - 2017-02-10 00:17:25 --> Database Driver Class Initialized
INFO - 2017-02-10 00:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:17:25 --> Controller Class Initialized
INFO - 2017-02-10 00:17:25 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:17:25 --> Final output sent to browser
DEBUG - 2017-02-10 00:17:25 --> Total execution time: 0.0130
INFO - 2017-02-10 00:17:56 --> Config Class Initialized
INFO - 2017-02-10 00:17:56 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:17:56 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:17:56 --> Utf8 Class Initialized
INFO - 2017-02-10 00:17:56 --> URI Class Initialized
INFO - 2017-02-10 00:17:56 --> Router Class Initialized
INFO - 2017-02-10 00:17:56 --> Output Class Initialized
INFO - 2017-02-10 00:17:56 --> Security Class Initialized
DEBUG - 2017-02-10 00:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:17:56 --> Input Class Initialized
INFO - 2017-02-10 00:17:56 --> Language Class Initialized
INFO - 2017-02-10 00:17:56 --> Loader Class Initialized
INFO - 2017-02-10 00:17:56 --> Database Driver Class Initialized
INFO - 2017-02-10 00:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:17:56 --> Controller Class Initialized
INFO - 2017-02-10 00:17:56 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-10 00:17:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-10 00:17:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-10 00:17:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-10 00:17:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:17:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:17:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:17:57 --> Final output sent to browser
DEBUG - 2017-02-10 00:17:57 --> Total execution time: 0.3848
INFO - 2017-02-10 00:17:58 --> Config Class Initialized
INFO - 2017-02-10 00:17:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:17:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:17:58 --> Utf8 Class Initialized
INFO - 2017-02-10 00:17:58 --> URI Class Initialized
INFO - 2017-02-10 00:17:58 --> Router Class Initialized
INFO - 2017-02-10 00:17:58 --> Output Class Initialized
INFO - 2017-02-10 00:17:58 --> Security Class Initialized
DEBUG - 2017-02-10 00:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:17:58 --> Input Class Initialized
INFO - 2017-02-10 00:17:58 --> Language Class Initialized
INFO - 2017-02-10 00:17:58 --> Loader Class Initialized
INFO - 2017-02-10 00:17:58 --> Database Driver Class Initialized
INFO - 2017-02-10 00:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:17:58 --> Controller Class Initialized
INFO - 2017-02-10 00:17:58 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:17:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:17:58 --> Final output sent to browser
DEBUG - 2017-02-10 00:17:58 --> Total execution time: 0.0139
INFO - 2017-02-10 00:18:41 --> Config Class Initialized
INFO - 2017-02-10 00:18:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:18:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:18:41 --> Utf8 Class Initialized
INFO - 2017-02-10 00:18:41 --> URI Class Initialized
INFO - 2017-02-10 00:18:41 --> Router Class Initialized
INFO - 2017-02-10 00:18:41 --> Output Class Initialized
INFO - 2017-02-10 00:18:41 --> Security Class Initialized
DEBUG - 2017-02-10 00:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:18:41 --> Input Class Initialized
INFO - 2017-02-10 00:18:41 --> Language Class Initialized
INFO - 2017-02-10 00:18:41 --> Loader Class Initialized
INFO - 2017-02-10 00:18:41 --> Database Driver Class Initialized
INFO - 2017-02-10 00:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:18:41 --> Controller Class Initialized
INFO - 2017-02-10 00:18:41 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-10 00:18:41 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-10 00:18:41 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-10 00:18:41 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-10 00:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:18:41 --> Final output sent to browser
DEBUG - 2017-02-10 00:18:41 --> Total execution time: 0.0149
INFO - 2017-02-10 00:18:43 --> Config Class Initialized
INFO - 2017-02-10 00:18:43 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:18:43 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:18:43 --> Utf8 Class Initialized
INFO - 2017-02-10 00:18:43 --> URI Class Initialized
INFO - 2017-02-10 00:18:43 --> Router Class Initialized
INFO - 2017-02-10 00:18:43 --> Output Class Initialized
INFO - 2017-02-10 00:18:43 --> Security Class Initialized
DEBUG - 2017-02-10 00:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:18:43 --> Input Class Initialized
INFO - 2017-02-10 00:18:43 --> Language Class Initialized
INFO - 2017-02-10 00:18:43 --> Loader Class Initialized
INFO - 2017-02-10 00:18:43 --> Database Driver Class Initialized
INFO - 2017-02-10 00:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:18:43 --> Controller Class Initialized
INFO - 2017-02-10 00:18:43 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:18:43 --> Final output sent to browser
DEBUG - 2017-02-10 00:18:43 --> Total execution time: 0.0139
INFO - 2017-02-10 00:30:10 --> Config Class Initialized
INFO - 2017-02-10 00:30:10 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:30:10 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:30:10 --> Utf8 Class Initialized
INFO - 2017-02-10 00:30:10 --> URI Class Initialized
DEBUG - 2017-02-10 00:30:10 --> No URI present. Default controller set.
INFO - 2017-02-10 00:30:10 --> Router Class Initialized
INFO - 2017-02-10 00:30:10 --> Output Class Initialized
INFO - 2017-02-10 00:30:10 --> Security Class Initialized
DEBUG - 2017-02-10 00:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:30:10 --> Input Class Initialized
INFO - 2017-02-10 00:30:10 --> Language Class Initialized
INFO - 2017-02-10 00:30:10 --> Loader Class Initialized
INFO - 2017-02-10 00:30:10 --> Database Driver Class Initialized
INFO - 2017-02-10 00:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:30:10 --> Controller Class Initialized
INFO - 2017-02-10 00:30:10 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:30:10 --> Final output sent to browser
DEBUG - 2017-02-10 00:30:10 --> Total execution time: 0.0135
INFO - 2017-02-10 00:36:49 --> Config Class Initialized
INFO - 2017-02-10 00:36:49 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:36:49 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:36:49 --> Utf8 Class Initialized
INFO - 2017-02-10 00:36:49 --> URI Class Initialized
INFO - 2017-02-10 00:36:49 --> Router Class Initialized
INFO - 2017-02-10 00:36:49 --> Output Class Initialized
INFO - 2017-02-10 00:36:49 --> Security Class Initialized
DEBUG - 2017-02-10 00:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:36:49 --> Input Class Initialized
INFO - 2017-02-10 00:36:49 --> Language Class Initialized
INFO - 2017-02-10 00:36:49 --> Loader Class Initialized
INFO - 2017-02-10 00:36:49 --> Database Driver Class Initialized
INFO - 2017-02-10 00:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:36:49 --> Controller Class Initialized
INFO - 2017-02-10 00:36:49 --> Helper loaded: date_helper
DEBUG - 2017-02-10 00:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:36:49 --> Helper loaded: url_helper
INFO - 2017-02-10 00:36:49 --> Helper loaded: download_helper
INFO - 2017-02-10 00:36:49 --> Config Class Initialized
INFO - 2017-02-10 00:36:49 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:36:49 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:36:49 --> Utf8 Class Initialized
INFO - 2017-02-10 00:36:49 --> URI Class Initialized
DEBUG - 2017-02-10 00:36:49 --> No URI present. Default controller set.
INFO - 2017-02-10 00:36:49 --> Router Class Initialized
INFO - 2017-02-10 00:36:49 --> Output Class Initialized
INFO - 2017-02-10 00:36:49 --> Security Class Initialized
DEBUG - 2017-02-10 00:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:36:49 --> Input Class Initialized
INFO - 2017-02-10 00:36:49 --> Language Class Initialized
INFO - 2017-02-10 00:36:49 --> Loader Class Initialized
INFO - 2017-02-10 00:36:49 --> Database Driver Class Initialized
INFO - 2017-02-10 00:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:36:49 --> Controller Class Initialized
INFO - 2017-02-10 00:36:49 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:36:49 --> Final output sent to browser
DEBUG - 2017-02-10 00:36:49 --> Total execution time: 0.0138
INFO - 2017-02-10 00:36:51 --> Config Class Initialized
INFO - 2017-02-10 00:36:51 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:36:51 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:36:51 --> Utf8 Class Initialized
INFO - 2017-02-10 00:36:51 --> URI Class Initialized
INFO - 2017-02-10 00:36:51 --> Router Class Initialized
INFO - 2017-02-10 00:36:51 --> Output Class Initialized
INFO - 2017-02-10 00:36:51 --> Security Class Initialized
DEBUG - 2017-02-10 00:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:36:51 --> Input Class Initialized
INFO - 2017-02-10 00:36:51 --> Language Class Initialized
INFO - 2017-02-10 00:36:51 --> Loader Class Initialized
INFO - 2017-02-10 00:36:51 --> Database Driver Class Initialized
INFO - 2017-02-10 00:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:36:51 --> Controller Class Initialized
INFO - 2017-02-10 00:36:51 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:36:51 --> Final output sent to browser
DEBUG - 2017-02-10 00:36:51 --> Total execution time: 0.0184
INFO - 2017-02-10 00:37:07 --> Config Class Initialized
INFO - 2017-02-10 00:37:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:07 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:07 --> URI Class Initialized
INFO - 2017-02-10 00:37:07 --> Router Class Initialized
INFO - 2017-02-10 00:37:07 --> Output Class Initialized
INFO - 2017-02-10 00:37:07 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:07 --> Input Class Initialized
INFO - 2017-02-10 00:37:07 --> Language Class Initialized
INFO - 2017-02-10 00:37:07 --> Loader Class Initialized
INFO - 2017-02-10 00:37:07 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:07 --> Controller Class Initialized
INFO - 2017-02-10 00:37:07 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:07 --> Config Class Initialized
INFO - 2017-02-10 00:37:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:07 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:07 --> URI Class Initialized
INFO - 2017-02-10 00:37:07 --> Router Class Initialized
INFO - 2017-02-10 00:37:07 --> Output Class Initialized
INFO - 2017-02-10 00:37:07 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:07 --> Input Class Initialized
INFO - 2017-02-10 00:37:07 --> Language Class Initialized
INFO - 2017-02-10 00:37:07 --> Loader Class Initialized
INFO - 2017-02-10 00:37:07 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:07 --> Controller Class Initialized
INFO - 2017-02-10 00:37:07 --> Helper loaded: date_helper
DEBUG - 2017-02-10 00:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:07 --> Helper loaded: url_helper
INFO - 2017-02-10 00:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-10 00:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-10 00:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-10 00:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:37:07 --> Final output sent to browser
DEBUG - 2017-02-10 00:37:07 --> Total execution time: 0.0599
INFO - 2017-02-10 00:37:09 --> Config Class Initialized
INFO - 2017-02-10 00:37:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:09 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:09 --> URI Class Initialized
INFO - 2017-02-10 00:37:09 --> Router Class Initialized
INFO - 2017-02-10 00:37:09 --> Output Class Initialized
INFO - 2017-02-10 00:37:09 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:09 --> Input Class Initialized
INFO - 2017-02-10 00:37:09 --> Language Class Initialized
INFO - 2017-02-10 00:37:09 --> Loader Class Initialized
INFO - 2017-02-10 00:37:09 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:09 --> Controller Class Initialized
INFO - 2017-02-10 00:37:09 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:37:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:37:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:37:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:37:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:37:09 --> Final output sent to browser
DEBUG - 2017-02-10 00:37:09 --> Total execution time: 0.0143
INFO - 2017-02-10 00:37:14 --> Config Class Initialized
INFO - 2017-02-10 00:37:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:14 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:14 --> URI Class Initialized
INFO - 2017-02-10 00:37:14 --> Router Class Initialized
INFO - 2017-02-10 00:37:14 --> Output Class Initialized
INFO - 2017-02-10 00:37:14 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:14 --> Input Class Initialized
INFO - 2017-02-10 00:37:14 --> Language Class Initialized
INFO - 2017-02-10 00:37:14 --> Loader Class Initialized
INFO - 2017-02-10 00:37:14 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:14 --> Controller Class Initialized
INFO - 2017-02-10 00:37:14 --> Helper loaded: date_helper
DEBUG - 2017-02-10 00:37:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:14 --> Helper loaded: url_helper
INFO - 2017-02-10 00:37:14 --> Helper loaded: download_helper
INFO - 2017-02-10 00:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-10 00:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-10 00:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-10 00:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:37:14 --> Final output sent to browser
DEBUG - 2017-02-10 00:37:14 --> Total execution time: 0.0611
INFO - 2017-02-10 00:37:16 --> Config Class Initialized
INFO - 2017-02-10 00:37:16 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:16 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:16 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:16 --> URI Class Initialized
INFO - 2017-02-10 00:37:16 --> Router Class Initialized
INFO - 2017-02-10 00:37:16 --> Output Class Initialized
INFO - 2017-02-10 00:37:16 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:16 --> Input Class Initialized
INFO - 2017-02-10 00:37:16 --> Language Class Initialized
INFO - 2017-02-10 00:37:16 --> Loader Class Initialized
INFO - 2017-02-10 00:37:16 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:16 --> Controller Class Initialized
INFO - 2017-02-10 00:37:16 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:37:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:37:16 --> Final output sent to browser
DEBUG - 2017-02-10 00:37:16 --> Total execution time: 0.0142
INFO - 2017-02-10 00:37:30 --> Config Class Initialized
INFO - 2017-02-10 00:37:30 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:30 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:30 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:30 --> URI Class Initialized
INFO - 2017-02-10 00:37:30 --> Router Class Initialized
INFO - 2017-02-10 00:37:30 --> Output Class Initialized
INFO - 2017-02-10 00:37:30 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:30 --> Input Class Initialized
INFO - 2017-02-10 00:37:30 --> Language Class Initialized
INFO - 2017-02-10 00:37:30 --> Loader Class Initialized
INFO - 2017-02-10 00:37:30 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:30 --> Controller Class Initialized
INFO - 2017-02-10 00:37:30 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:30 --> Config Class Initialized
INFO - 2017-02-10 00:37:30 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:30 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:30 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:30 --> URI Class Initialized
DEBUG - 2017-02-10 00:37:30 --> No URI present. Default controller set.
INFO - 2017-02-10 00:37:30 --> Router Class Initialized
INFO - 2017-02-10 00:37:30 --> Output Class Initialized
INFO - 2017-02-10 00:37:30 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:30 --> Input Class Initialized
INFO - 2017-02-10 00:37:30 --> Language Class Initialized
INFO - 2017-02-10 00:37:30 --> Loader Class Initialized
INFO - 2017-02-10 00:37:30 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:30 --> Controller Class Initialized
INFO - 2017-02-10 00:37:30 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:37:30 --> Final output sent to browser
DEBUG - 2017-02-10 00:37:30 --> Total execution time: 0.0134
INFO - 2017-02-10 00:37:30 --> Config Class Initialized
INFO - 2017-02-10 00:37:30 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:30 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:30 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:30 --> URI Class Initialized
INFO - 2017-02-10 00:37:30 --> Router Class Initialized
INFO - 2017-02-10 00:37:30 --> Output Class Initialized
INFO - 2017-02-10 00:37:30 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:30 --> Input Class Initialized
INFO - 2017-02-10 00:37:30 --> Language Class Initialized
INFO - 2017-02-10 00:37:30 --> Loader Class Initialized
INFO - 2017-02-10 00:37:30 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:30 --> Controller Class Initialized
INFO - 2017-02-10 00:37:30 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:37:30 --> Final output sent to browser
DEBUG - 2017-02-10 00:37:30 --> Total execution time: 0.0146
INFO - 2017-02-10 00:37:30 --> Config Class Initialized
INFO - 2017-02-10 00:37:30 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:37:30 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:37:30 --> Utf8 Class Initialized
INFO - 2017-02-10 00:37:30 --> URI Class Initialized
INFO - 2017-02-10 00:37:30 --> Router Class Initialized
INFO - 2017-02-10 00:37:30 --> Output Class Initialized
INFO - 2017-02-10 00:37:30 --> Security Class Initialized
DEBUG - 2017-02-10 00:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:37:30 --> Input Class Initialized
INFO - 2017-02-10 00:37:30 --> Language Class Initialized
INFO - 2017-02-10 00:37:30 --> Loader Class Initialized
INFO - 2017-02-10 00:37:30 --> Database Driver Class Initialized
INFO - 2017-02-10 00:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:37:30 --> Controller Class Initialized
INFO - 2017-02-10 00:37:30 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:37:30 --> Final output sent to browser
DEBUG - 2017-02-10 00:37:30 --> Total execution time: 0.0138
INFO - 2017-02-10 00:39:18 --> Config Class Initialized
INFO - 2017-02-10 00:39:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:18 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:18 --> URI Class Initialized
INFO - 2017-02-10 00:39:18 --> Router Class Initialized
INFO - 2017-02-10 00:39:18 --> Output Class Initialized
INFO - 2017-02-10 00:39:18 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:18 --> Input Class Initialized
INFO - 2017-02-10 00:39:18 --> Language Class Initialized
INFO - 2017-02-10 00:39:18 --> Loader Class Initialized
INFO - 2017-02-10 00:39:18 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:18 --> Controller Class Initialized
INFO - 2017-02-10 00:39:18 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:18 --> Config Class Initialized
INFO - 2017-02-10 00:39:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:18 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:18 --> URI Class Initialized
INFO - 2017-02-10 00:39:18 --> Router Class Initialized
INFO - 2017-02-10 00:39:18 --> Output Class Initialized
INFO - 2017-02-10 00:39:18 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:18 --> Input Class Initialized
INFO - 2017-02-10 00:39:18 --> Language Class Initialized
INFO - 2017-02-10 00:39:18 --> Loader Class Initialized
INFO - 2017-02-10 00:39:18 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:18 --> Controller Class Initialized
INFO - 2017-02-10 00:39:18 --> Helper loaded: date_helper
DEBUG - 2017-02-10 00:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:18 --> Helper loaded: url_helper
INFO - 2017-02-10 00:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-10 00:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-10 00:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-10 00:39:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:39:18 --> Final output sent to browser
DEBUG - 2017-02-10 00:39:18 --> Total execution time: 0.0146
INFO - 2017-02-10 00:39:19 --> Config Class Initialized
INFO - 2017-02-10 00:39:19 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:19 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:19 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:19 --> URI Class Initialized
INFO - 2017-02-10 00:39:19 --> Router Class Initialized
INFO - 2017-02-10 00:39:19 --> Output Class Initialized
INFO - 2017-02-10 00:39:19 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:19 --> Input Class Initialized
INFO - 2017-02-10 00:39:19 --> Language Class Initialized
INFO - 2017-02-10 00:39:19 --> Loader Class Initialized
INFO - 2017-02-10 00:39:19 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:19 --> Controller Class Initialized
INFO - 2017-02-10 00:39:19 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:39:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:39:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:39:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:39:19 --> Final output sent to browser
DEBUG - 2017-02-10 00:39:19 --> Total execution time: 0.0134
INFO - 2017-02-10 00:39:20 --> Config Class Initialized
INFO - 2017-02-10 00:39:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:20 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:20 --> URI Class Initialized
INFO - 2017-02-10 00:39:20 --> Router Class Initialized
INFO - 2017-02-10 00:39:20 --> Output Class Initialized
INFO - 2017-02-10 00:39:20 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:20 --> Input Class Initialized
INFO - 2017-02-10 00:39:20 --> Language Class Initialized
INFO - 2017-02-10 00:39:20 --> Loader Class Initialized
INFO - 2017-02-10 00:39:20 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:20 --> Controller Class Initialized
INFO - 2017-02-10 00:39:20 --> Helper loaded: date_helper
DEBUG - 2017-02-10 00:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:20 --> Helper loaded: url_helper
INFO - 2017-02-10 00:39:20 --> Helper loaded: download_helper
INFO - 2017-02-10 00:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-10 00:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-10 00:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-10 00:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:39:20 --> Final output sent to browser
DEBUG - 2017-02-10 00:39:20 --> Total execution time: 0.0190
INFO - 2017-02-10 00:39:21 --> Config Class Initialized
INFO - 2017-02-10 00:39:21 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:21 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:21 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:21 --> URI Class Initialized
INFO - 2017-02-10 00:39:21 --> Router Class Initialized
INFO - 2017-02-10 00:39:21 --> Output Class Initialized
INFO - 2017-02-10 00:39:21 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:21 --> Input Class Initialized
INFO - 2017-02-10 00:39:21 --> Language Class Initialized
INFO - 2017-02-10 00:39:21 --> Loader Class Initialized
INFO - 2017-02-10 00:39:21 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:21 --> Controller Class Initialized
INFO - 2017-02-10 00:39:21 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:39:21 --> Final output sent to browser
DEBUG - 2017-02-10 00:39:21 --> Total execution time: 0.0133
INFO - 2017-02-10 00:39:27 --> Config Class Initialized
INFO - 2017-02-10 00:39:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:27 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:27 --> URI Class Initialized
INFO - 2017-02-10 00:39:27 --> Router Class Initialized
INFO - 2017-02-10 00:39:27 --> Output Class Initialized
INFO - 2017-02-10 00:39:27 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:27 --> Input Class Initialized
INFO - 2017-02-10 00:39:27 --> Language Class Initialized
INFO - 2017-02-10 00:39:27 --> Loader Class Initialized
INFO - 2017-02-10 00:39:27 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:27 --> Controller Class Initialized
INFO - 2017-02-10 00:39:27 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:27 --> Config Class Initialized
INFO - 2017-02-10 00:39:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:27 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:27 --> URI Class Initialized
DEBUG - 2017-02-10 00:39:27 --> No URI present. Default controller set.
INFO - 2017-02-10 00:39:27 --> Router Class Initialized
INFO - 2017-02-10 00:39:27 --> Output Class Initialized
INFO - 2017-02-10 00:39:27 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:27 --> Input Class Initialized
INFO - 2017-02-10 00:39:27 --> Language Class Initialized
INFO - 2017-02-10 00:39:27 --> Loader Class Initialized
INFO - 2017-02-10 00:39:27 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:27 --> Controller Class Initialized
INFO - 2017-02-10 00:39:27 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:39:27 --> Final output sent to browser
DEBUG - 2017-02-10 00:39:27 --> Total execution time: 0.0142
INFO - 2017-02-10 00:39:28 --> Config Class Initialized
INFO - 2017-02-10 00:39:28 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:28 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:28 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:28 --> URI Class Initialized
INFO - 2017-02-10 00:39:28 --> Router Class Initialized
INFO - 2017-02-10 00:39:28 --> Output Class Initialized
INFO - 2017-02-10 00:39:28 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:28 --> Input Class Initialized
INFO - 2017-02-10 00:39:28 --> Language Class Initialized
INFO - 2017-02-10 00:39:28 --> Loader Class Initialized
INFO - 2017-02-10 00:39:28 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:28 --> Controller Class Initialized
INFO - 2017-02-10 00:39:28 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:39:28 --> Final output sent to browser
DEBUG - 2017-02-10 00:39:28 --> Total execution time: 0.0158
INFO - 2017-02-10 00:39:28 --> Config Class Initialized
INFO - 2017-02-10 00:39:28 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:39:28 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:39:28 --> Utf8 Class Initialized
INFO - 2017-02-10 00:39:28 --> URI Class Initialized
INFO - 2017-02-10 00:39:28 --> Router Class Initialized
INFO - 2017-02-10 00:39:28 --> Output Class Initialized
INFO - 2017-02-10 00:39:28 --> Security Class Initialized
DEBUG - 2017-02-10 00:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:39:28 --> Input Class Initialized
INFO - 2017-02-10 00:39:28 --> Language Class Initialized
INFO - 2017-02-10 00:39:28 --> Loader Class Initialized
INFO - 2017-02-10 00:39:28 --> Database Driver Class Initialized
INFO - 2017-02-10 00:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:39:28 --> Controller Class Initialized
INFO - 2017-02-10 00:39:28 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:39:28 --> Final output sent to browser
DEBUG - 2017-02-10 00:39:28 --> Total execution time: 0.0135
INFO - 2017-02-10 00:54:37 --> Config Class Initialized
INFO - 2017-02-10 00:54:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 00:54:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 00:54:37 --> Utf8 Class Initialized
INFO - 2017-02-10 00:54:37 --> URI Class Initialized
DEBUG - 2017-02-10 00:54:37 --> No URI present. Default controller set.
INFO - 2017-02-10 00:54:37 --> Router Class Initialized
INFO - 2017-02-10 00:54:37 --> Output Class Initialized
INFO - 2017-02-10 00:54:37 --> Security Class Initialized
DEBUG - 2017-02-10 00:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 00:54:37 --> Input Class Initialized
INFO - 2017-02-10 00:54:37 --> Language Class Initialized
INFO - 2017-02-10 00:54:37 --> Loader Class Initialized
INFO - 2017-02-10 00:54:37 --> Database Driver Class Initialized
INFO - 2017-02-10 00:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 00:54:37 --> Controller Class Initialized
INFO - 2017-02-10 00:54:37 --> Helper loaded: url_helper
DEBUG - 2017-02-10 00:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 00:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 00:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 00:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 00:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 00:54:37 --> Final output sent to browser
DEBUG - 2017-02-10 00:54:37 --> Total execution time: 0.0202
INFO - 2017-02-10 01:43:57 --> Config Class Initialized
INFO - 2017-02-10 01:43:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 01:43:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 01:43:57 --> Utf8 Class Initialized
INFO - 2017-02-10 01:43:57 --> URI Class Initialized
DEBUG - 2017-02-10 01:43:57 --> No URI present. Default controller set.
INFO - 2017-02-10 01:43:57 --> Router Class Initialized
INFO - 2017-02-10 01:43:57 --> Output Class Initialized
INFO - 2017-02-10 01:43:57 --> Security Class Initialized
DEBUG - 2017-02-10 01:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 01:43:57 --> Input Class Initialized
INFO - 2017-02-10 01:43:57 --> Language Class Initialized
INFO - 2017-02-10 01:43:57 --> Loader Class Initialized
INFO - 2017-02-10 01:43:57 --> Database Driver Class Initialized
INFO - 2017-02-10 01:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 01:43:57 --> Controller Class Initialized
INFO - 2017-02-10 01:43:57 --> Helper loaded: url_helper
DEBUG - 2017-02-10 01:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 01:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 01:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 01:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 01:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 01:43:57 --> Final output sent to browser
DEBUG - 2017-02-10 01:43:57 --> Total execution time: 0.0144
INFO - 2017-02-10 01:44:05 --> Config Class Initialized
INFO - 2017-02-10 01:44:05 --> Hooks Class Initialized
DEBUG - 2017-02-10 01:44:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 01:44:05 --> Utf8 Class Initialized
INFO - 2017-02-10 01:44:05 --> URI Class Initialized
DEBUG - 2017-02-10 01:44:05 --> No URI present. Default controller set.
INFO - 2017-02-10 01:44:05 --> Router Class Initialized
INFO - 2017-02-10 01:44:05 --> Output Class Initialized
INFO - 2017-02-10 01:44:05 --> Security Class Initialized
DEBUG - 2017-02-10 01:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 01:44:05 --> Input Class Initialized
INFO - 2017-02-10 01:44:05 --> Language Class Initialized
INFO - 2017-02-10 01:44:05 --> Loader Class Initialized
INFO - 2017-02-10 01:44:05 --> Database Driver Class Initialized
INFO - 2017-02-10 01:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 01:44:05 --> Controller Class Initialized
INFO - 2017-02-10 01:44:05 --> Helper loaded: url_helper
DEBUG - 2017-02-10 01:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 01:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 01:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 01:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 01:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 01:44:05 --> Final output sent to browser
DEBUG - 2017-02-10 01:44:05 --> Total execution time: 0.0134
INFO - 2017-02-10 04:10:31 --> Config Class Initialized
INFO - 2017-02-10 04:10:31 --> Hooks Class Initialized
DEBUG - 2017-02-10 04:10:31 --> UTF-8 Support Enabled
INFO - 2017-02-10 04:10:31 --> Utf8 Class Initialized
INFO - 2017-02-10 04:10:31 --> URI Class Initialized
DEBUG - 2017-02-10 04:10:31 --> No URI present. Default controller set.
INFO - 2017-02-10 04:10:31 --> Router Class Initialized
INFO - 2017-02-10 04:10:31 --> Output Class Initialized
INFO - 2017-02-10 04:10:31 --> Security Class Initialized
DEBUG - 2017-02-10 04:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 04:10:31 --> Input Class Initialized
INFO - 2017-02-10 04:10:31 --> Language Class Initialized
INFO - 2017-02-10 04:10:31 --> Loader Class Initialized
INFO - 2017-02-10 04:10:31 --> Database Driver Class Initialized
INFO - 2017-02-10 04:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 04:10:31 --> Controller Class Initialized
INFO - 2017-02-10 04:10:31 --> Helper loaded: url_helper
DEBUG - 2017-02-10 04:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 04:10:31 --> Final output sent to browser
DEBUG - 2017-02-10 04:10:31 --> Total execution time: 0.0155
INFO - 2017-02-10 04:18:53 --> Config Class Initialized
INFO - 2017-02-10 04:18:53 --> Hooks Class Initialized
DEBUG - 2017-02-10 04:18:53 --> UTF-8 Support Enabled
INFO - 2017-02-10 04:18:53 --> Utf8 Class Initialized
INFO - 2017-02-10 04:18:53 --> URI Class Initialized
INFO - 2017-02-10 04:18:53 --> Router Class Initialized
INFO - 2017-02-10 04:18:53 --> Output Class Initialized
INFO - 2017-02-10 04:18:53 --> Security Class Initialized
DEBUG - 2017-02-10 04:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 04:18:53 --> Input Class Initialized
INFO - 2017-02-10 04:18:53 --> Language Class Initialized
INFO - 2017-02-10 04:18:53 --> Loader Class Initialized
INFO - 2017-02-10 04:18:53 --> Database Driver Class Initialized
INFO - 2017-02-10 04:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 04:18:53 --> Controller Class Initialized
INFO - 2017-02-10 04:18:53 --> Helper loaded: date_helper
DEBUG - 2017-02-10 04:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 04:18:53 --> Helper loaded: url_helper
INFO - 2017-02-10 04:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 04:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-10 04:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-10 04:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-10 04:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 04:18:53 --> Final output sent to browser
DEBUG - 2017-02-10 04:18:53 --> Total execution time: 0.0142
INFO - 2017-02-10 04:18:58 --> Config Class Initialized
INFO - 2017-02-10 04:18:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 04:18:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 04:18:58 --> Utf8 Class Initialized
INFO - 2017-02-10 04:18:58 --> URI Class Initialized
INFO - 2017-02-10 04:18:58 --> Router Class Initialized
INFO - 2017-02-10 04:18:58 --> Output Class Initialized
INFO - 2017-02-10 04:18:58 --> Security Class Initialized
DEBUG - 2017-02-10 04:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 04:18:58 --> Input Class Initialized
INFO - 2017-02-10 04:18:58 --> Language Class Initialized
INFO - 2017-02-10 04:18:58 --> Loader Class Initialized
INFO - 2017-02-10 04:18:58 --> Database Driver Class Initialized
INFO - 2017-02-10 04:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 04:18:58 --> Controller Class Initialized
INFO - 2017-02-10 04:18:58 --> Helper loaded: url_helper
DEBUG - 2017-02-10 04:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 04:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 04:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 04:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 04:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 04:18:58 --> Final output sent to browser
DEBUG - 2017-02-10 04:18:58 --> Total execution time: 0.0133
INFO - 2017-02-10 10:26:48 --> Config Class Initialized
INFO - 2017-02-10 10:26:48 --> Hooks Class Initialized
DEBUG - 2017-02-10 10:26:48 --> UTF-8 Support Enabled
INFO - 2017-02-10 10:26:48 --> Utf8 Class Initialized
INFO - 2017-02-10 10:26:48 --> URI Class Initialized
INFO - 2017-02-10 10:26:48 --> Router Class Initialized
INFO - 2017-02-10 10:26:48 --> Output Class Initialized
INFO - 2017-02-10 10:26:48 --> Security Class Initialized
DEBUG - 2017-02-10 10:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 10:26:48 --> Input Class Initialized
INFO - 2017-02-10 10:26:48 --> Language Class Initialized
INFO - 2017-02-10 10:26:48 --> Loader Class Initialized
INFO - 2017-02-10 10:26:48 --> Database Driver Class Initialized
INFO - 2017-02-10 10:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 10:26:48 --> Controller Class Initialized
INFO - 2017-02-10 10:26:48 --> Helper loaded: url_helper
DEBUG - 2017-02-10 10:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 10:26:48 --> Final output sent to browser
DEBUG - 2017-02-10 10:26:48 --> Total execution time: 0.0923
INFO - 2017-02-10 10:26:48 --> Config Class Initialized
INFO - 2017-02-10 10:26:48 --> Hooks Class Initialized
DEBUG - 2017-02-10 10:26:48 --> UTF-8 Support Enabled
INFO - 2017-02-10 10:26:48 --> Utf8 Class Initialized
INFO - 2017-02-10 10:26:48 --> URI Class Initialized
DEBUG - 2017-02-10 10:26:48 --> No URI present. Default controller set.
INFO - 2017-02-10 10:26:48 --> Router Class Initialized
INFO - 2017-02-10 10:26:48 --> Output Class Initialized
INFO - 2017-02-10 10:26:48 --> Security Class Initialized
DEBUG - 2017-02-10 10:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 10:26:48 --> Input Class Initialized
INFO - 2017-02-10 10:26:48 --> Language Class Initialized
INFO - 2017-02-10 10:26:48 --> Loader Class Initialized
INFO - 2017-02-10 10:26:48 --> Database Driver Class Initialized
INFO - 2017-02-10 10:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 10:26:48 --> Controller Class Initialized
INFO - 2017-02-10 10:26:48 --> Helper loaded: url_helper
DEBUG - 2017-02-10 10:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 10:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 10:26:48 --> Final output sent to browser
DEBUG - 2017-02-10 10:26:48 --> Total execution time: 0.0169
INFO - 2017-02-10 10:40:38 --> Config Class Initialized
INFO - 2017-02-10 10:40:38 --> Hooks Class Initialized
DEBUG - 2017-02-10 10:40:38 --> UTF-8 Support Enabled
INFO - 2017-02-10 10:40:38 --> Utf8 Class Initialized
INFO - 2017-02-10 10:40:38 --> URI Class Initialized
INFO - 2017-02-10 10:40:38 --> Router Class Initialized
INFO - 2017-02-10 10:40:38 --> Output Class Initialized
INFO - 2017-02-10 10:40:38 --> Security Class Initialized
DEBUG - 2017-02-10 10:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 10:40:38 --> Input Class Initialized
INFO - 2017-02-10 10:40:38 --> Language Class Initialized
INFO - 2017-02-10 10:40:38 --> Loader Class Initialized
INFO - 2017-02-10 10:40:38 --> Database Driver Class Initialized
INFO - 2017-02-10 10:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 10:40:38 --> Controller Class Initialized
INFO - 2017-02-10 10:40:38 --> Helper loaded: url_helper
DEBUG - 2017-02-10 10:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 10:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 10:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 10:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 10:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 10:40:38 --> Final output sent to browser
DEBUG - 2017-02-10 10:40:38 --> Total execution time: 0.1389
INFO - 2017-02-10 10:40:39 --> Config Class Initialized
INFO - 2017-02-10 10:40:39 --> Hooks Class Initialized
DEBUG - 2017-02-10 10:40:39 --> UTF-8 Support Enabled
INFO - 2017-02-10 10:40:39 --> Utf8 Class Initialized
INFO - 2017-02-10 10:40:39 --> URI Class Initialized
DEBUG - 2017-02-10 10:40:39 --> No URI present. Default controller set.
INFO - 2017-02-10 10:40:39 --> Router Class Initialized
INFO - 2017-02-10 10:40:39 --> Output Class Initialized
INFO - 2017-02-10 10:40:39 --> Security Class Initialized
DEBUG - 2017-02-10 10:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 10:40:39 --> Input Class Initialized
INFO - 2017-02-10 10:40:39 --> Language Class Initialized
INFO - 2017-02-10 10:40:39 --> Loader Class Initialized
INFO - 2017-02-10 10:40:39 --> Database Driver Class Initialized
INFO - 2017-02-10 10:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 10:40:39 --> Controller Class Initialized
INFO - 2017-02-10 10:40:39 --> Helper loaded: url_helper
DEBUG - 2017-02-10 10:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 10:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 10:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 10:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 10:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 10:40:39 --> Final output sent to browser
DEBUG - 2017-02-10 10:40:39 --> Total execution time: 0.0134
INFO - 2017-02-10 12:40:43 --> Config Class Initialized
INFO - 2017-02-10 12:40:43 --> Hooks Class Initialized
DEBUG - 2017-02-10 12:40:43 --> UTF-8 Support Enabled
INFO - 2017-02-10 12:40:43 --> Utf8 Class Initialized
INFO - 2017-02-10 12:40:43 --> URI Class Initialized
DEBUG - 2017-02-10 12:40:43 --> No URI present. Default controller set.
INFO - 2017-02-10 12:40:43 --> Router Class Initialized
INFO - 2017-02-10 12:40:43 --> Output Class Initialized
INFO - 2017-02-10 12:40:43 --> Security Class Initialized
DEBUG - 2017-02-10 12:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 12:40:43 --> Input Class Initialized
INFO - 2017-02-10 12:40:43 --> Language Class Initialized
INFO - 2017-02-10 12:40:43 --> Loader Class Initialized
INFO - 2017-02-10 12:40:43 --> Database Driver Class Initialized
INFO - 2017-02-10 12:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 12:40:43 --> Controller Class Initialized
INFO - 2017-02-10 12:40:43 --> Helper loaded: url_helper
DEBUG - 2017-02-10 12:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 12:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 12:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 12:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 12:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 12:40:43 --> Final output sent to browser
DEBUG - 2017-02-10 12:40:43 --> Total execution time: 0.0137
INFO - 2017-02-10 15:22:33 --> Config Class Initialized
INFO - 2017-02-10 15:22:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 15:22:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 15:22:33 --> Utf8 Class Initialized
INFO - 2017-02-10 15:22:33 --> URI Class Initialized
DEBUG - 2017-02-10 15:22:33 --> No URI present. Default controller set.
INFO - 2017-02-10 15:22:33 --> Router Class Initialized
INFO - 2017-02-10 15:22:33 --> Output Class Initialized
INFO - 2017-02-10 15:22:33 --> Security Class Initialized
DEBUG - 2017-02-10 15:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 15:22:33 --> Input Class Initialized
INFO - 2017-02-10 15:22:33 --> Language Class Initialized
INFO - 2017-02-10 15:22:33 --> Loader Class Initialized
INFO - 2017-02-10 15:22:33 --> Database Driver Class Initialized
INFO - 2017-02-10 15:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 15:22:33 --> Controller Class Initialized
INFO - 2017-02-10 15:22:33 --> Helper loaded: url_helper
DEBUG - 2017-02-10 15:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 15:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 15:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 15:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 15:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 15:22:33 --> Final output sent to browser
DEBUG - 2017-02-10 15:22:33 --> Total execution time: 0.2633
INFO - 2017-02-10 19:26:17 --> Config Class Initialized
INFO - 2017-02-10 19:26:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:26:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:26:18 --> Utf8 Class Initialized
INFO - 2017-02-10 19:26:18 --> URI Class Initialized
DEBUG - 2017-02-10 19:26:18 --> No URI present. Default controller set.
INFO - 2017-02-10 19:26:18 --> Router Class Initialized
INFO - 2017-02-10 19:26:18 --> Output Class Initialized
INFO - 2017-02-10 19:26:18 --> Security Class Initialized
DEBUG - 2017-02-10 19:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:26:18 --> Input Class Initialized
INFO - 2017-02-10 19:26:18 --> Language Class Initialized
INFO - 2017-02-10 19:26:18 --> Loader Class Initialized
INFO - 2017-02-10 19:26:18 --> Database Driver Class Initialized
INFO - 2017-02-10 19:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:26:18 --> Controller Class Initialized
INFO - 2017-02-10 19:26:18 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:26:18 --> Final output sent to browser
DEBUG - 2017-02-10 19:26:18 --> Total execution time: 0.3724
INFO - 2017-02-10 19:26:21 --> Config Class Initialized
INFO - 2017-02-10 19:26:21 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:26:21 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:26:21 --> Utf8 Class Initialized
INFO - 2017-02-10 19:26:21 --> URI Class Initialized
INFO - 2017-02-10 19:26:21 --> Router Class Initialized
INFO - 2017-02-10 19:26:21 --> Output Class Initialized
INFO - 2017-02-10 19:26:21 --> Security Class Initialized
DEBUG - 2017-02-10 19:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:26:21 --> Input Class Initialized
INFO - 2017-02-10 19:26:21 --> Language Class Initialized
INFO - 2017-02-10 19:26:21 --> Loader Class Initialized
INFO - 2017-02-10 19:26:21 --> Database Driver Class Initialized
INFO - 2017-02-10 19:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:26:21 --> Controller Class Initialized
INFO - 2017-02-10 19:26:21 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:26:21 --> Final output sent to browser
DEBUG - 2017-02-10 19:26:21 --> Total execution time: 0.0501
INFO - 2017-02-10 19:26:26 --> Config Class Initialized
INFO - 2017-02-10 19:26:26 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:26:26 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:26:26 --> Utf8 Class Initialized
INFO - 2017-02-10 19:26:26 --> URI Class Initialized
INFO - 2017-02-10 19:26:26 --> Router Class Initialized
INFO - 2017-02-10 19:26:26 --> Output Class Initialized
INFO - 2017-02-10 19:26:26 --> Security Class Initialized
DEBUG - 2017-02-10 19:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:26:26 --> Input Class Initialized
INFO - 2017-02-10 19:26:26 --> Language Class Initialized
INFO - 2017-02-10 19:26:26 --> Loader Class Initialized
INFO - 2017-02-10 19:26:26 --> Database Driver Class Initialized
INFO - 2017-02-10 19:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:26:26 --> Controller Class Initialized
INFO - 2017-02-10 19:26:26 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:26:28 --> Config Class Initialized
INFO - 2017-02-10 19:26:28 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:26:28 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:26:28 --> Utf8 Class Initialized
INFO - 2017-02-10 19:26:28 --> URI Class Initialized
INFO - 2017-02-10 19:26:28 --> Router Class Initialized
INFO - 2017-02-10 19:26:28 --> Output Class Initialized
INFO - 2017-02-10 19:26:28 --> Security Class Initialized
DEBUG - 2017-02-10 19:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:26:28 --> Input Class Initialized
INFO - 2017-02-10 19:26:28 --> Language Class Initialized
INFO - 2017-02-10 19:26:28 --> Loader Class Initialized
INFO - 2017-02-10 19:26:28 --> Database Driver Class Initialized
INFO - 2017-02-10 19:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:26:28 --> Controller Class Initialized
INFO - 2017-02-10 19:26:29 --> Helper loaded: date_helper
DEBUG - 2017-02-10 19:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:26:29 --> Helper loaded: url_helper
INFO - 2017-02-10 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-10 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-10 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-10 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:26:29 --> Final output sent to browser
DEBUG - 2017-02-10 19:26:29 --> Total execution time: 0.4239
INFO - 2017-02-10 19:26:30 --> Config Class Initialized
INFO - 2017-02-10 19:26:30 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:26:30 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:26:30 --> Utf8 Class Initialized
INFO - 2017-02-10 19:26:30 --> URI Class Initialized
INFO - 2017-02-10 19:26:30 --> Router Class Initialized
INFO - 2017-02-10 19:26:30 --> Output Class Initialized
INFO - 2017-02-10 19:26:30 --> Security Class Initialized
DEBUG - 2017-02-10 19:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:26:30 --> Input Class Initialized
INFO - 2017-02-10 19:26:30 --> Language Class Initialized
INFO - 2017-02-10 19:26:30 --> Loader Class Initialized
INFO - 2017-02-10 19:26:30 --> Database Driver Class Initialized
INFO - 2017-02-10 19:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:26:30 --> Controller Class Initialized
INFO - 2017-02-10 19:26:30 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:26:30 --> Final output sent to browser
DEBUG - 2017-02-10 19:26:30 --> Total execution time: 0.0133
INFO - 2017-02-10 19:26:34 --> Config Class Initialized
INFO - 2017-02-10 19:26:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:26:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:26:34 --> Utf8 Class Initialized
INFO - 2017-02-10 19:26:34 --> URI Class Initialized
DEBUG - 2017-02-10 19:26:34 --> No URI present. Default controller set.
INFO - 2017-02-10 19:26:34 --> Router Class Initialized
INFO - 2017-02-10 19:26:34 --> Output Class Initialized
INFO - 2017-02-10 19:26:34 --> Security Class Initialized
DEBUG - 2017-02-10 19:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:26:34 --> Input Class Initialized
INFO - 2017-02-10 19:26:34 --> Language Class Initialized
INFO - 2017-02-10 19:26:34 --> Loader Class Initialized
INFO - 2017-02-10 19:26:34 --> Database Driver Class Initialized
INFO - 2017-02-10 19:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:26:34 --> Controller Class Initialized
INFO - 2017-02-10 19:26:34 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:26:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:26:34 --> Final output sent to browser
DEBUG - 2017-02-10 19:26:34 --> Total execution time: 0.0140
INFO - 2017-02-10 19:26:35 --> Config Class Initialized
INFO - 2017-02-10 19:26:35 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:26:35 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:26:35 --> Utf8 Class Initialized
INFO - 2017-02-10 19:26:35 --> URI Class Initialized
INFO - 2017-02-10 19:26:35 --> Router Class Initialized
INFO - 2017-02-10 19:26:35 --> Output Class Initialized
INFO - 2017-02-10 19:26:35 --> Security Class Initialized
DEBUG - 2017-02-10 19:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:26:35 --> Input Class Initialized
INFO - 2017-02-10 19:26:35 --> Language Class Initialized
INFO - 2017-02-10 19:26:35 --> Loader Class Initialized
INFO - 2017-02-10 19:26:35 --> Database Driver Class Initialized
INFO - 2017-02-10 19:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:26:35 --> Controller Class Initialized
INFO - 2017-02-10 19:26:35 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:26:35 --> Final output sent to browser
DEBUG - 2017-02-10 19:26:35 --> Total execution time: 0.0148
INFO - 2017-02-10 19:40:52 --> Config Class Initialized
INFO - 2017-02-10 19:40:52 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:40:52 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:40:52 --> Utf8 Class Initialized
INFO - 2017-02-10 19:40:52 --> URI Class Initialized
INFO - 2017-02-10 19:40:52 --> Router Class Initialized
INFO - 2017-02-10 19:40:52 --> Output Class Initialized
INFO - 2017-02-10 19:40:52 --> Security Class Initialized
DEBUG - 2017-02-10 19:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:40:52 --> Input Class Initialized
INFO - 2017-02-10 19:40:52 --> Language Class Initialized
INFO - 2017-02-10 19:40:52 --> Loader Class Initialized
INFO - 2017-02-10 19:40:52 --> Database Driver Class Initialized
INFO - 2017-02-10 19:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:40:52 --> Controller Class Initialized
INFO - 2017-02-10 19:40:52 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:40:52 --> Final output sent to browser
DEBUG - 2017-02-10 19:40:52 --> Total execution time: 0.0135
INFO - 2017-02-10 19:40:52 --> Config Class Initialized
INFO - 2017-02-10 19:40:52 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:40:52 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:40:52 --> Utf8 Class Initialized
INFO - 2017-02-10 19:40:52 --> URI Class Initialized
DEBUG - 2017-02-10 19:40:52 --> No URI present. Default controller set.
INFO - 2017-02-10 19:40:52 --> Router Class Initialized
INFO - 2017-02-10 19:40:52 --> Output Class Initialized
INFO - 2017-02-10 19:40:52 --> Security Class Initialized
DEBUG - 2017-02-10 19:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:40:52 --> Input Class Initialized
INFO - 2017-02-10 19:40:52 --> Language Class Initialized
INFO - 2017-02-10 19:40:52 --> Loader Class Initialized
INFO - 2017-02-10 19:40:52 --> Database Driver Class Initialized
INFO - 2017-02-10 19:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:40:52 --> Controller Class Initialized
INFO - 2017-02-10 19:40:52 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:40:52 --> Final output sent to browser
DEBUG - 2017-02-10 19:40:52 --> Total execution time: 0.0135
INFO - 2017-02-10 19:41:25 --> Config Class Initialized
INFO - 2017-02-10 19:41:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 19:41:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 19:41:25 --> Utf8 Class Initialized
INFO - 2017-02-10 19:41:25 --> URI Class Initialized
DEBUG - 2017-02-10 19:41:25 --> No URI present. Default controller set.
INFO - 2017-02-10 19:41:25 --> Router Class Initialized
INFO - 2017-02-10 19:41:25 --> Output Class Initialized
INFO - 2017-02-10 19:41:25 --> Security Class Initialized
DEBUG - 2017-02-10 19:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 19:41:25 --> Input Class Initialized
INFO - 2017-02-10 19:41:25 --> Language Class Initialized
INFO - 2017-02-10 19:41:25 --> Loader Class Initialized
INFO - 2017-02-10 19:41:25 --> Database Driver Class Initialized
INFO - 2017-02-10 19:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 19:41:25 --> Controller Class Initialized
INFO - 2017-02-10 19:41:25 --> Helper loaded: url_helper
DEBUG - 2017-02-10 19:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 19:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 19:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 19:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 19:41:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 19:41:25 --> Final output sent to browser
DEBUG - 2017-02-10 19:41:25 --> Total execution time: 0.0138
INFO - 2017-02-10 20:00:10 --> Config Class Initialized
INFO - 2017-02-10 20:00:10 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:00:10 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:00:10 --> Utf8 Class Initialized
INFO - 2017-02-10 20:00:10 --> URI Class Initialized
DEBUG - 2017-02-10 20:00:10 --> No URI present. Default controller set.
INFO - 2017-02-10 20:00:10 --> Router Class Initialized
INFO - 2017-02-10 20:00:10 --> Output Class Initialized
INFO - 2017-02-10 20:00:10 --> Security Class Initialized
DEBUG - 2017-02-10 20:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:00:10 --> Input Class Initialized
INFO - 2017-02-10 20:00:10 --> Language Class Initialized
INFO - 2017-02-10 20:00:10 --> Loader Class Initialized
INFO - 2017-02-10 20:00:10 --> Database Driver Class Initialized
INFO - 2017-02-10 20:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:00:10 --> Controller Class Initialized
INFO - 2017-02-10 20:00:10 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:00:10 --> Final output sent to browser
DEBUG - 2017-02-10 20:00:10 --> Total execution time: 0.0251
INFO - 2017-02-10 20:00:24 --> Config Class Initialized
INFO - 2017-02-10 20:00:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:00:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:00:24 --> Utf8 Class Initialized
INFO - 2017-02-10 20:00:24 --> URI Class Initialized
INFO - 2017-02-10 20:00:24 --> Router Class Initialized
INFO - 2017-02-10 20:00:24 --> Output Class Initialized
INFO - 2017-02-10 20:00:24 --> Security Class Initialized
DEBUG - 2017-02-10 20:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:00:24 --> Input Class Initialized
INFO - 2017-02-10 20:00:24 --> Language Class Initialized
INFO - 2017-02-10 20:00:24 --> Loader Class Initialized
INFO - 2017-02-10 20:00:24 --> Database Driver Class Initialized
INFO - 2017-02-10 20:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:00:24 --> Controller Class Initialized
INFO - 2017-02-10 20:00:24 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:00:24 --> Final output sent to browser
DEBUG - 2017-02-10 20:00:24 --> Total execution time: 0.0144
INFO - 2017-02-10 20:00:44 --> Config Class Initialized
INFO - 2017-02-10 20:00:44 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:00:44 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:00:44 --> Utf8 Class Initialized
INFO - 2017-02-10 20:00:44 --> URI Class Initialized
INFO - 2017-02-10 20:00:44 --> Router Class Initialized
INFO - 2017-02-10 20:00:44 --> Output Class Initialized
INFO - 2017-02-10 20:00:44 --> Security Class Initialized
DEBUG - 2017-02-10 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:00:44 --> Input Class Initialized
INFO - 2017-02-10 20:00:44 --> Language Class Initialized
INFO - 2017-02-10 20:00:44 --> Loader Class Initialized
INFO - 2017-02-10 20:00:44 --> Database Driver Class Initialized
INFO - 2017-02-10 20:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:00:44 --> Controller Class Initialized
INFO - 2017-02-10 20:00:44 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:00:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-10 20:00:45 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-10 20:00:45 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Gaby Robles')
INFO - 2017-02-10 20:00:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-10 20:00:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-10 20:00:45 --> Config Class Initialized
INFO - 2017-02-10 20:00:45 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:00:45 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:00:45 --> Utf8 Class Initialized
INFO - 2017-02-10 20:00:45 --> URI Class Initialized
INFO - 2017-02-10 20:00:45 --> Router Class Initialized
INFO - 2017-02-10 20:00:45 --> Output Class Initialized
INFO - 2017-02-10 20:00:45 --> Security Class Initialized
DEBUG - 2017-02-10 20:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:00:45 --> Input Class Initialized
INFO - 2017-02-10 20:00:45 --> Language Class Initialized
INFO - 2017-02-10 20:00:45 --> Loader Class Initialized
INFO - 2017-02-10 20:00:45 --> Database Driver Class Initialized
INFO - 2017-02-10 20:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:00:45 --> Controller Class Initialized
INFO - 2017-02-10 20:00:45 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:00:45 --> Final output sent to browser
DEBUG - 2017-02-10 20:00:45 --> Total execution time: 0.0137
INFO - 2017-02-10 20:01:08 --> Config Class Initialized
INFO - 2017-02-10 20:01:08 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:01:08 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:01:08 --> Utf8 Class Initialized
INFO - 2017-02-10 20:01:08 --> URI Class Initialized
DEBUG - 2017-02-10 20:01:08 --> No URI present. Default controller set.
INFO - 2017-02-10 20:01:08 --> Router Class Initialized
INFO - 2017-02-10 20:01:08 --> Output Class Initialized
INFO - 2017-02-10 20:01:08 --> Security Class Initialized
DEBUG - 2017-02-10 20:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:01:08 --> Input Class Initialized
INFO - 2017-02-10 20:01:08 --> Language Class Initialized
INFO - 2017-02-10 20:01:08 --> Loader Class Initialized
INFO - 2017-02-10 20:01:08 --> Database Driver Class Initialized
INFO - 2017-02-10 20:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:01:08 --> Controller Class Initialized
INFO - 2017-02-10 20:01:08 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:01:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:01:08 --> Final output sent to browser
DEBUG - 2017-02-10 20:01:08 --> Total execution time: 0.0627
INFO - 2017-02-10 20:01:10 --> Config Class Initialized
INFO - 2017-02-10 20:01:10 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:01:10 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:01:10 --> Utf8 Class Initialized
INFO - 2017-02-10 20:01:10 --> URI Class Initialized
INFO - 2017-02-10 20:01:10 --> Router Class Initialized
INFO - 2017-02-10 20:01:10 --> Output Class Initialized
INFO - 2017-02-10 20:01:10 --> Security Class Initialized
DEBUG - 2017-02-10 20:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:01:10 --> Input Class Initialized
INFO - 2017-02-10 20:01:10 --> Language Class Initialized
INFO - 2017-02-10 20:01:10 --> Loader Class Initialized
INFO - 2017-02-10 20:01:10 --> Database Driver Class Initialized
INFO - 2017-02-10 20:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:01:10 --> Controller Class Initialized
INFO - 2017-02-10 20:01:10 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:01:10 --> Final output sent to browser
DEBUG - 2017-02-10 20:01:10 --> Total execution time: 0.0138
INFO - 2017-02-10 20:01:24 --> Config Class Initialized
INFO - 2017-02-10 20:01:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:01:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:01:24 --> Utf8 Class Initialized
INFO - 2017-02-10 20:01:24 --> URI Class Initialized
INFO - 2017-02-10 20:01:24 --> Router Class Initialized
INFO - 2017-02-10 20:01:24 --> Output Class Initialized
INFO - 2017-02-10 20:01:24 --> Security Class Initialized
DEBUG - 2017-02-10 20:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:01:24 --> Input Class Initialized
INFO - 2017-02-10 20:01:24 --> Language Class Initialized
INFO - 2017-02-10 20:01:24 --> Loader Class Initialized
INFO - 2017-02-10 20:01:24 --> Database Driver Class Initialized
INFO - 2017-02-10 20:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:01:24 --> Controller Class Initialized
INFO - 2017-02-10 20:01:24 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:01:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-10 20:01:25 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-10 20:01:25 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Gaby Robles')
INFO - 2017-02-10 20:01:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-10 20:01:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-10 20:01:26 --> Config Class Initialized
INFO - 2017-02-10 20:01:26 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:01:26 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:01:26 --> Utf8 Class Initialized
INFO - 2017-02-10 20:01:26 --> URI Class Initialized
INFO - 2017-02-10 20:01:26 --> Router Class Initialized
INFO - 2017-02-10 20:01:26 --> Output Class Initialized
INFO - 2017-02-10 20:01:26 --> Security Class Initialized
DEBUG - 2017-02-10 20:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:01:26 --> Input Class Initialized
INFO - 2017-02-10 20:01:26 --> Language Class Initialized
INFO - 2017-02-10 20:01:26 --> Loader Class Initialized
INFO - 2017-02-10 20:01:26 --> Database Driver Class Initialized
INFO - 2017-02-10 20:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:01:26 --> Controller Class Initialized
INFO - 2017-02-10 20:01:26 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:01:26 --> Final output sent to browser
DEBUG - 2017-02-10 20:01:26 --> Total execution time: 0.0139
INFO - 2017-02-10 20:01:29 --> Config Class Initialized
INFO - 2017-02-10 20:01:29 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:01:29 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:01:29 --> Utf8 Class Initialized
INFO - 2017-02-10 20:01:29 --> URI Class Initialized
DEBUG - 2017-02-10 20:01:29 --> No URI present. Default controller set.
INFO - 2017-02-10 20:01:29 --> Router Class Initialized
INFO - 2017-02-10 20:01:29 --> Output Class Initialized
INFO - 2017-02-10 20:01:29 --> Security Class Initialized
DEBUG - 2017-02-10 20:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:01:29 --> Input Class Initialized
INFO - 2017-02-10 20:01:29 --> Language Class Initialized
INFO - 2017-02-10 20:01:29 --> Loader Class Initialized
INFO - 2017-02-10 20:01:29 --> Database Driver Class Initialized
INFO - 2017-02-10 20:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:01:29 --> Controller Class Initialized
INFO - 2017-02-10 20:01:29 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:01:29 --> Final output sent to browser
DEBUG - 2017-02-10 20:01:29 --> Total execution time: 0.0133
INFO - 2017-02-10 20:01:30 --> Config Class Initialized
INFO - 2017-02-10 20:01:30 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:01:30 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:01:30 --> Utf8 Class Initialized
INFO - 2017-02-10 20:01:30 --> URI Class Initialized
INFO - 2017-02-10 20:01:30 --> Router Class Initialized
INFO - 2017-02-10 20:01:30 --> Output Class Initialized
INFO - 2017-02-10 20:01:30 --> Security Class Initialized
DEBUG - 2017-02-10 20:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:01:30 --> Input Class Initialized
INFO - 2017-02-10 20:01:30 --> Language Class Initialized
INFO - 2017-02-10 20:01:30 --> Loader Class Initialized
INFO - 2017-02-10 20:01:30 --> Database Driver Class Initialized
INFO - 2017-02-10 20:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:01:30 --> Controller Class Initialized
INFO - 2017-02-10 20:01:30 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:01:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:01:30 --> Final output sent to browser
DEBUG - 2017-02-10 20:01:30 --> Total execution time: 0.0138
INFO - 2017-02-10 20:02:39 --> Config Class Initialized
INFO - 2017-02-10 20:02:39 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:02:39 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:02:39 --> Utf8 Class Initialized
INFO - 2017-02-10 20:02:39 --> URI Class Initialized
INFO - 2017-02-10 20:02:39 --> Router Class Initialized
INFO - 2017-02-10 20:02:39 --> Output Class Initialized
INFO - 2017-02-10 20:02:40 --> Security Class Initialized
DEBUG - 2017-02-10 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:02:40 --> Input Class Initialized
INFO - 2017-02-10 20:02:40 --> Language Class Initialized
INFO - 2017-02-10 20:02:40 --> Loader Class Initialized
INFO - 2017-02-10 20:02:40 --> Database Driver Class Initialized
INFO - 2017-02-10 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:02:40 --> Controller Class Initialized
INFO - 2017-02-10 20:02:40 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:02:40 --> Config Class Initialized
INFO - 2017-02-10 20:02:40 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:02:40 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:02:40 --> Utf8 Class Initialized
INFO - 2017-02-10 20:02:40 --> URI Class Initialized
INFO - 2017-02-10 20:02:40 --> Router Class Initialized
INFO - 2017-02-10 20:02:40 --> Output Class Initialized
INFO - 2017-02-10 20:02:40 --> Security Class Initialized
DEBUG - 2017-02-10 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:02:40 --> Input Class Initialized
INFO - 2017-02-10 20:02:40 --> Language Class Initialized
INFO - 2017-02-10 20:02:40 --> Loader Class Initialized
INFO - 2017-02-10 20:02:40 --> Database Driver Class Initialized
INFO - 2017-02-10 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:02:40 --> Controller Class Initialized
INFO - 2017-02-10 20:02:40 --> Helper loaded: date_helper
DEBUG - 2017-02-10 20:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:02:40 --> Helper loaded: url_helper
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:02:40 --> Final output sent to browser
DEBUG - 2017-02-10 20:02:40 --> Total execution time: 0.0134
INFO - 2017-02-10 20:02:40 --> Config Class Initialized
INFO - 2017-02-10 20:02:40 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:02:40 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:02:40 --> Utf8 Class Initialized
INFO - 2017-02-10 20:02:40 --> URI Class Initialized
INFO - 2017-02-10 20:02:40 --> Router Class Initialized
INFO - 2017-02-10 20:02:40 --> Output Class Initialized
INFO - 2017-02-10 20:02:40 --> Security Class Initialized
DEBUG - 2017-02-10 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:02:40 --> Input Class Initialized
INFO - 2017-02-10 20:02:40 --> Language Class Initialized
INFO - 2017-02-10 20:02:40 --> Loader Class Initialized
INFO - 2017-02-10 20:02:40 --> Database Driver Class Initialized
INFO - 2017-02-10 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:02:40 --> Controller Class Initialized
INFO - 2017-02-10 20:02:40 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:02:40 --> Final output sent to browser
DEBUG - 2017-02-10 20:02:40 --> Total execution time: 0.0138
INFO - 2017-02-10 20:02:46 --> Config Class Initialized
INFO - 2017-02-10 20:02:46 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:02:46 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:02:46 --> Utf8 Class Initialized
INFO - 2017-02-10 20:02:46 --> URI Class Initialized
INFO - 2017-02-10 20:02:46 --> Router Class Initialized
INFO - 2017-02-10 20:02:46 --> Output Class Initialized
INFO - 2017-02-10 20:02:46 --> Security Class Initialized
DEBUG - 2017-02-10 20:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:02:46 --> Input Class Initialized
INFO - 2017-02-10 20:02:46 --> Language Class Initialized
INFO - 2017-02-10 20:02:46 --> Loader Class Initialized
INFO - 2017-02-10 20:02:46 --> Database Driver Class Initialized
INFO - 2017-02-10 20:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:02:46 --> Controller Class Initialized
INFO - 2017-02-10 20:02:46 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:02:46 --> Final output sent to browser
DEBUG - 2017-02-10 20:02:46 --> Total execution time: 0.0144
INFO - 2017-02-10 20:02:46 --> Config Class Initialized
INFO - 2017-02-10 20:02:46 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:02:46 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:02:46 --> Utf8 Class Initialized
INFO - 2017-02-10 20:02:46 --> URI Class Initialized
DEBUG - 2017-02-10 20:02:46 --> No URI present. Default controller set.
INFO - 2017-02-10 20:02:46 --> Router Class Initialized
INFO - 2017-02-10 20:02:46 --> Output Class Initialized
INFO - 2017-02-10 20:02:46 --> Security Class Initialized
DEBUG - 2017-02-10 20:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:02:46 --> Input Class Initialized
INFO - 2017-02-10 20:02:46 --> Language Class Initialized
INFO - 2017-02-10 20:02:46 --> Loader Class Initialized
INFO - 2017-02-10 20:02:46 --> Database Driver Class Initialized
INFO - 2017-02-10 20:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:02:46 --> Controller Class Initialized
INFO - 2017-02-10 20:02:46 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:02:46 --> Final output sent to browser
DEBUG - 2017-02-10 20:02:46 --> Total execution time: 0.0131
INFO - 2017-02-10 20:02:50 --> Config Class Initialized
INFO - 2017-02-10 20:02:50 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:02:50 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:02:50 --> Utf8 Class Initialized
INFO - 2017-02-10 20:02:50 --> URI Class Initialized
DEBUG - 2017-02-10 20:02:50 --> No URI present. Default controller set.
INFO - 2017-02-10 20:02:50 --> Router Class Initialized
INFO - 2017-02-10 20:02:50 --> Output Class Initialized
INFO - 2017-02-10 20:02:50 --> Security Class Initialized
DEBUG - 2017-02-10 20:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:02:50 --> Input Class Initialized
INFO - 2017-02-10 20:02:50 --> Language Class Initialized
INFO - 2017-02-10 20:02:50 --> Loader Class Initialized
INFO - 2017-02-10 20:02:50 --> Database Driver Class Initialized
INFO - 2017-02-10 20:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:02:50 --> Controller Class Initialized
INFO - 2017-02-10 20:02:50 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:02:50 --> Final output sent to browser
DEBUG - 2017-02-10 20:02:50 --> Total execution time: 0.0135
INFO - 2017-02-10 20:02:52 --> Config Class Initialized
INFO - 2017-02-10 20:02:52 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:02:52 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:02:52 --> Utf8 Class Initialized
INFO - 2017-02-10 20:02:52 --> URI Class Initialized
INFO - 2017-02-10 20:02:52 --> Router Class Initialized
INFO - 2017-02-10 20:02:52 --> Output Class Initialized
INFO - 2017-02-10 20:02:52 --> Security Class Initialized
DEBUG - 2017-02-10 20:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:02:52 --> Input Class Initialized
INFO - 2017-02-10 20:02:52 --> Language Class Initialized
INFO - 2017-02-10 20:02:52 --> Loader Class Initialized
INFO - 2017-02-10 20:02:52 --> Database Driver Class Initialized
INFO - 2017-02-10 20:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:02:52 --> Controller Class Initialized
INFO - 2017-02-10 20:02:52 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:02:52 --> Final output sent to browser
DEBUG - 2017-02-10 20:02:52 --> Total execution time: 0.0181
INFO - 2017-02-10 20:03:31 --> Config Class Initialized
INFO - 2017-02-10 20:03:31 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:03:31 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:03:31 --> Utf8 Class Initialized
INFO - 2017-02-10 20:03:31 --> URI Class Initialized
INFO - 2017-02-10 20:03:31 --> Router Class Initialized
INFO - 2017-02-10 20:03:31 --> Output Class Initialized
INFO - 2017-02-10 20:03:31 --> Security Class Initialized
DEBUG - 2017-02-10 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:03:31 --> Input Class Initialized
INFO - 2017-02-10 20:03:31 --> Language Class Initialized
INFO - 2017-02-10 20:03:31 --> Loader Class Initialized
INFO - 2017-02-10 20:03:31 --> Database Driver Class Initialized
INFO - 2017-02-10 20:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:03:31 --> Controller Class Initialized
INFO - 2017-02-10 20:03:31 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:03:31 --> Config Class Initialized
INFO - 2017-02-10 20:03:31 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:03:31 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:03:31 --> Utf8 Class Initialized
INFO - 2017-02-10 20:03:31 --> URI Class Initialized
INFO - 2017-02-10 20:03:31 --> Router Class Initialized
INFO - 2017-02-10 20:03:31 --> Output Class Initialized
INFO - 2017-02-10 20:03:31 --> Security Class Initialized
DEBUG - 2017-02-10 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:03:31 --> Input Class Initialized
INFO - 2017-02-10 20:03:31 --> Language Class Initialized
INFO - 2017-02-10 20:03:31 --> Loader Class Initialized
INFO - 2017-02-10 20:03:31 --> Database Driver Class Initialized
INFO - 2017-02-10 20:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:03:31 --> Controller Class Initialized
INFO - 2017-02-10 20:03:31 --> Helper loaded: date_helper
DEBUG - 2017-02-10 20:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:03:31 --> Helper loaded: url_helper
INFO - 2017-02-10 20:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-10 20:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-10 20:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-10 20:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:03:31 --> Final output sent to browser
DEBUG - 2017-02-10 20:03:31 --> Total execution time: 0.0150
INFO - 2017-02-10 20:03:32 --> Config Class Initialized
INFO - 2017-02-10 20:03:32 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:03:32 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:03:32 --> Utf8 Class Initialized
INFO - 2017-02-10 20:03:32 --> URI Class Initialized
INFO - 2017-02-10 20:03:32 --> Router Class Initialized
INFO - 2017-02-10 20:03:32 --> Output Class Initialized
INFO - 2017-02-10 20:03:32 --> Security Class Initialized
DEBUG - 2017-02-10 20:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:03:32 --> Input Class Initialized
INFO - 2017-02-10 20:03:32 --> Language Class Initialized
INFO - 2017-02-10 20:03:32 --> Loader Class Initialized
INFO - 2017-02-10 20:03:32 --> Database Driver Class Initialized
INFO - 2017-02-10 20:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:03:32 --> Controller Class Initialized
INFO - 2017-02-10 20:03:32 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:03:32 --> Final output sent to browser
DEBUG - 2017-02-10 20:03:32 --> Total execution time: 0.0131
INFO - 2017-02-10 20:03:42 --> Config Class Initialized
INFO - 2017-02-10 20:03:42 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:03:42 --> Utf8 Class Initialized
INFO - 2017-02-10 20:03:42 --> URI Class Initialized
DEBUG - 2017-02-10 20:03:42 --> No URI present. Default controller set.
INFO - 2017-02-10 20:03:42 --> Router Class Initialized
INFO - 2017-02-10 20:03:42 --> Output Class Initialized
INFO - 2017-02-10 20:03:42 --> Security Class Initialized
DEBUG - 2017-02-10 20:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:03:42 --> Input Class Initialized
INFO - 2017-02-10 20:03:42 --> Language Class Initialized
INFO - 2017-02-10 20:03:42 --> Loader Class Initialized
INFO - 2017-02-10 20:03:42 --> Database Driver Class Initialized
INFO - 2017-02-10 20:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:03:42 --> Controller Class Initialized
INFO - 2017-02-10 20:03:42 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:03:42 --> Final output sent to browser
DEBUG - 2017-02-10 20:03:42 --> Total execution time: 0.0150
INFO - 2017-02-10 20:03:43 --> Config Class Initialized
INFO - 2017-02-10 20:03:43 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:03:43 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:03:43 --> Utf8 Class Initialized
INFO - 2017-02-10 20:03:43 --> URI Class Initialized
INFO - 2017-02-10 20:03:43 --> Router Class Initialized
INFO - 2017-02-10 20:03:43 --> Output Class Initialized
INFO - 2017-02-10 20:03:43 --> Security Class Initialized
DEBUG - 2017-02-10 20:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:03:43 --> Input Class Initialized
INFO - 2017-02-10 20:03:43 --> Language Class Initialized
INFO - 2017-02-10 20:03:43 --> Loader Class Initialized
INFO - 2017-02-10 20:03:43 --> Database Driver Class Initialized
INFO - 2017-02-10 20:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:03:43 --> Controller Class Initialized
INFO - 2017-02-10 20:03:43 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:03:43 --> Final output sent to browser
DEBUG - 2017-02-10 20:03:43 --> Total execution time: 0.0140
INFO - 2017-02-10 20:16:41 --> Config Class Initialized
INFO - 2017-02-10 20:16:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:16:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:16:41 --> Utf8 Class Initialized
INFO - 2017-02-10 20:16:41 --> URI Class Initialized
DEBUG - 2017-02-10 20:16:41 --> No URI present. Default controller set.
INFO - 2017-02-10 20:16:41 --> Router Class Initialized
INFO - 2017-02-10 20:16:41 --> Output Class Initialized
INFO - 2017-02-10 20:16:41 --> Security Class Initialized
DEBUG - 2017-02-10 20:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:16:41 --> Input Class Initialized
INFO - 2017-02-10 20:16:41 --> Language Class Initialized
INFO - 2017-02-10 20:16:41 --> Loader Class Initialized
INFO - 2017-02-10 20:16:41 --> Database Driver Class Initialized
INFO - 2017-02-10 20:16:41 --> Config Class Initialized
INFO - 2017-02-10 20:16:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:16:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:16:41 --> Utf8 Class Initialized
INFO - 2017-02-10 20:16:41 --> URI Class Initialized
INFO - 2017-02-10 20:16:41 --> Router Class Initialized
INFO - 2017-02-10 20:16:41 --> Output Class Initialized
INFO - 2017-02-10 20:16:41 --> Security Class Initialized
DEBUG - 2017-02-10 20:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:16:41 --> Input Class Initialized
INFO - 2017-02-10 20:16:41 --> Language Class Initialized
INFO - 2017-02-10 20:16:41 --> Loader Class Initialized
INFO - 2017-02-10 20:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:16:41 --> Controller Class Initialized
INFO - 2017-02-10 20:16:41 --> Database Driver Class Initialized
INFO - 2017-02-10 20:16:41 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:16:41 --> Final output sent to browser
DEBUG - 2017-02-10 20:16:41 --> Total execution time: 0.0463
INFO - 2017-02-10 20:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:16:41 --> Controller Class Initialized
INFO - 2017-02-10 20:16:41 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:16:41 --> Helper loaded: form_helper
INFO - 2017-02-10 20:16:41 --> Form Validation Class Initialized
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-10 20:16:41 --> Final output sent to browser
DEBUG - 2017-02-10 20:16:41 --> Total execution time: 0.2183
INFO - 2017-02-10 20:16:41 --> Config Class Initialized
INFO - 2017-02-10 20:16:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:16:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:16:41 --> Utf8 Class Initialized
INFO - 2017-02-10 20:16:41 --> URI Class Initialized
INFO - 2017-02-10 20:16:41 --> Router Class Initialized
INFO - 2017-02-10 20:16:41 --> Output Class Initialized
INFO - 2017-02-10 20:16:41 --> Security Class Initialized
DEBUG - 2017-02-10 20:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:16:41 --> Input Class Initialized
INFO - 2017-02-10 20:16:41 --> Language Class Initialized
INFO - 2017-02-10 20:16:41 --> Loader Class Initialized
INFO - 2017-02-10 20:16:41 --> Database Driver Class Initialized
INFO - 2017-02-10 20:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:16:41 --> Controller Class Initialized
INFO - 2017-02-10 20:16:41 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:16:41 --> Final output sent to browser
DEBUG - 2017-02-10 20:16:41 --> Total execution time: 0.0141
INFO - 2017-02-10 20:38:10 --> Config Class Initialized
INFO - 2017-02-10 20:38:10 --> Hooks Class Initialized
DEBUG - 2017-02-10 20:38:10 --> UTF-8 Support Enabled
INFO - 2017-02-10 20:38:10 --> Utf8 Class Initialized
INFO - 2017-02-10 20:38:10 --> URI Class Initialized
DEBUG - 2017-02-10 20:38:10 --> No URI present. Default controller set.
INFO - 2017-02-10 20:38:10 --> Router Class Initialized
INFO - 2017-02-10 20:38:10 --> Output Class Initialized
INFO - 2017-02-10 20:38:10 --> Security Class Initialized
DEBUG - 2017-02-10 20:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 20:38:10 --> Input Class Initialized
INFO - 2017-02-10 20:38:10 --> Language Class Initialized
INFO - 2017-02-10 20:38:10 --> Loader Class Initialized
INFO - 2017-02-10 20:38:10 --> Database Driver Class Initialized
INFO - 2017-02-10 20:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 20:38:10 --> Controller Class Initialized
INFO - 2017-02-10 20:38:10 --> Helper loaded: url_helper
DEBUG - 2017-02-10 20:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 20:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 20:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 20:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 20:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 20:38:10 --> Final output sent to browser
DEBUG - 2017-02-10 20:38:10 --> Total execution time: 0.0135
INFO - 2017-02-10 21:18:46 --> Config Class Initialized
INFO - 2017-02-10 21:18:46 --> Hooks Class Initialized
DEBUG - 2017-02-10 21:18:46 --> UTF-8 Support Enabled
INFO - 2017-02-10 21:18:46 --> Utf8 Class Initialized
INFO - 2017-02-10 21:18:46 --> URI Class Initialized
INFO - 2017-02-10 21:18:46 --> Router Class Initialized
INFO - 2017-02-10 21:18:46 --> Output Class Initialized
INFO - 2017-02-10 21:18:46 --> Security Class Initialized
DEBUG - 2017-02-10 21:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 21:18:46 --> Input Class Initialized
INFO - 2017-02-10 21:18:46 --> Language Class Initialized
INFO - 2017-02-10 21:18:46 --> Loader Class Initialized
INFO - 2017-02-10 21:18:46 --> Database Driver Class Initialized
INFO - 2017-02-10 21:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 21:18:46 --> Controller Class Initialized
INFO - 2017-02-10 21:18:46 --> Helper loaded: url_helper
DEBUG - 2017-02-10 21:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 21:18:46 --> Final output sent to browser
DEBUG - 2017-02-10 21:18:46 --> Total execution time: 0.0154
INFO - 2017-02-10 21:18:46 --> Config Class Initialized
INFO - 2017-02-10 21:18:46 --> Hooks Class Initialized
DEBUG - 2017-02-10 21:18:46 --> UTF-8 Support Enabled
INFO - 2017-02-10 21:18:46 --> Utf8 Class Initialized
INFO - 2017-02-10 21:18:46 --> URI Class Initialized
DEBUG - 2017-02-10 21:18:46 --> No URI present. Default controller set.
INFO - 2017-02-10 21:18:46 --> Router Class Initialized
INFO - 2017-02-10 21:18:46 --> Output Class Initialized
INFO - 2017-02-10 21:18:46 --> Security Class Initialized
DEBUG - 2017-02-10 21:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 21:18:46 --> Input Class Initialized
INFO - 2017-02-10 21:18:46 --> Language Class Initialized
INFO - 2017-02-10 21:18:46 --> Loader Class Initialized
INFO - 2017-02-10 21:18:46 --> Database Driver Class Initialized
INFO - 2017-02-10 21:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 21:18:46 --> Controller Class Initialized
INFO - 2017-02-10 21:18:46 --> Helper loaded: url_helper
DEBUG - 2017-02-10 21:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 21:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 21:18:46 --> Final output sent to browser
DEBUG - 2017-02-10 21:18:46 --> Total execution time: 0.0135
INFO - 2017-02-10 22:53:30 --> Config Class Initialized
INFO - 2017-02-10 22:53:30 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:53:30 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:53:30 --> Utf8 Class Initialized
INFO - 2017-02-10 22:53:30 --> URI Class Initialized
INFO - 2017-02-10 22:53:30 --> Router Class Initialized
INFO - 2017-02-10 22:53:30 --> Output Class Initialized
INFO - 2017-02-10 22:53:30 --> Security Class Initialized
DEBUG - 2017-02-10 22:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:53:30 --> Input Class Initialized
INFO - 2017-02-10 22:53:30 --> Language Class Initialized
INFO - 2017-02-10 22:53:30 --> Loader Class Initialized
INFO - 2017-02-10 22:53:30 --> Database Driver Class Initialized
INFO - 2017-02-10 22:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:53:30 --> Controller Class Initialized
INFO - 2017-02-10 22:53:30 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:53:30 --> Final output sent to browser
DEBUG - 2017-02-10 22:53:30 --> Total execution time: 0.2518
INFO - 2017-02-10 22:53:37 --> Config Class Initialized
INFO - 2017-02-10 22:53:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:53:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:53:37 --> Utf8 Class Initialized
INFO - 2017-02-10 22:53:37 --> URI Class Initialized
INFO - 2017-02-10 22:53:37 --> Router Class Initialized
INFO - 2017-02-10 22:53:37 --> Output Class Initialized
INFO - 2017-02-10 22:53:37 --> Security Class Initialized
DEBUG - 2017-02-10 22:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:53:37 --> Input Class Initialized
INFO - 2017-02-10 22:53:37 --> Language Class Initialized
INFO - 2017-02-10 22:53:37 --> Loader Class Initialized
INFO - 2017-02-10 22:53:37 --> Database Driver Class Initialized
INFO - 2017-02-10 22:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:53:37 --> Controller Class Initialized
INFO - 2017-02-10 22:53:37 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 22:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 22:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:53:37 --> Final output sent to browser
DEBUG - 2017-02-10 22:53:37 --> Total execution time: 0.0139
INFO - 2017-02-10 22:55:01 --> Config Class Initialized
INFO - 2017-02-10 22:55:01 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:55:01 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:55:01 --> Utf8 Class Initialized
INFO - 2017-02-10 22:55:01 --> URI Class Initialized
DEBUG - 2017-02-10 22:55:01 --> No URI present. Default controller set.
INFO - 2017-02-10 22:55:01 --> Router Class Initialized
INFO - 2017-02-10 22:55:01 --> Output Class Initialized
INFO - 2017-02-10 22:55:01 --> Security Class Initialized
DEBUG - 2017-02-10 22:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:55:01 --> Input Class Initialized
INFO - 2017-02-10 22:55:01 --> Language Class Initialized
INFO - 2017-02-10 22:55:01 --> Loader Class Initialized
INFO - 2017-02-10 22:55:01 --> Database Driver Class Initialized
INFO - 2017-02-10 22:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:55:01 --> Controller Class Initialized
INFO - 2017-02-10 22:55:01 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 22:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 22:55:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:55:01 --> Final output sent to browser
DEBUG - 2017-02-10 22:55:01 --> Total execution time: 0.0436
INFO - 2017-02-10 22:55:06 --> Config Class Initialized
INFO - 2017-02-10 22:55:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:55:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:55:06 --> Utf8 Class Initialized
INFO - 2017-02-10 22:55:06 --> URI Class Initialized
INFO - 2017-02-10 22:55:06 --> Router Class Initialized
INFO - 2017-02-10 22:55:06 --> Output Class Initialized
INFO - 2017-02-10 22:55:06 --> Security Class Initialized
DEBUG - 2017-02-10 22:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:55:06 --> Input Class Initialized
INFO - 2017-02-10 22:55:06 --> Language Class Initialized
INFO - 2017-02-10 22:55:06 --> Loader Class Initialized
INFO - 2017-02-10 22:55:06 --> Database Driver Class Initialized
INFO - 2017-02-10 22:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:55:06 --> Controller Class Initialized
INFO - 2017-02-10 22:55:06 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:55:06 --> Final output sent to browser
DEBUG - 2017-02-10 22:55:06 --> Total execution time: 0.1926
INFO - 2017-02-10 22:55:10 --> Config Class Initialized
INFO - 2017-02-10 22:55:10 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:55:10 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:55:10 --> Utf8 Class Initialized
INFO - 2017-02-10 22:55:10 --> URI Class Initialized
INFO - 2017-02-10 22:55:10 --> Router Class Initialized
INFO - 2017-02-10 22:55:10 --> Output Class Initialized
INFO - 2017-02-10 22:55:10 --> Security Class Initialized
DEBUG - 2017-02-10 22:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:55:10 --> Input Class Initialized
INFO - 2017-02-10 22:55:10 --> Language Class Initialized
INFO - 2017-02-10 22:55:10 --> Loader Class Initialized
INFO - 2017-02-10 22:55:10 --> Database Driver Class Initialized
INFO - 2017-02-10 22:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:55:10 --> Controller Class Initialized
INFO - 2017-02-10 22:55:10 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:55:11 --> Config Class Initialized
INFO - 2017-02-10 22:55:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:55:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:55:11 --> Utf8 Class Initialized
INFO - 2017-02-10 22:55:11 --> URI Class Initialized
INFO - 2017-02-10 22:55:11 --> Router Class Initialized
INFO - 2017-02-10 22:55:11 --> Output Class Initialized
INFO - 2017-02-10 22:55:11 --> Security Class Initialized
DEBUG - 2017-02-10 22:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:55:11 --> Input Class Initialized
INFO - 2017-02-10 22:55:11 --> Language Class Initialized
INFO - 2017-02-10 22:55:11 --> Loader Class Initialized
INFO - 2017-02-10 22:55:11 --> Database Driver Class Initialized
INFO - 2017-02-10 22:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:55:11 --> Controller Class Initialized
INFO - 2017-02-10 22:55:11 --> Helper loaded: date_helper
DEBUG - 2017-02-10 22:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:55:11 --> Helper loaded: url_helper
INFO - 2017-02-10 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-10 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-10 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-10 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:55:11 --> Final output sent to browser
DEBUG - 2017-02-10 22:55:11 --> Total execution time: 0.0145
INFO - 2017-02-10 22:55:12 --> Config Class Initialized
INFO - 2017-02-10 22:55:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:55:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:55:12 --> Utf8 Class Initialized
INFO - 2017-02-10 22:55:12 --> URI Class Initialized
INFO - 2017-02-10 22:55:12 --> Router Class Initialized
INFO - 2017-02-10 22:55:12 --> Output Class Initialized
INFO - 2017-02-10 22:55:12 --> Security Class Initialized
DEBUG - 2017-02-10 22:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:55:12 --> Input Class Initialized
INFO - 2017-02-10 22:55:12 --> Language Class Initialized
INFO - 2017-02-10 22:55:12 --> Loader Class Initialized
INFO - 2017-02-10 22:55:12 --> Database Driver Class Initialized
INFO - 2017-02-10 22:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:55:12 --> Controller Class Initialized
INFO - 2017-02-10 22:55:12 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:55:12 --> Final output sent to browser
DEBUG - 2017-02-10 22:55:12 --> Total execution time: 0.0163
INFO - 2017-02-10 22:55:13 --> Config Class Initialized
INFO - 2017-02-10 22:55:13 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:55:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:55:13 --> Utf8 Class Initialized
INFO - 2017-02-10 22:55:13 --> URI Class Initialized
DEBUG - 2017-02-10 22:55:13 --> No URI present. Default controller set.
INFO - 2017-02-10 22:55:13 --> Router Class Initialized
INFO - 2017-02-10 22:55:13 --> Output Class Initialized
INFO - 2017-02-10 22:55:13 --> Security Class Initialized
DEBUG - 2017-02-10 22:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:55:13 --> Input Class Initialized
INFO - 2017-02-10 22:55:13 --> Language Class Initialized
INFO - 2017-02-10 22:55:13 --> Loader Class Initialized
INFO - 2017-02-10 22:55:13 --> Database Driver Class Initialized
INFO - 2017-02-10 22:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:55:13 --> Controller Class Initialized
INFO - 2017-02-10 22:55:13 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 22:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 22:55:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:55:13 --> Final output sent to browser
DEBUG - 2017-02-10 22:55:13 --> Total execution time: 0.0132
INFO - 2017-02-10 22:55:14 --> Config Class Initialized
INFO - 2017-02-10 22:55:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 22:55:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 22:55:14 --> Utf8 Class Initialized
INFO - 2017-02-10 22:55:14 --> URI Class Initialized
INFO - 2017-02-10 22:55:14 --> Router Class Initialized
INFO - 2017-02-10 22:55:14 --> Output Class Initialized
INFO - 2017-02-10 22:55:14 --> Security Class Initialized
DEBUG - 2017-02-10 22:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 22:55:14 --> Input Class Initialized
INFO - 2017-02-10 22:55:14 --> Language Class Initialized
INFO - 2017-02-10 22:55:14 --> Loader Class Initialized
INFO - 2017-02-10 22:55:14 --> Database Driver Class Initialized
INFO - 2017-02-10 22:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 22:55:14 --> Controller Class Initialized
INFO - 2017-02-10 22:55:14 --> Helper loaded: url_helper
DEBUG - 2017-02-10 22:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-10 22:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-10 22:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-10 22:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-10 22:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-10 22:55:14 --> Final output sent to browser
DEBUG - 2017-02-10 22:55:14 --> Total execution time: 0.0132

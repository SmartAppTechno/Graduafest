<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-15 00:39:05 --> Config Class Initialized
INFO - 2017-02-15 00:39:05 --> Hooks Class Initialized
DEBUG - 2017-02-15 00:39:05 --> UTF-8 Support Enabled
INFO - 2017-02-15 00:39:05 --> Utf8 Class Initialized
INFO - 2017-02-15 00:39:05 --> URI Class Initialized
DEBUG - 2017-02-15 00:39:05 --> No URI present. Default controller set.
INFO - 2017-02-15 00:39:05 --> Router Class Initialized
INFO - 2017-02-15 00:39:05 --> Output Class Initialized
INFO - 2017-02-15 00:39:05 --> Security Class Initialized
DEBUG - 2017-02-15 00:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 00:39:05 --> Input Class Initialized
INFO - 2017-02-15 00:39:05 --> Language Class Initialized
INFO - 2017-02-15 00:39:05 --> Loader Class Initialized
INFO - 2017-02-15 00:39:05 --> Database Driver Class Initialized
INFO - 2017-02-15 00:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 00:39:05 --> Controller Class Initialized
INFO - 2017-02-15 00:39:05 --> Helper loaded: url_helper
DEBUG - 2017-02-15 00:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 00:39:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 00:39:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 00:39:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 00:39:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 00:39:05 --> Final output sent to browser
DEBUG - 2017-02-15 00:39:05 --> Total execution time: 0.0565
INFO - 2017-02-15 00:39:10 --> Config Class Initialized
INFO - 2017-02-15 00:39:10 --> Hooks Class Initialized
DEBUG - 2017-02-15 00:39:10 --> UTF-8 Support Enabled
INFO - 2017-02-15 00:39:10 --> Utf8 Class Initialized
INFO - 2017-02-15 00:39:10 --> URI Class Initialized
INFO - 2017-02-15 00:39:10 --> Router Class Initialized
INFO - 2017-02-15 00:39:10 --> Output Class Initialized
INFO - 2017-02-15 00:39:10 --> Security Class Initialized
DEBUG - 2017-02-15 00:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 00:39:10 --> Input Class Initialized
INFO - 2017-02-15 00:39:10 --> Language Class Initialized
INFO - 2017-02-15 00:39:10 --> Loader Class Initialized
INFO - 2017-02-15 00:39:10 --> Database Driver Class Initialized
INFO - 2017-02-15 00:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 00:39:10 --> Controller Class Initialized
INFO - 2017-02-15 00:39:10 --> Helper loaded: url_helper
DEBUG - 2017-02-15 00:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 00:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 00:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 00:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 00:39:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 00:39:10 --> Final output sent to browser
DEBUG - 2017-02-15 00:39:10 --> Total execution time: 0.0140
INFO - 2017-02-15 00:39:14 --> Config Class Initialized
INFO - 2017-02-15 00:39:14 --> Hooks Class Initialized
DEBUG - 2017-02-15 00:39:14 --> UTF-8 Support Enabled
INFO - 2017-02-15 00:39:14 --> Utf8 Class Initialized
INFO - 2017-02-15 00:39:14 --> URI Class Initialized
INFO - 2017-02-15 00:39:14 --> Router Class Initialized
INFO - 2017-02-15 00:39:14 --> Output Class Initialized
INFO - 2017-02-15 00:39:14 --> Security Class Initialized
DEBUG - 2017-02-15 00:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 00:39:14 --> Input Class Initialized
INFO - 2017-02-15 00:39:14 --> Language Class Initialized
INFO - 2017-02-15 00:39:14 --> Loader Class Initialized
INFO - 2017-02-15 00:39:14 --> Database Driver Class Initialized
INFO - 2017-02-15 00:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 00:39:14 --> Controller Class Initialized
INFO - 2017-02-15 00:39:14 --> Helper loaded: url_helper
DEBUG - 2017-02-15 00:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 00:39:15 --> Config Class Initialized
INFO - 2017-02-15 00:39:15 --> Hooks Class Initialized
DEBUG - 2017-02-15 00:39:15 --> UTF-8 Support Enabled
INFO - 2017-02-15 00:39:15 --> Utf8 Class Initialized
INFO - 2017-02-15 00:39:15 --> URI Class Initialized
INFO - 2017-02-15 00:39:15 --> Router Class Initialized
INFO - 2017-02-15 00:39:15 --> Output Class Initialized
INFO - 2017-02-15 00:39:15 --> Security Class Initialized
DEBUG - 2017-02-15 00:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 00:39:15 --> Input Class Initialized
INFO - 2017-02-15 00:39:15 --> Language Class Initialized
INFO - 2017-02-15 00:39:15 --> Loader Class Initialized
INFO - 2017-02-15 00:39:15 --> Database Driver Class Initialized
INFO - 2017-02-15 00:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 00:39:15 --> Controller Class Initialized
INFO - 2017-02-15 00:39:15 --> Helper loaded: date_helper
DEBUG - 2017-02-15 00:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 00:39:15 --> Helper loaded: url_helper
INFO - 2017-02-15 00:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 00:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 00:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 00:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 00:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 00:39:15 --> Final output sent to browser
DEBUG - 2017-02-15 00:39:15 --> Total execution time: 0.2149
INFO - 2017-02-15 00:39:16 --> Config Class Initialized
INFO - 2017-02-15 00:39:16 --> Hooks Class Initialized
DEBUG - 2017-02-15 00:39:16 --> UTF-8 Support Enabled
INFO - 2017-02-15 00:39:16 --> Utf8 Class Initialized
INFO - 2017-02-15 00:39:16 --> URI Class Initialized
INFO - 2017-02-15 00:39:16 --> Router Class Initialized
INFO - 2017-02-15 00:39:16 --> Output Class Initialized
INFO - 2017-02-15 00:39:16 --> Security Class Initialized
DEBUG - 2017-02-15 00:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 00:39:16 --> Input Class Initialized
INFO - 2017-02-15 00:39:16 --> Language Class Initialized
INFO - 2017-02-15 00:39:16 --> Loader Class Initialized
INFO - 2017-02-15 00:39:16 --> Database Driver Class Initialized
INFO - 2017-02-15 00:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 00:39:16 --> Controller Class Initialized
INFO - 2017-02-15 00:39:16 --> Helper loaded: url_helper
DEBUG - 2017-02-15 00:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 00:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 00:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 00:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 00:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 00:39:16 --> Final output sent to browser
DEBUG - 2017-02-15 00:39:16 --> Total execution time: 0.0133
INFO - 2017-02-15 01:05:57 --> Config Class Initialized
INFO - 2017-02-15 01:05:57 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:05:57 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:05:57 --> Utf8 Class Initialized
INFO - 2017-02-15 01:05:57 --> URI Class Initialized
INFO - 2017-02-15 01:05:57 --> Router Class Initialized
INFO - 2017-02-15 01:05:57 --> Output Class Initialized
INFO - 2017-02-15 01:05:57 --> Security Class Initialized
DEBUG - 2017-02-15 01:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:05:57 --> Input Class Initialized
INFO - 2017-02-15 01:05:57 --> Language Class Initialized
INFO - 2017-02-15 01:05:57 --> Loader Class Initialized
INFO - 2017-02-15 01:05:57 --> Database Driver Class Initialized
INFO - 2017-02-15 01:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:05:57 --> Controller Class Initialized
INFO - 2017-02-15 01:05:57 --> Helper loaded: date_helper
DEBUG - 2017-02-15 01:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:05:57 --> Helper loaded: url_helper
INFO - 2017-02-15 01:05:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:05:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 01:05:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 01:05:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 01:05:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:05:57 --> Final output sent to browser
DEBUG - 2017-02-15 01:05:57 --> Total execution time: 0.0137
INFO - 2017-02-15 01:05:59 --> Config Class Initialized
INFO - 2017-02-15 01:05:59 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:05:59 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:05:59 --> Utf8 Class Initialized
INFO - 2017-02-15 01:05:59 --> URI Class Initialized
INFO - 2017-02-15 01:05:59 --> Router Class Initialized
INFO - 2017-02-15 01:05:59 --> Output Class Initialized
INFO - 2017-02-15 01:05:59 --> Security Class Initialized
DEBUG - 2017-02-15 01:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:05:59 --> Input Class Initialized
INFO - 2017-02-15 01:05:59 --> Language Class Initialized
INFO - 2017-02-15 01:05:59 --> Loader Class Initialized
INFO - 2017-02-15 01:05:59 --> Database Driver Class Initialized
INFO - 2017-02-15 01:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:05:59 --> Controller Class Initialized
INFO - 2017-02-15 01:05:59 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:05:59 --> Final output sent to browser
DEBUG - 2017-02-15 01:05:59 --> Total execution time: 0.0181
INFO - 2017-02-15 01:23:07 --> Config Class Initialized
INFO - 2017-02-15 01:23:07 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:23:07 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:23:07 --> Utf8 Class Initialized
INFO - 2017-02-15 01:23:07 --> URI Class Initialized
DEBUG - 2017-02-15 01:23:07 --> No URI present. Default controller set.
INFO - 2017-02-15 01:23:07 --> Router Class Initialized
INFO - 2017-02-15 01:23:07 --> Output Class Initialized
INFO - 2017-02-15 01:23:07 --> Security Class Initialized
DEBUG - 2017-02-15 01:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:23:07 --> Input Class Initialized
INFO - 2017-02-15 01:23:07 --> Language Class Initialized
INFO - 2017-02-15 01:23:07 --> Loader Class Initialized
INFO - 2017-02-15 01:23:07 --> Database Driver Class Initialized
INFO - 2017-02-15 01:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:23:07 --> Controller Class Initialized
INFO - 2017-02-15 01:23:07 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:23:07 --> Final output sent to browser
DEBUG - 2017-02-15 01:23:07 --> Total execution time: 0.0138
INFO - 2017-02-15 01:24:21 --> Config Class Initialized
INFO - 2017-02-15 01:24:21 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:24:21 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:24:21 --> Utf8 Class Initialized
INFO - 2017-02-15 01:24:21 --> URI Class Initialized
INFO - 2017-02-15 01:24:21 --> Router Class Initialized
INFO - 2017-02-15 01:24:21 --> Output Class Initialized
INFO - 2017-02-15 01:24:21 --> Security Class Initialized
DEBUG - 2017-02-15 01:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:24:21 --> Input Class Initialized
INFO - 2017-02-15 01:24:21 --> Language Class Initialized
INFO - 2017-02-15 01:24:21 --> Loader Class Initialized
INFO - 2017-02-15 01:24:21 --> Database Driver Class Initialized
INFO - 2017-02-15 01:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:24:21 --> Controller Class Initialized
INFO - 2017-02-15 01:24:21 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:24:21 --> Final output sent to browser
DEBUG - 2017-02-15 01:24:21 --> Total execution time: 0.0131
INFO - 2017-02-15 01:24:52 --> Config Class Initialized
INFO - 2017-02-15 01:24:52 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:24:52 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:24:52 --> Utf8 Class Initialized
INFO - 2017-02-15 01:24:52 --> URI Class Initialized
INFO - 2017-02-15 01:24:52 --> Router Class Initialized
INFO - 2017-02-15 01:24:52 --> Output Class Initialized
INFO - 2017-02-15 01:24:52 --> Security Class Initialized
DEBUG - 2017-02-15 01:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:24:52 --> Input Class Initialized
INFO - 2017-02-15 01:24:52 --> Language Class Initialized
INFO - 2017-02-15 01:24:52 --> Loader Class Initialized
INFO - 2017-02-15 01:24:52 --> Database Driver Class Initialized
INFO - 2017-02-15 01:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:24:52 --> Controller Class Initialized
INFO - 2017-02-15 01:24:52 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:24:52 --> Final output sent to browser
DEBUG - 2017-02-15 01:24:52 --> Total execution time: 0.0138
INFO - 2017-02-15 01:25:08 --> Config Class Initialized
INFO - 2017-02-15 01:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:25:08 --> Utf8 Class Initialized
INFO - 2017-02-15 01:25:08 --> URI Class Initialized
INFO - 2017-02-15 01:25:08 --> Router Class Initialized
INFO - 2017-02-15 01:25:08 --> Output Class Initialized
INFO - 2017-02-15 01:25:08 --> Security Class Initialized
DEBUG - 2017-02-15 01:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:25:08 --> Input Class Initialized
INFO - 2017-02-15 01:25:08 --> Language Class Initialized
INFO - 2017-02-15 01:25:08 --> Loader Class Initialized
INFO - 2017-02-15 01:25:08 --> Database Driver Class Initialized
INFO - 2017-02-15 01:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:25:08 --> Controller Class Initialized
INFO - 2017-02-15 01:25:08 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:25:08 --> Final output sent to browser
DEBUG - 2017-02-15 01:25:08 --> Total execution time: 0.0139
INFO - 2017-02-15 01:26:22 --> Config Class Initialized
INFO - 2017-02-15 01:26:22 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:26:22 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:26:22 --> Utf8 Class Initialized
INFO - 2017-02-15 01:26:22 --> URI Class Initialized
INFO - 2017-02-15 01:26:22 --> Router Class Initialized
INFO - 2017-02-15 01:26:22 --> Output Class Initialized
INFO - 2017-02-15 01:26:22 --> Security Class Initialized
DEBUG - 2017-02-15 01:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:26:22 --> Input Class Initialized
INFO - 2017-02-15 01:26:22 --> Language Class Initialized
INFO - 2017-02-15 01:26:22 --> Loader Class Initialized
INFO - 2017-02-15 01:26:22 --> Database Driver Class Initialized
INFO - 2017-02-15 01:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:26:22 --> Controller Class Initialized
INFO - 2017-02-15 01:26:22 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:26:23 --> Config Class Initialized
INFO - 2017-02-15 01:26:23 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:26:23 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:26:23 --> Utf8 Class Initialized
INFO - 2017-02-15 01:26:23 --> URI Class Initialized
INFO - 2017-02-15 01:26:23 --> Router Class Initialized
INFO - 2017-02-15 01:26:23 --> Output Class Initialized
INFO - 2017-02-15 01:26:23 --> Security Class Initialized
DEBUG - 2017-02-15 01:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:26:23 --> Input Class Initialized
INFO - 2017-02-15 01:26:23 --> Language Class Initialized
INFO - 2017-02-15 01:26:23 --> Loader Class Initialized
INFO - 2017-02-15 01:26:23 --> Database Driver Class Initialized
INFO - 2017-02-15 01:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:26:23 --> Controller Class Initialized
INFO - 2017-02-15 01:26:23 --> Helper loaded: date_helper
DEBUG - 2017-02-15 01:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:26:23 --> Helper loaded: url_helper
INFO - 2017-02-15 01:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 01:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 01:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 01:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:26:23 --> Final output sent to browser
DEBUG - 2017-02-15 01:26:23 --> Total execution time: 0.0137
INFO - 2017-02-15 01:26:24 --> Config Class Initialized
INFO - 2017-02-15 01:26:24 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:26:24 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:26:24 --> Utf8 Class Initialized
INFO - 2017-02-15 01:26:24 --> URI Class Initialized
INFO - 2017-02-15 01:26:24 --> Router Class Initialized
INFO - 2017-02-15 01:26:24 --> Output Class Initialized
INFO - 2017-02-15 01:26:24 --> Security Class Initialized
DEBUG - 2017-02-15 01:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:26:24 --> Input Class Initialized
INFO - 2017-02-15 01:26:24 --> Language Class Initialized
INFO - 2017-02-15 01:26:24 --> Loader Class Initialized
INFO - 2017-02-15 01:26:24 --> Database Driver Class Initialized
INFO - 2017-02-15 01:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:26:24 --> Controller Class Initialized
INFO - 2017-02-15 01:26:24 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 01:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:26:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:26:24 --> Final output sent to browser
DEBUG - 2017-02-15 01:26:24 --> Total execution time: 0.0247
INFO - 2017-02-15 01:53:09 --> Config Class Initialized
INFO - 2017-02-15 01:53:09 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:53:09 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:53:09 --> Utf8 Class Initialized
INFO - 2017-02-15 01:53:09 --> URI Class Initialized
INFO - 2017-02-15 01:53:09 --> Router Class Initialized
INFO - 2017-02-15 01:53:09 --> Output Class Initialized
INFO - 2017-02-15 01:53:09 --> Security Class Initialized
DEBUG - 2017-02-15 01:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:53:09 --> Input Class Initialized
INFO - 2017-02-15 01:53:09 --> Language Class Initialized
INFO - 2017-02-15 01:53:09 --> Loader Class Initialized
INFO - 2017-02-15 01:53:09 --> Database Driver Class Initialized
INFO - 2017-02-15 01:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:53:09 --> Controller Class Initialized
INFO - 2017-02-15 01:53:09 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:53:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-15 01:53:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-15 01:53:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-15 01:53:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-15 01:53:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:53:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:53:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:53:09 --> Final output sent to browser
DEBUG - 2017-02-15 01:53:09 --> Total execution time: 0.0142
INFO - 2017-02-15 01:54:55 --> Config Class Initialized
INFO - 2017-02-15 01:54:55 --> Hooks Class Initialized
DEBUG - 2017-02-15 01:54:55 --> UTF-8 Support Enabled
INFO - 2017-02-15 01:54:55 --> Utf8 Class Initialized
INFO - 2017-02-15 01:54:55 --> URI Class Initialized
INFO - 2017-02-15 01:54:55 --> Router Class Initialized
INFO - 2017-02-15 01:54:55 --> Output Class Initialized
INFO - 2017-02-15 01:54:55 --> Security Class Initialized
DEBUG - 2017-02-15 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 01:54:55 --> Input Class Initialized
INFO - 2017-02-15 01:54:55 --> Language Class Initialized
INFO - 2017-02-15 01:54:55 --> Loader Class Initialized
INFO - 2017-02-15 01:54:55 --> Database Driver Class Initialized
INFO - 2017-02-15 01:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 01:54:55 --> Controller Class Initialized
INFO - 2017-02-15 01:54:55 --> Helper loaded: url_helper
DEBUG - 2017-02-15 01:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-15 01:54:55 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-15 01:54:55 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-15 01:54:55 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-15 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 01:54:55 --> Final output sent to browser
DEBUG - 2017-02-15 01:54:55 --> Total execution time: 0.0140
INFO - 2017-02-15 02:40:31 --> Config Class Initialized
INFO - 2017-02-15 02:40:31 --> Hooks Class Initialized
DEBUG - 2017-02-15 02:40:31 --> UTF-8 Support Enabled
INFO - 2017-02-15 02:40:31 --> Utf8 Class Initialized
INFO - 2017-02-15 02:40:31 --> URI Class Initialized
INFO - 2017-02-15 02:40:31 --> Router Class Initialized
INFO - 2017-02-15 02:40:31 --> Output Class Initialized
INFO - 2017-02-15 02:40:31 --> Security Class Initialized
DEBUG - 2017-02-15 02:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 02:40:31 --> Input Class Initialized
INFO - 2017-02-15 02:40:31 --> Language Class Initialized
INFO - 2017-02-15 02:40:31 --> Loader Class Initialized
INFO - 2017-02-15 02:40:31 --> Database Driver Class Initialized
INFO - 2017-02-15 02:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 02:40:31 --> Controller Class Initialized
INFO - 2017-02-15 02:40:31 --> Helper loaded: date_helper
DEBUG - 2017-02-15 02:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 02:40:31 --> Helper loaded: url_helper
INFO - 2017-02-15 02:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 02:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 02:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 02:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 02:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 02:40:31 --> Final output sent to browser
DEBUG - 2017-02-15 02:40:31 --> Total execution time: 0.0147
INFO - 2017-02-15 02:40:38 --> Config Class Initialized
INFO - 2017-02-15 02:40:38 --> Hooks Class Initialized
DEBUG - 2017-02-15 02:40:38 --> UTF-8 Support Enabled
INFO - 2017-02-15 02:40:38 --> Utf8 Class Initialized
INFO - 2017-02-15 02:40:38 --> URI Class Initialized
INFO - 2017-02-15 02:40:38 --> Router Class Initialized
INFO - 2017-02-15 02:40:38 --> Output Class Initialized
INFO - 2017-02-15 02:40:38 --> Security Class Initialized
DEBUG - 2017-02-15 02:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 02:40:38 --> Input Class Initialized
INFO - 2017-02-15 02:40:38 --> Language Class Initialized
INFO - 2017-02-15 02:40:38 --> Loader Class Initialized
INFO - 2017-02-15 02:40:38 --> Database Driver Class Initialized
INFO - 2017-02-15 02:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 02:40:38 --> Controller Class Initialized
INFO - 2017-02-15 02:40:38 --> Helper loaded: url_helper
DEBUG - 2017-02-15 02:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 02:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 02:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 02:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 02:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 02:40:38 --> Final output sent to browser
DEBUG - 2017-02-15 02:40:38 --> Total execution time: 0.0132
INFO - 2017-02-15 05:05:47 --> Config Class Initialized
INFO - 2017-02-15 05:05:47 --> Hooks Class Initialized
DEBUG - 2017-02-15 05:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-15 05:05:47 --> Utf8 Class Initialized
INFO - 2017-02-15 05:05:47 --> URI Class Initialized
INFO - 2017-02-15 05:05:47 --> Router Class Initialized
INFO - 2017-02-15 05:05:47 --> Output Class Initialized
INFO - 2017-02-15 05:05:47 --> Security Class Initialized
DEBUG - 2017-02-15 05:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 05:05:47 --> Input Class Initialized
INFO - 2017-02-15 05:05:47 --> Language Class Initialized
INFO - 2017-02-15 05:05:47 --> Loader Class Initialized
INFO - 2017-02-15 05:05:47 --> Database Driver Class Initialized
INFO - 2017-02-15 05:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 05:05:47 --> Controller Class Initialized
INFO - 2017-02-15 05:05:47 --> Helper loaded: url_helper
DEBUG - 2017-02-15 05:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 05:05:47 --> Final output sent to browser
DEBUG - 2017-02-15 05:05:47 --> Total execution time: 0.0137
INFO - 2017-02-15 05:05:47 --> Config Class Initialized
INFO - 2017-02-15 05:05:47 --> Hooks Class Initialized
DEBUG - 2017-02-15 05:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-15 05:05:47 --> Utf8 Class Initialized
INFO - 2017-02-15 05:05:47 --> URI Class Initialized
DEBUG - 2017-02-15 05:05:47 --> No URI present. Default controller set.
INFO - 2017-02-15 05:05:47 --> Router Class Initialized
INFO - 2017-02-15 05:05:47 --> Output Class Initialized
INFO - 2017-02-15 05:05:47 --> Security Class Initialized
DEBUG - 2017-02-15 05:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 05:05:47 --> Input Class Initialized
INFO - 2017-02-15 05:05:47 --> Language Class Initialized
INFO - 2017-02-15 05:05:47 --> Loader Class Initialized
INFO - 2017-02-15 05:05:47 --> Database Driver Class Initialized
INFO - 2017-02-15 05:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 05:05:47 --> Controller Class Initialized
INFO - 2017-02-15 05:05:47 --> Helper loaded: url_helper
DEBUG - 2017-02-15 05:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 05:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 05:05:47 --> Final output sent to browser
DEBUG - 2017-02-15 05:05:47 --> Total execution time: 0.0134
INFO - 2017-02-15 05:05:48 --> Config Class Initialized
INFO - 2017-02-15 05:05:48 --> Hooks Class Initialized
DEBUG - 2017-02-15 05:05:48 --> UTF-8 Support Enabled
INFO - 2017-02-15 05:05:48 --> Utf8 Class Initialized
INFO - 2017-02-15 05:05:48 --> URI Class Initialized
INFO - 2017-02-15 05:05:48 --> Router Class Initialized
INFO - 2017-02-15 05:05:48 --> Output Class Initialized
INFO - 2017-02-15 05:05:48 --> Security Class Initialized
DEBUG - 2017-02-15 05:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 05:05:48 --> Input Class Initialized
INFO - 2017-02-15 05:05:48 --> Language Class Initialized
INFO - 2017-02-15 05:05:48 --> Loader Class Initialized
INFO - 2017-02-15 05:05:48 --> Database Driver Class Initialized
INFO - 2017-02-15 05:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 05:05:48 --> Controller Class Initialized
INFO - 2017-02-15 05:05:48 --> Helper loaded: url_helper
DEBUG - 2017-02-15 05:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 05:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 05:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 05:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 05:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 05:05:48 --> Final output sent to browser
DEBUG - 2017-02-15 05:05:48 --> Total execution time: 0.0135
INFO - 2017-02-15 05:09:35 --> Config Class Initialized
INFO - 2017-02-15 05:09:35 --> Hooks Class Initialized
DEBUG - 2017-02-15 05:09:35 --> UTF-8 Support Enabled
INFO - 2017-02-15 05:09:35 --> Utf8 Class Initialized
INFO - 2017-02-15 05:09:35 --> URI Class Initialized
DEBUG - 2017-02-15 05:09:35 --> No URI present. Default controller set.
INFO - 2017-02-15 05:09:35 --> Router Class Initialized
INFO - 2017-02-15 05:09:35 --> Output Class Initialized
INFO - 2017-02-15 05:09:35 --> Security Class Initialized
DEBUG - 2017-02-15 05:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 05:09:35 --> Input Class Initialized
INFO - 2017-02-15 05:09:35 --> Language Class Initialized
INFO - 2017-02-15 05:09:35 --> Loader Class Initialized
INFO - 2017-02-15 05:09:35 --> Database Driver Class Initialized
INFO - 2017-02-15 05:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 05:09:35 --> Controller Class Initialized
INFO - 2017-02-15 05:09:35 --> Helper loaded: url_helper
DEBUG - 2017-02-15 05:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 05:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 05:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 05:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 05:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 05:09:35 --> Final output sent to browser
DEBUG - 2017-02-15 05:09:35 --> Total execution time: 0.0144
INFO - 2017-02-15 10:23:14 --> Config Class Initialized
INFO - 2017-02-15 10:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-15 10:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-15 10:23:14 --> Utf8 Class Initialized
INFO - 2017-02-15 10:23:14 --> URI Class Initialized
INFO - 2017-02-15 10:23:14 --> Router Class Initialized
INFO - 2017-02-15 10:23:14 --> Output Class Initialized
INFO - 2017-02-15 10:23:14 --> Security Class Initialized
DEBUG - 2017-02-15 10:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 10:23:14 --> Input Class Initialized
INFO - 2017-02-15 10:23:14 --> Language Class Initialized
INFO - 2017-02-15 10:23:14 --> Loader Class Initialized
INFO - 2017-02-15 10:23:14 --> Database Driver Class Initialized
INFO - 2017-02-15 10:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 10:23:14 --> Controller Class Initialized
INFO - 2017-02-15 10:23:14 --> Helper loaded: url_helper
DEBUG - 2017-02-15 10:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 10:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 10:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 10:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 10:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 10:23:14 --> Final output sent to browser
DEBUG - 2017-02-15 10:23:14 --> Total execution time: 0.0485
INFO - 2017-02-15 15:39:13 --> Config Class Initialized
INFO - 2017-02-15 15:39:13 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:39:13 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:39:13 --> Utf8 Class Initialized
INFO - 2017-02-15 15:39:13 --> URI Class Initialized
DEBUG - 2017-02-15 15:39:13 --> No URI present. Default controller set.
INFO - 2017-02-15 15:39:13 --> Router Class Initialized
INFO - 2017-02-15 15:39:13 --> Output Class Initialized
INFO - 2017-02-15 15:39:13 --> Security Class Initialized
DEBUG - 2017-02-15 15:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:39:13 --> Input Class Initialized
INFO - 2017-02-15 15:39:13 --> Language Class Initialized
INFO - 2017-02-15 15:39:13 --> Loader Class Initialized
INFO - 2017-02-15 15:39:13 --> Database Driver Class Initialized
INFO - 2017-02-15 15:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:39:13 --> Controller Class Initialized
INFO - 2017-02-15 15:39:13 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:39:13 --> Final output sent to browser
DEBUG - 2017-02-15 15:39:13 --> Total execution time: 0.0146
INFO - 2017-02-15 15:41:01 --> Config Class Initialized
INFO - 2017-02-15 15:41:01 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:41:01 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:41:01 --> Utf8 Class Initialized
INFO - 2017-02-15 15:41:01 --> URI Class Initialized
INFO - 2017-02-15 15:41:01 --> Router Class Initialized
INFO - 2017-02-15 15:41:01 --> Output Class Initialized
INFO - 2017-02-15 15:41:01 --> Security Class Initialized
DEBUG - 2017-02-15 15:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:41:01 --> Input Class Initialized
INFO - 2017-02-15 15:41:01 --> Language Class Initialized
INFO - 2017-02-15 15:41:01 --> Loader Class Initialized
INFO - 2017-02-15 15:41:01 --> Database Driver Class Initialized
INFO - 2017-02-15 15:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:41:01 --> Controller Class Initialized
INFO - 2017-02-15 15:41:01 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:41:01 --> Final output sent to browser
DEBUG - 2017-02-15 15:41:01 --> Total execution time: 0.0272
INFO - 2017-02-15 15:41:03 --> Config Class Initialized
INFO - 2017-02-15 15:41:03 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:41:03 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:41:03 --> Utf8 Class Initialized
INFO - 2017-02-15 15:41:03 --> URI Class Initialized
INFO - 2017-02-15 15:41:03 --> Router Class Initialized
INFO - 2017-02-15 15:41:03 --> Output Class Initialized
INFO - 2017-02-15 15:41:03 --> Security Class Initialized
DEBUG - 2017-02-15 15:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:41:03 --> Input Class Initialized
INFO - 2017-02-15 15:41:03 --> Language Class Initialized
INFO - 2017-02-15 15:41:03 --> Loader Class Initialized
INFO - 2017-02-15 15:41:03 --> Database Driver Class Initialized
INFO - 2017-02-15 15:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:41:03 --> Controller Class Initialized
INFO - 2017-02-15 15:41:03 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:41:03 --> Final output sent to browser
DEBUG - 2017-02-15 15:41:03 --> Total execution time: 0.0146
INFO - 2017-02-15 15:41:49 --> Config Class Initialized
INFO - 2017-02-15 15:41:49 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:41:49 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:41:49 --> Utf8 Class Initialized
INFO - 2017-02-15 15:41:49 --> URI Class Initialized
INFO - 2017-02-15 15:41:49 --> Router Class Initialized
INFO - 2017-02-15 15:41:49 --> Output Class Initialized
INFO - 2017-02-15 15:41:49 --> Security Class Initialized
DEBUG - 2017-02-15 15:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:41:49 --> Input Class Initialized
INFO - 2017-02-15 15:41:49 --> Language Class Initialized
INFO - 2017-02-15 15:41:49 --> Loader Class Initialized
INFO - 2017-02-15 15:41:49 --> Database Driver Class Initialized
INFO - 2017-02-15 15:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:41:49 --> Controller Class Initialized
INFO - 2017-02-15 15:41:49 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:41:49 --> Final output sent to browser
DEBUG - 2017-02-15 15:41:49 --> Total execution time: 0.0156
INFO - 2017-02-15 15:41:59 --> Config Class Initialized
INFO - 2017-02-15 15:41:59 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:41:59 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:41:59 --> Utf8 Class Initialized
INFO - 2017-02-15 15:41:59 --> URI Class Initialized
INFO - 2017-02-15 15:41:59 --> Router Class Initialized
INFO - 2017-02-15 15:41:59 --> Output Class Initialized
INFO - 2017-02-15 15:41:59 --> Security Class Initialized
DEBUG - 2017-02-15 15:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:41:59 --> Input Class Initialized
INFO - 2017-02-15 15:41:59 --> Language Class Initialized
INFO - 2017-02-15 15:41:59 --> Loader Class Initialized
INFO - 2017-02-15 15:41:59 --> Database Driver Class Initialized
INFO - 2017-02-15 15:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:41:59 --> Controller Class Initialized
INFO - 2017-02-15 15:41:59 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:41:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:41:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:41:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:41:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:41:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:41:59 --> Final output sent to browser
DEBUG - 2017-02-15 15:41:59 --> Total execution time: 0.0145
INFO - 2017-02-15 15:42:27 --> Config Class Initialized
INFO - 2017-02-15 15:42:27 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:42:27 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:42:27 --> Utf8 Class Initialized
INFO - 2017-02-15 15:42:27 --> URI Class Initialized
INFO - 2017-02-15 15:42:27 --> Router Class Initialized
INFO - 2017-02-15 15:42:27 --> Output Class Initialized
INFO - 2017-02-15 15:42:27 --> Security Class Initialized
DEBUG - 2017-02-15 15:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:42:27 --> Input Class Initialized
INFO - 2017-02-15 15:42:27 --> Language Class Initialized
INFO - 2017-02-15 15:42:27 --> Loader Class Initialized
INFO - 2017-02-15 15:42:27 --> Database Driver Class Initialized
INFO - 2017-02-15 15:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:42:27 --> Controller Class Initialized
INFO - 2017-02-15 15:42:27 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:42:27 --> Final output sent to browser
DEBUG - 2017-02-15 15:42:27 --> Total execution time: 0.0537
INFO - 2017-02-15 15:48:54 --> Config Class Initialized
INFO - 2017-02-15 15:48:54 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:48:54 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:48:54 --> Utf8 Class Initialized
INFO - 2017-02-15 15:48:54 --> URI Class Initialized
DEBUG - 2017-02-15 15:48:54 --> No URI present. Default controller set.
INFO - 2017-02-15 15:48:54 --> Router Class Initialized
INFO - 2017-02-15 15:48:54 --> Output Class Initialized
INFO - 2017-02-15 15:48:54 --> Security Class Initialized
DEBUG - 2017-02-15 15:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:48:54 --> Input Class Initialized
INFO - 2017-02-15 15:48:54 --> Language Class Initialized
INFO - 2017-02-15 15:48:54 --> Loader Class Initialized
INFO - 2017-02-15 15:48:54 --> Database Driver Class Initialized
INFO - 2017-02-15 15:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:48:54 --> Controller Class Initialized
INFO - 2017-02-15 15:48:54 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:48:54 --> Final output sent to browser
DEBUG - 2017-02-15 15:48:54 --> Total execution time: 0.0140
INFO - 2017-02-15 15:49:44 --> Config Class Initialized
INFO - 2017-02-15 15:49:44 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:49:44 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:49:44 --> Utf8 Class Initialized
INFO - 2017-02-15 15:49:44 --> URI Class Initialized
DEBUG - 2017-02-15 15:49:44 --> No URI present. Default controller set.
INFO - 2017-02-15 15:49:44 --> Router Class Initialized
INFO - 2017-02-15 15:49:44 --> Output Class Initialized
INFO - 2017-02-15 15:49:44 --> Security Class Initialized
DEBUG - 2017-02-15 15:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:49:44 --> Input Class Initialized
INFO - 2017-02-15 15:49:44 --> Language Class Initialized
INFO - 2017-02-15 15:49:44 --> Loader Class Initialized
INFO - 2017-02-15 15:49:44 --> Database Driver Class Initialized
INFO - 2017-02-15 15:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:49:44 --> Controller Class Initialized
INFO - 2017-02-15 15:49:44 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:49:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:49:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:49:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:49:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:49:44 --> Final output sent to browser
DEBUG - 2017-02-15 15:49:44 --> Total execution time: 0.0139
INFO - 2017-02-15 15:50:48 --> Config Class Initialized
INFO - 2017-02-15 15:50:48 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:50:48 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:50:48 --> Utf8 Class Initialized
INFO - 2017-02-15 15:50:48 --> URI Class Initialized
INFO - 2017-02-15 15:50:48 --> Router Class Initialized
INFO - 2017-02-15 15:50:48 --> Output Class Initialized
INFO - 2017-02-15 15:50:48 --> Security Class Initialized
DEBUG - 2017-02-15 15:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:50:48 --> Input Class Initialized
INFO - 2017-02-15 15:50:48 --> Language Class Initialized
INFO - 2017-02-15 15:50:48 --> Loader Class Initialized
INFO - 2017-02-15 15:50:48 --> Database Driver Class Initialized
INFO - 2017-02-15 15:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:50:48 --> Controller Class Initialized
INFO - 2017-02-15 15:50:48 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-15 15:50:48 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-15 15:50:48 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-15 15:50:48 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-15 15:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:50:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:50:48 --> Final output sent to browser
DEBUG - 2017-02-15 15:50:48 --> Total execution time: 0.0140
INFO - 2017-02-15 15:51:04 --> Config Class Initialized
INFO - 2017-02-15 15:51:04 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:51:04 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:51:04 --> Utf8 Class Initialized
INFO - 2017-02-15 15:51:04 --> URI Class Initialized
INFO - 2017-02-15 15:51:04 --> Router Class Initialized
INFO - 2017-02-15 15:51:04 --> Output Class Initialized
INFO - 2017-02-15 15:51:04 --> Security Class Initialized
DEBUG - 2017-02-15 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:51:04 --> Input Class Initialized
INFO - 2017-02-15 15:51:04 --> Language Class Initialized
INFO - 2017-02-15 15:51:04 --> Loader Class Initialized
INFO - 2017-02-15 15:51:04 --> Database Driver Class Initialized
INFO - 2017-02-15 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:51:04 --> Controller Class Initialized
INFO - 2017-02-15 15:51:04 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:51:04 --> Final output sent to browser
DEBUG - 2017-02-15 15:51:04 --> Total execution time: 0.0136
INFO - 2017-02-15 15:51:55 --> Config Class Initialized
INFO - 2017-02-15 15:51:55 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:51:55 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:51:55 --> Utf8 Class Initialized
INFO - 2017-02-15 15:51:55 --> URI Class Initialized
INFO - 2017-02-15 15:51:55 --> Router Class Initialized
INFO - 2017-02-15 15:51:55 --> Output Class Initialized
INFO - 2017-02-15 15:51:55 --> Security Class Initialized
DEBUG - 2017-02-15 15:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:51:55 --> Input Class Initialized
INFO - 2017-02-15 15:51:55 --> Language Class Initialized
INFO - 2017-02-15 15:51:55 --> Loader Class Initialized
INFO - 2017-02-15 15:51:55 --> Database Driver Class Initialized
INFO - 2017-02-15 15:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:51:55 --> Controller Class Initialized
INFO - 2017-02-15 15:51:55 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-15 15:51:55 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-15 15:51:55 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-15 15:51:55 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-15 15:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:51:55 --> Final output sent to browser
DEBUG - 2017-02-15 15:51:55 --> Total execution time: 0.0351
INFO - 2017-02-15 15:52:13 --> Config Class Initialized
INFO - 2017-02-15 15:52:13 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:52:13 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:52:13 --> Utf8 Class Initialized
INFO - 2017-02-15 15:52:13 --> URI Class Initialized
DEBUG - 2017-02-15 15:52:13 --> No URI present. Default controller set.
INFO - 2017-02-15 15:52:13 --> Router Class Initialized
INFO - 2017-02-15 15:52:13 --> Output Class Initialized
INFO - 2017-02-15 15:52:13 --> Security Class Initialized
DEBUG - 2017-02-15 15:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:52:13 --> Input Class Initialized
INFO - 2017-02-15 15:52:13 --> Language Class Initialized
INFO - 2017-02-15 15:52:13 --> Loader Class Initialized
INFO - 2017-02-15 15:52:13 --> Database Driver Class Initialized
INFO - 2017-02-15 15:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:52:13 --> Controller Class Initialized
INFO - 2017-02-15 15:52:13 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:52:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:52:13 --> Final output sent to browser
DEBUG - 2017-02-15 15:52:13 --> Total execution time: 0.0136
INFO - 2017-02-15 15:53:31 --> Config Class Initialized
INFO - 2017-02-15 15:53:31 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:53:31 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:53:31 --> Utf8 Class Initialized
INFO - 2017-02-15 15:53:31 --> URI Class Initialized
DEBUG - 2017-02-15 15:53:31 --> No URI present. Default controller set.
INFO - 2017-02-15 15:53:31 --> Router Class Initialized
INFO - 2017-02-15 15:53:31 --> Output Class Initialized
INFO - 2017-02-15 15:53:31 --> Security Class Initialized
DEBUG - 2017-02-15 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:53:31 --> Input Class Initialized
INFO - 2017-02-15 15:53:31 --> Language Class Initialized
INFO - 2017-02-15 15:53:31 --> Loader Class Initialized
INFO - 2017-02-15 15:53:31 --> Database Driver Class Initialized
INFO - 2017-02-15 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:53:31 --> Controller Class Initialized
INFO - 2017-02-15 15:53:31 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:53:31 --> Final output sent to browser
DEBUG - 2017-02-15 15:53:31 --> Total execution time: 0.0260
INFO - 2017-02-15 15:53:32 --> Config Class Initialized
INFO - 2017-02-15 15:53:32 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:53:32 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:53:32 --> Utf8 Class Initialized
INFO - 2017-02-15 15:53:32 --> URI Class Initialized
DEBUG - 2017-02-15 15:53:32 --> No URI present. Default controller set.
INFO - 2017-02-15 15:53:32 --> Router Class Initialized
INFO - 2017-02-15 15:53:32 --> Output Class Initialized
INFO - 2017-02-15 15:53:32 --> Security Class Initialized
DEBUG - 2017-02-15 15:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:53:32 --> Input Class Initialized
INFO - 2017-02-15 15:53:32 --> Language Class Initialized
INFO - 2017-02-15 15:53:32 --> Loader Class Initialized
INFO - 2017-02-15 15:53:32 --> Database Driver Class Initialized
INFO - 2017-02-15 15:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:53:32 --> Controller Class Initialized
INFO - 2017-02-15 15:53:32 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:53:32 --> Final output sent to browser
DEBUG - 2017-02-15 15:53:32 --> Total execution time: 0.0141
INFO - 2017-02-15 15:54:34 --> Config Class Initialized
INFO - 2017-02-15 15:54:34 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:34 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:34 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:34 --> URI Class Initialized
INFO - 2017-02-15 15:54:34 --> Router Class Initialized
INFO - 2017-02-15 15:54:34 --> Output Class Initialized
INFO - 2017-02-15 15:54:34 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:34 --> Input Class Initialized
INFO - 2017-02-15 15:54:34 --> Language Class Initialized
INFO - 2017-02-15 15:54:34 --> Loader Class Initialized
INFO - 2017-02-15 15:54:34 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:34 --> Controller Class Initialized
INFO - 2017-02-15 15:54:34 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:54:34 --> Final output sent to browser
DEBUG - 2017-02-15 15:54:34 --> Total execution time: 0.0140
INFO - 2017-02-15 15:54:40 --> Config Class Initialized
INFO - 2017-02-15 15:54:40 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:40 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:40 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:40 --> URI Class Initialized
INFO - 2017-02-15 15:54:40 --> Router Class Initialized
INFO - 2017-02-15 15:54:40 --> Output Class Initialized
INFO - 2017-02-15 15:54:40 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:40 --> Input Class Initialized
INFO - 2017-02-15 15:54:40 --> Language Class Initialized
INFO - 2017-02-15 15:54:40 --> Loader Class Initialized
INFO - 2017-02-15 15:54:40 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:40 --> Controller Class Initialized
INFO - 2017-02-15 15:54:40 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-15 15:54:40 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-15 15:54:40 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Gaby Robles')
INFO - 2017-02-15 15:54:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-15 15:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-15 15:54:41 --> Config Class Initialized
INFO - 2017-02-15 15:54:41 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:41 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:41 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:41 --> URI Class Initialized
INFO - 2017-02-15 15:54:41 --> Router Class Initialized
INFO - 2017-02-15 15:54:41 --> Output Class Initialized
INFO - 2017-02-15 15:54:41 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:41 --> Input Class Initialized
INFO - 2017-02-15 15:54:41 --> Language Class Initialized
INFO - 2017-02-15 15:54:41 --> Loader Class Initialized
INFO - 2017-02-15 15:54:41 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:41 --> Controller Class Initialized
INFO - 2017-02-15 15:54:41 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:54:41 --> Final output sent to browser
DEBUG - 2017-02-15 15:54:41 --> Total execution time: 0.0139
INFO - 2017-02-15 15:54:43 --> Config Class Initialized
INFO - 2017-02-15 15:54:43 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:43 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:43 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:43 --> URI Class Initialized
INFO - 2017-02-15 15:54:43 --> Router Class Initialized
INFO - 2017-02-15 15:54:43 --> Output Class Initialized
INFO - 2017-02-15 15:54:43 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:43 --> Input Class Initialized
INFO - 2017-02-15 15:54:43 --> Language Class Initialized
INFO - 2017-02-15 15:54:43 --> Loader Class Initialized
INFO - 2017-02-15 15:54:43 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:43 --> Controller Class Initialized
INFO - 2017-02-15 15:54:43 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-15 15:54:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-15 15:54:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-15 15:54:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-15 15:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:54:43 --> Final output sent to browser
DEBUG - 2017-02-15 15:54:43 --> Total execution time: 0.0143
INFO - 2017-02-15 15:54:44 --> Config Class Initialized
INFO - 2017-02-15 15:54:44 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:44 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:44 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:44 --> URI Class Initialized
INFO - 2017-02-15 15:54:44 --> Router Class Initialized
INFO - 2017-02-15 15:54:44 --> Output Class Initialized
INFO - 2017-02-15 15:54:44 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:44 --> Input Class Initialized
INFO - 2017-02-15 15:54:44 --> Language Class Initialized
INFO - 2017-02-15 15:54:44 --> Loader Class Initialized
INFO - 2017-02-15 15:54:44 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:45 --> Controller Class Initialized
INFO - 2017-02-15 15:54:45 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-15 15:54:45 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-15 15:54:45 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Gaby Robles')
INFO - 2017-02-15 15:54:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-15 15:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-15 15:54:45 --> Config Class Initialized
INFO - 2017-02-15 15:54:45 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:45 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:45 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:45 --> URI Class Initialized
INFO - 2017-02-15 15:54:45 --> Router Class Initialized
INFO - 2017-02-15 15:54:45 --> Output Class Initialized
INFO - 2017-02-15 15:54:45 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:45 --> Input Class Initialized
INFO - 2017-02-15 15:54:45 --> Language Class Initialized
INFO - 2017-02-15 15:54:45 --> Loader Class Initialized
INFO - 2017-02-15 15:54:45 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:45 --> Controller Class Initialized
INFO - 2017-02-15 15:54:45 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:54:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:54:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:54:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:54:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:54:45 --> Final output sent to browser
DEBUG - 2017-02-15 15:54:45 --> Total execution time: 0.0142
INFO - 2017-02-15 15:54:53 --> Config Class Initialized
INFO - 2017-02-15 15:54:53 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:53 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:53 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:53 --> URI Class Initialized
DEBUG - 2017-02-15 15:54:53 --> No URI present. Default controller set.
INFO - 2017-02-15 15:54:53 --> Router Class Initialized
INFO - 2017-02-15 15:54:53 --> Output Class Initialized
INFO - 2017-02-15 15:54:53 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:53 --> Input Class Initialized
INFO - 2017-02-15 15:54:53 --> Language Class Initialized
INFO - 2017-02-15 15:54:53 --> Loader Class Initialized
INFO - 2017-02-15 15:54:53 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:53 --> Controller Class Initialized
INFO - 2017-02-15 15:54:53 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:54:53 --> Config Class Initialized
INFO - 2017-02-15 15:54:53 --> Hooks Class Initialized
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:54:53 --> Final output sent to browser
DEBUG - 2017-02-15 15:54:53 --> Total execution time: 0.0145
DEBUG - 2017-02-15 15:54:53 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:53 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:53 --> URI Class Initialized
DEBUG - 2017-02-15 15:54:53 --> No URI present. Default controller set.
INFO - 2017-02-15 15:54:53 --> Router Class Initialized
INFO - 2017-02-15 15:54:53 --> Output Class Initialized
INFO - 2017-02-15 15:54:53 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:53 --> Input Class Initialized
INFO - 2017-02-15 15:54:53 --> Language Class Initialized
INFO - 2017-02-15 15:54:53 --> Loader Class Initialized
INFO - 2017-02-15 15:54:53 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:53 --> Controller Class Initialized
INFO - 2017-02-15 15:54:53 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:54:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:54:53 --> Final output sent to browser
DEBUG - 2017-02-15 15:54:53 --> Total execution time: 0.0858
INFO - 2017-02-15 15:54:57 --> Config Class Initialized
INFO - 2017-02-15 15:54:57 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:54:57 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:54:57 --> Utf8 Class Initialized
INFO - 2017-02-15 15:54:57 --> URI Class Initialized
INFO - 2017-02-15 15:54:57 --> Router Class Initialized
INFO - 2017-02-15 15:54:57 --> Output Class Initialized
INFO - 2017-02-15 15:54:57 --> Security Class Initialized
DEBUG - 2017-02-15 15:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:54:57 --> Input Class Initialized
INFO - 2017-02-15 15:54:57 --> Language Class Initialized
INFO - 2017-02-15 15:54:57 --> Loader Class Initialized
INFO - 2017-02-15 15:54:57 --> Database Driver Class Initialized
INFO - 2017-02-15 15:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:54:57 --> Controller Class Initialized
INFO - 2017-02-15 15:54:57 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:54:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:54:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:54:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:54:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:54:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:54:57 --> Final output sent to browser
DEBUG - 2017-02-15 15:54:57 --> Total execution time: 0.0141
INFO - 2017-02-15 15:55:04 --> Config Class Initialized
INFO - 2017-02-15 15:55:04 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:55:04 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:55:04 --> Utf8 Class Initialized
INFO - 2017-02-15 15:55:04 --> URI Class Initialized
INFO - 2017-02-15 15:55:04 --> Router Class Initialized
INFO - 2017-02-15 15:55:04 --> Output Class Initialized
INFO - 2017-02-15 15:55:04 --> Security Class Initialized
DEBUG - 2017-02-15 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:55:04 --> Input Class Initialized
INFO - 2017-02-15 15:55:04 --> Language Class Initialized
INFO - 2017-02-15 15:55:04 --> Loader Class Initialized
INFO - 2017-02-15 15:55:04 --> Database Driver Class Initialized
INFO - 2017-02-15 15:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:55:04 --> Controller Class Initialized
INFO - 2017-02-15 15:55:04 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:55:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-15 15:55:05 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-15 15:55:05 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Gaby Robles')
INFO - 2017-02-15 15:55:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-15 15:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-15 15:55:05 --> Config Class Initialized
INFO - 2017-02-15 15:55:05 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:55:05 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:55:05 --> Utf8 Class Initialized
INFO - 2017-02-15 15:55:05 --> URI Class Initialized
INFO - 2017-02-15 15:55:05 --> Router Class Initialized
INFO - 2017-02-15 15:55:05 --> Output Class Initialized
INFO - 2017-02-15 15:55:05 --> Security Class Initialized
DEBUG - 2017-02-15 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:55:05 --> Input Class Initialized
INFO - 2017-02-15 15:55:05 --> Language Class Initialized
INFO - 2017-02-15 15:55:05 --> Loader Class Initialized
INFO - 2017-02-15 15:55:05 --> Database Driver Class Initialized
INFO - 2017-02-15 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:55:05 --> Controller Class Initialized
INFO - 2017-02-15 15:55:05 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:55:06 --> Final output sent to browser
DEBUG - 2017-02-15 15:55:06 --> Total execution time: 0.0520
INFO - 2017-02-15 15:55:08 --> Config Class Initialized
INFO - 2017-02-15 15:55:08 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:55:08 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:55:08 --> Utf8 Class Initialized
INFO - 2017-02-15 15:55:08 --> URI Class Initialized
DEBUG - 2017-02-15 15:55:08 --> No URI present. Default controller set.
INFO - 2017-02-15 15:55:08 --> Router Class Initialized
INFO - 2017-02-15 15:55:08 --> Output Class Initialized
INFO - 2017-02-15 15:55:08 --> Security Class Initialized
DEBUG - 2017-02-15 15:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:55:08 --> Input Class Initialized
INFO - 2017-02-15 15:55:08 --> Language Class Initialized
INFO - 2017-02-15 15:55:08 --> Loader Class Initialized
INFO - 2017-02-15 15:55:08 --> Database Driver Class Initialized
INFO - 2017-02-15 15:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:55:08 --> Controller Class Initialized
INFO - 2017-02-15 15:55:08 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:55:08 --> Config Class Initialized
INFO - 2017-02-15 15:55:08 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:55:08 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:55:08 --> Utf8 Class Initialized
INFO - 2017-02-15 15:55:08 --> URI Class Initialized
DEBUG - 2017-02-15 15:55:08 --> No URI present. Default controller set.
INFO - 2017-02-15 15:55:08 --> Router Class Initialized
INFO - 2017-02-15 15:55:08 --> Output Class Initialized
INFO - 2017-02-15 15:55:08 --> Final output sent to browser
DEBUG - 2017-02-15 15:55:08 --> Total execution time: 0.0981
INFO - 2017-02-15 15:55:08 --> Security Class Initialized
DEBUG - 2017-02-15 15:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:55:08 --> Input Class Initialized
INFO - 2017-02-15 15:55:08 --> Language Class Initialized
INFO - 2017-02-15 15:55:08 --> Loader Class Initialized
INFO - 2017-02-15 15:55:08 --> Database Driver Class Initialized
INFO - 2017-02-15 15:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:55:08 --> Controller Class Initialized
INFO - 2017-02-15 15:55:08 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:55:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:55:08 --> Final output sent to browser
DEBUG - 2017-02-15 15:55:08 --> Total execution time: 0.0326
INFO - 2017-02-15 15:55:10 --> Config Class Initialized
INFO - 2017-02-15 15:55:10 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:55:10 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:55:10 --> Utf8 Class Initialized
INFO - 2017-02-15 15:55:10 --> URI Class Initialized
INFO - 2017-02-15 15:55:10 --> Router Class Initialized
INFO - 2017-02-15 15:55:10 --> Output Class Initialized
INFO - 2017-02-15 15:55:10 --> Security Class Initialized
DEBUG - 2017-02-15 15:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:55:10 --> Input Class Initialized
INFO - 2017-02-15 15:55:10 --> Language Class Initialized
INFO - 2017-02-15 15:55:10 --> Loader Class Initialized
INFO - 2017-02-15 15:55:10 --> Database Driver Class Initialized
INFO - 2017-02-15 15:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:55:10 --> Controller Class Initialized
INFO - 2017-02-15 15:55:10 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:55:10 --> Final output sent to browser
DEBUG - 2017-02-15 15:55:10 --> Total execution time: 0.0142
INFO - 2017-02-15 15:56:22 --> Config Class Initialized
INFO - 2017-02-15 15:56:22 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:56:22 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:56:22 --> Utf8 Class Initialized
INFO - 2017-02-15 15:56:22 --> URI Class Initialized
INFO - 2017-02-15 15:56:22 --> Router Class Initialized
INFO - 2017-02-15 15:56:22 --> Output Class Initialized
INFO - 2017-02-15 15:56:22 --> Security Class Initialized
DEBUG - 2017-02-15 15:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:56:22 --> Input Class Initialized
INFO - 2017-02-15 15:56:22 --> Language Class Initialized
INFO - 2017-02-15 15:56:22 --> Loader Class Initialized
INFO - 2017-02-15 15:56:22 --> Database Driver Class Initialized
INFO - 2017-02-15 15:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:56:22 --> Controller Class Initialized
INFO - 2017-02-15 15:56:22 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:56:22 --> Final output sent to browser
DEBUG - 2017-02-15 15:56:22 --> Total execution time: 0.0149
INFO - 2017-02-15 15:56:25 --> Config Class Initialized
INFO - 2017-02-15 15:56:25 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:56:25 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:56:25 --> Utf8 Class Initialized
INFO - 2017-02-15 15:56:25 --> URI Class Initialized
INFO - 2017-02-15 15:56:25 --> Router Class Initialized
INFO - 2017-02-15 15:56:25 --> Output Class Initialized
INFO - 2017-02-15 15:56:25 --> Security Class Initialized
DEBUG - 2017-02-15 15:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:56:25 --> Input Class Initialized
INFO - 2017-02-15 15:56:25 --> Language Class Initialized
INFO - 2017-02-15 15:56:25 --> Loader Class Initialized
INFO - 2017-02-15 15:56:25 --> Database Driver Class Initialized
INFO - 2017-02-15 15:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:56:25 --> Controller Class Initialized
INFO - 2017-02-15 15:56:25 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:56:25 --> Final output sent to browser
DEBUG - 2017-02-15 15:56:25 --> Total execution time: 0.0150
INFO - 2017-02-15 15:57:01 --> Config Class Initialized
INFO - 2017-02-15 15:57:01 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:01 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:01 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:01 --> URI Class Initialized
INFO - 2017-02-15 15:57:01 --> Router Class Initialized
INFO - 2017-02-15 15:57:01 --> Output Class Initialized
INFO - 2017-02-15 15:57:01 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:01 --> Input Class Initialized
INFO - 2017-02-15 15:57:01 --> Language Class Initialized
INFO - 2017-02-15 15:57:01 --> Loader Class Initialized
INFO - 2017-02-15 15:57:01 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:01 --> Controller Class Initialized
INFO - 2017-02-15 15:57:01 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:01 --> Config Class Initialized
INFO - 2017-02-15 15:57:01 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:01 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:01 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:02 --> URI Class Initialized
INFO - 2017-02-15 15:57:02 --> Router Class Initialized
INFO - 2017-02-15 15:57:02 --> Output Class Initialized
INFO - 2017-02-15 15:57:02 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:02 --> Input Class Initialized
INFO - 2017-02-15 15:57:02 --> Language Class Initialized
INFO - 2017-02-15 15:57:02 --> Loader Class Initialized
INFO - 2017-02-15 15:57:02 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:02 --> Controller Class Initialized
INFO - 2017-02-15 15:57:02 --> Helper loaded: date_helper
DEBUG - 2017-02-15 15:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:02 --> Helper loaded: url_helper
INFO - 2017-02-15 15:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 15:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 15:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 15:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:57:02 --> Final output sent to browser
DEBUG - 2017-02-15 15:57:02 --> Total execution time: 0.0850
INFO - 2017-02-15 15:57:03 --> Config Class Initialized
INFO - 2017-02-15 15:57:03 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:03 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:03 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:03 --> URI Class Initialized
INFO - 2017-02-15 15:57:03 --> Router Class Initialized
INFO - 2017-02-15 15:57:03 --> Output Class Initialized
INFO - 2017-02-15 15:57:03 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:03 --> Input Class Initialized
INFO - 2017-02-15 15:57:03 --> Language Class Initialized
INFO - 2017-02-15 15:57:03 --> Loader Class Initialized
INFO - 2017-02-15 15:57:03 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:03 --> Controller Class Initialized
INFO - 2017-02-15 15:57:03 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:57:03 --> Final output sent to browser
DEBUG - 2017-02-15 15:57:03 --> Total execution time: 0.0147
INFO - 2017-02-15 15:57:13 --> Config Class Initialized
INFO - 2017-02-15 15:57:13 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:13 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:13 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:13 --> URI Class Initialized
INFO - 2017-02-15 15:57:13 --> Router Class Initialized
INFO - 2017-02-15 15:57:13 --> Output Class Initialized
INFO - 2017-02-15 15:57:13 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:13 --> Input Class Initialized
INFO - 2017-02-15 15:57:13 --> Language Class Initialized
INFO - 2017-02-15 15:57:13 --> Loader Class Initialized
INFO - 2017-02-15 15:57:13 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:13 --> Controller Class Initialized
INFO - 2017-02-15 15:57:13 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-15 15:57:13 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`, `contraseña`) VALUES (NULL, NULL, NULL)
INFO - 2017-02-15 15:57:13 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-15 15:57:13 --> Config Class Initialized
INFO - 2017-02-15 15:57:13 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:13 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:13 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:13 --> URI Class Initialized
INFO - 2017-02-15 15:57:13 --> Router Class Initialized
INFO - 2017-02-15 15:57:13 --> Output Class Initialized
INFO - 2017-02-15 15:57:13 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:13 --> Input Class Initialized
INFO - 2017-02-15 15:57:13 --> Language Class Initialized
INFO - 2017-02-15 15:57:13 --> Loader Class Initialized
INFO - 2017-02-15 15:57:13 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:14 --> Controller Class Initialized
INFO - 2017-02-15 15:57:14 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-15 15:57:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`, `contraseña`) VALUES (NULL, NULL, NULL)
INFO - 2017-02-15 15:57:14 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-15 15:57:14 --> Config Class Initialized
INFO - 2017-02-15 15:57:14 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:14 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:14 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:14 --> URI Class Initialized
INFO - 2017-02-15 15:57:14 --> Router Class Initialized
INFO - 2017-02-15 15:57:14 --> Output Class Initialized
INFO - 2017-02-15 15:57:14 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:14 --> Input Class Initialized
INFO - 2017-02-15 15:57:14 --> Language Class Initialized
INFO - 2017-02-15 15:57:14 --> Loader Class Initialized
INFO - 2017-02-15 15:57:14 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:14 --> Controller Class Initialized
INFO - 2017-02-15 15:57:14 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:57:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:57:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:57:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:57:14 --> Final output sent to browser
DEBUG - 2017-02-15 15:57:14 --> Total execution time: 0.0616
INFO - 2017-02-15 15:57:17 --> Config Class Initialized
INFO - 2017-02-15 15:57:17 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:17 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:17 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:17 --> URI Class Initialized
DEBUG - 2017-02-15 15:57:17 --> No URI present. Default controller set.
INFO - 2017-02-15 15:57:17 --> Router Class Initialized
INFO - 2017-02-15 15:57:17 --> Output Class Initialized
INFO - 2017-02-15 15:57:17 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:17 --> Input Class Initialized
INFO - 2017-02-15 15:57:17 --> Language Class Initialized
INFO - 2017-02-15 15:57:17 --> Loader Class Initialized
INFO - 2017-02-15 15:57:17 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:17 --> Controller Class Initialized
INFO - 2017-02-15 15:57:17 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:57:17 --> Final output sent to browser
DEBUG - 2017-02-15 15:57:17 --> Total execution time: 0.0194
INFO - 2017-02-15 15:57:20 --> Config Class Initialized
INFO - 2017-02-15 15:57:20 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:20 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:20 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:20 --> URI Class Initialized
INFO - 2017-02-15 15:57:20 --> Router Class Initialized
INFO - 2017-02-15 15:57:20 --> Output Class Initialized
INFO - 2017-02-15 15:57:20 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:20 --> Input Class Initialized
INFO - 2017-02-15 15:57:20 --> Language Class Initialized
INFO - 2017-02-15 15:57:20 --> Loader Class Initialized
INFO - 2017-02-15 15:57:20 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:20 --> Controller Class Initialized
INFO - 2017-02-15 15:57:20 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:57:20 --> Final output sent to browser
DEBUG - 2017-02-15 15:57:20 --> Total execution time: 0.0138
INFO - 2017-02-15 15:57:34 --> Config Class Initialized
INFO - 2017-02-15 15:57:34 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:34 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:34 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:34 --> URI Class Initialized
DEBUG - 2017-02-15 15:57:34 --> No URI present. Default controller set.
INFO - 2017-02-15 15:57:34 --> Router Class Initialized
INFO - 2017-02-15 15:57:34 --> Output Class Initialized
INFO - 2017-02-15 15:57:34 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:34 --> Input Class Initialized
INFO - 2017-02-15 15:57:34 --> Language Class Initialized
INFO - 2017-02-15 15:57:34 --> Loader Class Initialized
INFO - 2017-02-15 15:57:34 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:34 --> Controller Class Initialized
INFO - 2017-02-15 15:57:34 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:57:34 --> Final output sent to browser
DEBUG - 2017-02-15 15:57:34 --> Total execution time: 0.0141
INFO - 2017-02-15 15:57:47 --> Config Class Initialized
INFO - 2017-02-15 15:57:47 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:57:47 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:57:47 --> Utf8 Class Initialized
INFO - 2017-02-15 15:57:47 --> URI Class Initialized
DEBUG - 2017-02-15 15:57:47 --> No URI present. Default controller set.
INFO - 2017-02-15 15:57:47 --> Router Class Initialized
INFO - 2017-02-15 15:57:47 --> Output Class Initialized
INFO - 2017-02-15 15:57:47 --> Security Class Initialized
DEBUG - 2017-02-15 15:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:57:47 --> Input Class Initialized
INFO - 2017-02-15 15:57:47 --> Language Class Initialized
INFO - 2017-02-15 15:57:47 --> Loader Class Initialized
INFO - 2017-02-15 15:57:47 --> Database Driver Class Initialized
INFO - 2017-02-15 15:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:57:47 --> Controller Class Initialized
INFO - 2017-02-15 15:57:47 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:57:47 --> Final output sent to browser
DEBUG - 2017-02-15 15:57:47 --> Total execution time: 0.0135
INFO - 2017-02-15 15:58:09 --> Config Class Initialized
INFO - 2017-02-15 15:58:09 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:58:09 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:58:09 --> Utf8 Class Initialized
INFO - 2017-02-15 15:58:09 --> URI Class Initialized
INFO - 2017-02-15 15:58:09 --> Router Class Initialized
INFO - 2017-02-15 15:58:09 --> Output Class Initialized
INFO - 2017-02-15 15:58:09 --> Security Class Initialized
DEBUG - 2017-02-15 15:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:58:09 --> Input Class Initialized
INFO - 2017-02-15 15:58:09 --> Language Class Initialized
INFO - 2017-02-15 15:58:09 --> Loader Class Initialized
INFO - 2017-02-15 15:58:09 --> Database Driver Class Initialized
INFO - 2017-02-15 15:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:58:09 --> Controller Class Initialized
INFO - 2017-02-15 15:58:09 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:58:09 --> Final output sent to browser
DEBUG - 2017-02-15 15:58:09 --> Total execution time: 0.0682
INFO - 2017-02-15 15:58:13 --> Config Class Initialized
INFO - 2017-02-15 15:58:13 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:58:13 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:58:13 --> Utf8 Class Initialized
INFO - 2017-02-15 15:58:13 --> URI Class Initialized
INFO - 2017-02-15 15:58:13 --> Router Class Initialized
INFO - 2017-02-15 15:58:13 --> Output Class Initialized
INFO - 2017-02-15 15:58:13 --> Security Class Initialized
DEBUG - 2017-02-15 15:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:58:13 --> Input Class Initialized
INFO - 2017-02-15 15:58:13 --> Language Class Initialized
INFO - 2017-02-15 15:58:13 --> Loader Class Initialized
INFO - 2017-02-15 15:58:13 --> Database Driver Class Initialized
INFO - 2017-02-15 15:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:58:13 --> Controller Class Initialized
INFO - 2017-02-15 15:58:13 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:58:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-15 15:58:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-15 15:58:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Gaby Robles')
INFO - 2017-02-15 15:58:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-15 15:58:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-15 15:58:15 --> Config Class Initialized
INFO - 2017-02-15 15:58:15 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:58:15 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:58:15 --> Utf8 Class Initialized
INFO - 2017-02-15 15:58:15 --> URI Class Initialized
INFO - 2017-02-15 15:58:15 --> Router Class Initialized
INFO - 2017-02-15 15:58:15 --> Output Class Initialized
INFO - 2017-02-15 15:58:15 --> Security Class Initialized
DEBUG - 2017-02-15 15:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:58:15 --> Input Class Initialized
INFO - 2017-02-15 15:58:15 --> Language Class Initialized
INFO - 2017-02-15 15:58:15 --> Loader Class Initialized
INFO - 2017-02-15 15:58:15 --> Database Driver Class Initialized
INFO - 2017-02-15 15:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:58:15 --> Controller Class Initialized
INFO - 2017-02-15 15:58:15 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:58:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:58:15 --> Final output sent to browser
DEBUG - 2017-02-15 15:58:15 --> Total execution time: 0.0384
INFO - 2017-02-15 15:58:18 --> Config Class Initialized
INFO - 2017-02-15 15:58:18 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:58:18 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:58:18 --> Utf8 Class Initialized
INFO - 2017-02-15 15:58:18 --> URI Class Initialized
DEBUG - 2017-02-15 15:58:18 --> No URI present. Default controller set.
INFO - 2017-02-15 15:58:18 --> Router Class Initialized
INFO - 2017-02-15 15:58:18 --> Output Class Initialized
INFO - 2017-02-15 15:58:18 --> Security Class Initialized
DEBUG - 2017-02-15 15:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:58:18 --> Input Class Initialized
INFO - 2017-02-15 15:58:18 --> Language Class Initialized
INFO - 2017-02-15 15:58:18 --> Loader Class Initialized
INFO - 2017-02-15 15:58:18 --> Database Driver Class Initialized
INFO - 2017-02-15 15:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:58:18 --> Controller Class Initialized
INFO - 2017-02-15 15:58:18 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:58:18 --> Final output sent to browser
DEBUG - 2017-02-15 15:58:18 --> Total execution time: 0.0342
INFO - 2017-02-15 15:58:20 --> Config Class Initialized
INFO - 2017-02-15 15:58:20 --> Hooks Class Initialized
DEBUG - 2017-02-15 15:58:20 --> UTF-8 Support Enabled
INFO - 2017-02-15 15:58:20 --> Utf8 Class Initialized
INFO - 2017-02-15 15:58:20 --> URI Class Initialized
INFO - 2017-02-15 15:58:20 --> Router Class Initialized
INFO - 2017-02-15 15:58:20 --> Output Class Initialized
INFO - 2017-02-15 15:58:20 --> Security Class Initialized
DEBUG - 2017-02-15 15:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 15:58:20 --> Input Class Initialized
INFO - 2017-02-15 15:58:20 --> Language Class Initialized
INFO - 2017-02-15 15:58:20 --> Loader Class Initialized
INFO - 2017-02-15 15:58:20 --> Database Driver Class Initialized
INFO - 2017-02-15 15:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 15:58:20 --> Controller Class Initialized
INFO - 2017-02-15 15:58:20 --> Helper loaded: url_helper
DEBUG - 2017-02-15 15:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 15:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 15:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 15:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 15:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 15:58:20 --> Final output sent to browser
DEBUG - 2017-02-15 15:58:20 --> Total execution time: 0.0145
INFO - 2017-02-15 16:00:22 --> Config Class Initialized
INFO - 2017-02-15 16:00:22 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:22 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:22 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:22 --> URI Class Initialized
INFO - 2017-02-15 16:00:22 --> Router Class Initialized
INFO - 2017-02-15 16:00:22 --> Output Class Initialized
INFO - 2017-02-15 16:00:22 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:22 --> Input Class Initialized
INFO - 2017-02-15 16:00:22 --> Language Class Initialized
INFO - 2017-02-15 16:00:22 --> Loader Class Initialized
INFO - 2017-02-15 16:00:22 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:22 --> Controller Class Initialized
INFO - 2017-02-15 16:00:22 --> Helper loaded: url_helper
DEBUG - 2017-02-15 16:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:23 --> Config Class Initialized
INFO - 2017-02-15 16:00:23 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:23 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:23 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:23 --> URI Class Initialized
INFO - 2017-02-15 16:00:23 --> Router Class Initialized
INFO - 2017-02-15 16:00:23 --> Output Class Initialized
INFO - 2017-02-15 16:00:23 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:23 --> Input Class Initialized
INFO - 2017-02-15 16:00:23 --> Language Class Initialized
INFO - 2017-02-15 16:00:23 --> Loader Class Initialized
INFO - 2017-02-15 16:00:23 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:23 --> Controller Class Initialized
INFO - 2017-02-15 16:00:23 --> Helper loaded: date_helper
DEBUG - 2017-02-15 16:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:23 --> Helper loaded: url_helper
INFO - 2017-02-15 16:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 16:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 16:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 16:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 16:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 16:00:23 --> Final output sent to browser
DEBUG - 2017-02-15 16:00:23 --> Total execution time: 0.0146
INFO - 2017-02-15 16:00:25 --> Config Class Initialized
INFO - 2017-02-15 16:00:25 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:25 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:25 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:25 --> URI Class Initialized
INFO - 2017-02-15 16:00:25 --> Router Class Initialized
INFO - 2017-02-15 16:00:25 --> Output Class Initialized
INFO - 2017-02-15 16:00:25 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:25 --> Input Class Initialized
INFO - 2017-02-15 16:00:25 --> Language Class Initialized
INFO - 2017-02-15 16:00:25 --> Loader Class Initialized
INFO - 2017-02-15 16:00:25 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:25 --> Controller Class Initialized
INFO - 2017-02-15 16:00:25 --> Helper loaded: url_helper
DEBUG - 2017-02-15 16:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 16:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 16:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 16:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 16:00:25 --> Final output sent to browser
DEBUG - 2017-02-15 16:00:25 --> Total execution time: 0.0141
INFO - 2017-02-15 16:00:37 --> Config Class Initialized
INFO - 2017-02-15 16:00:37 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:37 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:37 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:37 --> URI Class Initialized
DEBUG - 2017-02-15 16:00:37 --> No URI present. Default controller set.
INFO - 2017-02-15 16:00:37 --> Router Class Initialized
INFO - 2017-02-15 16:00:37 --> Output Class Initialized
INFO - 2017-02-15 16:00:37 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:37 --> Input Class Initialized
INFO - 2017-02-15 16:00:37 --> Language Class Initialized
INFO - 2017-02-15 16:00:37 --> Loader Class Initialized
INFO - 2017-02-15 16:00:37 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:37 --> Controller Class Initialized
INFO - 2017-02-15 16:00:37 --> Helper loaded: url_helper
DEBUG - 2017-02-15 16:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 16:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 16:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 16:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 16:00:37 --> Final output sent to browser
DEBUG - 2017-02-15 16:00:37 --> Total execution time: 0.0133
INFO - 2017-02-15 16:00:40 --> Config Class Initialized
INFO - 2017-02-15 16:00:40 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:40 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:40 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:40 --> URI Class Initialized
INFO - 2017-02-15 16:00:40 --> Router Class Initialized
INFO - 2017-02-15 16:00:40 --> Output Class Initialized
INFO - 2017-02-15 16:00:40 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:40 --> Input Class Initialized
INFO - 2017-02-15 16:00:40 --> Language Class Initialized
INFO - 2017-02-15 16:00:40 --> Loader Class Initialized
INFO - 2017-02-15 16:00:40 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:40 --> Controller Class Initialized
INFO - 2017-02-15 16:00:40 --> Helper loaded: url_helper
DEBUG - 2017-02-15 16:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 16:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 16:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 16:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 16:00:40 --> Final output sent to browser
DEBUG - 2017-02-15 16:00:40 --> Total execution time: 0.0140
INFO - 2017-02-15 16:00:54 --> Config Class Initialized
INFO - 2017-02-15 16:00:54 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:54 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:54 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:54 --> URI Class Initialized
INFO - 2017-02-15 16:00:54 --> Router Class Initialized
INFO - 2017-02-15 16:00:54 --> Output Class Initialized
INFO - 2017-02-15 16:00:54 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:54 --> Input Class Initialized
INFO - 2017-02-15 16:00:54 --> Language Class Initialized
INFO - 2017-02-15 16:00:54 --> Loader Class Initialized
INFO - 2017-02-15 16:00:54 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:54 --> Controller Class Initialized
INFO - 2017-02-15 16:00:54 --> Helper loaded: date_helper
DEBUG - 2017-02-15 16:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:54 --> Helper loaded: url_helper
INFO - 2017-02-15 16:00:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 16:00:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 16:00:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 16:00:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 16:00:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 16:00:54 --> Final output sent to browser
DEBUG - 2017-02-15 16:00:54 --> Total execution time: 0.0140
INFO - 2017-02-15 16:00:55 --> Config Class Initialized
INFO - 2017-02-15 16:00:55 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:55 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:55 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:55 --> URI Class Initialized
DEBUG - 2017-02-15 16:00:55 --> No URI present. Default controller set.
INFO - 2017-02-15 16:00:55 --> Router Class Initialized
INFO - 2017-02-15 16:00:55 --> Output Class Initialized
INFO - 2017-02-15 16:00:55 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:55 --> Input Class Initialized
INFO - 2017-02-15 16:00:55 --> Language Class Initialized
INFO - 2017-02-15 16:00:55 --> Loader Class Initialized
INFO - 2017-02-15 16:00:55 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:55 --> Controller Class Initialized
INFO - 2017-02-15 16:00:55 --> Helper loaded: url_helper
DEBUG - 2017-02-15 16:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 16:00:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 16:00:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 16:00:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 16:00:55 --> Final output sent to browser
DEBUG - 2017-02-15 16:00:55 --> Total execution time: 0.0135
INFO - 2017-02-15 16:00:56 --> Config Class Initialized
INFO - 2017-02-15 16:00:56 --> Hooks Class Initialized
DEBUG - 2017-02-15 16:00:56 --> UTF-8 Support Enabled
INFO - 2017-02-15 16:00:56 --> Utf8 Class Initialized
INFO - 2017-02-15 16:00:56 --> URI Class Initialized
INFO - 2017-02-15 16:00:56 --> Router Class Initialized
INFO - 2017-02-15 16:00:56 --> Output Class Initialized
INFO - 2017-02-15 16:00:56 --> Security Class Initialized
DEBUG - 2017-02-15 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 16:00:56 --> Input Class Initialized
INFO - 2017-02-15 16:00:56 --> Language Class Initialized
INFO - 2017-02-15 16:00:56 --> Loader Class Initialized
INFO - 2017-02-15 16:00:56 --> Database Driver Class Initialized
INFO - 2017-02-15 16:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 16:00:56 --> Controller Class Initialized
INFO - 2017-02-15 16:00:56 --> Helper loaded: url_helper
DEBUG - 2017-02-15 16:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 16:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 16:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 16:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 16:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 16:00:56 --> Final output sent to browser
DEBUG - 2017-02-15 16:00:56 --> Total execution time: 0.0140
INFO - 2017-02-15 17:09:08 --> Config Class Initialized
INFO - 2017-02-15 17:09:08 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:09:08 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:09:08 --> Utf8 Class Initialized
INFO - 2017-02-15 17:09:08 --> URI Class Initialized
DEBUG - 2017-02-15 17:09:08 --> No URI present. Default controller set.
INFO - 2017-02-15 17:09:08 --> Router Class Initialized
INFO - 2017-02-15 17:09:08 --> Output Class Initialized
INFO - 2017-02-15 17:09:08 --> Security Class Initialized
DEBUG - 2017-02-15 17:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:09:09 --> Input Class Initialized
INFO - 2017-02-15 17:09:09 --> Language Class Initialized
INFO - 2017-02-15 17:09:09 --> Loader Class Initialized
INFO - 2017-02-15 17:09:09 --> Database Driver Class Initialized
INFO - 2017-02-15 17:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:09:09 --> Controller Class Initialized
INFO - 2017-02-15 17:09:09 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:09:09 --> Final output sent to browser
DEBUG - 2017-02-15 17:09:09 --> Total execution time: 1.2837
INFO - 2017-02-15 17:13:10 --> Config Class Initialized
INFO - 2017-02-15 17:13:10 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:13:10 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:13:10 --> Utf8 Class Initialized
INFO - 2017-02-15 17:13:10 --> URI Class Initialized
INFO - 2017-02-15 17:13:10 --> Router Class Initialized
INFO - 2017-02-15 17:13:10 --> Output Class Initialized
INFO - 2017-02-15 17:13:10 --> Security Class Initialized
DEBUG - 2017-02-15 17:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:13:10 --> Input Class Initialized
INFO - 2017-02-15 17:13:10 --> Language Class Initialized
INFO - 2017-02-15 17:13:10 --> Loader Class Initialized
INFO - 2017-02-15 17:13:10 --> Database Driver Class Initialized
INFO - 2017-02-15 17:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:13:10 --> Controller Class Initialized
INFO - 2017-02-15 17:13:10 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:13:10 --> Config Class Initialized
INFO - 2017-02-15 17:13:10 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:13:10 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:13:10 --> Utf8 Class Initialized
INFO - 2017-02-15 17:13:10 --> URI Class Initialized
INFO - 2017-02-15 17:13:10 --> Router Class Initialized
INFO - 2017-02-15 17:13:10 --> Output Class Initialized
INFO - 2017-02-15 17:13:10 --> Security Class Initialized
DEBUG - 2017-02-15 17:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:13:10 --> Input Class Initialized
INFO - 2017-02-15 17:13:10 --> Language Class Initialized
INFO - 2017-02-15 17:13:10 --> Loader Class Initialized
INFO - 2017-02-15 17:13:10 --> Database Driver Class Initialized
INFO - 2017-02-15 17:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:13:10 --> Controller Class Initialized
INFO - 2017-02-15 17:13:10 --> Helper loaded: date_helper
DEBUG - 2017-02-15 17:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:13:10 --> Helper loaded: url_helper
INFO - 2017-02-15 17:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 17:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 17:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 17:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:13:10 --> Final output sent to browser
DEBUG - 2017-02-15 17:13:10 --> Total execution time: 0.0130
INFO - 2017-02-15 17:13:11 --> Config Class Initialized
INFO - 2017-02-15 17:13:11 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:13:11 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:13:11 --> Utf8 Class Initialized
INFO - 2017-02-15 17:13:11 --> URI Class Initialized
INFO - 2017-02-15 17:13:11 --> Router Class Initialized
INFO - 2017-02-15 17:13:11 --> Output Class Initialized
INFO - 2017-02-15 17:13:11 --> Security Class Initialized
DEBUG - 2017-02-15 17:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:13:11 --> Input Class Initialized
INFO - 2017-02-15 17:13:11 --> Language Class Initialized
INFO - 2017-02-15 17:13:11 --> Loader Class Initialized
INFO - 2017-02-15 17:13:11 --> Database Driver Class Initialized
INFO - 2017-02-15 17:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:13:11 --> Controller Class Initialized
INFO - 2017-02-15 17:13:11 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:13:11 --> Final output sent to browser
DEBUG - 2017-02-15 17:13:11 --> Total execution time: 0.0134
INFO - 2017-02-15 17:13:20 --> Config Class Initialized
INFO - 2017-02-15 17:13:20 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:13:20 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:13:20 --> Utf8 Class Initialized
INFO - 2017-02-15 17:13:20 --> URI Class Initialized
DEBUG - 2017-02-15 17:13:20 --> No URI present. Default controller set.
INFO - 2017-02-15 17:13:20 --> Router Class Initialized
INFO - 2017-02-15 17:13:20 --> Output Class Initialized
INFO - 2017-02-15 17:13:20 --> Security Class Initialized
DEBUG - 2017-02-15 17:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:13:20 --> Input Class Initialized
INFO - 2017-02-15 17:13:20 --> Language Class Initialized
INFO - 2017-02-15 17:13:20 --> Loader Class Initialized
INFO - 2017-02-15 17:13:20 --> Database Driver Class Initialized
INFO - 2017-02-15 17:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:13:20 --> Controller Class Initialized
INFO - 2017-02-15 17:13:20 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:13:20 --> Final output sent to browser
DEBUG - 2017-02-15 17:13:20 --> Total execution time: 0.0143
INFO - 2017-02-15 17:13:26 --> Config Class Initialized
INFO - 2017-02-15 17:13:26 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:13:26 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:13:26 --> Utf8 Class Initialized
INFO - 2017-02-15 17:13:26 --> URI Class Initialized
INFO - 2017-02-15 17:13:26 --> Router Class Initialized
INFO - 2017-02-15 17:13:26 --> Output Class Initialized
INFO - 2017-02-15 17:13:26 --> Security Class Initialized
DEBUG - 2017-02-15 17:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:13:26 --> Input Class Initialized
INFO - 2017-02-15 17:13:26 --> Language Class Initialized
INFO - 2017-02-15 17:13:26 --> Loader Class Initialized
INFO - 2017-02-15 17:13:26 --> Database Driver Class Initialized
INFO - 2017-02-15 17:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:13:26 --> Controller Class Initialized
INFO - 2017-02-15 17:13:26 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:13:26 --> Final output sent to browser
DEBUG - 2017-02-15 17:13:26 --> Total execution time: 0.0135
INFO - 2017-02-15 17:13:58 --> Config Class Initialized
INFO - 2017-02-15 17:13:58 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:13:58 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:13:58 --> Utf8 Class Initialized
INFO - 2017-02-15 17:13:58 --> URI Class Initialized
INFO - 2017-02-15 17:13:58 --> Router Class Initialized
INFO - 2017-02-15 17:13:58 --> Output Class Initialized
INFO - 2017-02-15 17:13:58 --> Security Class Initialized
DEBUG - 2017-02-15 17:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:13:58 --> Input Class Initialized
INFO - 2017-02-15 17:13:58 --> Language Class Initialized
INFO - 2017-02-15 17:13:58 --> Loader Class Initialized
INFO - 2017-02-15 17:13:58 --> Database Driver Class Initialized
INFO - 2017-02-15 17:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:13:58 --> Controller Class Initialized
INFO - 2017-02-15 17:13:58 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:13:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:13:58 --> Final output sent to browser
DEBUG - 2017-02-15 17:13:58 --> Total execution time: 0.0140
INFO - 2017-02-15 17:14:00 --> Config Class Initialized
INFO - 2017-02-15 17:14:00 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:00 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:00 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:00 --> URI Class Initialized
INFO - 2017-02-15 17:14:00 --> Router Class Initialized
INFO - 2017-02-15 17:14:00 --> Output Class Initialized
INFO - 2017-02-15 17:14:00 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:00 --> Input Class Initialized
INFO - 2017-02-15 17:14:00 --> Language Class Initialized
INFO - 2017-02-15 17:14:00 --> Loader Class Initialized
INFO - 2017-02-15 17:14:00 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:00 --> Controller Class Initialized
INFO - 2017-02-15 17:14:00 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:14:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:14:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:14:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:14:00 --> Final output sent to browser
DEBUG - 2017-02-15 17:14:00 --> Total execution time: 0.0196
INFO - 2017-02-15 17:14:22 --> Config Class Initialized
INFO - 2017-02-15 17:14:22 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:22 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:22 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:22 --> URI Class Initialized
INFO - 2017-02-15 17:14:22 --> Router Class Initialized
INFO - 2017-02-15 17:14:22 --> Output Class Initialized
INFO - 2017-02-15 17:14:22 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:22 --> Input Class Initialized
INFO - 2017-02-15 17:14:22 --> Language Class Initialized
INFO - 2017-02-15 17:14:22 --> Loader Class Initialized
INFO - 2017-02-15 17:14:22 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:22 --> Controller Class Initialized
INFO - 2017-02-15 17:14:22 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:23 --> Config Class Initialized
INFO - 2017-02-15 17:14:23 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:23 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:23 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:23 --> URI Class Initialized
INFO - 2017-02-15 17:14:23 --> Router Class Initialized
INFO - 2017-02-15 17:14:23 --> Output Class Initialized
INFO - 2017-02-15 17:14:23 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:23 --> Input Class Initialized
INFO - 2017-02-15 17:14:23 --> Language Class Initialized
INFO - 2017-02-15 17:14:23 --> Loader Class Initialized
INFO - 2017-02-15 17:14:23 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:23 --> Controller Class Initialized
INFO - 2017-02-15 17:14:23 --> Helper loaded: date_helper
DEBUG - 2017-02-15 17:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:23 --> Helper loaded: url_helper
INFO - 2017-02-15 17:14:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:14:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 17:14:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 17:14:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 17:14:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:14:23 --> Final output sent to browser
DEBUG - 2017-02-15 17:14:23 --> Total execution time: 0.0138
INFO - 2017-02-15 17:14:24 --> Config Class Initialized
INFO - 2017-02-15 17:14:24 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:24 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:24 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:24 --> URI Class Initialized
INFO - 2017-02-15 17:14:24 --> Router Class Initialized
INFO - 2017-02-15 17:14:24 --> Output Class Initialized
INFO - 2017-02-15 17:14:24 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:24 --> Input Class Initialized
INFO - 2017-02-15 17:14:24 --> Language Class Initialized
INFO - 2017-02-15 17:14:24 --> Loader Class Initialized
INFO - 2017-02-15 17:14:24 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:24 --> Controller Class Initialized
INFO - 2017-02-15 17:14:24 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:14:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:14:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:14:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:14:24 --> Final output sent to browser
DEBUG - 2017-02-15 17:14:24 --> Total execution time: 0.0131
INFO - 2017-02-15 17:14:34 --> Config Class Initialized
INFO - 2017-02-15 17:14:34 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:34 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:34 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:34 --> URI Class Initialized
DEBUG - 2017-02-15 17:14:34 --> No URI present. Default controller set.
INFO - 2017-02-15 17:14:34 --> Router Class Initialized
INFO - 2017-02-15 17:14:34 --> Output Class Initialized
INFO - 2017-02-15 17:14:34 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:34 --> Input Class Initialized
INFO - 2017-02-15 17:14:34 --> Language Class Initialized
INFO - 2017-02-15 17:14:34 --> Loader Class Initialized
INFO - 2017-02-15 17:14:34 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:34 --> Controller Class Initialized
INFO - 2017-02-15 17:14:34 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:14:34 --> Final output sent to browser
DEBUG - 2017-02-15 17:14:34 --> Total execution time: 0.0132
INFO - 2017-02-15 17:14:35 --> Config Class Initialized
INFO - 2017-02-15 17:14:35 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:35 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:35 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:35 --> URI Class Initialized
INFO - 2017-02-15 17:14:35 --> Router Class Initialized
INFO - 2017-02-15 17:14:35 --> Output Class Initialized
INFO - 2017-02-15 17:14:35 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:35 --> Input Class Initialized
INFO - 2017-02-15 17:14:35 --> Language Class Initialized
INFO - 2017-02-15 17:14:35 --> Loader Class Initialized
INFO - 2017-02-15 17:14:35 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:35 --> Controller Class Initialized
INFO - 2017-02-15 17:14:35 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:14:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:14:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:14:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:14:35 --> Final output sent to browser
DEBUG - 2017-02-15 17:14:35 --> Total execution time: 0.0134
INFO - 2017-02-15 17:14:44 --> Config Class Initialized
INFO - 2017-02-15 17:14:44 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:44 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:44 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:44 --> URI Class Initialized
INFO - 2017-02-15 17:14:44 --> Router Class Initialized
INFO - 2017-02-15 17:14:44 --> Output Class Initialized
INFO - 2017-02-15 17:14:44 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:44 --> Input Class Initialized
INFO - 2017-02-15 17:14:44 --> Language Class Initialized
INFO - 2017-02-15 17:14:44 --> Loader Class Initialized
INFO - 2017-02-15 17:14:44 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:44 --> Controller Class Initialized
INFO - 2017-02-15 17:14:44 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:44 --> Config Class Initialized
INFO - 2017-02-15 17:14:44 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:44 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:44 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:44 --> URI Class Initialized
INFO - 2017-02-15 17:14:44 --> Router Class Initialized
INFO - 2017-02-15 17:14:44 --> Output Class Initialized
INFO - 2017-02-15 17:14:44 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:44 --> Input Class Initialized
INFO - 2017-02-15 17:14:44 --> Language Class Initialized
INFO - 2017-02-15 17:14:44 --> Loader Class Initialized
INFO - 2017-02-15 17:14:44 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:44 --> Controller Class Initialized
INFO - 2017-02-15 17:14:44 --> Helper loaded: date_helper
DEBUG - 2017-02-15 17:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:44 --> Helper loaded: url_helper
INFO - 2017-02-15 17:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 17:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 17:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 17:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:14:44 --> Final output sent to browser
DEBUG - 2017-02-15 17:14:44 --> Total execution time: 0.0145
INFO - 2017-02-15 17:14:45 --> Config Class Initialized
INFO - 2017-02-15 17:14:45 --> Hooks Class Initialized
DEBUG - 2017-02-15 17:14:45 --> UTF-8 Support Enabled
INFO - 2017-02-15 17:14:45 --> Utf8 Class Initialized
INFO - 2017-02-15 17:14:45 --> URI Class Initialized
INFO - 2017-02-15 17:14:45 --> Router Class Initialized
INFO - 2017-02-15 17:14:45 --> Output Class Initialized
INFO - 2017-02-15 17:14:45 --> Security Class Initialized
DEBUG - 2017-02-15 17:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 17:14:45 --> Input Class Initialized
INFO - 2017-02-15 17:14:45 --> Language Class Initialized
INFO - 2017-02-15 17:14:45 --> Loader Class Initialized
INFO - 2017-02-15 17:14:45 --> Database Driver Class Initialized
INFO - 2017-02-15 17:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 17:14:45 --> Controller Class Initialized
INFO - 2017-02-15 17:14:45 --> Helper loaded: url_helper
DEBUG - 2017-02-15 17:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 17:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 17:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 17:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 17:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 17:14:45 --> Final output sent to browser
DEBUG - 2017-02-15 17:14:45 --> Total execution time: 0.0134
INFO - 2017-02-15 18:38:09 --> Config Class Initialized
INFO - 2017-02-15 18:38:09 --> Hooks Class Initialized
DEBUG - 2017-02-15 18:38:09 --> UTF-8 Support Enabled
INFO - 2017-02-15 18:38:09 --> Utf8 Class Initialized
INFO - 2017-02-15 18:38:09 --> URI Class Initialized
DEBUG - 2017-02-15 18:38:09 --> No URI present. Default controller set.
INFO - 2017-02-15 18:38:09 --> Router Class Initialized
INFO - 2017-02-15 18:38:09 --> Output Class Initialized
INFO - 2017-02-15 18:38:09 --> Security Class Initialized
DEBUG - 2017-02-15 18:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 18:38:09 --> Input Class Initialized
INFO - 2017-02-15 18:38:09 --> Language Class Initialized
INFO - 2017-02-15 18:38:09 --> Loader Class Initialized
INFO - 2017-02-15 18:38:09 --> Database Driver Class Initialized
INFO - 2017-02-15 18:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 18:38:09 --> Controller Class Initialized
INFO - 2017-02-15 18:38:09 --> Helper loaded: url_helper
DEBUG - 2017-02-15 18:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 18:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 18:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 18:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 18:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 18:38:09 --> Final output sent to browser
DEBUG - 2017-02-15 18:38:09 --> Total execution time: 0.0136
INFO - 2017-02-15 19:46:42 --> Config Class Initialized
INFO - 2017-02-15 19:46:42 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:46:42 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:46:42 --> Utf8 Class Initialized
INFO - 2017-02-15 19:46:42 --> URI Class Initialized
DEBUG - 2017-02-15 19:46:42 --> No URI present. Default controller set.
INFO - 2017-02-15 19:46:42 --> Router Class Initialized
INFO - 2017-02-15 19:46:42 --> Output Class Initialized
INFO - 2017-02-15 19:46:42 --> Security Class Initialized
DEBUG - 2017-02-15 19:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:46:42 --> Input Class Initialized
INFO - 2017-02-15 19:46:42 --> Language Class Initialized
INFO - 2017-02-15 19:46:42 --> Loader Class Initialized
INFO - 2017-02-15 19:46:43 --> Database Driver Class Initialized
INFO - 2017-02-15 19:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:46:43 --> Controller Class Initialized
INFO - 2017-02-15 19:46:43 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:46:43 --> Final output sent to browser
DEBUG - 2017-02-15 19:46:43 --> Total execution time: 0.9878
INFO - 2017-02-15 19:47:44 --> Config Class Initialized
INFO - 2017-02-15 19:47:44 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:47:44 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:47:44 --> Utf8 Class Initialized
INFO - 2017-02-15 19:47:44 --> URI Class Initialized
INFO - 2017-02-15 19:47:44 --> Router Class Initialized
INFO - 2017-02-15 19:47:44 --> Output Class Initialized
INFO - 2017-02-15 19:47:44 --> Security Class Initialized
DEBUG - 2017-02-15 19:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:47:44 --> Input Class Initialized
INFO - 2017-02-15 19:47:44 --> Language Class Initialized
INFO - 2017-02-15 19:47:44 --> Loader Class Initialized
INFO - 2017-02-15 19:47:44 --> Database Driver Class Initialized
INFO - 2017-02-15 19:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:47:44 --> Controller Class Initialized
INFO - 2017-02-15 19:47:44 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:47:44 --> Final output sent to browser
DEBUG - 2017-02-15 19:47:44 --> Total execution time: 0.0132
INFO - 2017-02-15 19:47:47 --> Config Class Initialized
INFO - 2017-02-15 19:47:47 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:47:47 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:47:47 --> Utf8 Class Initialized
INFO - 2017-02-15 19:47:47 --> URI Class Initialized
INFO - 2017-02-15 19:47:47 --> Router Class Initialized
INFO - 2017-02-15 19:47:47 --> Output Class Initialized
INFO - 2017-02-15 19:47:47 --> Security Class Initialized
DEBUG - 2017-02-15 19:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:47:47 --> Input Class Initialized
INFO - 2017-02-15 19:47:47 --> Language Class Initialized
INFO - 2017-02-15 19:47:47 --> Loader Class Initialized
INFO - 2017-02-15 19:47:47 --> Database Driver Class Initialized
INFO - 2017-02-15 19:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:47:47 --> Controller Class Initialized
INFO - 2017-02-15 19:47:47 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:47:47 --> Final output sent to browser
DEBUG - 2017-02-15 19:47:47 --> Total execution time: 0.0135
INFO - 2017-02-15 19:47:50 --> Config Class Initialized
INFO - 2017-02-15 19:47:50 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:47:50 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:47:50 --> Utf8 Class Initialized
INFO - 2017-02-15 19:47:50 --> URI Class Initialized
INFO - 2017-02-15 19:47:50 --> Router Class Initialized
INFO - 2017-02-15 19:47:50 --> Output Class Initialized
INFO - 2017-02-15 19:47:50 --> Security Class Initialized
DEBUG - 2017-02-15 19:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:47:50 --> Input Class Initialized
INFO - 2017-02-15 19:47:50 --> Language Class Initialized
INFO - 2017-02-15 19:47:50 --> Loader Class Initialized
INFO - 2017-02-15 19:47:50 --> Database Driver Class Initialized
INFO - 2017-02-15 19:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:47:50 --> Controller Class Initialized
INFO - 2017-02-15 19:47:50 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:47:50 --> Final output sent to browser
DEBUG - 2017-02-15 19:47:50 --> Total execution time: 0.0138
INFO - 2017-02-15 19:47:52 --> Config Class Initialized
INFO - 2017-02-15 19:47:52 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:47:52 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:47:52 --> Utf8 Class Initialized
INFO - 2017-02-15 19:47:52 --> URI Class Initialized
INFO - 2017-02-15 19:47:52 --> Router Class Initialized
INFO - 2017-02-15 19:47:52 --> Output Class Initialized
INFO - 2017-02-15 19:47:52 --> Security Class Initialized
DEBUG - 2017-02-15 19:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:47:52 --> Input Class Initialized
INFO - 2017-02-15 19:47:52 --> Language Class Initialized
INFO - 2017-02-15 19:47:52 --> Loader Class Initialized
INFO - 2017-02-15 19:47:52 --> Database Driver Class Initialized
INFO - 2017-02-15 19:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:47:52 --> Controller Class Initialized
INFO - 2017-02-15 19:47:52 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:47:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:47:52 --> Final output sent to browser
DEBUG - 2017-02-15 19:47:52 --> Total execution time: 0.0134
INFO - 2017-02-15 19:47:53 --> Config Class Initialized
INFO - 2017-02-15 19:47:53 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:47:53 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:47:53 --> Utf8 Class Initialized
INFO - 2017-02-15 19:47:53 --> URI Class Initialized
INFO - 2017-02-15 19:47:53 --> Router Class Initialized
INFO - 2017-02-15 19:47:53 --> Output Class Initialized
INFO - 2017-02-15 19:47:53 --> Security Class Initialized
DEBUG - 2017-02-15 19:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:47:53 --> Input Class Initialized
INFO - 2017-02-15 19:47:53 --> Language Class Initialized
INFO - 2017-02-15 19:47:53 --> Loader Class Initialized
INFO - 2017-02-15 19:47:53 --> Database Driver Class Initialized
INFO - 2017-02-15 19:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:47:53 --> Controller Class Initialized
INFO - 2017-02-15 19:47:53 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:47:53 --> Final output sent to browser
DEBUG - 2017-02-15 19:47:53 --> Total execution time: 0.0205
INFO - 2017-02-15 19:47:57 --> Config Class Initialized
INFO - 2017-02-15 19:47:57 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:47:57 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:47:57 --> Utf8 Class Initialized
INFO - 2017-02-15 19:47:57 --> URI Class Initialized
INFO - 2017-02-15 19:47:57 --> Router Class Initialized
INFO - 2017-02-15 19:47:57 --> Output Class Initialized
INFO - 2017-02-15 19:47:57 --> Security Class Initialized
DEBUG - 2017-02-15 19:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:47:57 --> Input Class Initialized
INFO - 2017-02-15 19:47:57 --> Language Class Initialized
INFO - 2017-02-15 19:47:57 --> Loader Class Initialized
INFO - 2017-02-15 19:47:57 --> Database Driver Class Initialized
INFO - 2017-02-15 19:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:47:57 --> Controller Class Initialized
INFO - 2017-02-15 19:47:57 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:47:57 --> Final output sent to browser
DEBUG - 2017-02-15 19:47:57 --> Total execution time: 0.0137
INFO - 2017-02-15 19:48:02 --> Config Class Initialized
INFO - 2017-02-15 19:48:02 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:48:02 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:48:02 --> Utf8 Class Initialized
INFO - 2017-02-15 19:48:02 --> URI Class Initialized
INFO - 2017-02-15 19:48:02 --> Router Class Initialized
INFO - 2017-02-15 19:48:02 --> Output Class Initialized
INFO - 2017-02-15 19:48:02 --> Security Class Initialized
DEBUG - 2017-02-15 19:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:48:02 --> Input Class Initialized
INFO - 2017-02-15 19:48:02 --> Language Class Initialized
INFO - 2017-02-15 19:48:02 --> Loader Class Initialized
INFO - 2017-02-15 19:48:02 --> Database Driver Class Initialized
INFO - 2017-02-15 19:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:48:02 --> Controller Class Initialized
INFO - 2017-02-15 19:48:02 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:48:04 --> Config Class Initialized
INFO - 2017-02-15 19:48:04 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:48:04 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:48:04 --> Utf8 Class Initialized
INFO - 2017-02-15 19:48:04 --> URI Class Initialized
INFO - 2017-02-15 19:48:04 --> Router Class Initialized
INFO - 2017-02-15 19:48:04 --> Output Class Initialized
INFO - 2017-02-15 19:48:04 --> Security Class Initialized
DEBUG - 2017-02-15 19:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:48:04 --> Input Class Initialized
INFO - 2017-02-15 19:48:04 --> Language Class Initialized
INFO - 2017-02-15 19:48:04 --> Loader Class Initialized
INFO - 2017-02-15 19:48:04 --> Database Driver Class Initialized
INFO - 2017-02-15 19:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:48:04 --> Controller Class Initialized
INFO - 2017-02-15 19:48:04 --> Helper loaded: date_helper
DEBUG - 2017-02-15 19:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:48:04 --> Helper loaded: url_helper
INFO - 2017-02-15 19:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 19:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 19:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 19:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:48:04 --> Final output sent to browser
DEBUG - 2017-02-15 19:48:04 --> Total execution time: 0.1078
INFO - 2017-02-15 19:48:12 --> Config Class Initialized
INFO - 2017-02-15 19:48:12 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:48:12 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:48:12 --> Utf8 Class Initialized
INFO - 2017-02-15 19:48:12 --> URI Class Initialized
DEBUG - 2017-02-15 19:48:12 --> No URI present. Default controller set.
INFO - 2017-02-15 19:48:12 --> Router Class Initialized
INFO - 2017-02-15 19:48:12 --> Output Class Initialized
INFO - 2017-02-15 19:48:12 --> Security Class Initialized
DEBUG - 2017-02-15 19:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:48:12 --> Input Class Initialized
INFO - 2017-02-15 19:48:12 --> Language Class Initialized
INFO - 2017-02-15 19:48:12 --> Loader Class Initialized
INFO - 2017-02-15 19:48:12 --> Database Driver Class Initialized
INFO - 2017-02-15 19:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:48:12 --> Controller Class Initialized
INFO - 2017-02-15 19:48:12 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:48:12 --> Final output sent to browser
DEBUG - 2017-02-15 19:48:12 --> Total execution time: 0.0139
INFO - 2017-02-15 19:48:17 --> Config Class Initialized
INFO - 2017-02-15 19:48:17 --> Hooks Class Initialized
DEBUG - 2017-02-15 19:48:17 --> UTF-8 Support Enabled
INFO - 2017-02-15 19:48:17 --> Utf8 Class Initialized
INFO - 2017-02-15 19:48:17 --> URI Class Initialized
INFO - 2017-02-15 19:48:17 --> Router Class Initialized
INFO - 2017-02-15 19:48:17 --> Output Class Initialized
INFO - 2017-02-15 19:48:17 --> Security Class Initialized
DEBUG - 2017-02-15 19:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 19:48:17 --> Input Class Initialized
INFO - 2017-02-15 19:48:17 --> Language Class Initialized
INFO - 2017-02-15 19:48:17 --> Loader Class Initialized
INFO - 2017-02-15 19:48:17 --> Database Driver Class Initialized
INFO - 2017-02-15 19:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 19:48:17 --> Controller Class Initialized
INFO - 2017-02-15 19:48:17 --> Helper loaded: url_helper
DEBUG - 2017-02-15 19:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 19:48:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 19:48:17 --> Final output sent to browser
DEBUG - 2017-02-15 19:48:17 --> Total execution time: 0.0203
INFO - 2017-02-15 20:01:07 --> Config Class Initialized
INFO - 2017-02-15 20:01:07 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:01:07 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:01:07 --> Utf8 Class Initialized
INFO - 2017-02-15 20:01:07 --> URI Class Initialized
DEBUG - 2017-02-15 20:01:07 --> No URI present. Default controller set.
INFO - 2017-02-15 20:01:07 --> Router Class Initialized
INFO - 2017-02-15 20:01:07 --> Output Class Initialized
INFO - 2017-02-15 20:01:07 --> Security Class Initialized
DEBUG - 2017-02-15 20:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:01:07 --> Input Class Initialized
INFO - 2017-02-15 20:01:07 --> Language Class Initialized
INFO - 2017-02-15 20:01:07 --> Loader Class Initialized
INFO - 2017-02-15 20:01:07 --> Database Driver Class Initialized
INFO - 2017-02-15 20:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:01:07 --> Controller Class Initialized
INFO - 2017-02-15 20:01:07 --> Helper loaded: url_helper
DEBUG - 2017-02-15 20:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 20:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 20:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 20:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 20:01:07 --> Final output sent to browser
DEBUG - 2017-02-15 20:01:07 --> Total execution time: 0.0131
INFO - 2017-02-15 20:55:00 --> Config Class Initialized
INFO - 2017-02-15 20:55:00 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:55:00 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:55:00 --> Utf8 Class Initialized
INFO - 2017-02-15 20:55:00 --> URI Class Initialized
DEBUG - 2017-02-15 20:55:00 --> No URI present. Default controller set.
INFO - 2017-02-15 20:55:00 --> Router Class Initialized
INFO - 2017-02-15 20:55:00 --> Output Class Initialized
INFO - 2017-02-15 20:55:00 --> Security Class Initialized
DEBUG - 2017-02-15 20:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:55:00 --> Input Class Initialized
INFO - 2017-02-15 20:55:00 --> Language Class Initialized
INFO - 2017-02-15 20:55:00 --> Loader Class Initialized
INFO - 2017-02-15 20:55:00 --> Database Driver Class Initialized
INFO - 2017-02-15 20:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:55:00 --> Controller Class Initialized
INFO - 2017-02-15 20:55:00 --> Helper loaded: url_helper
DEBUG - 2017-02-15 20:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 20:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 20:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 20:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 20:55:00 --> Final output sent to browser
DEBUG - 2017-02-15 20:55:00 --> Total execution time: 0.0142
INFO - 2017-02-15 20:55:15 --> Config Class Initialized
INFO - 2017-02-15 20:55:15 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:55:15 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:55:15 --> Utf8 Class Initialized
INFO - 2017-02-15 20:55:15 --> URI Class Initialized
INFO - 2017-02-15 20:55:15 --> Router Class Initialized
INFO - 2017-02-15 20:55:15 --> Output Class Initialized
INFO - 2017-02-15 20:55:15 --> Security Class Initialized
DEBUG - 2017-02-15 20:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:55:15 --> Input Class Initialized
INFO - 2017-02-15 20:55:15 --> Language Class Initialized
INFO - 2017-02-15 20:55:15 --> Loader Class Initialized
INFO - 2017-02-15 20:55:15 --> Database Driver Class Initialized
INFO - 2017-02-15 20:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:55:15 --> Controller Class Initialized
INFO - 2017-02-15 20:55:15 --> Helper loaded: url_helper
DEBUG - 2017-02-15 20:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 20:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 20:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 20:55:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 20:55:15 --> Final output sent to browser
DEBUG - 2017-02-15 20:55:15 --> Total execution time: 0.0132
INFO - 2017-02-15 20:55:28 --> Config Class Initialized
INFO - 2017-02-15 20:55:28 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:55:28 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:55:28 --> Utf8 Class Initialized
INFO - 2017-02-15 20:55:28 --> URI Class Initialized
INFO - 2017-02-15 20:55:28 --> Router Class Initialized
INFO - 2017-02-15 20:55:28 --> Output Class Initialized
INFO - 2017-02-15 20:55:28 --> Security Class Initialized
DEBUG - 2017-02-15 20:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:55:28 --> Input Class Initialized
INFO - 2017-02-15 20:55:28 --> Language Class Initialized
INFO - 2017-02-15 20:55:28 --> Loader Class Initialized
INFO - 2017-02-15 20:55:28 --> Database Driver Class Initialized
INFO - 2017-02-15 20:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:55:28 --> Controller Class Initialized
INFO - 2017-02-15 20:55:28 --> Helper loaded: url_helper
DEBUG - 2017-02-15 20:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:55:29 --> Config Class Initialized
INFO - 2017-02-15 20:55:29 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:55:29 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:55:29 --> Utf8 Class Initialized
INFO - 2017-02-15 20:55:29 --> URI Class Initialized
INFO - 2017-02-15 20:55:29 --> Router Class Initialized
INFO - 2017-02-15 20:55:29 --> Output Class Initialized
INFO - 2017-02-15 20:55:29 --> Security Class Initialized
DEBUG - 2017-02-15 20:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:55:29 --> Input Class Initialized
INFO - 2017-02-15 20:55:29 --> Language Class Initialized
INFO - 2017-02-15 20:55:29 --> Loader Class Initialized
INFO - 2017-02-15 20:55:29 --> Database Driver Class Initialized
INFO - 2017-02-15 20:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:55:29 --> Controller Class Initialized
INFO - 2017-02-15 20:55:29 --> Helper loaded: date_helper
DEBUG - 2017-02-15 20:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:55:29 --> Helper loaded: url_helper
INFO - 2017-02-15 20:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 20:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 20:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 20:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 20:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 20:55:29 --> Final output sent to browser
DEBUG - 2017-02-15 20:55:29 --> Total execution time: 0.0139
INFO - 2017-02-15 20:55:30 --> Config Class Initialized
INFO - 2017-02-15 20:55:30 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:55:30 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:55:30 --> Utf8 Class Initialized
INFO - 2017-02-15 20:55:30 --> URI Class Initialized
INFO - 2017-02-15 20:55:30 --> Router Class Initialized
INFO - 2017-02-15 20:55:30 --> Output Class Initialized
INFO - 2017-02-15 20:55:30 --> Security Class Initialized
DEBUG - 2017-02-15 20:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:55:30 --> Input Class Initialized
INFO - 2017-02-15 20:55:30 --> Language Class Initialized
INFO - 2017-02-15 20:55:30 --> Loader Class Initialized
INFO - 2017-02-15 20:55:30 --> Database Driver Class Initialized
INFO - 2017-02-15 20:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:55:30 --> Controller Class Initialized
INFO - 2017-02-15 20:55:30 --> Helper loaded: url_helper
DEBUG - 2017-02-15 20:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 20:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 20:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 20:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 20:55:30 --> Final output sent to browser
DEBUG - 2017-02-15 20:55:30 --> Total execution time: 0.0133
INFO - 2017-02-15 20:55:35 --> Config Class Initialized
INFO - 2017-02-15 20:55:35 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:55:35 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:55:35 --> Utf8 Class Initialized
INFO - 2017-02-15 20:55:35 --> URI Class Initialized
DEBUG - 2017-02-15 20:55:35 --> No URI present. Default controller set.
INFO - 2017-02-15 20:55:35 --> Router Class Initialized
INFO - 2017-02-15 20:55:35 --> Output Class Initialized
INFO - 2017-02-15 20:55:35 --> Security Class Initialized
DEBUG - 2017-02-15 20:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:55:35 --> Input Class Initialized
INFO - 2017-02-15 20:55:35 --> Language Class Initialized
INFO - 2017-02-15 20:55:35 --> Loader Class Initialized
INFO - 2017-02-15 20:55:35 --> Database Driver Class Initialized
INFO - 2017-02-15 20:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:55:35 --> Controller Class Initialized
INFO - 2017-02-15 20:55:35 --> Helper loaded: url_helper
DEBUG - 2017-02-15 20:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 20:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 20:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 20:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 20:55:35 --> Final output sent to browser
DEBUG - 2017-02-15 20:55:35 --> Total execution time: 0.0137
INFO - 2017-02-15 20:55:36 --> Config Class Initialized
INFO - 2017-02-15 20:55:36 --> Hooks Class Initialized
DEBUG - 2017-02-15 20:55:36 --> UTF-8 Support Enabled
INFO - 2017-02-15 20:55:36 --> Utf8 Class Initialized
INFO - 2017-02-15 20:55:36 --> URI Class Initialized
INFO - 2017-02-15 20:55:36 --> Router Class Initialized
INFO - 2017-02-15 20:55:36 --> Output Class Initialized
INFO - 2017-02-15 20:55:36 --> Security Class Initialized
DEBUG - 2017-02-15 20:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 20:55:36 --> Input Class Initialized
INFO - 2017-02-15 20:55:36 --> Language Class Initialized
INFO - 2017-02-15 20:55:36 --> Loader Class Initialized
INFO - 2017-02-15 20:55:36 --> Database Driver Class Initialized
INFO - 2017-02-15 20:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 20:55:36 --> Controller Class Initialized
INFO - 2017-02-15 20:55:36 --> Helper loaded: url_helper
DEBUG - 2017-02-15 20:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 20:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 20:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 20:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 20:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 20:55:36 --> Final output sent to browser
DEBUG - 2017-02-15 20:55:36 --> Total execution time: 0.0150
INFO - 2017-02-15 22:34:14 --> Config Class Initialized
INFO - 2017-02-15 22:34:14 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:34:14 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:34:14 --> Utf8 Class Initialized
INFO - 2017-02-15 22:34:14 --> URI Class Initialized
INFO - 2017-02-15 22:34:14 --> Router Class Initialized
INFO - 2017-02-15 22:34:14 --> Output Class Initialized
INFO - 2017-02-15 22:34:14 --> Security Class Initialized
DEBUG - 2017-02-15 22:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:34:14 --> Input Class Initialized
INFO - 2017-02-15 22:34:14 --> Language Class Initialized
INFO - 2017-02-15 22:34:14 --> Loader Class Initialized
INFO - 2017-02-15 22:34:14 --> Database Driver Class Initialized
INFO - 2017-02-15 22:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:34:14 --> Controller Class Initialized
INFO - 2017-02-15 22:34:14 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:34:14 --> Final output sent to browser
DEBUG - 2017-02-15 22:34:14 --> Total execution time: 0.0420
INFO - 2017-02-15 22:34:15 --> Config Class Initialized
INFO - 2017-02-15 22:34:15 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:34:15 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:34:15 --> Utf8 Class Initialized
INFO - 2017-02-15 22:34:15 --> URI Class Initialized
INFO - 2017-02-15 22:34:15 --> Router Class Initialized
INFO - 2017-02-15 22:34:15 --> Output Class Initialized
INFO - 2017-02-15 22:34:15 --> Security Class Initialized
DEBUG - 2017-02-15 22:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:34:15 --> Input Class Initialized
INFO - 2017-02-15 22:34:15 --> Language Class Initialized
INFO - 2017-02-15 22:34:15 --> Loader Class Initialized
INFO - 2017-02-15 22:34:15 --> Database Driver Class Initialized
INFO - 2017-02-15 22:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:34:15 --> Controller Class Initialized
INFO - 2017-02-15 22:34:15 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:34:15 --> Final output sent to browser
DEBUG - 2017-02-15 22:34:15 --> Total execution time: 0.0136
INFO - 2017-02-15 22:34:16 --> Config Class Initialized
INFO - 2017-02-15 22:34:16 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:34:16 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:34:16 --> Utf8 Class Initialized
INFO - 2017-02-15 22:34:16 --> URI Class Initialized
DEBUG - 2017-02-15 22:34:16 --> No URI present. Default controller set.
INFO - 2017-02-15 22:34:16 --> Router Class Initialized
INFO - 2017-02-15 22:34:16 --> Output Class Initialized
INFO - 2017-02-15 22:34:16 --> Security Class Initialized
DEBUG - 2017-02-15 22:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:34:16 --> Input Class Initialized
INFO - 2017-02-15 22:34:16 --> Language Class Initialized
INFO - 2017-02-15 22:34:16 --> Loader Class Initialized
INFO - 2017-02-15 22:34:16 --> Database Driver Class Initialized
INFO - 2017-02-15 22:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:34:16 --> Controller Class Initialized
INFO - 2017-02-15 22:34:16 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:34:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:34:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:34:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:34:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:34:16 --> Final output sent to browser
DEBUG - 2017-02-15 22:34:16 --> Total execution time: 0.0132
INFO - 2017-02-15 22:34:16 --> Config Class Initialized
INFO - 2017-02-15 22:34:16 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:34:16 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:34:16 --> Utf8 Class Initialized
INFO - 2017-02-15 22:34:16 --> URI Class Initialized
INFO - 2017-02-15 22:34:16 --> Router Class Initialized
INFO - 2017-02-15 22:34:16 --> Output Class Initialized
INFO - 2017-02-15 22:34:16 --> Security Class Initialized
DEBUG - 2017-02-15 22:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:34:16 --> Input Class Initialized
INFO - 2017-02-15 22:34:16 --> Language Class Initialized
ERROR - 2017-02-15 22:34:16 --> 404 Page Not Found: Blog/robots.txt
INFO - 2017-02-15 22:34:17 --> Config Class Initialized
INFO - 2017-02-15 22:34:17 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:34:17 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:34:17 --> Utf8 Class Initialized
INFO - 2017-02-15 22:34:17 --> URI Class Initialized
INFO - 2017-02-15 22:34:17 --> Router Class Initialized
INFO - 2017-02-15 22:34:17 --> Output Class Initialized
INFO - 2017-02-15 22:34:17 --> Security Class Initialized
DEBUG - 2017-02-15 22:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:34:17 --> Input Class Initialized
INFO - 2017-02-15 22:34:17 --> Language Class Initialized
INFO - 2017-02-15 22:34:17 --> Loader Class Initialized
INFO - 2017-02-15 22:34:17 --> Database Driver Class Initialized
INFO - 2017-02-15 22:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:34:17 --> Controller Class Initialized
INFO - 2017-02-15 22:34:17 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:34:17 --> Final output sent to browser
DEBUG - 2017-02-15 22:34:17 --> Total execution time: 0.0134
INFO - 2017-02-15 22:34:17 --> Config Class Initialized
INFO - 2017-02-15 22:34:17 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:34:17 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:34:17 --> Utf8 Class Initialized
INFO - 2017-02-15 22:34:17 --> URI Class Initialized
INFO - 2017-02-15 22:34:17 --> Router Class Initialized
INFO - 2017-02-15 22:34:17 --> Output Class Initialized
INFO - 2017-02-15 22:34:17 --> Security Class Initialized
DEBUG - 2017-02-15 22:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:34:17 --> Input Class Initialized
INFO - 2017-02-15 22:34:17 --> Language Class Initialized
INFO - 2017-02-15 22:34:17 --> Loader Class Initialized
INFO - 2017-02-15 22:34:17 --> Database Driver Class Initialized
INFO - 2017-02-15 22:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:34:17 --> Controller Class Initialized
INFO - 2017-02-15 22:34:17 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:34:17 --> Final output sent to browser
DEBUG - 2017-02-15 22:34:17 --> Total execution time: 0.0157
INFO - 2017-02-15 22:34:18 --> Config Class Initialized
INFO - 2017-02-15 22:34:18 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:34:18 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:34:18 --> Utf8 Class Initialized
INFO - 2017-02-15 22:34:18 --> URI Class Initialized
INFO - 2017-02-15 22:34:18 --> Router Class Initialized
INFO - 2017-02-15 22:34:18 --> Output Class Initialized
INFO - 2017-02-15 22:34:18 --> Security Class Initialized
DEBUG - 2017-02-15 22:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:34:18 --> Input Class Initialized
INFO - 2017-02-15 22:34:18 --> Language Class Initialized
INFO - 2017-02-15 22:34:18 --> Loader Class Initialized
INFO - 2017-02-15 22:34:18 --> Database Driver Class Initialized
INFO - 2017-02-15 22:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:34:18 --> Controller Class Initialized
INFO - 2017-02-15 22:34:18 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:34:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:34:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:34:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:34:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:34:18 --> Final output sent to browser
DEBUG - 2017-02-15 22:34:18 --> Total execution time: 0.0151
INFO - 2017-02-15 22:43:59 --> Config Class Initialized
INFO - 2017-02-15 22:43:59 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:43:59 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:43:59 --> Utf8 Class Initialized
INFO - 2017-02-15 22:43:59 --> URI Class Initialized
INFO - 2017-02-15 22:43:59 --> Router Class Initialized
INFO - 2017-02-15 22:43:59 --> Output Class Initialized
INFO - 2017-02-15 22:43:59 --> Security Class Initialized
DEBUG - 2017-02-15 22:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:43:59 --> Input Class Initialized
INFO - 2017-02-15 22:43:59 --> Language Class Initialized
INFO - 2017-02-15 22:43:59 --> Loader Class Initialized
INFO - 2017-02-15 22:43:59 --> Database Driver Class Initialized
INFO - 2017-02-15 22:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:43:59 --> Controller Class Initialized
INFO - 2017-02-15 22:43:59 --> Helper loaded: date_helper
DEBUG - 2017-02-15 22:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:43:59 --> Helper loaded: url_helper
INFO - 2017-02-15 22:43:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:43:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 22:43:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 22:43:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 22:43:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:43:59 --> Final output sent to browser
DEBUG - 2017-02-15 22:43:59 --> Total execution time: 0.0140
INFO - 2017-02-15 22:44:06 --> Config Class Initialized
INFO - 2017-02-15 22:44:06 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:44:06 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:44:06 --> Utf8 Class Initialized
INFO - 2017-02-15 22:44:06 --> URI Class Initialized
INFO - 2017-02-15 22:44:06 --> Router Class Initialized
INFO - 2017-02-15 22:44:06 --> Output Class Initialized
INFO - 2017-02-15 22:44:06 --> Security Class Initialized
DEBUG - 2017-02-15 22:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:44:06 --> Input Class Initialized
INFO - 2017-02-15 22:44:06 --> Language Class Initialized
INFO - 2017-02-15 22:44:06 --> Loader Class Initialized
INFO - 2017-02-15 22:44:06 --> Database Driver Class Initialized
INFO - 2017-02-15 22:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:44:06 --> Controller Class Initialized
INFO - 2017-02-15 22:44:06 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:44:06 --> Final output sent to browser
DEBUG - 2017-02-15 22:44:06 --> Total execution time: 0.0145
INFO - 2017-02-15 22:48:01 --> Config Class Initialized
INFO - 2017-02-15 22:48:01 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:48:01 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:48:01 --> Utf8 Class Initialized
INFO - 2017-02-15 22:48:01 --> URI Class Initialized
INFO - 2017-02-15 22:48:01 --> Router Class Initialized
INFO - 2017-02-15 22:48:01 --> Output Class Initialized
INFO - 2017-02-15 22:48:01 --> Security Class Initialized
DEBUG - 2017-02-15 22:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:48:01 --> Input Class Initialized
INFO - 2017-02-15 22:48:01 --> Language Class Initialized
INFO - 2017-02-15 22:48:01 --> Loader Class Initialized
INFO - 2017-02-15 22:48:01 --> Database Driver Class Initialized
INFO - 2017-02-15 22:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:48:01 --> Controller Class Initialized
INFO - 2017-02-15 22:48:01 --> Helper loaded: date_helper
DEBUG - 2017-02-15 22:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:48:01 --> Helper loaded: url_helper
INFO - 2017-02-15 22:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 22:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 22:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 22:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:48:01 --> Final output sent to browser
DEBUG - 2017-02-15 22:48:01 --> Total execution time: 0.0146
INFO - 2017-02-15 22:48:05 --> Config Class Initialized
INFO - 2017-02-15 22:48:05 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:48:05 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:48:05 --> Utf8 Class Initialized
INFO - 2017-02-15 22:48:05 --> URI Class Initialized
INFO - 2017-02-15 22:48:05 --> Router Class Initialized
INFO - 2017-02-15 22:48:05 --> Output Class Initialized
INFO - 2017-02-15 22:48:05 --> Security Class Initialized
DEBUG - 2017-02-15 22:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:48:05 --> Input Class Initialized
INFO - 2017-02-15 22:48:05 --> Language Class Initialized
INFO - 2017-02-15 22:48:05 --> Loader Class Initialized
INFO - 2017-02-15 22:48:05 --> Database Driver Class Initialized
INFO - 2017-02-15 22:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:48:05 --> Controller Class Initialized
INFO - 2017-02-15 22:48:05 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:48:05 --> Final output sent to browser
DEBUG - 2017-02-15 22:48:05 --> Total execution time: 0.0152
INFO - 2017-02-15 22:48:24 --> Config Class Initialized
INFO - 2017-02-15 22:48:24 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:48:24 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:48:24 --> Utf8 Class Initialized
INFO - 2017-02-15 22:48:24 --> URI Class Initialized
INFO - 2017-02-15 22:48:24 --> Router Class Initialized
INFO - 2017-02-15 22:48:24 --> Output Class Initialized
INFO - 2017-02-15 22:48:24 --> Security Class Initialized
DEBUG - 2017-02-15 22:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:48:24 --> Input Class Initialized
INFO - 2017-02-15 22:48:24 --> Language Class Initialized
INFO - 2017-02-15 22:48:24 --> Loader Class Initialized
INFO - 2017-02-15 22:48:24 --> Database Driver Class Initialized
INFO - 2017-02-15 22:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:48:24 --> Controller Class Initialized
INFO - 2017-02-15 22:48:24 --> Helper loaded: date_helper
DEBUG - 2017-02-15 22:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:48:24 --> Helper loaded: url_helper
INFO - 2017-02-15 22:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-15 22:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-15 22:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-15 22:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:48:24 --> Final output sent to browser
DEBUG - 2017-02-15 22:48:24 --> Total execution time: 0.0136
INFO - 2017-02-15 22:48:26 --> Config Class Initialized
INFO - 2017-02-15 22:48:26 --> Hooks Class Initialized
DEBUG - 2017-02-15 22:48:26 --> UTF-8 Support Enabled
INFO - 2017-02-15 22:48:26 --> Utf8 Class Initialized
INFO - 2017-02-15 22:48:26 --> URI Class Initialized
INFO - 2017-02-15 22:48:26 --> Router Class Initialized
INFO - 2017-02-15 22:48:26 --> Output Class Initialized
INFO - 2017-02-15 22:48:26 --> Security Class Initialized
DEBUG - 2017-02-15 22:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 22:48:26 --> Input Class Initialized
INFO - 2017-02-15 22:48:26 --> Language Class Initialized
INFO - 2017-02-15 22:48:26 --> Loader Class Initialized
INFO - 2017-02-15 22:48:26 --> Database Driver Class Initialized
INFO - 2017-02-15 22:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 22:48:26 --> Controller Class Initialized
INFO - 2017-02-15 22:48:26 --> Helper loaded: url_helper
DEBUG - 2017-02-15 22:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 22:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 22:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 22:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 22:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 22:48:26 --> Final output sent to browser
DEBUG - 2017-02-15 22:48:26 --> Total execution time: 0.0137
INFO - 2017-02-15 23:27:10 --> Config Class Initialized
INFO - 2017-02-15 23:27:10 --> Hooks Class Initialized
DEBUG - 2017-02-15 23:27:10 --> UTF-8 Support Enabled
INFO - 2017-02-15 23:27:10 --> Utf8 Class Initialized
INFO - 2017-02-15 23:27:10 --> URI Class Initialized
INFO - 2017-02-15 23:27:10 --> Router Class Initialized
INFO - 2017-02-15 23:27:10 --> Output Class Initialized
INFO - 2017-02-15 23:27:10 --> Security Class Initialized
DEBUG - 2017-02-15 23:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 23:27:10 --> Input Class Initialized
INFO - 2017-02-15 23:27:10 --> Language Class Initialized
ERROR - 2017-02-15 23:27:10 --> 404 Page Not Found: Unprotected/loader.html
INFO - 2017-02-15 23:40:09 --> Config Class Initialized
INFO - 2017-02-15 23:40:09 --> Hooks Class Initialized
DEBUG - 2017-02-15 23:40:09 --> UTF-8 Support Enabled
INFO - 2017-02-15 23:40:09 --> Utf8 Class Initialized
INFO - 2017-02-15 23:40:09 --> URI Class Initialized
DEBUG - 2017-02-15 23:40:09 --> No URI present. Default controller set.
INFO - 2017-02-15 23:40:09 --> Router Class Initialized
INFO - 2017-02-15 23:40:09 --> Output Class Initialized
INFO - 2017-02-15 23:40:09 --> Security Class Initialized
DEBUG - 2017-02-15 23:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 23:40:09 --> Input Class Initialized
INFO - 2017-02-15 23:40:09 --> Language Class Initialized
INFO - 2017-02-15 23:40:09 --> Loader Class Initialized
INFO - 2017-02-15 23:40:09 --> Database Driver Class Initialized
INFO - 2017-02-15 23:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 23:40:09 --> Controller Class Initialized
INFO - 2017-02-15 23:40:09 --> Helper loaded: url_helper
DEBUG - 2017-02-15 23:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 23:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 23:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 23:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 23:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 23:40:09 --> Final output sent to browser
DEBUG - 2017-02-15 23:40:09 --> Total execution time: 0.0145
INFO - 2017-02-15 23:40:11 --> Config Class Initialized
INFO - 2017-02-15 23:40:11 --> Hooks Class Initialized
DEBUG - 2017-02-15 23:40:11 --> UTF-8 Support Enabled
INFO - 2017-02-15 23:40:11 --> Utf8 Class Initialized
INFO - 2017-02-15 23:40:11 --> URI Class Initialized
INFO - 2017-02-15 23:40:11 --> Router Class Initialized
INFO - 2017-02-15 23:40:11 --> Output Class Initialized
INFO - 2017-02-15 23:40:11 --> Security Class Initialized
DEBUG - 2017-02-15 23:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 23:40:11 --> Input Class Initialized
INFO - 2017-02-15 23:40:11 --> Language Class Initialized
INFO - 2017-02-15 23:40:11 --> Loader Class Initialized
INFO - 2017-02-15 23:40:11 --> Database Driver Class Initialized
INFO - 2017-02-15 23:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 23:40:11 --> Controller Class Initialized
INFO - 2017-02-15 23:40:11 --> Helper loaded: url_helper
DEBUG - 2017-02-15 23:40:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 23:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 23:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 23:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 23:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 23:40:11 --> Final output sent to browser
DEBUG - 2017-02-15 23:40:11 --> Total execution time: 0.0138
INFO - 2017-02-15 23:40:37 --> Config Class Initialized
INFO - 2017-02-15 23:40:37 --> Hooks Class Initialized
DEBUG - 2017-02-15 23:40:37 --> UTF-8 Support Enabled
INFO - 2017-02-15 23:40:37 --> Utf8 Class Initialized
INFO - 2017-02-15 23:40:37 --> URI Class Initialized
INFO - 2017-02-15 23:40:37 --> Router Class Initialized
INFO - 2017-02-15 23:40:37 --> Output Class Initialized
INFO - 2017-02-15 23:40:37 --> Security Class Initialized
DEBUG - 2017-02-15 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 23:40:37 --> Input Class Initialized
INFO - 2017-02-15 23:40:37 --> Language Class Initialized
INFO - 2017-02-15 23:40:37 --> Loader Class Initialized
INFO - 2017-02-15 23:40:37 --> Database Driver Class Initialized
INFO - 2017-02-15 23:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 23:40:37 --> Controller Class Initialized
INFO - 2017-02-15 23:40:37 --> Helper loaded: url_helper
DEBUG - 2017-02-15 23:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 23:40:37 --> Final output sent to browser
DEBUG - 2017-02-15 23:40:37 --> Total execution time: 0.0142
INFO - 2017-02-15 23:40:38 --> Config Class Initialized
INFO - 2017-02-15 23:40:38 --> Hooks Class Initialized
DEBUG - 2017-02-15 23:40:38 --> UTF-8 Support Enabled
INFO - 2017-02-15 23:40:38 --> Utf8 Class Initialized
INFO - 2017-02-15 23:40:38 --> URI Class Initialized
INFO - 2017-02-15 23:40:38 --> Router Class Initialized
INFO - 2017-02-15 23:40:38 --> Output Class Initialized
INFO - 2017-02-15 23:40:38 --> Security Class Initialized
DEBUG - 2017-02-15 23:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-15 23:40:38 --> Input Class Initialized
INFO - 2017-02-15 23:40:38 --> Language Class Initialized
INFO - 2017-02-15 23:40:38 --> Loader Class Initialized
INFO - 2017-02-15 23:40:38 --> Database Driver Class Initialized
INFO - 2017-02-15 23:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-15 23:40:38 --> Controller Class Initialized
INFO - 2017-02-15 23:40:38 --> Helper loaded: url_helper
DEBUG - 2017-02-15 23:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-15 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-15 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-15 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-15 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-15 23:40:38 --> Final output sent to browser
DEBUG - 2017-02-15 23:40:38 --> Total execution time: 0.0136

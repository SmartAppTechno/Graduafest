<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-20 00:20:49 --> Config Class Initialized
INFO - 2017-02-20 00:20:49 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:20:49 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:20:49 --> Utf8 Class Initialized
INFO - 2017-02-20 00:20:49 --> URI Class Initialized
DEBUG - 2017-02-20 00:20:49 --> No URI present. Default controller set.
INFO - 2017-02-20 00:20:49 --> Router Class Initialized
INFO - 2017-02-20 00:20:49 --> Output Class Initialized
INFO - 2017-02-20 00:20:49 --> Security Class Initialized
DEBUG - 2017-02-20 00:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:20:49 --> Input Class Initialized
INFO - 2017-02-20 00:20:49 --> Language Class Initialized
INFO - 2017-02-20 00:20:49 --> Loader Class Initialized
INFO - 2017-02-20 00:20:49 --> Database Driver Class Initialized
INFO - 2017-02-20 00:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:20:49 --> Controller Class Initialized
INFO - 2017-02-20 00:20:49 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:20:49 --> Final output sent to browser
DEBUG - 2017-02-20 00:20:49 --> Total execution time: 0.0148
INFO - 2017-02-20 00:20:53 --> Config Class Initialized
INFO - 2017-02-20 00:20:53 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:20:53 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:20:53 --> Utf8 Class Initialized
INFO - 2017-02-20 00:20:53 --> URI Class Initialized
INFO - 2017-02-20 00:20:53 --> Router Class Initialized
INFO - 2017-02-20 00:20:53 --> Output Class Initialized
INFO - 2017-02-20 00:20:53 --> Security Class Initialized
DEBUG - 2017-02-20 00:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:20:53 --> Input Class Initialized
INFO - 2017-02-20 00:20:53 --> Language Class Initialized
INFO - 2017-02-20 00:20:53 --> Loader Class Initialized
INFO - 2017-02-20 00:20:53 --> Database Driver Class Initialized
INFO - 2017-02-20 00:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:20:53 --> Controller Class Initialized
INFO - 2017-02-20 00:20:53 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:20:53 --> Final output sent to browser
DEBUG - 2017-02-20 00:20:53 --> Total execution time: 0.0141
INFO - 2017-02-20 00:21:39 --> Config Class Initialized
INFO - 2017-02-20 00:21:39 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:21:39 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:21:39 --> Utf8 Class Initialized
INFO - 2017-02-20 00:21:39 --> URI Class Initialized
DEBUG - 2017-02-20 00:21:39 --> No URI present. Default controller set.
INFO - 2017-02-20 00:21:39 --> Router Class Initialized
INFO - 2017-02-20 00:21:39 --> Output Class Initialized
INFO - 2017-02-20 00:21:39 --> Security Class Initialized
DEBUG - 2017-02-20 00:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:21:39 --> Input Class Initialized
INFO - 2017-02-20 00:21:39 --> Language Class Initialized
INFO - 2017-02-20 00:21:39 --> Loader Class Initialized
INFO - 2017-02-20 00:21:39 --> Database Driver Class Initialized
INFO - 2017-02-20 00:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:21:39 --> Controller Class Initialized
INFO - 2017-02-20 00:21:39 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:21:39 --> Final output sent to browser
DEBUG - 2017-02-20 00:21:39 --> Total execution time: 0.0128
INFO - 2017-02-20 00:21:42 --> Config Class Initialized
INFO - 2017-02-20 00:21:42 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:21:42 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:21:42 --> Utf8 Class Initialized
INFO - 2017-02-20 00:21:42 --> URI Class Initialized
INFO - 2017-02-20 00:21:42 --> Router Class Initialized
INFO - 2017-02-20 00:21:42 --> Output Class Initialized
INFO - 2017-02-20 00:21:42 --> Security Class Initialized
DEBUG - 2017-02-20 00:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:21:42 --> Input Class Initialized
INFO - 2017-02-20 00:21:42 --> Language Class Initialized
INFO - 2017-02-20 00:21:42 --> Loader Class Initialized
INFO - 2017-02-20 00:21:42 --> Database Driver Class Initialized
INFO - 2017-02-20 00:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:21:42 --> Controller Class Initialized
INFO - 2017-02-20 00:21:42 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:21:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:21:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:21:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:21:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:21:42 --> Final output sent to browser
DEBUG - 2017-02-20 00:21:42 --> Total execution time: 0.0137
INFO - 2017-02-20 00:22:10 --> Config Class Initialized
INFO - 2017-02-20 00:22:10 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:22:10 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:22:10 --> Utf8 Class Initialized
INFO - 2017-02-20 00:22:10 --> URI Class Initialized
DEBUG - 2017-02-20 00:22:10 --> No URI present. Default controller set.
INFO - 2017-02-20 00:22:10 --> Router Class Initialized
INFO - 2017-02-20 00:22:10 --> Output Class Initialized
INFO - 2017-02-20 00:22:10 --> Security Class Initialized
DEBUG - 2017-02-20 00:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:22:10 --> Input Class Initialized
INFO - 2017-02-20 00:22:10 --> Language Class Initialized
INFO - 2017-02-20 00:22:10 --> Loader Class Initialized
INFO - 2017-02-20 00:22:10 --> Database Driver Class Initialized
INFO - 2017-02-20 00:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:22:10 --> Controller Class Initialized
INFO - 2017-02-20 00:22:10 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:22:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:22:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:22:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:22:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:22:10 --> Final output sent to browser
DEBUG - 2017-02-20 00:22:10 --> Total execution time: 0.0135
INFO - 2017-02-20 00:22:13 --> Config Class Initialized
INFO - 2017-02-20 00:22:13 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:22:13 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:22:13 --> Utf8 Class Initialized
INFO - 2017-02-20 00:22:13 --> URI Class Initialized
INFO - 2017-02-20 00:22:13 --> Router Class Initialized
INFO - 2017-02-20 00:22:13 --> Output Class Initialized
INFO - 2017-02-20 00:22:13 --> Security Class Initialized
DEBUG - 2017-02-20 00:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:22:13 --> Input Class Initialized
INFO - 2017-02-20 00:22:13 --> Language Class Initialized
INFO - 2017-02-20 00:22:13 --> Loader Class Initialized
INFO - 2017-02-20 00:22:13 --> Database Driver Class Initialized
INFO - 2017-02-20 00:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:22:13 --> Controller Class Initialized
INFO - 2017-02-20 00:22:13 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:22:13 --> Final output sent to browser
DEBUG - 2017-02-20 00:22:13 --> Total execution time: 0.0137
INFO - 2017-02-20 00:23:27 --> Config Class Initialized
INFO - 2017-02-20 00:23:27 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:23:27 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:23:27 --> Utf8 Class Initialized
INFO - 2017-02-20 00:23:27 --> URI Class Initialized
INFO - 2017-02-20 00:23:27 --> Router Class Initialized
INFO - 2017-02-20 00:23:27 --> Output Class Initialized
INFO - 2017-02-20 00:23:27 --> Security Class Initialized
DEBUG - 2017-02-20 00:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:23:27 --> Input Class Initialized
INFO - 2017-02-20 00:23:27 --> Language Class Initialized
INFO - 2017-02-20 00:23:27 --> Loader Class Initialized
INFO - 2017-02-20 00:23:27 --> Database Driver Class Initialized
INFO - 2017-02-20 00:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:23:27 --> Controller Class Initialized
INFO - 2017-02-20 00:23:27 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-20 00:23:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-20 00:23:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-20 00:23:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-20 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:23:27 --> Final output sent to browser
DEBUG - 2017-02-20 00:23:27 --> Total execution time: 0.0142
INFO - 2017-02-20 00:23:29 --> Config Class Initialized
INFO - 2017-02-20 00:23:29 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:23:29 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:23:29 --> Utf8 Class Initialized
INFO - 2017-02-20 00:23:29 --> URI Class Initialized
INFO - 2017-02-20 00:23:29 --> Router Class Initialized
INFO - 2017-02-20 00:23:29 --> Output Class Initialized
INFO - 2017-02-20 00:23:29 --> Security Class Initialized
DEBUG - 2017-02-20 00:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:23:29 --> Input Class Initialized
INFO - 2017-02-20 00:23:29 --> Language Class Initialized
INFO - 2017-02-20 00:23:29 --> Loader Class Initialized
INFO - 2017-02-20 00:23:29 --> Database Driver Class Initialized
INFO - 2017-02-20 00:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:23:29 --> Controller Class Initialized
INFO - 2017-02-20 00:23:29 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:23:29 --> Final output sent to browser
DEBUG - 2017-02-20 00:23:29 --> Total execution time: 0.0133
INFO - 2017-02-20 00:32:26 --> Config Class Initialized
INFO - 2017-02-20 00:32:26 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:32:26 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:32:26 --> Utf8 Class Initialized
INFO - 2017-02-20 00:32:26 --> URI Class Initialized
DEBUG - 2017-02-20 00:32:26 --> No URI present. Default controller set.
INFO - 2017-02-20 00:32:26 --> Router Class Initialized
INFO - 2017-02-20 00:32:26 --> Output Class Initialized
INFO - 2017-02-20 00:32:26 --> Security Class Initialized
DEBUG - 2017-02-20 00:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:32:26 --> Input Class Initialized
INFO - 2017-02-20 00:32:26 --> Language Class Initialized
INFO - 2017-02-20 00:32:26 --> Loader Class Initialized
INFO - 2017-02-20 00:32:26 --> Database Driver Class Initialized
INFO - 2017-02-20 00:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:32:26 --> Controller Class Initialized
INFO - 2017-02-20 00:32:26 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:32:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:32:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:32:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:32:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:32:26 --> Final output sent to browser
DEBUG - 2017-02-20 00:32:26 --> Total execution time: 0.0132
INFO - 2017-02-20 00:32:29 --> Config Class Initialized
INFO - 2017-02-20 00:32:29 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:32:29 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:32:29 --> Utf8 Class Initialized
INFO - 2017-02-20 00:32:29 --> URI Class Initialized
INFO - 2017-02-20 00:32:29 --> Router Class Initialized
INFO - 2017-02-20 00:32:29 --> Output Class Initialized
INFO - 2017-02-20 00:32:29 --> Security Class Initialized
DEBUG - 2017-02-20 00:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:32:29 --> Input Class Initialized
INFO - 2017-02-20 00:32:29 --> Language Class Initialized
INFO - 2017-02-20 00:32:29 --> Loader Class Initialized
INFO - 2017-02-20 00:32:29 --> Database Driver Class Initialized
INFO - 2017-02-20 00:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:32:29 --> Controller Class Initialized
INFO - 2017-02-20 00:32:29 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:32:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:32:29 --> Final output sent to browser
DEBUG - 2017-02-20 00:32:29 --> Total execution time: 0.0137
INFO - 2017-02-20 00:35:04 --> Config Class Initialized
INFO - 2017-02-20 00:35:04 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:35:04 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:35:04 --> Utf8 Class Initialized
INFO - 2017-02-20 00:35:04 --> URI Class Initialized
INFO - 2017-02-20 00:35:04 --> Router Class Initialized
INFO - 2017-02-20 00:35:04 --> Output Class Initialized
INFO - 2017-02-20 00:35:04 --> Security Class Initialized
DEBUG - 2017-02-20 00:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:35:04 --> Input Class Initialized
INFO - 2017-02-20 00:35:04 --> Language Class Initialized
INFO - 2017-02-20 00:35:04 --> Loader Class Initialized
INFO - 2017-02-20 00:35:04 --> Database Driver Class Initialized
INFO - 2017-02-20 00:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:35:04 --> Controller Class Initialized
INFO - 2017-02-20 00:35:04 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:35:04 --> Final output sent to browser
DEBUG - 2017-02-20 00:35:04 --> Total execution time: 0.0263
INFO - 2017-02-20 00:35:06 --> Config Class Initialized
INFO - 2017-02-20 00:35:06 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:35:06 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:35:06 --> Utf8 Class Initialized
INFO - 2017-02-20 00:35:06 --> URI Class Initialized
INFO - 2017-02-20 00:35:06 --> Router Class Initialized
INFO - 2017-02-20 00:35:06 --> Output Class Initialized
INFO - 2017-02-20 00:35:06 --> Security Class Initialized
DEBUG - 2017-02-20 00:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:35:06 --> Input Class Initialized
INFO - 2017-02-20 00:35:06 --> Language Class Initialized
INFO - 2017-02-20 00:35:06 --> Loader Class Initialized
INFO - 2017-02-20 00:35:06 --> Database Driver Class Initialized
INFO - 2017-02-20 00:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:35:06 --> Controller Class Initialized
INFO - 2017-02-20 00:35:06 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:35:06 --> Final output sent to browser
DEBUG - 2017-02-20 00:35:06 --> Total execution time: 0.0138
INFO - 2017-02-20 00:35:29 --> Config Class Initialized
INFO - 2017-02-20 00:35:29 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:35:29 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:35:29 --> Utf8 Class Initialized
INFO - 2017-02-20 00:35:29 --> URI Class Initialized
INFO - 2017-02-20 00:35:29 --> Router Class Initialized
INFO - 2017-02-20 00:35:29 --> Output Class Initialized
INFO - 2017-02-20 00:35:29 --> Security Class Initialized
DEBUG - 2017-02-20 00:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:35:29 --> Input Class Initialized
INFO - 2017-02-20 00:35:29 --> Language Class Initialized
INFO - 2017-02-20 00:35:29 --> Loader Class Initialized
INFO - 2017-02-20 00:35:29 --> Database Driver Class Initialized
INFO - 2017-02-20 00:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:35:29 --> Controller Class Initialized
INFO - 2017-02-20 00:35:29 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:35:29 --> Final output sent to browser
DEBUG - 2017-02-20 00:35:29 --> Total execution time: 0.0144
INFO - 2017-02-20 00:35:31 --> Config Class Initialized
INFO - 2017-02-20 00:35:31 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:35:31 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:35:31 --> Utf8 Class Initialized
INFO - 2017-02-20 00:35:31 --> URI Class Initialized
INFO - 2017-02-20 00:35:31 --> Router Class Initialized
INFO - 2017-02-20 00:35:31 --> Output Class Initialized
INFO - 2017-02-20 00:35:31 --> Security Class Initialized
DEBUG - 2017-02-20 00:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:35:31 --> Input Class Initialized
INFO - 2017-02-20 00:35:31 --> Language Class Initialized
INFO - 2017-02-20 00:35:31 --> Loader Class Initialized
INFO - 2017-02-20 00:35:31 --> Database Driver Class Initialized
INFO - 2017-02-20 00:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:35:31 --> Controller Class Initialized
INFO - 2017-02-20 00:35:31 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:35:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:35:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:35:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:35:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:35:31 --> Final output sent to browser
DEBUG - 2017-02-20 00:35:31 --> Total execution time: 0.0140
INFO - 2017-02-20 00:37:36 --> Config Class Initialized
INFO - 2017-02-20 00:37:36 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:37:36 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:37:36 --> Utf8 Class Initialized
INFO - 2017-02-20 00:37:36 --> URI Class Initialized
INFO - 2017-02-20 00:37:36 --> Router Class Initialized
INFO - 2017-02-20 00:37:36 --> Output Class Initialized
INFO - 2017-02-20 00:37:36 --> Security Class Initialized
DEBUG - 2017-02-20 00:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:37:36 --> Input Class Initialized
INFO - 2017-02-20 00:37:36 --> Language Class Initialized
INFO - 2017-02-20 00:37:36 --> Loader Class Initialized
INFO - 2017-02-20 00:37:36 --> Database Driver Class Initialized
INFO - 2017-02-20 00:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:37:36 --> Controller Class Initialized
INFO - 2017-02-20 00:37:36 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:37:36 --> Config Class Initialized
INFO - 2017-02-20 00:37:36 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:37:36 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:37:36 --> Utf8 Class Initialized
INFO - 2017-02-20 00:37:36 --> URI Class Initialized
INFO - 2017-02-20 00:37:36 --> Router Class Initialized
INFO - 2017-02-20 00:37:36 --> Output Class Initialized
INFO - 2017-02-20 00:37:36 --> Security Class Initialized
DEBUG - 2017-02-20 00:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:37:36 --> Input Class Initialized
INFO - 2017-02-20 00:37:36 --> Language Class Initialized
INFO - 2017-02-20 00:37:36 --> Loader Class Initialized
INFO - 2017-02-20 00:37:36 --> Database Driver Class Initialized
INFO - 2017-02-20 00:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:37:36 --> Controller Class Initialized
INFO - 2017-02-20 00:37:36 --> Helper loaded: date_helper
DEBUG - 2017-02-20 00:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:37:36 --> Helper loaded: url_helper
INFO - 2017-02-20 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-20 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-20 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-20 00:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:37:36 --> Final output sent to browser
DEBUG - 2017-02-20 00:37:36 --> Total execution time: 0.0398
INFO - 2017-02-20 00:37:38 --> Config Class Initialized
INFO - 2017-02-20 00:37:38 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:37:38 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:37:38 --> Utf8 Class Initialized
INFO - 2017-02-20 00:37:38 --> URI Class Initialized
INFO - 2017-02-20 00:37:38 --> Router Class Initialized
INFO - 2017-02-20 00:37:38 --> Output Class Initialized
INFO - 2017-02-20 00:37:38 --> Security Class Initialized
DEBUG - 2017-02-20 00:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:37:38 --> Input Class Initialized
INFO - 2017-02-20 00:37:38 --> Language Class Initialized
INFO - 2017-02-20 00:37:38 --> Loader Class Initialized
INFO - 2017-02-20 00:37:38 --> Database Driver Class Initialized
INFO - 2017-02-20 00:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:37:38 --> Controller Class Initialized
INFO - 2017-02-20 00:37:38 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:37:38 --> Final output sent to browser
DEBUG - 2017-02-20 00:37:38 --> Total execution time: 0.0138
INFO - 2017-02-20 00:56:05 --> Config Class Initialized
INFO - 2017-02-20 00:56:05 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:56:05 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:56:05 --> Utf8 Class Initialized
INFO - 2017-02-20 00:56:05 --> URI Class Initialized
DEBUG - 2017-02-20 00:56:05 --> No URI present. Default controller set.
INFO - 2017-02-20 00:56:05 --> Router Class Initialized
INFO - 2017-02-20 00:56:05 --> Output Class Initialized
INFO - 2017-02-20 00:56:05 --> Security Class Initialized
DEBUG - 2017-02-20 00:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:56:05 --> Input Class Initialized
INFO - 2017-02-20 00:56:05 --> Language Class Initialized
INFO - 2017-02-20 00:56:05 --> Loader Class Initialized
INFO - 2017-02-20 00:56:05 --> Database Driver Class Initialized
INFO - 2017-02-20 00:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:56:05 --> Controller Class Initialized
INFO - 2017-02-20 00:56:05 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:56:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:56:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:56:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:56:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:56:05 --> Final output sent to browser
DEBUG - 2017-02-20 00:56:05 --> Total execution time: 0.0134
INFO - 2017-02-20 00:56:12 --> Config Class Initialized
INFO - 2017-02-20 00:56:12 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:56:12 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:56:12 --> Utf8 Class Initialized
INFO - 2017-02-20 00:56:12 --> URI Class Initialized
INFO - 2017-02-20 00:56:12 --> Router Class Initialized
INFO - 2017-02-20 00:56:12 --> Output Class Initialized
INFO - 2017-02-20 00:56:12 --> Security Class Initialized
DEBUG - 2017-02-20 00:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:56:12 --> Input Class Initialized
INFO - 2017-02-20 00:56:12 --> Language Class Initialized
INFO - 2017-02-20 00:56:12 --> Loader Class Initialized
INFO - 2017-02-20 00:56:12 --> Database Driver Class Initialized
INFO - 2017-02-20 00:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:56:12 --> Controller Class Initialized
INFO - 2017-02-20 00:56:12 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:56:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:56:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:56:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:56:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:56:12 --> Final output sent to browser
DEBUG - 2017-02-20 00:56:12 --> Total execution time: 0.0141
INFO - 2017-02-20 00:56:57 --> Config Class Initialized
INFO - 2017-02-20 00:56:57 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:56:58 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:56:58 --> Utf8 Class Initialized
INFO - 2017-02-20 00:56:58 --> URI Class Initialized
DEBUG - 2017-02-20 00:56:58 --> No URI present. Default controller set.
INFO - 2017-02-20 00:56:58 --> Router Class Initialized
INFO - 2017-02-20 00:56:58 --> Output Class Initialized
INFO - 2017-02-20 00:56:58 --> Security Class Initialized
DEBUG - 2017-02-20 00:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:56:58 --> Input Class Initialized
INFO - 2017-02-20 00:56:58 --> Language Class Initialized
INFO - 2017-02-20 00:56:58 --> Loader Class Initialized
INFO - 2017-02-20 00:56:58 --> Database Driver Class Initialized
INFO - 2017-02-20 00:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:56:58 --> Controller Class Initialized
INFO - 2017-02-20 00:56:58 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:56:58 --> Final output sent to browser
DEBUG - 2017-02-20 00:56:58 --> Total execution time: 0.0133
INFO - 2017-02-20 00:57:00 --> Config Class Initialized
INFO - 2017-02-20 00:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-20 00:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-20 00:57:00 --> Utf8 Class Initialized
INFO - 2017-02-20 00:57:00 --> URI Class Initialized
INFO - 2017-02-20 00:57:00 --> Router Class Initialized
INFO - 2017-02-20 00:57:00 --> Output Class Initialized
INFO - 2017-02-20 00:57:00 --> Security Class Initialized
DEBUG - 2017-02-20 00:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 00:57:00 --> Input Class Initialized
INFO - 2017-02-20 00:57:00 --> Language Class Initialized
INFO - 2017-02-20 00:57:00 --> Loader Class Initialized
INFO - 2017-02-20 00:57:00 --> Database Driver Class Initialized
INFO - 2017-02-20 00:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 00:57:00 --> Controller Class Initialized
INFO - 2017-02-20 00:57:00 --> Helper loaded: url_helper
DEBUG - 2017-02-20 00:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 00:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 00:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 00:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 00:57:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 00:57:00 --> Final output sent to browser
DEBUG - 2017-02-20 00:57:00 --> Total execution time: 0.0135
INFO - 2017-02-20 01:57:39 --> Config Class Initialized
INFO - 2017-02-20 01:57:39 --> Hooks Class Initialized
DEBUG - 2017-02-20 01:57:39 --> UTF-8 Support Enabled
INFO - 2017-02-20 01:57:39 --> Utf8 Class Initialized
INFO - 2017-02-20 01:57:39 --> URI Class Initialized
DEBUG - 2017-02-20 01:57:39 --> No URI present. Default controller set.
INFO - 2017-02-20 01:57:39 --> Router Class Initialized
INFO - 2017-02-20 01:57:39 --> Output Class Initialized
INFO - 2017-02-20 01:57:39 --> Security Class Initialized
DEBUG - 2017-02-20 01:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 01:57:39 --> Input Class Initialized
INFO - 2017-02-20 01:57:39 --> Language Class Initialized
INFO - 2017-02-20 01:57:39 --> Loader Class Initialized
INFO - 2017-02-20 01:57:39 --> Database Driver Class Initialized
INFO - 2017-02-20 01:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 01:57:39 --> Controller Class Initialized
INFO - 2017-02-20 01:57:39 --> Helper loaded: url_helper
DEBUG - 2017-02-20 01:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 01:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 01:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 01:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 01:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 01:57:40 --> Final output sent to browser
DEBUG - 2017-02-20 01:57:40 --> Total execution time: 0.0137
INFO - 2017-02-20 02:22:49 --> Config Class Initialized
INFO - 2017-02-20 02:22:49 --> Hooks Class Initialized
DEBUG - 2017-02-20 02:22:49 --> UTF-8 Support Enabled
INFO - 2017-02-20 02:22:49 --> Utf8 Class Initialized
INFO - 2017-02-20 02:22:49 --> URI Class Initialized
INFO - 2017-02-20 02:22:49 --> Router Class Initialized
INFO - 2017-02-20 02:22:49 --> Output Class Initialized
INFO - 2017-02-20 02:22:49 --> Security Class Initialized
DEBUG - 2017-02-20 02:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 02:22:49 --> Input Class Initialized
INFO - 2017-02-20 02:22:49 --> Language Class Initialized
INFO - 2017-02-20 02:22:49 --> Loader Class Initialized
INFO - 2017-02-20 02:22:49 --> Database Driver Class Initialized
INFO - 2017-02-20 02:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 02:22:49 --> Controller Class Initialized
INFO - 2017-02-20 02:22:49 --> Helper loaded: url_helper
DEBUG - 2017-02-20 02:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 02:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 02:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 02:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 02:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 02:22:49 --> Final output sent to browser
DEBUG - 2017-02-20 02:22:49 --> Total execution time: 0.0140
INFO - 2017-02-20 14:05:04 --> Config Class Initialized
INFO - 2017-02-20 14:05:04 --> Hooks Class Initialized
DEBUG - 2017-02-20 14:05:04 --> UTF-8 Support Enabled
INFO - 2017-02-20 14:05:04 --> Utf8 Class Initialized
INFO - 2017-02-20 14:05:04 --> URI Class Initialized
INFO - 2017-02-20 14:05:04 --> Router Class Initialized
INFO - 2017-02-20 14:05:04 --> Output Class Initialized
INFO - 2017-02-20 14:05:05 --> Security Class Initialized
DEBUG - 2017-02-20 14:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 14:05:05 --> Input Class Initialized
INFO - 2017-02-20 14:05:05 --> Language Class Initialized
INFO - 2017-02-20 14:05:05 --> Loader Class Initialized
INFO - 2017-02-20 14:05:05 --> Database Driver Class Initialized
INFO - 2017-02-20 14:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 14:05:05 --> Controller Class Initialized
INFO - 2017-02-20 14:05:05 --> Helper loaded: url_helper
DEBUG - 2017-02-20 14:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 14:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 14:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 14:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 14:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 14:05:05 --> Final output sent to browser
DEBUG - 2017-02-20 14:05:05 --> Total execution time: 1.5860
INFO - 2017-02-20 14:05:07 --> Config Class Initialized
INFO - 2017-02-20 14:05:07 --> Hooks Class Initialized
DEBUG - 2017-02-20 14:05:07 --> UTF-8 Support Enabled
INFO - 2017-02-20 14:05:07 --> Utf8 Class Initialized
INFO - 2017-02-20 14:05:07 --> URI Class Initialized
INFO - 2017-02-20 14:05:07 --> Router Class Initialized
INFO - 2017-02-20 14:05:07 --> Output Class Initialized
INFO - 2017-02-20 14:05:07 --> Security Class Initialized
DEBUG - 2017-02-20 14:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 14:05:07 --> Input Class Initialized
INFO - 2017-02-20 14:05:07 --> Language Class Initialized
INFO - 2017-02-20 14:05:07 --> Loader Class Initialized
INFO - 2017-02-20 14:05:07 --> Database Driver Class Initialized
INFO - 2017-02-20 14:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 14:05:07 --> Controller Class Initialized
INFO - 2017-02-20 14:05:07 --> Helper loaded: url_helper
DEBUG - 2017-02-20 14:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 14:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 14:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 14:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 14:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 14:05:07 --> Final output sent to browser
DEBUG - 2017-02-20 14:05:07 --> Total execution time: 0.0146
INFO - 2017-02-20 14:14:46 --> Config Class Initialized
INFO - 2017-02-20 14:14:46 --> Hooks Class Initialized
DEBUG - 2017-02-20 14:14:46 --> UTF-8 Support Enabled
INFO - 2017-02-20 14:14:46 --> Utf8 Class Initialized
INFO - 2017-02-20 14:14:46 --> URI Class Initialized
DEBUG - 2017-02-20 14:14:46 --> No URI present. Default controller set.
INFO - 2017-02-20 14:14:46 --> Router Class Initialized
INFO - 2017-02-20 14:14:46 --> Output Class Initialized
INFO - 2017-02-20 14:14:46 --> Security Class Initialized
DEBUG - 2017-02-20 14:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 14:14:46 --> Input Class Initialized
INFO - 2017-02-20 14:14:46 --> Language Class Initialized
INFO - 2017-02-20 14:14:46 --> Loader Class Initialized
INFO - 2017-02-20 14:14:46 --> Database Driver Class Initialized
INFO - 2017-02-20 14:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 14:14:46 --> Controller Class Initialized
INFO - 2017-02-20 14:14:46 --> Helper loaded: url_helper
DEBUG - 2017-02-20 14:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 14:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 14:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 14:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 14:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 14:14:46 --> Final output sent to browser
DEBUG - 2017-02-20 14:14:46 --> Total execution time: 0.0135
INFO - 2017-02-20 14:14:55 --> Config Class Initialized
INFO - 2017-02-20 14:14:55 --> Hooks Class Initialized
DEBUG - 2017-02-20 14:14:55 --> UTF-8 Support Enabled
INFO - 2017-02-20 14:14:55 --> Utf8 Class Initialized
INFO - 2017-02-20 14:14:55 --> URI Class Initialized
DEBUG - 2017-02-20 14:14:55 --> No URI present. Default controller set.
INFO - 2017-02-20 14:14:55 --> Router Class Initialized
INFO - 2017-02-20 14:14:55 --> Output Class Initialized
INFO - 2017-02-20 14:14:55 --> Security Class Initialized
DEBUG - 2017-02-20 14:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 14:14:55 --> Input Class Initialized
INFO - 2017-02-20 14:14:55 --> Language Class Initialized
INFO - 2017-02-20 14:14:55 --> Loader Class Initialized
INFO - 2017-02-20 14:14:55 --> Database Driver Class Initialized
INFO - 2017-02-20 14:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 14:14:55 --> Controller Class Initialized
INFO - 2017-02-20 14:14:55 --> Helper loaded: url_helper
DEBUG - 2017-02-20 14:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 14:14:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 14:14:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 14:14:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 14:14:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 14:14:55 --> Final output sent to browser
DEBUG - 2017-02-20 14:14:55 --> Total execution time: 0.0134
INFO - 2017-02-20 14:15:17 --> Config Class Initialized
INFO - 2017-02-20 14:15:17 --> Hooks Class Initialized
DEBUG - 2017-02-20 14:15:17 --> UTF-8 Support Enabled
INFO - 2017-02-20 14:15:17 --> Utf8 Class Initialized
INFO - 2017-02-20 14:15:17 --> URI Class Initialized
INFO - 2017-02-20 14:15:17 --> Router Class Initialized
INFO - 2017-02-20 14:15:17 --> Output Class Initialized
INFO - 2017-02-20 14:15:17 --> Security Class Initialized
DEBUG - 2017-02-20 14:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 14:15:17 --> Input Class Initialized
INFO - 2017-02-20 14:15:17 --> Language Class Initialized
INFO - 2017-02-20 14:15:17 --> Loader Class Initialized
INFO - 2017-02-20 14:15:17 --> Database Driver Class Initialized
INFO - 2017-02-20 14:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 14:15:17 --> Controller Class Initialized
INFO - 2017-02-20 14:15:17 --> Helper loaded: url_helper
DEBUG - 2017-02-20 14:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 14:15:17 --> Config Class Initialized
INFO - 2017-02-20 14:15:17 --> Hooks Class Initialized
DEBUG - 2017-02-20 14:15:17 --> UTF-8 Support Enabled
INFO - 2017-02-20 14:15:17 --> Utf8 Class Initialized
INFO - 2017-02-20 14:15:17 --> URI Class Initialized
INFO - 2017-02-20 14:15:17 --> Router Class Initialized
INFO - 2017-02-20 14:15:17 --> Output Class Initialized
INFO - 2017-02-20 14:15:17 --> Security Class Initialized
DEBUG - 2017-02-20 14:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 14:15:17 --> Input Class Initialized
INFO - 2017-02-20 14:15:17 --> Language Class Initialized
INFO - 2017-02-20 14:15:17 --> Loader Class Initialized
INFO - 2017-02-20 14:15:17 --> Database Driver Class Initialized
INFO - 2017-02-20 14:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 14:15:17 --> Controller Class Initialized
INFO - 2017-02-20 14:15:17 --> Helper loaded: date_helper
DEBUG - 2017-02-20 14:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 14:15:17 --> Helper loaded: url_helper
INFO - 2017-02-20 14:15:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 14:15:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-20 14:15:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-20 14:15:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-20 14:15:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 14:15:17 --> Final output sent to browser
DEBUG - 2017-02-20 14:15:17 --> Total execution time: 0.1302
INFO - 2017-02-20 14:26:49 --> Config Class Initialized
INFO - 2017-02-20 14:26:49 --> Hooks Class Initialized
DEBUG - 2017-02-20 14:26:49 --> UTF-8 Support Enabled
INFO - 2017-02-20 14:26:49 --> Utf8 Class Initialized
INFO - 2017-02-20 14:26:49 --> URI Class Initialized
INFO - 2017-02-20 14:26:49 --> Router Class Initialized
INFO - 2017-02-20 14:26:49 --> Output Class Initialized
INFO - 2017-02-20 14:26:49 --> Security Class Initialized
DEBUG - 2017-02-20 14:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 14:26:49 --> Input Class Initialized
INFO - 2017-02-20 14:26:49 --> Language Class Initialized
INFO - 2017-02-20 14:26:49 --> Loader Class Initialized
INFO - 2017-02-20 14:26:49 --> Database Driver Class Initialized
INFO - 2017-02-20 14:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 14:26:49 --> Controller Class Initialized
INFO - 2017-02-20 14:26:49 --> Helper loaded: date_helper
DEBUG - 2017-02-20 14:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 14:26:49 --> Helper loaded: url_helper
INFO - 2017-02-20 14:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 14:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-20 14:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-20 14:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-20 14:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 14:26:49 --> Final output sent to browser
DEBUG - 2017-02-20 14:26:49 --> Total execution time: 0.0149
INFO - 2017-02-20 16:21:05 --> Config Class Initialized
INFO - 2017-02-20 16:21:05 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:21:05 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:21:05 --> Utf8 Class Initialized
INFO - 2017-02-20 16:21:05 --> URI Class Initialized
DEBUG - 2017-02-20 16:21:05 --> No URI present. Default controller set.
INFO - 2017-02-20 16:21:05 --> Router Class Initialized
INFO - 2017-02-20 16:21:05 --> Output Class Initialized
INFO - 2017-02-20 16:21:05 --> Security Class Initialized
DEBUG - 2017-02-20 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:21:05 --> Input Class Initialized
INFO - 2017-02-20 16:21:05 --> Language Class Initialized
INFO - 2017-02-20 16:21:05 --> Loader Class Initialized
INFO - 2017-02-20 16:21:05 --> Database Driver Class Initialized
INFO - 2017-02-20 16:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:21:06 --> Controller Class Initialized
INFO - 2017-02-20 16:21:06 --> Helper loaded: url_helper
DEBUG - 2017-02-20 16:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 16:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 16:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 16:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 16:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 16:21:06 --> Final output sent to browser
DEBUG - 2017-02-20 16:21:06 --> Total execution time: 0.4287
INFO - 2017-02-20 16:31:24 --> Config Class Initialized
INFO - 2017-02-20 16:31:24 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:31:25 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:31:25 --> Utf8 Class Initialized
INFO - 2017-02-20 16:31:25 --> URI Class Initialized
DEBUG - 2017-02-20 16:31:25 --> No URI present. Default controller set.
INFO - 2017-02-20 16:31:25 --> Router Class Initialized
INFO - 2017-02-20 16:31:25 --> Output Class Initialized
INFO - 2017-02-20 16:31:25 --> Security Class Initialized
DEBUG - 2017-02-20 16:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:31:25 --> Input Class Initialized
INFO - 2017-02-20 16:31:25 --> Language Class Initialized
INFO - 2017-02-20 16:31:25 --> Loader Class Initialized
INFO - 2017-02-20 16:31:25 --> Database Driver Class Initialized
INFO - 2017-02-20 16:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:31:26 --> Controller Class Initialized
INFO - 2017-02-20 16:31:26 --> Helper loaded: url_helper
DEBUG - 2017-02-20 16:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 16:31:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 16:31:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 16:31:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 16:31:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 16:31:26 --> Final output sent to browser
DEBUG - 2017-02-20 16:31:26 --> Total execution time: 1.9253
INFO - 2017-02-20 16:31:28 --> Config Class Initialized
INFO - 2017-02-20 16:31:28 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:31:28 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:31:28 --> Utf8 Class Initialized
INFO - 2017-02-20 16:31:28 --> URI Class Initialized
INFO - 2017-02-20 16:31:28 --> Router Class Initialized
INFO - 2017-02-20 16:31:28 --> Output Class Initialized
INFO - 2017-02-20 16:31:28 --> Security Class Initialized
DEBUG - 2017-02-20 16:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:31:28 --> Input Class Initialized
INFO - 2017-02-20 16:31:28 --> Language Class Initialized
INFO - 2017-02-20 16:31:28 --> Loader Class Initialized
INFO - 2017-02-20 16:31:28 --> Database Driver Class Initialized
INFO - 2017-02-20 16:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:31:28 --> Controller Class Initialized
INFO - 2017-02-20 16:31:28 --> Helper loaded: url_helper
DEBUG - 2017-02-20 16:31:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 16:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 16:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 16:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 16:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 16:31:28 --> Final output sent to browser
DEBUG - 2017-02-20 16:31:28 --> Total execution time: 0.0131
INFO - 2017-02-20 17:39:33 --> Config Class Initialized
INFO - 2017-02-20 17:39:33 --> Hooks Class Initialized
DEBUG - 2017-02-20 17:39:33 --> UTF-8 Support Enabled
INFO - 2017-02-20 17:39:33 --> Utf8 Class Initialized
INFO - 2017-02-20 17:39:33 --> URI Class Initialized
DEBUG - 2017-02-20 17:39:33 --> No URI present. Default controller set.
INFO - 2017-02-20 17:39:33 --> Router Class Initialized
INFO - 2017-02-20 17:39:33 --> Output Class Initialized
INFO - 2017-02-20 17:39:33 --> Security Class Initialized
DEBUG - 2017-02-20 17:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 17:39:33 --> Input Class Initialized
INFO - 2017-02-20 17:39:33 --> Language Class Initialized
INFO - 2017-02-20 17:39:33 --> Loader Class Initialized
INFO - 2017-02-20 17:39:33 --> Database Driver Class Initialized
INFO - 2017-02-20 17:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 17:39:33 --> Controller Class Initialized
INFO - 2017-02-20 17:39:33 --> Helper loaded: url_helper
DEBUG - 2017-02-20 17:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 17:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 17:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 17:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 17:39:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 17:39:33 --> Final output sent to browser
DEBUG - 2017-02-20 17:39:33 --> Total execution time: 0.0323
INFO - 2017-02-20 20:40:33 --> Config Class Initialized
INFO - 2017-02-20 20:40:33 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:40:33 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:40:33 --> Utf8 Class Initialized
INFO - 2017-02-20 20:40:33 --> URI Class Initialized
DEBUG - 2017-02-20 20:40:33 --> No URI present. Default controller set.
INFO - 2017-02-20 20:40:33 --> Router Class Initialized
INFO - 2017-02-20 20:40:33 --> Output Class Initialized
INFO - 2017-02-20 20:40:33 --> Security Class Initialized
DEBUG - 2017-02-20 20:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:40:33 --> Input Class Initialized
INFO - 2017-02-20 20:40:33 --> Language Class Initialized
INFO - 2017-02-20 20:40:33 --> Loader Class Initialized
INFO - 2017-02-20 20:40:33 --> Database Driver Class Initialized
INFO - 2017-02-20 20:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:40:33 --> Controller Class Initialized
INFO - 2017-02-20 20:40:33 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:40:33 --> Final output sent to browser
DEBUG - 2017-02-20 20:40:33 --> Total execution time: 0.5198
INFO - 2017-02-20 20:40:38 --> Config Class Initialized
INFO - 2017-02-20 20:40:38 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:40:38 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:40:38 --> Utf8 Class Initialized
INFO - 2017-02-20 20:40:38 --> URI Class Initialized
INFO - 2017-02-20 20:40:38 --> Router Class Initialized
INFO - 2017-02-20 20:40:38 --> Output Class Initialized
INFO - 2017-02-20 20:40:38 --> Security Class Initialized
DEBUG - 2017-02-20 20:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:40:38 --> Input Class Initialized
INFO - 2017-02-20 20:40:38 --> Language Class Initialized
INFO - 2017-02-20 20:40:38 --> Loader Class Initialized
INFO - 2017-02-20 20:40:38 --> Database Driver Class Initialized
INFO - 2017-02-20 20:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:40:38 --> Controller Class Initialized
INFO - 2017-02-20 20:40:38 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:40:38 --> Final output sent to browser
DEBUG - 2017-02-20 20:40:38 --> Total execution time: 0.0141
INFO - 2017-02-20 20:41:51 --> Config Class Initialized
INFO - 2017-02-20 20:41:51 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:41:51 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:41:51 --> Utf8 Class Initialized
INFO - 2017-02-20 20:41:51 --> URI Class Initialized
INFO - 2017-02-20 20:41:51 --> Router Class Initialized
INFO - 2017-02-20 20:41:51 --> Output Class Initialized
INFO - 2017-02-20 20:41:51 --> Security Class Initialized
DEBUG - 2017-02-20 20:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:41:51 --> Input Class Initialized
INFO - 2017-02-20 20:41:51 --> Language Class Initialized
INFO - 2017-02-20 20:41:51 --> Loader Class Initialized
INFO - 2017-02-20 20:41:51 --> Database Driver Class Initialized
INFO - 2017-02-20 20:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:41:51 --> Controller Class Initialized
INFO - 2017-02-20 20:41:51 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:41:51 --> Config Class Initialized
INFO - 2017-02-20 20:41:51 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:41:51 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:41:51 --> Utf8 Class Initialized
INFO - 2017-02-20 20:41:51 --> URI Class Initialized
INFO - 2017-02-20 20:41:51 --> Router Class Initialized
INFO - 2017-02-20 20:41:51 --> Output Class Initialized
INFO - 2017-02-20 20:41:51 --> Security Class Initialized
DEBUG - 2017-02-20 20:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:41:51 --> Input Class Initialized
INFO - 2017-02-20 20:41:51 --> Language Class Initialized
INFO - 2017-02-20 20:41:51 --> Loader Class Initialized
INFO - 2017-02-20 20:41:51 --> Database Driver Class Initialized
INFO - 2017-02-20 20:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:41:51 --> Controller Class Initialized
INFO - 2017-02-20 20:41:51 --> Helper loaded: date_helper
DEBUG - 2017-02-20 20:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:41:51 --> Helper loaded: url_helper
INFO - 2017-02-20 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-20 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-20 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-20 20:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:41:51 --> Final output sent to browser
DEBUG - 2017-02-20 20:41:51 --> Total execution time: 0.3598
INFO - 2017-02-20 20:41:52 --> Config Class Initialized
INFO - 2017-02-20 20:41:52 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:41:52 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:41:52 --> Utf8 Class Initialized
INFO - 2017-02-20 20:41:52 --> URI Class Initialized
INFO - 2017-02-20 20:41:52 --> Router Class Initialized
INFO - 2017-02-20 20:41:52 --> Output Class Initialized
INFO - 2017-02-20 20:41:52 --> Security Class Initialized
DEBUG - 2017-02-20 20:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:41:52 --> Input Class Initialized
INFO - 2017-02-20 20:41:52 --> Language Class Initialized
INFO - 2017-02-20 20:41:52 --> Loader Class Initialized
INFO - 2017-02-20 20:41:52 --> Database Driver Class Initialized
INFO - 2017-02-20 20:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:41:52 --> Controller Class Initialized
INFO - 2017-02-20 20:41:52 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:41:52 --> Final output sent to browser
DEBUG - 2017-02-20 20:41:52 --> Total execution time: 0.0555
INFO - 2017-02-20 20:42:03 --> Config Class Initialized
INFO - 2017-02-20 20:42:03 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:42:03 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:42:03 --> Utf8 Class Initialized
INFO - 2017-02-20 20:42:03 --> URI Class Initialized
DEBUG - 2017-02-20 20:42:03 --> No URI present. Default controller set.
INFO - 2017-02-20 20:42:03 --> Router Class Initialized
INFO - 2017-02-20 20:42:03 --> Output Class Initialized
INFO - 2017-02-20 20:42:03 --> Security Class Initialized
DEBUG - 2017-02-20 20:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:42:03 --> Input Class Initialized
INFO - 2017-02-20 20:42:03 --> Language Class Initialized
INFO - 2017-02-20 20:42:03 --> Loader Class Initialized
INFO - 2017-02-20 20:42:03 --> Database Driver Class Initialized
INFO - 2017-02-20 20:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:42:03 --> Controller Class Initialized
INFO - 2017-02-20 20:42:03 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:42:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:42:03 --> Final output sent to browser
DEBUG - 2017-02-20 20:42:03 --> Total execution time: 0.0135
INFO - 2017-02-20 20:42:04 --> Config Class Initialized
INFO - 2017-02-20 20:42:04 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:42:04 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:42:04 --> Utf8 Class Initialized
INFO - 2017-02-20 20:42:04 --> URI Class Initialized
INFO - 2017-02-20 20:42:04 --> Router Class Initialized
INFO - 2017-02-20 20:42:04 --> Output Class Initialized
INFO - 2017-02-20 20:42:04 --> Security Class Initialized
DEBUG - 2017-02-20 20:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:42:04 --> Input Class Initialized
INFO - 2017-02-20 20:42:04 --> Language Class Initialized
INFO - 2017-02-20 20:42:04 --> Loader Class Initialized
INFO - 2017-02-20 20:42:04 --> Database Driver Class Initialized
INFO - 2017-02-20 20:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:42:04 --> Controller Class Initialized
INFO - 2017-02-20 20:42:04 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:42:04 --> Final output sent to browser
DEBUG - 2017-02-20 20:42:04 --> Total execution time: 0.0153
INFO - 2017-02-20 20:43:07 --> Config Class Initialized
INFO - 2017-02-20 20:43:07 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:07 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:07 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:07 --> URI Class Initialized
INFO - 2017-02-20 20:43:07 --> Router Class Initialized
INFO - 2017-02-20 20:43:07 --> Output Class Initialized
INFO - 2017-02-20 20:43:07 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:07 --> Input Class Initialized
INFO - 2017-02-20 20:43:07 --> Language Class Initialized
INFO - 2017-02-20 20:43:07 --> Loader Class Initialized
INFO - 2017-02-20 20:43:07 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:07 --> Controller Class Initialized
INFO - 2017-02-20 20:43:07 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:08 --> Config Class Initialized
INFO - 2017-02-20 20:43:08 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:08 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:08 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:08 --> URI Class Initialized
INFO - 2017-02-20 20:43:08 --> Router Class Initialized
INFO - 2017-02-20 20:43:08 --> Output Class Initialized
INFO - 2017-02-20 20:43:08 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:08 --> Input Class Initialized
INFO - 2017-02-20 20:43:08 --> Language Class Initialized
INFO - 2017-02-20 20:43:08 --> Loader Class Initialized
INFO - 2017-02-20 20:43:08 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:08 --> Controller Class Initialized
INFO - 2017-02-20 20:43:08 --> Helper loaded: date_helper
DEBUG - 2017-02-20 20:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:08 --> Helper loaded: url_helper
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:08 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:08 --> Total execution time: 0.0608
INFO - 2017-02-20 20:43:08 --> Config Class Initialized
INFO - 2017-02-20 20:43:08 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:08 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:08 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:08 --> URI Class Initialized
INFO - 2017-02-20 20:43:08 --> Router Class Initialized
INFO - 2017-02-20 20:43:08 --> Output Class Initialized
INFO - 2017-02-20 20:43:08 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:08 --> Input Class Initialized
INFO - 2017-02-20 20:43:08 --> Language Class Initialized
INFO - 2017-02-20 20:43:08 --> Loader Class Initialized
INFO - 2017-02-20 20:43:08 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:08 --> Controller Class Initialized
INFO - 2017-02-20 20:43:08 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:43:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:08 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:08 --> Total execution time: 0.0445
INFO - 2017-02-20 20:43:13 --> Config Class Initialized
INFO - 2017-02-20 20:43:13 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:13 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:13 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:13 --> URI Class Initialized
DEBUG - 2017-02-20 20:43:13 --> No URI present. Default controller set.
INFO - 2017-02-20 20:43:13 --> Router Class Initialized
INFO - 2017-02-20 20:43:13 --> Output Class Initialized
INFO - 2017-02-20 20:43:13 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:13 --> Input Class Initialized
INFO - 2017-02-20 20:43:13 --> Language Class Initialized
INFO - 2017-02-20 20:43:13 --> Loader Class Initialized
INFO - 2017-02-20 20:43:13 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:13 --> Controller Class Initialized
INFO - 2017-02-20 20:43:13 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:13 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:13 --> Total execution time: 0.0148
INFO - 2017-02-20 20:43:13 --> Config Class Initialized
INFO - 2017-02-20 20:43:13 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:13 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:13 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:13 --> URI Class Initialized
INFO - 2017-02-20 20:43:13 --> Router Class Initialized
INFO - 2017-02-20 20:43:13 --> Output Class Initialized
INFO - 2017-02-20 20:43:13 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:13 --> Input Class Initialized
INFO - 2017-02-20 20:43:13 --> Language Class Initialized
INFO - 2017-02-20 20:43:13 --> Loader Class Initialized
INFO - 2017-02-20 20:43:13 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:13 --> Controller Class Initialized
INFO - 2017-02-20 20:43:13 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:13 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:13 --> Total execution time: 0.0691
INFO - 2017-02-20 20:43:17 --> Config Class Initialized
INFO - 2017-02-20 20:43:17 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:17 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:17 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:17 --> URI Class Initialized
INFO - 2017-02-20 20:43:17 --> Router Class Initialized
INFO - 2017-02-20 20:43:17 --> Output Class Initialized
INFO - 2017-02-20 20:43:17 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:17 --> Input Class Initialized
INFO - 2017-02-20 20:43:17 --> Language Class Initialized
INFO - 2017-02-20 20:43:17 --> Loader Class Initialized
INFO - 2017-02-20 20:43:17 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:17 --> Controller Class Initialized
INFO - 2017-02-20 20:43:17 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:19 --> Config Class Initialized
INFO - 2017-02-20 20:43:19 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:19 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:19 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:19 --> URI Class Initialized
INFO - 2017-02-20 20:43:19 --> Router Class Initialized
INFO - 2017-02-20 20:43:19 --> Output Class Initialized
INFO - 2017-02-20 20:43:19 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:19 --> Input Class Initialized
INFO - 2017-02-20 20:43:19 --> Language Class Initialized
INFO - 2017-02-20 20:43:19 --> Loader Class Initialized
INFO - 2017-02-20 20:43:19 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:19 --> Controller Class Initialized
INFO - 2017-02-20 20:43:19 --> Helper loaded: date_helper
DEBUG - 2017-02-20 20:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:19 --> Helper loaded: url_helper
INFO - 2017-02-20 20:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-20 20:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-20 20:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-20 20:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:19 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:19 --> Total execution time: 0.0158
INFO - 2017-02-20 20:43:20 --> Config Class Initialized
INFO - 2017-02-20 20:43:20 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:20 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:20 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:20 --> URI Class Initialized
INFO - 2017-02-20 20:43:20 --> Router Class Initialized
INFO - 2017-02-20 20:43:20 --> Output Class Initialized
INFO - 2017-02-20 20:43:20 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:20 --> Input Class Initialized
INFO - 2017-02-20 20:43:20 --> Language Class Initialized
INFO - 2017-02-20 20:43:20 --> Loader Class Initialized
INFO - 2017-02-20 20:43:20 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:20 --> Controller Class Initialized
INFO - 2017-02-20 20:43:20 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:20 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:20 --> Total execution time: 0.0144
INFO - 2017-02-20 20:43:22 --> Config Class Initialized
INFO - 2017-02-20 20:43:22 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:22 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:22 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:22 --> URI Class Initialized
DEBUG - 2017-02-20 20:43:22 --> No URI present. Default controller set.
INFO - 2017-02-20 20:43:22 --> Router Class Initialized
INFO - 2017-02-20 20:43:22 --> Output Class Initialized
INFO - 2017-02-20 20:43:22 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:22 --> Input Class Initialized
INFO - 2017-02-20 20:43:22 --> Language Class Initialized
INFO - 2017-02-20 20:43:22 --> Loader Class Initialized
INFO - 2017-02-20 20:43:22 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:22 --> Controller Class Initialized
INFO - 2017-02-20 20:43:22 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:43:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:43:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:22 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:22 --> Total execution time: 0.0426
INFO - 2017-02-20 20:43:23 --> Config Class Initialized
INFO - 2017-02-20 20:43:23 --> Hooks Class Initialized
DEBUG - 2017-02-20 20:43:23 --> UTF-8 Support Enabled
INFO - 2017-02-20 20:43:23 --> Utf8 Class Initialized
INFO - 2017-02-20 20:43:23 --> URI Class Initialized
INFO - 2017-02-20 20:43:23 --> Router Class Initialized
INFO - 2017-02-20 20:43:23 --> Output Class Initialized
INFO - 2017-02-20 20:43:23 --> Security Class Initialized
DEBUG - 2017-02-20 20:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 20:43:23 --> Input Class Initialized
INFO - 2017-02-20 20:43:23 --> Language Class Initialized
INFO - 2017-02-20 20:43:23 --> Loader Class Initialized
INFO - 2017-02-20 20:43:23 --> Database Driver Class Initialized
INFO - 2017-02-20 20:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 20:43:23 --> Controller Class Initialized
INFO - 2017-02-20 20:43:23 --> Helper loaded: url_helper
DEBUG - 2017-02-20 20:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 20:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 20:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 20:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 20:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 20:43:23 --> Final output sent to browser
DEBUG - 2017-02-20 20:43:23 --> Total execution time: 0.0138
INFO - 2017-02-20 22:08:01 --> Config Class Initialized
INFO - 2017-02-20 22:08:01 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:08:01 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:08:01 --> Utf8 Class Initialized
INFO - 2017-02-20 22:08:01 --> URI Class Initialized
DEBUG - 2017-02-20 22:08:01 --> No URI present. Default controller set.
INFO - 2017-02-20 22:08:01 --> Router Class Initialized
INFO - 2017-02-20 22:08:01 --> Output Class Initialized
INFO - 2017-02-20 22:08:01 --> Security Class Initialized
DEBUG - 2017-02-20 22:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:08:01 --> Input Class Initialized
INFO - 2017-02-20 22:08:01 --> Language Class Initialized
INFO - 2017-02-20 22:08:01 --> Loader Class Initialized
INFO - 2017-02-20 22:08:01 --> Database Driver Class Initialized
INFO - 2017-02-20 22:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:08:01 --> Controller Class Initialized
INFO - 2017-02-20 22:08:01 --> Helper loaded: url_helper
DEBUG - 2017-02-20 22:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 22:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 22:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 22:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 22:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 22:08:01 --> Final output sent to browser
DEBUG - 2017-02-20 22:08:01 --> Total execution time: 0.0325
INFO - 2017-02-20 22:08:04 --> Config Class Initialized
INFO - 2017-02-20 22:08:04 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:08:04 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:08:04 --> Utf8 Class Initialized
INFO - 2017-02-20 22:08:04 --> URI Class Initialized
INFO - 2017-02-20 22:08:04 --> Router Class Initialized
INFO - 2017-02-20 22:08:04 --> Output Class Initialized
INFO - 2017-02-20 22:08:04 --> Security Class Initialized
DEBUG - 2017-02-20 22:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:08:04 --> Input Class Initialized
INFO - 2017-02-20 22:08:04 --> Language Class Initialized
INFO - 2017-02-20 22:08:04 --> Loader Class Initialized
INFO - 2017-02-20 22:08:04 --> Database Driver Class Initialized
INFO - 2017-02-20 22:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:08:04 --> Controller Class Initialized
INFO - 2017-02-20 22:08:04 --> Helper loaded: url_helper
DEBUG - 2017-02-20 22:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 22:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 22:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 22:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 22:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 22:08:04 --> Final output sent to browser
DEBUG - 2017-02-20 22:08:04 --> Total execution time: 0.0140
INFO - 2017-02-20 23:17:09 --> Config Class Initialized
INFO - 2017-02-20 23:17:09 --> Hooks Class Initialized
DEBUG - 2017-02-20 23:17:09 --> UTF-8 Support Enabled
INFO - 2017-02-20 23:17:09 --> Utf8 Class Initialized
INFO - 2017-02-20 23:17:09 --> URI Class Initialized
DEBUG - 2017-02-20 23:17:09 --> No URI present. Default controller set.
INFO - 2017-02-20 23:17:09 --> Router Class Initialized
INFO - 2017-02-20 23:17:09 --> Output Class Initialized
INFO - 2017-02-20 23:17:09 --> Security Class Initialized
DEBUG - 2017-02-20 23:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 23:17:09 --> Input Class Initialized
INFO - 2017-02-20 23:17:09 --> Language Class Initialized
INFO - 2017-02-20 23:17:09 --> Loader Class Initialized
INFO - 2017-02-20 23:17:09 --> Database Driver Class Initialized
INFO - 2017-02-20 23:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 23:17:09 --> Controller Class Initialized
INFO - 2017-02-20 23:17:09 --> Helper loaded: url_helper
DEBUG - 2017-02-20 23:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 23:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 23:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 23:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 23:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 23:17:09 --> Final output sent to browser
DEBUG - 2017-02-20 23:17:09 --> Total execution time: 0.0141
INFO - 2017-02-20 23:17:29 --> Config Class Initialized
INFO - 2017-02-20 23:17:29 --> Hooks Class Initialized
DEBUG - 2017-02-20 23:17:29 --> UTF-8 Support Enabled
INFO - 2017-02-20 23:17:29 --> Utf8 Class Initialized
INFO - 2017-02-20 23:17:29 --> URI Class Initialized
INFO - 2017-02-20 23:17:29 --> Router Class Initialized
INFO - 2017-02-20 23:17:29 --> Output Class Initialized
INFO - 2017-02-20 23:17:29 --> Security Class Initialized
DEBUG - 2017-02-20 23:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 23:17:29 --> Input Class Initialized
INFO - 2017-02-20 23:17:29 --> Language Class Initialized
INFO - 2017-02-20 23:17:29 --> Loader Class Initialized
INFO - 2017-02-20 23:17:29 --> Database Driver Class Initialized
INFO - 2017-02-20 23:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 23:17:29 --> Controller Class Initialized
INFO - 2017-02-20 23:17:29 --> Helper loaded: url_helper
DEBUG - 2017-02-20 23:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 23:17:31 --> Config Class Initialized
INFO - 2017-02-20 23:17:31 --> Hooks Class Initialized
DEBUG - 2017-02-20 23:17:31 --> UTF-8 Support Enabled
INFO - 2017-02-20 23:17:31 --> Utf8 Class Initialized
INFO - 2017-02-20 23:17:31 --> URI Class Initialized
INFO - 2017-02-20 23:17:31 --> Router Class Initialized
INFO - 2017-02-20 23:17:31 --> Output Class Initialized
INFO - 2017-02-20 23:17:31 --> Security Class Initialized
DEBUG - 2017-02-20 23:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 23:17:31 --> Input Class Initialized
INFO - 2017-02-20 23:17:31 --> Language Class Initialized
INFO - 2017-02-20 23:17:31 --> Loader Class Initialized
INFO - 2017-02-20 23:17:31 --> Database Driver Class Initialized
INFO - 2017-02-20 23:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 23:17:31 --> Controller Class Initialized
INFO - 2017-02-20 23:17:31 --> Helper loaded: date_helper
DEBUG - 2017-02-20 23:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 23:17:31 --> Helper loaded: url_helper
INFO - 2017-02-20 23:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 23:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-20 23:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-20 23:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-20 23:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 23:17:31 --> Final output sent to browser
DEBUG - 2017-02-20 23:17:31 --> Total execution time: 0.2835
INFO - 2017-02-20 23:17:45 --> Config Class Initialized
INFO - 2017-02-20 23:17:45 --> Hooks Class Initialized
DEBUG - 2017-02-20 23:17:45 --> UTF-8 Support Enabled
INFO - 2017-02-20 23:17:45 --> Utf8 Class Initialized
INFO - 2017-02-20 23:17:45 --> URI Class Initialized
DEBUG - 2017-02-20 23:17:45 --> No URI present. Default controller set.
INFO - 2017-02-20 23:17:45 --> Router Class Initialized
INFO - 2017-02-20 23:17:45 --> Output Class Initialized
INFO - 2017-02-20 23:17:45 --> Security Class Initialized
DEBUG - 2017-02-20 23:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 23:17:45 --> Input Class Initialized
INFO - 2017-02-20 23:17:45 --> Language Class Initialized
INFO - 2017-02-20 23:17:45 --> Loader Class Initialized
INFO - 2017-02-20 23:17:45 --> Database Driver Class Initialized
INFO - 2017-02-20 23:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 23:17:45 --> Controller Class Initialized
INFO - 2017-02-20 23:17:45 --> Helper loaded: url_helper
DEBUG - 2017-02-20 23:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 23:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 23:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 23:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 23:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 23:17:45 --> Final output sent to browser
DEBUG - 2017-02-20 23:17:45 --> Total execution time: 0.0464
INFO - 2017-02-20 23:18:04 --> Config Class Initialized
INFO - 2017-02-20 23:18:04 --> Hooks Class Initialized
DEBUG - 2017-02-20 23:18:04 --> UTF-8 Support Enabled
INFO - 2017-02-20 23:18:04 --> Utf8 Class Initialized
INFO - 2017-02-20 23:18:04 --> URI Class Initialized
INFO - 2017-02-20 23:18:04 --> Router Class Initialized
INFO - 2017-02-20 23:18:04 --> Output Class Initialized
INFO - 2017-02-20 23:18:04 --> Security Class Initialized
DEBUG - 2017-02-20 23:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 23:18:04 --> Input Class Initialized
INFO - 2017-02-20 23:18:04 --> Language Class Initialized
INFO - 2017-02-20 23:18:04 --> Loader Class Initialized
INFO - 2017-02-20 23:18:04 --> Database Driver Class Initialized
INFO - 2017-02-20 23:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 23:18:04 --> Controller Class Initialized
INFO - 2017-02-20 23:18:04 --> Helper loaded: url_helper
DEBUG - 2017-02-20 23:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-20 23:18:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-20 23:18:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-20 23:18:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-20 23:18:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-20 23:18:04 --> Final output sent to browser
DEBUG - 2017-02-20 23:18:04 --> Total execution time: 0.0146

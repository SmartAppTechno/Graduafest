<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-17 00:05:27 --> Config Class Initialized
INFO - 2017-03-17 00:05:27 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:05:28 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:05:28 --> Utf8 Class Initialized
INFO - 2017-03-17 00:05:28 --> URI Class Initialized
INFO - 2017-03-17 00:05:28 --> Router Class Initialized
INFO - 2017-03-17 00:05:28 --> Output Class Initialized
INFO - 2017-03-17 00:05:28 --> Security Class Initialized
DEBUG - 2017-03-17 00:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:05:28 --> Input Class Initialized
INFO - 2017-03-17 00:05:28 --> Language Class Initialized
INFO - 2017-03-17 00:05:28 --> Loader Class Initialized
INFO - 2017-03-17 00:05:28 --> Database Driver Class Initialized
INFO - 2017-03-17 00:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:05:28 --> Controller Class Initialized
INFO - 2017-03-17 00:05:28 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:05:28 --> Helper loaded: url_helper
INFO - 2017-03-17 00:05:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 00:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 00:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 00:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:05:29 --> Final output sent to browser
DEBUG - 2017-03-17 00:05:29 --> Total execution time: 1.3876
INFO - 2017-03-17 00:40:20 --> Config Class Initialized
INFO - 2017-03-17 00:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:40:20 --> Utf8 Class Initialized
INFO - 2017-03-17 00:40:20 --> URI Class Initialized
DEBUG - 2017-03-17 00:40:20 --> No URI present. Default controller set.
INFO - 2017-03-17 00:40:20 --> Router Class Initialized
INFO - 2017-03-17 00:40:20 --> Output Class Initialized
INFO - 2017-03-17 00:40:20 --> Security Class Initialized
DEBUG - 2017-03-17 00:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:40:20 --> Input Class Initialized
INFO - 2017-03-17 00:40:20 --> Language Class Initialized
INFO - 2017-03-17 00:40:20 --> Loader Class Initialized
INFO - 2017-03-17 00:40:21 --> Database Driver Class Initialized
INFO - 2017-03-17 00:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:40:21 --> Controller Class Initialized
INFO - 2017-03-17 00:40:21 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:40:21 --> Final output sent to browser
DEBUG - 2017-03-17 00:40:21 --> Total execution time: 1.2178
INFO - 2017-03-17 00:40:31 --> Config Class Initialized
INFO - 2017-03-17 00:40:31 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:40:31 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:40:31 --> Utf8 Class Initialized
INFO - 2017-03-17 00:40:31 --> URI Class Initialized
INFO - 2017-03-17 00:40:31 --> Router Class Initialized
INFO - 2017-03-17 00:40:31 --> Output Class Initialized
INFO - 2017-03-17 00:40:31 --> Security Class Initialized
DEBUG - 2017-03-17 00:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:40:31 --> Input Class Initialized
INFO - 2017-03-17 00:40:31 --> Language Class Initialized
INFO - 2017-03-17 00:40:31 --> Loader Class Initialized
INFO - 2017-03-17 00:40:31 --> Database Driver Class Initialized
INFO - 2017-03-17 00:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:40:31 --> Controller Class Initialized
INFO - 2017-03-17 00:40:31 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:40:31 --> Final output sent to browser
DEBUG - 2017-03-17 00:40:31 --> Total execution time: 0.0138
INFO - 2017-03-17 00:40:34 --> Config Class Initialized
INFO - 2017-03-17 00:40:34 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:40:34 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:40:34 --> Utf8 Class Initialized
INFO - 2017-03-17 00:40:34 --> URI Class Initialized
INFO - 2017-03-17 00:40:34 --> Router Class Initialized
INFO - 2017-03-17 00:40:34 --> Output Class Initialized
INFO - 2017-03-17 00:40:34 --> Security Class Initialized
DEBUG - 2017-03-17 00:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:40:34 --> Input Class Initialized
INFO - 2017-03-17 00:40:34 --> Language Class Initialized
INFO - 2017-03-17 00:40:34 --> Loader Class Initialized
INFO - 2017-03-17 00:40:34 --> Database Driver Class Initialized
INFO - 2017-03-17 00:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:40:34 --> Controller Class Initialized
INFO - 2017-03-17 00:40:34 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:40:36 --> Config Class Initialized
INFO - 2017-03-17 00:40:36 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:40:36 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:40:36 --> Utf8 Class Initialized
INFO - 2017-03-17 00:40:36 --> URI Class Initialized
INFO - 2017-03-17 00:40:36 --> Router Class Initialized
INFO - 2017-03-17 00:40:36 --> Output Class Initialized
INFO - 2017-03-17 00:40:36 --> Security Class Initialized
DEBUG - 2017-03-17 00:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:40:36 --> Input Class Initialized
INFO - 2017-03-17 00:40:36 --> Language Class Initialized
INFO - 2017-03-17 00:40:36 --> Loader Class Initialized
INFO - 2017-03-17 00:40:36 --> Database Driver Class Initialized
INFO - 2017-03-17 00:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:40:36 --> Controller Class Initialized
INFO - 2017-03-17 00:40:36 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:40:36 --> Helper loaded: url_helper
INFO - 2017-03-17 00:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 00:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 00:40:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:40:36 --> Final output sent to browser
DEBUG - 2017-03-17 00:40:36 --> Total execution time: 0.2663
INFO - 2017-03-17 00:40:52 --> Config Class Initialized
INFO - 2017-03-17 00:40:52 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:40:52 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:40:52 --> Utf8 Class Initialized
INFO - 2017-03-17 00:40:52 --> URI Class Initialized
INFO - 2017-03-17 00:40:52 --> Router Class Initialized
INFO - 2017-03-17 00:40:52 --> Output Class Initialized
INFO - 2017-03-17 00:40:52 --> Security Class Initialized
DEBUG - 2017-03-17 00:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:40:52 --> Input Class Initialized
INFO - 2017-03-17 00:40:52 --> Language Class Initialized
INFO - 2017-03-17 00:40:53 --> Loader Class Initialized
INFO - 2017-03-17 00:40:53 --> Database Driver Class Initialized
INFO - 2017-03-17 00:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:40:53 --> Controller Class Initialized
INFO - 2017-03-17 00:40:53 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:40:53 --> Final output sent to browser
DEBUG - 2017-03-17 00:40:53 --> Total execution time: 1.3318
INFO - 2017-03-17 00:41:03 --> Config Class Initialized
INFO - 2017-03-17 00:41:03 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:41:03 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:41:03 --> Utf8 Class Initialized
INFO - 2017-03-17 00:41:03 --> URI Class Initialized
INFO - 2017-03-17 00:41:03 --> Router Class Initialized
INFO - 2017-03-17 00:41:03 --> Output Class Initialized
INFO - 2017-03-17 00:41:04 --> Security Class Initialized
DEBUG - 2017-03-17 00:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:41:07 --> Input Class Initialized
INFO - 2017-03-17 00:41:07 --> Language Class Initialized
INFO - 2017-03-17 00:41:07 --> Loader Class Initialized
INFO - 2017-03-17 00:41:07 --> Database Driver Class Initialized
INFO - 2017-03-17 00:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:41:07 --> Controller Class Initialized
INFO - 2017-03-17 00:41:07 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:41:07 --> Helper loaded: url_helper
INFO - 2017-03-17 00:41:07 --> Helper loaded: download_helper
INFO - 2017-03-17 00:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 00:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 00:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:41:08 --> Final output sent to browser
DEBUG - 2017-03-17 00:41:08 --> Total execution time: 4.2633
INFO - 2017-03-17 00:41:13 --> Config Class Initialized
INFO - 2017-03-17 00:41:13 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:41:13 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:41:13 --> Utf8 Class Initialized
INFO - 2017-03-17 00:41:13 --> URI Class Initialized
INFO - 2017-03-17 00:41:13 --> Router Class Initialized
INFO - 2017-03-17 00:41:13 --> Output Class Initialized
INFO - 2017-03-17 00:41:13 --> Security Class Initialized
DEBUG - 2017-03-17 00:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:41:13 --> Input Class Initialized
INFO - 2017-03-17 00:41:13 --> Language Class Initialized
INFO - 2017-03-17 00:41:13 --> Loader Class Initialized
INFO - 2017-03-17 00:41:13 --> Database Driver Class Initialized
INFO - 2017-03-17 00:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:41:13 --> Controller Class Initialized
INFO - 2017-03-17 00:41:13 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:41:13 --> Final output sent to browser
DEBUG - 2017-03-17 00:41:13 --> Total execution time: 0.0283
INFO - 2017-03-17 00:42:01 --> Config Class Initialized
INFO - 2017-03-17 00:42:01 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:42:01 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:42:01 --> Utf8 Class Initialized
INFO - 2017-03-17 00:42:01 --> URI Class Initialized
INFO - 2017-03-17 00:42:01 --> Router Class Initialized
INFO - 2017-03-17 00:42:01 --> Output Class Initialized
INFO - 2017-03-17 00:42:01 --> Security Class Initialized
DEBUG - 2017-03-17 00:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:42:01 --> Input Class Initialized
INFO - 2017-03-17 00:42:01 --> Language Class Initialized
INFO - 2017-03-17 00:42:01 --> Loader Class Initialized
INFO - 2017-03-17 00:42:01 --> Database Driver Class Initialized
INFO - 2017-03-17 00:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:42:01 --> Controller Class Initialized
INFO - 2017-03-17 00:42:01 --> Helper loaded: date_helper
INFO - 2017-03-17 00:42:01 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:42:01 --> Helper loaded: form_helper
INFO - 2017-03-17 00:42:01 --> Form Validation Class Initialized
INFO - 2017-03-17 00:42:01 --> Final output sent to browser
DEBUG - 2017-03-17 00:42:01 --> Total execution time: 0.1782
INFO - 2017-03-17 00:42:27 --> Config Class Initialized
INFO - 2017-03-17 00:42:27 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:42:27 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:42:27 --> Utf8 Class Initialized
INFO - 2017-03-17 00:42:27 --> URI Class Initialized
INFO - 2017-03-17 00:42:27 --> Router Class Initialized
INFO - 2017-03-17 00:42:27 --> Output Class Initialized
INFO - 2017-03-17 00:42:27 --> Security Class Initialized
DEBUG - 2017-03-17 00:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:42:27 --> Input Class Initialized
INFO - 2017-03-17 00:42:27 --> Language Class Initialized
INFO - 2017-03-17 00:42:27 --> Loader Class Initialized
INFO - 2017-03-17 00:42:27 --> Database Driver Class Initialized
INFO - 2017-03-17 00:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:42:27 --> Controller Class Initialized
INFO - 2017-03-17 00:42:27 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:42:27 --> Helper loaded: url_helper
INFO - 2017-03-17 00:42:27 --> Helper loaded: download_helper
INFO - 2017-03-17 00:42:27 --> Final output sent to browser
DEBUG - 2017-03-17 00:42:27 --> Total execution time: 0.0567
INFO - 2017-03-17 00:42:28 --> Config Class Initialized
INFO - 2017-03-17 00:42:28 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:42:28 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:42:28 --> Utf8 Class Initialized
INFO - 2017-03-17 00:42:28 --> URI Class Initialized
INFO - 2017-03-17 00:42:28 --> Router Class Initialized
INFO - 2017-03-17 00:42:28 --> Output Class Initialized
INFO - 2017-03-17 00:42:28 --> Security Class Initialized
DEBUG - 2017-03-17 00:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:42:28 --> Input Class Initialized
INFO - 2017-03-17 00:42:28 --> Language Class Initialized
INFO - 2017-03-17 00:42:28 --> Loader Class Initialized
INFO - 2017-03-17 00:42:28 --> Database Driver Class Initialized
INFO - 2017-03-17 00:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:42:28 --> Controller Class Initialized
INFO - 2017-03-17 00:42:28 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:42:28 --> Helper loaded: url_helper
INFO - 2017-03-17 00:42:28 --> Helper loaded: download_helper
INFO - 2017-03-17 00:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 00:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 00:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:42:28 --> Final output sent to browser
DEBUG - 2017-03-17 00:42:28 --> Total execution time: 0.0529
INFO - 2017-03-17 00:42:30 --> Config Class Initialized
INFO - 2017-03-17 00:42:30 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:42:30 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:42:30 --> Utf8 Class Initialized
INFO - 2017-03-17 00:42:30 --> URI Class Initialized
INFO - 2017-03-17 00:42:30 --> Router Class Initialized
INFO - 2017-03-17 00:42:30 --> Output Class Initialized
INFO - 2017-03-17 00:42:30 --> Security Class Initialized
DEBUG - 2017-03-17 00:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:42:30 --> Input Class Initialized
INFO - 2017-03-17 00:42:30 --> Language Class Initialized
INFO - 2017-03-17 00:42:30 --> Loader Class Initialized
INFO - 2017-03-17 00:42:30 --> Database Driver Class Initialized
INFO - 2017-03-17 00:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:42:30 --> Controller Class Initialized
INFO - 2017-03-17 00:42:30 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:42:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:42:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:42:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:42:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:42:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:42:31 --> Final output sent to browser
DEBUG - 2017-03-17 00:42:31 --> Total execution time: 0.0502
INFO - 2017-03-17 00:42:59 --> Config Class Initialized
INFO - 2017-03-17 00:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:42:59 --> Utf8 Class Initialized
INFO - 2017-03-17 00:42:59 --> URI Class Initialized
DEBUG - 2017-03-17 00:42:59 --> No URI present. Default controller set.
INFO - 2017-03-17 00:42:59 --> Router Class Initialized
INFO - 2017-03-17 00:42:59 --> Output Class Initialized
INFO - 2017-03-17 00:42:59 --> Security Class Initialized
DEBUG - 2017-03-17 00:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:42:59 --> Input Class Initialized
INFO - 2017-03-17 00:42:59 --> Language Class Initialized
INFO - 2017-03-17 00:42:59 --> Loader Class Initialized
INFO - 2017-03-17 00:42:59 --> Database Driver Class Initialized
INFO - 2017-03-17 00:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:42:59 --> Controller Class Initialized
INFO - 2017-03-17 00:42:59 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:42:59 --> Final output sent to browser
DEBUG - 2017-03-17 00:42:59 --> Total execution time: 0.0777
INFO - 2017-03-17 00:45:06 --> Config Class Initialized
INFO - 2017-03-17 00:45:06 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:06 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:06 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:06 --> URI Class Initialized
INFO - 2017-03-17 00:45:06 --> Router Class Initialized
INFO - 2017-03-17 00:45:06 --> Output Class Initialized
INFO - 2017-03-17 00:45:06 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:06 --> Input Class Initialized
INFO - 2017-03-17 00:45:06 --> Language Class Initialized
INFO - 2017-03-17 00:45:06 --> Loader Class Initialized
INFO - 2017-03-17 00:45:07 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:07 --> Controller Class Initialized
INFO - 2017-03-17 00:45:07 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:07 --> Helper loaded: url_helper
INFO - 2017-03-17 00:45:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-17 00:45:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:45:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-17 00:45:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-17 00:45:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:07 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:07 --> Total execution time: 0.2711
INFO - 2017-03-17 00:45:08 --> Config Class Initialized
INFO - 2017-03-17 00:45:08 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:08 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:08 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:08 --> URI Class Initialized
INFO - 2017-03-17 00:45:08 --> Router Class Initialized
INFO - 2017-03-17 00:45:08 --> Output Class Initialized
INFO - 2017-03-17 00:45:08 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:08 --> Input Class Initialized
INFO - 2017-03-17 00:45:08 --> Language Class Initialized
INFO - 2017-03-17 00:45:08 --> Loader Class Initialized
INFO - 2017-03-17 00:45:08 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:08 --> Controller Class Initialized
INFO - 2017-03-17 00:45:08 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:45:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:45:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:08 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:08 --> Total execution time: 0.2754
INFO - 2017-03-17 00:45:15 --> Config Class Initialized
INFO - 2017-03-17 00:45:15 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:15 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:15 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:15 --> URI Class Initialized
INFO - 2017-03-17 00:45:16 --> Router Class Initialized
INFO - 2017-03-17 00:45:16 --> Output Class Initialized
INFO - 2017-03-17 00:45:16 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:16 --> Input Class Initialized
INFO - 2017-03-17 00:45:16 --> Language Class Initialized
INFO - 2017-03-17 00:45:16 --> Loader Class Initialized
INFO - 2017-03-17 00:45:16 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:16 --> Controller Class Initialized
INFO - 2017-03-17 00:45:16 --> Upload Class Initialized
INFO - 2017-03-17 00:45:16 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:16 --> Helper loaded: url_helper
INFO - 2017-03-17 00:45:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:45:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-17 00:45:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-17 00:45:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-17 00:45:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:16 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:16 --> Total execution time: 0.4584
INFO - 2017-03-17 00:45:17 --> Config Class Initialized
INFO - 2017-03-17 00:45:17 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:17 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:17 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:17 --> URI Class Initialized
INFO - 2017-03-17 00:45:17 --> Router Class Initialized
INFO - 2017-03-17 00:45:17 --> Output Class Initialized
INFO - 2017-03-17 00:45:17 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:17 --> Input Class Initialized
INFO - 2017-03-17 00:45:17 --> Language Class Initialized
INFO - 2017-03-17 00:45:17 --> Loader Class Initialized
INFO - 2017-03-17 00:45:17 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:17 --> Controller Class Initialized
INFO - 2017-03-17 00:45:17 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:45:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:45:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:45:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:17 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:17 --> Total execution time: 0.0135
INFO - 2017-03-17 00:45:41 --> Config Class Initialized
INFO - 2017-03-17 00:45:41 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:41 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:41 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:41 --> URI Class Initialized
INFO - 2017-03-17 00:45:41 --> Router Class Initialized
INFO - 2017-03-17 00:45:41 --> Output Class Initialized
INFO - 2017-03-17 00:45:41 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:41 --> Input Class Initialized
INFO - 2017-03-17 00:45:41 --> Language Class Initialized
INFO - 2017-03-17 00:45:41 --> Loader Class Initialized
INFO - 2017-03-17 00:45:41 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:42 --> Controller Class Initialized
INFO - 2017-03-17 00:45:42 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:42 --> Helper loaded: url_helper
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:42 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:42 --> Total execution time: 0.9045
INFO - 2017-03-17 00:45:42 --> Config Class Initialized
INFO - 2017-03-17 00:45:42 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:42 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:42 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:42 --> URI Class Initialized
INFO - 2017-03-17 00:45:42 --> Router Class Initialized
INFO - 2017-03-17 00:45:42 --> Output Class Initialized
INFO - 2017-03-17 00:45:42 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:42 --> Input Class Initialized
INFO - 2017-03-17 00:45:42 --> Language Class Initialized
INFO - 2017-03-17 00:45:42 --> Loader Class Initialized
INFO - 2017-03-17 00:45:42 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:42 --> Controller Class Initialized
INFO - 2017-03-17 00:45:42 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:42 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:42 --> Total execution time: 0.0385
INFO - 2017-03-17 00:45:46 --> Config Class Initialized
INFO - 2017-03-17 00:45:46 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:46 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:46 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:46 --> URI Class Initialized
INFO - 2017-03-17 00:45:46 --> Router Class Initialized
INFO - 2017-03-17 00:45:46 --> Output Class Initialized
INFO - 2017-03-17 00:45:46 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:46 --> Input Class Initialized
INFO - 2017-03-17 00:45:46 --> Language Class Initialized
INFO - 2017-03-17 00:45:46 --> Loader Class Initialized
INFO - 2017-03-17 00:45:46 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:46 --> Controller Class Initialized
INFO - 2017-03-17 00:45:46 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:46 --> Helper loaded: url_helper
INFO - 2017-03-17 00:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 00:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 00:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:46 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:46 --> Total execution time: 0.0555
INFO - 2017-03-17 00:45:47 --> Config Class Initialized
INFO - 2017-03-17 00:45:47 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:47 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:47 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:47 --> URI Class Initialized
INFO - 2017-03-17 00:45:47 --> Router Class Initialized
INFO - 2017-03-17 00:45:47 --> Output Class Initialized
INFO - 2017-03-17 00:45:47 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:47 --> Input Class Initialized
INFO - 2017-03-17 00:45:47 --> Language Class Initialized
INFO - 2017-03-17 00:45:47 --> Loader Class Initialized
INFO - 2017-03-17 00:45:47 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:47 --> Controller Class Initialized
INFO - 2017-03-17 00:45:47 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:47 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:47 --> Total execution time: 0.0133
INFO - 2017-03-17 00:45:51 --> Config Class Initialized
INFO - 2017-03-17 00:45:51 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:51 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:51 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:51 --> URI Class Initialized
INFO - 2017-03-17 00:45:51 --> Router Class Initialized
INFO - 2017-03-17 00:45:51 --> Output Class Initialized
INFO - 2017-03-17 00:45:51 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:51 --> Input Class Initialized
INFO - 2017-03-17 00:45:51 --> Language Class Initialized
INFO - 2017-03-17 00:45:51 --> Loader Class Initialized
INFO - 2017-03-17 00:45:51 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:51 --> Controller Class Initialized
INFO - 2017-03-17 00:45:51 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:51 --> Helper loaded: url_helper
INFO - 2017-03-17 00:45:51 --> Helper loaded: download_helper
INFO - 2017-03-17 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:51 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:51 --> Total execution time: 0.0992
INFO - 2017-03-17 00:45:52 --> Config Class Initialized
INFO - 2017-03-17 00:45:52 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:45:52 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:45:52 --> Utf8 Class Initialized
INFO - 2017-03-17 00:45:52 --> URI Class Initialized
INFO - 2017-03-17 00:45:52 --> Router Class Initialized
INFO - 2017-03-17 00:45:52 --> Output Class Initialized
INFO - 2017-03-17 00:45:52 --> Security Class Initialized
DEBUG - 2017-03-17 00:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:45:52 --> Input Class Initialized
INFO - 2017-03-17 00:45:52 --> Language Class Initialized
INFO - 2017-03-17 00:45:52 --> Loader Class Initialized
INFO - 2017-03-17 00:45:52 --> Database Driver Class Initialized
INFO - 2017-03-17 00:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:45:52 --> Controller Class Initialized
INFO - 2017-03-17 00:45:52 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:45:52 --> Final output sent to browser
DEBUG - 2017-03-17 00:45:52 --> Total execution time: 0.0145
INFO - 2017-03-17 00:48:23 --> Config Class Initialized
INFO - 2017-03-17 00:48:23 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:48:23 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:48:23 --> Utf8 Class Initialized
INFO - 2017-03-17 00:48:23 --> URI Class Initialized
INFO - 2017-03-17 00:48:23 --> Router Class Initialized
INFO - 2017-03-17 00:48:23 --> Output Class Initialized
INFO - 2017-03-17 00:48:23 --> Security Class Initialized
DEBUG - 2017-03-17 00:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:48:23 --> Input Class Initialized
INFO - 2017-03-17 00:48:23 --> Language Class Initialized
INFO - 2017-03-17 00:48:23 --> Loader Class Initialized
INFO - 2017-03-17 00:48:23 --> Database Driver Class Initialized
INFO - 2017-03-17 00:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:48:24 --> Controller Class Initialized
INFO - 2017-03-17 00:48:24 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:48:24 --> Helper loaded: url_helper
INFO - 2017-03-17 00:48:24 --> Helper loaded: download_helper
INFO - 2017-03-17 00:48:24 --> Final output sent to browser
DEBUG - 2017-03-17 00:48:24 --> Total execution time: 1.0189
INFO - 2017-03-17 00:48:27 --> Config Class Initialized
INFO - 2017-03-17 00:48:27 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:48:27 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:48:27 --> Utf8 Class Initialized
INFO - 2017-03-17 00:48:27 --> URI Class Initialized
INFO - 2017-03-17 00:48:27 --> Router Class Initialized
INFO - 2017-03-17 00:48:27 --> Output Class Initialized
INFO - 2017-03-17 00:48:27 --> Security Class Initialized
DEBUG - 2017-03-17 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:48:27 --> Input Class Initialized
INFO - 2017-03-17 00:48:27 --> Language Class Initialized
INFO - 2017-03-17 00:48:27 --> Loader Class Initialized
INFO - 2017-03-17 00:48:27 --> Database Driver Class Initialized
INFO - 2017-03-17 00:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:48:27 --> Controller Class Initialized
INFO - 2017-03-17 00:48:27 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:48:27 --> Helper loaded: url_helper
INFO - 2017-03-17 00:48:27 --> Helper loaded: download_helper
INFO - 2017-03-17 00:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 00:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 00:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:48:27 --> Final output sent to browser
DEBUG - 2017-03-17 00:48:27 --> Total execution time: 0.1452
INFO - 2017-03-17 00:48:30 --> Config Class Initialized
INFO - 2017-03-17 00:48:30 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:48:30 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:48:30 --> Utf8 Class Initialized
INFO - 2017-03-17 00:48:30 --> URI Class Initialized
INFO - 2017-03-17 00:48:30 --> Router Class Initialized
INFO - 2017-03-17 00:48:30 --> Output Class Initialized
INFO - 2017-03-17 00:48:30 --> Security Class Initialized
DEBUG - 2017-03-17 00:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:48:30 --> Input Class Initialized
INFO - 2017-03-17 00:48:30 --> Language Class Initialized
INFO - 2017-03-17 00:48:30 --> Loader Class Initialized
INFO - 2017-03-17 00:48:30 --> Database Driver Class Initialized
INFO - 2017-03-17 00:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:48:30 --> Controller Class Initialized
INFO - 2017-03-17 00:48:30 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:48:30 --> Final output sent to browser
DEBUG - 2017-03-17 00:48:30 --> Total execution time: 0.2581
INFO - 2017-03-17 00:48:43 --> Config Class Initialized
INFO - 2017-03-17 00:48:43 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:48:43 --> Utf8 Class Initialized
INFO - 2017-03-17 00:48:43 --> URI Class Initialized
INFO - 2017-03-17 00:48:43 --> Router Class Initialized
INFO - 2017-03-17 00:48:43 --> Output Class Initialized
INFO - 2017-03-17 00:48:43 --> Security Class Initialized
DEBUG - 2017-03-17 00:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:48:43 --> Input Class Initialized
INFO - 2017-03-17 00:48:43 --> Language Class Initialized
INFO - 2017-03-17 00:48:43 --> Loader Class Initialized
INFO - 2017-03-17 00:48:43 --> Database Driver Class Initialized
INFO - 2017-03-17 00:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:48:43 --> Controller Class Initialized
INFO - 2017-03-17 00:48:44 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:48:44 --> Helper loaded: url_helper
INFO - 2017-03-17 00:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-17 00:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-17 00:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-17 00:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:48:44 --> Final output sent to browser
DEBUG - 2017-03-17 00:48:44 --> Total execution time: 1.1032
INFO - 2017-03-17 00:48:45 --> Config Class Initialized
INFO - 2017-03-17 00:48:45 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:48:45 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:48:45 --> Utf8 Class Initialized
INFO - 2017-03-17 00:48:45 --> URI Class Initialized
INFO - 2017-03-17 00:48:45 --> Router Class Initialized
INFO - 2017-03-17 00:48:45 --> Output Class Initialized
INFO - 2017-03-17 00:48:45 --> Security Class Initialized
DEBUG - 2017-03-17 00:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:48:45 --> Input Class Initialized
INFO - 2017-03-17 00:48:45 --> Language Class Initialized
INFO - 2017-03-17 00:48:45 --> Loader Class Initialized
INFO - 2017-03-17 00:48:45 --> Database Driver Class Initialized
INFO - 2017-03-17 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:48:45 --> Controller Class Initialized
INFO - 2017-03-17 00:48:45 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:48:45 --> Final output sent to browser
DEBUG - 2017-03-17 00:48:45 --> Total execution time: 0.2634
INFO - 2017-03-17 00:48:55 --> Config Class Initialized
INFO - 2017-03-17 00:48:55 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:48:55 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:48:55 --> Utf8 Class Initialized
INFO - 2017-03-17 00:48:55 --> URI Class Initialized
INFO - 2017-03-17 00:48:55 --> Router Class Initialized
INFO - 2017-03-17 00:48:55 --> Output Class Initialized
INFO - 2017-03-17 00:48:55 --> Security Class Initialized
DEBUG - 2017-03-17 00:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:48:55 --> Input Class Initialized
INFO - 2017-03-17 00:48:55 --> Language Class Initialized
INFO - 2017-03-17 00:48:55 --> Loader Class Initialized
INFO - 2017-03-17 00:48:55 --> Database Driver Class Initialized
INFO - 2017-03-17 00:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:48:55 --> Controller Class Initialized
INFO - 2017-03-17 00:48:55 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:48:55 --> Helper loaded: url_helper
INFO - 2017-03-17 00:48:55 --> Helper loaded: download_helper
INFO - 2017-03-17 00:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 00:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 00:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:48:55 --> Final output sent to browser
DEBUG - 2017-03-17 00:48:55 --> Total execution time: 0.1237
INFO - 2017-03-17 00:48:57 --> Config Class Initialized
INFO - 2017-03-17 00:48:57 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:48:57 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:48:57 --> Utf8 Class Initialized
INFO - 2017-03-17 00:48:57 --> URI Class Initialized
INFO - 2017-03-17 00:48:57 --> Router Class Initialized
INFO - 2017-03-17 00:48:57 --> Output Class Initialized
INFO - 2017-03-17 00:48:57 --> Security Class Initialized
DEBUG - 2017-03-17 00:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:48:57 --> Input Class Initialized
INFO - 2017-03-17 00:48:57 --> Language Class Initialized
INFO - 2017-03-17 00:48:57 --> Loader Class Initialized
INFO - 2017-03-17 00:48:57 --> Database Driver Class Initialized
INFO - 2017-03-17 00:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:48:57 --> Controller Class Initialized
INFO - 2017-03-17 00:48:57 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:48:57 --> Final output sent to browser
DEBUG - 2017-03-17 00:48:57 --> Total execution time: 0.0136
INFO - 2017-03-17 00:49:05 --> Config Class Initialized
INFO - 2017-03-17 00:49:05 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:49:05 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:49:05 --> Utf8 Class Initialized
INFO - 2017-03-17 00:49:05 --> URI Class Initialized
INFO - 2017-03-17 00:49:05 --> Router Class Initialized
INFO - 2017-03-17 00:49:05 --> Output Class Initialized
INFO - 2017-03-17 00:49:05 --> Security Class Initialized
DEBUG - 2017-03-17 00:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:49:05 --> Input Class Initialized
INFO - 2017-03-17 00:49:05 --> Language Class Initialized
INFO - 2017-03-17 00:49:05 --> Loader Class Initialized
INFO - 2017-03-17 00:49:05 --> Database Driver Class Initialized
INFO - 2017-03-17 00:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:49:05 --> Controller Class Initialized
INFO - 2017-03-17 00:49:05 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:49:05 --> Helper loaded: url_helper
INFO - 2017-03-17 00:49:05 --> Helper loaded: download_helper
INFO - 2017-03-17 00:49:06 --> Config Class Initialized
INFO - 2017-03-17 00:49:06 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:49:06 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:49:06 --> Utf8 Class Initialized
INFO - 2017-03-17 00:49:06 --> URI Class Initialized
DEBUG - 2017-03-17 00:49:06 --> No URI present. Default controller set.
INFO - 2017-03-17 00:49:06 --> Router Class Initialized
INFO - 2017-03-17 00:49:06 --> Output Class Initialized
INFO - 2017-03-17 00:49:06 --> Security Class Initialized
DEBUG - 2017-03-17 00:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:49:06 --> Input Class Initialized
INFO - 2017-03-17 00:49:06 --> Language Class Initialized
INFO - 2017-03-17 00:49:06 --> Loader Class Initialized
INFO - 2017-03-17 00:49:06 --> Database Driver Class Initialized
INFO - 2017-03-17 00:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:49:06 --> Controller Class Initialized
INFO - 2017-03-17 00:49:06 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:49:06 --> Final output sent to browser
DEBUG - 2017-03-17 00:49:06 --> Total execution time: 0.0128
INFO - 2017-03-17 00:49:33 --> Config Class Initialized
INFO - 2017-03-17 00:49:33 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:49:33 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:49:33 --> Utf8 Class Initialized
INFO - 2017-03-17 00:49:33 --> URI Class Initialized
INFO - 2017-03-17 00:49:33 --> Router Class Initialized
INFO - 2017-03-17 00:49:33 --> Output Class Initialized
INFO - 2017-03-17 00:49:33 --> Security Class Initialized
DEBUG - 2017-03-17 00:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:49:33 --> Input Class Initialized
INFO - 2017-03-17 00:49:33 --> Language Class Initialized
INFO - 2017-03-17 00:49:33 --> Loader Class Initialized
INFO - 2017-03-17 00:49:33 --> Database Driver Class Initialized
INFO - 2017-03-17 00:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:49:33 --> Controller Class Initialized
INFO - 2017-03-17 00:49:33 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:50:11 --> Config Class Initialized
INFO - 2017-03-17 00:50:11 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:50:11 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:50:11 --> Utf8 Class Initialized
INFO - 2017-03-17 00:50:11 --> URI Class Initialized
INFO - 2017-03-17 00:50:11 --> Router Class Initialized
INFO - 2017-03-17 00:50:11 --> Output Class Initialized
INFO - 2017-03-17 00:50:11 --> Security Class Initialized
DEBUG - 2017-03-17 00:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:50:11 --> Input Class Initialized
INFO - 2017-03-17 00:50:11 --> Language Class Initialized
INFO - 2017-03-17 00:50:11 --> Loader Class Initialized
INFO - 2017-03-17 00:50:11 --> Database Driver Class Initialized
INFO - 2017-03-17 00:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:50:11 --> Controller Class Initialized
INFO - 2017-03-17 00:50:11 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:50:13 --> Config Class Initialized
INFO - 2017-03-17 00:50:13 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:50:13 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:50:13 --> Utf8 Class Initialized
INFO - 2017-03-17 00:50:13 --> URI Class Initialized
INFO - 2017-03-17 00:50:13 --> Router Class Initialized
INFO - 2017-03-17 00:50:13 --> Output Class Initialized
INFO - 2017-03-17 00:50:13 --> Security Class Initialized
DEBUG - 2017-03-17 00:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:50:13 --> Input Class Initialized
INFO - 2017-03-17 00:50:13 --> Language Class Initialized
INFO - 2017-03-17 00:50:13 --> Loader Class Initialized
INFO - 2017-03-17 00:50:13 --> Database Driver Class Initialized
INFO - 2017-03-17 00:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:50:13 --> Controller Class Initialized
INFO - 2017-03-17 00:50:13 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:50:13 --> Helper loaded: url_helper
INFO - 2017-03-17 00:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 00:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 00:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:50:13 --> Final output sent to browser
DEBUG - 2017-03-17 00:50:13 --> Total execution time: 0.1105
INFO - 2017-03-17 00:50:20 --> Config Class Initialized
INFO - 2017-03-17 00:50:20 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:50:20 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:50:20 --> Utf8 Class Initialized
INFO - 2017-03-17 00:50:20 --> URI Class Initialized
INFO - 2017-03-17 00:50:20 --> Router Class Initialized
INFO - 2017-03-17 00:50:20 --> Output Class Initialized
INFO - 2017-03-17 00:50:20 --> Security Class Initialized
DEBUG - 2017-03-17 00:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:50:20 --> Input Class Initialized
INFO - 2017-03-17 00:50:20 --> Language Class Initialized
INFO - 2017-03-17 00:50:20 --> Loader Class Initialized
INFO - 2017-03-17 00:50:20 --> Database Driver Class Initialized
INFO - 2017-03-17 00:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:50:20 --> Controller Class Initialized
INFO - 2017-03-17 00:50:20 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:50:20 --> Final output sent to browser
DEBUG - 2017-03-17 00:50:20 --> Total execution time: 0.0421
INFO - 2017-03-17 00:50:24 --> Config Class Initialized
INFO - 2017-03-17 00:50:24 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:50:24 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:50:24 --> Utf8 Class Initialized
INFO - 2017-03-17 00:50:24 --> URI Class Initialized
INFO - 2017-03-17 00:50:24 --> Router Class Initialized
INFO - 2017-03-17 00:50:24 --> Output Class Initialized
INFO - 2017-03-17 00:50:24 --> Security Class Initialized
DEBUG - 2017-03-17 00:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:50:24 --> Input Class Initialized
INFO - 2017-03-17 00:50:24 --> Language Class Initialized
INFO - 2017-03-17 00:50:24 --> Loader Class Initialized
INFO - 2017-03-17 00:50:24 --> Database Driver Class Initialized
INFO - 2017-03-17 00:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:50:24 --> Controller Class Initialized
INFO - 2017-03-17 00:50:24 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:50:25 --> Helper loaded: url_helper
INFO - 2017-03-17 00:50:25 --> Helper loaded: download_helper
INFO - 2017-03-17 00:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 00:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 00:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:50:25 --> Final output sent to browser
DEBUG - 2017-03-17 00:50:25 --> Total execution time: 0.1046
INFO - 2017-03-17 00:50:29 --> Config Class Initialized
INFO - 2017-03-17 00:50:29 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:50:29 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:50:29 --> Utf8 Class Initialized
INFO - 2017-03-17 00:50:29 --> URI Class Initialized
INFO - 2017-03-17 00:50:29 --> Router Class Initialized
INFO - 2017-03-17 00:50:29 --> Output Class Initialized
INFO - 2017-03-17 00:50:29 --> Security Class Initialized
DEBUG - 2017-03-17 00:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:50:29 --> Input Class Initialized
INFO - 2017-03-17 00:50:29 --> Language Class Initialized
INFO - 2017-03-17 00:50:29 --> Loader Class Initialized
INFO - 2017-03-17 00:50:29 --> Database Driver Class Initialized
INFO - 2017-03-17 00:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:50:29 --> Controller Class Initialized
INFO - 2017-03-17 00:50:29 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:50:29 --> Final output sent to browser
DEBUG - 2017-03-17 00:50:29 --> Total execution time: 0.0149
INFO - 2017-03-17 00:52:21 --> Config Class Initialized
INFO - 2017-03-17 00:52:21 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:52:21 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:52:21 --> Utf8 Class Initialized
INFO - 2017-03-17 00:52:21 --> URI Class Initialized
INFO - 2017-03-17 00:52:21 --> Router Class Initialized
INFO - 2017-03-17 00:52:21 --> Output Class Initialized
INFO - 2017-03-17 00:52:21 --> Security Class Initialized
DEBUG - 2017-03-17 00:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:52:21 --> Input Class Initialized
INFO - 2017-03-17 00:52:21 --> Language Class Initialized
INFO - 2017-03-17 00:52:21 --> Loader Class Initialized
INFO - 2017-03-17 00:52:22 --> Database Driver Class Initialized
INFO - 2017-03-17 00:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:52:22 --> Controller Class Initialized
INFO - 2017-03-17 00:52:22 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:52:22 --> Helper loaded: url_helper
INFO - 2017-03-17 00:52:22 --> Helper loaded: download_helper
INFO - 2017-03-17 00:52:22 --> Final output sent to browser
DEBUG - 2017-03-17 00:52:22 --> Total execution time: 1.0401
INFO - 2017-03-17 00:52:24 --> Config Class Initialized
INFO - 2017-03-17 00:52:24 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:52:24 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:52:24 --> Utf8 Class Initialized
INFO - 2017-03-17 00:52:24 --> URI Class Initialized
INFO - 2017-03-17 00:52:24 --> Router Class Initialized
INFO - 2017-03-17 00:52:24 --> Output Class Initialized
INFO - 2017-03-17 00:52:24 --> Security Class Initialized
DEBUG - 2017-03-17 00:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:52:24 --> Input Class Initialized
INFO - 2017-03-17 00:52:24 --> Language Class Initialized
INFO - 2017-03-17 00:52:24 --> Loader Class Initialized
INFO - 2017-03-17 00:52:24 --> Database Driver Class Initialized
INFO - 2017-03-17 00:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:52:24 --> Controller Class Initialized
INFO - 2017-03-17 00:52:24 --> Helper loaded: date_helper
DEBUG - 2017-03-17 00:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:52:24 --> Helper loaded: url_helper
INFO - 2017-03-17 00:52:24 --> Helper loaded: download_helper
INFO - 2017-03-17 00:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 00:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 00:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 00:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:52:24 --> Final output sent to browser
DEBUG - 2017-03-17 00:52:24 --> Total execution time: 0.0918
INFO - 2017-03-17 00:52:25 --> Config Class Initialized
INFO - 2017-03-17 00:52:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 00:52:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 00:52:25 --> Utf8 Class Initialized
INFO - 2017-03-17 00:52:25 --> URI Class Initialized
INFO - 2017-03-17 00:52:25 --> Router Class Initialized
INFO - 2017-03-17 00:52:25 --> Output Class Initialized
INFO - 2017-03-17 00:52:25 --> Security Class Initialized
DEBUG - 2017-03-17 00:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 00:52:25 --> Input Class Initialized
INFO - 2017-03-17 00:52:25 --> Language Class Initialized
INFO - 2017-03-17 00:52:25 --> Loader Class Initialized
INFO - 2017-03-17 00:52:25 --> Database Driver Class Initialized
INFO - 2017-03-17 00:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 00:52:25 --> Controller Class Initialized
INFO - 2017-03-17 00:52:25 --> Helper loaded: url_helper
DEBUG - 2017-03-17 00:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 00:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 00:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 00:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 00:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 00:52:26 --> Final output sent to browser
DEBUG - 2017-03-17 00:52:26 --> Total execution time: 0.2504
INFO - 2017-03-17 01:03:31 --> Config Class Initialized
INFO - 2017-03-17 01:03:31 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:03:31 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:03:31 --> Utf8 Class Initialized
INFO - 2017-03-17 01:03:31 --> URI Class Initialized
INFO - 2017-03-17 01:03:31 --> Router Class Initialized
INFO - 2017-03-17 01:03:32 --> Output Class Initialized
INFO - 2017-03-17 01:03:32 --> Security Class Initialized
DEBUG - 2017-03-17 01:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:03:32 --> Input Class Initialized
INFO - 2017-03-17 01:03:32 --> Language Class Initialized
INFO - 2017-03-17 01:03:32 --> Loader Class Initialized
INFO - 2017-03-17 01:03:32 --> Database Driver Class Initialized
INFO - 2017-03-17 01:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:03:32 --> Controller Class Initialized
INFO - 2017-03-17 01:03:32 --> Helper loaded: date_helper
DEBUG - 2017-03-17 01:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:03:32 --> Helper loaded: url_helper
INFO - 2017-03-17 01:03:32 --> Helper loaded: download_helper
INFO - 2017-03-17 01:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 01:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 01:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 01:03:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:03:32 --> Final output sent to browser
DEBUG - 2017-03-17 01:03:32 --> Total execution time: 1.1511
INFO - 2017-03-17 01:04:05 --> Config Class Initialized
INFO - 2017-03-17 01:04:05 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:04:05 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:04:05 --> Utf8 Class Initialized
INFO - 2017-03-17 01:04:05 --> URI Class Initialized
INFO - 2017-03-17 01:04:05 --> Router Class Initialized
INFO - 2017-03-17 01:04:05 --> Output Class Initialized
INFO - 2017-03-17 01:04:05 --> Security Class Initialized
DEBUG - 2017-03-17 01:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:04:06 --> Input Class Initialized
INFO - 2017-03-17 01:04:06 --> Language Class Initialized
INFO - 2017-03-17 01:04:06 --> Loader Class Initialized
INFO - 2017-03-17 01:04:06 --> Database Driver Class Initialized
INFO - 2017-03-17 01:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:04:06 --> Controller Class Initialized
INFO - 2017-03-17 01:04:06 --> Helper loaded: date_helper
DEBUG - 2017-03-17 01:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:04:06 --> Helper loaded: url_helper
INFO - 2017-03-17 01:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 01:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 01:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 01:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:04:06 --> Final output sent to browser
DEBUG - 2017-03-17 01:04:06 --> Total execution time: 1.1497
INFO - 2017-03-17 01:16:46 --> Config Class Initialized
INFO - 2017-03-17 01:16:46 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:16:46 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:16:46 --> Utf8 Class Initialized
INFO - 2017-03-17 01:16:46 --> URI Class Initialized
DEBUG - 2017-03-17 01:16:46 --> No URI present. Default controller set.
INFO - 2017-03-17 01:16:46 --> Router Class Initialized
INFO - 2017-03-17 01:16:46 --> Output Class Initialized
INFO - 2017-03-17 01:16:46 --> Security Class Initialized
DEBUG - 2017-03-17 01:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:16:46 --> Input Class Initialized
INFO - 2017-03-17 01:16:46 --> Language Class Initialized
INFO - 2017-03-17 01:16:46 --> Loader Class Initialized
INFO - 2017-03-17 01:16:47 --> Database Driver Class Initialized
INFO - 2017-03-17 01:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:16:47 --> Controller Class Initialized
INFO - 2017-03-17 01:16:47 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:16:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:16:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:16:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:16:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:16:47 --> Final output sent to browser
DEBUG - 2017-03-17 01:16:47 --> Total execution time: 1.1992
INFO - 2017-03-17 01:17:07 --> Config Class Initialized
INFO - 2017-03-17 01:17:07 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:17:07 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:17:07 --> Utf8 Class Initialized
INFO - 2017-03-17 01:17:07 --> URI Class Initialized
INFO - 2017-03-17 01:17:07 --> Router Class Initialized
INFO - 2017-03-17 01:17:07 --> Output Class Initialized
INFO - 2017-03-17 01:17:07 --> Security Class Initialized
DEBUG - 2017-03-17 01:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:17:07 --> Input Class Initialized
INFO - 2017-03-17 01:17:07 --> Language Class Initialized
INFO - 2017-03-17 01:17:07 --> Loader Class Initialized
INFO - 2017-03-17 01:17:07 --> Database Driver Class Initialized
INFO - 2017-03-17 01:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:17:08 --> Controller Class Initialized
INFO - 2017-03-17 01:17:08 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:17:08 --> Final output sent to browser
DEBUG - 2017-03-17 01:17:08 --> Total execution time: 1.3177
INFO - 2017-03-17 01:25:35 --> Config Class Initialized
INFO - 2017-03-17 01:25:35 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:25:35 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:25:35 --> Utf8 Class Initialized
INFO - 2017-03-17 01:25:35 --> URI Class Initialized
DEBUG - 2017-03-17 01:25:35 --> No URI present. Default controller set.
INFO - 2017-03-17 01:25:35 --> Router Class Initialized
INFO - 2017-03-17 01:25:35 --> Output Class Initialized
INFO - 2017-03-17 01:25:35 --> Security Class Initialized
DEBUG - 2017-03-17 01:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:25:35 --> Input Class Initialized
INFO - 2017-03-17 01:25:35 --> Language Class Initialized
INFO - 2017-03-17 01:25:35 --> Loader Class Initialized
INFO - 2017-03-17 01:25:35 --> Database Driver Class Initialized
INFO - 2017-03-17 01:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:25:35 --> Controller Class Initialized
INFO - 2017-03-17 01:25:35 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:25:36 --> Final output sent to browser
DEBUG - 2017-03-17 01:25:36 --> Total execution time: 1.2112
INFO - 2017-03-17 01:25:43 --> Config Class Initialized
INFO - 2017-03-17 01:25:43 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:25:43 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:25:43 --> Utf8 Class Initialized
INFO - 2017-03-17 01:25:43 --> URI Class Initialized
INFO - 2017-03-17 01:25:43 --> Router Class Initialized
INFO - 2017-03-17 01:25:43 --> Output Class Initialized
INFO - 2017-03-17 01:25:43 --> Security Class Initialized
DEBUG - 2017-03-17 01:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:25:43 --> Input Class Initialized
INFO - 2017-03-17 01:25:43 --> Language Class Initialized
INFO - 2017-03-17 01:25:43 --> Loader Class Initialized
INFO - 2017-03-17 01:25:43 --> Database Driver Class Initialized
INFO - 2017-03-17 01:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:25:43 --> Controller Class Initialized
INFO - 2017-03-17 01:25:43 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:25:43 --> Final output sent to browser
DEBUG - 2017-03-17 01:25:43 --> Total execution time: 0.0141
INFO - 2017-03-17 01:26:02 --> Config Class Initialized
INFO - 2017-03-17 01:26:02 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:26:02 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:26:02 --> Utf8 Class Initialized
INFO - 2017-03-17 01:26:02 --> URI Class Initialized
INFO - 2017-03-17 01:26:02 --> Router Class Initialized
INFO - 2017-03-17 01:26:02 --> Output Class Initialized
INFO - 2017-03-17 01:26:02 --> Security Class Initialized
DEBUG - 2017-03-17 01:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:26:02 --> Input Class Initialized
INFO - 2017-03-17 01:26:02 --> Language Class Initialized
INFO - 2017-03-17 01:26:02 --> Loader Class Initialized
INFO - 2017-03-17 01:26:02 --> Database Driver Class Initialized
INFO - 2017-03-17 01:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:26:02 --> Controller Class Initialized
INFO - 2017-03-17 01:26:02 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:26:04 --> Config Class Initialized
INFO - 2017-03-17 01:26:04 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:26:04 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:26:04 --> Utf8 Class Initialized
INFO - 2017-03-17 01:26:04 --> URI Class Initialized
INFO - 2017-03-17 01:26:04 --> Router Class Initialized
INFO - 2017-03-17 01:26:04 --> Output Class Initialized
INFO - 2017-03-17 01:26:04 --> Security Class Initialized
DEBUG - 2017-03-17 01:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:26:04 --> Input Class Initialized
INFO - 2017-03-17 01:26:04 --> Language Class Initialized
INFO - 2017-03-17 01:26:04 --> Loader Class Initialized
INFO - 2017-03-17 01:26:04 --> Database Driver Class Initialized
INFO - 2017-03-17 01:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:26:04 --> Controller Class Initialized
INFO - 2017-03-17 01:26:04 --> Helper loaded: date_helper
DEBUG - 2017-03-17 01:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:26:04 --> Helper loaded: url_helper
INFO - 2017-03-17 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:26:04 --> Final output sent to browser
DEBUG - 2017-03-17 01:26:04 --> Total execution time: 0.1069
INFO - 2017-03-17 01:26:06 --> Config Class Initialized
INFO - 2017-03-17 01:26:06 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:26:06 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:26:06 --> Utf8 Class Initialized
INFO - 2017-03-17 01:26:06 --> URI Class Initialized
INFO - 2017-03-17 01:26:06 --> Router Class Initialized
INFO - 2017-03-17 01:26:06 --> Output Class Initialized
INFO - 2017-03-17 01:26:06 --> Security Class Initialized
DEBUG - 2017-03-17 01:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:26:06 --> Input Class Initialized
INFO - 2017-03-17 01:26:06 --> Language Class Initialized
INFO - 2017-03-17 01:26:06 --> Loader Class Initialized
INFO - 2017-03-17 01:26:06 --> Database Driver Class Initialized
INFO - 2017-03-17 01:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:26:06 --> Controller Class Initialized
INFO - 2017-03-17 01:26:06 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:26:06 --> Final output sent to browser
DEBUG - 2017-03-17 01:26:06 --> Total execution time: 0.0132
INFO - 2017-03-17 01:30:13 --> Config Class Initialized
INFO - 2017-03-17 01:30:13 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:30:13 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:30:13 --> Utf8 Class Initialized
INFO - 2017-03-17 01:30:13 --> URI Class Initialized
INFO - 2017-03-17 01:30:13 --> Router Class Initialized
INFO - 2017-03-17 01:30:13 --> Output Class Initialized
INFO - 2017-03-17 01:30:13 --> Security Class Initialized
DEBUG - 2017-03-17 01:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:30:13 --> Input Class Initialized
INFO - 2017-03-17 01:30:13 --> Language Class Initialized
INFO - 2017-03-17 01:30:13 --> Loader Class Initialized
INFO - 2017-03-17 01:30:14 --> Database Driver Class Initialized
INFO - 2017-03-17 01:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:30:14 --> Controller Class Initialized
INFO - 2017-03-17 01:30:14 --> Helper loaded: date_helper
DEBUG - 2017-03-17 01:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:30:14 --> Helper loaded: url_helper
INFO - 2017-03-17 01:30:14 --> Helper loaded: download_helper
INFO - 2017-03-17 01:30:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:30:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 01:30:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 01:30:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 01:30:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:30:14 --> Final output sent to browser
DEBUG - 2017-03-17 01:30:14 --> Total execution time: 1.2364
INFO - 2017-03-17 01:30:15 --> Config Class Initialized
INFO - 2017-03-17 01:30:15 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:30:15 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:30:15 --> Utf8 Class Initialized
INFO - 2017-03-17 01:30:15 --> URI Class Initialized
INFO - 2017-03-17 01:30:15 --> Router Class Initialized
INFO - 2017-03-17 01:30:15 --> Output Class Initialized
INFO - 2017-03-17 01:30:15 --> Security Class Initialized
DEBUG - 2017-03-17 01:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:30:15 --> Input Class Initialized
INFO - 2017-03-17 01:30:15 --> Language Class Initialized
INFO - 2017-03-17 01:30:15 --> Loader Class Initialized
INFO - 2017-03-17 01:30:15 --> Database Driver Class Initialized
INFO - 2017-03-17 01:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:30:15 --> Controller Class Initialized
INFO - 2017-03-17 01:30:15 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:30:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:30:16 --> Final output sent to browser
DEBUG - 2017-03-17 01:30:16 --> Total execution time: 0.3735
INFO - 2017-03-17 01:31:00 --> Config Class Initialized
INFO - 2017-03-17 01:31:00 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:31:00 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:31:00 --> Utf8 Class Initialized
INFO - 2017-03-17 01:31:00 --> URI Class Initialized
INFO - 2017-03-17 01:31:00 --> Router Class Initialized
INFO - 2017-03-17 01:31:00 --> Output Class Initialized
INFO - 2017-03-17 01:31:00 --> Security Class Initialized
DEBUG - 2017-03-17 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:31:00 --> Input Class Initialized
INFO - 2017-03-17 01:31:00 --> Language Class Initialized
INFO - 2017-03-17 01:31:00 --> Loader Class Initialized
INFO - 2017-03-17 01:31:00 --> Database Driver Class Initialized
INFO - 2017-03-17 01:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:31:00 --> Controller Class Initialized
INFO - 2017-03-17 01:31:00 --> Helper loaded: date_helper
DEBUG - 2017-03-17 01:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:31:00 --> Helper loaded: url_helper
INFO - 2017-03-17 01:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-17 01:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 01:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-17 01:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-17 01:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:31:00 --> Final output sent to browser
DEBUG - 2017-03-17 01:31:00 --> Total execution time: 0.1109
INFO - 2017-03-17 01:31:01 --> Config Class Initialized
INFO - 2017-03-17 01:31:01 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:31:01 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:31:01 --> Utf8 Class Initialized
INFO - 2017-03-17 01:31:01 --> URI Class Initialized
INFO - 2017-03-17 01:31:01 --> Router Class Initialized
INFO - 2017-03-17 01:31:01 --> Output Class Initialized
INFO - 2017-03-17 01:31:01 --> Security Class Initialized
DEBUG - 2017-03-17 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:31:01 --> Input Class Initialized
INFO - 2017-03-17 01:31:01 --> Language Class Initialized
INFO - 2017-03-17 01:31:01 --> Loader Class Initialized
INFO - 2017-03-17 01:31:01 --> Database Driver Class Initialized
INFO - 2017-03-17 01:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:31:01 --> Controller Class Initialized
INFO - 2017-03-17 01:31:01 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:31:01 --> Final output sent to browser
DEBUG - 2017-03-17 01:31:01 --> Total execution time: 0.0149
INFO - 2017-03-17 01:31:24 --> Config Class Initialized
INFO - 2017-03-17 01:31:24 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:31:24 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:31:24 --> Utf8 Class Initialized
INFO - 2017-03-17 01:31:24 --> URI Class Initialized
INFO - 2017-03-17 01:31:24 --> Router Class Initialized
INFO - 2017-03-17 01:31:24 --> Output Class Initialized
INFO - 2017-03-17 01:31:24 --> Security Class Initialized
DEBUG - 2017-03-17 01:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:31:24 --> Input Class Initialized
INFO - 2017-03-17 01:31:24 --> Language Class Initialized
INFO - 2017-03-17 01:31:24 --> Loader Class Initialized
INFO - 2017-03-17 01:31:24 --> Database Driver Class Initialized
INFO - 2017-03-17 01:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:31:24 --> Controller Class Initialized
INFO - 2017-03-17 01:31:24 --> Upload Class Initialized
INFO - 2017-03-17 01:31:24 --> Helper loaded: date_helper
DEBUG - 2017-03-17 01:31:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:31:24 --> Helper loaded: url_helper
INFO - 2017-03-17 01:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 01:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-17 01:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-17 01:31:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-17 01:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:31:24 --> Final output sent to browser
DEBUG - 2017-03-17 01:31:24 --> Total execution time: 0.0908
INFO - 2017-03-17 01:31:30 --> Config Class Initialized
INFO - 2017-03-17 01:31:30 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:31:30 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:31:30 --> Utf8 Class Initialized
INFO - 2017-03-17 01:31:30 --> URI Class Initialized
INFO - 2017-03-17 01:31:30 --> Router Class Initialized
INFO - 2017-03-17 01:31:30 --> Output Class Initialized
INFO - 2017-03-17 01:31:30 --> Security Class Initialized
DEBUG - 2017-03-17 01:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:31:30 --> Input Class Initialized
INFO - 2017-03-17 01:31:30 --> Language Class Initialized
INFO - 2017-03-17 01:31:30 --> Loader Class Initialized
INFO - 2017-03-17 01:31:30 --> Database Driver Class Initialized
INFO - 2017-03-17 01:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:31:30 --> Controller Class Initialized
INFO - 2017-03-17 01:31:30 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:31:30 --> Final output sent to browser
DEBUG - 2017-03-17 01:31:30 --> Total execution time: 0.0133
INFO - 2017-03-17 01:40:45 --> Config Class Initialized
INFO - 2017-03-17 01:40:45 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:40:45 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:40:45 --> Utf8 Class Initialized
INFO - 2017-03-17 01:40:45 --> URI Class Initialized
INFO - 2017-03-17 01:40:45 --> Router Class Initialized
INFO - 2017-03-17 01:40:45 --> Output Class Initialized
INFO - 2017-03-17 01:40:45 --> Security Class Initialized
DEBUG - 2017-03-17 01:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:40:45 --> Input Class Initialized
INFO - 2017-03-17 01:40:45 --> Language Class Initialized
INFO - 2017-03-17 01:40:45 --> Loader Class Initialized
INFO - 2017-03-17 01:40:45 --> Config Class Initialized
INFO - 2017-03-17 01:40:45 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:40:45 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:40:45 --> Utf8 Class Initialized
INFO - 2017-03-17 01:40:45 --> URI Class Initialized
INFO - 2017-03-17 01:40:45 --> Router Class Initialized
INFO - 2017-03-17 01:40:45 --> Output Class Initialized
INFO - 2017-03-17 01:40:45 --> Security Class Initialized
DEBUG - 2017-03-17 01:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:40:45 --> Input Class Initialized
INFO - 2017-03-17 01:40:45 --> Language Class Initialized
INFO - 2017-03-17 01:40:45 --> Loader Class Initialized
INFO - 2017-03-17 01:40:45 --> Database Driver Class Initialized
INFO - 2017-03-17 01:40:45 --> Database Driver Class Initialized
INFO - 2017-03-17 01:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:40:45 --> Controller Class Initialized
INFO - 2017-03-17 01:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:40:45 --> Controller Class Initialized
INFO - 2017-03-17 01:40:45 --> Config Class Initialized
INFO - 2017-03-17 01:40:45 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:40:45 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:40:45 --> Utf8 Class Initialized
INFO - 2017-03-17 01:40:45 --> URI Class Initialized
INFO - 2017-03-17 01:40:45 --> Router Class Initialized
INFO - 2017-03-17 01:40:45 --> Output Class Initialized
INFO - 2017-03-17 01:40:45 --> Security Class Initialized
DEBUG - 2017-03-17 01:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:40:45 --> Input Class Initialized
INFO - 2017-03-17 01:40:45 --> Language Class Initialized
INFO - 2017-03-17 01:40:45 --> Loader Class Initialized
INFO - 2017-03-17 01:40:45 --> Database Driver Class Initialized
INFO - 2017-03-17 01:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:40:45 --> Controller Class Initialized
INFO - 2017-03-17 01:40:46 --> Helper loaded: date_helper
INFO - 2017-03-17 01:40:46 --> Helper loaded: date_helper
DEBUG - 2017-03-17 01:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-17 01:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:40:46 --> Helper loaded: date_helper
INFO - 2017-03-17 01:40:46 --> Helper loaded: url_helper
INFO - 2017-03-17 01:40:46 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:40:46 --> Helper loaded: url_helper
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:40:46 --> Final output sent to browser
DEBUG - 2017-03-17 01:40:46 --> Total execution time: 0.2240
INFO - 2017-03-17 01:40:46 --> Final output sent to browser
DEBUG - 2017-03-17 01:40:46 --> Total execution time: 0.6542
INFO - 2017-03-17 01:40:46 --> Final output sent to browser
DEBUG - 2017-03-17 01:40:46 --> Total execution time: 1.0878
INFO - 2017-03-17 01:51:00 --> Config Class Initialized
INFO - 2017-03-17 01:51:00 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:51:00 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:51:00 --> Utf8 Class Initialized
INFO - 2017-03-17 01:51:00 --> URI Class Initialized
INFO - 2017-03-17 01:51:00 --> Router Class Initialized
INFO - 2017-03-17 01:51:00 --> Output Class Initialized
INFO - 2017-03-17 01:51:00 --> Security Class Initialized
DEBUG - 2017-03-17 01:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:51:00 --> Input Class Initialized
INFO - 2017-03-17 01:51:00 --> Language Class Initialized
INFO - 2017-03-17 01:51:01 --> Loader Class Initialized
INFO - 2017-03-17 01:51:01 --> Database Driver Class Initialized
INFO - 2017-03-17 01:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:51:01 --> Controller Class Initialized
INFO - 2017-03-17 01:51:01 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:51:02 --> Final output sent to browser
DEBUG - 2017-03-17 01:51:02 --> Total execution time: 1.4588
INFO - 2017-03-17 01:51:56 --> Config Class Initialized
INFO - 2017-03-17 01:51:56 --> Hooks Class Initialized
DEBUG - 2017-03-17 01:51:56 --> UTF-8 Support Enabled
INFO - 2017-03-17 01:51:56 --> Utf8 Class Initialized
INFO - 2017-03-17 01:51:56 --> URI Class Initialized
DEBUG - 2017-03-17 01:51:56 --> No URI present. Default controller set.
INFO - 2017-03-17 01:51:56 --> Router Class Initialized
INFO - 2017-03-17 01:51:56 --> Output Class Initialized
INFO - 2017-03-17 01:51:56 --> Security Class Initialized
DEBUG - 2017-03-17 01:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 01:51:56 --> Input Class Initialized
INFO - 2017-03-17 01:51:56 --> Language Class Initialized
INFO - 2017-03-17 01:51:56 --> Loader Class Initialized
INFO - 2017-03-17 01:51:56 --> Database Driver Class Initialized
INFO - 2017-03-17 01:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 01:51:56 --> Controller Class Initialized
INFO - 2017-03-17 01:51:56 --> Helper loaded: url_helper
DEBUG - 2017-03-17 01:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 01:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 01:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 01:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 01:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 01:51:56 --> Final output sent to browser
DEBUG - 2017-03-17 01:51:56 --> Total execution time: 0.0779
INFO - 2017-03-17 02:09:48 --> Config Class Initialized
INFO - 2017-03-17 02:09:48 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:09:48 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:09:48 --> Utf8 Class Initialized
INFO - 2017-03-17 02:09:48 --> URI Class Initialized
INFO - 2017-03-17 02:09:48 --> Router Class Initialized
INFO - 2017-03-17 02:09:48 --> Output Class Initialized
INFO - 2017-03-17 02:09:48 --> Security Class Initialized
DEBUG - 2017-03-17 02:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:09:48 --> Input Class Initialized
INFO - 2017-03-17 02:09:48 --> Language Class Initialized
INFO - 2017-03-17 02:09:48 --> Loader Class Initialized
INFO - 2017-03-17 02:09:48 --> Database Driver Class Initialized
INFO - 2017-03-17 02:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:09:48 --> Controller Class Initialized
INFO - 2017-03-17 02:09:48 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:09:49 --> Final output sent to browser
DEBUG - 2017-03-17 02:09:49 --> Total execution time: 1.2179
INFO - 2017-03-17 02:10:15 --> Config Class Initialized
INFO - 2017-03-17 02:10:15 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:10:15 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:10:15 --> Utf8 Class Initialized
INFO - 2017-03-17 02:10:15 --> URI Class Initialized
DEBUG - 2017-03-17 02:10:15 --> No URI present. Default controller set.
INFO - 2017-03-17 02:10:15 --> Router Class Initialized
INFO - 2017-03-17 02:10:15 --> Output Class Initialized
INFO - 2017-03-17 02:10:15 --> Security Class Initialized
DEBUG - 2017-03-17 02:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:10:15 --> Input Class Initialized
INFO - 2017-03-17 02:10:15 --> Language Class Initialized
INFO - 2017-03-17 02:10:15 --> Loader Class Initialized
INFO - 2017-03-17 02:10:15 --> Database Driver Class Initialized
INFO - 2017-03-17 02:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:10:15 --> Controller Class Initialized
INFO - 2017-03-17 02:10:15 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:10:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:10:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:10:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:10:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:10:15 --> Final output sent to browser
DEBUG - 2017-03-17 02:10:15 --> Total execution time: 0.1110
INFO - 2017-03-17 02:34:57 --> Config Class Initialized
INFO - 2017-03-17 02:34:57 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:34:57 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:34:57 --> Utf8 Class Initialized
INFO - 2017-03-17 02:34:57 --> URI Class Initialized
DEBUG - 2017-03-17 02:34:57 --> No URI present. Default controller set.
INFO - 2017-03-17 02:34:57 --> Router Class Initialized
INFO - 2017-03-17 02:34:57 --> Output Class Initialized
INFO - 2017-03-17 02:34:57 --> Security Class Initialized
DEBUG - 2017-03-17 02:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:34:57 --> Input Class Initialized
INFO - 2017-03-17 02:34:57 --> Language Class Initialized
INFO - 2017-03-17 02:34:57 --> Loader Class Initialized
INFO - 2017-03-17 02:34:58 --> Database Driver Class Initialized
INFO - 2017-03-17 02:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:34:58 --> Controller Class Initialized
INFO - 2017-03-17 02:34:58 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:34:58 --> Final output sent to browser
DEBUG - 2017-03-17 02:34:58 --> Total execution time: 1.2051
INFO - 2017-03-17 02:35:04 --> Config Class Initialized
INFO - 2017-03-17 02:35:04 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:35:04 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:35:04 --> Utf8 Class Initialized
INFO - 2017-03-17 02:35:04 --> URI Class Initialized
INFO - 2017-03-17 02:35:04 --> Router Class Initialized
INFO - 2017-03-17 02:35:04 --> Output Class Initialized
INFO - 2017-03-17 02:35:04 --> Security Class Initialized
DEBUG - 2017-03-17 02:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:35:04 --> Input Class Initialized
INFO - 2017-03-17 02:35:04 --> Language Class Initialized
INFO - 2017-03-17 02:35:04 --> Loader Class Initialized
INFO - 2017-03-17 02:35:04 --> Database Driver Class Initialized
INFO - 2017-03-17 02:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:35:04 --> Controller Class Initialized
INFO - 2017-03-17 02:35:04 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:35:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:35:04 --> Final output sent to browser
DEBUG - 2017-03-17 02:35:04 --> Total execution time: 0.0133
INFO - 2017-03-17 02:35:14 --> Config Class Initialized
INFO - 2017-03-17 02:35:14 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:35:14 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:35:14 --> Utf8 Class Initialized
INFO - 2017-03-17 02:35:14 --> URI Class Initialized
INFO - 2017-03-17 02:35:14 --> Router Class Initialized
INFO - 2017-03-17 02:35:14 --> Output Class Initialized
INFO - 2017-03-17 02:35:14 --> Security Class Initialized
DEBUG - 2017-03-17 02:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:35:14 --> Input Class Initialized
INFO - 2017-03-17 02:35:14 --> Language Class Initialized
INFO - 2017-03-17 02:35:14 --> Loader Class Initialized
INFO - 2017-03-17 02:35:14 --> Database Driver Class Initialized
INFO - 2017-03-17 02:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:35:14 --> Controller Class Initialized
INFO - 2017-03-17 02:35:14 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:35:17 --> Config Class Initialized
INFO - 2017-03-17 02:35:17 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:35:17 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:35:17 --> Utf8 Class Initialized
INFO - 2017-03-17 02:35:17 --> URI Class Initialized
INFO - 2017-03-17 02:35:17 --> Router Class Initialized
INFO - 2017-03-17 02:35:17 --> Output Class Initialized
INFO - 2017-03-17 02:35:17 --> Security Class Initialized
DEBUG - 2017-03-17 02:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:35:17 --> Input Class Initialized
INFO - 2017-03-17 02:35:17 --> Language Class Initialized
INFO - 2017-03-17 02:35:17 --> Loader Class Initialized
INFO - 2017-03-17 02:35:17 --> Database Driver Class Initialized
INFO - 2017-03-17 02:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:35:17 --> Controller Class Initialized
INFO - 2017-03-17 02:35:17 --> Helper loaded: date_helper
DEBUG - 2017-03-17 02:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:35:17 --> Helper loaded: url_helper
INFO - 2017-03-17 02:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 02:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 02:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 02:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:35:17 --> Final output sent to browser
DEBUG - 2017-03-17 02:35:17 --> Total execution time: 0.3603
INFO - 2017-03-17 02:35:18 --> Config Class Initialized
INFO - 2017-03-17 02:35:18 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:35:18 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:35:18 --> Utf8 Class Initialized
INFO - 2017-03-17 02:35:18 --> URI Class Initialized
INFO - 2017-03-17 02:35:18 --> Router Class Initialized
INFO - 2017-03-17 02:35:18 --> Output Class Initialized
INFO - 2017-03-17 02:35:18 --> Security Class Initialized
DEBUG - 2017-03-17 02:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:35:18 --> Input Class Initialized
INFO - 2017-03-17 02:35:18 --> Language Class Initialized
INFO - 2017-03-17 02:35:18 --> Loader Class Initialized
INFO - 2017-03-17 02:35:18 --> Database Driver Class Initialized
INFO - 2017-03-17 02:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:35:18 --> Controller Class Initialized
INFO - 2017-03-17 02:35:18 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:35:18 --> Final output sent to browser
DEBUG - 2017-03-17 02:35:18 --> Total execution time: 0.0145
INFO - 2017-03-17 02:35:21 --> Config Class Initialized
INFO - 2017-03-17 02:35:21 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:35:21 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:35:21 --> Utf8 Class Initialized
INFO - 2017-03-17 02:35:21 --> URI Class Initialized
DEBUG - 2017-03-17 02:35:21 --> No URI present. Default controller set.
INFO - 2017-03-17 02:35:21 --> Router Class Initialized
INFO - 2017-03-17 02:35:21 --> Output Class Initialized
INFO - 2017-03-17 02:35:21 --> Security Class Initialized
DEBUG - 2017-03-17 02:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:35:21 --> Input Class Initialized
INFO - 2017-03-17 02:35:21 --> Language Class Initialized
INFO - 2017-03-17 02:35:21 --> Loader Class Initialized
INFO - 2017-03-17 02:35:21 --> Database Driver Class Initialized
INFO - 2017-03-17 02:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:35:21 --> Controller Class Initialized
INFO - 2017-03-17 02:35:21 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:35:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:35:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:35:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:35:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:35:21 --> Final output sent to browser
DEBUG - 2017-03-17 02:35:21 --> Total execution time: 0.0135
INFO - 2017-03-17 02:35:22 --> Config Class Initialized
INFO - 2017-03-17 02:35:22 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:35:22 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:35:22 --> Utf8 Class Initialized
INFO - 2017-03-17 02:35:22 --> URI Class Initialized
INFO - 2017-03-17 02:35:22 --> Router Class Initialized
INFO - 2017-03-17 02:35:22 --> Output Class Initialized
INFO - 2017-03-17 02:35:22 --> Security Class Initialized
DEBUG - 2017-03-17 02:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:35:22 --> Input Class Initialized
INFO - 2017-03-17 02:35:22 --> Language Class Initialized
INFO - 2017-03-17 02:35:22 --> Loader Class Initialized
INFO - 2017-03-17 02:35:22 --> Database Driver Class Initialized
INFO - 2017-03-17 02:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:35:22 --> Controller Class Initialized
INFO - 2017-03-17 02:35:22 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:35:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:35:22 --> Final output sent to browser
DEBUG - 2017-03-17 02:35:22 --> Total execution time: 0.0135
INFO - 2017-03-17 02:36:06 --> Config Class Initialized
INFO - 2017-03-17 02:36:06 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:06 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:06 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:06 --> URI Class Initialized
INFO - 2017-03-17 02:36:06 --> Router Class Initialized
INFO - 2017-03-17 02:36:07 --> Output Class Initialized
INFO - 2017-03-17 02:36:07 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:07 --> Input Class Initialized
INFO - 2017-03-17 02:36:07 --> Language Class Initialized
INFO - 2017-03-17 02:36:07 --> Loader Class Initialized
INFO - 2017-03-17 02:36:07 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:07 --> Controller Class Initialized
INFO - 2017-03-17 02:36:07 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:10 --> Config Class Initialized
INFO - 2017-03-17 02:36:10 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:10 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:10 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:10 --> URI Class Initialized
INFO - 2017-03-17 02:36:10 --> Router Class Initialized
INFO - 2017-03-17 02:36:10 --> Output Class Initialized
INFO - 2017-03-17 02:36:10 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:10 --> Input Class Initialized
INFO - 2017-03-17 02:36:10 --> Language Class Initialized
INFO - 2017-03-17 02:36:10 --> Loader Class Initialized
INFO - 2017-03-17 02:36:10 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:10 --> Controller Class Initialized
INFO - 2017-03-17 02:36:10 --> Helper loaded: date_helper
DEBUG - 2017-03-17 02:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:10 --> Helper loaded: url_helper
INFO - 2017-03-17 02:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 02:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 02:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 02:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:10 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:10 --> Total execution time: 0.2588
INFO - 2017-03-17 02:36:10 --> Config Class Initialized
INFO - 2017-03-17 02:36:10 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:10 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:10 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:10 --> URI Class Initialized
INFO - 2017-03-17 02:36:10 --> Router Class Initialized
INFO - 2017-03-17 02:36:10 --> Output Class Initialized
INFO - 2017-03-17 02:36:10 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:10 --> Input Class Initialized
INFO - 2017-03-17 02:36:10 --> Language Class Initialized
INFO - 2017-03-17 02:36:10 --> Loader Class Initialized
INFO - 2017-03-17 02:36:11 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:11 --> Controller Class Initialized
INFO - 2017-03-17 02:36:11 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:11 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:11 --> Total execution time: 0.6727
INFO - 2017-03-17 02:36:14 --> Config Class Initialized
INFO - 2017-03-17 02:36:14 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:14 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:14 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:14 --> URI Class Initialized
DEBUG - 2017-03-17 02:36:14 --> No URI present. Default controller set.
INFO - 2017-03-17 02:36:14 --> Router Class Initialized
INFO - 2017-03-17 02:36:14 --> Output Class Initialized
INFO - 2017-03-17 02:36:14 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:14 --> Input Class Initialized
INFO - 2017-03-17 02:36:14 --> Language Class Initialized
INFO - 2017-03-17 02:36:14 --> Loader Class Initialized
INFO - 2017-03-17 02:36:14 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:14 --> Controller Class Initialized
INFO - 2017-03-17 02:36:14 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:14 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:14 --> Total execution time: 0.5624
INFO - 2017-03-17 02:36:15 --> Config Class Initialized
INFO - 2017-03-17 02:36:15 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:16 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:16 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:16 --> URI Class Initialized
INFO - 2017-03-17 02:36:16 --> Router Class Initialized
INFO - 2017-03-17 02:36:16 --> Output Class Initialized
INFO - 2017-03-17 02:36:16 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:16 --> Input Class Initialized
INFO - 2017-03-17 02:36:16 --> Language Class Initialized
INFO - 2017-03-17 02:36:16 --> Loader Class Initialized
INFO - 2017-03-17 02:36:16 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:16 --> Controller Class Initialized
INFO - 2017-03-17 02:36:16 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:17 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:17 --> Total execution time: 1.2108
INFO - 2017-03-17 02:36:21 --> Config Class Initialized
INFO - 2017-03-17 02:36:21 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:21 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:21 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:21 --> URI Class Initialized
INFO - 2017-03-17 02:36:21 --> Router Class Initialized
INFO - 2017-03-17 02:36:21 --> Output Class Initialized
INFO - 2017-03-17 02:36:21 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:21 --> Input Class Initialized
INFO - 2017-03-17 02:36:21 --> Language Class Initialized
INFO - 2017-03-17 02:36:21 --> Loader Class Initialized
INFO - 2017-03-17 02:36:21 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:21 --> Controller Class Initialized
INFO - 2017-03-17 02:36:21 --> Helper loaded: date_helper
DEBUG - 2017-03-17 02:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:21 --> Helper loaded: url_helper
INFO - 2017-03-17 02:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 02:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 02:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 02:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:21 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:21 --> Total execution time: 0.8903
INFO - 2017-03-17 02:36:22 --> Config Class Initialized
INFO - 2017-03-17 02:36:22 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:22 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:22 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:22 --> URI Class Initialized
INFO - 2017-03-17 02:36:22 --> Router Class Initialized
INFO - 2017-03-17 02:36:22 --> Output Class Initialized
INFO - 2017-03-17 02:36:22 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:22 --> Input Class Initialized
INFO - 2017-03-17 02:36:22 --> Language Class Initialized
INFO - 2017-03-17 02:36:22 --> Loader Class Initialized
INFO - 2017-03-17 02:36:22 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:23 --> Controller Class Initialized
INFO - 2017-03-17 02:36:23 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:23 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:23 --> Total execution time: 1.2189
INFO - 2017-03-17 02:36:24 --> Config Class Initialized
INFO - 2017-03-17 02:36:24 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:24 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:24 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:24 --> URI Class Initialized
DEBUG - 2017-03-17 02:36:24 --> No URI present. Default controller set.
INFO - 2017-03-17 02:36:24 --> Router Class Initialized
INFO - 2017-03-17 02:36:24 --> Output Class Initialized
INFO - 2017-03-17 02:36:24 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:24 --> Input Class Initialized
INFO - 2017-03-17 02:36:24 --> Language Class Initialized
INFO - 2017-03-17 02:36:24 --> Loader Class Initialized
INFO - 2017-03-17 02:36:24 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:24 --> Controller Class Initialized
INFO - 2017-03-17 02:36:24 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:24 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:24 --> Total execution time: 0.0148
INFO - 2017-03-17 02:36:25 --> Config Class Initialized
INFO - 2017-03-17 02:36:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:25 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:25 --> URI Class Initialized
INFO - 2017-03-17 02:36:25 --> Router Class Initialized
INFO - 2017-03-17 02:36:25 --> Output Class Initialized
INFO - 2017-03-17 02:36:25 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:25 --> Input Class Initialized
INFO - 2017-03-17 02:36:25 --> Language Class Initialized
INFO - 2017-03-17 02:36:25 --> Loader Class Initialized
INFO - 2017-03-17 02:36:25 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:25 --> Controller Class Initialized
INFO - 2017-03-17 02:36:25 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:25 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:25 --> Total execution time: 0.0138
INFO - 2017-03-17 02:36:39 --> Config Class Initialized
INFO - 2017-03-17 02:36:39 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:39 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:39 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:39 --> URI Class Initialized
INFO - 2017-03-17 02:36:39 --> Router Class Initialized
INFO - 2017-03-17 02:36:39 --> Output Class Initialized
INFO - 2017-03-17 02:36:39 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:39 --> Input Class Initialized
INFO - 2017-03-17 02:36:39 --> Language Class Initialized
INFO - 2017-03-17 02:36:39 --> Loader Class Initialized
INFO - 2017-03-17 02:36:39 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:39 --> Controller Class Initialized
INFO - 2017-03-17 02:36:39 --> Helper loaded: date_helper
DEBUG - 2017-03-17 02:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:39 --> Helper loaded: url_helper
INFO - 2017-03-17 02:36:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:40 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:40 --> Total execution time: 0.1159
INFO - 2017-03-17 02:36:40 --> Config Class Initialized
INFO - 2017-03-17 02:36:40 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:40 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:40 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:40 --> URI Class Initialized
INFO - 2017-03-17 02:36:40 --> Router Class Initialized
INFO - 2017-03-17 02:36:40 --> Output Class Initialized
INFO - 2017-03-17 02:36:40 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:40 --> Input Class Initialized
INFO - 2017-03-17 02:36:40 --> Language Class Initialized
INFO - 2017-03-17 02:36:40 --> Loader Class Initialized
INFO - 2017-03-17 02:36:40 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:40 --> Controller Class Initialized
INFO - 2017-03-17 02:36:40 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:40 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:40 --> Total execution time: 0.0151
INFO - 2017-03-17 02:36:41 --> Config Class Initialized
INFO - 2017-03-17 02:36:41 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:41 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:41 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:41 --> URI Class Initialized
DEBUG - 2017-03-17 02:36:41 --> No URI present. Default controller set.
INFO - 2017-03-17 02:36:41 --> Router Class Initialized
INFO - 2017-03-17 02:36:41 --> Output Class Initialized
INFO - 2017-03-17 02:36:41 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:41 --> Input Class Initialized
INFO - 2017-03-17 02:36:41 --> Language Class Initialized
INFO - 2017-03-17 02:36:41 --> Loader Class Initialized
INFO - 2017-03-17 02:36:41 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:41 --> Controller Class Initialized
INFO - 2017-03-17 02:36:41 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:41 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:41 --> Total execution time: 0.0143
INFO - 2017-03-17 02:36:42 --> Config Class Initialized
INFO - 2017-03-17 02:36:42 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:36:42 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:36:42 --> Utf8 Class Initialized
INFO - 2017-03-17 02:36:42 --> URI Class Initialized
INFO - 2017-03-17 02:36:42 --> Router Class Initialized
INFO - 2017-03-17 02:36:42 --> Output Class Initialized
INFO - 2017-03-17 02:36:42 --> Security Class Initialized
DEBUG - 2017-03-17 02:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:36:42 --> Input Class Initialized
INFO - 2017-03-17 02:36:42 --> Language Class Initialized
INFO - 2017-03-17 02:36:42 --> Loader Class Initialized
INFO - 2017-03-17 02:36:42 --> Database Driver Class Initialized
INFO - 2017-03-17 02:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:36:42 --> Controller Class Initialized
INFO - 2017-03-17 02:36:42 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:36:42 --> Final output sent to browser
DEBUG - 2017-03-17 02:36:42 --> Total execution time: 0.0134
INFO - 2017-03-17 02:48:22 --> Config Class Initialized
INFO - 2017-03-17 02:48:22 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:48:22 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:48:22 --> Utf8 Class Initialized
INFO - 2017-03-17 02:48:22 --> URI Class Initialized
INFO - 2017-03-17 02:48:23 --> Router Class Initialized
INFO - 2017-03-17 02:48:23 --> Output Class Initialized
INFO - 2017-03-17 02:48:23 --> Security Class Initialized
DEBUG - 2017-03-17 02:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:48:23 --> Input Class Initialized
INFO - 2017-03-17 02:48:23 --> Language Class Initialized
INFO - 2017-03-17 02:48:23 --> Loader Class Initialized
INFO - 2017-03-17 02:48:23 --> Database Driver Class Initialized
INFO - 2017-03-17 02:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:48:23 --> Controller Class Initialized
INFO - 2017-03-17 02:48:23 --> Helper loaded: date_helper
DEBUG - 2017-03-17 02:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:48:23 --> Helper loaded: url_helper
INFO - 2017-03-17 02:48:23 --> Helper loaded: download_helper
INFO - 2017-03-17 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 02:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:48:23 --> Final output sent to browser
DEBUG - 2017-03-17 02:48:23 --> Total execution time: 1.1679
INFO - 2017-03-17 02:48:26 --> Config Class Initialized
INFO - 2017-03-17 02:48:26 --> Hooks Class Initialized
DEBUG - 2017-03-17 02:48:26 --> UTF-8 Support Enabled
INFO - 2017-03-17 02:48:26 --> Utf8 Class Initialized
INFO - 2017-03-17 02:48:26 --> URI Class Initialized
INFO - 2017-03-17 02:48:26 --> Router Class Initialized
INFO - 2017-03-17 02:48:26 --> Output Class Initialized
INFO - 2017-03-17 02:48:26 --> Security Class Initialized
DEBUG - 2017-03-17 02:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 02:48:26 --> Input Class Initialized
INFO - 2017-03-17 02:48:26 --> Language Class Initialized
INFO - 2017-03-17 02:48:26 --> Loader Class Initialized
INFO - 2017-03-17 02:48:26 --> Database Driver Class Initialized
INFO - 2017-03-17 02:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 02:48:26 --> Controller Class Initialized
INFO - 2017-03-17 02:48:26 --> Helper loaded: url_helper
DEBUG - 2017-03-17 02:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 02:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 02:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 02:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 02:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 02:48:27 --> Final output sent to browser
DEBUG - 2017-03-17 02:48:27 --> Total execution time: 0.5201
INFO - 2017-03-17 03:24:00 --> Config Class Initialized
INFO - 2017-03-17 03:24:00 --> Hooks Class Initialized
DEBUG - 2017-03-17 03:24:00 --> UTF-8 Support Enabled
INFO - 2017-03-17 03:24:00 --> Utf8 Class Initialized
INFO - 2017-03-17 03:24:00 --> URI Class Initialized
DEBUG - 2017-03-17 03:24:00 --> No URI present. Default controller set.
INFO - 2017-03-17 03:24:00 --> Router Class Initialized
INFO - 2017-03-17 03:24:00 --> Output Class Initialized
INFO - 2017-03-17 03:24:00 --> Security Class Initialized
DEBUG - 2017-03-17 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 03:24:00 --> Input Class Initialized
INFO - 2017-03-17 03:24:00 --> Language Class Initialized
INFO - 2017-03-17 03:24:00 --> Loader Class Initialized
INFO - 2017-03-17 03:24:00 --> Database Driver Class Initialized
INFO - 2017-03-17 03:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 03:24:00 --> Controller Class Initialized
INFO - 2017-03-17 03:24:00 --> Helper loaded: url_helper
DEBUG - 2017-03-17 03:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 03:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 03:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 03:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 03:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 03:24:01 --> Final output sent to browser
DEBUG - 2017-03-17 03:24:01 --> Total execution time: 1.1891
INFO - 2017-03-17 03:24:44 --> Config Class Initialized
INFO - 2017-03-17 03:24:44 --> Hooks Class Initialized
DEBUG - 2017-03-17 03:24:44 --> UTF-8 Support Enabled
INFO - 2017-03-17 03:24:44 --> Utf8 Class Initialized
INFO - 2017-03-17 03:24:44 --> URI Class Initialized
INFO - 2017-03-17 03:24:44 --> Router Class Initialized
INFO - 2017-03-17 03:24:44 --> Output Class Initialized
INFO - 2017-03-17 03:24:44 --> Security Class Initialized
DEBUG - 2017-03-17 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 03:24:44 --> Input Class Initialized
INFO - 2017-03-17 03:24:44 --> Language Class Initialized
INFO - 2017-03-17 03:24:44 --> Loader Class Initialized
INFO - 2017-03-17 03:24:44 --> Database Driver Class Initialized
INFO - 2017-03-17 03:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 03:24:44 --> Controller Class Initialized
INFO - 2017-03-17 03:24:44 --> Helper loaded: url_helper
DEBUG - 2017-03-17 03:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 03:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 03:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 03:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 03:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 03:24:45 --> Final output sent to browser
DEBUG - 2017-03-17 03:24:45 --> Total execution time: 0.9263
INFO - 2017-03-17 03:25:54 --> Config Class Initialized
INFO - 2017-03-17 03:25:54 --> Hooks Class Initialized
DEBUG - 2017-03-17 03:25:55 --> UTF-8 Support Enabled
INFO - 2017-03-17 03:25:55 --> Utf8 Class Initialized
INFO - 2017-03-17 03:25:55 --> URI Class Initialized
INFO - 2017-03-17 03:25:55 --> Router Class Initialized
INFO - 2017-03-17 03:25:55 --> Output Class Initialized
INFO - 2017-03-17 03:25:55 --> Security Class Initialized
DEBUG - 2017-03-17 03:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 03:25:55 --> Input Class Initialized
INFO - 2017-03-17 03:25:55 --> Language Class Initialized
INFO - 2017-03-17 03:25:55 --> Loader Class Initialized
INFO - 2017-03-17 03:25:55 --> Database Driver Class Initialized
INFO - 2017-03-17 03:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 03:25:55 --> Controller Class Initialized
INFO - 2017-03-17 03:25:55 --> Helper loaded: url_helper
DEBUG - 2017-03-17 03:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 03:25:56 --> Config Class Initialized
INFO - 2017-03-17 03:25:56 --> Hooks Class Initialized
DEBUG - 2017-03-17 03:25:56 --> UTF-8 Support Enabled
INFO - 2017-03-17 03:25:56 --> Utf8 Class Initialized
INFO - 2017-03-17 03:25:56 --> URI Class Initialized
INFO - 2017-03-17 03:25:56 --> Router Class Initialized
INFO - 2017-03-17 03:25:56 --> Output Class Initialized
INFO - 2017-03-17 03:25:56 --> Security Class Initialized
DEBUG - 2017-03-17 03:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 03:25:56 --> Input Class Initialized
INFO - 2017-03-17 03:25:56 --> Language Class Initialized
INFO - 2017-03-17 03:25:56 --> Loader Class Initialized
INFO - 2017-03-17 03:25:56 --> Database Driver Class Initialized
INFO - 2017-03-17 03:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 03:25:56 --> Controller Class Initialized
INFO - 2017-03-17 03:25:56 --> Helper loaded: date_helper
DEBUG - 2017-03-17 03:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 03:25:56 --> Helper loaded: url_helper
INFO - 2017-03-17 03:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 03:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 03:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 03:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 03:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 03:25:56 --> Final output sent to browser
DEBUG - 2017-03-17 03:25:56 --> Total execution time: 0.1323
INFO - 2017-03-17 04:01:57 --> Config Class Initialized
INFO - 2017-03-17 04:01:57 --> Hooks Class Initialized
DEBUG - 2017-03-17 04:01:57 --> UTF-8 Support Enabled
INFO - 2017-03-17 04:01:57 --> Utf8 Class Initialized
INFO - 2017-03-17 04:01:57 --> URI Class Initialized
DEBUG - 2017-03-17 04:01:57 --> No URI present. Default controller set.
INFO - 2017-03-17 04:01:57 --> Router Class Initialized
INFO - 2017-03-17 04:01:57 --> Output Class Initialized
INFO - 2017-03-17 04:01:57 --> Security Class Initialized
DEBUG - 2017-03-17 04:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 04:01:57 --> Input Class Initialized
INFO - 2017-03-17 04:01:57 --> Language Class Initialized
INFO - 2017-03-17 04:01:57 --> Loader Class Initialized
INFO - 2017-03-17 04:01:58 --> Database Driver Class Initialized
INFO - 2017-03-17 04:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 04:01:58 --> Controller Class Initialized
INFO - 2017-03-17 04:01:58 --> Helper loaded: url_helper
DEBUG - 2017-03-17 04:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 04:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 04:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 04:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 04:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 04:01:58 --> Final output sent to browser
DEBUG - 2017-03-17 04:01:58 --> Total execution time: 1.2785
INFO - 2017-03-17 04:17:30 --> Config Class Initialized
INFO - 2017-03-17 04:17:30 --> Hooks Class Initialized
DEBUG - 2017-03-17 04:17:30 --> UTF-8 Support Enabled
INFO - 2017-03-17 04:17:30 --> Utf8 Class Initialized
INFO - 2017-03-17 04:17:30 --> URI Class Initialized
INFO - 2017-03-17 04:17:30 --> Router Class Initialized
INFO - 2017-03-17 04:17:30 --> Output Class Initialized
INFO - 2017-03-17 04:17:30 --> Security Class Initialized
DEBUG - 2017-03-17 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 04:17:30 --> Input Class Initialized
INFO - 2017-03-17 04:17:30 --> Language Class Initialized
INFO - 2017-03-17 04:17:30 --> Loader Class Initialized
INFO - 2017-03-17 04:17:30 --> Database Driver Class Initialized
INFO - 2017-03-17 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 04:17:30 --> Controller Class Initialized
INFO - 2017-03-17 04:17:31 --> Helper loaded: date_helper
DEBUG - 2017-03-17 04:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 04:17:31 --> Helper loaded: url_helper
INFO - 2017-03-17 04:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 04:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 04:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 04:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 04:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 04:17:31 --> Final output sent to browser
DEBUG - 2017-03-17 04:17:31 --> Total execution time: 1.1344
INFO - 2017-03-17 04:28:20 --> Config Class Initialized
INFO - 2017-03-17 04:28:20 --> Hooks Class Initialized
DEBUG - 2017-03-17 04:28:20 --> UTF-8 Support Enabled
INFO - 2017-03-17 04:28:20 --> Utf8 Class Initialized
INFO - 2017-03-17 04:28:20 --> URI Class Initialized
INFO - 2017-03-17 04:28:20 --> Router Class Initialized
INFO - 2017-03-17 04:28:20 --> Output Class Initialized
INFO - 2017-03-17 04:28:20 --> Security Class Initialized
DEBUG - 2017-03-17 04:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 04:28:20 --> Input Class Initialized
INFO - 2017-03-17 04:28:20 --> Language Class Initialized
INFO - 2017-03-17 04:28:20 --> Loader Class Initialized
INFO - 2017-03-17 04:28:21 --> Database Driver Class Initialized
INFO - 2017-03-17 04:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 04:28:21 --> Controller Class Initialized
INFO - 2017-03-17 04:28:21 --> Helper loaded: date_helper
DEBUG - 2017-03-17 04:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 04:28:21 --> Helper loaded: url_helper
INFO - 2017-03-17 04:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 04:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 04:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 04:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 04:28:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 04:28:21 --> Final output sent to browser
DEBUG - 2017-03-17 04:28:21 --> Total execution time: 1.0772
INFO - 2017-03-17 04:31:09 --> Config Class Initialized
INFO - 2017-03-17 04:31:09 --> Hooks Class Initialized
DEBUG - 2017-03-17 04:31:10 --> UTF-8 Support Enabled
INFO - 2017-03-17 04:31:10 --> Utf8 Class Initialized
INFO - 2017-03-17 04:31:10 --> URI Class Initialized
INFO - 2017-03-17 04:31:10 --> Router Class Initialized
INFO - 2017-03-17 04:31:10 --> Output Class Initialized
INFO - 2017-03-17 04:31:10 --> Security Class Initialized
DEBUG - 2017-03-17 04:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 04:31:10 --> Input Class Initialized
INFO - 2017-03-17 04:31:10 --> Language Class Initialized
INFO - 2017-03-17 04:31:10 --> Loader Class Initialized
INFO - 2017-03-17 04:31:10 --> Database Driver Class Initialized
INFO - 2017-03-17 04:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 04:31:10 --> Controller Class Initialized
INFO - 2017-03-17 04:31:10 --> Helper loaded: date_helper
DEBUG - 2017-03-17 04:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 04:31:10 --> Helper loaded: url_helper
INFO - 2017-03-17 04:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 04:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 04:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 04:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 04:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 04:31:10 --> Final output sent to browser
DEBUG - 2017-03-17 04:31:10 --> Total execution time: 1.1120
INFO - 2017-03-17 04:36:06 --> Config Class Initialized
INFO - 2017-03-17 04:36:06 --> Hooks Class Initialized
DEBUG - 2017-03-17 04:36:06 --> UTF-8 Support Enabled
INFO - 2017-03-17 04:36:06 --> Utf8 Class Initialized
INFO - 2017-03-17 04:36:06 --> URI Class Initialized
INFO - 2017-03-17 04:36:06 --> Router Class Initialized
INFO - 2017-03-17 04:36:06 --> Output Class Initialized
INFO - 2017-03-17 04:36:06 --> Security Class Initialized
DEBUG - 2017-03-17 04:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 04:36:06 --> Input Class Initialized
INFO - 2017-03-17 04:36:06 --> Language Class Initialized
INFO - 2017-03-17 04:36:06 --> Loader Class Initialized
INFO - 2017-03-17 04:36:06 --> Database Driver Class Initialized
INFO - 2017-03-17 04:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 04:36:06 --> Controller Class Initialized
INFO - 2017-03-17 04:36:07 --> Helper loaded: date_helper
DEBUG - 2017-03-17 04:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 04:36:07 --> Helper loaded: url_helper
INFO - 2017-03-17 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 04:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 04:36:07 --> Final output sent to browser
DEBUG - 2017-03-17 04:36:07 --> Total execution time: 1.0543
INFO - 2017-03-17 04:36:10 --> Config Class Initialized
INFO - 2017-03-17 04:36:10 --> Hooks Class Initialized
DEBUG - 2017-03-17 04:36:10 --> UTF-8 Support Enabled
INFO - 2017-03-17 04:36:10 --> Utf8 Class Initialized
INFO - 2017-03-17 04:36:10 --> URI Class Initialized
INFO - 2017-03-17 04:36:10 --> Router Class Initialized
INFO - 2017-03-17 04:36:10 --> Output Class Initialized
INFO - 2017-03-17 04:36:10 --> Security Class Initialized
DEBUG - 2017-03-17 04:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 04:36:10 --> Input Class Initialized
INFO - 2017-03-17 04:36:10 --> Language Class Initialized
INFO - 2017-03-17 04:36:10 --> Loader Class Initialized
INFO - 2017-03-17 04:36:10 --> Database Driver Class Initialized
INFO - 2017-03-17 04:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 04:36:10 --> Controller Class Initialized
INFO - 2017-03-17 04:36:10 --> Helper loaded: url_helper
DEBUG - 2017-03-17 04:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 04:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 04:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 04:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 04:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 04:36:10 --> Final output sent to browser
DEBUG - 2017-03-17 04:36:10 --> Total execution time: 0.5236
INFO - 2017-03-17 07:59:24 --> Config Class Initialized
INFO - 2017-03-17 07:59:24 --> Hooks Class Initialized
DEBUG - 2017-03-17 07:59:24 --> UTF-8 Support Enabled
INFO - 2017-03-17 07:59:24 --> Utf8 Class Initialized
INFO - 2017-03-17 07:59:24 --> URI Class Initialized
INFO - 2017-03-17 07:59:24 --> Router Class Initialized
INFO - 2017-03-17 07:59:24 --> Output Class Initialized
INFO - 2017-03-17 07:59:24 --> Security Class Initialized
DEBUG - 2017-03-17 07:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 07:59:24 --> Input Class Initialized
INFO - 2017-03-17 07:59:24 --> Language Class Initialized
INFO - 2017-03-17 07:59:24 --> Loader Class Initialized
INFO - 2017-03-17 07:59:24 --> Database Driver Class Initialized
INFO - 2017-03-17 07:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 07:59:25 --> Controller Class Initialized
INFO - 2017-03-17 07:59:25 --> Helper loaded: url_helper
DEBUG - 2017-03-17 07:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 07:59:25 --> Config Class Initialized
INFO - 2017-03-17 07:59:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 07:59:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 07:59:25 --> Utf8 Class Initialized
INFO - 2017-03-17 07:59:25 --> URI Class Initialized
INFO - 2017-03-17 07:59:25 --> Router Class Initialized
INFO - 2017-03-17 07:59:25 --> Output Class Initialized
INFO - 2017-03-17 07:59:25 --> Security Class Initialized
DEBUG - 2017-03-17 07:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 07:59:25 --> Input Class Initialized
INFO - 2017-03-17 07:59:25 --> Language Class Initialized
INFO - 2017-03-17 07:59:25 --> Loader Class Initialized
INFO - 2017-03-17 07:59:25 --> Database Driver Class Initialized
INFO - 2017-03-17 07:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 07:59:25 --> Controller Class Initialized
INFO - 2017-03-17 07:59:25 --> Helper loaded: url_helper
DEBUG - 2017-03-17 07:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 07:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 07:59:25 --> Final output sent to browser
DEBUG - 2017-03-17 07:59:25 --> Total execution time: 0.6409
INFO - 2017-03-17 07:59:25 --> Final output sent to browser
DEBUG - 2017-03-17 07:59:25 --> Total execution time: 1.4509
INFO - 2017-03-17 07:59:53 --> Config Class Initialized
INFO - 2017-03-17 07:59:53 --> Hooks Class Initialized
DEBUG - 2017-03-17 07:59:53 --> UTF-8 Support Enabled
INFO - 2017-03-17 07:59:53 --> Utf8 Class Initialized
INFO - 2017-03-17 07:59:53 --> URI Class Initialized
DEBUG - 2017-03-17 07:59:53 --> No URI present. Default controller set.
INFO - 2017-03-17 07:59:53 --> Router Class Initialized
INFO - 2017-03-17 07:59:53 --> Output Class Initialized
INFO - 2017-03-17 07:59:53 --> Security Class Initialized
DEBUG - 2017-03-17 07:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 07:59:53 --> Input Class Initialized
INFO - 2017-03-17 07:59:53 --> Language Class Initialized
INFO - 2017-03-17 07:59:53 --> Loader Class Initialized
INFO - 2017-03-17 07:59:53 --> Database Driver Class Initialized
INFO - 2017-03-17 07:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 07:59:53 --> Controller Class Initialized
INFO - 2017-03-17 07:59:53 --> Helper loaded: url_helper
DEBUG - 2017-03-17 07:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 07:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 07:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 07:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 07:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 07:59:53 --> Final output sent to browser
DEBUG - 2017-03-17 07:59:53 --> Total execution time: 0.0134
INFO - 2017-03-17 07:59:54 --> Config Class Initialized
INFO - 2017-03-17 07:59:54 --> Hooks Class Initialized
DEBUG - 2017-03-17 07:59:54 --> UTF-8 Support Enabled
INFO - 2017-03-17 07:59:54 --> Utf8 Class Initialized
INFO - 2017-03-17 07:59:54 --> URI Class Initialized
DEBUG - 2017-03-17 07:59:54 --> No URI present. Default controller set.
INFO - 2017-03-17 07:59:54 --> Router Class Initialized
INFO - 2017-03-17 07:59:54 --> Output Class Initialized
INFO - 2017-03-17 07:59:54 --> Security Class Initialized
DEBUG - 2017-03-17 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 07:59:54 --> Input Class Initialized
INFO - 2017-03-17 07:59:54 --> Language Class Initialized
INFO - 2017-03-17 07:59:54 --> Loader Class Initialized
INFO - 2017-03-17 07:59:54 --> Database Driver Class Initialized
INFO - 2017-03-17 07:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 07:59:54 --> Controller Class Initialized
INFO - 2017-03-17 07:59:54 --> Helper loaded: url_helper
DEBUG - 2017-03-17 07:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 07:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 07:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 07:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 07:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 07:59:54 --> Final output sent to browser
DEBUG - 2017-03-17 07:59:54 --> Total execution time: 0.0131
INFO - 2017-03-17 10:39:32 --> Config Class Initialized
INFO - 2017-03-17 10:39:32 --> Hooks Class Initialized
DEBUG - 2017-03-17 10:39:32 --> UTF-8 Support Enabled
INFO - 2017-03-17 10:39:32 --> Utf8 Class Initialized
INFO - 2017-03-17 10:39:32 --> URI Class Initialized
INFO - 2017-03-17 10:39:32 --> Router Class Initialized
INFO - 2017-03-17 10:39:32 --> Output Class Initialized
INFO - 2017-03-17 10:39:32 --> Security Class Initialized
DEBUG - 2017-03-17 10:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 10:39:32 --> Input Class Initialized
INFO - 2017-03-17 10:39:32 --> Language Class Initialized
INFO - 2017-03-17 10:39:33 --> Loader Class Initialized
INFO - 2017-03-17 10:39:33 --> Database Driver Class Initialized
INFO - 2017-03-17 10:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 10:39:33 --> Controller Class Initialized
INFO - 2017-03-17 10:39:33 --> Helper loaded: url_helper
DEBUG - 2017-03-17 10:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 10:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 10:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 10:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 10:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 10:39:34 --> Final output sent to browser
DEBUG - 2017-03-17 10:39:34 --> Total execution time: 1.6677
INFO - 2017-03-17 10:39:48 --> Config Class Initialized
INFO - 2017-03-17 10:39:48 --> Hooks Class Initialized
DEBUG - 2017-03-17 10:39:48 --> UTF-8 Support Enabled
INFO - 2017-03-17 10:39:48 --> Utf8 Class Initialized
INFO - 2017-03-17 10:39:48 --> URI Class Initialized
DEBUG - 2017-03-17 10:39:48 --> No URI present. Default controller set.
INFO - 2017-03-17 10:39:48 --> Router Class Initialized
INFO - 2017-03-17 10:39:48 --> Output Class Initialized
INFO - 2017-03-17 10:39:48 --> Security Class Initialized
DEBUG - 2017-03-17 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 10:39:49 --> Input Class Initialized
INFO - 2017-03-17 10:39:49 --> Language Class Initialized
INFO - 2017-03-17 10:39:49 --> Loader Class Initialized
INFO - 2017-03-17 10:39:49 --> Database Driver Class Initialized
INFO - 2017-03-17 10:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 10:39:50 --> Controller Class Initialized
INFO - 2017-03-17 10:39:50 --> Helper loaded: url_helper
DEBUG - 2017-03-17 10:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 10:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 10:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 10:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 10:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 10:39:50 --> Final output sent to browser
DEBUG - 2017-03-17 10:39:50 --> Total execution time: 1.6576
INFO - 2017-03-17 12:32:34 --> Config Class Initialized
INFO - 2017-03-17 12:32:34 --> Hooks Class Initialized
DEBUG - 2017-03-17 12:32:34 --> UTF-8 Support Enabled
INFO - 2017-03-17 12:32:34 --> Utf8 Class Initialized
INFO - 2017-03-17 12:32:34 --> URI Class Initialized
INFO - 2017-03-17 12:32:34 --> Router Class Initialized
INFO - 2017-03-17 12:32:34 --> Output Class Initialized
INFO - 2017-03-17 12:32:34 --> Security Class Initialized
DEBUG - 2017-03-17 12:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 12:32:34 --> Input Class Initialized
INFO - 2017-03-17 12:32:34 --> Language Class Initialized
INFO - 2017-03-17 12:32:34 --> Loader Class Initialized
INFO - 2017-03-17 12:32:35 --> Database Driver Class Initialized
INFO - 2017-03-17 12:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 12:32:35 --> Controller Class Initialized
INFO - 2017-03-17 12:32:35 --> Helper loaded: url_helper
DEBUG - 2017-03-17 12:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 12:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 12:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 12:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 12:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 12:32:35 --> Final output sent to browser
DEBUG - 2017-03-17 12:32:35 --> Total execution time: 1.2564
INFO - 2017-03-17 12:33:02 --> Config Class Initialized
INFO - 2017-03-17 12:33:02 --> Hooks Class Initialized
DEBUG - 2017-03-17 12:33:02 --> UTF-8 Support Enabled
INFO - 2017-03-17 12:33:02 --> Utf8 Class Initialized
INFO - 2017-03-17 12:33:02 --> URI Class Initialized
DEBUG - 2017-03-17 12:33:03 --> No URI present. Default controller set.
INFO - 2017-03-17 12:33:03 --> Router Class Initialized
INFO - 2017-03-17 12:33:03 --> Output Class Initialized
INFO - 2017-03-17 12:33:03 --> Security Class Initialized
DEBUG - 2017-03-17 12:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 12:33:03 --> Input Class Initialized
INFO - 2017-03-17 12:33:03 --> Language Class Initialized
INFO - 2017-03-17 12:33:03 --> Loader Class Initialized
INFO - 2017-03-17 12:33:03 --> Database Driver Class Initialized
INFO - 2017-03-17 12:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 12:33:03 --> Controller Class Initialized
INFO - 2017-03-17 12:33:03 --> Helper loaded: url_helper
DEBUG - 2017-03-17 12:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 12:33:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 12:33:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 12:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 12:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 12:33:04 --> Final output sent to browser
DEBUG - 2017-03-17 12:33:04 --> Total execution time: 1.2325
INFO - 2017-03-17 13:29:19 --> Config Class Initialized
INFO - 2017-03-17 13:29:19 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:29:19 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:29:19 --> Utf8 Class Initialized
INFO - 2017-03-17 13:29:19 --> URI Class Initialized
INFO - 2017-03-17 13:29:19 --> Router Class Initialized
INFO - 2017-03-17 13:29:19 --> Output Class Initialized
INFO - 2017-03-17 13:29:19 --> Security Class Initialized
DEBUG - 2017-03-17 13:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:29:19 --> Input Class Initialized
INFO - 2017-03-17 13:29:19 --> Language Class Initialized
INFO - 2017-03-17 13:29:19 --> Loader Class Initialized
INFO - 2017-03-17 13:29:19 --> Database Driver Class Initialized
INFO - 2017-03-17 13:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:29:20 --> Controller Class Initialized
INFO - 2017-03-17 13:29:20 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:29:20 --> Final output sent to browser
DEBUG - 2017-03-17 13:29:20 --> Total execution time: 1.4126
INFO - 2017-03-17 13:30:08 --> Config Class Initialized
INFO - 2017-03-17 13:30:08 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:30:08 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:30:08 --> Utf8 Class Initialized
INFO - 2017-03-17 13:30:08 --> URI Class Initialized
DEBUG - 2017-03-17 13:30:08 --> No URI present. Default controller set.
INFO - 2017-03-17 13:30:08 --> Router Class Initialized
INFO - 2017-03-17 13:30:08 --> Output Class Initialized
INFO - 2017-03-17 13:30:08 --> Security Class Initialized
DEBUG - 2017-03-17 13:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:30:08 --> Input Class Initialized
INFO - 2017-03-17 13:30:08 --> Language Class Initialized
INFO - 2017-03-17 13:30:09 --> Loader Class Initialized
INFO - 2017-03-17 13:30:09 --> Database Driver Class Initialized
INFO - 2017-03-17 13:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:30:09 --> Controller Class Initialized
INFO - 2017-03-17 13:30:09 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:30:09 --> Final output sent to browser
DEBUG - 2017-03-17 13:30:09 --> Total execution time: 1.3921
INFO - 2017-03-17 13:37:56 --> Config Class Initialized
INFO - 2017-03-17 13:37:56 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:37:56 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:37:57 --> Utf8 Class Initialized
INFO - 2017-03-17 13:37:57 --> URI Class Initialized
DEBUG - 2017-03-17 13:37:57 --> No URI present. Default controller set.
INFO - 2017-03-17 13:37:57 --> Router Class Initialized
INFO - 2017-03-17 13:37:57 --> Output Class Initialized
INFO - 2017-03-17 13:37:57 --> Security Class Initialized
DEBUG - 2017-03-17 13:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:37:57 --> Input Class Initialized
INFO - 2017-03-17 13:37:57 --> Language Class Initialized
INFO - 2017-03-17 13:37:57 --> Loader Class Initialized
INFO - 2017-03-17 13:37:57 --> Database Driver Class Initialized
INFO - 2017-03-17 13:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:37:57 --> Controller Class Initialized
INFO - 2017-03-17 13:37:57 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:37:58 --> Final output sent to browser
DEBUG - 2017-03-17 13:37:58 --> Total execution time: 1.3791
INFO - 2017-03-17 13:38:10 --> Config Class Initialized
INFO - 2017-03-17 13:38:10 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:38:10 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:38:10 --> Utf8 Class Initialized
INFO - 2017-03-17 13:38:10 --> URI Class Initialized
INFO - 2017-03-17 13:38:10 --> Router Class Initialized
INFO - 2017-03-17 13:38:10 --> Output Class Initialized
INFO - 2017-03-17 13:38:11 --> Security Class Initialized
DEBUG - 2017-03-17 13:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:38:11 --> Input Class Initialized
INFO - 2017-03-17 13:38:11 --> Language Class Initialized
INFO - 2017-03-17 13:38:11 --> Loader Class Initialized
INFO - 2017-03-17 13:38:11 --> Database Driver Class Initialized
INFO - 2017-03-17 13:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:38:11 --> Controller Class Initialized
INFO - 2017-03-17 13:38:11 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:38:11 --> Final output sent to browser
DEBUG - 2017-03-17 13:38:11 --> Total execution time: 1.2253
INFO - 2017-03-17 13:38:23 --> Config Class Initialized
INFO - 2017-03-17 13:38:23 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:38:23 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:38:23 --> Utf8 Class Initialized
INFO - 2017-03-17 13:38:23 --> URI Class Initialized
INFO - 2017-03-17 13:38:23 --> Router Class Initialized
INFO - 2017-03-17 13:38:23 --> Output Class Initialized
INFO - 2017-03-17 13:38:23 --> Security Class Initialized
DEBUG - 2017-03-17 13:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:38:23 --> Input Class Initialized
INFO - 2017-03-17 13:38:23 --> Language Class Initialized
INFO - 2017-03-17 13:38:23 --> Loader Class Initialized
INFO - 2017-03-17 13:38:23 --> Database Driver Class Initialized
INFO - 2017-03-17 13:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:38:23 --> Controller Class Initialized
INFO - 2017-03-17 13:38:23 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-17 13:38:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-17 13:38:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-17 13:38:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-17 13:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:38:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:38:23 --> Final output sent to browser
DEBUG - 2017-03-17 13:38:23 --> Total execution time: 0.2926
INFO - 2017-03-17 13:38:26 --> Config Class Initialized
INFO - 2017-03-17 13:38:26 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:38:26 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:38:26 --> Utf8 Class Initialized
INFO - 2017-03-17 13:38:26 --> URI Class Initialized
INFO - 2017-03-17 13:38:26 --> Router Class Initialized
INFO - 2017-03-17 13:38:26 --> Output Class Initialized
INFO - 2017-03-17 13:38:26 --> Security Class Initialized
DEBUG - 2017-03-17 13:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:38:26 --> Input Class Initialized
INFO - 2017-03-17 13:38:26 --> Language Class Initialized
INFO - 2017-03-17 13:38:26 --> Loader Class Initialized
INFO - 2017-03-17 13:38:26 --> Database Driver Class Initialized
INFO - 2017-03-17 13:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:38:26 --> Controller Class Initialized
INFO - 2017-03-17 13:38:26 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:38:26 --> Final output sent to browser
DEBUG - 2017-03-17 13:38:26 --> Total execution time: 0.0136
INFO - 2017-03-17 13:40:28 --> Config Class Initialized
INFO - 2017-03-17 13:40:28 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:28 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:28 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:28 --> URI Class Initialized
INFO - 2017-03-17 13:40:28 --> Router Class Initialized
INFO - 2017-03-17 13:40:28 --> Output Class Initialized
INFO - 2017-03-17 13:40:28 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:28 --> Input Class Initialized
INFO - 2017-03-17 13:40:28 --> Language Class Initialized
INFO - 2017-03-17 13:40:28 --> Loader Class Initialized
INFO - 2017-03-17 13:40:28 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:28 --> Controller Class Initialized
INFO - 2017-03-17 13:40:28 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:40:28 --> Final output sent to browser
DEBUG - 2017-03-17 13:40:28 --> Total execution time: 0.0484
INFO - 2017-03-17 13:40:30 --> Config Class Initialized
INFO - 2017-03-17 13:40:30 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:30 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:30 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:30 --> URI Class Initialized
INFO - 2017-03-17 13:40:30 --> Router Class Initialized
INFO - 2017-03-17 13:40:30 --> Output Class Initialized
INFO - 2017-03-17 13:40:30 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:30 --> Input Class Initialized
INFO - 2017-03-17 13:40:30 --> Language Class Initialized
INFO - 2017-03-17 13:40:30 --> Loader Class Initialized
INFO - 2017-03-17 13:40:30 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:30 --> Controller Class Initialized
INFO - 2017-03-17 13:40:30 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:40:30 --> Final output sent to browser
DEBUG - 2017-03-17 13:40:30 --> Total execution time: 0.0130
INFO - 2017-03-17 13:40:42 --> Config Class Initialized
INFO - 2017-03-17 13:40:42 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:42 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:42 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:42 --> URI Class Initialized
INFO - 2017-03-17 13:40:42 --> Router Class Initialized
INFO - 2017-03-17 13:40:42 --> Output Class Initialized
INFO - 2017-03-17 13:40:42 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:42 --> Input Class Initialized
INFO - 2017-03-17 13:40:42 --> Language Class Initialized
INFO - 2017-03-17 13:40:42 --> Loader Class Initialized
INFO - 2017-03-17 13:40:42 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:42 --> Controller Class Initialized
INFO - 2017-03-17 13:40:42 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-17 13:40:44 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-17 13:40:44 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Claudia Serrano')
INFO - 2017-03-17 13:40:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-17 13:40:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-17 13:40:45 --> Config Class Initialized
INFO - 2017-03-17 13:40:45 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:45 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:45 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:45 --> URI Class Initialized
INFO - 2017-03-17 13:40:45 --> Router Class Initialized
INFO - 2017-03-17 13:40:45 --> Output Class Initialized
INFO - 2017-03-17 13:40:45 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:45 --> Input Class Initialized
INFO - 2017-03-17 13:40:45 --> Language Class Initialized
INFO - 2017-03-17 13:40:45 --> Loader Class Initialized
INFO - 2017-03-17 13:40:45 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:45 --> Controller Class Initialized
INFO - 2017-03-17 13:40:45 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:40:45 --> Final output sent to browser
DEBUG - 2017-03-17 13:40:45 --> Total execution time: 0.0134
INFO - 2017-03-17 13:40:49 --> Config Class Initialized
INFO - 2017-03-17 13:40:49 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:49 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:49 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:49 --> URI Class Initialized
INFO - 2017-03-17 13:40:49 --> Router Class Initialized
INFO - 2017-03-17 13:40:49 --> Output Class Initialized
INFO - 2017-03-17 13:40:49 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:49 --> Input Class Initialized
INFO - 2017-03-17 13:40:49 --> Language Class Initialized
INFO - 2017-03-17 13:40:49 --> Loader Class Initialized
INFO - 2017-03-17 13:40:49 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:49 --> Controller Class Initialized
INFO - 2017-03-17 13:40:49 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-17 13:40:49 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-17 13:40:49 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Claudia Serrano')
INFO - 2017-03-17 13:40:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-17 13:40:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-17 13:40:50 --> Config Class Initialized
INFO - 2017-03-17 13:40:50 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:50 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:50 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:50 --> URI Class Initialized
INFO - 2017-03-17 13:40:50 --> Router Class Initialized
INFO - 2017-03-17 13:40:50 --> Output Class Initialized
INFO - 2017-03-17 13:40:50 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:50 --> Input Class Initialized
INFO - 2017-03-17 13:40:50 --> Language Class Initialized
INFO - 2017-03-17 13:40:50 --> Loader Class Initialized
INFO - 2017-03-17 13:40:50 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:50 --> Controller Class Initialized
INFO - 2017-03-17 13:40:50 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:40:50 --> Final output sent to browser
DEBUG - 2017-03-17 13:40:50 --> Total execution time: 0.0137
INFO - 2017-03-17 13:40:51 --> Config Class Initialized
INFO - 2017-03-17 13:40:51 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:51 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:51 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:51 --> URI Class Initialized
INFO - 2017-03-17 13:40:51 --> Router Class Initialized
INFO - 2017-03-17 13:40:51 --> Output Class Initialized
INFO - 2017-03-17 13:40:51 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:51 --> Input Class Initialized
INFO - 2017-03-17 13:40:51 --> Language Class Initialized
INFO - 2017-03-17 13:40:51 --> Loader Class Initialized
INFO - 2017-03-17 13:40:51 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:51 --> Controller Class Initialized
INFO - 2017-03-17 13:40:51 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-17 13:40:51 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-17 13:40:51 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Claudia Serrano')
INFO - 2017-03-17 13:40:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-17 13:40:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-17 13:40:51 --> Config Class Initialized
INFO - 2017-03-17 13:40:51 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:51 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:51 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:51 --> URI Class Initialized
INFO - 2017-03-17 13:40:51 --> Router Class Initialized
INFO - 2017-03-17 13:40:51 --> Output Class Initialized
INFO - 2017-03-17 13:40:51 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:51 --> Input Class Initialized
INFO - 2017-03-17 13:40:51 --> Language Class Initialized
INFO - 2017-03-17 13:40:51 --> Loader Class Initialized
INFO - 2017-03-17 13:40:51 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:51 --> Controller Class Initialized
INFO - 2017-03-17 13:40:51 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:40:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:40:51 --> Final output sent to browser
DEBUG - 2017-03-17 13:40:51 --> Total execution time: 0.0131
INFO - 2017-03-17 13:40:54 --> Config Class Initialized
INFO - 2017-03-17 13:40:54 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:40:54 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:40:54 --> Utf8 Class Initialized
INFO - 2017-03-17 13:40:54 --> URI Class Initialized
DEBUG - 2017-03-17 13:40:54 --> No URI present. Default controller set.
INFO - 2017-03-17 13:40:54 --> Router Class Initialized
INFO - 2017-03-17 13:40:54 --> Output Class Initialized
INFO - 2017-03-17 13:40:54 --> Security Class Initialized
DEBUG - 2017-03-17 13:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:40:54 --> Input Class Initialized
INFO - 2017-03-17 13:40:54 --> Language Class Initialized
INFO - 2017-03-17 13:40:54 --> Loader Class Initialized
INFO - 2017-03-17 13:40:54 --> Database Driver Class Initialized
INFO - 2017-03-17 13:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:40:54 --> Controller Class Initialized
INFO - 2017-03-17 13:40:54 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:40:54 --> Final output sent to browser
DEBUG - 2017-03-17 13:40:54 --> Total execution time: 0.0132
INFO - 2017-03-17 13:42:44 --> Config Class Initialized
INFO - 2017-03-17 13:42:44 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:42:44 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:42:44 --> Utf8 Class Initialized
INFO - 2017-03-17 13:42:44 --> URI Class Initialized
DEBUG - 2017-03-17 13:42:44 --> No URI present. Default controller set.
INFO - 2017-03-17 13:42:44 --> Router Class Initialized
INFO - 2017-03-17 13:42:44 --> Output Class Initialized
INFO - 2017-03-17 13:42:44 --> Security Class Initialized
DEBUG - 2017-03-17 13:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:42:45 --> Input Class Initialized
INFO - 2017-03-17 13:42:45 --> Language Class Initialized
INFO - 2017-03-17 13:42:45 --> Loader Class Initialized
INFO - 2017-03-17 13:42:45 --> Database Driver Class Initialized
INFO - 2017-03-17 13:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:42:45 --> Controller Class Initialized
INFO - 2017-03-17 13:42:45 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:42:46 --> Final output sent to browser
DEBUG - 2017-03-17 13:42:46 --> Total execution time: 1.3974
INFO - 2017-03-17 13:42:50 --> Config Class Initialized
INFO - 2017-03-17 13:42:50 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:42:50 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:42:50 --> Utf8 Class Initialized
INFO - 2017-03-17 13:42:50 --> URI Class Initialized
INFO - 2017-03-17 13:42:50 --> Router Class Initialized
INFO - 2017-03-17 13:42:50 --> Output Class Initialized
INFO - 2017-03-17 13:42:50 --> Security Class Initialized
DEBUG - 2017-03-17 13:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:42:50 --> Input Class Initialized
INFO - 2017-03-17 13:42:50 --> Language Class Initialized
INFO - 2017-03-17 13:42:50 --> Loader Class Initialized
INFO - 2017-03-17 13:42:50 --> Database Driver Class Initialized
INFO - 2017-03-17 13:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:42:50 --> Controller Class Initialized
INFO - 2017-03-17 13:42:50 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:42:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:42:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:42:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:42:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:42:50 --> Final output sent to browser
DEBUG - 2017-03-17 13:42:50 --> Total execution time: 0.0137
INFO - 2017-03-17 13:43:09 --> Config Class Initialized
INFO - 2017-03-17 13:43:09 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:43:09 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:43:09 --> Utf8 Class Initialized
INFO - 2017-03-17 13:43:09 --> URI Class Initialized
INFO - 2017-03-17 13:43:09 --> Router Class Initialized
INFO - 2017-03-17 13:43:09 --> Output Class Initialized
INFO - 2017-03-17 13:43:09 --> Security Class Initialized
DEBUG - 2017-03-17 13:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:43:09 --> Input Class Initialized
INFO - 2017-03-17 13:43:09 --> Language Class Initialized
INFO - 2017-03-17 13:43:09 --> Loader Class Initialized
INFO - 2017-03-17 13:43:09 --> Database Driver Class Initialized
INFO - 2017-03-17 13:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:43:09 --> Controller Class Initialized
INFO - 2017-03-17 13:43:09 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:43:11 --> Config Class Initialized
INFO - 2017-03-17 13:43:11 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:43:11 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:43:11 --> Utf8 Class Initialized
INFO - 2017-03-17 13:43:11 --> URI Class Initialized
INFO - 2017-03-17 13:43:11 --> Router Class Initialized
INFO - 2017-03-17 13:43:11 --> Output Class Initialized
INFO - 2017-03-17 13:43:11 --> Security Class Initialized
DEBUG - 2017-03-17 13:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:43:11 --> Input Class Initialized
INFO - 2017-03-17 13:43:11 --> Language Class Initialized
INFO - 2017-03-17 13:43:11 --> Loader Class Initialized
INFO - 2017-03-17 13:43:11 --> Database Driver Class Initialized
INFO - 2017-03-17 13:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:43:11 --> Controller Class Initialized
INFO - 2017-03-17 13:43:11 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:43:11 --> Helper loaded: url_helper
INFO - 2017-03-17 13:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 13:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 13:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:43:11 --> Final output sent to browser
DEBUG - 2017-03-17 13:43:11 --> Total execution time: 0.2234
INFO - 2017-03-17 13:43:13 --> Config Class Initialized
INFO - 2017-03-17 13:43:13 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:43:13 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:43:13 --> Utf8 Class Initialized
INFO - 2017-03-17 13:43:13 --> URI Class Initialized
INFO - 2017-03-17 13:43:13 --> Router Class Initialized
INFO - 2017-03-17 13:43:13 --> Output Class Initialized
INFO - 2017-03-17 13:43:13 --> Security Class Initialized
DEBUG - 2017-03-17 13:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:43:13 --> Input Class Initialized
INFO - 2017-03-17 13:43:13 --> Language Class Initialized
INFO - 2017-03-17 13:43:13 --> Loader Class Initialized
INFO - 2017-03-17 13:43:13 --> Database Driver Class Initialized
INFO - 2017-03-17 13:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:43:13 --> Controller Class Initialized
INFO - 2017-03-17 13:43:13 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:43:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:43:13 --> Final output sent to browser
DEBUG - 2017-03-17 13:43:13 --> Total execution time: 0.0245
INFO - 2017-03-17 13:43:16 --> Config Class Initialized
INFO - 2017-03-17 13:43:16 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:43:16 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:43:16 --> Utf8 Class Initialized
INFO - 2017-03-17 13:43:16 --> URI Class Initialized
INFO - 2017-03-17 13:43:16 --> Router Class Initialized
INFO - 2017-03-17 13:43:16 --> Output Class Initialized
INFO - 2017-03-17 13:43:16 --> Security Class Initialized
DEBUG - 2017-03-17 13:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:43:16 --> Input Class Initialized
INFO - 2017-03-17 13:43:16 --> Language Class Initialized
INFO - 2017-03-17 13:43:16 --> Loader Class Initialized
INFO - 2017-03-17 13:43:16 --> Database Driver Class Initialized
INFO - 2017-03-17 13:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:43:16 --> Controller Class Initialized
INFO - 2017-03-17 13:43:16 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:43:16 --> Helper loaded: url_helper
INFO - 2017-03-17 13:43:16 --> Helper loaded: download_helper
INFO - 2017-03-17 13:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 13:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 13:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:43:16 --> Final output sent to browser
DEBUG - 2017-03-17 13:43:16 --> Total execution time: 0.1149
INFO - 2017-03-17 13:43:17 --> Config Class Initialized
INFO - 2017-03-17 13:43:17 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:43:17 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:43:17 --> Utf8 Class Initialized
INFO - 2017-03-17 13:43:17 --> URI Class Initialized
INFO - 2017-03-17 13:43:17 --> Router Class Initialized
INFO - 2017-03-17 13:43:17 --> Output Class Initialized
INFO - 2017-03-17 13:43:17 --> Security Class Initialized
DEBUG - 2017-03-17 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:43:17 --> Input Class Initialized
INFO - 2017-03-17 13:43:17 --> Language Class Initialized
INFO - 2017-03-17 13:43:17 --> Loader Class Initialized
INFO - 2017-03-17 13:43:17 --> Database Driver Class Initialized
INFO - 2017-03-17 13:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:43:17 --> Controller Class Initialized
INFO - 2017-03-17 13:43:17 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:43:17 --> Final output sent to browser
DEBUG - 2017-03-17 13:43:17 --> Total execution time: 0.0139
INFO - 2017-03-17 13:44:11 --> Config Class Initialized
INFO - 2017-03-17 13:44:11 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:44:12 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:44:12 --> Utf8 Class Initialized
INFO - 2017-03-17 13:44:12 --> URI Class Initialized
INFO - 2017-03-17 13:44:12 --> Router Class Initialized
INFO - 2017-03-17 13:44:12 --> Output Class Initialized
INFO - 2017-03-17 13:44:12 --> Security Class Initialized
DEBUG - 2017-03-17 13:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:44:12 --> Input Class Initialized
INFO - 2017-03-17 13:44:12 --> Language Class Initialized
INFO - 2017-03-17 13:44:12 --> Loader Class Initialized
INFO - 2017-03-17 13:44:12 --> Database Driver Class Initialized
INFO - 2017-03-17 13:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:44:12 --> Controller Class Initialized
INFO - 2017-03-17 13:44:12 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:44:12 --> Helper loaded: url_helper
INFO - 2017-03-17 13:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-17 13:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-17 13:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-17 13:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:44:12 --> Final output sent to browser
DEBUG - 2017-03-17 13:44:12 --> Total execution time: 0.4600
INFO - 2017-03-17 13:44:13 --> Config Class Initialized
INFO - 2017-03-17 13:44:13 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:44:13 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:44:13 --> Utf8 Class Initialized
INFO - 2017-03-17 13:44:13 --> URI Class Initialized
INFO - 2017-03-17 13:44:13 --> Router Class Initialized
INFO - 2017-03-17 13:44:13 --> Output Class Initialized
INFO - 2017-03-17 13:44:13 --> Security Class Initialized
DEBUG - 2017-03-17 13:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:44:13 --> Input Class Initialized
INFO - 2017-03-17 13:44:13 --> Language Class Initialized
INFO - 2017-03-17 13:44:13 --> Loader Class Initialized
INFO - 2017-03-17 13:44:13 --> Database Driver Class Initialized
INFO - 2017-03-17 13:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:44:13 --> Controller Class Initialized
INFO - 2017-03-17 13:44:13 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:44:13 --> Final output sent to browser
DEBUG - 2017-03-17 13:44:13 --> Total execution time: 0.0288
INFO - 2017-03-17 13:44:32 --> Config Class Initialized
INFO - 2017-03-17 13:44:32 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:44:32 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:44:32 --> Utf8 Class Initialized
INFO - 2017-03-17 13:44:32 --> URI Class Initialized
INFO - 2017-03-17 13:44:32 --> Router Class Initialized
INFO - 2017-03-17 13:44:32 --> Output Class Initialized
INFO - 2017-03-17 13:44:32 --> Security Class Initialized
DEBUG - 2017-03-17 13:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:44:32 --> Input Class Initialized
INFO - 2017-03-17 13:44:32 --> Language Class Initialized
INFO - 2017-03-17 13:44:32 --> Loader Class Initialized
INFO - 2017-03-17 13:44:32 --> Database Driver Class Initialized
INFO - 2017-03-17 13:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:44:32 --> Controller Class Initialized
INFO - 2017-03-17 13:44:32 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:44:32 --> Helper loaded: url_helper
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:44:32 --> Final output sent to browser
DEBUG - 2017-03-17 13:44:32 --> Total execution time: 0.0149
INFO - 2017-03-17 13:44:32 --> Config Class Initialized
INFO - 2017-03-17 13:44:32 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:44:32 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:44:32 --> Utf8 Class Initialized
INFO - 2017-03-17 13:44:32 --> URI Class Initialized
INFO - 2017-03-17 13:44:32 --> Router Class Initialized
INFO - 2017-03-17 13:44:32 --> Output Class Initialized
INFO - 2017-03-17 13:44:32 --> Security Class Initialized
DEBUG - 2017-03-17 13:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:44:32 --> Input Class Initialized
INFO - 2017-03-17 13:44:32 --> Language Class Initialized
INFO - 2017-03-17 13:44:32 --> Loader Class Initialized
INFO - 2017-03-17 13:44:32 --> Database Driver Class Initialized
INFO - 2017-03-17 13:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:44:32 --> Controller Class Initialized
INFO - 2017-03-17 13:44:32 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:44:32 --> Final output sent to browser
DEBUG - 2017-03-17 13:44:32 --> Total execution time: 0.0139
INFO - 2017-03-17 13:45:39 --> Config Class Initialized
INFO - 2017-03-17 13:45:39 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:45:39 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:45:40 --> Utf8 Class Initialized
INFO - 2017-03-17 13:45:40 --> URI Class Initialized
INFO - 2017-03-17 13:45:40 --> Router Class Initialized
INFO - 2017-03-17 13:45:40 --> Output Class Initialized
INFO - 2017-03-17 13:45:40 --> Security Class Initialized
DEBUG - 2017-03-17 13:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:45:40 --> Input Class Initialized
INFO - 2017-03-17 13:45:40 --> Language Class Initialized
INFO - 2017-03-17 13:45:40 --> Loader Class Initialized
INFO - 2017-03-17 13:45:40 --> Database Driver Class Initialized
INFO - 2017-03-17 13:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:45:40 --> Controller Class Initialized
INFO - 2017-03-17 13:45:40 --> Upload Class Initialized
INFO - 2017-03-17 13:45:40 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:45:40 --> Helper loaded: url_helper
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:45:41 --> Final output sent to browser
DEBUG - 2017-03-17 13:45:41 --> Total execution time: 1.2321
INFO - 2017-03-17 13:45:41 --> Config Class Initialized
INFO - 2017-03-17 13:45:41 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:45:41 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:45:41 --> Utf8 Class Initialized
INFO - 2017-03-17 13:45:41 --> URI Class Initialized
INFO - 2017-03-17 13:45:41 --> Router Class Initialized
INFO - 2017-03-17 13:45:41 --> Output Class Initialized
INFO - 2017-03-17 13:45:41 --> Security Class Initialized
DEBUG - 2017-03-17 13:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:45:41 --> Input Class Initialized
INFO - 2017-03-17 13:45:41 --> Language Class Initialized
INFO - 2017-03-17 13:45:41 --> Loader Class Initialized
INFO - 2017-03-17 13:45:41 --> Database Driver Class Initialized
INFO - 2017-03-17 13:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:45:41 --> Controller Class Initialized
INFO - 2017-03-17 13:45:41 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:45:42 --> Final output sent to browser
DEBUG - 2017-03-17 13:45:42 --> Total execution time: 0.2608
INFO - 2017-03-17 13:46:06 --> Config Class Initialized
INFO - 2017-03-17 13:46:06 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:46:06 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:46:06 --> Utf8 Class Initialized
INFO - 2017-03-17 13:46:06 --> URI Class Initialized
INFO - 2017-03-17 13:46:07 --> Router Class Initialized
INFO - 2017-03-17 13:46:07 --> Output Class Initialized
INFO - 2017-03-17 13:46:07 --> Security Class Initialized
DEBUG - 2017-03-17 13:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:46:07 --> Input Class Initialized
INFO - 2017-03-17 13:46:07 --> Language Class Initialized
INFO - 2017-03-17 13:46:07 --> Loader Class Initialized
INFO - 2017-03-17 13:46:07 --> Database Driver Class Initialized
INFO - 2017-03-17 13:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:46:07 --> Controller Class Initialized
INFO - 2017-03-17 13:46:07 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:46:07 --> Helper loaded: url_helper
INFO - 2017-03-17 13:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-17 13:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-17 13:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-17 13:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:46:07 --> Final output sent to browser
DEBUG - 2017-03-17 13:46:07 --> Total execution time: 1.1297
INFO - 2017-03-17 13:46:08 --> Config Class Initialized
INFO - 2017-03-17 13:46:08 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:46:08 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:46:08 --> Utf8 Class Initialized
INFO - 2017-03-17 13:46:08 --> URI Class Initialized
INFO - 2017-03-17 13:46:09 --> Router Class Initialized
INFO - 2017-03-17 13:46:09 --> Output Class Initialized
INFO - 2017-03-17 13:46:09 --> Security Class Initialized
DEBUG - 2017-03-17 13:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:46:09 --> Input Class Initialized
INFO - 2017-03-17 13:46:09 --> Language Class Initialized
INFO - 2017-03-17 13:46:09 --> Loader Class Initialized
INFO - 2017-03-17 13:46:09 --> Database Driver Class Initialized
INFO - 2017-03-17 13:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:46:09 --> Controller Class Initialized
INFO - 2017-03-17 13:46:09 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:46:09 --> Final output sent to browser
DEBUG - 2017-03-17 13:46:09 --> Total execution time: 0.7745
INFO - 2017-03-17 13:46:25 --> Config Class Initialized
INFO - 2017-03-17 13:46:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:46:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:46:25 --> Utf8 Class Initialized
INFO - 2017-03-17 13:46:25 --> URI Class Initialized
INFO - 2017-03-17 13:46:25 --> Router Class Initialized
INFO - 2017-03-17 13:46:25 --> Output Class Initialized
INFO - 2017-03-17 13:46:25 --> Security Class Initialized
DEBUG - 2017-03-17 13:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:46:25 --> Input Class Initialized
INFO - 2017-03-17 13:46:25 --> Language Class Initialized
INFO - 2017-03-17 13:46:25 --> Loader Class Initialized
INFO - 2017-03-17 13:46:26 --> Database Driver Class Initialized
INFO - 2017-03-17 13:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:46:26 --> Controller Class Initialized
INFO - 2017-03-17 13:46:26 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:46:26 --> Helper loaded: url_helper
INFO - 2017-03-17 13:46:26 --> Helper loaded: download_helper
INFO - 2017-03-17 13:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 13:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 13:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:46:26 --> Final output sent to browser
DEBUG - 2017-03-17 13:46:26 --> Total execution time: 1.1449
INFO - 2017-03-17 13:46:27 --> Config Class Initialized
INFO - 2017-03-17 13:46:27 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:46:27 --> Utf8 Class Initialized
INFO - 2017-03-17 13:46:27 --> URI Class Initialized
INFO - 2017-03-17 13:46:27 --> Router Class Initialized
INFO - 2017-03-17 13:46:27 --> Output Class Initialized
INFO - 2017-03-17 13:46:27 --> Security Class Initialized
DEBUG - 2017-03-17 13:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:46:27 --> Input Class Initialized
INFO - 2017-03-17 13:46:27 --> Language Class Initialized
INFO - 2017-03-17 13:46:27 --> Loader Class Initialized
INFO - 2017-03-17 13:46:27 --> Database Driver Class Initialized
INFO - 2017-03-17 13:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:46:27 --> Controller Class Initialized
INFO - 2017-03-17 13:46:27 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:46:27 --> Final output sent to browser
DEBUG - 2017-03-17 13:46:27 --> Total execution time: 0.3907
INFO - 2017-03-17 13:50:24 --> Config Class Initialized
INFO - 2017-03-17 13:50:24 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:50:24 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:50:24 --> Utf8 Class Initialized
INFO - 2017-03-17 13:50:24 --> URI Class Initialized
INFO - 2017-03-17 13:50:24 --> Router Class Initialized
INFO - 2017-03-17 13:50:24 --> Output Class Initialized
INFO - 2017-03-17 13:50:24 --> Security Class Initialized
DEBUG - 2017-03-17 13:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:50:24 --> Input Class Initialized
INFO - 2017-03-17 13:50:24 --> Language Class Initialized
INFO - 2017-03-17 13:50:24 --> Loader Class Initialized
INFO - 2017-03-17 13:50:25 --> Database Driver Class Initialized
INFO - 2017-03-17 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:50:25 --> Controller Class Initialized
INFO - 2017-03-17 13:50:25 --> Config Class Initialized
INFO - 2017-03-17 13:50:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:50:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:50:25 --> Utf8 Class Initialized
INFO - 2017-03-17 13:50:25 --> URI Class Initialized
INFO - 2017-03-17 13:50:25 --> Router Class Initialized
INFO - 2017-03-17 13:50:25 --> Output Class Initialized
INFO - 2017-03-17 13:50:25 --> Security Class Initialized
DEBUG - 2017-03-17 13:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:50:25 --> Input Class Initialized
INFO - 2017-03-17 13:50:25 --> Language Class Initialized
INFO - 2017-03-17 13:50:25 --> Loader Class Initialized
INFO - 2017-03-17 13:50:25 --> Database Driver Class Initialized
INFO - 2017-03-17 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:50:25 --> Controller Class Initialized
INFO - 2017-03-17 13:50:25 --> Helper loaded: date_helper
INFO - 2017-03-17 13:50:25 --> Helper loaded: date_helper
DEBUG - 2017-03-17 13:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-17 13:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:50:25 --> Helper loaded: url_helper
INFO - 2017-03-17 13:50:25 --> Helper loaded: download_helper
INFO - 2017-03-17 13:50:25 --> Helper loaded: url_helper
INFO - 2017-03-17 13:50:25 --> Helper loaded: download_helper
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:50:25 --> Final output sent to browser
DEBUG - 2017-03-17 13:50:25 --> Total execution time: 1.3344
INFO - 2017-03-17 13:50:25 --> Config Class Initialized
INFO - 2017-03-17 13:50:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:50:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:50:25 --> Utf8 Class Initialized
INFO - 2017-03-17 13:50:25 --> URI Class Initialized
DEBUG - 2017-03-17 13:50:25 --> No URI present. Default controller set.
INFO - 2017-03-17 13:50:25 --> Router Class Initialized
INFO - 2017-03-17 13:50:25 --> Output Class Initialized
INFO - 2017-03-17 13:50:25 --> Security Class Initialized
DEBUG - 2017-03-17 13:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:50:25 --> Input Class Initialized
INFO - 2017-03-17 13:50:25 --> Language Class Initialized
INFO - 2017-03-17 13:50:25 --> Loader Class Initialized
INFO - 2017-03-17 13:50:25 --> Database Driver Class Initialized
INFO - 2017-03-17 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:50:25 --> Controller Class Initialized
INFO - 2017-03-17 13:50:25 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:50:25 --> Final output sent to browser
DEBUG - 2017-03-17 13:50:25 --> Total execution time: 0.2496
INFO - 2017-03-17 13:50:26 --> Config Class Initialized
INFO - 2017-03-17 13:50:26 --> Hooks Class Initialized
DEBUG - 2017-03-17 13:50:26 --> UTF-8 Support Enabled
INFO - 2017-03-17 13:50:26 --> Utf8 Class Initialized
INFO - 2017-03-17 13:50:26 --> URI Class Initialized
INFO - 2017-03-17 13:50:26 --> Router Class Initialized
INFO - 2017-03-17 13:50:26 --> Output Class Initialized
INFO - 2017-03-17 13:50:26 --> Security Class Initialized
DEBUG - 2017-03-17 13:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 13:50:26 --> Input Class Initialized
INFO - 2017-03-17 13:50:26 --> Language Class Initialized
INFO - 2017-03-17 13:50:26 --> Loader Class Initialized
INFO - 2017-03-17 13:50:26 --> Database Driver Class Initialized
INFO - 2017-03-17 13:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 13:50:26 --> Controller Class Initialized
INFO - 2017-03-17 13:50:26 --> Helper loaded: url_helper
DEBUG - 2017-03-17 13:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 13:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 13:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 13:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 13:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 13:50:26 --> Final output sent to browser
DEBUG - 2017-03-17 13:50:26 --> Total execution time: 0.0150
INFO - 2017-03-17 15:34:14 --> Config Class Initialized
INFO - 2017-03-17 15:34:14 --> Hooks Class Initialized
DEBUG - 2017-03-17 15:34:14 --> UTF-8 Support Enabled
INFO - 2017-03-17 15:34:14 --> Utf8 Class Initialized
INFO - 2017-03-17 15:34:14 --> URI Class Initialized
INFO - 2017-03-17 15:34:14 --> Router Class Initialized
INFO - 2017-03-17 15:34:14 --> Output Class Initialized
INFO - 2017-03-17 15:34:14 --> Security Class Initialized
DEBUG - 2017-03-17 15:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 15:34:14 --> Input Class Initialized
INFO - 2017-03-17 15:34:14 --> Language Class Initialized
INFO - 2017-03-17 15:34:14 --> Loader Class Initialized
INFO - 2017-03-17 15:34:14 --> Database Driver Class Initialized
INFO - 2017-03-17 15:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 15:34:15 --> Controller Class Initialized
INFO - 2017-03-17 15:34:15 --> Helper loaded: url_helper
DEBUG - 2017-03-17 15:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 15:34:15 --> Final output sent to browser
DEBUG - 2017-03-17 15:34:15 --> Total execution time: 1.3761
INFO - 2017-03-17 15:35:23 --> Config Class Initialized
INFO - 2017-03-17 15:35:23 --> Hooks Class Initialized
DEBUG - 2017-03-17 15:35:23 --> UTF-8 Support Enabled
INFO - 2017-03-17 15:35:23 --> Utf8 Class Initialized
INFO - 2017-03-17 15:35:23 --> URI Class Initialized
DEBUG - 2017-03-17 15:35:23 --> No URI present. Default controller set.
INFO - 2017-03-17 15:35:23 --> Router Class Initialized
INFO - 2017-03-17 15:35:23 --> Output Class Initialized
INFO - 2017-03-17 15:35:23 --> Security Class Initialized
DEBUG - 2017-03-17 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 15:35:23 --> Input Class Initialized
INFO - 2017-03-17 15:35:23 --> Language Class Initialized
INFO - 2017-03-17 15:35:23 --> Loader Class Initialized
INFO - 2017-03-17 15:35:23 --> Database Driver Class Initialized
INFO - 2017-03-17 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 15:35:24 --> Controller Class Initialized
INFO - 2017-03-17 15:35:24 --> Helper loaded: url_helper
DEBUG - 2017-03-17 15:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 15:35:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 15:35:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 15:35:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 15:35:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 15:35:24 --> Final output sent to browser
DEBUG - 2017-03-17 15:35:24 --> Total execution time: 1.3642
INFO - 2017-03-17 16:06:01 --> Config Class Initialized
INFO - 2017-03-17 16:06:01 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:06:01 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:06:01 --> Utf8 Class Initialized
INFO - 2017-03-17 16:06:01 --> URI Class Initialized
DEBUG - 2017-03-17 16:06:01 --> No URI present. Default controller set.
INFO - 2017-03-17 16:06:01 --> Router Class Initialized
INFO - 2017-03-17 16:06:01 --> Output Class Initialized
INFO - 2017-03-17 16:06:01 --> Security Class Initialized
DEBUG - 2017-03-17 16:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:06:01 --> Input Class Initialized
INFO - 2017-03-17 16:06:01 --> Language Class Initialized
INFO - 2017-03-17 16:06:01 --> Loader Class Initialized
INFO - 2017-03-17 16:06:02 --> Database Driver Class Initialized
INFO - 2017-03-17 16:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:06:02 --> Controller Class Initialized
INFO - 2017-03-17 16:06:02 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:06:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:06:02 --> Final output sent to browser
DEBUG - 2017-03-17 16:06:02 --> Total execution time: 1.4009
INFO - 2017-03-17 16:06:09 --> Config Class Initialized
INFO - 2017-03-17 16:06:09 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:06:09 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:06:09 --> Utf8 Class Initialized
INFO - 2017-03-17 16:06:09 --> URI Class Initialized
INFO - 2017-03-17 16:06:09 --> Router Class Initialized
INFO - 2017-03-17 16:06:09 --> Output Class Initialized
INFO - 2017-03-17 16:06:09 --> Security Class Initialized
DEBUG - 2017-03-17 16:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:06:09 --> Input Class Initialized
INFO - 2017-03-17 16:06:09 --> Language Class Initialized
INFO - 2017-03-17 16:06:09 --> Loader Class Initialized
INFO - 2017-03-17 16:06:09 --> Database Driver Class Initialized
INFO - 2017-03-17 16:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:06:09 --> Controller Class Initialized
INFO - 2017-03-17 16:06:09 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:06:09 --> Final output sent to browser
DEBUG - 2017-03-17 16:06:09 --> Total execution time: 0.0139
INFO - 2017-03-17 16:07:02 --> Config Class Initialized
INFO - 2017-03-17 16:07:02 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:07:02 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:07:02 --> Utf8 Class Initialized
INFO - 2017-03-17 16:07:02 --> URI Class Initialized
INFO - 2017-03-17 16:07:02 --> Router Class Initialized
INFO - 2017-03-17 16:07:02 --> Output Class Initialized
INFO - 2017-03-17 16:07:02 --> Security Class Initialized
DEBUG - 2017-03-17 16:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:07:02 --> Input Class Initialized
INFO - 2017-03-17 16:07:02 --> Language Class Initialized
INFO - 2017-03-17 16:07:02 --> Loader Class Initialized
INFO - 2017-03-17 16:07:02 --> Database Driver Class Initialized
INFO - 2017-03-17 16:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:07:02 --> Controller Class Initialized
INFO - 2017-03-17 16:07:02 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-17 16:07:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-17 16:07:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-17 16:07:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-17 16:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:07:02 --> Final output sent to browser
DEBUG - 2017-03-17 16:07:02 --> Total execution time: 0.0982
INFO - 2017-03-17 16:07:03 --> Config Class Initialized
INFO - 2017-03-17 16:07:03 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:07:03 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:07:03 --> Utf8 Class Initialized
INFO - 2017-03-17 16:07:03 --> URI Class Initialized
INFO - 2017-03-17 16:07:03 --> Router Class Initialized
INFO - 2017-03-17 16:07:03 --> Output Class Initialized
INFO - 2017-03-17 16:07:03 --> Security Class Initialized
DEBUG - 2017-03-17 16:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:07:03 --> Input Class Initialized
INFO - 2017-03-17 16:07:03 --> Language Class Initialized
INFO - 2017-03-17 16:07:03 --> Loader Class Initialized
INFO - 2017-03-17 16:07:03 --> Database Driver Class Initialized
INFO - 2017-03-17 16:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:07:03 --> Controller Class Initialized
INFO - 2017-03-17 16:07:03 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:07:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:07:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:07:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:07:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:07:03 --> Final output sent to browser
DEBUG - 2017-03-17 16:07:03 --> Total execution time: 0.0134
INFO - 2017-03-17 16:07:29 --> Config Class Initialized
INFO - 2017-03-17 16:07:29 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:07:29 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:07:29 --> Utf8 Class Initialized
INFO - 2017-03-17 16:07:29 --> URI Class Initialized
INFO - 2017-03-17 16:07:29 --> Router Class Initialized
INFO - 2017-03-17 16:07:29 --> Output Class Initialized
INFO - 2017-03-17 16:07:29 --> Security Class Initialized
DEBUG - 2017-03-17 16:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:07:29 --> Input Class Initialized
INFO - 2017-03-17 16:07:29 --> Language Class Initialized
INFO - 2017-03-17 16:07:29 --> Loader Class Initialized
INFO - 2017-03-17 16:07:29 --> Database Driver Class Initialized
INFO - 2017-03-17 16:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:07:30 --> Controller Class Initialized
INFO - 2017-03-17 16:07:30 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:07:31 --> Config Class Initialized
INFO - 2017-03-17 16:07:31 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:07:31 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:07:31 --> Utf8 Class Initialized
INFO - 2017-03-17 16:07:31 --> URI Class Initialized
INFO - 2017-03-17 16:07:31 --> Router Class Initialized
INFO - 2017-03-17 16:07:31 --> Output Class Initialized
INFO - 2017-03-17 16:07:31 --> Security Class Initialized
DEBUG - 2017-03-17 16:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:07:31 --> Input Class Initialized
INFO - 2017-03-17 16:07:31 --> Language Class Initialized
INFO - 2017-03-17 16:07:31 --> Loader Class Initialized
INFO - 2017-03-17 16:07:31 --> Database Driver Class Initialized
INFO - 2017-03-17 16:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:07:31 --> Controller Class Initialized
INFO - 2017-03-17 16:07:31 --> Helper loaded: date_helper
DEBUG - 2017-03-17 16:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:07:31 --> Helper loaded: url_helper
INFO - 2017-03-17 16:07:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:07:32 --> Final output sent to browser
DEBUG - 2017-03-17 16:07:32 --> Total execution time: 0.2420
INFO - 2017-03-17 16:07:33 --> Config Class Initialized
INFO - 2017-03-17 16:07:33 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:07:33 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:07:33 --> Utf8 Class Initialized
INFO - 2017-03-17 16:07:33 --> URI Class Initialized
INFO - 2017-03-17 16:07:33 --> Router Class Initialized
INFO - 2017-03-17 16:07:33 --> Output Class Initialized
INFO - 2017-03-17 16:07:33 --> Security Class Initialized
DEBUG - 2017-03-17 16:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:07:33 --> Input Class Initialized
INFO - 2017-03-17 16:07:33 --> Language Class Initialized
INFO - 2017-03-17 16:07:33 --> Loader Class Initialized
INFO - 2017-03-17 16:07:33 --> Database Driver Class Initialized
INFO - 2017-03-17 16:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:07:34 --> Controller Class Initialized
INFO - 2017-03-17 16:07:34 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:07:34 --> Final output sent to browser
DEBUG - 2017-03-17 16:07:34 --> Total execution time: 0.8083
INFO - 2017-03-17 16:40:01 --> Config Class Initialized
INFO - 2017-03-17 16:40:01 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:40:01 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:40:01 --> Utf8 Class Initialized
INFO - 2017-03-17 16:40:01 --> URI Class Initialized
INFO - 2017-03-17 16:40:01 --> Router Class Initialized
INFO - 2017-03-17 16:40:01 --> Output Class Initialized
INFO - 2017-03-17 16:40:01 --> Security Class Initialized
DEBUG - 2017-03-17 16:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:40:01 --> Input Class Initialized
INFO - 2017-03-17 16:40:01 --> Language Class Initialized
INFO - 2017-03-17 16:40:02 --> Loader Class Initialized
INFO - 2017-03-17 16:40:02 --> Database Driver Class Initialized
INFO - 2017-03-17 16:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:40:02 --> Controller Class Initialized
INFO - 2017-03-17 16:40:02 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:40:03 --> Final output sent to browser
DEBUG - 2017-03-17 16:40:03 --> Total execution time: 1.6668
INFO - 2017-03-17 16:40:05 --> Config Class Initialized
INFO - 2017-03-17 16:40:05 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:40:05 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:40:05 --> Utf8 Class Initialized
INFO - 2017-03-17 16:40:05 --> URI Class Initialized
DEBUG - 2017-03-17 16:40:05 --> No URI present. Default controller set.
INFO - 2017-03-17 16:40:05 --> Router Class Initialized
INFO - 2017-03-17 16:40:05 --> Output Class Initialized
INFO - 2017-03-17 16:40:05 --> Security Class Initialized
DEBUG - 2017-03-17 16:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:40:05 --> Input Class Initialized
INFO - 2017-03-17 16:40:05 --> Language Class Initialized
INFO - 2017-03-17 16:40:05 --> Loader Class Initialized
INFO - 2017-03-17 16:40:05 --> Database Driver Class Initialized
INFO - 2017-03-17 16:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:40:05 --> Controller Class Initialized
INFO - 2017-03-17 16:40:05 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:40:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:40:05 --> Final output sent to browser
DEBUG - 2017-03-17 16:40:05 --> Total execution time: 0.0142
INFO - 2017-03-17 16:45:28 --> Config Class Initialized
INFO - 2017-03-17 16:45:28 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:45:28 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:45:28 --> Utf8 Class Initialized
INFO - 2017-03-17 16:45:28 --> URI Class Initialized
DEBUG - 2017-03-17 16:45:28 --> No URI present. Default controller set.
INFO - 2017-03-17 16:45:28 --> Router Class Initialized
INFO - 2017-03-17 16:45:28 --> Output Class Initialized
INFO - 2017-03-17 16:45:28 --> Security Class Initialized
DEBUG - 2017-03-17 16:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:45:28 --> Input Class Initialized
INFO - 2017-03-17 16:45:28 --> Language Class Initialized
INFO - 2017-03-17 16:45:28 --> Loader Class Initialized
INFO - 2017-03-17 16:45:29 --> Database Driver Class Initialized
INFO - 2017-03-17 16:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:45:29 --> Controller Class Initialized
INFO - 2017-03-17 16:45:29 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:45:30 --> Final output sent to browser
DEBUG - 2017-03-17 16:45:30 --> Total execution time: 1.6587
INFO - 2017-03-17 16:45:36 --> Config Class Initialized
INFO - 2017-03-17 16:45:36 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:45:36 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:45:36 --> Utf8 Class Initialized
INFO - 2017-03-17 16:45:36 --> URI Class Initialized
INFO - 2017-03-17 16:45:36 --> Router Class Initialized
INFO - 2017-03-17 16:45:37 --> Output Class Initialized
INFO - 2017-03-17 16:45:37 --> Security Class Initialized
DEBUG - 2017-03-17 16:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:45:37 --> Input Class Initialized
INFO - 2017-03-17 16:45:37 --> Language Class Initialized
INFO - 2017-03-17 16:45:37 --> Loader Class Initialized
INFO - 2017-03-17 16:45:37 --> Database Driver Class Initialized
INFO - 2017-03-17 16:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:45:37 --> Controller Class Initialized
INFO - 2017-03-17 16:45:37 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:45:37 --> Final output sent to browser
DEBUG - 2017-03-17 16:45:37 --> Total execution time: 1.2241
INFO - 2017-03-17 16:46:18 --> Config Class Initialized
INFO - 2017-03-17 16:46:18 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:46:18 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:46:18 --> Utf8 Class Initialized
INFO - 2017-03-17 16:46:18 --> URI Class Initialized
INFO - 2017-03-17 16:46:18 --> Router Class Initialized
INFO - 2017-03-17 16:46:18 --> Output Class Initialized
INFO - 2017-03-17 16:46:18 --> Security Class Initialized
DEBUG - 2017-03-17 16:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:46:18 --> Input Class Initialized
INFO - 2017-03-17 16:46:18 --> Language Class Initialized
INFO - 2017-03-17 16:46:18 --> Loader Class Initialized
INFO - 2017-03-17 16:46:19 --> Database Driver Class Initialized
INFO - 2017-03-17 16:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:46:19 --> Controller Class Initialized
INFO - 2017-03-17 16:46:19 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:46:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:46:19 --> Final output sent to browser
DEBUG - 2017-03-17 16:46:19 --> Total execution time: 1.2486
INFO - 2017-03-17 16:46:21 --> Config Class Initialized
INFO - 2017-03-17 16:46:21 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:46:21 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:46:21 --> Utf8 Class Initialized
INFO - 2017-03-17 16:46:21 --> URI Class Initialized
INFO - 2017-03-17 16:46:21 --> Router Class Initialized
INFO - 2017-03-17 16:46:21 --> Output Class Initialized
INFO - 2017-03-17 16:46:21 --> Security Class Initialized
DEBUG - 2017-03-17 16:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:46:21 --> Input Class Initialized
INFO - 2017-03-17 16:46:21 --> Language Class Initialized
INFO - 2017-03-17 16:46:21 --> Loader Class Initialized
INFO - 2017-03-17 16:46:21 --> Database Driver Class Initialized
INFO - 2017-03-17 16:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:46:21 --> Controller Class Initialized
INFO - 2017-03-17 16:46:21 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:46:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:46:21 --> Final output sent to browser
DEBUG - 2017-03-17 16:46:21 --> Total execution time: 0.0145
INFO - 2017-03-17 16:46:53 --> Config Class Initialized
INFO - 2017-03-17 16:46:53 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:46:53 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:46:54 --> Utf8 Class Initialized
INFO - 2017-03-17 16:46:54 --> URI Class Initialized
INFO - 2017-03-17 16:46:54 --> Router Class Initialized
INFO - 2017-03-17 16:46:54 --> Output Class Initialized
INFO - 2017-03-17 16:46:54 --> Security Class Initialized
DEBUG - 2017-03-17 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:46:54 --> Input Class Initialized
INFO - 2017-03-17 16:46:54 --> Language Class Initialized
INFO - 2017-03-17 16:46:54 --> Loader Class Initialized
INFO - 2017-03-17 16:46:54 --> Database Driver Class Initialized
INFO - 2017-03-17 16:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:46:54 --> Controller Class Initialized
INFO - 2017-03-17 16:46:54 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:46:55 --> Final output sent to browser
DEBUG - 2017-03-17 16:46:55 --> Total execution time: 1.2329
INFO - 2017-03-17 16:47:00 --> Config Class Initialized
INFO - 2017-03-17 16:47:00 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:47:00 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:47:00 --> Utf8 Class Initialized
INFO - 2017-03-17 16:47:00 --> URI Class Initialized
INFO - 2017-03-17 16:47:00 --> Router Class Initialized
INFO - 2017-03-17 16:47:00 --> Output Class Initialized
INFO - 2017-03-17 16:47:00 --> Security Class Initialized
DEBUG - 2017-03-17 16:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:47:00 --> Input Class Initialized
INFO - 2017-03-17 16:47:00 --> Language Class Initialized
INFO - 2017-03-17 16:47:00 --> Loader Class Initialized
INFO - 2017-03-17 16:47:00 --> Database Driver Class Initialized
INFO - 2017-03-17 16:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:47:00 --> Controller Class Initialized
INFO - 2017-03-17 16:47:00 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:47:00 --> Final output sent to browser
DEBUG - 2017-03-17 16:47:00 --> Total execution time: 0.0137
INFO - 2017-03-17 16:48:55 --> Config Class Initialized
INFO - 2017-03-17 16:48:55 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:48:55 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:48:55 --> Utf8 Class Initialized
INFO - 2017-03-17 16:48:55 --> URI Class Initialized
INFO - 2017-03-17 16:48:55 --> Router Class Initialized
INFO - 2017-03-17 16:48:55 --> Output Class Initialized
INFO - 2017-03-17 16:48:55 --> Security Class Initialized
DEBUG - 2017-03-17 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:48:55 --> Input Class Initialized
INFO - 2017-03-17 16:48:55 --> Language Class Initialized
INFO - 2017-03-17 16:48:55 --> Loader Class Initialized
INFO - 2017-03-17 16:48:56 --> Database Driver Class Initialized
INFO - 2017-03-17 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:48:56 --> Controller Class Initialized
INFO - 2017-03-17 16:48:56 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:48:58 --> Config Class Initialized
INFO - 2017-03-17 16:48:58 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:48:58 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:48:58 --> Utf8 Class Initialized
INFO - 2017-03-17 16:48:58 --> URI Class Initialized
INFO - 2017-03-17 16:48:58 --> Router Class Initialized
INFO - 2017-03-17 16:48:58 --> Output Class Initialized
INFO - 2017-03-17 16:48:58 --> Security Class Initialized
DEBUG - 2017-03-17 16:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:48:58 --> Input Class Initialized
INFO - 2017-03-17 16:48:58 --> Language Class Initialized
INFO - 2017-03-17 16:48:58 --> Loader Class Initialized
INFO - 2017-03-17 16:48:58 --> Database Driver Class Initialized
INFO - 2017-03-17 16:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:48:58 --> Controller Class Initialized
INFO - 2017-03-17 16:48:58 --> Helper loaded: date_helper
DEBUG - 2017-03-17 16:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:48:58 --> Helper loaded: url_helper
INFO - 2017-03-17 16:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 16:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 16:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 16:48:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:48:58 --> Final output sent to browser
DEBUG - 2017-03-17 16:48:58 --> Total execution time: 0.1418
INFO - 2017-03-17 16:49:00 --> Config Class Initialized
INFO - 2017-03-17 16:49:00 --> Hooks Class Initialized
DEBUG - 2017-03-17 16:49:00 --> UTF-8 Support Enabled
INFO - 2017-03-17 16:49:00 --> Utf8 Class Initialized
INFO - 2017-03-17 16:49:00 --> URI Class Initialized
INFO - 2017-03-17 16:49:00 --> Router Class Initialized
INFO - 2017-03-17 16:49:00 --> Output Class Initialized
INFO - 2017-03-17 16:49:00 --> Security Class Initialized
DEBUG - 2017-03-17 16:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 16:49:00 --> Input Class Initialized
INFO - 2017-03-17 16:49:00 --> Language Class Initialized
INFO - 2017-03-17 16:49:00 --> Loader Class Initialized
INFO - 2017-03-17 16:49:00 --> Database Driver Class Initialized
INFO - 2017-03-17 16:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 16:49:00 --> Controller Class Initialized
INFO - 2017-03-17 16:49:00 --> Helper loaded: url_helper
DEBUG - 2017-03-17 16:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 16:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 16:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 16:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 16:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 16:49:00 --> Final output sent to browser
DEBUG - 2017-03-17 16:49:00 --> Total execution time: 0.0336
INFO - 2017-03-17 17:27:07 --> Config Class Initialized
INFO - 2017-03-17 17:27:07 --> Hooks Class Initialized
DEBUG - 2017-03-17 17:27:07 --> UTF-8 Support Enabled
INFO - 2017-03-17 17:27:07 --> Utf8 Class Initialized
INFO - 2017-03-17 17:27:07 --> URI Class Initialized
INFO - 2017-03-17 17:27:07 --> Router Class Initialized
INFO - 2017-03-17 17:27:08 --> Output Class Initialized
INFO - 2017-03-17 17:27:08 --> Security Class Initialized
DEBUG - 2017-03-17 17:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 17:27:08 --> Input Class Initialized
INFO - 2017-03-17 17:27:08 --> Language Class Initialized
INFO - 2017-03-17 17:27:08 --> Loader Class Initialized
INFO - 2017-03-17 17:27:08 --> Database Driver Class Initialized
INFO - 2017-03-17 17:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 17:27:08 --> Controller Class Initialized
INFO - 2017-03-17 17:27:08 --> Helper loaded: url_helper
DEBUG - 2017-03-17 17:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 17:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 17:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 17:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 17:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 17:27:09 --> Final output sent to browser
DEBUG - 2017-03-17 17:27:09 --> Total execution time: 1.4280
INFO - 2017-03-17 17:33:15 --> Config Class Initialized
INFO - 2017-03-17 17:33:15 --> Hooks Class Initialized
DEBUG - 2017-03-17 17:33:15 --> UTF-8 Support Enabled
INFO - 2017-03-17 17:33:15 --> Utf8 Class Initialized
INFO - 2017-03-17 17:33:15 --> URI Class Initialized
DEBUG - 2017-03-17 17:33:15 --> No URI present. Default controller set.
INFO - 2017-03-17 17:33:15 --> Router Class Initialized
INFO - 2017-03-17 17:33:15 --> Output Class Initialized
INFO - 2017-03-17 17:33:15 --> Security Class Initialized
DEBUG - 2017-03-17 17:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 17:33:15 --> Input Class Initialized
INFO - 2017-03-17 17:33:15 --> Language Class Initialized
INFO - 2017-03-17 17:33:15 --> Loader Class Initialized
INFO - 2017-03-17 17:33:16 --> Database Driver Class Initialized
INFO - 2017-03-17 17:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 17:33:16 --> Controller Class Initialized
INFO - 2017-03-17 17:33:16 --> Helper loaded: url_helper
DEBUG - 2017-03-17 17:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 17:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 17:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 17:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 17:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 17:33:16 --> Final output sent to browser
DEBUG - 2017-03-17 17:33:16 --> Total execution time: 1.4209
INFO - 2017-03-17 19:54:14 --> Config Class Initialized
INFO - 2017-03-17 19:54:14 --> Hooks Class Initialized
DEBUG - 2017-03-17 19:54:14 --> UTF-8 Support Enabled
INFO - 2017-03-17 19:54:14 --> Utf8 Class Initialized
INFO - 2017-03-17 19:54:14 --> URI Class Initialized
INFO - 2017-03-17 19:54:14 --> Router Class Initialized
INFO - 2017-03-17 19:54:14 --> Output Class Initialized
INFO - 2017-03-17 19:54:14 --> Security Class Initialized
DEBUG - 2017-03-17 19:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 19:54:14 --> Input Class Initialized
INFO - 2017-03-17 19:54:14 --> Language Class Initialized
INFO - 2017-03-17 19:54:14 --> Loader Class Initialized
INFO - 2017-03-17 19:54:15 --> Database Driver Class Initialized
INFO - 2017-03-17 19:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 19:54:15 --> Controller Class Initialized
INFO - 2017-03-17 19:54:15 --> Helper loaded: url_helper
DEBUG - 2017-03-17 19:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 19:54:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 19:54:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 19:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 19:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 19:54:16 --> Final output sent to browser
DEBUG - 2017-03-17 19:54:16 --> Total execution time: 1.6483
INFO - 2017-03-17 19:54:16 --> Config Class Initialized
INFO - 2017-03-17 19:54:16 --> Hooks Class Initialized
DEBUG - 2017-03-17 19:54:16 --> UTF-8 Support Enabled
INFO - 2017-03-17 19:54:16 --> Utf8 Class Initialized
INFO - 2017-03-17 19:54:16 --> URI Class Initialized
DEBUG - 2017-03-17 19:54:16 --> No URI present. Default controller set.
INFO - 2017-03-17 19:54:16 --> Router Class Initialized
INFO - 2017-03-17 19:54:16 --> Output Class Initialized
INFO - 2017-03-17 19:54:16 --> Security Class Initialized
DEBUG - 2017-03-17 19:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 19:54:16 --> Input Class Initialized
INFO - 2017-03-17 19:54:16 --> Language Class Initialized
INFO - 2017-03-17 19:54:16 --> Loader Class Initialized
INFO - 2017-03-17 19:54:16 --> Database Driver Class Initialized
INFO - 2017-03-17 19:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 19:54:16 --> Controller Class Initialized
INFO - 2017-03-17 19:54:16 --> Helper loaded: url_helper
DEBUG - 2017-03-17 19:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 19:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 19:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 19:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 19:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 19:54:16 --> Final output sent to browser
DEBUG - 2017-03-17 19:54:16 --> Total execution time: 0.0301
INFO - 2017-03-17 20:18:39 --> Config Class Initialized
INFO - 2017-03-17 20:18:39 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:18:39 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:18:39 --> Utf8 Class Initialized
INFO - 2017-03-17 20:18:39 --> URI Class Initialized
DEBUG - 2017-03-17 20:18:40 --> No URI present. Default controller set.
INFO - 2017-03-17 20:18:40 --> Router Class Initialized
INFO - 2017-03-17 20:18:40 --> Output Class Initialized
INFO - 2017-03-17 20:18:40 --> Security Class Initialized
DEBUG - 2017-03-17 20:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:18:40 --> Input Class Initialized
INFO - 2017-03-17 20:18:40 --> Language Class Initialized
INFO - 2017-03-17 20:18:40 --> Loader Class Initialized
INFO - 2017-03-17 20:18:40 --> Database Driver Class Initialized
INFO - 2017-03-17 20:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:18:40 --> Controller Class Initialized
INFO - 2017-03-17 20:18:40 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:18:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:18:41 --> Final output sent to browser
DEBUG - 2017-03-17 20:18:41 --> Total execution time: 1.4267
INFO - 2017-03-17 20:18:46 --> Config Class Initialized
INFO - 2017-03-17 20:18:46 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:18:46 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:18:46 --> Utf8 Class Initialized
INFO - 2017-03-17 20:18:46 --> URI Class Initialized
INFO - 2017-03-17 20:18:46 --> Router Class Initialized
INFO - 2017-03-17 20:18:46 --> Output Class Initialized
INFO - 2017-03-17 20:18:46 --> Security Class Initialized
DEBUG - 2017-03-17 20:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:18:46 --> Input Class Initialized
INFO - 2017-03-17 20:18:46 --> Language Class Initialized
INFO - 2017-03-17 20:18:46 --> Loader Class Initialized
INFO - 2017-03-17 20:18:46 --> Database Driver Class Initialized
INFO - 2017-03-17 20:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:18:46 --> Controller Class Initialized
INFO - 2017-03-17 20:18:46 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:18:46 --> Final output sent to browser
DEBUG - 2017-03-17 20:18:46 --> Total execution time: 0.0137
INFO - 2017-03-17 20:19:11 --> Config Class Initialized
INFO - 2017-03-17 20:19:11 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:19:11 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:19:11 --> Utf8 Class Initialized
INFO - 2017-03-17 20:19:11 --> URI Class Initialized
DEBUG - 2017-03-17 20:19:11 --> No URI present. Default controller set.
INFO - 2017-03-17 20:19:11 --> Router Class Initialized
INFO - 2017-03-17 20:19:11 --> Output Class Initialized
INFO - 2017-03-17 20:19:11 --> Security Class Initialized
DEBUG - 2017-03-17 20:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:19:11 --> Input Class Initialized
INFO - 2017-03-17 20:19:11 --> Language Class Initialized
INFO - 2017-03-17 20:19:11 --> Loader Class Initialized
INFO - 2017-03-17 20:19:11 --> Database Driver Class Initialized
INFO - 2017-03-17 20:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:19:11 --> Controller Class Initialized
INFO - 2017-03-17 20:19:11 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:19:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:19:11 --> Final output sent to browser
DEBUG - 2017-03-17 20:19:11 --> Total execution time: 0.0138
INFO - 2017-03-17 20:19:12 --> Config Class Initialized
INFO - 2017-03-17 20:19:12 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:19:12 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:19:12 --> Utf8 Class Initialized
INFO - 2017-03-17 20:19:12 --> URI Class Initialized
INFO - 2017-03-17 20:19:12 --> Router Class Initialized
INFO - 2017-03-17 20:19:12 --> Output Class Initialized
INFO - 2017-03-17 20:19:12 --> Security Class Initialized
DEBUG - 2017-03-17 20:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:19:12 --> Input Class Initialized
INFO - 2017-03-17 20:19:12 --> Language Class Initialized
INFO - 2017-03-17 20:19:12 --> Loader Class Initialized
INFO - 2017-03-17 20:19:12 --> Database Driver Class Initialized
INFO - 2017-03-17 20:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:19:12 --> Controller Class Initialized
INFO - 2017-03-17 20:19:12 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:19:12 --> Final output sent to browser
DEBUG - 2017-03-17 20:19:12 --> Total execution time: 0.0144
INFO - 2017-03-17 20:19:23 --> Config Class Initialized
INFO - 2017-03-17 20:19:23 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:19:23 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:19:23 --> Utf8 Class Initialized
INFO - 2017-03-17 20:19:23 --> URI Class Initialized
DEBUG - 2017-03-17 20:19:23 --> No URI present. Default controller set.
INFO - 2017-03-17 20:19:23 --> Router Class Initialized
INFO - 2017-03-17 20:19:23 --> Output Class Initialized
INFO - 2017-03-17 20:19:23 --> Security Class Initialized
DEBUG - 2017-03-17 20:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:19:23 --> Input Class Initialized
INFO - 2017-03-17 20:19:23 --> Language Class Initialized
INFO - 2017-03-17 20:19:23 --> Loader Class Initialized
INFO - 2017-03-17 20:19:23 --> Database Driver Class Initialized
INFO - 2017-03-17 20:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:19:23 --> Controller Class Initialized
INFO - 2017-03-17 20:19:23 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:19:23 --> Final output sent to browser
DEBUG - 2017-03-17 20:19:23 --> Total execution time: 0.0129
INFO - 2017-03-17 20:19:25 --> Config Class Initialized
INFO - 2017-03-17 20:19:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:19:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:19:25 --> Utf8 Class Initialized
INFO - 2017-03-17 20:19:25 --> URI Class Initialized
INFO - 2017-03-17 20:19:25 --> Router Class Initialized
INFO - 2017-03-17 20:19:25 --> Output Class Initialized
INFO - 2017-03-17 20:19:25 --> Security Class Initialized
DEBUG - 2017-03-17 20:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:19:25 --> Input Class Initialized
INFO - 2017-03-17 20:19:25 --> Language Class Initialized
INFO - 2017-03-17 20:19:25 --> Loader Class Initialized
INFO - 2017-03-17 20:19:25 --> Database Driver Class Initialized
INFO - 2017-03-17 20:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:19:25 --> Controller Class Initialized
INFO - 2017-03-17 20:19:25 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:19:25 --> Final output sent to browser
DEBUG - 2017-03-17 20:19:25 --> Total execution time: 0.0133
INFO - 2017-03-17 20:20:27 --> Config Class Initialized
INFO - 2017-03-17 20:20:27 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:20:27 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:20:27 --> Utf8 Class Initialized
INFO - 2017-03-17 20:20:27 --> URI Class Initialized
INFO - 2017-03-17 20:20:27 --> Router Class Initialized
INFO - 2017-03-17 20:20:27 --> Output Class Initialized
INFO - 2017-03-17 20:20:27 --> Security Class Initialized
DEBUG - 2017-03-17 20:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:20:27 --> Input Class Initialized
INFO - 2017-03-17 20:20:27 --> Language Class Initialized
INFO - 2017-03-17 20:20:27 --> Loader Class Initialized
INFO - 2017-03-17 20:20:27 --> Database Driver Class Initialized
INFO - 2017-03-17 20:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:20:27 --> Controller Class Initialized
INFO - 2017-03-17 20:20:27 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:20:29 --> Config Class Initialized
INFO - 2017-03-17 20:20:29 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:20:29 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:20:29 --> Utf8 Class Initialized
INFO - 2017-03-17 20:20:29 --> URI Class Initialized
INFO - 2017-03-17 20:20:29 --> Router Class Initialized
INFO - 2017-03-17 20:20:29 --> Output Class Initialized
INFO - 2017-03-17 20:20:29 --> Security Class Initialized
DEBUG - 2017-03-17 20:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:20:29 --> Input Class Initialized
INFO - 2017-03-17 20:20:29 --> Language Class Initialized
INFO - 2017-03-17 20:20:29 --> Loader Class Initialized
INFO - 2017-03-17 20:20:29 --> Database Driver Class Initialized
INFO - 2017-03-17 20:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:20:29 --> Controller Class Initialized
INFO - 2017-03-17 20:20:29 --> Helper loaded: date_helper
DEBUG - 2017-03-17 20:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:20:30 --> Helper loaded: url_helper
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:20:30 --> Final output sent to browser
DEBUG - 2017-03-17 20:20:30 --> Total execution time: 0.2542
INFO - 2017-03-17 20:20:30 --> Config Class Initialized
INFO - 2017-03-17 20:20:30 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:20:30 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:20:30 --> Utf8 Class Initialized
INFO - 2017-03-17 20:20:30 --> URI Class Initialized
INFO - 2017-03-17 20:20:30 --> Router Class Initialized
INFO - 2017-03-17 20:20:30 --> Output Class Initialized
INFO - 2017-03-17 20:20:30 --> Security Class Initialized
DEBUG - 2017-03-17 20:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:20:30 --> Input Class Initialized
INFO - 2017-03-17 20:20:30 --> Language Class Initialized
INFO - 2017-03-17 20:20:30 --> Loader Class Initialized
INFO - 2017-03-17 20:20:30 --> Database Driver Class Initialized
INFO - 2017-03-17 20:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:20:30 --> Controller Class Initialized
INFO - 2017-03-17 20:20:30 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:20:30 --> Final output sent to browser
DEBUG - 2017-03-17 20:20:30 --> Total execution time: 0.0136
INFO - 2017-03-17 20:20:58 --> Config Class Initialized
INFO - 2017-03-17 20:20:58 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:20:58 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:20:58 --> Utf8 Class Initialized
INFO - 2017-03-17 20:20:58 --> URI Class Initialized
INFO - 2017-03-17 20:20:58 --> Router Class Initialized
INFO - 2017-03-17 20:20:58 --> Output Class Initialized
INFO - 2017-03-17 20:20:58 --> Security Class Initialized
DEBUG - 2017-03-17 20:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:20:58 --> Input Class Initialized
INFO - 2017-03-17 20:20:58 --> Language Class Initialized
INFO - 2017-03-17 20:20:58 --> Loader Class Initialized
INFO - 2017-03-17 20:20:58 --> Database Driver Class Initialized
INFO - 2017-03-17 20:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:20:58 --> Controller Class Initialized
INFO - 2017-03-17 20:20:58 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:20:58 --> Final output sent to browser
DEBUG - 2017-03-17 20:20:58 --> Total execution time: 0.0131
INFO - 2017-03-17 20:21:25 --> Config Class Initialized
INFO - 2017-03-17 20:21:25 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:21:25 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:21:25 --> Utf8 Class Initialized
INFO - 2017-03-17 20:21:25 --> URI Class Initialized
DEBUG - 2017-03-17 20:21:25 --> No URI present. Default controller set.
INFO - 2017-03-17 20:21:25 --> Router Class Initialized
INFO - 2017-03-17 20:21:25 --> Output Class Initialized
INFO - 2017-03-17 20:21:25 --> Security Class Initialized
DEBUG - 2017-03-17 20:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:21:25 --> Input Class Initialized
INFO - 2017-03-17 20:21:25 --> Language Class Initialized
INFO - 2017-03-17 20:21:25 --> Loader Class Initialized
INFO - 2017-03-17 20:21:25 --> Database Driver Class Initialized
INFO - 2017-03-17 20:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:21:25 --> Controller Class Initialized
INFO - 2017-03-17 20:21:25 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:21:25 --> Final output sent to browser
DEBUG - 2017-03-17 20:21:25 --> Total execution time: 0.0128
INFO - 2017-03-17 20:44:41 --> Config Class Initialized
INFO - 2017-03-17 20:44:41 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:44:42 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:44:42 --> Utf8 Class Initialized
INFO - 2017-03-17 20:44:42 --> URI Class Initialized
DEBUG - 2017-03-17 20:44:42 --> No URI present. Default controller set.
INFO - 2017-03-17 20:44:42 --> Router Class Initialized
INFO - 2017-03-17 20:44:42 --> Output Class Initialized
INFO - 2017-03-17 20:44:42 --> Security Class Initialized
DEBUG - 2017-03-17 20:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:44:42 --> Input Class Initialized
INFO - 2017-03-17 20:44:42 --> Language Class Initialized
INFO - 2017-03-17 20:44:42 --> Loader Class Initialized
INFO - 2017-03-17 20:44:42 --> Database Driver Class Initialized
INFO - 2017-03-17 20:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:44:42 --> Controller Class Initialized
INFO - 2017-03-17 20:44:42 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:44:43 --> Final output sent to browser
DEBUG - 2017-03-17 20:44:43 --> Total execution time: 1.2179
INFO - 2017-03-17 20:44:45 --> Config Class Initialized
INFO - 2017-03-17 20:44:45 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:44:45 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:44:45 --> Utf8 Class Initialized
INFO - 2017-03-17 20:44:45 --> URI Class Initialized
INFO - 2017-03-17 20:44:45 --> Router Class Initialized
INFO - 2017-03-17 20:44:45 --> Output Class Initialized
INFO - 2017-03-17 20:44:45 --> Security Class Initialized
DEBUG - 2017-03-17 20:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:44:45 --> Input Class Initialized
INFO - 2017-03-17 20:44:45 --> Language Class Initialized
INFO - 2017-03-17 20:44:45 --> Loader Class Initialized
INFO - 2017-03-17 20:44:45 --> Database Driver Class Initialized
INFO - 2017-03-17 20:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:44:45 --> Controller Class Initialized
INFO - 2017-03-17 20:44:45 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:44:45 --> Final output sent to browser
DEBUG - 2017-03-17 20:44:45 --> Total execution time: 0.0490
INFO - 2017-03-17 20:44:50 --> Config Class Initialized
INFO - 2017-03-17 20:44:50 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:44:50 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:44:50 --> Utf8 Class Initialized
INFO - 2017-03-17 20:44:50 --> URI Class Initialized
INFO - 2017-03-17 20:44:50 --> Router Class Initialized
INFO - 2017-03-17 20:44:50 --> Output Class Initialized
INFO - 2017-03-17 20:44:50 --> Security Class Initialized
DEBUG - 2017-03-17 20:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:44:50 --> Input Class Initialized
INFO - 2017-03-17 20:44:50 --> Language Class Initialized
INFO - 2017-03-17 20:44:50 --> Loader Class Initialized
INFO - 2017-03-17 20:44:50 --> Database Driver Class Initialized
INFO - 2017-03-17 20:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:44:50 --> Controller Class Initialized
INFO - 2017-03-17 20:44:50 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:44:51 --> Config Class Initialized
INFO - 2017-03-17 20:44:51 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:44:51 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:44:51 --> Utf8 Class Initialized
INFO - 2017-03-17 20:44:51 --> URI Class Initialized
INFO - 2017-03-17 20:44:51 --> Router Class Initialized
INFO - 2017-03-17 20:44:51 --> Output Class Initialized
INFO - 2017-03-17 20:44:51 --> Security Class Initialized
DEBUG - 2017-03-17 20:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:44:51 --> Input Class Initialized
INFO - 2017-03-17 20:44:51 --> Language Class Initialized
INFO - 2017-03-17 20:44:51 --> Loader Class Initialized
INFO - 2017-03-17 20:44:51 --> Database Driver Class Initialized
INFO - 2017-03-17 20:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:44:51 --> Controller Class Initialized
INFO - 2017-03-17 20:44:51 --> Helper loaded: date_helper
DEBUG - 2017-03-17 20:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:44:51 --> Helper loaded: url_helper
INFO - 2017-03-17 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:44:51 --> Final output sent to browser
DEBUG - 2017-03-17 20:44:51 --> Total execution time: 0.2576
INFO - 2017-03-17 20:44:59 --> Config Class Initialized
INFO - 2017-03-17 20:44:59 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:44:59 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:44:59 --> Utf8 Class Initialized
INFO - 2017-03-17 20:44:59 --> URI Class Initialized
INFO - 2017-03-17 20:44:59 --> Router Class Initialized
INFO - 2017-03-17 20:44:59 --> Output Class Initialized
INFO - 2017-03-17 20:44:59 --> Security Class Initialized
DEBUG - 2017-03-17 20:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:44:59 --> Input Class Initialized
INFO - 2017-03-17 20:44:59 --> Language Class Initialized
INFO - 2017-03-17 20:44:59 --> Loader Class Initialized
INFO - 2017-03-17 20:44:59 --> Database Driver Class Initialized
INFO - 2017-03-17 20:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:44:59 --> Controller Class Initialized
INFO - 2017-03-17 20:44:59 --> Helper loaded: date_helper
DEBUG - 2017-03-17 20:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:45:00 --> Helper loaded: url_helper
INFO - 2017-03-17 20:45:00 --> Helper loaded: download_helper
INFO - 2017-03-17 20:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 20:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-17 20:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-17 20:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:45:00 --> Final output sent to browser
DEBUG - 2017-03-17 20:45:00 --> Total execution time: 1.2340
INFO - 2017-03-17 20:45:01 --> Config Class Initialized
INFO - 2017-03-17 20:45:01 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:45:01 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:45:01 --> Utf8 Class Initialized
INFO - 2017-03-17 20:45:01 --> URI Class Initialized
INFO - 2017-03-17 20:45:01 --> Router Class Initialized
INFO - 2017-03-17 20:45:01 --> Output Class Initialized
INFO - 2017-03-17 20:45:01 --> Security Class Initialized
DEBUG - 2017-03-17 20:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:45:01 --> Input Class Initialized
INFO - 2017-03-17 20:45:01 --> Language Class Initialized
INFO - 2017-03-17 20:45:01 --> Loader Class Initialized
INFO - 2017-03-17 20:45:01 --> Database Driver Class Initialized
INFO - 2017-03-17 20:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:45:01 --> Controller Class Initialized
INFO - 2017-03-17 20:45:01 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:45:01 --> Final output sent to browser
DEBUG - 2017-03-17 20:45:01 --> Total execution time: 0.2615
INFO - 2017-03-17 20:45:21 --> Config Class Initialized
INFO - 2017-03-17 20:45:21 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:45:21 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:45:21 --> Utf8 Class Initialized
INFO - 2017-03-17 20:45:21 --> URI Class Initialized
INFO - 2017-03-17 20:45:21 --> Router Class Initialized
INFO - 2017-03-17 20:45:21 --> Output Class Initialized
INFO - 2017-03-17 20:45:21 --> Security Class Initialized
DEBUG - 2017-03-17 20:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:45:21 --> Input Class Initialized
INFO - 2017-03-17 20:45:21 --> Language Class Initialized
INFO - 2017-03-17 20:45:21 --> Loader Class Initialized
INFO - 2017-03-17 20:45:21 --> Database Driver Class Initialized
INFO - 2017-03-17 20:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:45:21 --> Controller Class Initialized
INFO - 2017-03-17 20:45:21 --> Upload Class Initialized
INFO - 2017-03-17 20:45:21 --> Helper loaded: date_helper
DEBUG - 2017-03-17 20:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:45:21 --> Helper loaded: url_helper
INFO - 2017-03-17 20:45:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:45:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 20:45:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-17 20:45:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-17 20:45:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-17 20:45:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:45:21 --> Final output sent to browser
DEBUG - 2017-03-17 20:45:21 --> Total execution time: 0.8801
INFO - 2017-03-17 20:45:22 --> Config Class Initialized
INFO - 2017-03-17 20:45:22 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:45:22 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:45:22 --> Utf8 Class Initialized
INFO - 2017-03-17 20:45:22 --> URI Class Initialized
INFO - 2017-03-17 20:45:22 --> Router Class Initialized
INFO - 2017-03-17 20:45:22 --> Output Class Initialized
INFO - 2017-03-17 20:45:22 --> Security Class Initialized
DEBUG - 2017-03-17 20:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:45:22 --> Input Class Initialized
INFO - 2017-03-17 20:45:22 --> Language Class Initialized
INFO - 2017-03-17 20:45:22 --> Loader Class Initialized
INFO - 2017-03-17 20:45:22 --> Database Driver Class Initialized
INFO - 2017-03-17 20:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:45:22 --> Controller Class Initialized
INFO - 2017-03-17 20:45:22 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:45:22 --> Final output sent to browser
DEBUG - 2017-03-17 20:45:22 --> Total execution time: 0.0153
INFO - 2017-03-17 20:45:28 --> Config Class Initialized
INFO - 2017-03-17 20:45:28 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:45:28 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:45:28 --> Utf8 Class Initialized
INFO - 2017-03-17 20:45:28 --> URI Class Initialized
INFO - 2017-03-17 20:45:28 --> Router Class Initialized
INFO - 2017-03-17 20:45:28 --> Output Class Initialized
INFO - 2017-03-17 20:45:28 --> Security Class Initialized
DEBUG - 2017-03-17 20:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:45:28 --> Input Class Initialized
INFO - 2017-03-17 20:45:28 --> Language Class Initialized
INFO - 2017-03-17 20:45:28 --> Loader Class Initialized
INFO - 2017-03-17 20:45:28 --> Database Driver Class Initialized
INFO - 2017-03-17 20:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:45:28 --> Controller Class Initialized
INFO - 2017-03-17 20:45:28 --> Helper loaded: date_helper
DEBUG - 2017-03-17 20:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:45:28 --> Helper loaded: url_helper
INFO - 2017-03-17 20:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-17 20:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-17 20:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 20:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:45:28 --> Final output sent to browser
DEBUG - 2017-03-17 20:45:28 --> Total execution time: 0.0527
INFO - 2017-03-17 20:45:29 --> Config Class Initialized
INFO - 2017-03-17 20:45:29 --> Hooks Class Initialized
DEBUG - 2017-03-17 20:45:29 --> UTF-8 Support Enabled
INFO - 2017-03-17 20:45:29 --> Utf8 Class Initialized
INFO - 2017-03-17 20:45:29 --> URI Class Initialized
INFO - 2017-03-17 20:45:29 --> Router Class Initialized
INFO - 2017-03-17 20:45:29 --> Output Class Initialized
INFO - 2017-03-17 20:45:29 --> Security Class Initialized
DEBUG - 2017-03-17 20:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 20:45:29 --> Input Class Initialized
INFO - 2017-03-17 20:45:29 --> Language Class Initialized
INFO - 2017-03-17 20:45:29 --> Loader Class Initialized
INFO - 2017-03-17 20:45:29 --> Database Driver Class Initialized
INFO - 2017-03-17 20:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 20:45:29 --> Controller Class Initialized
INFO - 2017-03-17 20:45:29 --> Helper loaded: url_helper
DEBUG - 2017-03-17 20:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 20:45:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 20:45:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 20:45:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 20:45:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 20:45:29 --> Final output sent to browser
DEBUG - 2017-03-17 20:45:29 --> Total execution time: 0.0141
INFO - 2017-03-17 21:55:02 --> Config Class Initialized
INFO - 2017-03-17 21:55:02 --> Hooks Class Initialized
DEBUG - 2017-03-17 21:55:02 --> UTF-8 Support Enabled
INFO - 2017-03-17 21:55:02 --> Utf8 Class Initialized
INFO - 2017-03-17 21:55:02 --> URI Class Initialized
DEBUG - 2017-03-17 21:55:02 --> No URI present. Default controller set.
INFO - 2017-03-17 21:55:02 --> Router Class Initialized
INFO - 2017-03-17 21:55:03 --> Output Class Initialized
INFO - 2017-03-17 21:55:03 --> Security Class Initialized
DEBUG - 2017-03-17 21:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 21:55:03 --> Input Class Initialized
INFO - 2017-03-17 21:55:03 --> Language Class Initialized
INFO - 2017-03-17 21:55:03 --> Loader Class Initialized
INFO - 2017-03-17 21:55:03 --> Database Driver Class Initialized
INFO - 2017-03-17 21:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 21:55:04 --> Controller Class Initialized
INFO - 2017-03-17 21:55:04 --> Helper loaded: url_helper
DEBUG - 2017-03-17 21:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 21:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 21:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 21:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 21:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 21:55:04 --> Final output sent to browser
DEBUG - 2017-03-17 21:55:04 --> Total execution time: 1.9843
INFO - 2017-03-17 21:55:07 --> Config Class Initialized
INFO - 2017-03-17 21:55:07 --> Hooks Class Initialized
DEBUG - 2017-03-17 21:55:07 --> UTF-8 Support Enabled
INFO - 2017-03-17 21:55:07 --> Utf8 Class Initialized
INFO - 2017-03-17 21:55:07 --> URI Class Initialized
INFO - 2017-03-17 21:55:07 --> Router Class Initialized
INFO - 2017-03-17 21:55:07 --> Output Class Initialized
INFO - 2017-03-17 21:55:07 --> Security Class Initialized
DEBUG - 2017-03-17 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 21:55:07 --> Input Class Initialized
INFO - 2017-03-17 21:55:07 --> Language Class Initialized
INFO - 2017-03-17 21:55:07 --> Loader Class Initialized
INFO - 2017-03-17 21:55:07 --> Database Driver Class Initialized
INFO - 2017-03-17 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 21:55:07 --> Controller Class Initialized
INFO - 2017-03-17 21:55:07 --> Helper loaded: url_helper
DEBUG - 2017-03-17 21:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 21:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 21:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 21:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 21:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 21:55:07 --> Final output sent to browser
DEBUG - 2017-03-17 21:55:07 --> Total execution time: 0.0139
INFO - 2017-03-17 21:55:33 --> Config Class Initialized
INFO - 2017-03-17 21:55:33 --> Hooks Class Initialized
DEBUG - 2017-03-17 21:55:33 --> UTF-8 Support Enabled
INFO - 2017-03-17 21:55:33 --> Utf8 Class Initialized
INFO - 2017-03-17 21:55:33 --> URI Class Initialized
INFO - 2017-03-17 21:55:34 --> Router Class Initialized
INFO - 2017-03-17 21:55:34 --> Output Class Initialized
INFO - 2017-03-17 21:55:34 --> Security Class Initialized
DEBUG - 2017-03-17 21:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 21:55:34 --> Input Class Initialized
INFO - 2017-03-17 21:55:34 --> Language Class Initialized
INFO - 2017-03-17 21:55:34 --> Loader Class Initialized
INFO - 2017-03-17 21:55:34 --> Database Driver Class Initialized
INFO - 2017-03-17 21:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 21:55:34 --> Controller Class Initialized
INFO - 2017-03-17 21:55:34 --> Helper loaded: date_helper
DEBUG - 2017-03-17 21:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 21:55:34 --> Helper loaded: url_helper
INFO - 2017-03-17 21:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 21:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-17 21:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-17 21:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-17 21:55:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 21:55:34 --> Final output sent to browser
DEBUG - 2017-03-17 21:55:34 --> Total execution time: 1.1220
INFO - 2017-03-17 21:55:35 --> Config Class Initialized
INFO - 2017-03-17 21:55:35 --> Hooks Class Initialized
DEBUG - 2017-03-17 21:55:35 --> UTF-8 Support Enabled
INFO - 2017-03-17 21:55:35 --> Utf8 Class Initialized
INFO - 2017-03-17 21:55:35 --> URI Class Initialized
INFO - 2017-03-17 21:55:35 --> Router Class Initialized
INFO - 2017-03-17 21:55:35 --> Output Class Initialized
INFO - 2017-03-17 21:55:35 --> Security Class Initialized
DEBUG - 2017-03-17 21:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 21:55:35 --> Input Class Initialized
INFO - 2017-03-17 21:55:35 --> Language Class Initialized
INFO - 2017-03-17 21:55:35 --> Loader Class Initialized
INFO - 2017-03-17 21:55:35 --> Database Driver Class Initialized
INFO - 2017-03-17 21:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 21:55:35 --> Controller Class Initialized
INFO - 2017-03-17 21:55:35 --> Helper loaded: url_helper
DEBUG - 2017-03-17 21:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 21:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 21:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 21:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 21:55:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 21:55:35 --> Final output sent to browser
DEBUG - 2017-03-17 21:55:35 --> Total execution time: 0.2734
INFO - 2017-03-17 21:58:33 --> Config Class Initialized
INFO - 2017-03-17 21:58:33 --> Hooks Class Initialized
DEBUG - 2017-03-17 21:58:33 --> UTF-8 Support Enabled
INFO - 2017-03-17 21:58:33 --> Utf8 Class Initialized
INFO - 2017-03-17 21:58:33 --> URI Class Initialized
INFO - 2017-03-17 21:58:34 --> Router Class Initialized
INFO - 2017-03-17 21:58:34 --> Output Class Initialized
INFO - 2017-03-17 21:58:34 --> Security Class Initialized
DEBUG - 2017-03-17 21:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 21:58:34 --> Input Class Initialized
INFO - 2017-03-17 21:58:34 --> Language Class Initialized
INFO - 2017-03-17 21:58:34 --> Loader Class Initialized
INFO - 2017-03-17 21:58:34 --> Database Driver Class Initialized
INFO - 2017-03-17 21:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 21:58:35 --> Controller Class Initialized
INFO - 2017-03-17 21:58:35 --> Helper loaded: url_helper
DEBUG - 2017-03-17 21:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 21:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 21:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 21:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 21:58:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 21:58:35 --> Final output sent to browser
DEBUG - 2017-03-17 21:58:35 --> Total execution time: 1.8259
INFO - 2017-03-17 23:41:16 --> Config Class Initialized
INFO - 2017-03-17 23:41:16 --> Hooks Class Initialized
DEBUG - 2017-03-17 23:41:16 --> UTF-8 Support Enabled
INFO - 2017-03-17 23:41:16 --> Utf8 Class Initialized
INFO - 2017-03-17 23:41:16 --> URI Class Initialized
DEBUG - 2017-03-17 23:41:17 --> No URI present. Default controller set.
INFO - 2017-03-17 23:41:17 --> Router Class Initialized
INFO - 2017-03-17 23:41:17 --> Output Class Initialized
INFO - 2017-03-17 23:41:17 --> Security Class Initialized
DEBUG - 2017-03-17 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 23:41:17 --> Input Class Initialized
INFO - 2017-03-17 23:41:17 --> Language Class Initialized
INFO - 2017-03-17 23:41:17 --> Loader Class Initialized
INFO - 2017-03-17 23:41:17 --> Database Driver Class Initialized
INFO - 2017-03-17 23:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 23:41:18 --> Controller Class Initialized
INFO - 2017-03-17 23:41:18 --> Helper loaded: url_helper
DEBUG - 2017-03-17 23:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 23:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 23:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 23:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 23:41:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 23:41:18 --> Final output sent to browser
DEBUG - 2017-03-17 23:41:18 --> Total execution time: 2.1434
INFO - 2017-03-17 23:53:40 --> Config Class Initialized
INFO - 2017-03-17 23:53:40 --> Hooks Class Initialized
DEBUG - 2017-03-17 23:53:40 --> UTF-8 Support Enabled
INFO - 2017-03-17 23:53:40 --> Utf8 Class Initialized
INFO - 2017-03-17 23:53:40 --> URI Class Initialized
DEBUG - 2017-03-17 23:53:40 --> No URI present. Default controller set.
INFO - 2017-03-17 23:53:40 --> Router Class Initialized
INFO - 2017-03-17 23:53:40 --> Output Class Initialized
INFO - 2017-03-17 23:53:40 --> Security Class Initialized
DEBUG - 2017-03-17 23:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 23:53:40 --> Input Class Initialized
INFO - 2017-03-17 23:53:40 --> Language Class Initialized
INFO - 2017-03-17 23:53:40 --> Loader Class Initialized
INFO - 2017-03-17 23:53:41 --> Database Driver Class Initialized
INFO - 2017-03-17 23:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 23:53:41 --> Controller Class Initialized
INFO - 2017-03-17 23:53:41 --> Helper loaded: url_helper
DEBUG - 2017-03-17 23:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 23:53:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 23:53:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 23:53:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 23:53:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 23:53:42 --> Final output sent to browser
DEBUG - 2017-03-17 23:53:42 --> Total execution time: 1.9876
INFO - 2017-03-17 23:55:11 --> Config Class Initialized
INFO - 2017-03-17 23:55:11 --> Hooks Class Initialized
DEBUG - 2017-03-17 23:55:11 --> UTF-8 Support Enabled
INFO - 2017-03-17 23:55:11 --> Utf8 Class Initialized
INFO - 2017-03-17 23:55:11 --> URI Class Initialized
DEBUG - 2017-03-17 23:55:11 --> No URI present. Default controller set.
INFO - 2017-03-17 23:55:11 --> Router Class Initialized
INFO - 2017-03-17 23:55:11 --> Output Class Initialized
INFO - 2017-03-17 23:55:11 --> Security Class Initialized
DEBUG - 2017-03-17 23:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 23:55:11 --> Input Class Initialized
INFO - 2017-03-17 23:55:11 --> Language Class Initialized
INFO - 2017-03-17 23:55:11 --> Loader Class Initialized
INFO - 2017-03-17 23:55:11 --> Database Driver Class Initialized
INFO - 2017-03-17 23:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 23:55:11 --> Controller Class Initialized
INFO - 2017-03-17 23:55:11 --> Helper loaded: url_helper
DEBUG - 2017-03-17 23:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 23:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 23:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 23:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 23:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 23:55:11 --> Final output sent to browser
DEBUG - 2017-03-17 23:55:11 --> Total execution time: 0.2037
INFO - 2017-03-17 23:57:14 --> Config Class Initialized
INFO - 2017-03-17 23:57:14 --> Hooks Class Initialized
DEBUG - 2017-03-17 23:57:14 --> UTF-8 Support Enabled
INFO - 2017-03-17 23:57:14 --> Utf8 Class Initialized
INFO - 2017-03-17 23:57:14 --> URI Class Initialized
INFO - 2017-03-17 23:57:14 --> Router Class Initialized
INFO - 2017-03-17 23:57:14 --> Output Class Initialized
INFO - 2017-03-17 23:57:15 --> Security Class Initialized
DEBUG - 2017-03-17 23:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 23:57:15 --> Input Class Initialized
INFO - 2017-03-17 23:57:15 --> Language Class Initialized
INFO - 2017-03-17 23:57:15 --> Loader Class Initialized
INFO - 2017-03-17 23:57:15 --> Database Driver Class Initialized
INFO - 2017-03-17 23:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 23:57:15 --> Controller Class Initialized
INFO - 2017-03-17 23:57:15 --> Helper loaded: url_helper
DEBUG - 2017-03-17 23:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 23:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 23:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 23:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 23:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 23:57:16 --> Final output sent to browser
DEBUG - 2017-03-17 23:57:16 --> Total execution time: 1.5128
INFO - 2017-03-17 23:59:29 --> Config Class Initialized
INFO - 2017-03-17 23:59:29 --> Hooks Class Initialized
DEBUG - 2017-03-17 23:59:29 --> UTF-8 Support Enabled
INFO - 2017-03-17 23:59:29 --> Utf8 Class Initialized
INFO - 2017-03-17 23:59:29 --> URI Class Initialized
INFO - 2017-03-17 23:59:29 --> Router Class Initialized
INFO - 2017-03-17 23:59:29 --> Output Class Initialized
INFO - 2017-03-17 23:59:29 --> Security Class Initialized
DEBUG - 2017-03-17 23:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 23:59:29 --> Input Class Initialized
INFO - 2017-03-17 23:59:29 --> Language Class Initialized
INFO - 2017-03-17 23:59:29 --> Loader Class Initialized
INFO - 2017-03-17 23:59:30 --> Database Driver Class Initialized
INFO - 2017-03-17 23:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 23:59:30 --> Controller Class Initialized
INFO - 2017-03-17 23:59:30 --> Helper loaded: url_helper
DEBUG - 2017-03-17 23:59:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-17 23:59:33 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-17 23:59:33 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Valeria Canales Salas')
INFO - 2017-03-17 23:59:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-17 23:59:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-17 23:59:37 --> Config Class Initialized
INFO - 2017-03-17 23:59:37 --> Hooks Class Initialized
DEBUG - 2017-03-17 23:59:37 --> UTF-8 Support Enabled
INFO - 2017-03-17 23:59:37 --> Utf8 Class Initialized
INFO - 2017-03-17 23:59:37 --> URI Class Initialized
INFO - 2017-03-17 23:59:37 --> Router Class Initialized
INFO - 2017-03-17 23:59:37 --> Output Class Initialized
INFO - 2017-03-17 23:59:37 --> Security Class Initialized
DEBUG - 2017-03-17 23:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 23:59:37 --> Input Class Initialized
INFO - 2017-03-17 23:59:37 --> Language Class Initialized
INFO - 2017-03-17 23:59:37 --> Loader Class Initialized
INFO - 2017-03-17 23:59:37 --> Database Driver Class Initialized
INFO - 2017-03-17 23:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 23:59:37 --> Controller Class Initialized
INFO - 2017-03-17 23:59:37 --> Helper loaded: url_helper
DEBUG - 2017-03-17 23:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-17 23:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-17 23:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-17 23:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-17 23:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-17 23:59:37 --> Final output sent to browser
DEBUG - 2017-03-17 23:59:37 --> Total execution time: 0.1307

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-13 15:03:44 --> Config Class Initialized
INFO - 2016-12-13 15:03:44 --> Hooks Class Initialized
DEBUG - 2016-12-13 15:03:44 --> UTF-8 Support Enabled
INFO - 2016-12-13 15:03:44 --> Utf8 Class Initialized
INFO - 2016-12-13 15:03:44 --> URI Class Initialized
DEBUG - 2016-12-13 15:03:44 --> No URI present. Default controller set.
INFO - 2016-12-13 15:03:44 --> Router Class Initialized
INFO - 2016-12-13 15:03:44 --> Output Class Initialized
INFO - 2016-12-13 15:03:44 --> Security Class Initialized
DEBUG - 2016-12-13 15:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 15:03:44 --> Input Class Initialized
INFO - 2016-12-13 15:03:44 --> Language Class Initialized
INFO - 2016-12-13 15:03:44 --> Loader Class Initialized
INFO - 2016-12-13 15:03:45 --> Database Driver Class Initialized
INFO - 2016-12-13 15:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 15:03:45 --> Controller Class Initialized
INFO - 2016-12-13 15:03:45 --> Helper loaded: url_helper
DEBUG - 2016-12-13 15:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 15:03:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 15:03:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 15:03:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 15:03:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 15:03:45 --> Final output sent to browser
DEBUG - 2016-12-13 15:03:45 --> Total execution time: 1.8577
INFO - 2016-12-13 15:04:17 --> Config Class Initialized
INFO - 2016-12-13 15:04:17 --> Hooks Class Initialized
DEBUG - 2016-12-13 15:04:17 --> UTF-8 Support Enabled
INFO - 2016-12-13 15:04:17 --> Utf8 Class Initialized
INFO - 2016-12-13 15:04:17 --> URI Class Initialized
INFO - 2016-12-13 15:04:17 --> Router Class Initialized
INFO - 2016-12-13 15:04:17 --> Output Class Initialized
INFO - 2016-12-13 15:04:17 --> Security Class Initialized
DEBUG - 2016-12-13 15:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 15:04:17 --> Input Class Initialized
INFO - 2016-12-13 15:04:17 --> Language Class Initialized
INFO - 2016-12-13 15:04:17 --> Loader Class Initialized
INFO - 2016-12-13 15:04:17 --> Database Driver Class Initialized
INFO - 2016-12-13 15:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 15:04:17 --> Controller Class Initialized
INFO - 2016-12-13 15:04:17 --> Helper loaded: url_helper
DEBUG - 2016-12-13 15:04:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 15:04:19 --> Config Class Initialized
INFO - 2016-12-13 15:04:19 --> Hooks Class Initialized
DEBUG - 2016-12-13 15:04:19 --> UTF-8 Support Enabled
INFO - 2016-12-13 15:04:19 --> Utf8 Class Initialized
INFO - 2016-12-13 15:04:19 --> URI Class Initialized
INFO - 2016-12-13 15:04:19 --> Router Class Initialized
INFO - 2016-12-13 15:04:19 --> Output Class Initialized
INFO - 2016-12-13 15:04:19 --> Security Class Initialized
DEBUG - 2016-12-13 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 15:04:19 --> Input Class Initialized
INFO - 2016-12-13 15:04:19 --> Language Class Initialized
INFO - 2016-12-13 15:04:19 --> Loader Class Initialized
INFO - 2016-12-13 15:04:19 --> Database Driver Class Initialized
INFO - 2016-12-13 15:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 15:04:19 --> Controller Class Initialized
DEBUG - 2016-12-13 15:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 15:04:19 --> Helper loaded: url_helper
INFO - 2016-12-13 15:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 15:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-13 15:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-13 15:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-13 15:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 15:04:20 --> Final output sent to browser
DEBUG - 2016-12-13 15:04:20 --> Total execution time: 0.0805
INFO - 2016-12-13 16:09:34 --> Config Class Initialized
INFO - 2016-12-13 16:09:34 --> Hooks Class Initialized
DEBUG - 2016-12-13 16:09:35 --> UTF-8 Support Enabled
INFO - 2016-12-13 16:09:35 --> Utf8 Class Initialized
INFO - 2016-12-13 16:09:35 --> URI Class Initialized
DEBUG - 2016-12-13 16:09:35 --> No URI present. Default controller set.
INFO - 2016-12-13 16:09:35 --> Router Class Initialized
INFO - 2016-12-13 16:09:35 --> Output Class Initialized
INFO - 2016-12-13 16:09:35 --> Security Class Initialized
DEBUG - 2016-12-13 16:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 16:09:35 --> Input Class Initialized
INFO - 2016-12-13 16:09:35 --> Language Class Initialized
INFO - 2016-12-13 16:09:35 --> Loader Class Initialized
INFO - 2016-12-13 16:09:35 --> Database Driver Class Initialized
INFO - 2016-12-13 16:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 16:09:35 --> Controller Class Initialized
INFO - 2016-12-13 16:09:35 --> Helper loaded: url_helper
DEBUG - 2016-12-13 16:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 16:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 16:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 16:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 16:09:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 16:09:36 --> Final output sent to browser
DEBUG - 2016-12-13 16:09:36 --> Total execution time: 1.2762
INFO - 2016-12-13 20:19:37 --> Config Class Initialized
INFO - 2016-12-13 20:19:37 --> Hooks Class Initialized
DEBUG - 2016-12-13 20:19:37 --> UTF-8 Support Enabled
INFO - 2016-12-13 20:19:37 --> Utf8 Class Initialized
INFO - 2016-12-13 20:19:37 --> URI Class Initialized
DEBUG - 2016-12-13 20:19:37 --> No URI present. Default controller set.
INFO - 2016-12-13 20:19:37 --> Router Class Initialized
INFO - 2016-12-13 20:19:37 --> Output Class Initialized
INFO - 2016-12-13 20:19:37 --> Security Class Initialized
DEBUG - 2016-12-13 20:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 20:19:38 --> Input Class Initialized
INFO - 2016-12-13 20:19:38 --> Language Class Initialized
INFO - 2016-12-13 20:19:38 --> Loader Class Initialized
INFO - 2016-12-13 20:19:38 --> Database Driver Class Initialized
INFO - 2016-12-13 20:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 20:19:38 --> Controller Class Initialized
INFO - 2016-12-13 20:19:38 --> Helper loaded: url_helper
DEBUG - 2016-12-13 20:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 20:19:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 20:19:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 20:19:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 20:19:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 20:19:38 --> Final output sent to browser
DEBUG - 2016-12-13 20:19:38 --> Total execution time: 1.6600
INFO - 2016-12-13 21:57:51 --> Config Class Initialized
INFO - 2016-12-13 21:57:51 --> Hooks Class Initialized
DEBUG - 2016-12-13 21:57:51 --> UTF-8 Support Enabled
INFO - 2016-12-13 21:57:51 --> Utf8 Class Initialized
INFO - 2016-12-13 21:57:51 --> URI Class Initialized
DEBUG - 2016-12-13 21:57:51 --> No URI present. Default controller set.
INFO - 2016-12-13 21:57:51 --> Router Class Initialized
INFO - 2016-12-13 21:57:51 --> Output Class Initialized
INFO - 2016-12-13 21:57:51 --> Security Class Initialized
DEBUG - 2016-12-13 21:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 21:57:51 --> Input Class Initialized
INFO - 2016-12-13 21:57:51 --> Language Class Initialized
INFO - 2016-12-13 21:57:51 --> Loader Class Initialized
INFO - 2016-12-13 21:57:51 --> Database Driver Class Initialized
INFO - 2016-12-13 21:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 21:57:51 --> Controller Class Initialized
INFO - 2016-12-13 21:57:51 --> Helper loaded: url_helper
DEBUG - 2016-12-13 21:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 21:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 21:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 21:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 21:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 21:57:51 --> Final output sent to browser
DEBUG - 2016-12-13 21:57:51 --> Total execution time: 0.0544
INFO - 2016-12-13 21:57:53 --> Config Class Initialized
INFO - 2016-12-13 21:57:53 --> Hooks Class Initialized
DEBUG - 2016-12-13 21:57:53 --> UTF-8 Support Enabled
INFO - 2016-12-13 21:57:53 --> Utf8 Class Initialized
INFO - 2016-12-13 21:57:53 --> URI Class Initialized
INFO - 2016-12-13 21:57:53 --> Router Class Initialized
INFO - 2016-12-13 21:57:53 --> Output Class Initialized
INFO - 2016-12-13 21:57:53 --> Security Class Initialized
DEBUG - 2016-12-13 21:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 21:57:53 --> Input Class Initialized
INFO - 2016-12-13 21:57:53 --> Language Class Initialized
INFO - 2016-12-13 21:57:53 --> Loader Class Initialized
INFO - 2016-12-13 21:57:53 --> Database Driver Class Initialized
INFO - 2016-12-13 21:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 21:57:53 --> Controller Class Initialized
INFO - 2016-12-13 21:57:53 --> Helper loaded: url_helper
DEBUG - 2016-12-13 21:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 21:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 21:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 21:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 21:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 21:57:53 --> Final output sent to browser
DEBUG - 2016-12-13 21:57:53 --> Total execution time: 0.0134
INFO - 2016-12-13 21:58:18 --> Config Class Initialized
INFO - 2016-12-13 21:58:18 --> Hooks Class Initialized
DEBUG - 2016-12-13 21:58:18 --> UTF-8 Support Enabled
INFO - 2016-12-13 21:58:18 --> Utf8 Class Initialized
INFO - 2016-12-13 21:58:18 --> URI Class Initialized
INFO - 2016-12-13 21:58:18 --> Router Class Initialized
INFO - 2016-12-13 21:58:18 --> Output Class Initialized
INFO - 2016-12-13 21:58:18 --> Security Class Initialized
DEBUG - 2016-12-13 21:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 21:58:18 --> Input Class Initialized
INFO - 2016-12-13 21:58:18 --> Language Class Initialized
INFO - 2016-12-13 21:58:18 --> Loader Class Initialized
INFO - 2016-12-13 21:58:18 --> Database Driver Class Initialized
INFO - 2016-12-13 21:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 21:58:18 --> Controller Class Initialized
INFO - 2016-12-13 21:58:18 --> Helper loaded: url_helper
DEBUG - 2016-12-13 21:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 21:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 21:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 21:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 21:58:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 21:58:18 --> Final output sent to browser
DEBUG - 2016-12-13 21:58:18 --> Total execution time: 0.0137
INFO - 2016-12-13 21:58:58 --> Config Class Initialized
INFO - 2016-12-13 21:58:58 --> Hooks Class Initialized
DEBUG - 2016-12-13 21:58:58 --> UTF-8 Support Enabled
INFO - 2016-12-13 21:58:58 --> Utf8 Class Initialized
INFO - 2016-12-13 21:58:58 --> URI Class Initialized
INFO - 2016-12-13 21:58:58 --> Router Class Initialized
INFO - 2016-12-13 21:58:58 --> Output Class Initialized
INFO - 2016-12-13 21:58:58 --> Security Class Initialized
DEBUG - 2016-12-13 21:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 21:58:58 --> Input Class Initialized
INFO - 2016-12-13 21:58:58 --> Language Class Initialized
INFO - 2016-12-13 21:58:58 --> Loader Class Initialized
INFO - 2016-12-13 21:58:58 --> Database Driver Class Initialized
INFO - 2016-12-13 21:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 21:58:58 --> Controller Class Initialized
INFO - 2016-12-13 21:58:58 --> Helper loaded: url_helper
DEBUG - 2016-12-13 21:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 21:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 21:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 21:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 21:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 21:58:58 --> Final output sent to browser
DEBUG - 2016-12-13 21:58:58 --> Total execution time: 0.0144
INFO - 2016-12-13 21:59:30 --> Config Class Initialized
INFO - 2016-12-13 21:59:30 --> Hooks Class Initialized
DEBUG - 2016-12-13 21:59:30 --> UTF-8 Support Enabled
INFO - 2016-12-13 21:59:30 --> Utf8 Class Initialized
INFO - 2016-12-13 21:59:30 --> URI Class Initialized
DEBUG - 2016-12-13 21:59:30 --> No URI present. Default controller set.
INFO - 2016-12-13 21:59:30 --> Router Class Initialized
INFO - 2016-12-13 21:59:30 --> Output Class Initialized
INFO - 2016-12-13 21:59:30 --> Security Class Initialized
DEBUG - 2016-12-13 21:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 21:59:30 --> Input Class Initialized
INFO - 2016-12-13 21:59:30 --> Language Class Initialized
INFO - 2016-12-13 21:59:30 --> Loader Class Initialized
INFO - 2016-12-13 21:59:30 --> Database Driver Class Initialized
INFO - 2016-12-13 21:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 21:59:30 --> Controller Class Initialized
INFO - 2016-12-13 21:59:30 --> Helper loaded: url_helper
DEBUG - 2016-12-13 21:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 21:59:30 --> Final output sent to browser
DEBUG - 2016-12-13 21:59:30 --> Total execution time: 0.0133
INFO - 2016-12-13 21:59:31 --> Config Class Initialized
INFO - 2016-12-13 21:59:31 --> Hooks Class Initialized
DEBUG - 2016-12-13 21:59:31 --> UTF-8 Support Enabled
INFO - 2016-12-13 21:59:31 --> Utf8 Class Initialized
INFO - 2016-12-13 21:59:31 --> URI Class Initialized
INFO - 2016-12-13 21:59:31 --> Router Class Initialized
INFO - 2016-12-13 21:59:31 --> Output Class Initialized
INFO - 2016-12-13 21:59:31 --> Security Class Initialized
DEBUG - 2016-12-13 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 21:59:31 --> Input Class Initialized
INFO - 2016-12-13 21:59:31 --> Language Class Initialized
INFO - 2016-12-13 21:59:31 --> Loader Class Initialized
INFO - 2016-12-13 21:59:31 --> Database Driver Class Initialized
INFO - 2016-12-13 21:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 21:59:31 --> Controller Class Initialized
INFO - 2016-12-13 21:59:31 --> Helper loaded: url_helper
DEBUG - 2016-12-13 21:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 21:59:31 --> Final output sent to browser
DEBUG - 2016-12-13 21:59:31 --> Total execution time: 0.0142
INFO - 2016-12-13 22:00:15 --> Config Class Initialized
INFO - 2016-12-13 22:00:15 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:00:15 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:00:15 --> Utf8 Class Initialized
INFO - 2016-12-13 22:00:15 --> URI Class Initialized
INFO - 2016-12-13 22:00:15 --> Router Class Initialized
INFO - 2016-12-13 22:00:15 --> Output Class Initialized
INFO - 2016-12-13 22:00:15 --> Security Class Initialized
DEBUG - 2016-12-13 22:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:00:15 --> Input Class Initialized
INFO - 2016-12-13 22:00:15 --> Language Class Initialized
INFO - 2016-12-13 22:00:15 --> Loader Class Initialized
INFO - 2016-12-13 22:00:15 --> Database Driver Class Initialized
INFO - 2016-12-13 22:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:00:15 --> Controller Class Initialized
INFO - 2016-12-13 22:00:15 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:00:16 --> Config Class Initialized
INFO - 2016-12-13 22:00:16 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:00:16 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:00:16 --> Utf8 Class Initialized
INFO - 2016-12-13 22:00:16 --> URI Class Initialized
INFO - 2016-12-13 22:00:16 --> Router Class Initialized
INFO - 2016-12-13 22:00:16 --> Output Class Initialized
INFO - 2016-12-13 22:00:16 --> Security Class Initialized
DEBUG - 2016-12-13 22:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:00:16 --> Input Class Initialized
INFO - 2016-12-13 22:00:16 --> Language Class Initialized
INFO - 2016-12-13 22:00:16 --> Loader Class Initialized
INFO - 2016-12-13 22:00:16 --> Database Driver Class Initialized
INFO - 2016-12-13 22:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:00:16 --> Controller Class Initialized
DEBUG - 2016-12-13 22:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:00:16 --> Helper loaded: url_helper
INFO - 2016-12-13 22:00:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:00:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-13 22:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-13 22:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-13 22:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:00:17 --> Final output sent to browser
DEBUG - 2016-12-13 22:00:17 --> Total execution time: 0.1104
INFO - 2016-12-13 22:00:17 --> Config Class Initialized
INFO - 2016-12-13 22:00:17 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:00:17 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:00:17 --> Utf8 Class Initialized
INFO - 2016-12-13 22:00:17 --> URI Class Initialized
INFO - 2016-12-13 22:00:17 --> Router Class Initialized
INFO - 2016-12-13 22:00:17 --> Output Class Initialized
INFO - 2016-12-13 22:00:17 --> Security Class Initialized
DEBUG - 2016-12-13 22:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:00:17 --> Input Class Initialized
INFO - 2016-12-13 22:00:17 --> Language Class Initialized
INFO - 2016-12-13 22:00:17 --> Loader Class Initialized
INFO - 2016-12-13 22:00:17 --> Database Driver Class Initialized
INFO - 2016-12-13 22:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:00:17 --> Controller Class Initialized
INFO - 2016-12-13 22:00:17 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:00:17 --> Final output sent to browser
DEBUG - 2016-12-13 22:00:17 --> Total execution time: 0.0134
INFO - 2016-12-13 22:00:22 --> Config Class Initialized
INFO - 2016-12-13 22:00:22 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:00:22 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:00:22 --> Utf8 Class Initialized
INFO - 2016-12-13 22:00:22 --> URI Class Initialized
INFO - 2016-12-13 22:00:22 --> Router Class Initialized
INFO - 2016-12-13 22:00:22 --> Output Class Initialized
INFO - 2016-12-13 22:00:22 --> Security Class Initialized
DEBUG - 2016-12-13 22:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:00:22 --> Input Class Initialized
INFO - 2016-12-13 22:00:22 --> Language Class Initialized
INFO - 2016-12-13 22:00:22 --> Loader Class Initialized
INFO - 2016-12-13 22:00:22 --> Database Driver Class Initialized
INFO - 2016-12-13 22:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:00:22 --> Controller Class Initialized
INFO - 2016-12-13 22:00:22 --> Helper loaded: date_helper
DEBUG - 2016-12-13 22:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:00:23 --> Helper loaded: url_helper
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:00:23 --> Final output sent to browser
DEBUG - 2016-12-13 22:00:23 --> Total execution time: 0.1753
INFO - 2016-12-13 22:00:23 --> Config Class Initialized
INFO - 2016-12-13 22:00:23 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:00:23 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:00:23 --> Utf8 Class Initialized
INFO - 2016-12-13 22:00:23 --> URI Class Initialized
INFO - 2016-12-13 22:00:23 --> Router Class Initialized
INFO - 2016-12-13 22:00:23 --> Output Class Initialized
INFO - 2016-12-13 22:00:23 --> Security Class Initialized
DEBUG - 2016-12-13 22:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:00:23 --> Input Class Initialized
INFO - 2016-12-13 22:00:23 --> Language Class Initialized
INFO - 2016-12-13 22:00:23 --> Loader Class Initialized
INFO - 2016-12-13 22:00:23 --> Database Driver Class Initialized
INFO - 2016-12-13 22:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:00:23 --> Controller Class Initialized
INFO - 2016-12-13 22:00:23 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:00:23 --> Final output sent to browser
DEBUG - 2016-12-13 22:00:23 --> Total execution time: 0.0131
INFO - 2016-12-13 22:08:43 --> Config Class Initialized
INFO - 2016-12-13 22:08:43 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:08:43 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:08:43 --> Utf8 Class Initialized
INFO - 2016-12-13 22:08:43 --> URI Class Initialized
INFO - 2016-12-13 22:08:43 --> Router Class Initialized
INFO - 2016-12-13 22:08:43 --> Output Class Initialized
INFO - 2016-12-13 22:08:43 --> Security Class Initialized
DEBUG - 2016-12-13 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:08:43 --> Input Class Initialized
INFO - 2016-12-13 22:08:43 --> Language Class Initialized
INFO - 2016-12-13 22:08:43 --> Loader Class Initialized
INFO - 2016-12-13 22:08:43 --> Database Driver Class Initialized
INFO - 2016-12-13 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:08:43 --> Controller Class Initialized
INFO - 2016-12-13 22:08:43 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:08:43 --> Config Class Initialized
INFO - 2016-12-13 22:08:43 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:08:43 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:08:43 --> Utf8 Class Initialized
INFO - 2016-12-13 22:08:43 --> URI Class Initialized
DEBUG - 2016-12-13 22:08:43 --> No URI present. Default controller set.
INFO - 2016-12-13 22:08:43 --> Router Class Initialized
INFO - 2016-12-13 22:08:43 --> Output Class Initialized
INFO - 2016-12-13 22:08:43 --> Security Class Initialized
DEBUG - 2016-12-13 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:08:43 --> Input Class Initialized
INFO - 2016-12-13 22:08:43 --> Language Class Initialized
INFO - 2016-12-13 22:08:43 --> Loader Class Initialized
INFO - 2016-12-13 22:08:43 --> Database Driver Class Initialized
INFO - 2016-12-13 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:08:43 --> Controller Class Initialized
INFO - 2016-12-13 22:08:43 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:08:43 --> Final output sent to browser
DEBUG - 2016-12-13 22:08:43 --> Total execution time: 0.0132
INFO - 2016-12-13 22:08:43 --> Config Class Initialized
INFO - 2016-12-13 22:08:43 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:08:43 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:08:43 --> Utf8 Class Initialized
INFO - 2016-12-13 22:08:43 --> URI Class Initialized
INFO - 2016-12-13 22:08:43 --> Router Class Initialized
INFO - 2016-12-13 22:08:43 --> Output Class Initialized
INFO - 2016-12-13 22:08:43 --> Security Class Initialized
DEBUG - 2016-12-13 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:08:43 --> Input Class Initialized
INFO - 2016-12-13 22:08:43 --> Language Class Initialized
INFO - 2016-12-13 22:08:43 --> Loader Class Initialized
INFO - 2016-12-13 22:08:43 --> Database Driver Class Initialized
INFO - 2016-12-13 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:08:43 --> Controller Class Initialized
INFO - 2016-12-13 22:08:43 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:08:43 --> Final output sent to browser
DEBUG - 2016-12-13 22:08:43 --> Total execution time: 0.0133
INFO - 2016-12-13 22:08:43 --> Config Class Initialized
INFO - 2016-12-13 22:08:43 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:08:43 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:08:43 --> Utf8 Class Initialized
INFO - 2016-12-13 22:08:43 --> URI Class Initialized
INFO - 2016-12-13 22:08:43 --> Router Class Initialized
INFO - 2016-12-13 22:08:43 --> Output Class Initialized
INFO - 2016-12-13 22:08:43 --> Security Class Initialized
DEBUG - 2016-12-13 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:08:43 --> Input Class Initialized
INFO - 2016-12-13 22:08:43 --> Language Class Initialized
INFO - 2016-12-13 22:08:43 --> Loader Class Initialized
INFO - 2016-12-13 22:08:43 --> Database Driver Class Initialized
INFO - 2016-12-13 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:08:43 --> Controller Class Initialized
INFO - 2016-12-13 22:08:43 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:08:43 --> Final output sent to browser
DEBUG - 2016-12-13 22:08:43 --> Total execution time: 0.0135
INFO - 2016-12-13 22:55:56 --> Config Class Initialized
INFO - 2016-12-13 22:55:56 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:55:56 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:55:56 --> Utf8 Class Initialized
INFO - 2016-12-13 22:55:56 --> URI Class Initialized
DEBUG - 2016-12-13 22:55:56 --> No URI present. Default controller set.
INFO - 2016-12-13 22:55:56 --> Router Class Initialized
INFO - 2016-12-13 22:55:56 --> Output Class Initialized
INFO - 2016-12-13 22:55:56 --> Security Class Initialized
DEBUG - 2016-12-13 22:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:55:56 --> Input Class Initialized
INFO - 2016-12-13 22:55:56 --> Language Class Initialized
INFO - 2016-12-13 22:55:56 --> Loader Class Initialized
INFO - 2016-12-13 22:55:56 --> Database Driver Class Initialized
INFO - 2016-12-13 22:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:55:56 --> Controller Class Initialized
INFO - 2016-12-13 22:55:56 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:55:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:55:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:55:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:55:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:55:56 --> Final output sent to browser
DEBUG - 2016-12-13 22:55:56 --> Total execution time: 0.0177
INFO - 2016-12-13 22:55:59 --> Config Class Initialized
INFO - 2016-12-13 22:55:59 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:55:59 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:55:59 --> Utf8 Class Initialized
INFO - 2016-12-13 22:55:59 --> URI Class Initialized
INFO - 2016-12-13 22:55:59 --> Router Class Initialized
INFO - 2016-12-13 22:55:59 --> Output Class Initialized
INFO - 2016-12-13 22:55:59 --> Security Class Initialized
DEBUG - 2016-12-13 22:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:55:59 --> Input Class Initialized
INFO - 2016-12-13 22:55:59 --> Language Class Initialized
INFO - 2016-12-13 22:55:59 --> Loader Class Initialized
INFO - 2016-12-13 22:55:59 --> Database Driver Class Initialized
INFO - 2016-12-13 22:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:55:59 --> Controller Class Initialized
INFO - 2016-12-13 22:55:59 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:55:59 --> Final output sent to browser
DEBUG - 2016-12-13 22:55:59 --> Total execution time: 0.0156
INFO - 2016-12-13 22:56:03 --> Config Class Initialized
INFO - 2016-12-13 22:56:03 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:03 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:03 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:03 --> URI Class Initialized
INFO - 2016-12-13 22:56:03 --> Router Class Initialized
INFO - 2016-12-13 22:56:03 --> Output Class Initialized
INFO - 2016-12-13 22:56:03 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:03 --> Input Class Initialized
INFO - 2016-12-13 22:56:03 --> Language Class Initialized
INFO - 2016-12-13 22:56:03 --> Loader Class Initialized
INFO - 2016-12-13 22:56:03 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:03 --> Controller Class Initialized
INFO - 2016-12-13 22:56:03 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:03 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:03 --> Total execution time: 0.1942
INFO - 2016-12-13 22:56:04 --> Config Class Initialized
INFO - 2016-12-13 22:56:04 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:04 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:04 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:04 --> URI Class Initialized
INFO - 2016-12-13 22:56:04 --> Router Class Initialized
INFO - 2016-12-13 22:56:04 --> Output Class Initialized
INFO - 2016-12-13 22:56:04 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:04 --> Input Class Initialized
INFO - 2016-12-13 22:56:04 --> Language Class Initialized
INFO - 2016-12-13 22:56:04 --> Loader Class Initialized
INFO - 2016-12-13 22:56:04 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:04 --> Controller Class Initialized
INFO - 2016-12-13 22:56:04 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:04 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:04 --> Total execution time: 0.0134
INFO - 2016-12-13 22:56:11 --> Config Class Initialized
INFO - 2016-12-13 22:56:11 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:11 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:11 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:11 --> URI Class Initialized
INFO - 2016-12-13 22:56:11 --> Router Class Initialized
INFO - 2016-12-13 22:56:11 --> Output Class Initialized
INFO - 2016-12-13 22:56:11 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:11 --> Input Class Initialized
INFO - 2016-12-13 22:56:11 --> Language Class Initialized
INFO - 2016-12-13 22:56:11 --> Loader Class Initialized
INFO - 2016-12-13 22:56:11 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:11 --> Controller Class Initialized
INFO - 2016-12-13 22:56:11 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:11 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:11 --> Total execution time: 0.0158
INFO - 2016-12-13 22:56:11 --> Config Class Initialized
INFO - 2016-12-13 22:56:11 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:11 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:11 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:11 --> URI Class Initialized
INFO - 2016-12-13 22:56:11 --> Router Class Initialized
INFO - 2016-12-13 22:56:11 --> Output Class Initialized
INFO - 2016-12-13 22:56:11 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:11 --> Input Class Initialized
INFO - 2016-12-13 22:56:11 --> Language Class Initialized
INFO - 2016-12-13 22:56:11 --> Loader Class Initialized
INFO - 2016-12-13 22:56:11 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:11 --> Controller Class Initialized
INFO - 2016-12-13 22:56:11 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:11 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:11 --> Total execution time: 0.0136
INFO - 2016-12-13 22:56:18 --> Config Class Initialized
INFO - 2016-12-13 22:56:18 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:18 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:18 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:18 --> URI Class Initialized
DEBUG - 2016-12-13 22:56:18 --> No URI present. Default controller set.
INFO - 2016-12-13 22:56:18 --> Router Class Initialized
INFO - 2016-12-13 22:56:18 --> Output Class Initialized
INFO - 2016-12-13 22:56:18 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:18 --> Input Class Initialized
INFO - 2016-12-13 22:56:18 --> Language Class Initialized
INFO - 2016-12-13 22:56:18 --> Loader Class Initialized
INFO - 2016-12-13 22:56:18 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:18 --> Controller Class Initialized
INFO - 2016-12-13 22:56:18 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:18 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:18 --> Total execution time: 0.0154
INFO - 2016-12-13 22:56:21 --> Config Class Initialized
INFO - 2016-12-13 22:56:21 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:21 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:21 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:21 --> URI Class Initialized
DEBUG - 2016-12-13 22:56:21 --> No URI present. Default controller set.
INFO - 2016-12-13 22:56:21 --> Router Class Initialized
INFO - 2016-12-13 22:56:21 --> Output Class Initialized
INFO - 2016-12-13 22:56:21 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:21 --> Input Class Initialized
INFO - 2016-12-13 22:56:21 --> Language Class Initialized
INFO - 2016-12-13 22:56:21 --> Loader Class Initialized
INFO - 2016-12-13 22:56:21 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:21 --> Controller Class Initialized
INFO - 2016-12-13 22:56:21 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:21 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:21 --> Total execution time: 0.0140
INFO - 2016-12-13 22:56:22 --> Config Class Initialized
INFO - 2016-12-13 22:56:22 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:22 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:22 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:22 --> URI Class Initialized
INFO - 2016-12-13 22:56:22 --> Router Class Initialized
INFO - 2016-12-13 22:56:22 --> Output Class Initialized
INFO - 2016-12-13 22:56:22 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:22 --> Input Class Initialized
INFO - 2016-12-13 22:56:22 --> Language Class Initialized
INFO - 2016-12-13 22:56:22 --> Loader Class Initialized
INFO - 2016-12-13 22:56:22 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:22 --> Controller Class Initialized
INFO - 2016-12-13 22:56:22 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:22 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:22 --> Total execution time: 0.0133
INFO - 2016-12-13 22:56:31 --> Config Class Initialized
INFO - 2016-12-13 22:56:31 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:31 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:31 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:31 --> URI Class Initialized
INFO - 2016-12-13 22:56:31 --> Router Class Initialized
INFO - 2016-12-13 22:56:31 --> Output Class Initialized
INFO - 2016-12-13 22:56:31 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:31 --> Input Class Initialized
INFO - 2016-12-13 22:56:31 --> Language Class Initialized
INFO - 2016-12-13 22:56:31 --> Loader Class Initialized
INFO - 2016-12-13 22:56:31 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:31 --> Controller Class Initialized
INFO - 2016-12-13 22:56:31 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:31 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:31 --> Total execution time: 0.0126
INFO - 2016-12-13 22:56:32 --> Config Class Initialized
INFO - 2016-12-13 22:56:32 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:32 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:32 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:32 --> URI Class Initialized
INFO - 2016-12-13 22:56:32 --> Router Class Initialized
INFO - 2016-12-13 22:56:32 --> Output Class Initialized
INFO - 2016-12-13 22:56:32 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:32 --> Input Class Initialized
INFO - 2016-12-13 22:56:32 --> Language Class Initialized
INFO - 2016-12-13 22:56:32 --> Loader Class Initialized
INFO - 2016-12-13 22:56:32 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:32 --> Controller Class Initialized
INFO - 2016-12-13 22:56:32 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:32 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:32 --> Total execution time: 0.0128
INFO - 2016-12-13 22:56:33 --> Config Class Initialized
INFO - 2016-12-13 22:56:33 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:33 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:33 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:33 --> URI Class Initialized
DEBUG - 2016-12-13 22:56:33 --> No URI present. Default controller set.
INFO - 2016-12-13 22:56:33 --> Router Class Initialized
INFO - 2016-12-13 22:56:33 --> Output Class Initialized
INFO - 2016-12-13 22:56:33 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:33 --> Input Class Initialized
INFO - 2016-12-13 22:56:33 --> Language Class Initialized
INFO - 2016-12-13 22:56:33 --> Loader Class Initialized
INFO - 2016-12-13 22:56:33 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:33 --> Controller Class Initialized
INFO - 2016-12-13 22:56:33 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:33 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:33 --> Total execution time: 0.0206
INFO - 2016-12-13 22:56:35 --> Config Class Initialized
INFO - 2016-12-13 22:56:35 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:56:35 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:56:35 --> Utf8 Class Initialized
INFO - 2016-12-13 22:56:35 --> URI Class Initialized
INFO - 2016-12-13 22:56:35 --> Router Class Initialized
INFO - 2016-12-13 22:56:35 --> Output Class Initialized
INFO - 2016-12-13 22:56:35 --> Security Class Initialized
DEBUG - 2016-12-13 22:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:56:35 --> Input Class Initialized
INFO - 2016-12-13 22:56:35 --> Language Class Initialized
INFO - 2016-12-13 22:56:35 --> Loader Class Initialized
INFO - 2016-12-13 22:56:35 --> Database Driver Class Initialized
INFO - 2016-12-13 22:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:56:35 --> Controller Class Initialized
INFO - 2016-12-13 22:56:35 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:56:35 --> Final output sent to browser
DEBUG - 2016-12-13 22:56:35 --> Total execution time: 0.0232
INFO - 2016-12-13 22:57:05 --> Config Class Initialized
INFO - 2016-12-13 22:57:05 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:57:05 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:57:05 --> Utf8 Class Initialized
INFO - 2016-12-13 22:57:05 --> URI Class Initialized
INFO - 2016-12-13 22:57:05 --> Router Class Initialized
INFO - 2016-12-13 22:57:05 --> Output Class Initialized
INFO - 2016-12-13 22:57:05 --> Security Class Initialized
DEBUG - 2016-12-13 22:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:57:05 --> Input Class Initialized
INFO - 2016-12-13 22:57:05 --> Language Class Initialized
INFO - 2016-12-13 22:57:05 --> Loader Class Initialized
INFO - 2016-12-13 22:57:05 --> Database Driver Class Initialized
INFO - 2016-12-13 22:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:57:05 --> Controller Class Initialized
INFO - 2016-12-13 22:57:05 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:57:05 --> Config Class Initialized
INFO - 2016-12-13 22:57:05 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:57:05 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:57:05 --> Utf8 Class Initialized
INFO - 2016-12-13 22:57:05 --> URI Class Initialized
INFO - 2016-12-13 22:57:05 --> Router Class Initialized
INFO - 2016-12-13 22:57:05 --> Output Class Initialized
INFO - 2016-12-13 22:57:05 --> Security Class Initialized
DEBUG - 2016-12-13 22:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:57:05 --> Input Class Initialized
INFO - 2016-12-13 22:57:05 --> Language Class Initialized
INFO - 2016-12-13 22:57:05 --> Loader Class Initialized
INFO - 2016-12-13 22:57:05 --> Database Driver Class Initialized
INFO - 2016-12-13 22:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:57:05 --> Controller Class Initialized
INFO - 2016-12-13 22:57:05 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:57:05 --> Config Class Initialized
INFO - 2016-12-13 22:57:05 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:57:05 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:57:05 --> Utf8 Class Initialized
INFO - 2016-12-13 22:57:05 --> URI Class Initialized
INFO - 2016-12-13 22:57:05 --> Router Class Initialized
INFO - 2016-12-13 22:57:05 --> Output Class Initialized
INFO - 2016-12-13 22:57:05 --> Security Class Initialized
DEBUG - 2016-12-13 22:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:57:05 --> Input Class Initialized
INFO - 2016-12-13 22:57:05 --> Language Class Initialized
INFO - 2016-12-13 22:57:05 --> Loader Class Initialized
INFO - 2016-12-13 22:57:05 --> Database Driver Class Initialized
INFO - 2016-12-13 22:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:57:05 --> Controller Class Initialized
DEBUG - 2016-12-13 22:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:57:05 --> Helper loaded: url_helper
INFO - 2016-12-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-13 22:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:57:05 --> Final output sent to browser
DEBUG - 2016-12-13 22:57:05 --> Total execution time: 0.0308
INFO - 2016-12-13 22:57:06 --> Config Class Initialized
INFO - 2016-12-13 22:57:06 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:57:06 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:57:06 --> Utf8 Class Initialized
INFO - 2016-12-13 22:57:06 --> URI Class Initialized
INFO - 2016-12-13 22:57:06 --> Router Class Initialized
INFO - 2016-12-13 22:57:06 --> Output Class Initialized
INFO - 2016-12-13 22:57:06 --> Security Class Initialized
DEBUG - 2016-12-13 22:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:57:06 --> Input Class Initialized
INFO - 2016-12-13 22:57:06 --> Language Class Initialized
INFO - 2016-12-13 22:57:06 --> Loader Class Initialized
INFO - 2016-12-13 22:57:06 --> Database Driver Class Initialized
INFO - 2016-12-13 22:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:57:06 --> Controller Class Initialized
INFO - 2016-12-13 22:57:06 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:57:06 --> Config Class Initialized
INFO - 2016-12-13 22:57:06 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:57:06 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:57:06 --> Utf8 Class Initialized
INFO - 2016-12-13 22:57:06 --> URI Class Initialized
INFO - 2016-12-13 22:57:06 --> Router Class Initialized
INFO - 2016-12-13 22:57:06 --> Output Class Initialized
INFO - 2016-12-13 22:57:06 --> Security Class Initialized
DEBUG - 2016-12-13 22:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:57:06 --> Input Class Initialized
INFO - 2016-12-13 22:57:06 --> Language Class Initialized
INFO - 2016-12-13 22:57:06 --> Loader Class Initialized
INFO - 2016-12-13 22:57:06 --> Database Driver Class Initialized
INFO - 2016-12-13 22:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:57:06 --> Controller Class Initialized
DEBUG - 2016-12-13 22:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:57:06 --> Helper loaded: url_helper
INFO - 2016-12-13 22:57:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:57:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-13 22:57:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-13 22:57:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:57:06 --> Final output sent to browser
DEBUG - 2016-12-13 22:57:06 --> Total execution time: 0.0128
INFO - 2016-12-13 22:57:07 --> Config Class Initialized
INFO - 2016-12-13 22:57:07 --> Hooks Class Initialized
DEBUG - 2016-12-13 22:57:07 --> UTF-8 Support Enabled
INFO - 2016-12-13 22:57:07 --> Utf8 Class Initialized
INFO - 2016-12-13 22:57:07 --> URI Class Initialized
INFO - 2016-12-13 22:57:07 --> Router Class Initialized
INFO - 2016-12-13 22:57:07 --> Output Class Initialized
INFO - 2016-12-13 22:57:07 --> Security Class Initialized
DEBUG - 2016-12-13 22:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-13 22:57:07 --> Input Class Initialized
INFO - 2016-12-13 22:57:07 --> Language Class Initialized
INFO - 2016-12-13 22:57:07 --> Loader Class Initialized
INFO - 2016-12-13 22:57:07 --> Database Driver Class Initialized
INFO - 2016-12-13 22:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-13 22:57:07 --> Controller Class Initialized
INFO - 2016-12-13 22:57:07 --> Helper loaded: url_helper
DEBUG - 2016-12-13 22:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-13 22:57:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-13 22:57:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-13 22:57:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-13 22:57:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-13 22:57:07 --> Final output sent to browser
DEBUG - 2016-12-13 22:57:07 --> Total execution time: 0.0136

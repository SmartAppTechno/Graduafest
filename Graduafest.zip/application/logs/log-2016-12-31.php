<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-31 06:19:53 --> Config Class Initialized
INFO - 2016-12-31 06:19:53 --> Hooks Class Initialized
DEBUG - 2016-12-31 06:19:53 --> UTF-8 Support Enabled
INFO - 2016-12-31 06:19:53 --> Utf8 Class Initialized
INFO - 2016-12-31 06:19:53 --> URI Class Initialized
DEBUG - 2016-12-31 06:19:53 --> No URI present. Default controller set.
INFO - 2016-12-31 06:19:53 --> Router Class Initialized
INFO - 2016-12-31 06:19:53 --> Output Class Initialized
INFO - 2016-12-31 06:19:53 --> Security Class Initialized
DEBUG - 2016-12-31 06:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 06:19:53 --> Input Class Initialized
INFO - 2016-12-31 06:19:53 --> Language Class Initialized
INFO - 2016-12-31 06:19:53 --> Loader Class Initialized
INFO - 2016-12-31 06:19:53 --> Database Driver Class Initialized
INFO - 2016-12-31 06:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-31 06:19:53 --> Controller Class Initialized
INFO - 2016-12-31 06:19:53 --> Helper loaded: url_helper
DEBUG - 2016-12-31 06:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-31 06:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-31 06:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-31 06:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-31 06:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-31 06:19:54 --> Final output sent to browser
DEBUG - 2016-12-31 06:19:54 --> Total execution time: 1.5927
INFO - 2016-12-31 06:19:56 --> Config Class Initialized
INFO - 2016-12-31 06:19:56 --> Hooks Class Initialized
DEBUG - 2016-12-31 06:19:56 --> UTF-8 Support Enabled
INFO - 2016-12-31 06:19:56 --> Utf8 Class Initialized
INFO - 2016-12-31 06:19:56 --> URI Class Initialized
INFO - 2016-12-31 06:19:56 --> Config Class Initialized
INFO - 2016-12-31 06:19:56 --> Hooks Class Initialized
INFO - 2016-12-31 06:19:56 --> Router Class Initialized
INFO - 2016-12-31 06:19:56 --> Output Class Initialized
INFO - 2016-12-31 06:19:56 --> Security Class Initialized
DEBUG - 2016-12-31 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 06:19:56 --> Input Class Initialized
INFO - 2016-12-31 06:19:56 --> Language Class Initialized
DEBUG - 2016-12-31 06:19:56 --> UTF-8 Support Enabled
INFO - 2016-12-31 06:19:56 --> Utf8 Class Initialized
INFO - 2016-12-31 06:19:56 --> URI Class Initialized
INFO - 2016-12-31 06:19:56 --> Router Class Initialized
INFO - 2016-12-31 06:19:56 --> Output Class Initialized
INFO - 2016-12-31 06:19:56 --> Security Class Initialized
DEBUG - 2016-12-31 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 06:19:56 --> Input Class Initialized
INFO - 2016-12-31 06:19:56 --> Language Class Initialized
ERROR - 2016-12-31 06:19:56 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
ERROR - 2016-12-31 06:19:56 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-31 06:19:56 --> Config Class Initialized
INFO - 2016-12-31 06:19:56 --> Hooks Class Initialized
DEBUG - 2016-12-31 06:19:56 --> UTF-8 Support Enabled
INFO - 2016-12-31 06:19:56 --> Utf8 Class Initialized
INFO - 2016-12-31 06:19:56 --> URI Class Initialized
INFO - 2016-12-31 06:19:56 --> Router Class Initialized
INFO - 2016-12-31 06:19:56 --> Output Class Initialized
INFO - 2016-12-31 06:19:56 --> Security Class Initialized
DEBUG - 2016-12-31 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 06:19:56 --> Input Class Initialized
INFO - 2016-12-31 06:19:56 --> Language Class Initialized
ERROR - 2016-12-31 06:19:56 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-31 06:19:56 --> Config Class Initialized
INFO - 2016-12-31 06:19:56 --> Hooks Class Initialized
DEBUG - 2016-12-31 06:19:56 --> UTF-8 Support Enabled
INFO - 2016-12-31 06:19:56 --> Utf8 Class Initialized
INFO - 2016-12-31 06:19:56 --> URI Class Initialized
INFO - 2016-12-31 06:19:56 --> Router Class Initialized
INFO - 2016-12-31 06:19:56 --> Output Class Initialized
INFO - 2016-12-31 06:19:56 --> Security Class Initialized
INFO - 2016-12-31 06:19:56 --> Config Class Initialized
INFO - 2016-12-31 06:19:56 --> Hooks Class Initialized
DEBUG - 2016-12-31 06:19:56 --> UTF-8 Support Enabled
INFO - 2016-12-31 06:19:56 --> Utf8 Class Initialized
INFO - 2016-12-31 06:19:56 --> URI Class Initialized
INFO - 2016-12-31 06:19:56 --> Router Class Initialized
INFO - 2016-12-31 06:19:56 --> Output Class Initialized
INFO - 2016-12-31 06:19:56 --> Security Class Initialized
DEBUG - 2016-12-31 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 06:19:56 --> Input Class Initialized
INFO - 2016-12-31 06:19:56 --> Language Class Initialized
ERROR - 2016-12-31 06:19:56 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
DEBUG - 2016-12-31 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 06:19:56 --> Input Class Initialized
INFO - 2016-12-31 06:19:56 --> Language Class Initialized
ERROR - 2016-12-31 06:19:56 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-31 06:19:56 --> Config Class Initialized
INFO - 2016-12-31 06:19:56 --> Hooks Class Initialized
DEBUG - 2016-12-31 06:19:56 --> UTF-8 Support Enabled
INFO - 2016-12-31 06:19:56 --> Utf8 Class Initialized
INFO - 2016-12-31 06:19:56 --> URI Class Initialized
INFO - 2016-12-31 06:19:56 --> Router Class Initialized
INFO - 2016-12-31 06:19:56 --> Output Class Initialized
INFO - 2016-12-31 06:19:56 --> Security Class Initialized
DEBUG - 2016-12-31 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 06:19:56 --> Input Class Initialized
INFO - 2016-12-31 06:19:56 --> Language Class Initialized
INFO - 2016-12-31 06:19:56 --> Loader Class Initialized
INFO - 2016-12-31 06:19:56 --> Database Driver Class Initialized
INFO - 2016-12-31 06:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-31 06:19:56 --> Controller Class Initialized
INFO - 2016-12-31 06:19:56 --> Helper loaded: url_helper
DEBUG - 2016-12-31 06:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-31 06:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-31 06:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-31 06:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-31 06:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-31 06:19:56 --> Final output sent to browser
DEBUG - 2016-12-31 06:19:56 --> Total execution time: 0.0352
INFO - 2016-12-31 20:42:06 --> Config Class Initialized
INFO - 2016-12-31 20:42:06 --> Hooks Class Initialized
DEBUG - 2016-12-31 20:42:07 --> UTF-8 Support Enabled
INFO - 2016-12-31 20:42:07 --> Utf8 Class Initialized
INFO - 2016-12-31 20:42:07 --> URI Class Initialized
DEBUG - 2016-12-31 20:42:07 --> No URI present. Default controller set.
INFO - 2016-12-31 20:42:07 --> Router Class Initialized
INFO - 2016-12-31 20:42:07 --> Output Class Initialized
INFO - 2016-12-31 20:42:07 --> Security Class Initialized
DEBUG - 2016-12-31 20:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-31 20:42:07 --> Input Class Initialized
INFO - 2016-12-31 20:42:07 --> Language Class Initialized
INFO - 2016-12-31 20:42:07 --> Loader Class Initialized
INFO - 2016-12-31 20:42:07 --> Database Driver Class Initialized
INFO - 2016-12-31 20:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-31 20:42:07 --> Controller Class Initialized
INFO - 2016-12-31 20:42:07 --> Helper loaded: url_helper
DEBUG - 2016-12-31 20:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-31 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-31 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-31 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-31 20:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-31 20:42:08 --> Final output sent to browser
DEBUG - 2016-12-31 20:42:08 --> Total execution time: 1.6120

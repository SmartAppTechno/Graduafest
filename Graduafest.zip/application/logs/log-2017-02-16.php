<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-16 00:38:40 --> Config Class Initialized
INFO - 2017-02-16 00:38:40 --> Hooks Class Initialized
DEBUG - 2017-02-16 00:38:40 --> UTF-8 Support Enabled
INFO - 2017-02-16 00:38:40 --> Utf8 Class Initialized
INFO - 2017-02-16 00:38:40 --> URI Class Initialized
DEBUG - 2017-02-16 00:38:40 --> No URI present. Default controller set.
INFO - 2017-02-16 00:38:40 --> Router Class Initialized
INFO - 2017-02-16 00:38:40 --> Output Class Initialized
INFO - 2017-02-16 00:38:40 --> Security Class Initialized
DEBUG - 2017-02-16 00:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 00:38:40 --> Input Class Initialized
INFO - 2017-02-16 00:38:40 --> Language Class Initialized
INFO - 2017-02-16 00:38:40 --> Loader Class Initialized
INFO - 2017-02-16 00:38:40 --> Database Driver Class Initialized
INFO - 2017-02-16 00:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 00:38:40 --> Controller Class Initialized
INFO - 2017-02-16 00:38:40 --> Helper loaded: url_helper
DEBUG - 2017-02-16 00:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 00:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 00:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 00:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 00:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 00:38:40 --> Final output sent to browser
DEBUG - 2017-02-16 00:38:40 --> Total execution time: 0.0233
INFO - 2017-02-16 01:00:43 --> Config Class Initialized
INFO - 2017-02-16 01:00:43 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:00:43 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:00:43 --> Utf8 Class Initialized
INFO - 2017-02-16 01:00:43 --> URI Class Initialized
DEBUG - 2017-02-16 01:00:43 --> No URI present. Default controller set.
INFO - 2017-02-16 01:00:43 --> Router Class Initialized
INFO - 2017-02-16 01:00:43 --> Output Class Initialized
INFO - 2017-02-16 01:00:43 --> Security Class Initialized
DEBUG - 2017-02-16 01:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:00:43 --> Input Class Initialized
INFO - 2017-02-16 01:00:43 --> Language Class Initialized
INFO - 2017-02-16 01:00:43 --> Loader Class Initialized
INFO - 2017-02-16 01:00:43 --> Database Driver Class Initialized
INFO - 2017-02-16 01:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:00:43 --> Controller Class Initialized
INFO - 2017-02-16 01:00:43 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:00:43 --> Final output sent to browser
DEBUG - 2017-02-16 01:00:43 --> Total execution time: 0.0134
INFO - 2017-02-16 01:00:48 --> Config Class Initialized
INFO - 2017-02-16 01:00:48 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:00:48 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:00:48 --> Utf8 Class Initialized
INFO - 2017-02-16 01:00:48 --> URI Class Initialized
INFO - 2017-02-16 01:00:48 --> Router Class Initialized
INFO - 2017-02-16 01:00:48 --> Output Class Initialized
INFO - 2017-02-16 01:00:48 --> Security Class Initialized
DEBUG - 2017-02-16 01:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:00:48 --> Input Class Initialized
INFO - 2017-02-16 01:00:48 --> Language Class Initialized
INFO - 2017-02-16 01:00:48 --> Loader Class Initialized
INFO - 2017-02-16 01:00:48 --> Database Driver Class Initialized
INFO - 2017-02-16 01:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:00:48 --> Controller Class Initialized
INFO - 2017-02-16 01:00:48 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:00:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:00:48 --> Final output sent to browser
DEBUG - 2017-02-16 01:00:48 --> Total execution time: 0.0142
INFO - 2017-02-16 01:01:02 --> Config Class Initialized
INFO - 2017-02-16 01:01:02 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:02 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:02 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:02 --> URI Class Initialized
INFO - 2017-02-16 01:01:02 --> Router Class Initialized
INFO - 2017-02-16 01:01:02 --> Output Class Initialized
INFO - 2017-02-16 01:01:02 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:02 --> Input Class Initialized
INFO - 2017-02-16 01:01:02 --> Language Class Initialized
INFO - 2017-02-16 01:01:02 --> Loader Class Initialized
INFO - 2017-02-16 01:01:02 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:02 --> Controller Class Initialized
INFO - 2017-02-16 01:01:02 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:04 --> Config Class Initialized
INFO - 2017-02-16 01:01:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:04 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:04 --> URI Class Initialized
INFO - 2017-02-16 01:01:04 --> Router Class Initialized
INFO - 2017-02-16 01:01:04 --> Output Class Initialized
INFO - 2017-02-16 01:01:04 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:04 --> Input Class Initialized
INFO - 2017-02-16 01:01:04 --> Language Class Initialized
INFO - 2017-02-16 01:01:04 --> Loader Class Initialized
INFO - 2017-02-16 01:01:04 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:04 --> Controller Class Initialized
INFO - 2017-02-16 01:01:04 --> Helper loaded: date_helper
DEBUG - 2017-02-16 01:01:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:04 --> Helper loaded: url_helper
INFO - 2017-02-16 01:01:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 01:01:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 01:01:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 01:01:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:04 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:04 --> Total execution time: 0.1541
INFO - 2017-02-16 01:01:05 --> Config Class Initialized
INFO - 2017-02-16 01:01:05 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:05 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:05 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:05 --> URI Class Initialized
INFO - 2017-02-16 01:01:05 --> Router Class Initialized
INFO - 2017-02-16 01:01:05 --> Output Class Initialized
INFO - 2017-02-16 01:01:05 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:05 --> Input Class Initialized
INFO - 2017-02-16 01:01:05 --> Language Class Initialized
INFO - 2017-02-16 01:01:05 --> Loader Class Initialized
INFO - 2017-02-16 01:01:05 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:05 --> Controller Class Initialized
INFO - 2017-02-16 01:01:05 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:05 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:05 --> Total execution time: 0.0147
INFO - 2017-02-16 01:01:14 --> Config Class Initialized
INFO - 2017-02-16 01:01:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:14 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:14 --> URI Class Initialized
DEBUG - 2017-02-16 01:01:14 --> No URI present. Default controller set.
INFO - 2017-02-16 01:01:14 --> Router Class Initialized
INFO - 2017-02-16 01:01:14 --> Output Class Initialized
INFO - 2017-02-16 01:01:14 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:14 --> Input Class Initialized
INFO - 2017-02-16 01:01:14 --> Language Class Initialized
INFO - 2017-02-16 01:01:14 --> Loader Class Initialized
INFO - 2017-02-16 01:01:14 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:14 --> Controller Class Initialized
INFO - 2017-02-16 01:01:14 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:14 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:14 --> Total execution time: 0.0132
INFO - 2017-02-16 01:01:16 --> Config Class Initialized
INFO - 2017-02-16 01:01:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:16 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:16 --> URI Class Initialized
INFO - 2017-02-16 01:01:16 --> Router Class Initialized
INFO - 2017-02-16 01:01:16 --> Output Class Initialized
INFO - 2017-02-16 01:01:16 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:16 --> Input Class Initialized
INFO - 2017-02-16 01:01:16 --> Language Class Initialized
INFO - 2017-02-16 01:01:16 --> Loader Class Initialized
INFO - 2017-02-16 01:01:16 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:16 --> Controller Class Initialized
INFO - 2017-02-16 01:01:16 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:16 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:16 --> Total execution time: 0.0136
INFO - 2017-02-16 01:01:20 --> Config Class Initialized
INFO - 2017-02-16 01:01:20 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:20 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:20 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:20 --> URI Class Initialized
INFO - 2017-02-16 01:01:20 --> Router Class Initialized
INFO - 2017-02-16 01:01:20 --> Output Class Initialized
INFO - 2017-02-16 01:01:20 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:20 --> Input Class Initialized
INFO - 2017-02-16 01:01:20 --> Language Class Initialized
INFO - 2017-02-16 01:01:20 --> Loader Class Initialized
INFO - 2017-02-16 01:01:20 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:20 --> Controller Class Initialized
INFO - 2017-02-16 01:01:20 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:21 --> Config Class Initialized
INFO - 2017-02-16 01:01:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:21 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:21 --> URI Class Initialized
INFO - 2017-02-16 01:01:21 --> Router Class Initialized
INFO - 2017-02-16 01:01:21 --> Output Class Initialized
INFO - 2017-02-16 01:01:21 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:21 --> Input Class Initialized
INFO - 2017-02-16 01:01:21 --> Language Class Initialized
INFO - 2017-02-16 01:01:21 --> Loader Class Initialized
INFO - 2017-02-16 01:01:21 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:21 --> Controller Class Initialized
INFO - 2017-02-16 01:01:21 --> Helper loaded: date_helper
DEBUG - 2017-02-16 01:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:21 --> Helper loaded: url_helper
INFO - 2017-02-16 01:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 01:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 01:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 01:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:21 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:21 --> Total execution time: 0.0141
INFO - 2017-02-16 01:01:22 --> Config Class Initialized
INFO - 2017-02-16 01:01:22 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:22 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:22 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:22 --> URI Class Initialized
INFO - 2017-02-16 01:01:22 --> Router Class Initialized
INFO - 2017-02-16 01:01:22 --> Output Class Initialized
INFO - 2017-02-16 01:01:22 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:22 --> Input Class Initialized
INFO - 2017-02-16 01:01:22 --> Language Class Initialized
INFO - 2017-02-16 01:01:22 --> Loader Class Initialized
INFO - 2017-02-16 01:01:22 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:22 --> Controller Class Initialized
INFO - 2017-02-16 01:01:22 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:22 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:22 --> Total execution time: 0.0132
INFO - 2017-02-16 01:01:31 --> Config Class Initialized
INFO - 2017-02-16 01:01:31 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:31 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:31 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:31 --> URI Class Initialized
DEBUG - 2017-02-16 01:01:31 --> No URI present. Default controller set.
INFO - 2017-02-16 01:01:31 --> Router Class Initialized
INFO - 2017-02-16 01:01:31 --> Output Class Initialized
INFO - 2017-02-16 01:01:31 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:31 --> Input Class Initialized
INFO - 2017-02-16 01:01:31 --> Language Class Initialized
INFO - 2017-02-16 01:01:31 --> Loader Class Initialized
INFO - 2017-02-16 01:01:31 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:31 --> Controller Class Initialized
INFO - 2017-02-16 01:01:31 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:31 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:31 --> Total execution time: 0.0401
INFO - 2017-02-16 01:01:32 --> Config Class Initialized
INFO - 2017-02-16 01:01:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:01:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:01:32 --> Utf8 Class Initialized
INFO - 2017-02-16 01:01:32 --> URI Class Initialized
INFO - 2017-02-16 01:01:32 --> Router Class Initialized
INFO - 2017-02-16 01:01:32 --> Output Class Initialized
INFO - 2017-02-16 01:01:32 --> Security Class Initialized
DEBUG - 2017-02-16 01:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:01:32 --> Input Class Initialized
INFO - 2017-02-16 01:01:32 --> Language Class Initialized
INFO - 2017-02-16 01:01:32 --> Loader Class Initialized
INFO - 2017-02-16 01:01:32 --> Database Driver Class Initialized
INFO - 2017-02-16 01:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:01:32 --> Controller Class Initialized
INFO - 2017-02-16 01:01:32 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:01:32 --> Final output sent to browser
DEBUG - 2017-02-16 01:01:32 --> Total execution time: 0.0139
INFO - 2017-02-16 01:02:13 --> Config Class Initialized
INFO - 2017-02-16 01:02:13 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:02:13 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:02:13 --> Utf8 Class Initialized
INFO - 2017-02-16 01:02:13 --> URI Class Initialized
INFO - 2017-02-16 01:02:13 --> Router Class Initialized
INFO - 2017-02-16 01:02:13 --> Output Class Initialized
INFO - 2017-02-16 01:02:13 --> Security Class Initialized
DEBUG - 2017-02-16 01:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:02:13 --> Input Class Initialized
INFO - 2017-02-16 01:02:13 --> Language Class Initialized
INFO - 2017-02-16 01:02:13 --> Loader Class Initialized
INFO - 2017-02-16 01:02:13 --> Database Driver Class Initialized
INFO - 2017-02-16 01:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:02:13 --> Controller Class Initialized
INFO - 2017-02-16 01:02:13 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:02:14 --> Config Class Initialized
INFO - 2017-02-16 01:02:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:02:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:02:14 --> Utf8 Class Initialized
INFO - 2017-02-16 01:02:14 --> URI Class Initialized
INFO - 2017-02-16 01:02:14 --> Router Class Initialized
INFO - 2017-02-16 01:02:14 --> Output Class Initialized
INFO - 2017-02-16 01:02:14 --> Security Class Initialized
DEBUG - 2017-02-16 01:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:02:14 --> Input Class Initialized
INFO - 2017-02-16 01:02:14 --> Language Class Initialized
INFO - 2017-02-16 01:02:14 --> Loader Class Initialized
INFO - 2017-02-16 01:02:14 --> Database Driver Class Initialized
INFO - 2017-02-16 01:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:02:14 --> Controller Class Initialized
INFO - 2017-02-16 01:02:14 --> Helper loaded: date_helper
DEBUG - 2017-02-16 01:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:02:14 --> Helper loaded: url_helper
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:02:14 --> Final output sent to browser
DEBUG - 2017-02-16 01:02:14 --> Total execution time: 0.0137
INFO - 2017-02-16 01:02:14 --> Config Class Initialized
INFO - 2017-02-16 01:02:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:02:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:02:14 --> Utf8 Class Initialized
INFO - 2017-02-16 01:02:14 --> URI Class Initialized
INFO - 2017-02-16 01:02:14 --> Router Class Initialized
INFO - 2017-02-16 01:02:14 --> Output Class Initialized
INFO - 2017-02-16 01:02:14 --> Security Class Initialized
DEBUG - 2017-02-16 01:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:02:14 --> Input Class Initialized
INFO - 2017-02-16 01:02:14 --> Language Class Initialized
INFO - 2017-02-16 01:02:14 --> Loader Class Initialized
INFO - 2017-02-16 01:02:14 --> Database Driver Class Initialized
INFO - 2017-02-16 01:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:02:14 --> Controller Class Initialized
INFO - 2017-02-16 01:02:14 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:02:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:02:14 --> Final output sent to browser
DEBUG - 2017-02-16 01:02:14 --> Total execution time: 0.0138
INFO - 2017-02-16 01:23:33 --> Config Class Initialized
INFO - 2017-02-16 01:23:33 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:23:33 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:23:33 --> Utf8 Class Initialized
INFO - 2017-02-16 01:23:33 --> URI Class Initialized
DEBUG - 2017-02-16 01:23:33 --> No URI present. Default controller set.
INFO - 2017-02-16 01:23:33 --> Router Class Initialized
INFO - 2017-02-16 01:23:33 --> Output Class Initialized
INFO - 2017-02-16 01:23:33 --> Security Class Initialized
DEBUG - 2017-02-16 01:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:23:33 --> Input Class Initialized
INFO - 2017-02-16 01:23:33 --> Language Class Initialized
INFO - 2017-02-16 01:23:33 --> Loader Class Initialized
INFO - 2017-02-16 01:23:33 --> Database Driver Class Initialized
INFO - 2017-02-16 01:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:23:33 --> Controller Class Initialized
INFO - 2017-02-16 01:23:33 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:23:33 --> Final output sent to browser
DEBUG - 2017-02-16 01:23:33 --> Total execution time: 0.0138
INFO - 2017-02-16 01:23:41 --> Config Class Initialized
INFO - 2017-02-16 01:23:41 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:23:41 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:23:41 --> Utf8 Class Initialized
INFO - 2017-02-16 01:23:41 --> URI Class Initialized
INFO - 2017-02-16 01:23:41 --> Router Class Initialized
INFO - 2017-02-16 01:23:41 --> Output Class Initialized
INFO - 2017-02-16 01:23:41 --> Security Class Initialized
DEBUG - 2017-02-16 01:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:23:41 --> Input Class Initialized
INFO - 2017-02-16 01:23:41 --> Language Class Initialized
INFO - 2017-02-16 01:23:41 --> Loader Class Initialized
INFO - 2017-02-16 01:23:41 --> Database Driver Class Initialized
INFO - 2017-02-16 01:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:23:41 --> Controller Class Initialized
INFO - 2017-02-16 01:23:41 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:23:41 --> Final output sent to browser
DEBUG - 2017-02-16 01:23:41 --> Total execution time: 0.0135
INFO - 2017-02-16 01:25:14 --> Config Class Initialized
INFO - 2017-02-16 01:25:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:25:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:25:14 --> Utf8 Class Initialized
INFO - 2017-02-16 01:25:14 --> URI Class Initialized
INFO - 2017-02-16 01:25:14 --> Router Class Initialized
INFO - 2017-02-16 01:25:14 --> Output Class Initialized
INFO - 2017-02-16 01:25:14 --> Security Class Initialized
DEBUG - 2017-02-16 01:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:25:14 --> Input Class Initialized
INFO - 2017-02-16 01:25:14 --> Language Class Initialized
INFO - 2017-02-16 01:25:14 --> Loader Class Initialized
INFO - 2017-02-16 01:25:14 --> Database Driver Class Initialized
INFO - 2017-02-16 01:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:25:14 --> Controller Class Initialized
INFO - 2017-02-16 01:25:14 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:25:15 --> Config Class Initialized
INFO - 2017-02-16 01:25:15 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:25:15 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:25:15 --> Utf8 Class Initialized
INFO - 2017-02-16 01:25:15 --> URI Class Initialized
INFO - 2017-02-16 01:25:15 --> Router Class Initialized
INFO - 2017-02-16 01:25:15 --> Output Class Initialized
INFO - 2017-02-16 01:25:15 --> Security Class Initialized
DEBUG - 2017-02-16 01:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:25:15 --> Input Class Initialized
INFO - 2017-02-16 01:25:15 --> Language Class Initialized
INFO - 2017-02-16 01:25:15 --> Loader Class Initialized
INFO - 2017-02-16 01:25:15 --> Database Driver Class Initialized
INFO - 2017-02-16 01:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:25:15 --> Controller Class Initialized
INFO - 2017-02-16 01:25:15 --> Helper loaded: date_helper
DEBUG - 2017-02-16 01:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:25:15 --> Helper loaded: url_helper
INFO - 2017-02-16 01:25:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:25:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 01:25:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 01:25:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 01:25:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:25:15 --> Final output sent to browser
DEBUG - 2017-02-16 01:25:15 --> Total execution time: 0.0136
INFO - 2017-02-16 01:25:16 --> Config Class Initialized
INFO - 2017-02-16 01:25:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:25:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:25:16 --> Utf8 Class Initialized
INFO - 2017-02-16 01:25:16 --> URI Class Initialized
INFO - 2017-02-16 01:25:16 --> Router Class Initialized
INFO - 2017-02-16 01:25:16 --> Output Class Initialized
INFO - 2017-02-16 01:25:16 --> Security Class Initialized
DEBUG - 2017-02-16 01:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:25:16 --> Input Class Initialized
INFO - 2017-02-16 01:25:16 --> Language Class Initialized
INFO - 2017-02-16 01:25:16 --> Loader Class Initialized
INFO - 2017-02-16 01:25:16 --> Database Driver Class Initialized
INFO - 2017-02-16 01:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:25:16 --> Controller Class Initialized
INFO - 2017-02-16 01:25:16 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:25:16 --> Final output sent to browser
DEBUG - 2017-02-16 01:25:16 --> Total execution time: 0.0134
INFO - 2017-02-16 01:33:21 --> Config Class Initialized
INFO - 2017-02-16 01:33:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:33:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:33:21 --> Utf8 Class Initialized
INFO - 2017-02-16 01:33:21 --> URI Class Initialized
INFO - 2017-02-16 01:33:21 --> Router Class Initialized
INFO - 2017-02-16 01:33:21 --> Output Class Initialized
INFO - 2017-02-16 01:33:21 --> Security Class Initialized
DEBUG - 2017-02-16 01:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:33:21 --> Input Class Initialized
INFO - 2017-02-16 01:33:21 --> Language Class Initialized
INFO - 2017-02-16 01:33:21 --> Loader Class Initialized
INFO - 2017-02-16 01:33:21 --> Database Driver Class Initialized
INFO - 2017-02-16 01:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:33:21 --> Controller Class Initialized
INFO - 2017-02-16 01:33:21 --> Helper loaded: date_helper
DEBUG - 2017-02-16 01:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:33:21 --> Helper loaded: url_helper
INFO - 2017-02-16 01:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 01:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 01:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 01:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:33:21 --> Final output sent to browser
DEBUG - 2017-02-16 01:33:21 --> Total execution time: 0.0139
INFO - 2017-02-16 01:33:27 --> Config Class Initialized
INFO - 2017-02-16 01:33:27 --> Hooks Class Initialized
DEBUG - 2017-02-16 01:33:27 --> UTF-8 Support Enabled
INFO - 2017-02-16 01:33:27 --> Utf8 Class Initialized
INFO - 2017-02-16 01:33:27 --> URI Class Initialized
INFO - 2017-02-16 01:33:27 --> Router Class Initialized
INFO - 2017-02-16 01:33:27 --> Output Class Initialized
INFO - 2017-02-16 01:33:27 --> Security Class Initialized
DEBUG - 2017-02-16 01:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 01:33:27 --> Input Class Initialized
INFO - 2017-02-16 01:33:27 --> Language Class Initialized
INFO - 2017-02-16 01:33:27 --> Loader Class Initialized
INFO - 2017-02-16 01:33:27 --> Database Driver Class Initialized
INFO - 2017-02-16 01:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 01:33:27 --> Controller Class Initialized
INFO - 2017-02-16 01:33:27 --> Helper loaded: url_helper
DEBUG - 2017-02-16 01:33:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 01:33:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 01:33:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 01:33:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 01:33:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 01:33:27 --> Final output sent to browser
DEBUG - 2017-02-16 01:33:27 --> Total execution time: 0.0136
INFO - 2017-02-16 02:03:16 --> Config Class Initialized
INFO - 2017-02-16 02:03:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:03:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:03:16 --> Utf8 Class Initialized
INFO - 2017-02-16 02:03:16 --> URI Class Initialized
INFO - 2017-02-16 02:03:16 --> Router Class Initialized
INFO - 2017-02-16 02:03:16 --> Output Class Initialized
INFO - 2017-02-16 02:03:16 --> Security Class Initialized
DEBUG - 2017-02-16 02:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:03:16 --> Input Class Initialized
INFO - 2017-02-16 02:03:16 --> Language Class Initialized
INFO - 2017-02-16 02:03:16 --> Loader Class Initialized
INFO - 2017-02-16 02:03:16 --> Database Driver Class Initialized
INFO - 2017-02-16 02:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:03:16 --> Controller Class Initialized
INFO - 2017-02-16 02:03:16 --> Helper loaded: url_helper
DEBUG - 2017-02-16 02:03:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 02:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 02:03:16 --> Final output sent to browser
DEBUG - 2017-02-16 02:03:16 --> Total execution time: 0.0134
INFO - 2017-02-16 02:03:20 --> Config Class Initialized
INFO - 2017-02-16 02:03:20 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:03:20 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:03:20 --> Utf8 Class Initialized
INFO - 2017-02-16 02:03:20 --> URI Class Initialized
DEBUG - 2017-02-16 02:03:20 --> No URI present. Default controller set.
INFO - 2017-02-16 02:03:20 --> Router Class Initialized
INFO - 2017-02-16 02:03:20 --> Output Class Initialized
INFO - 2017-02-16 02:03:20 --> Security Class Initialized
DEBUG - 2017-02-16 02:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:03:20 --> Input Class Initialized
INFO - 2017-02-16 02:03:20 --> Language Class Initialized
INFO - 2017-02-16 02:03:20 --> Loader Class Initialized
INFO - 2017-02-16 02:03:20 --> Database Driver Class Initialized
INFO - 2017-02-16 02:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:03:20 --> Controller Class Initialized
INFO - 2017-02-16 02:03:20 --> Helper loaded: url_helper
DEBUG - 2017-02-16 02:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:03:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 02:03:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 02:03:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 02:03:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 02:03:20 --> Final output sent to browser
DEBUG - 2017-02-16 02:03:20 --> Total execution time: 0.0133
INFO - 2017-02-16 02:25:48 --> Config Class Initialized
INFO - 2017-02-16 02:25:48 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:25:48 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:25:48 --> Utf8 Class Initialized
INFO - 2017-02-16 02:25:48 --> URI Class Initialized
DEBUG - 2017-02-16 02:25:48 --> No URI present. Default controller set.
INFO - 2017-02-16 02:25:48 --> Router Class Initialized
INFO - 2017-02-16 02:25:48 --> Output Class Initialized
INFO - 2017-02-16 02:25:48 --> Security Class Initialized
DEBUG - 2017-02-16 02:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:25:48 --> Input Class Initialized
INFO - 2017-02-16 02:25:48 --> Language Class Initialized
INFO - 2017-02-16 02:25:48 --> Loader Class Initialized
INFO - 2017-02-16 02:25:48 --> Database Driver Class Initialized
INFO - 2017-02-16 02:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:25:48 --> Controller Class Initialized
INFO - 2017-02-16 02:25:48 --> Helper loaded: url_helper
DEBUG - 2017-02-16 02:25:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 02:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 02:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 02:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 02:25:48 --> Final output sent to browser
DEBUG - 2017-02-16 02:25:48 --> Total execution time: 0.0144
INFO - 2017-02-16 02:26:20 --> Config Class Initialized
INFO - 2017-02-16 02:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:26:20 --> Utf8 Class Initialized
INFO - 2017-02-16 02:26:20 --> URI Class Initialized
INFO - 2017-02-16 02:26:20 --> Router Class Initialized
INFO - 2017-02-16 02:26:20 --> Output Class Initialized
INFO - 2017-02-16 02:26:20 --> Security Class Initialized
DEBUG - 2017-02-16 02:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:26:20 --> Input Class Initialized
INFO - 2017-02-16 02:26:20 --> Language Class Initialized
INFO - 2017-02-16 02:26:20 --> Loader Class Initialized
INFO - 2017-02-16 02:26:20 --> Database Driver Class Initialized
INFO - 2017-02-16 02:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:26:20 --> Controller Class Initialized
INFO - 2017-02-16 02:26:20 --> Helper loaded: url_helper
DEBUG - 2017-02-16 02:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 02:26:20 --> Final output sent to browser
DEBUG - 2017-02-16 02:26:20 --> Total execution time: 0.0134
INFO - 2017-02-16 02:26:58 --> Config Class Initialized
INFO - 2017-02-16 02:26:58 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:26:58 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:26:58 --> Utf8 Class Initialized
INFO - 2017-02-16 02:26:58 --> URI Class Initialized
INFO - 2017-02-16 02:26:58 --> Router Class Initialized
INFO - 2017-02-16 02:26:58 --> Output Class Initialized
INFO - 2017-02-16 02:26:58 --> Security Class Initialized
DEBUG - 2017-02-16 02:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:26:58 --> Input Class Initialized
INFO - 2017-02-16 02:26:58 --> Language Class Initialized
INFO - 2017-02-16 02:26:58 --> Loader Class Initialized
INFO - 2017-02-16 02:26:58 --> Database Driver Class Initialized
INFO - 2017-02-16 02:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:26:58 --> Controller Class Initialized
INFO - 2017-02-16 02:26:58 --> Helper loaded: url_helper
DEBUG - 2017-02-16 02:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:27:00 --> Config Class Initialized
INFO - 2017-02-16 02:27:00 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:27:00 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:27:00 --> Utf8 Class Initialized
INFO - 2017-02-16 02:27:00 --> URI Class Initialized
INFO - 2017-02-16 02:27:00 --> Router Class Initialized
INFO - 2017-02-16 02:27:00 --> Output Class Initialized
INFO - 2017-02-16 02:27:00 --> Security Class Initialized
DEBUG - 2017-02-16 02:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:27:00 --> Input Class Initialized
INFO - 2017-02-16 02:27:00 --> Language Class Initialized
INFO - 2017-02-16 02:27:00 --> Loader Class Initialized
INFO - 2017-02-16 02:27:00 --> Database Driver Class Initialized
INFO - 2017-02-16 02:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:27:00 --> Controller Class Initialized
INFO - 2017-02-16 02:27:00 --> Helper loaded: date_helper
DEBUG - 2017-02-16 02:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:27:00 --> Helper loaded: url_helper
INFO - 2017-02-16 02:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 02:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 02:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 02:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 02:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 02:27:00 --> Final output sent to browser
DEBUG - 2017-02-16 02:27:00 --> Total execution time: 0.0140
INFO - 2017-02-16 02:27:01 --> Config Class Initialized
INFO - 2017-02-16 02:27:01 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:27:01 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:27:01 --> Utf8 Class Initialized
INFO - 2017-02-16 02:27:01 --> URI Class Initialized
INFO - 2017-02-16 02:27:01 --> Router Class Initialized
INFO - 2017-02-16 02:27:01 --> Output Class Initialized
INFO - 2017-02-16 02:27:01 --> Security Class Initialized
DEBUG - 2017-02-16 02:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:27:01 --> Input Class Initialized
INFO - 2017-02-16 02:27:01 --> Language Class Initialized
INFO - 2017-02-16 02:27:01 --> Loader Class Initialized
INFO - 2017-02-16 02:27:01 --> Database Driver Class Initialized
INFO - 2017-02-16 02:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:27:01 --> Controller Class Initialized
INFO - 2017-02-16 02:27:01 --> Helper loaded: url_helper
DEBUG - 2017-02-16 02:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:27:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 02:27:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 02:27:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 02:27:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 02:27:01 --> Final output sent to browser
DEBUG - 2017-02-16 02:27:01 --> Total execution time: 0.0142
INFO - 2017-02-16 02:29:15 --> Config Class Initialized
INFO - 2017-02-16 02:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:29:15 --> Utf8 Class Initialized
INFO - 2017-02-16 02:29:15 --> URI Class Initialized
INFO - 2017-02-16 02:29:15 --> Router Class Initialized
INFO - 2017-02-16 02:29:15 --> Output Class Initialized
INFO - 2017-02-16 02:29:15 --> Security Class Initialized
DEBUG - 2017-02-16 02:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:29:15 --> Input Class Initialized
INFO - 2017-02-16 02:29:15 --> Language Class Initialized
INFO - 2017-02-16 02:29:15 --> Loader Class Initialized
INFO - 2017-02-16 02:29:15 --> Database Driver Class Initialized
INFO - 2017-02-16 02:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:29:15 --> Controller Class Initialized
INFO - 2017-02-16 02:29:15 --> Helper loaded: url_helper
DEBUG - 2017-02-16 02:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:29:16 --> Config Class Initialized
INFO - 2017-02-16 02:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 02:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 02:29:16 --> Utf8 Class Initialized
INFO - 2017-02-16 02:29:16 --> URI Class Initialized
INFO - 2017-02-16 02:29:16 --> Router Class Initialized
INFO - 2017-02-16 02:29:16 --> Output Class Initialized
INFO - 2017-02-16 02:29:16 --> Security Class Initialized
DEBUG - 2017-02-16 02:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 02:29:16 --> Input Class Initialized
INFO - 2017-02-16 02:29:16 --> Language Class Initialized
INFO - 2017-02-16 02:29:16 --> Loader Class Initialized
INFO - 2017-02-16 02:29:16 --> Database Driver Class Initialized
INFO - 2017-02-16 02:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 02:29:16 --> Controller Class Initialized
INFO - 2017-02-16 02:29:16 --> Helper loaded: date_helper
DEBUG - 2017-02-16 02:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 02:29:16 --> Helper loaded: url_helper
INFO - 2017-02-16 02:29:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 02:29:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 02:29:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 02:29:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 02:29:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 02:29:16 --> Final output sent to browser
DEBUG - 2017-02-16 02:29:16 --> Total execution time: 0.0142
INFO - 2017-02-16 03:32:23 --> Config Class Initialized
INFO - 2017-02-16 03:32:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 03:32:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 03:32:23 --> Utf8 Class Initialized
INFO - 2017-02-16 03:32:23 --> URI Class Initialized
DEBUG - 2017-02-16 03:32:23 --> No URI present. Default controller set.
INFO - 2017-02-16 03:32:23 --> Router Class Initialized
INFO - 2017-02-16 03:32:23 --> Output Class Initialized
INFO - 2017-02-16 03:32:23 --> Security Class Initialized
DEBUG - 2017-02-16 03:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 03:32:23 --> Input Class Initialized
INFO - 2017-02-16 03:32:23 --> Language Class Initialized
INFO - 2017-02-16 03:32:23 --> Loader Class Initialized
INFO - 2017-02-16 03:32:23 --> Database Driver Class Initialized
INFO - 2017-02-16 03:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 03:32:23 --> Controller Class Initialized
INFO - 2017-02-16 03:32:23 --> Helper loaded: url_helper
DEBUG - 2017-02-16 03:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 03:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 03:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 03:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 03:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 03:32:23 --> Final output sent to browser
DEBUG - 2017-02-16 03:32:23 --> Total execution time: 0.0138
INFO - 2017-02-16 03:32:35 --> Config Class Initialized
INFO - 2017-02-16 03:32:35 --> Hooks Class Initialized
DEBUG - 2017-02-16 03:32:35 --> UTF-8 Support Enabled
INFO - 2017-02-16 03:32:35 --> Utf8 Class Initialized
INFO - 2017-02-16 03:32:35 --> URI Class Initialized
INFO - 2017-02-16 03:32:35 --> Router Class Initialized
INFO - 2017-02-16 03:32:35 --> Output Class Initialized
INFO - 2017-02-16 03:32:35 --> Security Class Initialized
DEBUG - 2017-02-16 03:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 03:32:35 --> Input Class Initialized
INFO - 2017-02-16 03:32:35 --> Language Class Initialized
INFO - 2017-02-16 03:32:35 --> Loader Class Initialized
INFO - 2017-02-16 03:32:35 --> Database Driver Class Initialized
INFO - 2017-02-16 03:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 03:32:35 --> Controller Class Initialized
INFO - 2017-02-16 03:32:35 --> Helper loaded: url_helper
DEBUG - 2017-02-16 03:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 03:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 03:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 03:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 03:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 03:32:35 --> Final output sent to browser
DEBUG - 2017-02-16 03:32:35 --> Total execution time: 0.0158
INFO - 2017-02-16 03:32:47 --> Config Class Initialized
INFO - 2017-02-16 03:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-16 03:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-16 03:32:47 --> Utf8 Class Initialized
INFO - 2017-02-16 03:32:47 --> URI Class Initialized
INFO - 2017-02-16 03:32:47 --> Router Class Initialized
INFO - 2017-02-16 03:32:47 --> Output Class Initialized
INFO - 2017-02-16 03:32:47 --> Security Class Initialized
DEBUG - 2017-02-16 03:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 03:32:47 --> Input Class Initialized
INFO - 2017-02-16 03:32:47 --> Language Class Initialized
INFO - 2017-02-16 03:32:47 --> Loader Class Initialized
INFO - 2017-02-16 03:32:47 --> Database Driver Class Initialized
INFO - 2017-02-16 03:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 03:32:47 --> Controller Class Initialized
INFO - 2017-02-16 03:32:47 --> Helper loaded: url_helper
DEBUG - 2017-02-16 03:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 03:32:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-16 03:32:47 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-16 03:32:47 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-16 03:32:47 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-16 03:32:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 03:32:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 03:32:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 03:32:47 --> Final output sent to browser
DEBUG - 2017-02-16 03:32:47 --> Total execution time: 0.0305
INFO - 2017-02-16 03:32:48 --> Config Class Initialized
INFO - 2017-02-16 03:32:48 --> Hooks Class Initialized
DEBUG - 2017-02-16 03:32:48 --> UTF-8 Support Enabled
INFO - 2017-02-16 03:32:48 --> Utf8 Class Initialized
INFO - 2017-02-16 03:32:48 --> URI Class Initialized
INFO - 2017-02-16 03:32:48 --> Router Class Initialized
INFO - 2017-02-16 03:32:48 --> Output Class Initialized
INFO - 2017-02-16 03:32:48 --> Security Class Initialized
DEBUG - 2017-02-16 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 03:32:48 --> Input Class Initialized
INFO - 2017-02-16 03:32:48 --> Language Class Initialized
INFO - 2017-02-16 03:32:48 --> Loader Class Initialized
INFO - 2017-02-16 03:32:48 --> Database Driver Class Initialized
INFO - 2017-02-16 03:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 03:32:48 --> Controller Class Initialized
INFO - 2017-02-16 03:32:48 --> Helper loaded: url_helper
DEBUG - 2017-02-16 03:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 03:32:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 03:32:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 03:32:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 03:32:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 03:32:48 --> Final output sent to browser
DEBUG - 2017-02-16 03:32:48 --> Total execution time: 0.0136
INFO - 2017-02-16 03:33:03 --> Config Class Initialized
INFO - 2017-02-16 03:33:03 --> Hooks Class Initialized
DEBUG - 2017-02-16 03:33:03 --> UTF-8 Support Enabled
INFO - 2017-02-16 03:33:03 --> Utf8 Class Initialized
INFO - 2017-02-16 03:33:03 --> URI Class Initialized
INFO - 2017-02-16 03:33:03 --> Router Class Initialized
INFO - 2017-02-16 03:33:03 --> Output Class Initialized
INFO - 2017-02-16 03:33:03 --> Security Class Initialized
DEBUG - 2017-02-16 03:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 03:33:03 --> Input Class Initialized
INFO - 2017-02-16 03:33:03 --> Language Class Initialized
INFO - 2017-02-16 03:33:03 --> Loader Class Initialized
INFO - 2017-02-16 03:33:03 --> Database Driver Class Initialized
INFO - 2017-02-16 03:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 03:33:03 --> Controller Class Initialized
INFO - 2017-02-16 03:33:03 --> Helper loaded: url_helper
DEBUG - 2017-02-16 03:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 03:33:04 --> Config Class Initialized
INFO - 2017-02-16 03:33:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 03:33:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 03:33:04 --> Utf8 Class Initialized
INFO - 2017-02-16 03:33:04 --> URI Class Initialized
INFO - 2017-02-16 03:33:04 --> Router Class Initialized
INFO - 2017-02-16 03:33:04 --> Output Class Initialized
INFO - 2017-02-16 03:33:04 --> Security Class Initialized
DEBUG - 2017-02-16 03:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 03:33:04 --> Input Class Initialized
INFO - 2017-02-16 03:33:04 --> Language Class Initialized
INFO - 2017-02-16 03:33:04 --> Loader Class Initialized
INFO - 2017-02-16 03:33:04 --> Database Driver Class Initialized
INFO - 2017-02-16 03:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 03:33:04 --> Controller Class Initialized
INFO - 2017-02-16 03:33:04 --> Helper loaded: date_helper
DEBUG - 2017-02-16 03:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 03:33:04 --> Helper loaded: url_helper
INFO - 2017-02-16 03:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 03:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 03:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 03:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 03:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 03:33:04 --> Final output sent to browser
DEBUG - 2017-02-16 03:33:04 --> Total execution time: 0.0138
INFO - 2017-02-16 03:33:05 --> Config Class Initialized
INFO - 2017-02-16 03:33:05 --> Hooks Class Initialized
DEBUG - 2017-02-16 03:33:05 --> UTF-8 Support Enabled
INFO - 2017-02-16 03:33:05 --> Utf8 Class Initialized
INFO - 2017-02-16 03:33:05 --> URI Class Initialized
INFO - 2017-02-16 03:33:05 --> Router Class Initialized
INFO - 2017-02-16 03:33:05 --> Output Class Initialized
INFO - 2017-02-16 03:33:05 --> Security Class Initialized
DEBUG - 2017-02-16 03:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 03:33:05 --> Input Class Initialized
INFO - 2017-02-16 03:33:05 --> Language Class Initialized
INFO - 2017-02-16 03:33:05 --> Loader Class Initialized
INFO - 2017-02-16 03:33:05 --> Database Driver Class Initialized
INFO - 2017-02-16 03:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 03:33:05 --> Controller Class Initialized
INFO - 2017-02-16 03:33:05 --> Helper loaded: url_helper
DEBUG - 2017-02-16 03:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 03:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 03:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 03:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 03:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 03:33:05 --> Final output sent to browser
DEBUG - 2017-02-16 03:33:05 --> Total execution time: 0.0133
INFO - 2017-02-16 04:24:56 --> Config Class Initialized
INFO - 2017-02-16 04:24:56 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:24:56 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:24:56 --> Utf8 Class Initialized
INFO - 2017-02-16 04:24:56 --> URI Class Initialized
DEBUG - 2017-02-16 04:24:56 --> No URI present. Default controller set.
INFO - 2017-02-16 04:24:56 --> Router Class Initialized
INFO - 2017-02-16 04:24:56 --> Output Class Initialized
INFO - 2017-02-16 04:24:56 --> Security Class Initialized
DEBUG - 2017-02-16 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:24:56 --> Input Class Initialized
INFO - 2017-02-16 04:24:56 --> Language Class Initialized
INFO - 2017-02-16 04:24:56 --> Loader Class Initialized
INFO - 2017-02-16 04:24:56 --> Database Driver Class Initialized
INFO - 2017-02-16 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:24:56 --> Controller Class Initialized
INFO - 2017-02-16 04:24:56 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:24:56 --> Final output sent to browser
DEBUG - 2017-02-16 04:24:56 --> Total execution time: 0.0134
INFO - 2017-02-16 04:24:56 --> Config Class Initialized
INFO - 2017-02-16 04:24:56 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:24:56 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:24:56 --> Utf8 Class Initialized
INFO - 2017-02-16 04:24:56 --> URI Class Initialized
DEBUG - 2017-02-16 04:24:56 --> No URI present. Default controller set.
INFO - 2017-02-16 04:24:56 --> Router Class Initialized
INFO - 2017-02-16 04:24:56 --> Output Class Initialized
INFO - 2017-02-16 04:24:56 --> Security Class Initialized
DEBUG - 2017-02-16 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:24:56 --> Input Class Initialized
INFO - 2017-02-16 04:24:56 --> Language Class Initialized
INFO - 2017-02-16 04:24:56 --> Loader Class Initialized
INFO - 2017-02-16 04:24:56 --> Database Driver Class Initialized
INFO - 2017-02-16 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:24:56 --> Controller Class Initialized
INFO - 2017-02-16 04:24:56 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:24:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:24:56 --> Final output sent to browser
DEBUG - 2017-02-16 04:24:56 --> Total execution time: 0.0136
INFO - 2017-02-16 04:25:01 --> Config Class Initialized
INFO - 2017-02-16 04:25:01 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:01 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:01 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:01 --> URI Class Initialized
INFO - 2017-02-16 04:25:01 --> Router Class Initialized
INFO - 2017-02-16 04:25:01 --> Output Class Initialized
INFO - 2017-02-16 04:25:01 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:01 --> Input Class Initialized
INFO - 2017-02-16 04:25:01 --> Language Class Initialized
INFO - 2017-02-16 04:25:01 --> Loader Class Initialized
INFO - 2017-02-16 04:25:01 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:01 --> Controller Class Initialized
INFO - 2017-02-16 04:25:01 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:25:01 --> Final output sent to browser
DEBUG - 2017-02-16 04:25:01 --> Total execution time: 0.0133
INFO - 2017-02-16 04:25:04 --> Config Class Initialized
INFO - 2017-02-16 04:25:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:04 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:04 --> URI Class Initialized
INFO - 2017-02-16 04:25:04 --> Router Class Initialized
INFO - 2017-02-16 04:25:04 --> Output Class Initialized
INFO - 2017-02-16 04:25:04 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:04 --> Input Class Initialized
INFO - 2017-02-16 04:25:04 --> Language Class Initialized
INFO - 2017-02-16 04:25:04 --> Loader Class Initialized
INFO - 2017-02-16 04:25:04 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:04 --> Controller Class Initialized
INFO - 2017-02-16 04:25:04 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:25:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:05 --> Config Class Initialized
INFO - 2017-02-16 04:25:05 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:05 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:05 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:05 --> URI Class Initialized
INFO - 2017-02-16 04:25:05 --> Router Class Initialized
INFO - 2017-02-16 04:25:05 --> Output Class Initialized
INFO - 2017-02-16 04:25:05 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:05 --> Input Class Initialized
INFO - 2017-02-16 04:25:05 --> Language Class Initialized
INFO - 2017-02-16 04:25:05 --> Loader Class Initialized
INFO - 2017-02-16 04:25:05 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:05 --> Controller Class Initialized
INFO - 2017-02-16 04:25:05 --> Helper loaded: date_helper
DEBUG - 2017-02-16 04:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:05 --> Helper loaded: url_helper
INFO - 2017-02-16 04:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 04:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 04:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 04:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:25:05 --> Final output sent to browser
DEBUG - 2017-02-16 04:25:05 --> Total execution time: 0.0135
INFO - 2017-02-16 04:25:06 --> Config Class Initialized
INFO - 2017-02-16 04:25:06 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:06 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:06 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:06 --> URI Class Initialized
INFO - 2017-02-16 04:25:06 --> Router Class Initialized
INFO - 2017-02-16 04:25:06 --> Output Class Initialized
INFO - 2017-02-16 04:25:06 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:06 --> Input Class Initialized
INFO - 2017-02-16 04:25:06 --> Language Class Initialized
INFO - 2017-02-16 04:25:06 --> Loader Class Initialized
INFO - 2017-02-16 04:25:06 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:06 --> Controller Class Initialized
INFO - 2017-02-16 04:25:06 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:25:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:25:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:25:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:25:06 --> Final output sent to browser
DEBUG - 2017-02-16 04:25:06 --> Total execution time: 0.0138
INFO - 2017-02-16 04:25:26 --> Config Class Initialized
INFO - 2017-02-16 04:25:26 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:26 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:26 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:26 --> URI Class Initialized
INFO - 2017-02-16 04:25:26 --> Router Class Initialized
INFO - 2017-02-16 04:25:26 --> Output Class Initialized
INFO - 2017-02-16 04:25:26 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:26 --> Input Class Initialized
INFO - 2017-02-16 04:25:26 --> Language Class Initialized
INFO - 2017-02-16 04:25:26 --> Loader Class Initialized
INFO - 2017-02-16 04:25:26 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:26 --> Controller Class Initialized
INFO - 2017-02-16 04:25:26 --> Helper loaded: date_helper
DEBUG - 2017-02-16 04:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:26 --> Helper loaded: url_helper
INFO - 2017-02-16 04:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 04:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 04:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 04:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:25:26 --> Final output sent to browser
DEBUG - 2017-02-16 04:25:26 --> Total execution time: 0.0136
INFO - 2017-02-16 04:25:27 --> Config Class Initialized
INFO - 2017-02-16 04:25:27 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:27 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:27 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:27 --> URI Class Initialized
INFO - 2017-02-16 04:25:27 --> Router Class Initialized
INFO - 2017-02-16 04:25:27 --> Output Class Initialized
INFO - 2017-02-16 04:25:27 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:27 --> Input Class Initialized
INFO - 2017-02-16 04:25:27 --> Language Class Initialized
INFO - 2017-02-16 04:25:27 --> Loader Class Initialized
INFO - 2017-02-16 04:25:27 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:27 --> Controller Class Initialized
INFO - 2017-02-16 04:25:27 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:25:27 --> Final output sent to browser
DEBUG - 2017-02-16 04:25:27 --> Total execution time: 0.0138
INFO - 2017-02-16 04:25:30 --> Config Class Initialized
INFO - 2017-02-16 04:25:30 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:30 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:30 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:30 --> URI Class Initialized
DEBUG - 2017-02-16 04:25:30 --> No URI present. Default controller set.
INFO - 2017-02-16 04:25:30 --> Router Class Initialized
INFO - 2017-02-16 04:25:30 --> Output Class Initialized
INFO - 2017-02-16 04:25:30 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:30 --> Input Class Initialized
INFO - 2017-02-16 04:25:30 --> Language Class Initialized
INFO - 2017-02-16 04:25:30 --> Loader Class Initialized
INFO - 2017-02-16 04:25:30 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:30 --> Controller Class Initialized
INFO - 2017-02-16 04:25:30 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:25:30 --> Final output sent to browser
DEBUG - 2017-02-16 04:25:30 --> Total execution time: 0.0143
INFO - 2017-02-16 04:25:31 --> Config Class Initialized
INFO - 2017-02-16 04:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:25:31 --> Utf8 Class Initialized
INFO - 2017-02-16 04:25:31 --> URI Class Initialized
INFO - 2017-02-16 04:25:31 --> Router Class Initialized
INFO - 2017-02-16 04:25:31 --> Output Class Initialized
INFO - 2017-02-16 04:25:31 --> Security Class Initialized
DEBUG - 2017-02-16 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:25:31 --> Input Class Initialized
INFO - 2017-02-16 04:25:31 --> Language Class Initialized
INFO - 2017-02-16 04:25:31 --> Loader Class Initialized
INFO - 2017-02-16 04:25:31 --> Database Driver Class Initialized
INFO - 2017-02-16 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:25:31 --> Controller Class Initialized
INFO - 2017-02-16 04:25:31 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:25:31 --> Final output sent to browser
DEBUG - 2017-02-16 04:25:31 --> Total execution time: 0.0132
INFO - 2017-02-16 04:26:15 --> Config Class Initialized
INFO - 2017-02-16 04:26:15 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:26:15 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:26:15 --> Utf8 Class Initialized
INFO - 2017-02-16 04:26:15 --> URI Class Initialized
INFO - 2017-02-16 04:26:15 --> Router Class Initialized
INFO - 2017-02-16 04:26:15 --> Output Class Initialized
INFO - 2017-02-16 04:26:15 --> Security Class Initialized
DEBUG - 2017-02-16 04:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:26:15 --> Input Class Initialized
INFO - 2017-02-16 04:26:15 --> Language Class Initialized
INFO - 2017-02-16 04:26:15 --> Loader Class Initialized
INFO - 2017-02-16 04:26:15 --> Database Driver Class Initialized
INFO - 2017-02-16 04:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:26:15 --> Controller Class Initialized
INFO - 2017-02-16 04:26:15 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:26:16 --> Config Class Initialized
INFO - 2017-02-16 04:26:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:26:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:26:16 --> Utf8 Class Initialized
INFO - 2017-02-16 04:26:16 --> URI Class Initialized
INFO - 2017-02-16 04:26:16 --> Router Class Initialized
INFO - 2017-02-16 04:26:16 --> Output Class Initialized
INFO - 2017-02-16 04:26:16 --> Security Class Initialized
DEBUG - 2017-02-16 04:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:26:16 --> Input Class Initialized
INFO - 2017-02-16 04:26:16 --> Language Class Initialized
INFO - 2017-02-16 04:26:16 --> Loader Class Initialized
INFO - 2017-02-16 04:26:16 --> Database Driver Class Initialized
INFO - 2017-02-16 04:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:26:16 --> Controller Class Initialized
INFO - 2017-02-16 04:26:16 --> Helper loaded: date_helper
DEBUG - 2017-02-16 04:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:26:16 --> Helper loaded: url_helper
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:26:16 --> Final output sent to browser
DEBUG - 2017-02-16 04:26:16 --> Total execution time: 0.0139
INFO - 2017-02-16 04:26:16 --> Config Class Initialized
INFO - 2017-02-16 04:26:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:26:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:26:16 --> Utf8 Class Initialized
INFO - 2017-02-16 04:26:16 --> URI Class Initialized
INFO - 2017-02-16 04:26:16 --> Router Class Initialized
INFO - 2017-02-16 04:26:16 --> Output Class Initialized
INFO - 2017-02-16 04:26:16 --> Security Class Initialized
DEBUG - 2017-02-16 04:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:26:16 --> Input Class Initialized
INFO - 2017-02-16 04:26:16 --> Language Class Initialized
INFO - 2017-02-16 04:26:16 --> Loader Class Initialized
INFO - 2017-02-16 04:26:16 --> Database Driver Class Initialized
INFO - 2017-02-16 04:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:26:16 --> Controller Class Initialized
INFO - 2017-02-16 04:26:16 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:26:16 --> Final output sent to browser
DEBUG - 2017-02-16 04:26:16 --> Total execution time: 0.0133
INFO - 2017-02-16 04:26:20 --> Config Class Initialized
INFO - 2017-02-16 04:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:26:20 --> Utf8 Class Initialized
INFO - 2017-02-16 04:26:20 --> URI Class Initialized
DEBUG - 2017-02-16 04:26:20 --> No URI present. Default controller set.
INFO - 2017-02-16 04:26:20 --> Router Class Initialized
INFO - 2017-02-16 04:26:20 --> Output Class Initialized
INFO - 2017-02-16 04:26:20 --> Security Class Initialized
DEBUG - 2017-02-16 04:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:26:20 --> Input Class Initialized
INFO - 2017-02-16 04:26:20 --> Language Class Initialized
INFO - 2017-02-16 04:26:20 --> Loader Class Initialized
INFO - 2017-02-16 04:26:20 --> Database Driver Class Initialized
INFO - 2017-02-16 04:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:26:20 --> Controller Class Initialized
INFO - 2017-02-16 04:26:20 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:26:20 --> Final output sent to browser
DEBUG - 2017-02-16 04:26:20 --> Total execution time: 0.0136
INFO - 2017-02-16 04:26:21 --> Config Class Initialized
INFO - 2017-02-16 04:26:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 04:26:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 04:26:21 --> Utf8 Class Initialized
INFO - 2017-02-16 04:26:21 --> URI Class Initialized
INFO - 2017-02-16 04:26:21 --> Router Class Initialized
INFO - 2017-02-16 04:26:21 --> Output Class Initialized
INFO - 2017-02-16 04:26:21 --> Security Class Initialized
DEBUG - 2017-02-16 04:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 04:26:21 --> Input Class Initialized
INFO - 2017-02-16 04:26:21 --> Language Class Initialized
INFO - 2017-02-16 04:26:21 --> Loader Class Initialized
INFO - 2017-02-16 04:26:21 --> Database Driver Class Initialized
INFO - 2017-02-16 04:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 04:26:21 --> Controller Class Initialized
INFO - 2017-02-16 04:26:21 --> Helper loaded: url_helper
DEBUG - 2017-02-16 04:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 04:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 04:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 04:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 04:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 04:26:21 --> Final output sent to browser
DEBUG - 2017-02-16 04:26:21 --> Total execution time: 0.0133
INFO - 2017-02-16 05:01:32 --> Config Class Initialized
INFO - 2017-02-16 05:01:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 05:01:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 05:01:32 --> Utf8 Class Initialized
INFO - 2017-02-16 05:01:32 --> URI Class Initialized
DEBUG - 2017-02-16 05:01:32 --> No URI present. Default controller set.
INFO - 2017-02-16 05:01:32 --> Router Class Initialized
INFO - 2017-02-16 05:01:32 --> Output Class Initialized
INFO - 2017-02-16 05:01:32 --> Security Class Initialized
DEBUG - 2017-02-16 05:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 05:01:32 --> Input Class Initialized
INFO - 2017-02-16 05:01:32 --> Language Class Initialized
INFO - 2017-02-16 05:01:32 --> Loader Class Initialized
INFO - 2017-02-16 05:01:32 --> Database Driver Class Initialized
INFO - 2017-02-16 05:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 05:01:32 --> Controller Class Initialized
INFO - 2017-02-16 05:01:32 --> Helper loaded: url_helper
DEBUG - 2017-02-16 05:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 05:01:32 --> Final output sent to browser
DEBUG - 2017-02-16 05:01:32 --> Total execution time: 0.0149
INFO - 2017-02-16 15:19:13 --> Config Class Initialized
INFO - 2017-02-16 15:19:13 --> Hooks Class Initialized
DEBUG - 2017-02-16 15:19:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 15:19:14 --> Utf8 Class Initialized
INFO - 2017-02-16 15:19:14 --> URI Class Initialized
DEBUG - 2017-02-16 15:19:14 --> No URI present. Default controller set.
INFO - 2017-02-16 15:19:14 --> Router Class Initialized
INFO - 2017-02-16 15:19:14 --> Output Class Initialized
INFO - 2017-02-16 15:19:14 --> Security Class Initialized
DEBUG - 2017-02-16 15:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 15:19:14 --> Input Class Initialized
INFO - 2017-02-16 15:19:14 --> Language Class Initialized
INFO - 2017-02-16 15:19:14 --> Loader Class Initialized
INFO - 2017-02-16 15:19:14 --> Database Driver Class Initialized
INFO - 2017-02-16 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 15:19:15 --> Controller Class Initialized
INFO - 2017-02-16 15:19:15 --> Helper loaded: url_helper
DEBUG - 2017-02-16 15:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 15:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 15:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 15:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 15:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 15:19:15 --> Final output sent to browser
DEBUG - 2017-02-16 15:19:15 --> Total execution time: 1.3329
INFO - 2017-02-16 16:46:08 --> Config Class Initialized
INFO - 2017-02-16 16:46:08 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:46:09 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:46:09 --> Utf8 Class Initialized
INFO - 2017-02-16 16:46:09 --> URI Class Initialized
DEBUG - 2017-02-16 16:46:09 --> No URI present. Default controller set.
INFO - 2017-02-16 16:46:09 --> Router Class Initialized
INFO - 2017-02-16 16:46:09 --> Output Class Initialized
INFO - 2017-02-16 16:46:09 --> Security Class Initialized
DEBUG - 2017-02-16 16:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:46:09 --> Input Class Initialized
INFO - 2017-02-16 16:46:09 --> Language Class Initialized
INFO - 2017-02-16 16:46:09 --> Loader Class Initialized
INFO - 2017-02-16 16:46:09 --> Database Driver Class Initialized
INFO - 2017-02-16 16:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:46:09 --> Controller Class Initialized
INFO - 2017-02-16 16:46:09 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:46:09 --> Final output sent to browser
DEBUG - 2017-02-16 16:46:09 --> Total execution time: 0.8694
INFO - 2017-02-16 16:46:14 --> Config Class Initialized
INFO - 2017-02-16 16:46:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:46:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:46:14 --> Utf8 Class Initialized
INFO - 2017-02-16 16:46:14 --> URI Class Initialized
INFO - 2017-02-16 16:46:14 --> Router Class Initialized
INFO - 2017-02-16 16:46:15 --> Output Class Initialized
INFO - 2017-02-16 16:46:15 --> Security Class Initialized
DEBUG - 2017-02-16 16:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:46:15 --> Input Class Initialized
INFO - 2017-02-16 16:46:15 --> Language Class Initialized
INFO - 2017-02-16 16:46:15 --> Loader Class Initialized
INFO - 2017-02-16 16:46:15 --> Database Driver Class Initialized
INFO - 2017-02-16 16:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:46:15 --> Controller Class Initialized
INFO - 2017-02-16 16:46:15 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:46:15 --> Final output sent to browser
DEBUG - 2017-02-16 16:46:15 --> Total execution time: 1.5364
INFO - 2017-02-16 16:46:51 --> Config Class Initialized
INFO - 2017-02-16 16:46:51 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:46:51 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:46:51 --> Utf8 Class Initialized
INFO - 2017-02-16 16:46:51 --> URI Class Initialized
DEBUG - 2017-02-16 16:46:51 --> No URI present. Default controller set.
INFO - 2017-02-16 16:46:51 --> Router Class Initialized
INFO - 2017-02-16 16:46:51 --> Output Class Initialized
INFO - 2017-02-16 16:46:51 --> Security Class Initialized
DEBUG - 2017-02-16 16:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:46:51 --> Input Class Initialized
INFO - 2017-02-16 16:46:51 --> Language Class Initialized
INFO - 2017-02-16 16:46:51 --> Loader Class Initialized
INFO - 2017-02-16 16:46:51 --> Database Driver Class Initialized
INFO - 2017-02-16 16:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:46:51 --> Controller Class Initialized
INFO - 2017-02-16 16:46:51 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:46:51 --> Final output sent to browser
DEBUG - 2017-02-16 16:46:51 --> Total execution time: 0.7117
INFO - 2017-02-16 16:46:59 --> Config Class Initialized
INFO - 2017-02-16 16:46:59 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:46:59 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:46:59 --> Utf8 Class Initialized
INFO - 2017-02-16 16:46:59 --> URI Class Initialized
INFO - 2017-02-16 16:46:59 --> Router Class Initialized
INFO - 2017-02-16 16:46:59 --> Output Class Initialized
INFO - 2017-02-16 16:46:59 --> Security Class Initialized
DEBUG - 2017-02-16 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:46:59 --> Input Class Initialized
INFO - 2017-02-16 16:46:59 --> Language Class Initialized
INFO - 2017-02-16 16:46:59 --> Loader Class Initialized
INFO - 2017-02-16 16:46:59 --> Database Driver Class Initialized
INFO - 2017-02-16 16:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:46:59 --> Controller Class Initialized
INFO - 2017-02-16 16:46:59 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:46:59 --> Final output sent to browser
DEBUG - 2017-02-16 16:46:59 --> Total execution time: 0.0136
INFO - 2017-02-16 16:47:00 --> Config Class Initialized
INFO - 2017-02-16 16:47:00 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:47:00 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:47:00 --> Utf8 Class Initialized
INFO - 2017-02-16 16:47:00 --> URI Class Initialized
INFO - 2017-02-16 16:47:00 --> Router Class Initialized
INFO - 2017-02-16 16:47:00 --> Output Class Initialized
INFO - 2017-02-16 16:47:00 --> Security Class Initialized
DEBUG - 2017-02-16 16:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:47:00 --> Input Class Initialized
INFO - 2017-02-16 16:47:00 --> Language Class Initialized
INFO - 2017-02-16 16:47:00 --> Loader Class Initialized
INFO - 2017-02-16 16:47:00 --> Database Driver Class Initialized
INFO - 2017-02-16 16:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:47:00 --> Controller Class Initialized
INFO - 2017-02-16 16:47:00 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:47:00 --> Final output sent to browser
DEBUG - 2017-02-16 16:47:00 --> Total execution time: 0.0652
INFO - 2017-02-16 16:47:00 --> Config Class Initialized
INFO - 2017-02-16 16:47:00 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:47:00 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:47:00 --> Utf8 Class Initialized
INFO - 2017-02-16 16:47:00 --> URI Class Initialized
INFO - 2017-02-16 16:47:00 --> Router Class Initialized
INFO - 2017-02-16 16:47:00 --> Output Class Initialized
INFO - 2017-02-16 16:47:00 --> Security Class Initialized
DEBUG - 2017-02-16 16:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:47:00 --> Input Class Initialized
INFO - 2017-02-16 16:47:00 --> Language Class Initialized
INFO - 2017-02-16 16:47:00 --> Loader Class Initialized
INFO - 2017-02-16 16:47:00 --> Database Driver Class Initialized
INFO - 2017-02-16 16:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:47:00 --> Controller Class Initialized
INFO - 2017-02-16 16:47:00 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:47:00 --> Final output sent to browser
DEBUG - 2017-02-16 16:47:00 --> Total execution time: 0.0139
INFO - 2017-02-16 16:47:46 --> Config Class Initialized
INFO - 2017-02-16 16:47:46 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:47:46 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:47:46 --> Utf8 Class Initialized
INFO - 2017-02-16 16:47:46 --> URI Class Initialized
INFO - 2017-02-16 16:47:46 --> Router Class Initialized
INFO - 2017-02-16 16:47:46 --> Output Class Initialized
INFO - 2017-02-16 16:47:46 --> Security Class Initialized
DEBUG - 2017-02-16 16:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:47:46 --> Input Class Initialized
INFO - 2017-02-16 16:47:46 --> Language Class Initialized
INFO - 2017-02-16 16:47:46 --> Loader Class Initialized
INFO - 2017-02-16 16:47:46 --> Database Driver Class Initialized
INFO - 2017-02-16 16:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:47:46 --> Controller Class Initialized
INFO - 2017-02-16 16:47:46 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:47:46 --> Config Class Initialized
INFO - 2017-02-16 16:47:46 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:47:46 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:47:46 --> Utf8 Class Initialized
INFO - 2017-02-16 16:47:46 --> URI Class Initialized
INFO - 2017-02-16 16:47:46 --> Router Class Initialized
INFO - 2017-02-16 16:47:46 --> Output Class Initialized
INFO - 2017-02-16 16:47:46 --> Security Class Initialized
DEBUG - 2017-02-16 16:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:47:46 --> Input Class Initialized
INFO - 2017-02-16 16:47:46 --> Language Class Initialized
INFO - 2017-02-16 16:47:46 --> Loader Class Initialized
INFO - 2017-02-16 16:47:46 --> Database Driver Class Initialized
INFO - 2017-02-16 16:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:47:46 --> Controller Class Initialized
INFO - 2017-02-16 16:47:47 --> Helper loaded: date_helper
DEBUG - 2017-02-16 16:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:47:47 --> Helper loaded: url_helper
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:47:47 --> Final output sent to browser
DEBUG - 2017-02-16 16:47:47 --> Total execution time: 0.2414
INFO - 2017-02-16 16:47:47 --> Config Class Initialized
INFO - 2017-02-16 16:47:47 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:47:47 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:47:47 --> Utf8 Class Initialized
INFO - 2017-02-16 16:47:47 --> URI Class Initialized
INFO - 2017-02-16 16:47:47 --> Router Class Initialized
INFO - 2017-02-16 16:47:47 --> Output Class Initialized
INFO - 2017-02-16 16:47:47 --> Security Class Initialized
DEBUG - 2017-02-16 16:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:47:47 --> Input Class Initialized
INFO - 2017-02-16 16:47:47 --> Language Class Initialized
INFO - 2017-02-16 16:47:47 --> Loader Class Initialized
INFO - 2017-02-16 16:47:47 --> Database Driver Class Initialized
INFO - 2017-02-16 16:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:47:47 --> Controller Class Initialized
INFO - 2017-02-16 16:47:47 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:47:47 --> Final output sent to browser
DEBUG - 2017-02-16 16:47:47 --> Total execution time: 0.0151
INFO - 2017-02-16 16:48:09 --> Config Class Initialized
INFO - 2017-02-16 16:48:09 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:09 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:09 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:09 --> URI Class Initialized
INFO - 2017-02-16 16:48:09 --> Router Class Initialized
INFO - 2017-02-16 16:48:09 --> Output Class Initialized
INFO - 2017-02-16 16:48:09 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:09 --> Input Class Initialized
INFO - 2017-02-16 16:48:09 --> Language Class Initialized
INFO - 2017-02-16 16:48:09 --> Loader Class Initialized
INFO - 2017-02-16 16:48:09 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:09 --> Controller Class Initialized
INFO - 2017-02-16 16:48:09 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:09 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:09 --> Total execution time: 0.6822
INFO - 2017-02-16 16:48:10 --> Config Class Initialized
INFO - 2017-02-16 16:48:10 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:10 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:11 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:11 --> URI Class Initialized
INFO - 2017-02-16 16:48:11 --> Router Class Initialized
INFO - 2017-02-16 16:48:11 --> Output Class Initialized
INFO - 2017-02-16 16:48:11 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:11 --> Input Class Initialized
INFO - 2017-02-16 16:48:11 --> Language Class Initialized
INFO - 2017-02-16 16:48:11 --> Loader Class Initialized
INFO - 2017-02-16 16:48:11 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:11 --> Controller Class Initialized
INFO - 2017-02-16 16:48:11 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:11 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:11 --> Total execution time: 0.4581
INFO - 2017-02-16 16:48:13 --> Config Class Initialized
INFO - 2017-02-16 16:48:13 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:14 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:14 --> URI Class Initialized
DEBUG - 2017-02-16 16:48:14 --> No URI present. Default controller set.
INFO - 2017-02-16 16:48:14 --> Router Class Initialized
INFO - 2017-02-16 16:48:14 --> Output Class Initialized
INFO - 2017-02-16 16:48:14 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:14 --> Input Class Initialized
INFO - 2017-02-16 16:48:14 --> Language Class Initialized
INFO - 2017-02-16 16:48:14 --> Loader Class Initialized
INFO - 2017-02-16 16:48:14 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:14 --> Controller Class Initialized
INFO - 2017-02-16 16:48:14 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:14 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:14 --> Total execution time: 0.4954
INFO - 2017-02-16 16:48:14 --> Config Class Initialized
INFO - 2017-02-16 16:48:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:14 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:14 --> URI Class Initialized
INFO - 2017-02-16 16:48:14 --> Router Class Initialized
INFO - 2017-02-16 16:48:14 --> Output Class Initialized
INFO - 2017-02-16 16:48:14 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:14 --> Input Class Initialized
INFO - 2017-02-16 16:48:14 --> Language Class Initialized
INFO - 2017-02-16 16:48:14 --> Loader Class Initialized
INFO - 2017-02-16 16:48:14 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:14 --> Controller Class Initialized
INFO - 2017-02-16 16:48:14 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:48:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:14 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:14 --> Total execution time: 0.0197
INFO - 2017-02-16 16:48:32 --> Config Class Initialized
INFO - 2017-02-16 16:48:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:32 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:32 --> URI Class Initialized
INFO - 2017-02-16 16:48:32 --> Router Class Initialized
INFO - 2017-02-16 16:48:32 --> Output Class Initialized
INFO - 2017-02-16 16:48:32 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:32 --> Input Class Initialized
INFO - 2017-02-16 16:48:32 --> Language Class Initialized
INFO - 2017-02-16 16:48:32 --> Loader Class Initialized
INFO - 2017-02-16 16:48:33 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:33 --> Controller Class Initialized
INFO - 2017-02-16 16:48:33 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:33 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:33 --> Total execution time: 0.6709
INFO - 2017-02-16 16:48:34 --> Config Class Initialized
INFO - 2017-02-16 16:48:34 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:34 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:34 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:34 --> URI Class Initialized
INFO - 2017-02-16 16:48:34 --> Router Class Initialized
INFO - 2017-02-16 16:48:34 --> Output Class Initialized
INFO - 2017-02-16 16:48:34 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:34 --> Input Class Initialized
INFO - 2017-02-16 16:48:34 --> Language Class Initialized
INFO - 2017-02-16 16:48:34 --> Loader Class Initialized
INFO - 2017-02-16 16:48:34 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:34 --> Controller Class Initialized
INFO - 2017-02-16 16:48:34 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:35 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:35 --> Total execution time: 0.4236
INFO - 2017-02-16 16:48:44 --> Config Class Initialized
INFO - 2017-02-16 16:48:44 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:45 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:45 --> URI Class Initialized
INFO - 2017-02-16 16:48:45 --> Router Class Initialized
INFO - 2017-02-16 16:48:45 --> Output Class Initialized
INFO - 2017-02-16 16:48:45 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:45 --> Input Class Initialized
INFO - 2017-02-16 16:48:45 --> Language Class Initialized
INFO - 2017-02-16 16:48:45 --> Loader Class Initialized
INFO - 2017-02-16 16:48:45 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:45 --> Controller Class Initialized
INFO - 2017-02-16 16:48:45 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:45 --> Config Class Initialized
INFO - 2017-02-16 16:48:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:45 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:45 --> URI Class Initialized
INFO - 2017-02-16 16:48:45 --> Router Class Initialized
INFO - 2017-02-16 16:48:45 --> Output Class Initialized
INFO - 2017-02-16 16:48:45 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:45 --> Input Class Initialized
INFO - 2017-02-16 16:48:45 --> Language Class Initialized
INFO - 2017-02-16 16:48:45 --> Loader Class Initialized
INFO - 2017-02-16 16:48:46 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:46 --> Controller Class Initialized
INFO - 2017-02-16 16:48:46 --> Helper loaded: date_helper
DEBUG - 2017-02-16 16:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:46 --> Helper loaded: url_helper
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:46 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:46 --> Total execution time: 0.5116
INFO - 2017-02-16 16:48:46 --> Config Class Initialized
INFO - 2017-02-16 16:48:46 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:48:46 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:48:46 --> Utf8 Class Initialized
INFO - 2017-02-16 16:48:46 --> URI Class Initialized
INFO - 2017-02-16 16:48:46 --> Router Class Initialized
INFO - 2017-02-16 16:48:46 --> Output Class Initialized
INFO - 2017-02-16 16:48:46 --> Security Class Initialized
DEBUG - 2017-02-16 16:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:48:46 --> Input Class Initialized
INFO - 2017-02-16 16:48:46 --> Language Class Initialized
INFO - 2017-02-16 16:48:46 --> Loader Class Initialized
INFO - 2017-02-16 16:48:46 --> Database Driver Class Initialized
INFO - 2017-02-16 16:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:48:46 --> Controller Class Initialized
INFO - 2017-02-16 16:48:46 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:48:46 --> Final output sent to browser
DEBUG - 2017-02-16 16:48:46 --> Total execution time: 0.1503
INFO - 2017-02-16 16:49:00 --> Config Class Initialized
INFO - 2017-02-16 16:49:01 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:49:01 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:49:01 --> Utf8 Class Initialized
INFO - 2017-02-16 16:49:01 --> URI Class Initialized
INFO - 2017-02-16 16:49:01 --> Router Class Initialized
INFO - 2017-02-16 16:49:01 --> Output Class Initialized
INFO - 2017-02-16 16:49:01 --> Security Class Initialized
DEBUG - 2017-02-16 16:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:49:01 --> Input Class Initialized
INFO - 2017-02-16 16:49:01 --> Language Class Initialized
INFO - 2017-02-16 16:49:01 --> Loader Class Initialized
INFO - 2017-02-16 16:49:01 --> Database Driver Class Initialized
INFO - 2017-02-16 16:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:49:01 --> Controller Class Initialized
INFO - 2017-02-16 16:49:01 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-16 16:49:16 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-16 16:49:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-16 16:49:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-16 16:49:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:49:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:49:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:49:17 --> Final output sent to browser
DEBUG - 2017-02-16 16:49:17 --> Total execution time: 16.5629
INFO - 2017-02-16 16:49:19 --> Config Class Initialized
INFO - 2017-02-16 16:49:19 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:49:19 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:49:19 --> Utf8 Class Initialized
INFO - 2017-02-16 16:49:19 --> URI Class Initialized
INFO - 2017-02-16 16:49:20 --> Router Class Initialized
INFO - 2017-02-16 16:49:20 --> Output Class Initialized
INFO - 2017-02-16 16:49:20 --> Security Class Initialized
DEBUG - 2017-02-16 16:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:49:20 --> Input Class Initialized
INFO - 2017-02-16 16:49:20 --> Language Class Initialized
INFO - 2017-02-16 16:49:20 --> Loader Class Initialized
INFO - 2017-02-16 16:49:20 --> Database Driver Class Initialized
INFO - 2017-02-16 16:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:49:20 --> Controller Class Initialized
INFO - 2017-02-16 16:49:20 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:49:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:49:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:49:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:49:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:49:20 --> Final output sent to browser
DEBUG - 2017-02-16 16:49:20 --> Total execution time: 0.2018
INFO - 2017-02-16 16:50:01 --> Config Class Initialized
INFO - 2017-02-16 16:50:01 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:01 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:01 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:01 --> URI Class Initialized
INFO - 2017-02-16 16:50:01 --> Router Class Initialized
INFO - 2017-02-16 16:50:01 --> Output Class Initialized
INFO - 2017-02-16 16:50:01 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:01 --> Input Class Initialized
INFO - 2017-02-16 16:50:01 --> Language Class Initialized
INFO - 2017-02-16 16:50:01 --> Loader Class Initialized
INFO - 2017-02-16 16:50:01 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:01 --> Controller Class Initialized
INFO - 2017-02-16 16:50:01 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-16 16:50:02 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 16:50:02 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kristiina Setala')
INFO - 2017-02-16 16:50:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 16:50:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 16:50:02 --> Config Class Initialized
INFO - 2017-02-16 16:50:02 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:02 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:02 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:02 --> URI Class Initialized
INFO - 2017-02-16 16:50:02 --> Router Class Initialized
INFO - 2017-02-16 16:50:02 --> Output Class Initialized
INFO - 2017-02-16 16:50:02 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:02 --> Input Class Initialized
INFO - 2017-02-16 16:50:02 --> Language Class Initialized
INFO - 2017-02-16 16:50:02 --> Loader Class Initialized
INFO - 2017-02-16 16:50:02 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:02 --> Controller Class Initialized
INFO - 2017-02-16 16:50:02 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:50:02 --> Final output sent to browser
DEBUG - 2017-02-16 16:50:02 --> Total execution time: 0.0156
INFO - 2017-02-16 16:50:04 --> Config Class Initialized
INFO - 2017-02-16 16:50:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:04 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:04 --> URI Class Initialized
INFO - 2017-02-16 16:50:04 --> Router Class Initialized
INFO - 2017-02-16 16:50:04 --> Output Class Initialized
INFO - 2017-02-16 16:50:04 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:04 --> Input Class Initialized
INFO - 2017-02-16 16:50:04 --> Language Class Initialized
INFO - 2017-02-16 16:50:04 --> Loader Class Initialized
INFO - 2017-02-16 16:50:04 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:04 --> Controller Class Initialized
INFO - 2017-02-16 16:50:04 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-16 16:50:04 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 16:50:04 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kristiina Setala')
INFO - 2017-02-16 16:50:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 16:50:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 16:50:04 --> Config Class Initialized
INFO - 2017-02-16 16:50:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:04 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:04 --> URI Class Initialized
INFO - 2017-02-16 16:50:04 --> Router Class Initialized
INFO - 2017-02-16 16:50:04 --> Output Class Initialized
INFO - 2017-02-16 16:50:04 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:04 --> Input Class Initialized
INFO - 2017-02-16 16:50:04 --> Language Class Initialized
INFO - 2017-02-16 16:50:04 --> Loader Class Initialized
INFO - 2017-02-16 16:50:04 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:04 --> Controller Class Initialized
INFO - 2017-02-16 16:50:04 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:50:04 --> Final output sent to browser
DEBUG - 2017-02-16 16:50:04 --> Total execution time: 0.0157
INFO - 2017-02-16 16:50:08 --> Config Class Initialized
INFO - 2017-02-16 16:50:08 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:08 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:08 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:08 --> URI Class Initialized
INFO - 2017-02-16 16:50:08 --> Router Class Initialized
INFO - 2017-02-16 16:50:08 --> Output Class Initialized
INFO - 2017-02-16 16:50:08 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:08 --> Input Class Initialized
INFO - 2017-02-16 16:50:08 --> Language Class Initialized
INFO - 2017-02-16 16:50:08 --> Loader Class Initialized
INFO - 2017-02-16 16:50:08 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:08 --> Controller Class Initialized
INFO - 2017-02-16 16:50:08 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:50:17 --> Config Class Initialized
INFO - 2017-02-16 16:50:17 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:17 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:17 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:17 --> URI Class Initialized
INFO - 2017-02-16 16:50:17 --> Router Class Initialized
INFO - 2017-02-16 16:50:17 --> Output Class Initialized
INFO - 2017-02-16 16:50:17 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:18 --> Input Class Initialized
INFO - 2017-02-16 16:50:18 --> Language Class Initialized
INFO - 2017-02-16 16:50:18 --> Loader Class Initialized
INFO - 2017-02-16 16:50:18 --> Database Driver Class Initialized
ERROR - 2017-02-16 16:50:18 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 16:50:18 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kristiina Setala')
INFO - 2017-02-16 16:50:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 16:50:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 16:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:18 --> Controller Class Initialized
INFO - 2017-02-16 16:50:19 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-16 16:50:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 16:50:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kristiina Setala')
INFO - 2017-02-16 16:50:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 16:50:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 16:50:19 --> Config Class Initialized
INFO - 2017-02-16 16:50:19 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:19 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:19 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:19 --> URI Class Initialized
INFO - 2017-02-16 16:50:19 --> Router Class Initialized
INFO - 2017-02-16 16:50:19 --> Output Class Initialized
INFO - 2017-02-16 16:50:19 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:19 --> Input Class Initialized
INFO - 2017-02-16 16:50:19 --> Language Class Initialized
INFO - 2017-02-16 16:50:19 --> Loader Class Initialized
INFO - 2017-02-16 16:50:19 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:19 --> Controller Class Initialized
INFO - 2017-02-16 16:50:19 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:50:19 --> Final output sent to browser
DEBUG - 2017-02-16 16:50:19 --> Total execution time: 0.3607
INFO - 2017-02-16 16:50:23 --> Config Class Initialized
INFO - 2017-02-16 16:50:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:23 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:23 --> URI Class Initialized
INFO - 2017-02-16 16:50:24 --> Router Class Initialized
INFO - 2017-02-16 16:50:24 --> Output Class Initialized
INFO - 2017-02-16 16:50:24 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:24 --> Input Class Initialized
INFO - 2017-02-16 16:50:24 --> Language Class Initialized
INFO - 2017-02-16 16:50:24 --> Loader Class Initialized
INFO - 2017-02-16 16:50:24 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:24 --> Controller Class Initialized
INFO - 2017-02-16 16:50:24 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-16 16:50:29 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 16:50:29 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kristiina Setala')
INFO - 2017-02-16 16:50:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 16:50:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 16:50:31 --> Config Class Initialized
INFO - 2017-02-16 16:50:31 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:50:31 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:50:31 --> Utf8 Class Initialized
INFO - 2017-02-16 16:50:31 --> URI Class Initialized
INFO - 2017-02-16 16:50:31 --> Router Class Initialized
INFO - 2017-02-16 16:50:31 --> Output Class Initialized
INFO - 2017-02-16 16:50:31 --> Security Class Initialized
DEBUG - 2017-02-16 16:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:50:31 --> Input Class Initialized
INFO - 2017-02-16 16:50:31 --> Language Class Initialized
INFO - 2017-02-16 16:50:31 --> Loader Class Initialized
INFO - 2017-02-16 16:50:31 --> Database Driver Class Initialized
INFO - 2017-02-16 16:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:50:31 --> Controller Class Initialized
INFO - 2017-02-16 16:50:31 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:50:31 --> Final output sent to browser
DEBUG - 2017-02-16 16:50:31 --> Total execution time: 0.1735
INFO - 2017-02-16 16:51:04 --> Config Class Initialized
INFO - 2017-02-16 16:51:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:51:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:51:04 --> Utf8 Class Initialized
INFO - 2017-02-16 16:51:04 --> URI Class Initialized
DEBUG - 2017-02-16 16:51:04 --> No URI present. Default controller set.
INFO - 2017-02-16 16:51:04 --> Router Class Initialized
INFO - 2017-02-16 16:51:04 --> Output Class Initialized
INFO - 2017-02-16 16:51:04 --> Security Class Initialized
DEBUG - 2017-02-16 16:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:51:04 --> Input Class Initialized
INFO - 2017-02-16 16:51:04 --> Language Class Initialized
INFO - 2017-02-16 16:51:04 --> Loader Class Initialized
INFO - 2017-02-16 16:51:04 --> Database Driver Class Initialized
INFO - 2017-02-16 16:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:51:04 --> Controller Class Initialized
INFO - 2017-02-16 16:51:04 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:51:04 --> Final output sent to browser
DEBUG - 2017-02-16 16:51:04 --> Total execution time: 0.0294
INFO - 2017-02-16 16:51:06 --> Config Class Initialized
INFO - 2017-02-16 16:51:06 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:51:06 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:51:06 --> Utf8 Class Initialized
INFO - 2017-02-16 16:51:06 --> URI Class Initialized
INFO - 2017-02-16 16:51:06 --> Router Class Initialized
INFO - 2017-02-16 16:51:06 --> Output Class Initialized
INFO - 2017-02-16 16:51:06 --> Security Class Initialized
DEBUG - 2017-02-16 16:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:51:06 --> Input Class Initialized
INFO - 2017-02-16 16:51:06 --> Language Class Initialized
INFO - 2017-02-16 16:51:06 --> Loader Class Initialized
INFO - 2017-02-16 16:51:06 --> Database Driver Class Initialized
INFO - 2017-02-16 16:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:51:06 --> Controller Class Initialized
INFO - 2017-02-16 16:51:06 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:51:06 --> Final output sent to browser
DEBUG - 2017-02-16 16:51:06 --> Total execution time: 0.1858
INFO - 2017-02-16 16:52:31 --> Config Class Initialized
INFO - 2017-02-16 16:52:31 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:52:31 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:52:31 --> Utf8 Class Initialized
INFO - 2017-02-16 16:52:31 --> URI Class Initialized
INFO - 2017-02-16 16:52:31 --> Router Class Initialized
INFO - 2017-02-16 16:52:31 --> Output Class Initialized
INFO - 2017-02-16 16:52:31 --> Security Class Initialized
DEBUG - 2017-02-16 16:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:52:31 --> Input Class Initialized
INFO - 2017-02-16 16:52:31 --> Language Class Initialized
INFO - 2017-02-16 16:52:31 --> Loader Class Initialized
INFO - 2017-02-16 16:52:31 --> Database Driver Class Initialized
INFO - 2017-02-16 16:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:52:32 --> Controller Class Initialized
INFO - 2017-02-16 16:52:32 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:52:32 --> Final output sent to browser
DEBUG - 2017-02-16 16:52:32 --> Total execution time: 0.4531
INFO - 2017-02-16 16:52:32 --> Config Class Initialized
INFO - 2017-02-16 16:52:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:52:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:52:32 --> Utf8 Class Initialized
INFO - 2017-02-16 16:52:32 --> URI Class Initialized
INFO - 2017-02-16 16:52:32 --> Router Class Initialized
INFO - 2017-02-16 16:52:32 --> Output Class Initialized
INFO - 2017-02-16 16:52:32 --> Security Class Initialized
DEBUG - 2017-02-16 16:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:52:32 --> Input Class Initialized
INFO - 2017-02-16 16:52:32 --> Language Class Initialized
INFO - 2017-02-16 16:52:32 --> Loader Class Initialized
INFO - 2017-02-16 16:52:32 --> Database Driver Class Initialized
INFO - 2017-02-16 16:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:52:32 --> Controller Class Initialized
INFO - 2017-02-16 16:52:32 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:52:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:52:32 --> Final output sent to browser
DEBUG - 2017-02-16 16:52:32 --> Total execution time: 0.0134
INFO - 2017-02-16 16:53:34 --> Config Class Initialized
INFO - 2017-02-16 16:53:34 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:53:34 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:53:34 --> Utf8 Class Initialized
INFO - 2017-02-16 16:53:34 --> URI Class Initialized
INFO - 2017-02-16 16:53:34 --> Router Class Initialized
INFO - 2017-02-16 16:53:34 --> Output Class Initialized
INFO - 2017-02-16 16:53:34 --> Security Class Initialized
DEBUG - 2017-02-16 16:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:53:34 --> Input Class Initialized
INFO - 2017-02-16 16:53:34 --> Language Class Initialized
INFO - 2017-02-16 16:53:34 --> Loader Class Initialized
INFO - 2017-02-16 16:53:34 --> Database Driver Class Initialized
INFO - 2017-02-16 16:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:53:34 --> Controller Class Initialized
INFO - 2017-02-16 16:53:34 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:53:34 --> Config Class Initialized
INFO - 2017-02-16 16:53:34 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:53:34 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:53:34 --> Utf8 Class Initialized
INFO - 2017-02-16 16:53:34 --> URI Class Initialized
INFO - 2017-02-16 16:53:34 --> Router Class Initialized
INFO - 2017-02-16 16:53:34 --> Output Class Initialized
INFO - 2017-02-16 16:53:34 --> Security Class Initialized
DEBUG - 2017-02-16 16:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:53:34 --> Input Class Initialized
INFO - 2017-02-16 16:53:34 --> Language Class Initialized
INFO - 2017-02-16 16:53:34 --> Loader Class Initialized
INFO - 2017-02-16 16:53:34 --> Database Driver Class Initialized
INFO - 2017-02-16 16:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:53:34 --> Controller Class Initialized
INFO - 2017-02-16 16:53:34 --> Helper loaded: date_helper
DEBUG - 2017-02-16 16:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:53:34 --> Helper loaded: url_helper
INFO - 2017-02-16 16:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 16:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 16:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 16:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:53:34 --> Final output sent to browser
DEBUG - 2017-02-16 16:53:34 --> Total execution time: 0.0862
INFO - 2017-02-16 16:53:35 --> Config Class Initialized
INFO - 2017-02-16 16:53:35 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:53:35 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:53:35 --> Utf8 Class Initialized
INFO - 2017-02-16 16:53:35 --> URI Class Initialized
INFO - 2017-02-16 16:53:35 --> Router Class Initialized
INFO - 2017-02-16 16:53:35 --> Output Class Initialized
INFO - 2017-02-16 16:53:35 --> Security Class Initialized
DEBUG - 2017-02-16 16:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:53:35 --> Input Class Initialized
INFO - 2017-02-16 16:53:35 --> Language Class Initialized
INFO - 2017-02-16 16:53:35 --> Loader Class Initialized
INFO - 2017-02-16 16:53:35 --> Database Driver Class Initialized
INFO - 2017-02-16 16:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:53:35 --> Controller Class Initialized
INFO - 2017-02-16 16:53:35 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:53:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:53:35 --> Final output sent to browser
DEBUG - 2017-02-16 16:53:35 --> Total execution time: 0.0154
INFO - 2017-02-16 16:53:45 --> Config Class Initialized
INFO - 2017-02-16 16:53:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:53:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:53:45 --> Utf8 Class Initialized
INFO - 2017-02-16 16:53:45 --> URI Class Initialized
DEBUG - 2017-02-16 16:53:45 --> No URI present. Default controller set.
INFO - 2017-02-16 16:53:45 --> Router Class Initialized
INFO - 2017-02-16 16:53:45 --> Output Class Initialized
INFO - 2017-02-16 16:53:45 --> Security Class Initialized
DEBUG - 2017-02-16 16:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:53:45 --> Input Class Initialized
INFO - 2017-02-16 16:53:45 --> Language Class Initialized
INFO - 2017-02-16 16:53:45 --> Loader Class Initialized
INFO - 2017-02-16 16:53:45 --> Database Driver Class Initialized
INFO - 2017-02-16 16:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:53:45 --> Controller Class Initialized
INFO - 2017-02-16 16:53:45 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:53:45 --> Final output sent to browser
DEBUG - 2017-02-16 16:53:45 --> Total execution time: 0.0142
INFO - 2017-02-16 16:53:45 --> Config Class Initialized
INFO - 2017-02-16 16:53:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:53:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:53:45 --> Utf8 Class Initialized
INFO - 2017-02-16 16:53:45 --> URI Class Initialized
INFO - 2017-02-16 16:53:45 --> Router Class Initialized
INFO - 2017-02-16 16:53:45 --> Output Class Initialized
INFO - 2017-02-16 16:53:45 --> Security Class Initialized
DEBUG - 2017-02-16 16:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:53:45 --> Input Class Initialized
INFO - 2017-02-16 16:53:45 --> Language Class Initialized
INFO - 2017-02-16 16:53:45 --> Loader Class Initialized
INFO - 2017-02-16 16:53:45 --> Database Driver Class Initialized
INFO - 2017-02-16 16:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:53:45 --> Controller Class Initialized
INFO - 2017-02-16 16:53:45 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:53:45 --> Final output sent to browser
DEBUG - 2017-02-16 16:53:45 --> Total execution time: 0.0141
INFO - 2017-02-16 16:53:47 --> Config Class Initialized
INFO - 2017-02-16 16:53:47 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:53:47 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:53:47 --> Utf8 Class Initialized
INFO - 2017-02-16 16:53:47 --> URI Class Initialized
DEBUG - 2017-02-16 16:53:47 --> No URI present. Default controller set.
INFO - 2017-02-16 16:53:47 --> Router Class Initialized
INFO - 2017-02-16 16:53:47 --> Output Class Initialized
INFO - 2017-02-16 16:53:47 --> Security Class Initialized
DEBUG - 2017-02-16 16:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:53:47 --> Input Class Initialized
INFO - 2017-02-16 16:53:47 --> Language Class Initialized
INFO - 2017-02-16 16:53:47 --> Loader Class Initialized
INFO - 2017-02-16 16:53:47 --> Database Driver Class Initialized
INFO - 2017-02-16 16:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:53:47 --> Controller Class Initialized
INFO - 2017-02-16 16:53:47 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:53:47 --> Final output sent to browser
DEBUG - 2017-02-16 16:53:47 --> Total execution time: 0.1570
INFO - 2017-02-16 16:53:47 --> Config Class Initialized
INFO - 2017-02-16 16:53:47 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:53:47 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:53:47 --> Utf8 Class Initialized
INFO - 2017-02-16 16:53:47 --> URI Class Initialized
INFO - 2017-02-16 16:53:47 --> Router Class Initialized
INFO - 2017-02-16 16:53:47 --> Output Class Initialized
INFO - 2017-02-16 16:53:47 --> Security Class Initialized
DEBUG - 2017-02-16 16:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:53:47 --> Input Class Initialized
INFO - 2017-02-16 16:53:47 --> Language Class Initialized
INFO - 2017-02-16 16:53:47 --> Loader Class Initialized
INFO - 2017-02-16 16:53:47 --> Database Driver Class Initialized
INFO - 2017-02-16 16:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:53:47 --> Controller Class Initialized
INFO - 2017-02-16 16:53:47 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:53:47 --> Final output sent to browser
DEBUG - 2017-02-16 16:53:47 --> Total execution time: 0.0151
INFO - 2017-02-16 16:54:07 --> Config Class Initialized
INFO - 2017-02-16 16:54:07 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:07 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:07 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:07 --> URI Class Initialized
INFO - 2017-02-16 16:54:07 --> Router Class Initialized
INFO - 2017-02-16 16:54:07 --> Output Class Initialized
INFO - 2017-02-16 16:54:07 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:07 --> Input Class Initialized
INFO - 2017-02-16 16:54:07 --> Language Class Initialized
INFO - 2017-02-16 16:54:07 --> Loader Class Initialized
INFO - 2017-02-16 16:54:07 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:07 --> Controller Class Initialized
INFO - 2017-02-16 16:54:07 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:08 --> Config Class Initialized
INFO - 2017-02-16 16:54:08 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:08 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:08 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:08 --> URI Class Initialized
INFO - 2017-02-16 16:54:08 --> Router Class Initialized
INFO - 2017-02-16 16:54:08 --> Output Class Initialized
INFO - 2017-02-16 16:54:08 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:08 --> Input Class Initialized
INFO - 2017-02-16 16:54:08 --> Language Class Initialized
INFO - 2017-02-16 16:54:08 --> Loader Class Initialized
INFO - 2017-02-16 16:54:08 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:08 --> Controller Class Initialized
INFO - 2017-02-16 16:54:08 --> Helper loaded: date_helper
DEBUG - 2017-02-16 16:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:08 --> Helper loaded: url_helper
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:54:08 --> Final output sent to browser
DEBUG - 2017-02-16 16:54:08 --> Total execution time: 0.0140
INFO - 2017-02-16 16:54:08 --> Config Class Initialized
INFO - 2017-02-16 16:54:08 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:08 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:08 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:08 --> URI Class Initialized
INFO - 2017-02-16 16:54:08 --> Router Class Initialized
INFO - 2017-02-16 16:54:08 --> Output Class Initialized
INFO - 2017-02-16 16:54:08 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:08 --> Input Class Initialized
INFO - 2017-02-16 16:54:08 --> Language Class Initialized
INFO - 2017-02-16 16:54:08 --> Loader Class Initialized
INFO - 2017-02-16 16:54:08 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:08 --> Controller Class Initialized
INFO - 2017-02-16 16:54:08 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:54:08 --> Final output sent to browser
DEBUG - 2017-02-16 16:54:08 --> Total execution time: 0.0138
INFO - 2017-02-16 16:54:23 --> Config Class Initialized
INFO - 2017-02-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:23 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:23 --> URI Class Initialized
DEBUG - 2017-02-16 16:54:23 --> No URI present. Default controller set.
INFO - 2017-02-16 16:54:23 --> Router Class Initialized
INFO - 2017-02-16 16:54:23 --> Output Class Initialized
INFO - 2017-02-16 16:54:23 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:23 --> Input Class Initialized
INFO - 2017-02-16 16:54:23 --> Language Class Initialized
INFO - 2017-02-16 16:54:23 --> Loader Class Initialized
INFO - 2017-02-16 16:54:23 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:23 --> Controller Class Initialized
INFO - 2017-02-16 16:54:23 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:54:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:54:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:54:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:54:23 --> Final output sent to browser
DEBUG - 2017-02-16 16:54:23 --> Total execution time: 0.0137
INFO - 2017-02-16 16:54:24 --> Config Class Initialized
INFO - 2017-02-16 16:54:24 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:24 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:24 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:24 --> URI Class Initialized
INFO - 2017-02-16 16:54:24 --> Router Class Initialized
INFO - 2017-02-16 16:54:24 --> Output Class Initialized
INFO - 2017-02-16 16:54:24 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:24 --> Input Class Initialized
INFO - 2017-02-16 16:54:24 --> Language Class Initialized
INFO - 2017-02-16 16:54:24 --> Loader Class Initialized
INFO - 2017-02-16 16:54:24 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:24 --> Controller Class Initialized
INFO - 2017-02-16 16:54:24 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:54:24 --> Final output sent to browser
DEBUG - 2017-02-16 16:54:24 --> Total execution time: 0.0163
INFO - 2017-02-16 16:54:43 --> Config Class Initialized
INFO - 2017-02-16 16:54:43 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:43 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:43 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:43 --> URI Class Initialized
INFO - 2017-02-16 16:54:43 --> Router Class Initialized
INFO - 2017-02-16 16:54:43 --> Output Class Initialized
INFO - 2017-02-16 16:54:43 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:43 --> Input Class Initialized
INFO - 2017-02-16 16:54:43 --> Language Class Initialized
INFO - 2017-02-16 16:54:43 --> Loader Class Initialized
INFO - 2017-02-16 16:54:43 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:43 --> Controller Class Initialized
INFO - 2017-02-16 16:54:43 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-16 16:54:44 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 16:54:44 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Kristiina Setala')
INFO - 2017-02-16 16:54:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 16:54:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 16:54:44 --> Config Class Initialized
INFO - 2017-02-16 16:54:44 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:44 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:44 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:44 --> URI Class Initialized
INFO - 2017-02-16 16:54:44 --> Router Class Initialized
INFO - 2017-02-16 16:54:44 --> Output Class Initialized
INFO - 2017-02-16 16:54:44 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:44 --> Input Class Initialized
INFO - 2017-02-16 16:54:44 --> Language Class Initialized
INFO - 2017-02-16 16:54:44 --> Loader Class Initialized
INFO - 2017-02-16 16:54:44 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:44 --> Controller Class Initialized
INFO - 2017-02-16 16:54:44 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:54:44 --> Final output sent to browser
DEBUG - 2017-02-16 16:54:44 --> Total execution time: 0.0155
INFO - 2017-02-16 16:54:48 --> Config Class Initialized
INFO - 2017-02-16 16:54:48 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:48 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:48 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:48 --> URI Class Initialized
DEBUG - 2017-02-16 16:54:48 --> No URI present. Default controller set.
INFO - 2017-02-16 16:54:48 --> Router Class Initialized
INFO - 2017-02-16 16:54:48 --> Output Class Initialized
INFO - 2017-02-16 16:54:48 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:48 --> Input Class Initialized
INFO - 2017-02-16 16:54:48 --> Language Class Initialized
INFO - 2017-02-16 16:54:48 --> Loader Class Initialized
INFO - 2017-02-16 16:54:48 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:48 --> Controller Class Initialized
INFO - 2017-02-16 16:54:48 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:54:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:54:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:54:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:54:48 --> Final output sent to browser
DEBUG - 2017-02-16 16:54:48 --> Total execution time: 0.0173
INFO - 2017-02-16 16:54:49 --> Config Class Initialized
INFO - 2017-02-16 16:54:49 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:54:49 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:54:49 --> Utf8 Class Initialized
INFO - 2017-02-16 16:54:49 --> URI Class Initialized
INFO - 2017-02-16 16:54:49 --> Router Class Initialized
INFO - 2017-02-16 16:54:49 --> Output Class Initialized
INFO - 2017-02-16 16:54:49 --> Security Class Initialized
DEBUG - 2017-02-16 16:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:54:49 --> Input Class Initialized
INFO - 2017-02-16 16:54:49 --> Language Class Initialized
INFO - 2017-02-16 16:54:49 --> Loader Class Initialized
INFO - 2017-02-16 16:54:49 --> Database Driver Class Initialized
INFO - 2017-02-16 16:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:54:49 --> Controller Class Initialized
INFO - 2017-02-16 16:54:49 --> Helper loaded: url_helper
DEBUG - 2017-02-16 16:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 16:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 16:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 16:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 16:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 16:54:49 --> Final output sent to browser
DEBUG - 2017-02-16 16:54:49 --> Total execution time: 0.0280
INFO - 2017-02-16 18:49:50 --> Config Class Initialized
INFO - 2017-02-16 18:49:50 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:49:50 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:49:50 --> Utf8 Class Initialized
INFO - 2017-02-16 18:49:50 --> URI Class Initialized
DEBUG - 2017-02-16 18:49:50 --> No URI present. Default controller set.
INFO - 2017-02-16 18:49:50 --> Router Class Initialized
INFO - 2017-02-16 18:49:51 --> Output Class Initialized
INFO - 2017-02-16 18:49:51 --> Security Class Initialized
DEBUG - 2017-02-16 18:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:49:51 --> Input Class Initialized
INFO - 2017-02-16 18:49:51 --> Language Class Initialized
INFO - 2017-02-16 18:49:51 --> Loader Class Initialized
INFO - 2017-02-16 18:49:51 --> Database Driver Class Initialized
INFO - 2017-02-16 18:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:49:52 --> Controller Class Initialized
INFO - 2017-02-16 18:49:52 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:49:52 --> Final output sent to browser
DEBUG - 2017-02-16 18:49:52 --> Total execution time: 1.9085
INFO - 2017-02-16 18:50:40 --> Config Class Initialized
INFO - 2017-02-16 18:50:40 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:50:40 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:50:40 --> Utf8 Class Initialized
INFO - 2017-02-16 18:50:40 --> URI Class Initialized
INFO - 2017-02-16 18:50:40 --> Router Class Initialized
INFO - 2017-02-16 18:50:40 --> Output Class Initialized
INFO - 2017-02-16 18:50:40 --> Security Class Initialized
DEBUG - 2017-02-16 18:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:50:40 --> Input Class Initialized
INFO - 2017-02-16 18:50:40 --> Language Class Initialized
INFO - 2017-02-16 18:50:40 --> Loader Class Initialized
INFO - 2017-02-16 18:50:40 --> Database Driver Class Initialized
INFO - 2017-02-16 18:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:50:40 --> Controller Class Initialized
INFO - 2017-02-16 18:50:40 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:50:40 --> Final output sent to browser
DEBUG - 2017-02-16 18:50:40 --> Total execution time: 0.0134
INFO - 2017-02-16 18:51:12 --> Config Class Initialized
INFO - 2017-02-16 18:51:12 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:51:12 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:51:12 --> Utf8 Class Initialized
INFO - 2017-02-16 18:51:12 --> URI Class Initialized
DEBUG - 2017-02-16 18:51:12 --> No URI present. Default controller set.
INFO - 2017-02-16 18:51:12 --> Router Class Initialized
INFO - 2017-02-16 18:51:12 --> Output Class Initialized
INFO - 2017-02-16 18:51:12 --> Security Class Initialized
DEBUG - 2017-02-16 18:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:51:12 --> Input Class Initialized
INFO - 2017-02-16 18:51:12 --> Language Class Initialized
INFO - 2017-02-16 18:51:12 --> Loader Class Initialized
INFO - 2017-02-16 18:51:12 --> Database Driver Class Initialized
INFO - 2017-02-16 18:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:51:12 --> Controller Class Initialized
INFO - 2017-02-16 18:51:12 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:51:12 --> Final output sent to browser
DEBUG - 2017-02-16 18:51:12 --> Total execution time: 0.0140
INFO - 2017-02-16 18:51:24 --> Config Class Initialized
INFO - 2017-02-16 18:51:24 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:51:24 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:51:24 --> Utf8 Class Initialized
INFO - 2017-02-16 18:51:24 --> URI Class Initialized
DEBUG - 2017-02-16 18:51:24 --> No URI present. Default controller set.
INFO - 2017-02-16 18:51:24 --> Router Class Initialized
INFO - 2017-02-16 18:51:24 --> Output Class Initialized
INFO - 2017-02-16 18:51:24 --> Security Class Initialized
DEBUG - 2017-02-16 18:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:51:24 --> Input Class Initialized
INFO - 2017-02-16 18:51:24 --> Language Class Initialized
INFO - 2017-02-16 18:51:24 --> Loader Class Initialized
INFO - 2017-02-16 18:51:24 --> Database Driver Class Initialized
INFO - 2017-02-16 18:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:51:24 --> Controller Class Initialized
INFO - 2017-02-16 18:51:24 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:51:24 --> Final output sent to browser
DEBUG - 2017-02-16 18:51:24 --> Total execution time: 0.0135
INFO - 2017-02-16 18:51:25 --> Config Class Initialized
INFO - 2017-02-16 18:51:25 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:51:25 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:51:25 --> Utf8 Class Initialized
INFO - 2017-02-16 18:51:25 --> URI Class Initialized
INFO - 2017-02-16 18:51:25 --> Router Class Initialized
INFO - 2017-02-16 18:51:25 --> Output Class Initialized
INFO - 2017-02-16 18:51:25 --> Security Class Initialized
DEBUG - 2017-02-16 18:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:51:25 --> Input Class Initialized
INFO - 2017-02-16 18:51:25 --> Language Class Initialized
INFO - 2017-02-16 18:51:25 --> Loader Class Initialized
INFO - 2017-02-16 18:51:25 --> Database Driver Class Initialized
INFO - 2017-02-16 18:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:51:25 --> Controller Class Initialized
INFO - 2017-02-16 18:51:25 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:51:25 --> Final output sent to browser
DEBUG - 2017-02-16 18:51:25 --> Total execution time: 0.0132
INFO - 2017-02-16 18:51:32 --> Config Class Initialized
INFO - 2017-02-16 18:51:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:51:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:51:32 --> Utf8 Class Initialized
INFO - 2017-02-16 18:51:32 --> URI Class Initialized
INFO - 2017-02-16 18:51:32 --> Router Class Initialized
INFO - 2017-02-16 18:51:32 --> Output Class Initialized
INFO - 2017-02-16 18:51:32 --> Security Class Initialized
DEBUG - 2017-02-16 18:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:51:32 --> Input Class Initialized
INFO - 2017-02-16 18:51:32 --> Language Class Initialized
INFO - 2017-02-16 18:51:32 --> Loader Class Initialized
INFO - 2017-02-16 18:51:32 --> Database Driver Class Initialized
INFO - 2017-02-16 18:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:51:32 --> Controller Class Initialized
INFO - 2017-02-16 18:51:32 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:51:32 --> Final output sent to browser
DEBUG - 2017-02-16 18:51:32 --> Total execution time: 0.0133
INFO - 2017-02-16 18:52:46 --> Config Class Initialized
INFO - 2017-02-16 18:52:46 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:52:46 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:52:46 --> Utf8 Class Initialized
INFO - 2017-02-16 18:52:46 --> URI Class Initialized
DEBUG - 2017-02-16 18:52:46 --> No URI present. Default controller set.
INFO - 2017-02-16 18:52:46 --> Router Class Initialized
INFO - 2017-02-16 18:52:46 --> Output Class Initialized
INFO - 2017-02-16 18:52:46 --> Security Class Initialized
DEBUG - 2017-02-16 18:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:52:46 --> Input Class Initialized
INFO - 2017-02-16 18:52:46 --> Language Class Initialized
INFO - 2017-02-16 18:52:46 --> Loader Class Initialized
INFO - 2017-02-16 18:52:46 --> Database Driver Class Initialized
INFO - 2017-02-16 18:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:52:46 --> Controller Class Initialized
INFO - 2017-02-16 18:52:46 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:52:46 --> Final output sent to browser
DEBUG - 2017-02-16 18:52:46 --> Total execution time: 0.0129
INFO - 2017-02-16 18:53:07 --> Config Class Initialized
INFO - 2017-02-16 18:53:07 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:53:07 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:53:07 --> Utf8 Class Initialized
INFO - 2017-02-16 18:53:07 --> URI Class Initialized
INFO - 2017-02-16 18:53:07 --> Router Class Initialized
INFO - 2017-02-16 18:53:07 --> Output Class Initialized
INFO - 2017-02-16 18:53:07 --> Security Class Initialized
DEBUG - 2017-02-16 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:53:07 --> Input Class Initialized
INFO - 2017-02-16 18:53:07 --> Language Class Initialized
INFO - 2017-02-16 18:53:07 --> Loader Class Initialized
INFO - 2017-02-16 18:53:07 --> Database Driver Class Initialized
INFO - 2017-02-16 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:53:07 --> Controller Class Initialized
INFO - 2017-02-16 18:53:07 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:53:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:53:07 --> Final output sent to browser
DEBUG - 2017-02-16 18:53:07 --> Total execution time: 0.0131
INFO - 2017-02-16 18:53:43 --> Config Class Initialized
INFO - 2017-02-16 18:53:43 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:53:43 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:53:43 --> Utf8 Class Initialized
INFO - 2017-02-16 18:53:43 --> URI Class Initialized
INFO - 2017-02-16 18:53:43 --> Router Class Initialized
INFO - 2017-02-16 18:53:43 --> Output Class Initialized
INFO - 2017-02-16 18:53:43 --> Security Class Initialized
DEBUG - 2017-02-16 18:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:53:43 --> Input Class Initialized
INFO - 2017-02-16 18:53:43 --> Language Class Initialized
INFO - 2017-02-16 18:53:43 --> Loader Class Initialized
INFO - 2017-02-16 18:53:43 --> Database Driver Class Initialized
INFO - 2017-02-16 18:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:53:43 --> Controller Class Initialized
INFO - 2017-02-16 18:53:43 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:53:44 --> Config Class Initialized
INFO - 2017-02-16 18:53:44 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:53:44 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:53:44 --> Utf8 Class Initialized
INFO - 2017-02-16 18:53:44 --> URI Class Initialized
INFO - 2017-02-16 18:53:44 --> Router Class Initialized
INFO - 2017-02-16 18:53:44 --> Output Class Initialized
INFO - 2017-02-16 18:53:44 --> Security Class Initialized
DEBUG - 2017-02-16 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:53:44 --> Input Class Initialized
INFO - 2017-02-16 18:53:44 --> Language Class Initialized
INFO - 2017-02-16 18:53:44 --> Loader Class Initialized
INFO - 2017-02-16 18:53:44 --> Database Driver Class Initialized
INFO - 2017-02-16 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:53:44 --> Controller Class Initialized
INFO - 2017-02-16 18:53:44 --> Helper loaded: date_helper
DEBUG - 2017-02-16 18:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:53:44 --> Helper loaded: url_helper
INFO - 2017-02-16 18:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 18:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 18:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 18:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:53:44 --> Final output sent to browser
DEBUG - 2017-02-16 18:53:44 --> Total execution time: 0.2030
INFO - 2017-02-16 18:53:46 --> Config Class Initialized
INFO - 2017-02-16 18:53:46 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:53:46 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:53:46 --> Utf8 Class Initialized
INFO - 2017-02-16 18:53:46 --> URI Class Initialized
INFO - 2017-02-16 18:53:46 --> Router Class Initialized
INFO - 2017-02-16 18:53:46 --> Output Class Initialized
INFO - 2017-02-16 18:53:46 --> Security Class Initialized
DEBUG - 2017-02-16 18:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:53:46 --> Input Class Initialized
INFO - 2017-02-16 18:53:46 --> Language Class Initialized
INFO - 2017-02-16 18:53:46 --> Loader Class Initialized
INFO - 2017-02-16 18:53:46 --> Database Driver Class Initialized
INFO - 2017-02-16 18:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:53:46 --> Controller Class Initialized
INFO - 2017-02-16 18:53:46 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:53:46 --> Final output sent to browser
DEBUG - 2017-02-16 18:53:46 --> Total execution time: 0.0131
INFO - 2017-02-16 18:54:21 --> Config Class Initialized
INFO - 2017-02-16 18:54:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:54:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:54:21 --> Utf8 Class Initialized
INFO - 2017-02-16 18:54:21 --> URI Class Initialized
INFO - 2017-02-16 18:54:21 --> Router Class Initialized
INFO - 2017-02-16 18:54:21 --> Output Class Initialized
INFO - 2017-02-16 18:54:21 --> Security Class Initialized
DEBUG - 2017-02-16 18:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:54:21 --> Input Class Initialized
INFO - 2017-02-16 18:54:21 --> Language Class Initialized
INFO - 2017-02-16 18:54:21 --> Loader Class Initialized
INFO - 2017-02-16 18:54:21 --> Database Driver Class Initialized
INFO - 2017-02-16 18:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:54:21 --> Controller Class Initialized
INFO - 2017-02-16 18:54:21 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:54:22 --> Config Class Initialized
INFO - 2017-02-16 18:54:22 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:54:22 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:54:22 --> Utf8 Class Initialized
INFO - 2017-02-16 18:54:22 --> URI Class Initialized
INFO - 2017-02-16 18:54:22 --> Router Class Initialized
INFO - 2017-02-16 18:54:22 --> Output Class Initialized
INFO - 2017-02-16 18:54:22 --> Security Class Initialized
DEBUG - 2017-02-16 18:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:54:22 --> Input Class Initialized
INFO - 2017-02-16 18:54:22 --> Language Class Initialized
INFO - 2017-02-16 18:54:22 --> Loader Class Initialized
INFO - 2017-02-16 18:54:22 --> Database Driver Class Initialized
INFO - 2017-02-16 18:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:54:22 --> Controller Class Initialized
INFO - 2017-02-16 18:54:22 --> Helper loaded: date_helper
DEBUG - 2017-02-16 18:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:54:22 --> Helper loaded: url_helper
INFO - 2017-02-16 18:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 18:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 18:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 18:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:54:22 --> Final output sent to browser
DEBUG - 2017-02-16 18:54:22 --> Total execution time: 0.0143
INFO - 2017-02-16 18:54:26 --> Config Class Initialized
INFO - 2017-02-16 18:54:26 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:54:26 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:54:26 --> Utf8 Class Initialized
INFO - 2017-02-16 18:54:26 --> URI Class Initialized
INFO - 2017-02-16 18:54:26 --> Router Class Initialized
INFO - 2017-02-16 18:54:26 --> Output Class Initialized
INFO - 2017-02-16 18:54:27 --> Security Class Initialized
DEBUG - 2017-02-16 18:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:54:27 --> Input Class Initialized
INFO - 2017-02-16 18:54:27 --> Language Class Initialized
INFO - 2017-02-16 18:54:27 --> Loader Class Initialized
INFO - 2017-02-16 18:54:27 --> Database Driver Class Initialized
INFO - 2017-02-16 18:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:54:27 --> Controller Class Initialized
INFO - 2017-02-16 18:54:27 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:54:27 --> Final output sent to browser
DEBUG - 2017-02-16 18:54:27 --> Total execution time: 0.0192
INFO - 2017-02-16 18:54:34 --> Config Class Initialized
INFO - 2017-02-16 18:54:34 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:54:34 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:54:34 --> Utf8 Class Initialized
INFO - 2017-02-16 18:54:34 --> URI Class Initialized
DEBUG - 2017-02-16 18:54:34 --> No URI present. Default controller set.
INFO - 2017-02-16 18:54:34 --> Router Class Initialized
INFO - 2017-02-16 18:54:34 --> Output Class Initialized
INFO - 2017-02-16 18:54:34 --> Security Class Initialized
DEBUG - 2017-02-16 18:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:54:34 --> Input Class Initialized
INFO - 2017-02-16 18:54:34 --> Language Class Initialized
INFO - 2017-02-16 18:54:34 --> Loader Class Initialized
INFO - 2017-02-16 18:54:34 --> Database Driver Class Initialized
INFO - 2017-02-16 18:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:54:34 --> Controller Class Initialized
INFO - 2017-02-16 18:54:34 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:54:34 --> Final output sent to browser
DEBUG - 2017-02-16 18:54:34 --> Total execution time: 0.0142
INFO - 2017-02-16 18:54:35 --> Config Class Initialized
INFO - 2017-02-16 18:54:35 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:54:35 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:54:35 --> Utf8 Class Initialized
INFO - 2017-02-16 18:54:35 --> URI Class Initialized
DEBUG - 2017-02-16 18:54:35 --> No URI present. Default controller set.
INFO - 2017-02-16 18:54:35 --> Router Class Initialized
INFO - 2017-02-16 18:54:35 --> Output Class Initialized
INFO - 2017-02-16 18:54:35 --> Security Class Initialized
DEBUG - 2017-02-16 18:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:54:35 --> Input Class Initialized
INFO - 2017-02-16 18:54:35 --> Language Class Initialized
INFO - 2017-02-16 18:54:35 --> Loader Class Initialized
INFO - 2017-02-16 18:54:35 --> Database Driver Class Initialized
INFO - 2017-02-16 18:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:54:35 --> Controller Class Initialized
INFO - 2017-02-16 18:54:35 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:54:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:54:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:54:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:54:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:54:35 --> Final output sent to browser
DEBUG - 2017-02-16 18:54:35 --> Total execution time: 0.0129
INFO - 2017-02-16 18:54:38 --> Config Class Initialized
INFO - 2017-02-16 18:54:38 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:54:38 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:54:38 --> Utf8 Class Initialized
INFO - 2017-02-16 18:54:38 --> URI Class Initialized
INFO - 2017-02-16 18:54:38 --> Router Class Initialized
INFO - 2017-02-16 18:54:38 --> Output Class Initialized
INFO - 2017-02-16 18:54:38 --> Security Class Initialized
DEBUG - 2017-02-16 18:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:54:38 --> Input Class Initialized
INFO - 2017-02-16 18:54:38 --> Language Class Initialized
INFO - 2017-02-16 18:54:38 --> Loader Class Initialized
INFO - 2017-02-16 18:54:38 --> Database Driver Class Initialized
INFO - 2017-02-16 18:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:54:38 --> Controller Class Initialized
INFO - 2017-02-16 18:54:38 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:54:38 --> Final output sent to browser
DEBUG - 2017-02-16 18:54:38 --> Total execution time: 0.0131
INFO - 2017-02-16 18:54:41 --> Config Class Initialized
INFO - 2017-02-16 18:54:41 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:54:41 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:54:41 --> Utf8 Class Initialized
INFO - 2017-02-16 18:54:41 --> URI Class Initialized
INFO - 2017-02-16 18:54:41 --> Router Class Initialized
INFO - 2017-02-16 18:54:41 --> Output Class Initialized
INFO - 2017-02-16 18:54:41 --> Security Class Initialized
DEBUG - 2017-02-16 18:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:54:41 --> Input Class Initialized
INFO - 2017-02-16 18:54:41 --> Language Class Initialized
INFO - 2017-02-16 18:54:41 --> Loader Class Initialized
INFO - 2017-02-16 18:54:41 --> Database Driver Class Initialized
INFO - 2017-02-16 18:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:54:41 --> Controller Class Initialized
INFO - 2017-02-16 18:54:41 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:54:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:54:41 --> Final output sent to browser
DEBUG - 2017-02-16 18:54:41 --> Total execution time: 0.0133
INFO - 2017-02-16 18:55:09 --> Config Class Initialized
INFO - 2017-02-16 18:55:09 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:09 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:09 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:09 --> URI Class Initialized
DEBUG - 2017-02-16 18:55:09 --> No URI present. Default controller set.
INFO - 2017-02-16 18:55:09 --> Router Class Initialized
INFO - 2017-02-16 18:55:09 --> Output Class Initialized
INFO - 2017-02-16 18:55:09 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:09 --> Input Class Initialized
INFO - 2017-02-16 18:55:09 --> Language Class Initialized
INFO - 2017-02-16 18:55:09 --> Loader Class Initialized
INFO - 2017-02-16 18:55:09 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:09 --> Controller Class Initialized
INFO - 2017-02-16 18:55:09 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:55:09 --> Final output sent to browser
DEBUG - 2017-02-16 18:55:09 --> Total execution time: 0.0139
INFO - 2017-02-16 18:55:37 --> Config Class Initialized
INFO - 2017-02-16 18:55:37 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:37 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:37 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:37 --> URI Class Initialized
DEBUG - 2017-02-16 18:55:37 --> No URI present. Default controller set.
INFO - 2017-02-16 18:55:37 --> Router Class Initialized
INFO - 2017-02-16 18:55:37 --> Output Class Initialized
INFO - 2017-02-16 18:55:37 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:37 --> Input Class Initialized
INFO - 2017-02-16 18:55:37 --> Language Class Initialized
INFO - 2017-02-16 18:55:37 --> Loader Class Initialized
INFO - 2017-02-16 18:55:37 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:37 --> Controller Class Initialized
INFO - 2017-02-16 18:55:37 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:55:37 --> Final output sent to browser
DEBUG - 2017-02-16 18:55:37 --> Total execution time: 0.0136
INFO - 2017-02-16 18:56:24 --> Config Class Initialized
INFO - 2017-02-16 18:56:24 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:56:24 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:56:24 --> Utf8 Class Initialized
INFO - 2017-02-16 18:56:24 --> URI Class Initialized
INFO - 2017-02-16 18:56:24 --> Router Class Initialized
INFO - 2017-02-16 18:56:24 --> Output Class Initialized
INFO - 2017-02-16 18:56:24 --> Security Class Initialized
DEBUG - 2017-02-16 18:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:56:24 --> Input Class Initialized
INFO - 2017-02-16 18:56:25 --> Language Class Initialized
INFO - 2017-02-16 18:56:25 --> Loader Class Initialized
INFO - 2017-02-16 18:56:25 --> Database Driver Class Initialized
INFO - 2017-02-16 18:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:56:25 --> Controller Class Initialized
INFO - 2017-02-16 18:56:25 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:56:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-16 18:56:26 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 18:56:26 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ingrid Tachiquin')
INFO - 2017-02-16 18:56:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 18:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 18:56:26 --> Config Class Initialized
INFO - 2017-02-16 18:56:26 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:56:26 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:56:26 --> Utf8 Class Initialized
INFO - 2017-02-16 18:56:26 --> URI Class Initialized
INFO - 2017-02-16 18:56:26 --> Router Class Initialized
INFO - 2017-02-16 18:56:26 --> Output Class Initialized
INFO - 2017-02-16 18:56:26 --> Security Class Initialized
DEBUG - 2017-02-16 18:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:56:26 --> Input Class Initialized
INFO - 2017-02-16 18:56:26 --> Language Class Initialized
INFO - 2017-02-16 18:56:26 --> Loader Class Initialized
INFO - 2017-02-16 18:56:26 --> Database Driver Class Initialized
INFO - 2017-02-16 18:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:56:26 --> Controller Class Initialized
INFO - 2017-02-16 18:56:26 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:56:26 --> Final output sent to browser
DEBUG - 2017-02-16 18:56:26 --> Total execution time: 0.0139
INFO - 2017-02-16 18:56:47 --> Config Class Initialized
INFO - 2017-02-16 18:56:47 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:56:47 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:56:47 --> Utf8 Class Initialized
INFO - 2017-02-16 18:56:47 --> URI Class Initialized
DEBUG - 2017-02-16 18:56:47 --> No URI present. Default controller set.
INFO - 2017-02-16 18:56:47 --> Router Class Initialized
INFO - 2017-02-16 18:56:47 --> Output Class Initialized
INFO - 2017-02-16 18:56:47 --> Security Class Initialized
DEBUG - 2017-02-16 18:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:56:47 --> Input Class Initialized
INFO - 2017-02-16 18:56:47 --> Language Class Initialized
INFO - 2017-02-16 18:56:47 --> Loader Class Initialized
INFO - 2017-02-16 18:56:47 --> Database Driver Class Initialized
INFO - 2017-02-16 18:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:56:47 --> Controller Class Initialized
INFO - 2017-02-16 18:56:47 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:56:47 --> Final output sent to browser
DEBUG - 2017-02-16 18:56:47 --> Total execution time: 0.0132
INFO - 2017-02-16 18:56:50 --> Config Class Initialized
INFO - 2017-02-16 18:56:50 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:56:50 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:56:50 --> Utf8 Class Initialized
INFO - 2017-02-16 18:56:50 --> URI Class Initialized
INFO - 2017-02-16 18:56:50 --> Router Class Initialized
INFO - 2017-02-16 18:56:50 --> Output Class Initialized
INFO - 2017-02-16 18:56:50 --> Security Class Initialized
DEBUG - 2017-02-16 18:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:56:50 --> Input Class Initialized
INFO - 2017-02-16 18:56:50 --> Language Class Initialized
INFO - 2017-02-16 18:56:50 --> Loader Class Initialized
INFO - 2017-02-16 18:56:50 --> Database Driver Class Initialized
INFO - 2017-02-16 18:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:56:50 --> Controller Class Initialized
INFO - 2017-02-16 18:56:50 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:56:51 --> Config Class Initialized
INFO - 2017-02-16 18:56:51 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:56:51 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:56:51 --> Utf8 Class Initialized
INFO - 2017-02-16 18:56:51 --> URI Class Initialized
INFO - 2017-02-16 18:56:51 --> Router Class Initialized
INFO - 2017-02-16 18:56:51 --> Output Class Initialized
INFO - 2017-02-16 18:56:51 --> Security Class Initialized
DEBUG - 2017-02-16 18:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:56:51 --> Input Class Initialized
INFO - 2017-02-16 18:56:51 --> Language Class Initialized
INFO - 2017-02-16 18:56:51 --> Loader Class Initialized
INFO - 2017-02-16 18:56:51 --> Database Driver Class Initialized
INFO - 2017-02-16 18:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:56:51 --> Controller Class Initialized
INFO - 2017-02-16 18:56:51 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:56:51 --> Final output sent to browser
DEBUG - 2017-02-16 18:56:51 --> Total execution time: 0.0128
ERROR - 2017-02-16 18:56:51 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 18:56:51 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ingrid Tachiquin')
INFO - 2017-02-16 18:56:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 18:56:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 18:57:15 --> Config Class Initialized
INFO - 2017-02-16 18:57:15 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:57:15 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:57:15 --> Utf8 Class Initialized
INFO - 2017-02-16 18:57:15 --> URI Class Initialized
INFO - 2017-02-16 18:57:15 --> Router Class Initialized
INFO - 2017-02-16 18:57:15 --> Output Class Initialized
INFO - 2017-02-16 18:57:15 --> Security Class Initialized
DEBUG - 2017-02-16 18:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:57:15 --> Input Class Initialized
INFO - 2017-02-16 18:57:15 --> Language Class Initialized
INFO - 2017-02-16 18:57:15 --> Loader Class Initialized
INFO - 2017-02-16 18:57:15 --> Database Driver Class Initialized
INFO - 2017-02-16 18:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:57:15 --> Controller Class Initialized
INFO - 2017-02-16 18:57:15 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:57:15 --> Final output sent to browser
DEBUG - 2017-02-16 18:57:15 --> Total execution time: 0.0133
INFO - 2017-02-16 18:57:25 --> Config Class Initialized
INFO - 2017-02-16 18:57:25 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:57:25 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:57:25 --> Utf8 Class Initialized
INFO - 2017-02-16 18:57:25 --> URI Class Initialized
DEBUG - 2017-02-16 18:57:25 --> No URI present. Default controller set.
INFO - 2017-02-16 18:57:25 --> Router Class Initialized
INFO - 2017-02-16 18:57:25 --> Output Class Initialized
INFO - 2017-02-16 18:57:25 --> Security Class Initialized
DEBUG - 2017-02-16 18:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:57:25 --> Input Class Initialized
INFO - 2017-02-16 18:57:25 --> Language Class Initialized
INFO - 2017-02-16 18:57:25 --> Loader Class Initialized
INFO - 2017-02-16 18:57:25 --> Database Driver Class Initialized
INFO - 2017-02-16 18:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:57:25 --> Controller Class Initialized
INFO - 2017-02-16 18:57:25 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:57:25 --> Final output sent to browser
DEBUG - 2017-02-16 18:57:25 --> Total execution time: 0.0127
INFO - 2017-02-16 18:58:32 --> Config Class Initialized
INFO - 2017-02-16 18:58:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:58:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:58:32 --> Utf8 Class Initialized
INFO - 2017-02-16 18:58:32 --> URI Class Initialized
INFO - 2017-02-16 18:58:32 --> Router Class Initialized
INFO - 2017-02-16 18:58:32 --> Output Class Initialized
INFO - 2017-02-16 18:58:32 --> Security Class Initialized
DEBUG - 2017-02-16 18:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:58:32 --> Input Class Initialized
INFO - 2017-02-16 18:58:32 --> Language Class Initialized
INFO - 2017-02-16 18:58:32 --> Loader Class Initialized
INFO - 2017-02-16 18:58:32 --> Database Driver Class Initialized
INFO - 2017-02-16 18:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:58:32 --> Controller Class Initialized
INFO - 2017-02-16 18:58:32 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:58:32 --> Config Class Initialized
INFO - 2017-02-16 18:58:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:58:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:58:32 --> Utf8 Class Initialized
INFO - 2017-02-16 18:58:32 --> URI Class Initialized
INFO - 2017-02-16 18:58:32 --> Router Class Initialized
INFO - 2017-02-16 18:58:32 --> Output Class Initialized
INFO - 2017-02-16 18:58:32 --> Security Class Initialized
DEBUG - 2017-02-16 18:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:58:32 --> Input Class Initialized
INFO - 2017-02-16 18:58:32 --> Language Class Initialized
INFO - 2017-02-16 18:58:32 --> Loader Class Initialized
INFO - 2017-02-16 18:58:32 --> Database Driver Class Initialized
INFO - 2017-02-16 18:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:58:32 --> Controller Class Initialized
INFO - 2017-02-16 18:58:32 --> Helper loaded: date_helper
DEBUG - 2017-02-16 18:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:58:32 --> Helper loaded: url_helper
INFO - 2017-02-16 18:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 18:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 18:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 18:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:58:32 --> Final output sent to browser
DEBUG - 2017-02-16 18:58:32 --> Total execution time: 0.0132
INFO - 2017-02-16 18:59:15 --> Config Class Initialized
INFO - 2017-02-16 18:59:15 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:15 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:15 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:15 --> URI Class Initialized
DEBUG - 2017-02-16 18:59:15 --> No URI present. Default controller set.
INFO - 2017-02-16 18:59:15 --> Router Class Initialized
INFO - 2017-02-16 18:59:15 --> Output Class Initialized
INFO - 2017-02-16 18:59:15 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:15 --> Input Class Initialized
INFO - 2017-02-16 18:59:15 --> Language Class Initialized
INFO - 2017-02-16 18:59:15 --> Loader Class Initialized
INFO - 2017-02-16 18:59:15 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:15 --> Controller Class Initialized
INFO - 2017-02-16 18:59:15 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:59:15 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:15 --> Total execution time: 0.0133
INFO - 2017-02-16 18:59:30 --> Config Class Initialized
INFO - 2017-02-16 18:59:30 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:30 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:30 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:30 --> URI Class Initialized
DEBUG - 2017-02-16 18:59:30 --> No URI present. Default controller set.
INFO - 2017-02-16 18:59:30 --> Router Class Initialized
INFO - 2017-02-16 18:59:30 --> Output Class Initialized
INFO - 2017-02-16 18:59:30 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:30 --> Input Class Initialized
INFO - 2017-02-16 18:59:30 --> Language Class Initialized
INFO - 2017-02-16 18:59:30 --> Loader Class Initialized
INFO - 2017-02-16 18:59:30 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:30 --> Controller Class Initialized
INFO - 2017-02-16 18:59:30 --> Helper loaded: url_helper
DEBUG - 2017-02-16 18:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 18:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 18:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 18:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 18:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 18:59:30 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:30 --> Total execution time: 0.0135
INFO - 2017-02-16 19:00:00 --> Config Class Initialized
INFO - 2017-02-16 19:00:00 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:00:00 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:00:00 --> Utf8 Class Initialized
INFO - 2017-02-16 19:00:00 --> URI Class Initialized
INFO - 2017-02-16 19:00:00 --> Router Class Initialized
INFO - 2017-02-16 19:00:00 --> Output Class Initialized
INFO - 2017-02-16 19:00:00 --> Security Class Initialized
DEBUG - 2017-02-16 19:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:00:00 --> Input Class Initialized
INFO - 2017-02-16 19:00:00 --> Language Class Initialized
INFO - 2017-02-16 19:00:00 --> Loader Class Initialized
INFO - 2017-02-16 19:00:00 --> Database Driver Class Initialized
INFO - 2017-02-16 19:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:00:00 --> Controller Class Initialized
INFO - 2017-02-16 19:00:00 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:00:00 --> Config Class Initialized
INFO - 2017-02-16 19:00:00 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:00:00 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:00:00 --> Utf8 Class Initialized
INFO - 2017-02-16 19:00:00 --> URI Class Initialized
INFO - 2017-02-16 19:00:00 --> Router Class Initialized
INFO - 2017-02-16 19:00:00 --> Output Class Initialized
INFO - 2017-02-16 19:00:00 --> Security Class Initialized
DEBUG - 2017-02-16 19:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:00:00 --> Input Class Initialized
INFO - 2017-02-16 19:00:00 --> Language Class Initialized
INFO - 2017-02-16 19:00:00 --> Loader Class Initialized
INFO - 2017-02-16 19:00:00 --> Database Driver Class Initialized
INFO - 2017-02-16 19:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:00:00 --> Controller Class Initialized
INFO - 2017-02-16 19:00:00 --> Helper loaded: date_helper
DEBUG - 2017-02-16 19:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:00:00 --> Helper loaded: url_helper
INFO - 2017-02-16 19:00:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:00:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 19:00:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 19:00:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 19:00:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:00:00 --> Final output sent to browser
DEBUG - 2017-02-16 19:00:00 --> Total execution time: 0.0689
INFO - 2017-02-16 19:00:11 --> Config Class Initialized
INFO - 2017-02-16 19:00:11 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:00:11 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:00:11 --> Utf8 Class Initialized
INFO - 2017-02-16 19:00:11 --> URI Class Initialized
INFO - 2017-02-16 19:00:11 --> Router Class Initialized
INFO - 2017-02-16 19:00:11 --> Output Class Initialized
INFO - 2017-02-16 19:00:11 --> Security Class Initialized
DEBUG - 2017-02-16 19:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:00:11 --> Input Class Initialized
INFO - 2017-02-16 19:00:11 --> Language Class Initialized
INFO - 2017-02-16 19:00:11 --> Loader Class Initialized
INFO - 2017-02-16 19:00:11 --> Database Driver Class Initialized
INFO - 2017-02-16 19:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:00:11 --> Controller Class Initialized
INFO - 2017-02-16 19:00:11 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:00:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-16 19:00:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-16 19:00:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ingrid Tachiquin')
INFO - 2017-02-16 19:00:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-16 19:00:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-16 19:10:42 --> Config Class Initialized
INFO - 2017-02-16 19:10:42 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:10:42 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:10:42 --> Utf8 Class Initialized
INFO - 2017-02-16 19:10:42 --> URI Class Initialized
DEBUG - 2017-02-16 19:10:42 --> No URI present. Default controller set.
INFO - 2017-02-16 19:10:42 --> Router Class Initialized
INFO - 2017-02-16 19:10:42 --> Output Class Initialized
INFO - 2017-02-16 19:10:42 --> Security Class Initialized
DEBUG - 2017-02-16 19:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:10:42 --> Input Class Initialized
INFO - 2017-02-16 19:10:42 --> Language Class Initialized
INFO - 2017-02-16 19:10:42 --> Loader Class Initialized
INFO - 2017-02-16 19:10:42 --> Database Driver Class Initialized
INFO - 2017-02-16 19:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:10:42 --> Controller Class Initialized
INFO - 2017-02-16 19:10:42 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:10:42 --> Final output sent to browser
DEBUG - 2017-02-16 19:10:42 --> Total execution time: 0.0127
INFO - 2017-02-16 19:10:48 --> Config Class Initialized
INFO - 2017-02-16 19:10:48 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:10:48 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:10:48 --> Utf8 Class Initialized
INFO - 2017-02-16 19:10:48 --> URI Class Initialized
INFO - 2017-02-16 19:10:48 --> Router Class Initialized
INFO - 2017-02-16 19:10:48 --> Output Class Initialized
INFO - 2017-02-16 19:10:48 --> Security Class Initialized
DEBUG - 2017-02-16 19:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:10:48 --> Input Class Initialized
INFO - 2017-02-16 19:10:48 --> Language Class Initialized
INFO - 2017-02-16 19:10:48 --> Loader Class Initialized
INFO - 2017-02-16 19:10:48 --> Database Driver Class Initialized
INFO - 2017-02-16 19:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:10:48 --> Controller Class Initialized
INFO - 2017-02-16 19:10:48 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:10:48 --> Final output sent to browser
DEBUG - 2017-02-16 19:10:48 --> Total execution time: 0.0130
INFO - 2017-02-16 19:12:15 --> Config Class Initialized
INFO - 2017-02-16 19:12:15 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:12:15 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:12:15 --> Utf8 Class Initialized
INFO - 2017-02-16 19:12:15 --> URI Class Initialized
INFO - 2017-02-16 19:12:15 --> Router Class Initialized
INFO - 2017-02-16 19:12:15 --> Output Class Initialized
INFO - 2017-02-16 19:12:15 --> Security Class Initialized
DEBUG - 2017-02-16 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:12:15 --> Input Class Initialized
INFO - 2017-02-16 19:12:15 --> Language Class Initialized
INFO - 2017-02-16 19:12:15 --> Loader Class Initialized
INFO - 2017-02-16 19:12:15 --> Database Driver Class Initialized
INFO - 2017-02-16 19:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:12:15 --> Controller Class Initialized
INFO - 2017-02-16 19:12:15 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:12:15 --> Config Class Initialized
INFO - 2017-02-16 19:12:15 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:12:15 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:12:15 --> Utf8 Class Initialized
INFO - 2017-02-16 19:12:15 --> URI Class Initialized
INFO - 2017-02-16 19:12:15 --> Router Class Initialized
INFO - 2017-02-16 19:12:15 --> Output Class Initialized
INFO - 2017-02-16 19:12:15 --> Security Class Initialized
DEBUG - 2017-02-16 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:12:15 --> Input Class Initialized
INFO - 2017-02-16 19:12:15 --> Language Class Initialized
INFO - 2017-02-16 19:12:15 --> Loader Class Initialized
INFO - 2017-02-16 19:12:15 --> Database Driver Class Initialized
INFO - 2017-02-16 19:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:12:15 --> Controller Class Initialized
INFO - 2017-02-16 19:12:15 --> Helper loaded: date_helper
DEBUG - 2017-02-16 19:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:12:15 --> Helper loaded: url_helper
INFO - 2017-02-16 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-16 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-16 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-16 19:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:12:15 --> Final output sent to browser
DEBUG - 2017-02-16 19:12:15 --> Total execution time: 0.0142
INFO - 2017-02-16 19:12:16 --> Config Class Initialized
INFO - 2017-02-16 19:12:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:12:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:12:16 --> Utf8 Class Initialized
INFO - 2017-02-16 19:12:16 --> URI Class Initialized
INFO - 2017-02-16 19:12:16 --> Router Class Initialized
INFO - 2017-02-16 19:12:16 --> Output Class Initialized
INFO - 2017-02-16 19:12:16 --> Security Class Initialized
DEBUG - 2017-02-16 19:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:12:16 --> Input Class Initialized
INFO - 2017-02-16 19:12:16 --> Language Class Initialized
INFO - 2017-02-16 19:12:16 --> Loader Class Initialized
INFO - 2017-02-16 19:12:16 --> Database Driver Class Initialized
INFO - 2017-02-16 19:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:12:16 --> Controller Class Initialized
INFO - 2017-02-16 19:12:16 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:12:16 --> Final output sent to browser
DEBUG - 2017-02-16 19:12:16 --> Total execution time: 0.0128
INFO - 2017-02-16 19:12:21 --> Config Class Initialized
INFO - 2017-02-16 19:12:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:12:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:12:21 --> Utf8 Class Initialized
INFO - 2017-02-16 19:12:21 --> URI Class Initialized
DEBUG - 2017-02-16 19:12:21 --> No URI present. Default controller set.
INFO - 2017-02-16 19:12:21 --> Router Class Initialized
INFO - 2017-02-16 19:12:21 --> Output Class Initialized
INFO - 2017-02-16 19:12:21 --> Security Class Initialized
DEBUG - 2017-02-16 19:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:12:21 --> Input Class Initialized
INFO - 2017-02-16 19:12:21 --> Language Class Initialized
INFO - 2017-02-16 19:12:21 --> Loader Class Initialized
INFO - 2017-02-16 19:12:21 --> Database Driver Class Initialized
INFO - 2017-02-16 19:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:12:21 --> Controller Class Initialized
INFO - 2017-02-16 19:12:21 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:12:21 --> Final output sent to browser
DEBUG - 2017-02-16 19:12:21 --> Total execution time: 0.0148
INFO - 2017-02-16 19:12:22 --> Config Class Initialized
INFO - 2017-02-16 19:12:22 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:12:22 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:12:22 --> Utf8 Class Initialized
INFO - 2017-02-16 19:12:22 --> URI Class Initialized
INFO - 2017-02-16 19:12:22 --> Router Class Initialized
INFO - 2017-02-16 19:12:22 --> Output Class Initialized
INFO - 2017-02-16 19:12:22 --> Security Class Initialized
DEBUG - 2017-02-16 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:12:22 --> Input Class Initialized
INFO - 2017-02-16 19:12:22 --> Language Class Initialized
INFO - 2017-02-16 19:12:22 --> Loader Class Initialized
INFO - 2017-02-16 19:12:22 --> Database Driver Class Initialized
INFO - 2017-02-16 19:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:12:22 --> Controller Class Initialized
INFO - 2017-02-16 19:12:22 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:12:22 --> Final output sent to browser
DEBUG - 2017-02-16 19:12:22 --> Total execution time: 0.0143
INFO - 2017-02-16 19:21:21 --> Config Class Initialized
INFO - 2017-02-16 19:21:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:21:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:21:21 --> Utf8 Class Initialized
INFO - 2017-02-16 19:21:21 --> URI Class Initialized
INFO - 2017-02-16 19:21:21 --> Router Class Initialized
INFO - 2017-02-16 19:21:21 --> Output Class Initialized
INFO - 2017-02-16 19:21:21 --> Security Class Initialized
DEBUG - 2017-02-16 19:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:21:21 --> Input Class Initialized
INFO - 2017-02-16 19:21:21 --> Language Class Initialized
INFO - 2017-02-16 19:21:21 --> Loader Class Initialized
INFO - 2017-02-16 19:21:21 --> Database Driver Class Initialized
INFO - 2017-02-16 19:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:21:21 --> Controller Class Initialized
INFO - 2017-02-16 19:21:21 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:21:21 --> Final output sent to browser
DEBUG - 2017-02-16 19:21:21 --> Total execution time: 0.0139
INFO - 2017-02-16 19:21:21 --> Config Class Initialized
INFO - 2017-02-16 19:21:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:21:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:21:21 --> Utf8 Class Initialized
INFO - 2017-02-16 19:21:21 --> URI Class Initialized
DEBUG - 2017-02-16 19:21:21 --> No URI present. Default controller set.
INFO - 2017-02-16 19:21:21 --> Router Class Initialized
INFO - 2017-02-16 19:21:21 --> Output Class Initialized
INFO - 2017-02-16 19:21:21 --> Security Class Initialized
DEBUG - 2017-02-16 19:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:21:21 --> Input Class Initialized
INFO - 2017-02-16 19:21:21 --> Language Class Initialized
INFO - 2017-02-16 19:21:21 --> Loader Class Initialized
INFO - 2017-02-16 19:21:21 --> Database Driver Class Initialized
INFO - 2017-02-16 19:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:21:21 --> Controller Class Initialized
INFO - 2017-02-16 19:21:21 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:21:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:21:21 --> Final output sent to browser
DEBUG - 2017-02-16 19:21:21 --> Total execution time: 0.0130
INFO - 2017-02-16 19:50:36 --> Config Class Initialized
INFO - 2017-02-16 19:50:36 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:50:36 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:50:36 --> Utf8 Class Initialized
INFO - 2017-02-16 19:50:36 --> URI Class Initialized
DEBUG - 2017-02-16 19:50:36 --> No URI present. Default controller set.
INFO - 2017-02-16 19:50:36 --> Router Class Initialized
INFO - 2017-02-16 19:50:36 --> Output Class Initialized
INFO - 2017-02-16 19:50:36 --> Security Class Initialized
DEBUG - 2017-02-16 19:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:50:36 --> Input Class Initialized
INFO - 2017-02-16 19:50:36 --> Language Class Initialized
INFO - 2017-02-16 19:50:36 --> Loader Class Initialized
INFO - 2017-02-16 19:50:36 --> Database Driver Class Initialized
INFO - 2017-02-16 19:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:50:36 --> Controller Class Initialized
INFO - 2017-02-16 19:50:36 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:50:36 --> Final output sent to browser
DEBUG - 2017-02-16 19:50:36 --> Total execution time: 0.0136
INFO - 2017-02-16 19:50:40 --> Config Class Initialized
INFO - 2017-02-16 19:50:40 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:50:40 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:50:40 --> Utf8 Class Initialized
INFO - 2017-02-16 19:50:40 --> URI Class Initialized
DEBUG - 2017-02-16 19:50:40 --> No URI present. Default controller set.
INFO - 2017-02-16 19:50:40 --> Router Class Initialized
INFO - 2017-02-16 19:50:40 --> Output Class Initialized
INFO - 2017-02-16 19:50:40 --> Security Class Initialized
DEBUG - 2017-02-16 19:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:50:40 --> Input Class Initialized
INFO - 2017-02-16 19:50:40 --> Language Class Initialized
INFO - 2017-02-16 19:50:40 --> Loader Class Initialized
INFO - 2017-02-16 19:50:40 --> Database Driver Class Initialized
INFO - 2017-02-16 19:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:50:40 --> Controller Class Initialized
INFO - 2017-02-16 19:50:40 --> Helper loaded: url_helper
DEBUG - 2017-02-16 19:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 19:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 19:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 19:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 19:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 19:50:40 --> Final output sent to browser
DEBUG - 2017-02-16 19:50:40 --> Total execution time: 0.0506
INFO - 2017-02-16 21:24:45 --> Config Class Initialized
INFO - 2017-02-16 21:24:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 21:24:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 21:24:45 --> Utf8 Class Initialized
INFO - 2017-02-16 21:24:45 --> URI Class Initialized
INFO - 2017-02-16 21:24:45 --> Router Class Initialized
INFO - 2017-02-16 21:24:45 --> Output Class Initialized
INFO - 2017-02-16 21:24:45 --> Security Class Initialized
DEBUG - 2017-02-16 21:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 21:24:45 --> Input Class Initialized
INFO - 2017-02-16 21:24:45 --> Language Class Initialized
INFO - 2017-02-16 21:24:45 --> Loader Class Initialized
INFO - 2017-02-16 21:24:45 --> Database Driver Class Initialized
INFO - 2017-02-16 21:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 21:24:45 --> Controller Class Initialized
INFO - 2017-02-16 21:24:45 --> Helper loaded: url_helper
DEBUG - 2017-02-16 21:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 21:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 21:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 21:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 21:24:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 21:24:45 --> Final output sent to browser
DEBUG - 2017-02-16 21:24:45 --> Total execution time: 0.0696
INFO - 2017-02-16 21:29:45 --> Config Class Initialized
INFO - 2017-02-16 21:29:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 21:29:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 21:29:45 --> Utf8 Class Initialized
INFO - 2017-02-16 21:29:45 --> URI Class Initialized
INFO - 2017-02-16 21:29:45 --> Router Class Initialized
INFO - 2017-02-16 21:29:45 --> Output Class Initialized
INFO - 2017-02-16 21:29:45 --> Security Class Initialized
DEBUG - 2017-02-16 21:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 21:29:45 --> Input Class Initialized
INFO - 2017-02-16 21:29:45 --> Language Class Initialized
INFO - 2017-02-16 21:29:45 --> Loader Class Initialized
INFO - 2017-02-16 21:29:45 --> Database Driver Class Initialized
INFO - 2017-02-16 21:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 21:29:45 --> Controller Class Initialized
INFO - 2017-02-16 21:29:45 --> Helper loaded: url_helper
DEBUG - 2017-02-16 21:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 21:29:45 --> Final output sent to browser
DEBUG - 2017-02-16 21:29:45 --> Total execution time: 0.0130
INFO - 2017-02-16 21:29:46 --> Config Class Initialized
INFO - 2017-02-16 21:29:46 --> Hooks Class Initialized
DEBUG - 2017-02-16 21:29:46 --> UTF-8 Support Enabled
INFO - 2017-02-16 21:29:46 --> Utf8 Class Initialized
INFO - 2017-02-16 21:29:46 --> URI Class Initialized
DEBUG - 2017-02-16 21:29:46 --> No URI present. Default controller set.
INFO - 2017-02-16 21:29:46 --> Router Class Initialized
INFO - 2017-02-16 21:29:46 --> Output Class Initialized
INFO - 2017-02-16 21:29:46 --> Security Class Initialized
DEBUG - 2017-02-16 21:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 21:29:46 --> Input Class Initialized
INFO - 2017-02-16 21:29:46 --> Language Class Initialized
INFO - 2017-02-16 21:29:46 --> Loader Class Initialized
INFO - 2017-02-16 21:29:46 --> Database Driver Class Initialized
INFO - 2017-02-16 21:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 21:29:46 --> Controller Class Initialized
INFO - 2017-02-16 21:29:46 --> Helper loaded: url_helper
DEBUG - 2017-02-16 21:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-16 21:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-16 21:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-16 21:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-16 21:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-16 21:29:46 --> Final output sent to browser
DEBUG - 2017-02-16 21:29:46 --> Total execution time: 0.0133

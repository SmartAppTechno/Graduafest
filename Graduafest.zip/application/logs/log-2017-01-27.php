<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-27 01:16:35 --> Config Class Initialized
INFO - 2017-01-27 01:16:35 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:16:35 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:16:35 --> Utf8 Class Initialized
INFO - 2017-01-27 01:16:35 --> URI Class Initialized
DEBUG - 2017-01-27 01:16:35 --> No URI present. Default controller set.
INFO - 2017-01-27 01:16:35 --> Router Class Initialized
INFO - 2017-01-27 01:16:35 --> Output Class Initialized
INFO - 2017-01-27 01:16:35 --> Security Class Initialized
DEBUG - 2017-01-27 01:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:16:35 --> Input Class Initialized
INFO - 2017-01-27 01:16:35 --> Language Class Initialized
INFO - 2017-01-27 01:16:35 --> Loader Class Initialized
INFO - 2017-01-27 01:16:35 --> Database Driver Class Initialized
INFO - 2017-01-27 01:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:16:35 --> Controller Class Initialized
INFO - 2017-01-27 01:16:35 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:16:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:16:35 --> Final output sent to browser
DEBUG - 2017-01-27 01:16:35 --> Total execution time: 0.0341
INFO - 2017-01-27 01:16:37 --> Config Class Initialized
INFO - 2017-01-27 01:16:37 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:16:37 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:16:37 --> Utf8 Class Initialized
INFO - 2017-01-27 01:16:37 --> URI Class Initialized
INFO - 2017-01-27 01:16:37 --> Router Class Initialized
INFO - 2017-01-27 01:16:37 --> Output Class Initialized
INFO - 2017-01-27 01:16:37 --> Security Class Initialized
DEBUG - 2017-01-27 01:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:16:37 --> Input Class Initialized
INFO - 2017-01-27 01:16:37 --> Language Class Initialized
INFO - 2017-01-27 01:16:37 --> Loader Class Initialized
INFO - 2017-01-27 01:16:37 --> Database Driver Class Initialized
INFO - 2017-01-27 01:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:16:37 --> Controller Class Initialized
INFO - 2017-01-27 01:16:37 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:16:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:16:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:16:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:16:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:16:37 --> Final output sent to browser
DEBUG - 2017-01-27 01:16:37 --> Total execution time: 0.0135
INFO - 2017-01-27 01:17:25 --> Config Class Initialized
INFO - 2017-01-27 01:17:25 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:17:25 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:17:25 --> Utf8 Class Initialized
INFO - 2017-01-27 01:17:25 --> URI Class Initialized
INFO - 2017-01-27 01:17:25 --> Router Class Initialized
INFO - 2017-01-27 01:17:25 --> Output Class Initialized
INFO - 2017-01-27 01:17:25 --> Security Class Initialized
DEBUG - 2017-01-27 01:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:17:25 --> Input Class Initialized
INFO - 2017-01-27 01:17:25 --> Language Class Initialized
INFO - 2017-01-27 01:17:25 --> Loader Class Initialized
INFO - 2017-01-27 01:17:25 --> Database Driver Class Initialized
INFO - 2017-01-27 01:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:17:25 --> Controller Class Initialized
INFO - 2017-01-27 01:17:25 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:17:25 --> Config Class Initialized
INFO - 2017-01-27 01:17:25 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:17:25 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:17:25 --> Utf8 Class Initialized
INFO - 2017-01-27 01:17:25 --> URI Class Initialized
INFO - 2017-01-27 01:17:25 --> Router Class Initialized
INFO - 2017-01-27 01:17:25 --> Output Class Initialized
INFO - 2017-01-27 01:17:25 --> Security Class Initialized
DEBUG - 2017-01-27 01:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:17:25 --> Input Class Initialized
INFO - 2017-01-27 01:17:25 --> Language Class Initialized
INFO - 2017-01-27 01:17:25 --> Loader Class Initialized
INFO - 2017-01-27 01:17:25 --> Database Driver Class Initialized
INFO - 2017-01-27 01:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:17:25 --> Controller Class Initialized
INFO - 2017-01-27 01:17:25 --> Helper loaded: date_helper
DEBUG - 2017-01-27 01:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:17:25 --> Helper loaded: url_helper
INFO - 2017-01-27 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-27 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-27 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 01:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:17:25 --> Final output sent to browser
DEBUG - 2017-01-27 01:17:25 --> Total execution time: 0.0908
INFO - 2017-01-27 01:17:26 --> Config Class Initialized
INFO - 2017-01-27 01:17:26 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:17:26 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:17:26 --> Utf8 Class Initialized
INFO - 2017-01-27 01:17:26 --> URI Class Initialized
INFO - 2017-01-27 01:17:26 --> Router Class Initialized
INFO - 2017-01-27 01:17:26 --> Output Class Initialized
INFO - 2017-01-27 01:17:26 --> Security Class Initialized
DEBUG - 2017-01-27 01:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:17:26 --> Input Class Initialized
INFO - 2017-01-27 01:17:26 --> Language Class Initialized
INFO - 2017-01-27 01:17:26 --> Loader Class Initialized
INFO - 2017-01-27 01:17:26 --> Database Driver Class Initialized
INFO - 2017-01-27 01:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:17:26 --> Controller Class Initialized
INFO - 2017-01-27 01:17:26 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:17:26 --> Final output sent to browser
DEBUG - 2017-01-27 01:17:26 --> Total execution time: 0.0132
INFO - 2017-01-27 01:17:42 --> Config Class Initialized
INFO - 2017-01-27 01:17:42 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:17:42 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:17:42 --> Utf8 Class Initialized
INFO - 2017-01-27 01:17:42 --> URI Class Initialized
INFO - 2017-01-27 01:17:42 --> Router Class Initialized
INFO - 2017-01-27 01:17:42 --> Output Class Initialized
INFO - 2017-01-27 01:17:42 --> Security Class Initialized
DEBUG - 2017-01-27 01:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:17:42 --> Input Class Initialized
INFO - 2017-01-27 01:17:42 --> Language Class Initialized
INFO - 2017-01-27 01:17:42 --> Loader Class Initialized
INFO - 2017-01-27 01:17:42 --> Database Driver Class Initialized
INFO - 2017-01-27 01:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:17:42 --> Controller Class Initialized
INFO - 2017-01-27 01:17:42 --> Helper loaded: date_helper
DEBUG - 2017-01-27 01:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:17:42 --> Helper loaded: url_helper
INFO - 2017-01-27 01:17:42 --> Helper loaded: download_helper
INFO - 2017-01-27 01:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-27 01:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-27 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-27 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:17:43 --> Final output sent to browser
DEBUG - 2017-01-27 01:17:43 --> Total execution time: 0.3857
INFO - 2017-01-27 01:17:43 --> Config Class Initialized
INFO - 2017-01-27 01:17:43 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:17:43 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:17:43 --> Utf8 Class Initialized
INFO - 2017-01-27 01:17:43 --> URI Class Initialized
INFO - 2017-01-27 01:17:43 --> Router Class Initialized
INFO - 2017-01-27 01:17:43 --> Output Class Initialized
INFO - 2017-01-27 01:17:43 --> Security Class Initialized
DEBUG - 2017-01-27 01:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:17:43 --> Input Class Initialized
INFO - 2017-01-27 01:17:43 --> Language Class Initialized
INFO - 2017-01-27 01:17:43 --> Loader Class Initialized
INFO - 2017-01-27 01:17:43 --> Database Driver Class Initialized
INFO - 2017-01-27 01:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:17:43 --> Controller Class Initialized
INFO - 2017-01-27 01:17:43 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:17:43 --> Final output sent to browser
DEBUG - 2017-01-27 01:17:43 --> Total execution time: 0.0132
INFO - 2017-01-27 01:18:35 --> Config Class Initialized
INFO - 2017-01-27 01:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:35 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:35 --> URI Class Initialized
INFO - 2017-01-27 01:18:35 --> Router Class Initialized
INFO - 2017-01-27 01:18:35 --> Output Class Initialized
INFO - 2017-01-27 01:18:35 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:35 --> Input Class Initialized
INFO - 2017-01-27 01:18:35 --> Language Class Initialized
INFO - 2017-01-27 01:18:35 --> Loader Class Initialized
INFO - 2017-01-27 01:18:35 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:35 --> Controller Class Initialized
INFO - 2017-01-27 01:18:35 --> Helper loaded: date_helper
DEBUG - 2017-01-27 01:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:35 --> Helper loaded: url_helper
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:18:35 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:35 --> Total execution time: 0.0516
INFO - 2017-01-27 01:18:35 --> Config Class Initialized
INFO - 2017-01-27 01:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:35 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:35 --> URI Class Initialized
INFO - 2017-01-27 01:18:35 --> Router Class Initialized
INFO - 2017-01-27 01:18:35 --> Output Class Initialized
INFO - 2017-01-27 01:18:35 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:35 --> Input Class Initialized
INFO - 2017-01-27 01:18:35 --> Language Class Initialized
INFO - 2017-01-27 01:18:35 --> Loader Class Initialized
INFO - 2017-01-27 01:18:35 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:35 --> Controller Class Initialized
INFO - 2017-01-27 01:18:35 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:18:35 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:35 --> Total execution time: 0.0142
INFO - 2017-01-27 01:18:36 --> Config Class Initialized
INFO - 2017-01-27 01:18:36 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:36 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:36 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:36 --> URI Class Initialized
INFO - 2017-01-27 01:18:36 --> Router Class Initialized
INFO - 2017-01-27 01:18:36 --> Output Class Initialized
INFO - 2017-01-27 01:18:36 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:36 --> Input Class Initialized
INFO - 2017-01-27 01:18:36 --> Language Class Initialized
INFO - 2017-01-27 01:18:36 --> Loader Class Initialized
INFO - 2017-01-27 01:18:36 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:36 --> Controller Class Initialized
INFO - 2017-01-27 01:18:36 --> Upload Class Initialized
INFO - 2017-01-27 01:18:36 --> Helper loaded: date_helper
DEBUG - 2017-01-27 01:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:36 --> Helper loaded: url_helper
INFO - 2017-01-27 01:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-27 01:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-27 01:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-27 01:18:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-27 01:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:18:36 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:36 --> Total execution time: 0.2626
INFO - 2017-01-27 01:18:37 --> Config Class Initialized
INFO - 2017-01-27 01:18:37 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:37 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:37 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:37 --> URI Class Initialized
INFO - 2017-01-27 01:18:37 --> Router Class Initialized
INFO - 2017-01-27 01:18:37 --> Output Class Initialized
INFO - 2017-01-27 01:18:37 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:37 --> Input Class Initialized
INFO - 2017-01-27 01:18:37 --> Language Class Initialized
INFO - 2017-01-27 01:18:37 --> Loader Class Initialized
INFO - 2017-01-27 01:18:37 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:37 --> Controller Class Initialized
INFO - 2017-01-27 01:18:37 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:18:37 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:37 --> Total execution time: 0.0140
INFO - 2017-01-27 01:18:45 --> Config Class Initialized
INFO - 2017-01-27 01:18:45 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:45 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:45 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:45 --> URI Class Initialized
INFO - 2017-01-27 01:18:45 --> Router Class Initialized
INFO - 2017-01-27 01:18:45 --> Output Class Initialized
INFO - 2017-01-27 01:18:45 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:45 --> Input Class Initialized
INFO - 2017-01-27 01:18:45 --> Language Class Initialized
INFO - 2017-01-27 01:18:45 --> Loader Class Initialized
INFO - 2017-01-27 01:18:45 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:45 --> Controller Class Initialized
INFO - 2017-01-27 01:18:45 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:46 --> Config Class Initialized
INFO - 2017-01-27 01:18:46 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:46 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:46 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:46 --> URI Class Initialized
DEBUG - 2017-01-27 01:18:46 --> No URI present. Default controller set.
INFO - 2017-01-27 01:18:46 --> Router Class Initialized
INFO - 2017-01-27 01:18:46 --> Output Class Initialized
INFO - 2017-01-27 01:18:46 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:46 --> Input Class Initialized
INFO - 2017-01-27 01:18:46 --> Language Class Initialized
INFO - 2017-01-27 01:18:46 --> Loader Class Initialized
INFO - 2017-01-27 01:18:46 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:46 --> Controller Class Initialized
INFO - 2017-01-27 01:18:46 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:18:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:18:46 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:46 --> Total execution time: 0.0149
INFO - 2017-01-27 01:18:47 --> Config Class Initialized
INFO - 2017-01-27 01:18:47 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:47 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:47 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:47 --> URI Class Initialized
INFO - 2017-01-27 01:18:47 --> Router Class Initialized
INFO - 2017-01-27 01:18:47 --> Output Class Initialized
INFO - 2017-01-27 01:18:47 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:47 --> Input Class Initialized
INFO - 2017-01-27 01:18:47 --> Language Class Initialized
INFO - 2017-01-27 01:18:47 --> Loader Class Initialized
INFO - 2017-01-27 01:18:47 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:47 --> Controller Class Initialized
INFO - 2017-01-27 01:18:47 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:18:47 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:47 --> Total execution time: 0.0151
INFO - 2017-01-27 01:18:50 --> Config Class Initialized
INFO - 2017-01-27 01:18:50 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:50 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:50 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:50 --> URI Class Initialized
INFO - 2017-01-27 01:18:50 --> Router Class Initialized
INFO - 2017-01-27 01:18:50 --> Output Class Initialized
INFO - 2017-01-27 01:18:50 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:50 --> Input Class Initialized
INFO - 2017-01-27 01:18:50 --> Language Class Initialized
INFO - 2017-01-27 01:18:50 --> Loader Class Initialized
INFO - 2017-01-27 01:18:50 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:50 --> Controller Class Initialized
INFO - 2017-01-27 01:18:50 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:50 --> Helper loaded: form_helper
INFO - 2017-01-27 01:18:50 --> Form Validation Class Initialized
INFO - 2017-01-27 01:18:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-27 01:18:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-27 01:18:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-27 01:18:50 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:50 --> Total execution time: 0.1701
INFO - 2017-01-27 01:18:51 --> Config Class Initialized
INFO - 2017-01-27 01:18:51 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:51 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:51 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:51 --> URI Class Initialized
INFO - 2017-01-27 01:18:51 --> Router Class Initialized
INFO - 2017-01-27 01:18:51 --> Output Class Initialized
INFO - 2017-01-27 01:18:51 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:51 --> Input Class Initialized
INFO - 2017-01-27 01:18:51 --> Language Class Initialized
INFO - 2017-01-27 01:18:51 --> Loader Class Initialized
INFO - 2017-01-27 01:18:51 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:51 --> Controller Class Initialized
INFO - 2017-01-27 01:18:51 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:18:51 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:51 --> Total execution time: 0.0568
INFO - 2017-01-27 01:18:59 --> Config Class Initialized
INFO - 2017-01-27 01:18:59 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:59 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:59 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:59 --> URI Class Initialized
INFO - 2017-01-27 01:18:59 --> Router Class Initialized
INFO - 2017-01-27 01:18:59 --> Output Class Initialized
INFO - 2017-01-27 01:18:59 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:59 --> Input Class Initialized
INFO - 2017-01-27 01:18:59 --> Language Class Initialized
INFO - 2017-01-27 01:18:59 --> Loader Class Initialized
INFO - 2017-01-27 01:18:59 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:59 --> Controller Class Initialized
INFO - 2017-01-27 01:18:59 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:59 --> Helper loaded: form_helper
INFO - 2017-01-27 01:18:59 --> Form Validation Class Initialized
INFO - 2017-01-27 01:18:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-27 01:18:59 --> Config Class Initialized
INFO - 2017-01-27 01:18:59 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:18:59 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:18:59 --> Utf8 Class Initialized
INFO - 2017-01-27 01:18:59 --> URI Class Initialized
INFO - 2017-01-27 01:18:59 --> Router Class Initialized
INFO - 2017-01-27 01:18:59 --> Output Class Initialized
INFO - 2017-01-27 01:18:59 --> Security Class Initialized
DEBUG - 2017-01-27 01:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:18:59 --> Input Class Initialized
INFO - 2017-01-27 01:18:59 --> Language Class Initialized
INFO - 2017-01-27 01:18:59 --> Loader Class Initialized
INFO - 2017-01-27 01:18:59 --> Database Driver Class Initialized
INFO - 2017-01-27 01:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:18:59 --> Controller Class Initialized
INFO - 2017-01-27 01:18:59 --> Helper loaded: date_helper
INFO - 2017-01-27 01:18:59 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:18:59 --> Helper loaded: form_helper
INFO - 2017-01-27 01:18:59 --> Form Validation Class Initialized
INFO - 2017-01-27 01:18:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-27 01:18:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-27 01:18:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-27 01:18:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-27 01:18:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-27 01:18:59 --> Final output sent to browser
DEBUG - 2017-01-27 01:18:59 --> Total execution time: 0.0837
INFO - 2017-01-27 01:19:00 --> Config Class Initialized
INFO - 2017-01-27 01:19:00 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:00 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:00 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:00 --> URI Class Initialized
INFO - 2017-01-27 01:19:00 --> Router Class Initialized
INFO - 2017-01-27 01:19:00 --> Output Class Initialized
INFO - 2017-01-27 01:19:00 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:00 --> Input Class Initialized
INFO - 2017-01-27 01:19:00 --> Language Class Initialized
INFO - 2017-01-27 01:19:00 --> Loader Class Initialized
INFO - 2017-01-27 01:19:00 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:00 --> Controller Class Initialized
INFO - 2017-01-27 01:19:00 --> Helper loaded: date_helper
INFO - 2017-01-27 01:19:00 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:00 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:00 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:00 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:00 --> Total execution time: 0.0148
INFO - 2017-01-27 01:19:00 --> Config Class Initialized
INFO - 2017-01-27 01:19:00 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:00 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:00 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:00 --> URI Class Initialized
INFO - 2017-01-27 01:19:00 --> Router Class Initialized
INFO - 2017-01-27 01:19:00 --> Output Class Initialized
INFO - 2017-01-27 01:19:00 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:00 --> Input Class Initialized
INFO - 2017-01-27 01:19:00 --> Language Class Initialized
INFO - 2017-01-27 01:19:00 --> Loader Class Initialized
INFO - 2017-01-27 01:19:00 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:00 --> Controller Class Initialized
INFO - 2017-01-27 01:19:00 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:19:00 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:00 --> Total execution time: 0.0139
INFO - 2017-01-27 01:19:04 --> Config Class Initialized
INFO - 2017-01-27 01:19:04 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:04 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:04 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:04 --> URI Class Initialized
INFO - 2017-01-27 01:19:04 --> Router Class Initialized
INFO - 2017-01-27 01:19:04 --> Output Class Initialized
INFO - 2017-01-27 01:19:04 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:04 --> Input Class Initialized
INFO - 2017-01-27 01:19:04 --> Language Class Initialized
INFO - 2017-01-27 01:19:04 --> Loader Class Initialized
INFO - 2017-01-27 01:19:04 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:04 --> Controller Class Initialized
INFO - 2017-01-27 01:19:04 --> Upload Class Initialized
INFO - 2017-01-27 01:19:04 --> Helper loaded: date_helper
INFO - 2017-01-27 01:19:04 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:04 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:04 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-27 01:19:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-27 01:19:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-27 01:19:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-27 01:19:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-27 01:19:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-27 01:19:04 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:04 --> Total execution time: 0.0695
INFO - 2017-01-27 01:19:05 --> Config Class Initialized
INFO - 2017-01-27 01:19:05 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:05 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:05 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:05 --> URI Class Initialized
INFO - 2017-01-27 01:19:05 --> Router Class Initialized
INFO - 2017-01-27 01:19:05 --> Output Class Initialized
INFO - 2017-01-27 01:19:05 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:05 --> Input Class Initialized
INFO - 2017-01-27 01:19:05 --> Language Class Initialized
INFO - 2017-01-27 01:19:05 --> Loader Class Initialized
INFO - 2017-01-27 01:19:05 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:05 --> Controller Class Initialized
INFO - 2017-01-27 01:19:05 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:19:05 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:05 --> Total execution time: 0.0138
INFO - 2017-01-27 01:19:07 --> Config Class Initialized
INFO - 2017-01-27 01:19:07 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:07 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:07 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:07 --> URI Class Initialized
INFO - 2017-01-27 01:19:07 --> Router Class Initialized
INFO - 2017-01-27 01:19:07 --> Output Class Initialized
INFO - 2017-01-27 01:19:07 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:07 --> Input Class Initialized
INFO - 2017-01-27 01:19:07 --> Language Class Initialized
INFO - 2017-01-27 01:19:07 --> Loader Class Initialized
INFO - 2017-01-27 01:19:07 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:07 --> Controller Class Initialized
INFO - 2017-01-27 01:19:07 --> Upload Class Initialized
INFO - 2017-01-27 01:19:07 --> Helper loaded: date_helper
INFO - 2017-01-27 01:19:07 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:07 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:07 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:07 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:07 --> Total execution time: 0.0409
INFO - 2017-01-27 01:19:14 --> Config Class Initialized
INFO - 2017-01-27 01:19:14 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:14 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:14 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:14 --> URI Class Initialized
INFO - 2017-01-27 01:19:14 --> Router Class Initialized
INFO - 2017-01-27 01:19:14 --> Output Class Initialized
INFO - 2017-01-27 01:19:14 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:14 --> Input Class Initialized
INFO - 2017-01-27 01:19:14 --> Language Class Initialized
INFO - 2017-01-27 01:19:14 --> Loader Class Initialized
INFO - 2017-01-27 01:19:14 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:14 --> Controller Class Initialized
INFO - 2017-01-27 01:19:14 --> Upload Class Initialized
INFO - 2017-01-27 01:19:14 --> Helper loaded: date_helper
INFO - 2017-01-27 01:19:14 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:14 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:14 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:14 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:14 --> Total execution time: 0.0296
INFO - 2017-01-27 01:19:15 --> Config Class Initialized
INFO - 2017-01-27 01:19:15 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:15 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:15 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:15 --> URI Class Initialized
INFO - 2017-01-27 01:19:15 --> Router Class Initialized
INFO - 2017-01-27 01:19:15 --> Output Class Initialized
INFO - 2017-01-27 01:19:15 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:15 --> Input Class Initialized
INFO - 2017-01-27 01:19:15 --> Language Class Initialized
INFO - 2017-01-27 01:19:15 --> Loader Class Initialized
INFO - 2017-01-27 01:19:15 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:15 --> Controller Class Initialized
INFO - 2017-01-27 01:19:15 --> Upload Class Initialized
INFO - 2017-01-27 01:19:15 --> Helper loaded: date_helper
INFO - 2017-01-27 01:19:15 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:15 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:15 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:15 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:15 --> Total execution time: 0.0156
INFO - 2017-01-27 01:19:50 --> Config Class Initialized
INFO - 2017-01-27 01:19:50 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:50 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:50 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:50 --> URI Class Initialized
INFO - 2017-01-27 01:19:50 --> Router Class Initialized
INFO - 2017-01-27 01:19:50 --> Output Class Initialized
INFO - 2017-01-27 01:19:50 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:50 --> Input Class Initialized
INFO - 2017-01-27 01:19:50 --> Language Class Initialized
INFO - 2017-01-27 01:19:50 --> Loader Class Initialized
INFO - 2017-01-27 01:19:50 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:50 --> Controller Class Initialized
INFO - 2017-01-27 01:19:50 --> Helper loaded: date_helper
INFO - 2017-01-27 01:19:50 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:50 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:50 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-27 01:19:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-27 01:19:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-27 01:19:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-27 01:19:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-27 01:19:50 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:50 --> Total execution time: 0.0149
INFO - 2017-01-27 01:19:51 --> Config Class Initialized
INFO - 2017-01-27 01:19:51 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:51 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:51 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:51 --> URI Class Initialized
INFO - 2017-01-27 01:19:51 --> Router Class Initialized
INFO - 2017-01-27 01:19:51 --> Output Class Initialized
INFO - 2017-01-27 01:19:51 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:51 --> Input Class Initialized
INFO - 2017-01-27 01:19:51 --> Language Class Initialized
INFO - 2017-01-27 01:19:51 --> Loader Class Initialized
INFO - 2017-01-27 01:19:51 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:51 --> Controller Class Initialized
INFO - 2017-01-27 01:19:51 --> Helper loaded: date_helper
INFO - 2017-01-27 01:19:51 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:51 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:51 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:51 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:51 --> Total execution time: 0.0149
INFO - 2017-01-27 01:19:51 --> Config Class Initialized
INFO - 2017-01-27 01:19:51 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:51 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:51 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:51 --> URI Class Initialized
INFO - 2017-01-27 01:19:51 --> Router Class Initialized
INFO - 2017-01-27 01:19:51 --> Output Class Initialized
INFO - 2017-01-27 01:19:51 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:51 --> Input Class Initialized
INFO - 2017-01-27 01:19:51 --> Language Class Initialized
INFO - 2017-01-27 01:19:51 --> Loader Class Initialized
INFO - 2017-01-27 01:19:51 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:51 --> Controller Class Initialized
INFO - 2017-01-27 01:19:51 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:19:51 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:51 --> Total execution time: 0.0135
INFO - 2017-01-27 01:19:53 --> Config Class Initialized
INFO - 2017-01-27 01:19:53 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:53 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:53 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:53 --> URI Class Initialized
INFO - 2017-01-27 01:19:53 --> Router Class Initialized
INFO - 2017-01-27 01:19:53 --> Output Class Initialized
INFO - 2017-01-27 01:19:53 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:53 --> Input Class Initialized
INFO - 2017-01-27 01:19:53 --> Language Class Initialized
INFO - 2017-01-27 01:19:53 --> Loader Class Initialized
INFO - 2017-01-27 01:19:53 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:53 --> Controller Class Initialized
INFO - 2017-01-27 01:19:53 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:53 --> Config Class Initialized
INFO - 2017-01-27 01:19:53 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:53 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:53 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:53 --> URI Class Initialized
INFO - 2017-01-27 01:19:53 --> Router Class Initialized
INFO - 2017-01-27 01:19:53 --> Output Class Initialized
INFO - 2017-01-27 01:19:53 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:53 --> Input Class Initialized
INFO - 2017-01-27 01:19:53 --> Language Class Initialized
INFO - 2017-01-27 01:19:53 --> Loader Class Initialized
INFO - 2017-01-27 01:19:53 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:53 --> Controller Class Initialized
INFO - 2017-01-27 01:19:53 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:53 --> Helper loaded: form_helper
INFO - 2017-01-27 01:19:53 --> Form Validation Class Initialized
INFO - 2017-01-27 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-27 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-27 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-27 01:19:53 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:53 --> Total execution time: 0.0132
INFO - 2017-01-27 01:19:54 --> Config Class Initialized
INFO - 2017-01-27 01:19:54 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:19:54 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:19:54 --> Utf8 Class Initialized
INFO - 2017-01-27 01:19:54 --> URI Class Initialized
INFO - 2017-01-27 01:19:54 --> Router Class Initialized
INFO - 2017-01-27 01:19:54 --> Output Class Initialized
INFO - 2017-01-27 01:19:54 --> Security Class Initialized
DEBUG - 2017-01-27 01:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:19:54 --> Input Class Initialized
INFO - 2017-01-27 01:19:54 --> Language Class Initialized
INFO - 2017-01-27 01:19:54 --> Loader Class Initialized
INFO - 2017-01-27 01:19:54 --> Database Driver Class Initialized
INFO - 2017-01-27 01:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:19:54 --> Controller Class Initialized
INFO - 2017-01-27 01:19:54 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:19:54 --> Final output sent to browser
DEBUG - 2017-01-27 01:19:54 --> Total execution time: 0.0141
INFO - 2017-01-27 01:27:48 --> Config Class Initialized
INFO - 2017-01-27 01:27:48 --> Hooks Class Initialized
DEBUG - 2017-01-27 01:27:48 --> UTF-8 Support Enabled
INFO - 2017-01-27 01:27:48 --> Utf8 Class Initialized
INFO - 2017-01-27 01:27:48 --> URI Class Initialized
DEBUG - 2017-01-27 01:27:48 --> No URI present. Default controller set.
INFO - 2017-01-27 01:27:48 --> Router Class Initialized
INFO - 2017-01-27 01:27:48 --> Output Class Initialized
INFO - 2017-01-27 01:27:48 --> Security Class Initialized
DEBUG - 2017-01-27 01:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 01:27:48 --> Input Class Initialized
INFO - 2017-01-27 01:27:48 --> Language Class Initialized
INFO - 2017-01-27 01:27:48 --> Loader Class Initialized
INFO - 2017-01-27 01:27:48 --> Database Driver Class Initialized
INFO - 2017-01-27 01:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 01:27:48 --> Controller Class Initialized
INFO - 2017-01-27 01:27:48 --> Helper loaded: url_helper
DEBUG - 2017-01-27 01:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 01:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 01:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 01:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 01:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 01:27:48 --> Final output sent to browser
DEBUG - 2017-01-27 01:27:48 --> Total execution time: 0.0133
INFO - 2017-01-27 03:19:32 --> Config Class Initialized
INFO - 2017-01-27 03:19:32 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:19:32 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:19:32 --> Utf8 Class Initialized
INFO - 2017-01-27 03:19:32 --> URI Class Initialized
INFO - 2017-01-27 03:19:32 --> Router Class Initialized
INFO - 2017-01-27 03:19:32 --> Output Class Initialized
INFO - 2017-01-27 03:19:32 --> Security Class Initialized
DEBUG - 2017-01-27 03:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:19:32 --> Input Class Initialized
INFO - 2017-01-27 03:19:32 --> Language Class Initialized
INFO - 2017-01-27 03:19:32 --> Loader Class Initialized
INFO - 2017-01-27 03:19:32 --> Database Driver Class Initialized
INFO - 2017-01-27 03:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:19:32 --> Controller Class Initialized
INFO - 2017-01-27 03:19:32 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:19:32 --> Final output sent to browser
DEBUG - 2017-01-27 03:19:32 --> Total execution time: 0.0134
INFO - 2017-01-27 03:19:32 --> Config Class Initialized
INFO - 2017-01-27 03:19:32 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:19:32 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:19:32 --> Utf8 Class Initialized
INFO - 2017-01-27 03:19:32 --> URI Class Initialized
INFO - 2017-01-27 03:19:32 --> Router Class Initialized
INFO - 2017-01-27 03:19:32 --> Output Class Initialized
INFO - 2017-01-27 03:19:32 --> Security Class Initialized
DEBUG - 2017-01-27 03:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:19:32 --> Input Class Initialized
INFO - 2017-01-27 03:19:32 --> Language Class Initialized
ERROR - 2017-01-27 03:19:32 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2017-01-27 03:29:55 --> Config Class Initialized
INFO - 2017-01-27 03:29:55 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:29:55 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:29:55 --> Utf8 Class Initialized
INFO - 2017-01-27 03:29:55 --> URI Class Initialized
DEBUG - 2017-01-27 03:29:55 --> No URI present. Default controller set.
INFO - 2017-01-27 03:29:55 --> Router Class Initialized
INFO - 2017-01-27 03:29:55 --> Output Class Initialized
INFO - 2017-01-27 03:29:55 --> Security Class Initialized
DEBUG - 2017-01-27 03:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:29:55 --> Input Class Initialized
INFO - 2017-01-27 03:29:55 --> Language Class Initialized
INFO - 2017-01-27 03:29:55 --> Loader Class Initialized
INFO - 2017-01-27 03:29:55 --> Database Driver Class Initialized
INFO - 2017-01-27 03:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:29:55 --> Controller Class Initialized
INFO - 2017-01-27 03:29:55 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:29:55 --> Final output sent to browser
DEBUG - 2017-01-27 03:29:55 --> Total execution time: 0.0135
INFO - 2017-01-27 03:30:25 --> Config Class Initialized
INFO - 2017-01-27 03:30:25 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:30:25 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:30:25 --> Utf8 Class Initialized
INFO - 2017-01-27 03:30:25 --> URI Class Initialized
INFO - 2017-01-27 03:30:25 --> Router Class Initialized
INFO - 2017-01-27 03:30:25 --> Output Class Initialized
INFO - 2017-01-27 03:30:25 --> Security Class Initialized
DEBUG - 2017-01-27 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:30:25 --> Input Class Initialized
INFO - 2017-01-27 03:30:25 --> Language Class Initialized
INFO - 2017-01-27 03:30:25 --> Loader Class Initialized
INFO - 2017-01-27 03:30:25 --> Database Driver Class Initialized
INFO - 2017-01-27 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:30:25 --> Controller Class Initialized
INFO - 2017-01-27 03:30:25 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-27 03:30:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-27 03:30:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-27 03:30:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-27 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:30:25 --> Final output sent to browser
DEBUG - 2017-01-27 03:30:25 --> Total execution time: 0.0143
INFO - 2017-01-27 03:30:48 --> Config Class Initialized
INFO - 2017-01-27 03:30:48 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:30:48 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:30:48 --> Utf8 Class Initialized
INFO - 2017-01-27 03:30:48 --> URI Class Initialized
INFO - 2017-01-27 03:30:48 --> Router Class Initialized
INFO - 2017-01-27 03:30:48 --> Output Class Initialized
INFO - 2017-01-27 03:30:48 --> Security Class Initialized
DEBUG - 2017-01-27 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:30:48 --> Input Class Initialized
INFO - 2017-01-27 03:30:48 --> Language Class Initialized
INFO - 2017-01-27 03:30:48 --> Loader Class Initialized
INFO - 2017-01-27 03:30:48 --> Database Driver Class Initialized
INFO - 2017-01-27 03:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:30:48 --> Controller Class Initialized
INFO - 2017-01-27 03:30:48 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:30:48 --> Final output sent to browser
DEBUG - 2017-01-27 03:30:48 --> Total execution time: 0.0142
INFO - 2017-01-27 03:31:03 --> Config Class Initialized
INFO - 2017-01-27 03:31:03 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:31:03 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:31:03 --> Utf8 Class Initialized
INFO - 2017-01-27 03:31:03 --> URI Class Initialized
INFO - 2017-01-27 03:31:03 --> Router Class Initialized
INFO - 2017-01-27 03:31:03 --> Output Class Initialized
INFO - 2017-01-27 03:31:03 --> Security Class Initialized
DEBUG - 2017-01-27 03:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:31:03 --> Input Class Initialized
INFO - 2017-01-27 03:31:03 --> Language Class Initialized
INFO - 2017-01-27 03:31:03 --> Loader Class Initialized
INFO - 2017-01-27 03:31:03 --> Database Driver Class Initialized
INFO - 2017-01-27 03:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:31:03 --> Controller Class Initialized
INFO - 2017-01-27 03:31:03 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:31:05 --> Config Class Initialized
INFO - 2017-01-27 03:31:05 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:31:05 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:31:05 --> Utf8 Class Initialized
INFO - 2017-01-27 03:31:05 --> URI Class Initialized
INFO - 2017-01-27 03:31:05 --> Router Class Initialized
INFO - 2017-01-27 03:31:05 --> Output Class Initialized
INFO - 2017-01-27 03:31:05 --> Security Class Initialized
DEBUG - 2017-01-27 03:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:31:05 --> Input Class Initialized
INFO - 2017-01-27 03:31:05 --> Language Class Initialized
INFO - 2017-01-27 03:31:05 --> Loader Class Initialized
INFO - 2017-01-27 03:31:05 --> Database Driver Class Initialized
INFO - 2017-01-27 03:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:31:05 --> Controller Class Initialized
INFO - 2017-01-27 03:31:05 --> Helper loaded: date_helper
DEBUG - 2017-01-27 03:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:31:05 --> Helper loaded: url_helper
INFO - 2017-01-27 03:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 03:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 03:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 03:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:31:05 --> Final output sent to browser
DEBUG - 2017-01-27 03:31:05 --> Total execution time: 0.0140
INFO - 2017-01-27 03:31:18 --> Config Class Initialized
INFO - 2017-01-27 03:31:18 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:31:18 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:31:18 --> Utf8 Class Initialized
INFO - 2017-01-27 03:31:18 --> URI Class Initialized
DEBUG - 2017-01-27 03:31:18 --> No URI present. Default controller set.
INFO - 2017-01-27 03:31:18 --> Router Class Initialized
INFO - 2017-01-27 03:31:18 --> Output Class Initialized
INFO - 2017-01-27 03:31:18 --> Security Class Initialized
DEBUG - 2017-01-27 03:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:31:18 --> Input Class Initialized
INFO - 2017-01-27 03:31:18 --> Language Class Initialized
INFO - 2017-01-27 03:31:18 --> Loader Class Initialized
INFO - 2017-01-27 03:31:18 --> Database Driver Class Initialized
INFO - 2017-01-27 03:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:31:18 --> Controller Class Initialized
INFO - 2017-01-27 03:31:18 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:31:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:31:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:31:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:31:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:31:18 --> Final output sent to browser
DEBUG - 2017-01-27 03:31:18 --> Total execution time: 0.0136
INFO - 2017-01-27 03:50:16 --> Config Class Initialized
INFO - 2017-01-27 03:50:16 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:50:16 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:50:16 --> Utf8 Class Initialized
INFO - 2017-01-27 03:50:16 --> URI Class Initialized
DEBUG - 2017-01-27 03:50:16 --> No URI present. Default controller set.
INFO - 2017-01-27 03:50:16 --> Router Class Initialized
INFO - 2017-01-27 03:50:16 --> Output Class Initialized
INFO - 2017-01-27 03:50:16 --> Security Class Initialized
DEBUG - 2017-01-27 03:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:50:16 --> Input Class Initialized
INFO - 2017-01-27 03:50:16 --> Language Class Initialized
INFO - 2017-01-27 03:50:16 --> Loader Class Initialized
INFO - 2017-01-27 03:50:16 --> Database Driver Class Initialized
INFO - 2017-01-27 03:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:50:16 --> Controller Class Initialized
INFO - 2017-01-27 03:50:16 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:50:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:50:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:50:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:50:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:50:16 --> Final output sent to browser
DEBUG - 2017-01-27 03:50:16 --> Total execution time: 0.0147
INFO - 2017-01-27 03:50:21 --> Config Class Initialized
INFO - 2017-01-27 03:50:21 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:50:21 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:50:21 --> Utf8 Class Initialized
INFO - 2017-01-27 03:50:21 --> URI Class Initialized
INFO - 2017-01-27 03:50:21 --> Router Class Initialized
INFO - 2017-01-27 03:50:21 --> Output Class Initialized
INFO - 2017-01-27 03:50:21 --> Security Class Initialized
DEBUG - 2017-01-27 03:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:50:21 --> Input Class Initialized
INFO - 2017-01-27 03:50:21 --> Language Class Initialized
INFO - 2017-01-27 03:50:21 --> Loader Class Initialized
INFO - 2017-01-27 03:50:21 --> Database Driver Class Initialized
INFO - 2017-01-27 03:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:50:21 --> Controller Class Initialized
INFO - 2017-01-27 03:50:21 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:50:21 --> Final output sent to browser
DEBUG - 2017-01-27 03:50:21 --> Total execution time: 0.0166
INFO - 2017-01-27 03:51:06 --> Config Class Initialized
INFO - 2017-01-27 03:51:06 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:51:06 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:51:06 --> Utf8 Class Initialized
INFO - 2017-01-27 03:51:06 --> URI Class Initialized
DEBUG - 2017-01-27 03:51:06 --> No URI present. Default controller set.
INFO - 2017-01-27 03:51:06 --> Router Class Initialized
INFO - 2017-01-27 03:51:06 --> Output Class Initialized
INFO - 2017-01-27 03:51:06 --> Security Class Initialized
DEBUG - 2017-01-27 03:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:51:06 --> Input Class Initialized
INFO - 2017-01-27 03:51:06 --> Language Class Initialized
INFO - 2017-01-27 03:51:06 --> Loader Class Initialized
INFO - 2017-01-27 03:51:06 --> Database Driver Class Initialized
INFO - 2017-01-27 03:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:51:06 --> Controller Class Initialized
INFO - 2017-01-27 03:51:06 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:51:06 --> Final output sent to browser
DEBUG - 2017-01-27 03:51:06 --> Total execution time: 0.0222
INFO - 2017-01-27 03:51:09 --> Config Class Initialized
INFO - 2017-01-27 03:51:09 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:51:09 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:51:09 --> Utf8 Class Initialized
INFO - 2017-01-27 03:51:09 --> URI Class Initialized
INFO - 2017-01-27 03:51:09 --> Router Class Initialized
INFO - 2017-01-27 03:51:09 --> Output Class Initialized
INFO - 2017-01-27 03:51:09 --> Security Class Initialized
DEBUG - 2017-01-27 03:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:51:09 --> Input Class Initialized
INFO - 2017-01-27 03:51:09 --> Language Class Initialized
INFO - 2017-01-27 03:51:09 --> Loader Class Initialized
INFO - 2017-01-27 03:51:09 --> Database Driver Class Initialized
INFO - 2017-01-27 03:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:51:09 --> Controller Class Initialized
INFO - 2017-01-27 03:51:09 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:51:09 --> Final output sent to browser
DEBUG - 2017-01-27 03:51:09 --> Total execution time: 0.0136
INFO - 2017-01-27 03:51:13 --> Config Class Initialized
INFO - 2017-01-27 03:51:13 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:51:13 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:51:13 --> Utf8 Class Initialized
INFO - 2017-01-27 03:51:13 --> URI Class Initialized
INFO - 2017-01-27 03:51:13 --> Router Class Initialized
INFO - 2017-01-27 03:51:13 --> Output Class Initialized
INFO - 2017-01-27 03:51:13 --> Security Class Initialized
DEBUG - 2017-01-27 03:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:51:13 --> Input Class Initialized
INFO - 2017-01-27 03:51:13 --> Language Class Initialized
INFO - 2017-01-27 03:51:13 --> Loader Class Initialized
INFO - 2017-01-27 03:51:13 --> Database Driver Class Initialized
INFO - 2017-01-27 03:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:51:13 --> Controller Class Initialized
INFO - 2017-01-27 03:51:13 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:51:13 --> Config Class Initialized
INFO - 2017-01-27 03:51:13 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:51:13 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:51:13 --> Utf8 Class Initialized
INFO - 2017-01-27 03:51:13 --> URI Class Initialized
INFO - 2017-01-27 03:51:13 --> Router Class Initialized
INFO - 2017-01-27 03:51:13 --> Output Class Initialized
INFO - 2017-01-27 03:51:13 --> Security Class Initialized
DEBUG - 2017-01-27 03:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:51:13 --> Input Class Initialized
INFO - 2017-01-27 03:51:13 --> Language Class Initialized
INFO - 2017-01-27 03:51:13 --> Loader Class Initialized
INFO - 2017-01-27 03:51:13 --> Database Driver Class Initialized
INFO - 2017-01-27 03:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:51:13 --> Controller Class Initialized
INFO - 2017-01-27 03:51:13 --> Helper loaded: date_helper
DEBUG - 2017-01-27 03:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:51:13 --> Helper loaded: url_helper
INFO - 2017-01-27 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:51:13 --> Final output sent to browser
DEBUG - 2017-01-27 03:51:13 --> Total execution time: 0.0139
INFO - 2017-01-27 03:51:14 --> Config Class Initialized
INFO - 2017-01-27 03:51:14 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:51:14 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:51:14 --> Utf8 Class Initialized
INFO - 2017-01-27 03:51:14 --> URI Class Initialized
INFO - 2017-01-27 03:51:14 --> Router Class Initialized
INFO - 2017-01-27 03:51:14 --> Output Class Initialized
INFO - 2017-01-27 03:51:14 --> Security Class Initialized
DEBUG - 2017-01-27 03:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:51:14 --> Input Class Initialized
INFO - 2017-01-27 03:51:14 --> Language Class Initialized
INFO - 2017-01-27 03:51:14 --> Loader Class Initialized
INFO - 2017-01-27 03:51:14 --> Database Driver Class Initialized
INFO - 2017-01-27 03:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:51:14 --> Controller Class Initialized
INFO - 2017-01-27 03:51:14 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:51:14 --> Final output sent to browser
DEBUG - 2017-01-27 03:51:14 --> Total execution time: 0.0133
INFO - 2017-01-27 03:51:23 --> Config Class Initialized
INFO - 2017-01-27 03:51:23 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:51:23 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:51:23 --> Utf8 Class Initialized
INFO - 2017-01-27 03:51:23 --> URI Class Initialized
DEBUG - 2017-01-27 03:51:23 --> No URI present. Default controller set.
INFO - 2017-01-27 03:51:23 --> Router Class Initialized
INFO - 2017-01-27 03:51:23 --> Output Class Initialized
INFO - 2017-01-27 03:51:23 --> Security Class Initialized
DEBUG - 2017-01-27 03:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:51:23 --> Input Class Initialized
INFO - 2017-01-27 03:51:23 --> Language Class Initialized
INFO - 2017-01-27 03:51:23 --> Loader Class Initialized
INFO - 2017-01-27 03:51:23 --> Database Driver Class Initialized
INFO - 2017-01-27 03:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:51:23 --> Controller Class Initialized
INFO - 2017-01-27 03:51:23 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:51:23 --> Final output sent to browser
DEBUG - 2017-01-27 03:51:23 --> Total execution time: 0.0132
INFO - 2017-01-27 03:51:25 --> Config Class Initialized
INFO - 2017-01-27 03:51:25 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:51:25 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:51:25 --> Utf8 Class Initialized
INFO - 2017-01-27 03:51:25 --> URI Class Initialized
INFO - 2017-01-27 03:51:25 --> Router Class Initialized
INFO - 2017-01-27 03:51:25 --> Output Class Initialized
INFO - 2017-01-27 03:51:25 --> Security Class Initialized
DEBUG - 2017-01-27 03:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:51:25 --> Input Class Initialized
INFO - 2017-01-27 03:51:25 --> Language Class Initialized
INFO - 2017-01-27 03:51:25 --> Loader Class Initialized
INFO - 2017-01-27 03:51:25 --> Database Driver Class Initialized
INFO - 2017-01-27 03:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:51:25 --> Controller Class Initialized
INFO - 2017-01-27 03:51:25 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:51:25 --> Final output sent to browser
DEBUG - 2017-01-27 03:51:25 --> Total execution time: 0.0133
INFO - 2017-01-27 03:52:08 --> Config Class Initialized
INFO - 2017-01-27 03:52:08 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:52:08 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:52:08 --> Utf8 Class Initialized
INFO - 2017-01-27 03:52:08 --> URI Class Initialized
INFO - 2017-01-27 03:52:08 --> Router Class Initialized
INFO - 2017-01-27 03:52:08 --> Output Class Initialized
INFO - 2017-01-27 03:52:08 --> Security Class Initialized
DEBUG - 2017-01-27 03:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:52:08 --> Input Class Initialized
INFO - 2017-01-27 03:52:08 --> Language Class Initialized
INFO - 2017-01-27 03:52:08 --> Loader Class Initialized
INFO - 2017-01-27 03:52:08 --> Database Driver Class Initialized
INFO - 2017-01-27 03:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:52:08 --> Controller Class Initialized
INFO - 2017-01-27 03:52:08 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:52:08 --> Final output sent to browser
DEBUG - 2017-01-27 03:52:08 --> Total execution time: 0.0142
INFO - 2017-01-27 03:52:09 --> Config Class Initialized
INFO - 2017-01-27 03:52:09 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:52:09 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:52:09 --> Utf8 Class Initialized
INFO - 2017-01-27 03:52:09 --> URI Class Initialized
INFO - 2017-01-27 03:52:09 --> Router Class Initialized
INFO - 2017-01-27 03:52:09 --> Output Class Initialized
INFO - 2017-01-27 03:52:09 --> Security Class Initialized
DEBUG - 2017-01-27 03:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:52:09 --> Input Class Initialized
INFO - 2017-01-27 03:52:09 --> Language Class Initialized
INFO - 2017-01-27 03:52:09 --> Loader Class Initialized
INFO - 2017-01-27 03:52:09 --> Database Driver Class Initialized
INFO - 2017-01-27 03:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:52:09 --> Controller Class Initialized
INFO - 2017-01-27 03:52:09 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:52:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:52:09 --> Final output sent to browser
DEBUG - 2017-01-27 03:52:09 --> Total execution time: 0.0136
INFO - 2017-01-27 03:52:59 --> Config Class Initialized
INFO - 2017-01-27 03:52:59 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:52:59 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:52:59 --> Utf8 Class Initialized
INFO - 2017-01-27 03:52:59 --> URI Class Initialized
DEBUG - 2017-01-27 03:52:59 --> No URI present. Default controller set.
INFO - 2017-01-27 03:52:59 --> Router Class Initialized
INFO - 2017-01-27 03:52:59 --> Output Class Initialized
INFO - 2017-01-27 03:52:59 --> Security Class Initialized
DEBUG - 2017-01-27 03:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:52:59 --> Input Class Initialized
INFO - 2017-01-27 03:52:59 --> Language Class Initialized
INFO - 2017-01-27 03:52:59 --> Loader Class Initialized
INFO - 2017-01-27 03:52:59 --> Database Driver Class Initialized
INFO - 2017-01-27 03:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:52:59 --> Controller Class Initialized
INFO - 2017-01-27 03:52:59 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:52:59 --> Final output sent to browser
DEBUG - 2017-01-27 03:52:59 --> Total execution time: 0.0135
INFO - 2017-01-27 03:53:00 --> Config Class Initialized
INFO - 2017-01-27 03:53:00 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:53:00 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:53:00 --> Utf8 Class Initialized
INFO - 2017-01-27 03:53:00 --> URI Class Initialized
INFO - 2017-01-27 03:53:00 --> Router Class Initialized
INFO - 2017-01-27 03:53:00 --> Output Class Initialized
INFO - 2017-01-27 03:53:00 --> Security Class Initialized
DEBUG - 2017-01-27 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:53:00 --> Input Class Initialized
INFO - 2017-01-27 03:53:00 --> Language Class Initialized
INFO - 2017-01-27 03:53:00 --> Loader Class Initialized
INFO - 2017-01-27 03:53:00 --> Database Driver Class Initialized
INFO - 2017-01-27 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:53:00 --> Controller Class Initialized
INFO - 2017-01-27 03:53:00 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:53:00 --> Final output sent to browser
DEBUG - 2017-01-27 03:53:00 --> Total execution time: 0.0149
INFO - 2017-01-27 03:56:10 --> Config Class Initialized
INFO - 2017-01-27 03:56:10 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:56:10 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:56:10 --> Utf8 Class Initialized
INFO - 2017-01-27 03:56:10 --> URI Class Initialized
DEBUG - 2017-01-27 03:56:10 --> No URI present. Default controller set.
INFO - 2017-01-27 03:56:10 --> Router Class Initialized
INFO - 2017-01-27 03:56:10 --> Output Class Initialized
INFO - 2017-01-27 03:56:10 --> Security Class Initialized
DEBUG - 2017-01-27 03:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:56:10 --> Input Class Initialized
INFO - 2017-01-27 03:56:10 --> Language Class Initialized
INFO - 2017-01-27 03:56:10 --> Loader Class Initialized
INFO - 2017-01-27 03:56:11 --> Database Driver Class Initialized
INFO - 2017-01-27 03:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:56:11 --> Controller Class Initialized
INFO - 2017-01-27 03:56:11 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:56:11 --> Final output sent to browser
DEBUG - 2017-01-27 03:56:11 --> Total execution time: 0.0142
INFO - 2017-01-27 03:56:14 --> Config Class Initialized
INFO - 2017-01-27 03:56:14 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:56:14 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:56:14 --> Utf8 Class Initialized
INFO - 2017-01-27 03:56:14 --> URI Class Initialized
INFO - 2017-01-27 03:56:14 --> Router Class Initialized
INFO - 2017-01-27 03:56:14 --> Output Class Initialized
INFO - 2017-01-27 03:56:14 --> Security Class Initialized
DEBUG - 2017-01-27 03:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:56:14 --> Input Class Initialized
INFO - 2017-01-27 03:56:14 --> Language Class Initialized
INFO - 2017-01-27 03:56:14 --> Loader Class Initialized
INFO - 2017-01-27 03:56:14 --> Database Driver Class Initialized
INFO - 2017-01-27 03:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:56:14 --> Controller Class Initialized
INFO - 2017-01-27 03:56:14 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:56:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:56:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:56:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:56:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:56:14 --> Final output sent to browser
DEBUG - 2017-01-27 03:56:14 --> Total execution time: 0.0144
INFO - 2017-01-27 03:56:58 --> Config Class Initialized
INFO - 2017-01-27 03:56:58 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:56:58 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:56:58 --> Utf8 Class Initialized
INFO - 2017-01-27 03:56:58 --> URI Class Initialized
DEBUG - 2017-01-27 03:56:58 --> No URI present. Default controller set.
INFO - 2017-01-27 03:56:58 --> Router Class Initialized
INFO - 2017-01-27 03:56:58 --> Output Class Initialized
INFO - 2017-01-27 03:56:58 --> Security Class Initialized
DEBUG - 2017-01-27 03:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:56:58 --> Input Class Initialized
INFO - 2017-01-27 03:56:58 --> Language Class Initialized
INFO - 2017-01-27 03:56:58 --> Loader Class Initialized
INFO - 2017-01-27 03:56:58 --> Database Driver Class Initialized
INFO - 2017-01-27 03:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:56:58 --> Controller Class Initialized
INFO - 2017-01-27 03:56:58 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:56:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:56:58 --> Final output sent to browser
DEBUG - 2017-01-27 03:56:58 --> Total execution time: 0.0134
INFO - 2017-01-27 03:57:02 --> Config Class Initialized
INFO - 2017-01-27 03:57:02 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:57:02 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:57:02 --> Utf8 Class Initialized
INFO - 2017-01-27 03:57:02 --> URI Class Initialized
INFO - 2017-01-27 03:57:02 --> Router Class Initialized
INFO - 2017-01-27 03:57:02 --> Output Class Initialized
INFO - 2017-01-27 03:57:02 --> Security Class Initialized
DEBUG - 2017-01-27 03:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:57:02 --> Input Class Initialized
INFO - 2017-01-27 03:57:02 --> Language Class Initialized
INFO - 2017-01-27 03:57:02 --> Loader Class Initialized
INFO - 2017-01-27 03:57:02 --> Database Driver Class Initialized
INFO - 2017-01-27 03:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:57:02 --> Controller Class Initialized
INFO - 2017-01-27 03:57:02 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:57:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:57:02 --> Final output sent to browser
DEBUG - 2017-01-27 03:57:02 --> Total execution time: 0.0135
INFO - 2017-01-27 03:57:55 --> Config Class Initialized
INFO - 2017-01-27 03:57:55 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:57:55 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:57:55 --> Utf8 Class Initialized
INFO - 2017-01-27 03:57:55 --> URI Class Initialized
INFO - 2017-01-27 03:57:55 --> Router Class Initialized
INFO - 2017-01-27 03:57:55 --> Output Class Initialized
INFO - 2017-01-27 03:57:55 --> Security Class Initialized
DEBUG - 2017-01-27 03:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:57:55 --> Input Class Initialized
INFO - 2017-01-27 03:57:55 --> Language Class Initialized
INFO - 2017-01-27 03:57:55 --> Loader Class Initialized
INFO - 2017-01-27 03:57:55 --> Database Driver Class Initialized
INFO - 2017-01-27 03:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:57:55 --> Controller Class Initialized
INFO - 2017-01-27 03:57:55 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:57:56 --> Config Class Initialized
INFO - 2017-01-27 03:57:56 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:57:56 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:57:56 --> Utf8 Class Initialized
INFO - 2017-01-27 03:57:56 --> URI Class Initialized
INFO - 2017-01-27 03:57:56 --> Router Class Initialized
INFO - 2017-01-27 03:57:56 --> Output Class Initialized
INFO - 2017-01-27 03:57:56 --> Security Class Initialized
DEBUG - 2017-01-27 03:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:57:56 --> Input Class Initialized
INFO - 2017-01-27 03:57:56 --> Language Class Initialized
INFO - 2017-01-27 03:57:56 --> Loader Class Initialized
INFO - 2017-01-27 03:57:56 --> Database Driver Class Initialized
INFO - 2017-01-27 03:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:57:56 --> Controller Class Initialized
INFO - 2017-01-27 03:57:56 --> Helper loaded: date_helper
DEBUG - 2017-01-27 03:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:57:56 --> Helper loaded: url_helper
INFO - 2017-01-27 03:57:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:57:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 03:57:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 03:57:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 03:57:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:57:56 --> Final output sent to browser
DEBUG - 2017-01-27 03:57:56 --> Total execution time: 0.0135
INFO - 2017-01-27 03:57:58 --> Config Class Initialized
INFO - 2017-01-27 03:57:58 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:57:58 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:57:58 --> Utf8 Class Initialized
INFO - 2017-01-27 03:57:58 --> URI Class Initialized
INFO - 2017-01-27 03:57:58 --> Router Class Initialized
INFO - 2017-01-27 03:57:58 --> Output Class Initialized
INFO - 2017-01-27 03:57:58 --> Security Class Initialized
DEBUG - 2017-01-27 03:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:57:58 --> Input Class Initialized
INFO - 2017-01-27 03:57:58 --> Language Class Initialized
INFO - 2017-01-27 03:57:58 --> Loader Class Initialized
INFO - 2017-01-27 03:57:58 --> Database Driver Class Initialized
INFO - 2017-01-27 03:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:57:58 --> Controller Class Initialized
INFO - 2017-01-27 03:57:58 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:57:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:57:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:57:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:57:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:57:58 --> Final output sent to browser
DEBUG - 2017-01-27 03:57:58 --> Total execution time: 0.0137
INFO - 2017-01-27 03:58:13 --> Config Class Initialized
INFO - 2017-01-27 03:58:13 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:58:13 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:58:13 --> Utf8 Class Initialized
INFO - 2017-01-27 03:58:13 --> URI Class Initialized
DEBUG - 2017-01-27 03:58:13 --> No URI present. Default controller set.
INFO - 2017-01-27 03:58:13 --> Router Class Initialized
INFO - 2017-01-27 03:58:13 --> Output Class Initialized
INFO - 2017-01-27 03:58:13 --> Security Class Initialized
DEBUG - 2017-01-27 03:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:58:13 --> Input Class Initialized
INFO - 2017-01-27 03:58:13 --> Language Class Initialized
INFO - 2017-01-27 03:58:13 --> Loader Class Initialized
INFO - 2017-01-27 03:58:13 --> Database Driver Class Initialized
INFO - 2017-01-27 03:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:58:13 --> Controller Class Initialized
INFO - 2017-01-27 03:58:13 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:58:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:58:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:58:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:58:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:58:13 --> Final output sent to browser
DEBUG - 2017-01-27 03:58:13 --> Total execution time: 0.0139
INFO - 2017-01-27 03:58:15 --> Config Class Initialized
INFO - 2017-01-27 03:58:15 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:58:15 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:58:15 --> Utf8 Class Initialized
INFO - 2017-01-27 03:58:15 --> URI Class Initialized
INFO - 2017-01-27 03:58:15 --> Router Class Initialized
INFO - 2017-01-27 03:58:15 --> Output Class Initialized
INFO - 2017-01-27 03:58:15 --> Security Class Initialized
DEBUG - 2017-01-27 03:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:58:15 --> Input Class Initialized
INFO - 2017-01-27 03:58:15 --> Language Class Initialized
INFO - 2017-01-27 03:58:16 --> Loader Class Initialized
INFO - 2017-01-27 03:58:16 --> Database Driver Class Initialized
INFO - 2017-01-27 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:58:16 --> Controller Class Initialized
INFO - 2017-01-27 03:58:16 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:58:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:58:16 --> Final output sent to browser
DEBUG - 2017-01-27 03:58:16 --> Total execution time: 0.0146
INFO - 2017-01-27 03:59:00 --> Config Class Initialized
INFO - 2017-01-27 03:59:00 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:59:00 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:59:00 --> Utf8 Class Initialized
INFO - 2017-01-27 03:59:00 --> URI Class Initialized
INFO - 2017-01-27 03:59:00 --> Router Class Initialized
INFO - 2017-01-27 03:59:00 --> Output Class Initialized
INFO - 2017-01-27 03:59:00 --> Security Class Initialized
DEBUG - 2017-01-27 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:59:00 --> Input Class Initialized
INFO - 2017-01-27 03:59:00 --> Language Class Initialized
INFO - 2017-01-27 03:59:00 --> Loader Class Initialized
INFO - 2017-01-27 03:59:00 --> Database Driver Class Initialized
INFO - 2017-01-27 03:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:59:00 --> Controller Class Initialized
INFO - 2017-01-27 03:59:00 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:59:00 --> Helper loaded: form_helper
INFO - 2017-01-27 03:59:00 --> Form Validation Class Initialized
INFO - 2017-01-27 03:59:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-27 03:59:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-27 03:59:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-27 03:59:00 --> Final output sent to browser
DEBUG - 2017-01-27 03:59:00 --> Total execution time: 0.0130
INFO - 2017-01-27 03:59:00 --> Config Class Initialized
INFO - 2017-01-27 03:59:00 --> Hooks Class Initialized
DEBUG - 2017-01-27 03:59:00 --> UTF-8 Support Enabled
INFO - 2017-01-27 03:59:00 --> Utf8 Class Initialized
INFO - 2017-01-27 03:59:00 --> URI Class Initialized
INFO - 2017-01-27 03:59:00 --> Router Class Initialized
INFO - 2017-01-27 03:59:00 --> Output Class Initialized
INFO - 2017-01-27 03:59:00 --> Security Class Initialized
DEBUG - 2017-01-27 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 03:59:00 --> Input Class Initialized
INFO - 2017-01-27 03:59:00 --> Language Class Initialized
INFO - 2017-01-27 03:59:00 --> Loader Class Initialized
INFO - 2017-01-27 03:59:00 --> Database Driver Class Initialized
INFO - 2017-01-27 03:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 03:59:00 --> Controller Class Initialized
INFO - 2017-01-27 03:59:00 --> Helper loaded: url_helper
DEBUG - 2017-01-27 03:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 03:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 03:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 03:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 03:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 03:59:00 --> Final output sent to browser
DEBUG - 2017-01-27 03:59:00 --> Total execution time: 0.0152
INFO - 2017-01-27 04:00:04 --> Config Class Initialized
INFO - 2017-01-27 04:00:04 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:00:04 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:00:04 --> Utf8 Class Initialized
INFO - 2017-01-27 04:00:04 --> URI Class Initialized
DEBUG - 2017-01-27 04:00:04 --> No URI present. Default controller set.
INFO - 2017-01-27 04:00:04 --> Router Class Initialized
INFO - 2017-01-27 04:00:04 --> Output Class Initialized
INFO - 2017-01-27 04:00:04 --> Security Class Initialized
DEBUG - 2017-01-27 04:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:00:04 --> Input Class Initialized
INFO - 2017-01-27 04:00:04 --> Language Class Initialized
INFO - 2017-01-27 04:00:04 --> Loader Class Initialized
INFO - 2017-01-27 04:00:04 --> Database Driver Class Initialized
INFO - 2017-01-27 04:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:00:04 --> Controller Class Initialized
INFO - 2017-01-27 04:00:04 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:00:04 --> Final output sent to browser
DEBUG - 2017-01-27 04:00:04 --> Total execution time: 0.0137
INFO - 2017-01-27 04:00:10 --> Config Class Initialized
INFO - 2017-01-27 04:00:10 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:00:10 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:00:10 --> Utf8 Class Initialized
INFO - 2017-01-27 04:00:10 --> URI Class Initialized
INFO - 2017-01-27 04:00:10 --> Router Class Initialized
INFO - 2017-01-27 04:00:10 --> Output Class Initialized
INFO - 2017-01-27 04:00:10 --> Security Class Initialized
DEBUG - 2017-01-27 04:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:00:10 --> Input Class Initialized
INFO - 2017-01-27 04:00:10 --> Language Class Initialized
INFO - 2017-01-27 04:00:10 --> Loader Class Initialized
INFO - 2017-01-27 04:00:10 --> Database Driver Class Initialized
INFO - 2017-01-27 04:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:00:10 --> Controller Class Initialized
INFO - 2017-01-27 04:00:10 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:00:10 --> Final output sent to browser
DEBUG - 2017-01-27 04:00:10 --> Total execution time: 0.0139
INFO - 2017-01-27 04:00:57 --> Config Class Initialized
INFO - 2017-01-27 04:00:57 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:00:57 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:00:57 --> Utf8 Class Initialized
INFO - 2017-01-27 04:00:57 --> URI Class Initialized
INFO - 2017-01-27 04:00:57 --> Router Class Initialized
INFO - 2017-01-27 04:00:57 --> Output Class Initialized
INFO - 2017-01-27 04:00:57 --> Security Class Initialized
DEBUG - 2017-01-27 04:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:00:57 --> Input Class Initialized
INFO - 2017-01-27 04:00:57 --> Language Class Initialized
INFO - 2017-01-27 04:00:57 --> Loader Class Initialized
INFO - 2017-01-27 04:00:57 --> Database Driver Class Initialized
INFO - 2017-01-27 04:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:00:57 --> Controller Class Initialized
INFO - 2017-01-27 04:00:57 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:00:58 --> Config Class Initialized
INFO - 2017-01-27 04:00:58 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:00:58 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:00:58 --> Utf8 Class Initialized
INFO - 2017-01-27 04:00:58 --> URI Class Initialized
INFO - 2017-01-27 04:00:58 --> Router Class Initialized
INFO - 2017-01-27 04:00:58 --> Output Class Initialized
INFO - 2017-01-27 04:00:58 --> Security Class Initialized
DEBUG - 2017-01-27 04:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:00:58 --> Input Class Initialized
INFO - 2017-01-27 04:00:58 --> Language Class Initialized
INFO - 2017-01-27 04:00:58 --> Loader Class Initialized
INFO - 2017-01-27 04:00:58 --> Database Driver Class Initialized
INFO - 2017-01-27 04:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:00:58 --> Controller Class Initialized
INFO - 2017-01-27 04:00:58 --> Helper loaded: date_helper
DEBUG - 2017-01-27 04:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:00:58 --> Helper loaded: url_helper
INFO - 2017-01-27 04:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 04:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 04:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 04:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:00:58 --> Final output sent to browser
DEBUG - 2017-01-27 04:00:58 --> Total execution time: 0.0140
INFO - 2017-01-27 04:01:00 --> Config Class Initialized
INFO - 2017-01-27 04:01:00 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:01:00 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:01:00 --> Utf8 Class Initialized
INFO - 2017-01-27 04:01:00 --> URI Class Initialized
INFO - 2017-01-27 04:01:00 --> Router Class Initialized
INFO - 2017-01-27 04:01:00 --> Output Class Initialized
INFO - 2017-01-27 04:01:00 --> Security Class Initialized
DEBUG - 2017-01-27 04:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:01:00 --> Input Class Initialized
INFO - 2017-01-27 04:01:00 --> Language Class Initialized
INFO - 2017-01-27 04:01:00 --> Loader Class Initialized
INFO - 2017-01-27 04:01:00 --> Database Driver Class Initialized
INFO - 2017-01-27 04:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:01:00 --> Controller Class Initialized
INFO - 2017-01-27 04:01:00 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:01:00 --> Final output sent to browser
DEBUG - 2017-01-27 04:01:00 --> Total execution time: 0.0142
INFO - 2017-01-27 04:12:56 --> Config Class Initialized
INFO - 2017-01-27 04:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:12:56 --> Utf8 Class Initialized
INFO - 2017-01-27 04:12:56 --> URI Class Initialized
DEBUG - 2017-01-27 04:12:56 --> No URI present. Default controller set.
INFO - 2017-01-27 04:12:56 --> Router Class Initialized
INFO - 2017-01-27 04:12:56 --> Output Class Initialized
INFO - 2017-01-27 04:12:56 --> Security Class Initialized
DEBUG - 2017-01-27 04:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:12:56 --> Input Class Initialized
INFO - 2017-01-27 04:12:56 --> Language Class Initialized
INFO - 2017-01-27 04:12:56 --> Loader Class Initialized
INFO - 2017-01-27 04:12:56 --> Database Driver Class Initialized
INFO - 2017-01-27 04:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:12:56 --> Controller Class Initialized
INFO - 2017-01-27 04:12:56 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:12:56 --> Final output sent to browser
DEBUG - 2017-01-27 04:12:56 --> Total execution time: 0.0131
INFO - 2017-01-27 04:13:05 --> Config Class Initialized
INFO - 2017-01-27 04:13:05 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:05 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:05 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:05 --> URI Class Initialized
INFO - 2017-01-27 04:13:05 --> Router Class Initialized
INFO - 2017-01-27 04:13:05 --> Output Class Initialized
INFO - 2017-01-27 04:13:05 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:05 --> Input Class Initialized
INFO - 2017-01-27 04:13:05 --> Language Class Initialized
INFO - 2017-01-27 04:13:05 --> Loader Class Initialized
INFO - 2017-01-27 04:13:05 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:05 --> Controller Class Initialized
INFO - 2017-01-27 04:13:05 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:05 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:05 --> Total execution time: 0.0137
INFO - 2017-01-27 04:13:23 --> Config Class Initialized
INFO - 2017-01-27 04:13:23 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:23 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:23 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:23 --> URI Class Initialized
INFO - 2017-01-27 04:13:23 --> Router Class Initialized
INFO - 2017-01-27 04:13:23 --> Output Class Initialized
INFO - 2017-01-27 04:13:23 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:23 --> Input Class Initialized
INFO - 2017-01-27 04:13:23 --> Language Class Initialized
INFO - 2017-01-27 04:13:23 --> Loader Class Initialized
INFO - 2017-01-27 04:13:23 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:23 --> Controller Class Initialized
INFO - 2017-01-27 04:13:23 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:25 --> Config Class Initialized
INFO - 2017-01-27 04:13:25 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:25 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:25 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:25 --> URI Class Initialized
INFO - 2017-01-27 04:13:25 --> Router Class Initialized
INFO - 2017-01-27 04:13:25 --> Output Class Initialized
INFO - 2017-01-27 04:13:25 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:25 --> Input Class Initialized
INFO - 2017-01-27 04:13:25 --> Language Class Initialized
INFO - 2017-01-27 04:13:25 --> Loader Class Initialized
INFO - 2017-01-27 04:13:25 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:25 --> Controller Class Initialized
INFO - 2017-01-27 04:13:25 --> Helper loaded: date_helper
DEBUG - 2017-01-27 04:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:25 --> Helper loaded: url_helper
INFO - 2017-01-27 04:13:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 04:13:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 04:13:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 04:13:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:25 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:25 --> Total execution time: 0.0137
INFO - 2017-01-27 04:13:26 --> Config Class Initialized
INFO - 2017-01-27 04:13:26 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:26 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:26 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:26 --> URI Class Initialized
INFO - 2017-01-27 04:13:26 --> Router Class Initialized
INFO - 2017-01-27 04:13:26 --> Output Class Initialized
INFO - 2017-01-27 04:13:26 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:26 --> Input Class Initialized
INFO - 2017-01-27 04:13:26 --> Language Class Initialized
INFO - 2017-01-27 04:13:26 --> Loader Class Initialized
INFO - 2017-01-27 04:13:26 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:26 --> Controller Class Initialized
INFO - 2017-01-27 04:13:26 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:26 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:26 --> Total execution time: 0.0139
INFO - 2017-01-27 04:13:36 --> Config Class Initialized
INFO - 2017-01-27 04:13:36 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:36 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:36 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:36 --> URI Class Initialized
DEBUG - 2017-01-27 04:13:36 --> No URI present. Default controller set.
INFO - 2017-01-27 04:13:36 --> Router Class Initialized
INFO - 2017-01-27 04:13:36 --> Output Class Initialized
INFO - 2017-01-27 04:13:36 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:36 --> Input Class Initialized
INFO - 2017-01-27 04:13:36 --> Language Class Initialized
INFO - 2017-01-27 04:13:36 --> Loader Class Initialized
INFO - 2017-01-27 04:13:36 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:36 --> Controller Class Initialized
INFO - 2017-01-27 04:13:36 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:13:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:36 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:36 --> Total execution time: 0.0133
INFO - 2017-01-27 04:13:37 --> Config Class Initialized
INFO - 2017-01-27 04:13:37 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:37 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:37 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:37 --> URI Class Initialized
INFO - 2017-01-27 04:13:37 --> Router Class Initialized
INFO - 2017-01-27 04:13:37 --> Output Class Initialized
INFO - 2017-01-27 04:13:37 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:37 --> Input Class Initialized
INFO - 2017-01-27 04:13:37 --> Language Class Initialized
INFO - 2017-01-27 04:13:37 --> Loader Class Initialized
INFO - 2017-01-27 04:13:38 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:38 --> Controller Class Initialized
INFO - 2017-01-27 04:13:38 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:38 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:38 --> Total execution time: 0.0132
INFO - 2017-01-27 04:13:48 --> Config Class Initialized
INFO - 2017-01-27 04:13:48 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:48 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:48 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:48 --> URI Class Initialized
DEBUG - 2017-01-27 04:13:48 --> No URI present. Default controller set.
INFO - 2017-01-27 04:13:48 --> Router Class Initialized
INFO - 2017-01-27 04:13:48 --> Output Class Initialized
INFO - 2017-01-27 04:13:48 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:48 --> Input Class Initialized
INFO - 2017-01-27 04:13:48 --> Language Class Initialized
INFO - 2017-01-27 04:13:48 --> Loader Class Initialized
INFO - 2017-01-27 04:13:48 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:48 --> Controller Class Initialized
INFO - 2017-01-27 04:13:48 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:48 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:48 --> Total execution time: 0.0214
INFO - 2017-01-27 04:13:50 --> Config Class Initialized
INFO - 2017-01-27 04:13:50 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:50 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:50 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:50 --> URI Class Initialized
INFO - 2017-01-27 04:13:50 --> Router Class Initialized
INFO - 2017-01-27 04:13:50 --> Output Class Initialized
INFO - 2017-01-27 04:13:50 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:50 --> Input Class Initialized
INFO - 2017-01-27 04:13:50 --> Language Class Initialized
INFO - 2017-01-27 04:13:50 --> Loader Class Initialized
INFO - 2017-01-27 04:13:50 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:50 --> Controller Class Initialized
INFO - 2017-01-27 04:13:50 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:52 --> Config Class Initialized
INFO - 2017-01-27 04:13:52 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:52 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:52 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:52 --> URI Class Initialized
INFO - 2017-01-27 04:13:52 --> Router Class Initialized
INFO - 2017-01-27 04:13:52 --> Output Class Initialized
INFO - 2017-01-27 04:13:52 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:52 --> Input Class Initialized
INFO - 2017-01-27 04:13:52 --> Language Class Initialized
INFO - 2017-01-27 04:13:52 --> Loader Class Initialized
INFO - 2017-01-27 04:13:52 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:52 --> Controller Class Initialized
INFO - 2017-01-27 04:13:52 --> Helper loaded: date_helper
DEBUG - 2017-01-27 04:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:52 --> Helper loaded: url_helper
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:52 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:52 --> Total execution time: 0.0175
INFO - 2017-01-27 04:13:52 --> Config Class Initialized
INFO - 2017-01-27 04:13:52 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:52 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:52 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:52 --> URI Class Initialized
INFO - 2017-01-27 04:13:52 --> Router Class Initialized
INFO - 2017-01-27 04:13:52 --> Output Class Initialized
INFO - 2017-01-27 04:13:52 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:52 --> Input Class Initialized
INFO - 2017-01-27 04:13:52 --> Language Class Initialized
INFO - 2017-01-27 04:13:52 --> Loader Class Initialized
INFO - 2017-01-27 04:13:52 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:52 --> Controller Class Initialized
INFO - 2017-01-27 04:13:52 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:52 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:52 --> Total execution time: 0.0151
INFO - 2017-01-27 04:13:55 --> Config Class Initialized
INFO - 2017-01-27 04:13:55 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:13:55 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:13:55 --> Utf8 Class Initialized
INFO - 2017-01-27 04:13:55 --> URI Class Initialized
INFO - 2017-01-27 04:13:55 --> Router Class Initialized
INFO - 2017-01-27 04:13:55 --> Output Class Initialized
INFO - 2017-01-27 04:13:55 --> Security Class Initialized
DEBUG - 2017-01-27 04:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:13:55 --> Input Class Initialized
INFO - 2017-01-27 04:13:55 --> Language Class Initialized
INFO - 2017-01-27 04:13:55 --> Loader Class Initialized
INFO - 2017-01-27 04:13:55 --> Database Driver Class Initialized
INFO - 2017-01-27 04:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:13:55 --> Controller Class Initialized
INFO - 2017-01-27 04:13:55 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:13:55 --> Final output sent to browser
DEBUG - 2017-01-27 04:13:55 --> Total execution time: 0.0136
INFO - 2017-01-27 04:15:27 --> Config Class Initialized
INFO - 2017-01-27 04:15:27 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:27 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:27 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:27 --> URI Class Initialized
INFO - 2017-01-27 04:15:27 --> Router Class Initialized
INFO - 2017-01-27 04:15:27 --> Output Class Initialized
INFO - 2017-01-27 04:15:27 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:27 --> Input Class Initialized
INFO - 2017-01-27 04:15:27 --> Language Class Initialized
INFO - 2017-01-27 04:15:27 --> Loader Class Initialized
INFO - 2017-01-27 04:15:28 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:28 --> Controller Class Initialized
INFO - 2017-01-27 04:15:28 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:28 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:28 --> Total execution time: 0.0145
INFO - 2017-01-27 04:15:31 --> Config Class Initialized
INFO - 2017-01-27 04:15:31 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:31 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:31 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:31 --> URI Class Initialized
INFO - 2017-01-27 04:15:31 --> Router Class Initialized
INFO - 2017-01-27 04:15:31 --> Output Class Initialized
INFO - 2017-01-27 04:15:31 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:31 --> Input Class Initialized
INFO - 2017-01-27 04:15:31 --> Language Class Initialized
INFO - 2017-01-27 04:15:31 --> Loader Class Initialized
INFO - 2017-01-27 04:15:31 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:31 --> Controller Class Initialized
INFO - 2017-01-27 04:15:31 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:31 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:31 --> Total execution time: 0.0143
INFO - 2017-01-27 04:15:33 --> Config Class Initialized
INFO - 2017-01-27 04:15:33 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:33 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:33 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:33 --> URI Class Initialized
DEBUG - 2017-01-27 04:15:33 --> No URI present. Default controller set.
INFO - 2017-01-27 04:15:33 --> Router Class Initialized
INFO - 2017-01-27 04:15:33 --> Output Class Initialized
INFO - 2017-01-27 04:15:33 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:33 --> Input Class Initialized
INFO - 2017-01-27 04:15:33 --> Language Class Initialized
INFO - 2017-01-27 04:15:33 --> Loader Class Initialized
INFO - 2017-01-27 04:15:33 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:33 --> Controller Class Initialized
INFO - 2017-01-27 04:15:33 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:33 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:33 --> Total execution time: 0.0142
INFO - 2017-01-27 04:15:34 --> Config Class Initialized
INFO - 2017-01-27 04:15:34 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:34 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:34 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:34 --> URI Class Initialized
INFO - 2017-01-27 04:15:34 --> Router Class Initialized
INFO - 2017-01-27 04:15:34 --> Output Class Initialized
INFO - 2017-01-27 04:15:34 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:34 --> Input Class Initialized
INFO - 2017-01-27 04:15:34 --> Language Class Initialized
INFO - 2017-01-27 04:15:34 --> Loader Class Initialized
INFO - 2017-01-27 04:15:34 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:34 --> Controller Class Initialized
INFO - 2017-01-27 04:15:34 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:34 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:34 --> Total execution time: 0.0134
INFO - 2017-01-27 04:15:38 --> Config Class Initialized
INFO - 2017-01-27 04:15:38 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:38 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:38 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:38 --> URI Class Initialized
DEBUG - 2017-01-27 04:15:38 --> No URI present. Default controller set.
INFO - 2017-01-27 04:15:38 --> Router Class Initialized
INFO - 2017-01-27 04:15:38 --> Output Class Initialized
INFO - 2017-01-27 04:15:38 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:38 --> Input Class Initialized
INFO - 2017-01-27 04:15:38 --> Language Class Initialized
INFO - 2017-01-27 04:15:38 --> Loader Class Initialized
INFO - 2017-01-27 04:15:38 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:38 --> Controller Class Initialized
INFO - 2017-01-27 04:15:38 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:38 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:38 --> Total execution time: 0.0132
INFO - 2017-01-27 04:15:50 --> Config Class Initialized
INFO - 2017-01-27 04:15:50 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:50 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:50 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:50 --> URI Class Initialized
DEBUG - 2017-01-27 04:15:50 --> No URI present. Default controller set.
INFO - 2017-01-27 04:15:50 --> Router Class Initialized
INFO - 2017-01-27 04:15:50 --> Output Class Initialized
INFO - 2017-01-27 04:15:50 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:50 --> Input Class Initialized
INFO - 2017-01-27 04:15:50 --> Language Class Initialized
INFO - 2017-01-27 04:15:50 --> Loader Class Initialized
INFO - 2017-01-27 04:15:50 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:50 --> Controller Class Initialized
INFO - 2017-01-27 04:15:50 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:50 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:50 --> Total execution time: 0.0140
INFO - 2017-01-27 04:15:51 --> Config Class Initialized
INFO - 2017-01-27 04:15:51 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:51 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:51 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:51 --> URI Class Initialized
INFO - 2017-01-27 04:15:51 --> Router Class Initialized
INFO - 2017-01-27 04:15:51 --> Output Class Initialized
INFO - 2017-01-27 04:15:51 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:51 --> Input Class Initialized
INFO - 2017-01-27 04:15:51 --> Language Class Initialized
INFO - 2017-01-27 04:15:51 --> Loader Class Initialized
INFO - 2017-01-27 04:15:51 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:51 --> Controller Class Initialized
INFO - 2017-01-27 04:15:51 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:52 --> Config Class Initialized
INFO - 2017-01-27 04:15:52 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:52 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:52 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:52 --> URI Class Initialized
INFO - 2017-01-27 04:15:52 --> Router Class Initialized
INFO - 2017-01-27 04:15:52 --> Output Class Initialized
INFO - 2017-01-27 04:15:52 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:52 --> Input Class Initialized
INFO - 2017-01-27 04:15:52 --> Language Class Initialized
INFO - 2017-01-27 04:15:52 --> Loader Class Initialized
INFO - 2017-01-27 04:15:52 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:52 --> Controller Class Initialized
INFO - 2017-01-27 04:15:52 --> Helper loaded: date_helper
DEBUG - 2017-01-27 04:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:52 --> Helper loaded: url_helper
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:52 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:52 --> Total execution time: 0.0142
INFO - 2017-01-27 04:15:52 --> Config Class Initialized
INFO - 2017-01-27 04:15:52 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:52 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:52 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:52 --> URI Class Initialized
INFO - 2017-01-27 04:15:52 --> Router Class Initialized
INFO - 2017-01-27 04:15:52 --> Output Class Initialized
INFO - 2017-01-27 04:15:52 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:52 --> Input Class Initialized
INFO - 2017-01-27 04:15:52 --> Language Class Initialized
INFO - 2017-01-27 04:15:52 --> Loader Class Initialized
INFO - 2017-01-27 04:15:52 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:52 --> Controller Class Initialized
INFO - 2017-01-27 04:15:52 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:52 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:52 --> Total execution time: 0.0137
INFO - 2017-01-27 04:15:53 --> Config Class Initialized
INFO - 2017-01-27 04:15:53 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:53 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:53 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:53 --> URI Class Initialized
INFO - 2017-01-27 04:15:53 --> Router Class Initialized
INFO - 2017-01-27 04:15:53 --> Output Class Initialized
INFO - 2017-01-27 04:15:54 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:54 --> Input Class Initialized
INFO - 2017-01-27 04:15:54 --> Language Class Initialized
INFO - 2017-01-27 04:15:54 --> Loader Class Initialized
INFO - 2017-01-27 04:15:54 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:54 --> Controller Class Initialized
INFO - 2017-01-27 04:15:54 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:54 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:54 --> Total execution time: 0.0534
INFO - 2017-01-27 04:15:55 --> Config Class Initialized
INFO - 2017-01-27 04:15:55 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:55 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:55 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:55 --> URI Class Initialized
DEBUG - 2017-01-27 04:15:55 --> No URI present. Default controller set.
INFO - 2017-01-27 04:15:55 --> Router Class Initialized
INFO - 2017-01-27 04:15:55 --> Output Class Initialized
INFO - 2017-01-27 04:15:55 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:55 --> Input Class Initialized
INFO - 2017-01-27 04:15:55 --> Language Class Initialized
INFO - 2017-01-27 04:15:55 --> Loader Class Initialized
INFO - 2017-01-27 04:15:55 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:55 --> Controller Class Initialized
INFO - 2017-01-27 04:15:55 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:55 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:55 --> Total execution time: 0.0178
INFO - 2017-01-27 04:15:56 --> Config Class Initialized
INFO - 2017-01-27 04:15:56 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:15:56 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:15:56 --> Utf8 Class Initialized
INFO - 2017-01-27 04:15:56 --> URI Class Initialized
INFO - 2017-01-27 04:15:56 --> Router Class Initialized
INFO - 2017-01-27 04:15:56 --> Output Class Initialized
INFO - 2017-01-27 04:15:56 --> Security Class Initialized
DEBUG - 2017-01-27 04:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:15:56 --> Input Class Initialized
INFO - 2017-01-27 04:15:56 --> Language Class Initialized
INFO - 2017-01-27 04:15:56 --> Loader Class Initialized
INFO - 2017-01-27 04:15:56 --> Database Driver Class Initialized
INFO - 2017-01-27 04:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:15:56 --> Controller Class Initialized
INFO - 2017-01-27 04:15:56 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:15:56 --> Final output sent to browser
DEBUG - 2017-01-27 04:15:56 --> Total execution time: 0.0140
INFO - 2017-01-27 04:22:31 --> Config Class Initialized
INFO - 2017-01-27 04:22:31 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:22:31 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:22:31 --> Utf8 Class Initialized
INFO - 2017-01-27 04:22:31 --> URI Class Initialized
DEBUG - 2017-01-27 04:22:31 --> No URI present. Default controller set.
INFO - 2017-01-27 04:22:31 --> Router Class Initialized
INFO - 2017-01-27 04:22:31 --> Output Class Initialized
INFO - 2017-01-27 04:22:31 --> Security Class Initialized
DEBUG - 2017-01-27 04:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:22:31 --> Input Class Initialized
INFO - 2017-01-27 04:22:31 --> Language Class Initialized
INFO - 2017-01-27 04:22:31 --> Loader Class Initialized
INFO - 2017-01-27 04:22:31 --> Database Driver Class Initialized
INFO - 2017-01-27 04:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:22:31 --> Controller Class Initialized
INFO - 2017-01-27 04:22:31 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:22:31 --> Final output sent to browser
DEBUG - 2017-01-27 04:22:31 --> Total execution time: 0.0132
INFO - 2017-01-27 04:22:37 --> Config Class Initialized
INFO - 2017-01-27 04:22:37 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:22:37 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:22:37 --> Utf8 Class Initialized
INFO - 2017-01-27 04:22:37 --> URI Class Initialized
INFO - 2017-01-27 04:22:37 --> Router Class Initialized
INFO - 2017-01-27 04:22:37 --> Output Class Initialized
INFO - 2017-01-27 04:22:37 --> Security Class Initialized
DEBUG - 2017-01-27 04:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:22:37 --> Input Class Initialized
INFO - 2017-01-27 04:22:37 --> Language Class Initialized
INFO - 2017-01-27 04:22:37 --> Loader Class Initialized
INFO - 2017-01-27 04:22:37 --> Database Driver Class Initialized
INFO - 2017-01-27 04:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:22:37 --> Controller Class Initialized
INFO - 2017-01-27 04:22:37 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:22:37 --> Final output sent to browser
DEBUG - 2017-01-27 04:22:37 --> Total execution time: 0.0131
INFO - 2017-01-27 04:23:53 --> Config Class Initialized
INFO - 2017-01-27 04:23:53 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:23:53 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:23:53 --> Utf8 Class Initialized
INFO - 2017-01-27 04:23:53 --> URI Class Initialized
INFO - 2017-01-27 04:23:53 --> Router Class Initialized
INFO - 2017-01-27 04:23:53 --> Output Class Initialized
INFO - 2017-01-27 04:23:53 --> Security Class Initialized
DEBUG - 2017-01-27 04:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:23:53 --> Input Class Initialized
INFO - 2017-01-27 04:23:53 --> Language Class Initialized
INFO - 2017-01-27 04:23:53 --> Loader Class Initialized
INFO - 2017-01-27 04:23:53 --> Database Driver Class Initialized
INFO - 2017-01-27 04:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:23:53 --> Controller Class Initialized
INFO - 2017-01-27 04:23:53 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:23:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-27 04:23:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-27 04:23:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-01-27 04:23:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-27 04:23:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-27 04:23:55 --> Config Class Initialized
INFO - 2017-01-27 04:23:55 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:23:55 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:23:55 --> Utf8 Class Initialized
INFO - 2017-01-27 04:23:55 --> URI Class Initialized
INFO - 2017-01-27 04:23:55 --> Router Class Initialized
INFO - 2017-01-27 04:23:55 --> Output Class Initialized
INFO - 2017-01-27 04:23:55 --> Security Class Initialized
DEBUG - 2017-01-27 04:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:23:55 --> Input Class Initialized
INFO - 2017-01-27 04:23:55 --> Language Class Initialized
INFO - 2017-01-27 04:23:55 --> Loader Class Initialized
INFO - 2017-01-27 04:23:55 --> Database Driver Class Initialized
INFO - 2017-01-27 04:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:23:55 --> Controller Class Initialized
INFO - 2017-01-27 04:23:55 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:23:55 --> Final output sent to browser
DEBUG - 2017-01-27 04:23:55 --> Total execution time: 0.0136
INFO - 2017-01-27 04:24:31 --> Config Class Initialized
INFO - 2017-01-27 04:24:31 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:24:31 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:24:31 --> Utf8 Class Initialized
INFO - 2017-01-27 04:24:31 --> URI Class Initialized
DEBUG - 2017-01-27 04:24:31 --> No URI present. Default controller set.
INFO - 2017-01-27 04:24:31 --> Router Class Initialized
INFO - 2017-01-27 04:24:31 --> Output Class Initialized
INFO - 2017-01-27 04:24:31 --> Security Class Initialized
DEBUG - 2017-01-27 04:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:24:31 --> Input Class Initialized
INFO - 2017-01-27 04:24:31 --> Language Class Initialized
INFO - 2017-01-27 04:24:31 --> Loader Class Initialized
INFO - 2017-01-27 04:24:31 --> Database Driver Class Initialized
INFO - 2017-01-27 04:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:24:31 --> Controller Class Initialized
INFO - 2017-01-27 04:24:31 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:24:31 --> Final output sent to browser
DEBUG - 2017-01-27 04:24:31 --> Total execution time: 0.0131
INFO - 2017-01-27 04:24:35 --> Config Class Initialized
INFO - 2017-01-27 04:24:35 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:24:35 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:24:35 --> Utf8 Class Initialized
INFO - 2017-01-27 04:24:35 --> URI Class Initialized
INFO - 2017-01-27 04:24:35 --> Router Class Initialized
INFO - 2017-01-27 04:24:35 --> Output Class Initialized
INFO - 2017-01-27 04:24:35 --> Security Class Initialized
DEBUG - 2017-01-27 04:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:24:35 --> Input Class Initialized
INFO - 2017-01-27 04:24:35 --> Language Class Initialized
INFO - 2017-01-27 04:24:35 --> Loader Class Initialized
INFO - 2017-01-27 04:24:35 --> Database Driver Class Initialized
INFO - 2017-01-27 04:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:24:35 --> Controller Class Initialized
INFO - 2017-01-27 04:24:35 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:24:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:24:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:24:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:24:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:24:35 --> Final output sent to browser
DEBUG - 2017-01-27 04:24:35 --> Total execution time: 0.0134
INFO - 2017-01-27 04:24:37 --> Config Class Initialized
INFO - 2017-01-27 04:24:37 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:24:37 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:24:37 --> Utf8 Class Initialized
INFO - 2017-01-27 04:24:37 --> URI Class Initialized
INFO - 2017-01-27 04:24:37 --> Router Class Initialized
INFO - 2017-01-27 04:24:37 --> Output Class Initialized
INFO - 2017-01-27 04:24:37 --> Security Class Initialized
DEBUG - 2017-01-27 04:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:24:37 --> Input Class Initialized
INFO - 2017-01-27 04:24:37 --> Language Class Initialized
INFO - 2017-01-27 04:24:37 --> Loader Class Initialized
INFO - 2017-01-27 04:24:37 --> Database Driver Class Initialized
INFO - 2017-01-27 04:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:24:37 --> Controller Class Initialized
INFO - 2017-01-27 04:24:37 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:24:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-27 04:24:38 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-27 04:24:38 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-01-27 04:24:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-27 04:24:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-27 04:24:39 --> Config Class Initialized
INFO - 2017-01-27 04:24:39 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:24:39 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:24:39 --> Utf8 Class Initialized
INFO - 2017-01-27 04:24:39 --> URI Class Initialized
INFO - 2017-01-27 04:24:39 --> Router Class Initialized
INFO - 2017-01-27 04:24:39 --> Output Class Initialized
INFO - 2017-01-27 04:24:39 --> Security Class Initialized
DEBUG - 2017-01-27 04:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:24:39 --> Input Class Initialized
INFO - 2017-01-27 04:24:39 --> Language Class Initialized
INFO - 2017-01-27 04:24:39 --> Loader Class Initialized
INFO - 2017-01-27 04:24:39 --> Database Driver Class Initialized
INFO - 2017-01-27 04:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:24:39 --> Controller Class Initialized
INFO - 2017-01-27 04:24:39 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:24:39 --> Final output sent to browser
DEBUG - 2017-01-27 04:24:39 --> Total execution time: 0.0135
INFO - 2017-01-27 04:24:40 --> Config Class Initialized
INFO - 2017-01-27 04:24:40 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:24:40 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:24:40 --> Utf8 Class Initialized
INFO - 2017-01-27 04:24:40 --> URI Class Initialized
INFO - 2017-01-27 04:24:40 --> Router Class Initialized
INFO - 2017-01-27 04:24:40 --> Output Class Initialized
INFO - 2017-01-27 04:24:40 --> Security Class Initialized
DEBUG - 2017-01-27 04:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:24:40 --> Input Class Initialized
INFO - 2017-01-27 04:24:40 --> Language Class Initialized
INFO - 2017-01-27 04:24:40 --> Loader Class Initialized
INFO - 2017-01-27 04:24:40 --> Database Driver Class Initialized
INFO - 2017-01-27 04:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:24:40 --> Controller Class Initialized
INFO - 2017-01-27 04:24:40 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:24:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-27 04:24:41 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-27 04:24:41 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-01-27 04:24:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-27 04:24:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-27 04:24:41 --> Config Class Initialized
INFO - 2017-01-27 04:24:41 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:24:41 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:24:41 --> Utf8 Class Initialized
INFO - 2017-01-27 04:24:41 --> URI Class Initialized
INFO - 2017-01-27 04:24:41 --> Router Class Initialized
INFO - 2017-01-27 04:24:41 --> Output Class Initialized
INFO - 2017-01-27 04:24:41 --> Security Class Initialized
DEBUG - 2017-01-27 04:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:24:41 --> Input Class Initialized
INFO - 2017-01-27 04:24:41 --> Language Class Initialized
INFO - 2017-01-27 04:24:41 --> Loader Class Initialized
INFO - 2017-01-27 04:24:41 --> Database Driver Class Initialized
INFO - 2017-01-27 04:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:24:41 --> Controller Class Initialized
INFO - 2017-01-27 04:24:41 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:24:41 --> Final output sent to browser
DEBUG - 2017-01-27 04:24:41 --> Total execution time: 0.0133
INFO - 2017-01-27 04:36:58 --> Config Class Initialized
INFO - 2017-01-27 04:36:58 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:36:58 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:36:58 --> Utf8 Class Initialized
INFO - 2017-01-27 04:36:58 --> URI Class Initialized
DEBUG - 2017-01-27 04:36:58 --> No URI present. Default controller set.
INFO - 2017-01-27 04:36:58 --> Router Class Initialized
INFO - 2017-01-27 04:36:58 --> Output Class Initialized
INFO - 2017-01-27 04:36:58 --> Security Class Initialized
DEBUG - 2017-01-27 04:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:36:58 --> Input Class Initialized
INFO - 2017-01-27 04:36:58 --> Language Class Initialized
INFO - 2017-01-27 04:36:58 --> Loader Class Initialized
INFO - 2017-01-27 04:36:58 --> Database Driver Class Initialized
INFO - 2017-01-27 04:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:36:58 --> Controller Class Initialized
INFO - 2017-01-27 04:36:58 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:36:58 --> Final output sent to browser
DEBUG - 2017-01-27 04:36:58 --> Total execution time: 0.0136
INFO - 2017-01-27 04:37:03 --> Config Class Initialized
INFO - 2017-01-27 04:37:03 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:37:03 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:37:03 --> Utf8 Class Initialized
INFO - 2017-01-27 04:37:03 --> URI Class Initialized
INFO - 2017-01-27 04:37:03 --> Router Class Initialized
INFO - 2017-01-27 04:37:03 --> Output Class Initialized
INFO - 2017-01-27 04:37:03 --> Security Class Initialized
DEBUG - 2017-01-27 04:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:37:03 --> Input Class Initialized
INFO - 2017-01-27 04:37:03 --> Language Class Initialized
INFO - 2017-01-27 04:37:03 --> Loader Class Initialized
INFO - 2017-01-27 04:37:03 --> Database Driver Class Initialized
INFO - 2017-01-27 04:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:37:03 --> Controller Class Initialized
INFO - 2017-01-27 04:37:03 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:37:03 --> Final output sent to browser
DEBUG - 2017-01-27 04:37:03 --> Total execution time: 0.0134
INFO - 2017-01-27 04:37:46 --> Config Class Initialized
INFO - 2017-01-27 04:37:46 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:37:46 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:37:46 --> Utf8 Class Initialized
INFO - 2017-01-27 04:37:46 --> URI Class Initialized
INFO - 2017-01-27 04:37:46 --> Router Class Initialized
INFO - 2017-01-27 04:37:46 --> Output Class Initialized
INFO - 2017-01-27 04:37:46 --> Security Class Initialized
DEBUG - 2017-01-27 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:37:46 --> Input Class Initialized
INFO - 2017-01-27 04:37:46 --> Language Class Initialized
INFO - 2017-01-27 04:37:46 --> Loader Class Initialized
INFO - 2017-01-27 04:37:46 --> Database Driver Class Initialized
INFO - 2017-01-27 04:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:37:46 --> Controller Class Initialized
INFO - 2017-01-27 04:37:46 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-27 04:37:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-27 04:37:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-27 04:37:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-27 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:37:46 --> Final output sent to browser
DEBUG - 2017-01-27 04:37:46 --> Total execution time: 0.0325
INFO - 2017-01-27 04:37:49 --> Config Class Initialized
INFO - 2017-01-27 04:37:49 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:37:49 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:37:49 --> Utf8 Class Initialized
INFO - 2017-01-27 04:37:49 --> URI Class Initialized
INFO - 2017-01-27 04:37:49 --> Router Class Initialized
INFO - 2017-01-27 04:37:49 --> Output Class Initialized
INFO - 2017-01-27 04:37:49 --> Security Class Initialized
DEBUG - 2017-01-27 04:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:37:49 --> Input Class Initialized
INFO - 2017-01-27 04:37:49 --> Language Class Initialized
INFO - 2017-01-27 04:37:49 --> Loader Class Initialized
INFO - 2017-01-27 04:37:49 --> Database Driver Class Initialized
INFO - 2017-01-27 04:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:37:49 --> Controller Class Initialized
INFO - 2017-01-27 04:37:49 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:37:49 --> Final output sent to browser
DEBUG - 2017-01-27 04:37:49 --> Total execution time: 0.0134
INFO - 2017-01-27 04:38:07 --> Config Class Initialized
INFO - 2017-01-27 04:38:07 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:07 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:07 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:07 --> URI Class Initialized
INFO - 2017-01-27 04:38:07 --> Router Class Initialized
INFO - 2017-01-27 04:38:07 --> Output Class Initialized
INFO - 2017-01-27 04:38:07 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:07 --> Input Class Initialized
INFO - 2017-01-27 04:38:07 --> Language Class Initialized
INFO - 2017-01-27 04:38:07 --> Loader Class Initialized
INFO - 2017-01-27 04:38:07 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:07 --> Controller Class Initialized
INFO - 2017-01-27 04:38:07 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:08 --> Config Class Initialized
INFO - 2017-01-27 04:38:08 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:08 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:08 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:08 --> URI Class Initialized
INFO - 2017-01-27 04:38:08 --> Router Class Initialized
INFO - 2017-01-27 04:38:08 --> Output Class Initialized
INFO - 2017-01-27 04:38:08 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:08 --> Input Class Initialized
INFO - 2017-01-27 04:38:08 --> Language Class Initialized
INFO - 2017-01-27 04:38:08 --> Loader Class Initialized
INFO - 2017-01-27 04:38:08 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:08 --> Controller Class Initialized
INFO - 2017-01-27 04:38:08 --> Helper loaded: date_helper
DEBUG - 2017-01-27 04:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:08 --> Helper loaded: url_helper
INFO - 2017-01-27 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 04:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:38:08 --> Final output sent to browser
DEBUG - 2017-01-27 04:38:08 --> Total execution time: 0.0136
INFO - 2017-01-27 04:38:09 --> Config Class Initialized
INFO - 2017-01-27 04:38:09 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:09 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:09 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:09 --> URI Class Initialized
INFO - 2017-01-27 04:38:09 --> Router Class Initialized
INFO - 2017-01-27 04:38:09 --> Output Class Initialized
INFO - 2017-01-27 04:38:09 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:09 --> Input Class Initialized
INFO - 2017-01-27 04:38:09 --> Language Class Initialized
INFO - 2017-01-27 04:38:09 --> Loader Class Initialized
INFO - 2017-01-27 04:38:09 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:09 --> Controller Class Initialized
INFO - 2017-01-27 04:38:09 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:38:09 --> Final output sent to browser
DEBUG - 2017-01-27 04:38:09 --> Total execution time: 0.0139
INFO - 2017-01-27 04:38:19 --> Config Class Initialized
INFO - 2017-01-27 04:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:19 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:19 --> URI Class Initialized
INFO - 2017-01-27 04:38:19 --> Router Class Initialized
INFO - 2017-01-27 04:38:19 --> Output Class Initialized
INFO - 2017-01-27 04:38:19 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:19 --> Input Class Initialized
INFO - 2017-01-27 04:38:19 --> Language Class Initialized
INFO - 2017-01-27 04:38:19 --> Loader Class Initialized
INFO - 2017-01-27 04:38:19 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:19 --> Controller Class Initialized
INFO - 2017-01-27 04:38:19 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:19 --> Config Class Initialized
INFO - 2017-01-27 04:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:19 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:19 --> URI Class Initialized
INFO - 2017-01-27 04:38:19 --> Router Class Initialized
INFO - 2017-01-27 04:38:19 --> Output Class Initialized
INFO - 2017-01-27 04:38:19 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:19 --> Input Class Initialized
INFO - 2017-01-27 04:38:19 --> Language Class Initialized
INFO - 2017-01-27 04:38:19 --> Loader Class Initialized
INFO - 2017-01-27 04:38:19 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:19 --> Controller Class Initialized
INFO - 2017-01-27 04:38:19 --> Helper loaded: date_helper
DEBUG - 2017-01-27 04:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:19 --> Helper loaded: url_helper
INFO - 2017-01-27 04:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 04:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 04:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 04:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:38:19 --> Final output sent to browser
DEBUG - 2017-01-27 04:38:19 --> Total execution time: 0.0144
INFO - 2017-01-27 04:38:20 --> Config Class Initialized
INFO - 2017-01-27 04:38:20 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:20 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:20 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:20 --> URI Class Initialized
INFO - 2017-01-27 04:38:20 --> Router Class Initialized
INFO - 2017-01-27 04:38:20 --> Output Class Initialized
INFO - 2017-01-27 04:38:20 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:20 --> Input Class Initialized
INFO - 2017-01-27 04:38:20 --> Language Class Initialized
INFO - 2017-01-27 04:38:20 --> Loader Class Initialized
INFO - 2017-01-27 04:38:20 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:20 --> Controller Class Initialized
INFO - 2017-01-27 04:38:20 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:38:20 --> Final output sent to browser
DEBUG - 2017-01-27 04:38:20 --> Total execution time: 0.0143
INFO - 2017-01-27 04:38:25 --> Config Class Initialized
INFO - 2017-01-27 04:38:25 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:25 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:25 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:25 --> URI Class Initialized
INFO - 2017-01-27 04:38:25 --> Router Class Initialized
INFO - 2017-01-27 04:38:25 --> Output Class Initialized
INFO - 2017-01-27 04:38:25 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:25 --> Input Class Initialized
INFO - 2017-01-27 04:38:25 --> Language Class Initialized
INFO - 2017-01-27 04:38:25 --> Loader Class Initialized
INFO - 2017-01-27 04:38:25 --> Config Class Initialized
INFO - 2017-01-27 04:38:25 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:38:25 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:38:25 --> Utf8 Class Initialized
INFO - 2017-01-27 04:38:25 --> URI Class Initialized
DEBUG - 2017-01-27 04:38:25 --> No URI present. Default controller set.
INFO - 2017-01-27 04:38:25 --> Router Class Initialized
INFO - 2017-01-27 04:38:25 --> Output Class Initialized
INFO - 2017-01-27 04:38:25 --> Security Class Initialized
DEBUG - 2017-01-27 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:38:25 --> Input Class Initialized
INFO - 2017-01-27 04:38:25 --> Language Class Initialized
INFO - 2017-01-27 04:38:25 --> Loader Class Initialized
INFO - 2017-01-27 04:38:25 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:25 --> Database Driver Class Initialized
INFO - 2017-01-27 04:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:26 --> Controller Class Initialized
INFO - 2017-01-27 04:38:26 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:38:26 --> Controller Class Initialized
INFO - 2017-01-27 04:38:26 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:38:26 --> Final output sent to browser
DEBUG - 2017-01-27 04:38:26 --> Total execution time: 0.0636
INFO - 2017-01-27 04:42:59 --> Config Class Initialized
INFO - 2017-01-27 04:42:59 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:42:59 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:42:59 --> Utf8 Class Initialized
INFO - 2017-01-27 04:42:59 --> URI Class Initialized
INFO - 2017-01-27 04:42:59 --> Router Class Initialized
INFO - 2017-01-27 04:42:59 --> Output Class Initialized
INFO - 2017-01-27 04:42:59 --> Security Class Initialized
DEBUG - 2017-01-27 04:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:42:59 --> Input Class Initialized
INFO - 2017-01-27 04:42:59 --> Language Class Initialized
INFO - 2017-01-27 04:42:59 --> Loader Class Initialized
INFO - 2017-01-27 04:42:59 --> Database Driver Class Initialized
INFO - 2017-01-27 04:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:42:59 --> Controller Class Initialized
INFO - 2017-01-27 04:42:59 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:42:59 --> Final output sent to browser
DEBUG - 2017-01-27 04:42:59 --> Total execution time: 0.0136
INFO - 2017-01-27 04:42:59 --> Config Class Initialized
INFO - 2017-01-27 04:42:59 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:42:59 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:42:59 --> Utf8 Class Initialized
INFO - 2017-01-27 04:42:59 --> URI Class Initialized
INFO - 2017-01-27 04:42:59 --> Router Class Initialized
INFO - 2017-01-27 04:42:59 --> Output Class Initialized
INFO - 2017-01-27 04:42:59 --> Security Class Initialized
DEBUG - 2017-01-27 04:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:42:59 --> Input Class Initialized
INFO - 2017-01-27 04:42:59 --> Language Class Initialized
ERROR - 2017-01-27 04:42:59 --> 404 Page Not Found: Well-known/apple-app-site-association
INFO - 2017-01-27 04:57:33 --> Config Class Initialized
INFO - 2017-01-27 04:57:33 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:57:33 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:57:33 --> Utf8 Class Initialized
INFO - 2017-01-27 04:57:33 --> URI Class Initialized
INFO - 2017-01-27 04:57:33 --> Router Class Initialized
INFO - 2017-01-27 04:57:33 --> Output Class Initialized
INFO - 2017-01-27 04:57:33 --> Security Class Initialized
DEBUG - 2017-01-27 04:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:57:33 --> Input Class Initialized
INFO - 2017-01-27 04:57:33 --> Language Class Initialized
INFO - 2017-01-27 04:57:33 --> Loader Class Initialized
INFO - 2017-01-27 04:57:33 --> Database Driver Class Initialized
INFO - 2017-01-27 04:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:57:33 --> Controller Class Initialized
INFO - 2017-01-27 04:57:33 --> Helper loaded: date_helper
DEBUG - 2017-01-27 04:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:57:33 --> Helper loaded: url_helper
INFO - 2017-01-27 04:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 04:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 04:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 04:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:57:33 --> Final output sent to browser
DEBUG - 2017-01-27 04:57:33 --> Total execution time: 0.0160
INFO - 2017-01-27 04:57:38 --> Config Class Initialized
INFO - 2017-01-27 04:57:38 --> Hooks Class Initialized
DEBUG - 2017-01-27 04:57:38 --> UTF-8 Support Enabled
INFO - 2017-01-27 04:57:38 --> Utf8 Class Initialized
INFO - 2017-01-27 04:57:38 --> URI Class Initialized
INFO - 2017-01-27 04:57:38 --> Router Class Initialized
INFO - 2017-01-27 04:57:38 --> Output Class Initialized
INFO - 2017-01-27 04:57:38 --> Security Class Initialized
DEBUG - 2017-01-27 04:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 04:57:38 --> Input Class Initialized
INFO - 2017-01-27 04:57:38 --> Language Class Initialized
INFO - 2017-01-27 04:57:38 --> Loader Class Initialized
INFO - 2017-01-27 04:57:38 --> Database Driver Class Initialized
INFO - 2017-01-27 04:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 04:57:38 --> Controller Class Initialized
INFO - 2017-01-27 04:57:38 --> Helper loaded: url_helper
DEBUG - 2017-01-27 04:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 04:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 04:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 04:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 04:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 04:57:38 --> Final output sent to browser
DEBUG - 2017-01-27 04:57:38 --> Total execution time: 0.0133
INFO - 2017-01-27 08:21:30 --> Config Class Initialized
INFO - 2017-01-27 08:21:30 --> Hooks Class Initialized
DEBUG - 2017-01-27 08:21:30 --> UTF-8 Support Enabled
INFO - 2017-01-27 08:21:30 --> Utf8 Class Initialized
INFO - 2017-01-27 08:21:30 --> URI Class Initialized
INFO - 2017-01-27 08:21:30 --> Router Class Initialized
INFO - 2017-01-27 08:21:30 --> Output Class Initialized
INFO - 2017-01-27 08:21:30 --> Security Class Initialized
DEBUG - 2017-01-27 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 08:21:30 --> Input Class Initialized
INFO - 2017-01-27 08:21:30 --> Language Class Initialized
INFO - 2017-01-27 08:21:30 --> Loader Class Initialized
INFO - 2017-01-27 08:21:30 --> Database Driver Class Initialized
INFO - 2017-01-27 08:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 08:21:30 --> Controller Class Initialized
INFO - 2017-01-27 08:21:30 --> Helper loaded: date_helper
DEBUG - 2017-01-27 08:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 08:21:30 --> Helper loaded: url_helper
INFO - 2017-01-27 08:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 08:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 08:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 08:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 08:21:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 08:21:30 --> Final output sent to browser
DEBUG - 2017-01-27 08:21:30 --> Total execution time: 0.1859
INFO - 2017-01-27 12:08:21 --> Config Class Initialized
INFO - 2017-01-27 12:08:21 --> Hooks Class Initialized
DEBUG - 2017-01-27 12:08:21 --> UTF-8 Support Enabled
INFO - 2017-01-27 12:08:21 --> Utf8 Class Initialized
INFO - 2017-01-27 12:08:21 --> URI Class Initialized
INFO - 2017-01-27 12:08:21 --> Router Class Initialized
INFO - 2017-01-27 12:08:21 --> Output Class Initialized
INFO - 2017-01-27 12:08:21 --> Security Class Initialized
DEBUG - 2017-01-27 12:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 12:08:21 --> Input Class Initialized
INFO - 2017-01-27 12:08:21 --> Language Class Initialized
INFO - 2017-01-27 12:08:22 --> Loader Class Initialized
INFO - 2017-01-27 12:08:22 --> Database Driver Class Initialized
INFO - 2017-01-27 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 12:08:22 --> Controller Class Initialized
INFO - 2017-01-27 12:08:22 --> Helper loaded: url_helper
DEBUG - 2017-01-27 12:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 12:08:23 --> Final output sent to browser
DEBUG - 2017-01-27 12:08:23 --> Total execution time: 2.2538
INFO - 2017-01-27 12:08:23 --> Config Class Initialized
INFO - 2017-01-27 12:08:23 --> Hooks Class Initialized
DEBUG - 2017-01-27 12:08:23 --> UTF-8 Support Enabled
INFO - 2017-01-27 12:08:23 --> Utf8 Class Initialized
INFO - 2017-01-27 12:08:23 --> URI Class Initialized
INFO - 2017-01-27 12:08:23 --> Router Class Initialized
INFO - 2017-01-27 12:08:23 --> Output Class Initialized
INFO - 2017-01-27 12:08:23 --> Security Class Initialized
DEBUG - 2017-01-27 12:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 12:08:23 --> Input Class Initialized
INFO - 2017-01-27 12:08:23 --> Language Class Initialized
INFO - 2017-01-27 12:08:23 --> Loader Class Initialized
INFO - 2017-01-27 12:08:23 --> Database Driver Class Initialized
INFO - 2017-01-27 12:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 12:08:23 --> Controller Class Initialized
INFO - 2017-01-27 12:08:23 --> Helper loaded: url_helper
DEBUG - 2017-01-27 12:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 12:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 12:08:23 --> Final output sent to browser
DEBUG - 2017-01-27 12:08:23 --> Total execution time: 0.0151
INFO - 2017-01-27 13:18:46 --> Config Class Initialized
INFO - 2017-01-27 13:18:46 --> Hooks Class Initialized
DEBUG - 2017-01-27 13:18:47 --> UTF-8 Support Enabled
INFO - 2017-01-27 13:18:47 --> Utf8 Class Initialized
INFO - 2017-01-27 13:18:47 --> URI Class Initialized
DEBUG - 2017-01-27 13:18:47 --> No URI present. Default controller set.
INFO - 2017-01-27 13:18:47 --> Router Class Initialized
INFO - 2017-01-27 13:18:47 --> Output Class Initialized
INFO - 2017-01-27 13:18:47 --> Security Class Initialized
DEBUG - 2017-01-27 13:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 13:18:47 --> Input Class Initialized
INFO - 2017-01-27 13:18:47 --> Language Class Initialized
INFO - 2017-01-27 13:18:47 --> Loader Class Initialized
INFO - 2017-01-27 13:18:47 --> Database Driver Class Initialized
INFO - 2017-01-27 13:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 13:18:47 --> Controller Class Initialized
INFO - 2017-01-27 13:18:47 --> Helper loaded: url_helper
DEBUG - 2017-01-27 13:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 13:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 13:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 13:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 13:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 13:18:47 --> Final output sent to browser
DEBUG - 2017-01-27 13:18:47 --> Total execution time: 1.0407
INFO - 2017-01-27 13:18:53 --> Config Class Initialized
INFO - 2017-01-27 13:18:53 --> Hooks Class Initialized
DEBUG - 2017-01-27 13:18:53 --> UTF-8 Support Enabled
INFO - 2017-01-27 13:18:53 --> Utf8 Class Initialized
INFO - 2017-01-27 13:18:53 --> URI Class Initialized
INFO - 2017-01-27 13:18:53 --> Router Class Initialized
INFO - 2017-01-27 13:18:53 --> Output Class Initialized
INFO - 2017-01-27 13:18:53 --> Security Class Initialized
DEBUG - 2017-01-27 13:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 13:18:53 --> Input Class Initialized
INFO - 2017-01-27 13:18:53 --> Language Class Initialized
INFO - 2017-01-27 13:18:53 --> Loader Class Initialized
INFO - 2017-01-27 13:18:53 --> Database Driver Class Initialized
INFO - 2017-01-27 13:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 13:18:53 --> Controller Class Initialized
INFO - 2017-01-27 13:18:53 --> Helper loaded: url_helper
DEBUG - 2017-01-27 13:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 13:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 13:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 13:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 13:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 13:18:53 --> Final output sent to browser
DEBUG - 2017-01-27 13:18:53 --> Total execution time: 0.0133
INFO - 2017-01-27 13:19:00 --> Config Class Initialized
INFO - 2017-01-27 13:19:00 --> Hooks Class Initialized
DEBUG - 2017-01-27 13:19:00 --> UTF-8 Support Enabled
INFO - 2017-01-27 13:19:00 --> Utf8 Class Initialized
INFO - 2017-01-27 13:19:00 --> URI Class Initialized
INFO - 2017-01-27 13:19:00 --> Router Class Initialized
INFO - 2017-01-27 13:19:00 --> Output Class Initialized
INFO - 2017-01-27 13:19:00 --> Security Class Initialized
DEBUG - 2017-01-27 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 13:19:00 --> Input Class Initialized
INFO - 2017-01-27 13:19:00 --> Language Class Initialized
INFO - 2017-01-27 13:19:00 --> Loader Class Initialized
INFO - 2017-01-27 13:19:00 --> Database Driver Class Initialized
INFO - 2017-01-27 13:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 13:19:00 --> Controller Class Initialized
INFO - 2017-01-27 13:19:00 --> Helper loaded: url_helper
DEBUG - 2017-01-27 13:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 13:19:02 --> Config Class Initialized
INFO - 2017-01-27 13:19:02 --> Hooks Class Initialized
DEBUG - 2017-01-27 13:19:02 --> UTF-8 Support Enabled
INFO - 2017-01-27 13:19:02 --> Utf8 Class Initialized
INFO - 2017-01-27 13:19:02 --> URI Class Initialized
INFO - 2017-01-27 13:19:02 --> Router Class Initialized
INFO - 2017-01-27 13:19:02 --> Output Class Initialized
INFO - 2017-01-27 13:19:02 --> Security Class Initialized
DEBUG - 2017-01-27 13:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 13:19:02 --> Input Class Initialized
INFO - 2017-01-27 13:19:02 --> Language Class Initialized
INFO - 2017-01-27 13:19:02 --> Loader Class Initialized
INFO - 2017-01-27 13:19:02 --> Database Driver Class Initialized
INFO - 2017-01-27 13:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 13:19:02 --> Controller Class Initialized
INFO - 2017-01-27 13:19:02 --> Helper loaded: date_helper
DEBUG - 2017-01-27 13:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 13:19:02 --> Helper loaded: url_helper
INFO - 2017-01-27 13:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 13:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 13:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 13:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 13:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 13:19:02 --> Final output sent to browser
DEBUG - 2017-01-27 13:19:02 --> Total execution time: 0.0801
INFO - 2017-01-27 13:19:03 --> Config Class Initialized
INFO - 2017-01-27 13:19:03 --> Hooks Class Initialized
DEBUG - 2017-01-27 13:19:03 --> UTF-8 Support Enabled
INFO - 2017-01-27 13:19:03 --> Utf8 Class Initialized
INFO - 2017-01-27 13:19:03 --> URI Class Initialized
INFO - 2017-01-27 13:19:03 --> Router Class Initialized
INFO - 2017-01-27 13:19:03 --> Output Class Initialized
INFO - 2017-01-27 13:19:03 --> Security Class Initialized
DEBUG - 2017-01-27 13:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 13:19:03 --> Input Class Initialized
INFO - 2017-01-27 13:19:03 --> Language Class Initialized
INFO - 2017-01-27 13:19:03 --> Loader Class Initialized
INFO - 2017-01-27 13:19:03 --> Database Driver Class Initialized
INFO - 2017-01-27 13:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 13:19:03 --> Controller Class Initialized
INFO - 2017-01-27 13:19:03 --> Helper loaded: url_helper
DEBUG - 2017-01-27 13:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 13:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 13:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 13:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 13:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 13:19:03 --> Final output sent to browser
DEBUG - 2017-01-27 13:19:03 --> Total execution time: 0.0145
INFO - 2017-01-27 17:43:29 --> Config Class Initialized
INFO - 2017-01-27 17:43:29 --> Hooks Class Initialized
DEBUG - 2017-01-27 17:43:29 --> UTF-8 Support Enabled
INFO - 2017-01-27 17:43:29 --> Utf8 Class Initialized
INFO - 2017-01-27 17:43:29 --> URI Class Initialized
DEBUG - 2017-01-27 17:43:29 --> No URI present. Default controller set.
INFO - 2017-01-27 17:43:29 --> Router Class Initialized
INFO - 2017-01-27 17:43:29 --> Output Class Initialized
INFO - 2017-01-27 17:43:29 --> Security Class Initialized
DEBUG - 2017-01-27 17:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 17:43:29 --> Input Class Initialized
INFO - 2017-01-27 17:43:29 --> Language Class Initialized
INFO - 2017-01-27 17:43:30 --> Loader Class Initialized
INFO - 2017-01-27 17:43:30 --> Database Driver Class Initialized
INFO - 2017-01-27 17:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 17:43:30 --> Controller Class Initialized
INFO - 2017-01-27 17:43:30 --> Helper loaded: url_helper
DEBUG - 2017-01-27 17:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 17:43:31 --> Final output sent to browser
DEBUG - 2017-01-27 17:43:31 --> Total execution time: 1.9237
INFO - 2017-01-27 18:01:44 --> Config Class Initialized
INFO - 2017-01-27 18:01:44 --> Hooks Class Initialized
DEBUG - 2017-01-27 18:01:44 --> UTF-8 Support Enabled
INFO - 2017-01-27 18:01:44 --> Utf8 Class Initialized
INFO - 2017-01-27 18:01:44 --> URI Class Initialized
INFO - 2017-01-27 18:01:44 --> Config Class Initialized
INFO - 2017-01-27 18:01:44 --> Hooks Class Initialized
DEBUG - 2017-01-27 18:01:44 --> UTF-8 Support Enabled
INFO - 2017-01-27 18:01:44 --> Router Class Initialized
INFO - 2017-01-27 18:01:44 --> Utf8 Class Initialized
INFO - 2017-01-27 18:01:44 --> URI Class Initialized
INFO - 2017-01-27 18:01:44 --> Output Class Initialized
DEBUG - 2017-01-27 18:01:44 --> No URI present. Default controller set.
INFO - 2017-01-27 18:01:44 --> Router Class Initialized
INFO - 2017-01-27 18:01:44 --> Security Class Initialized
INFO - 2017-01-27 18:01:44 --> Output Class Initialized
DEBUG - 2017-01-27 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 18:01:44 --> Input Class Initialized
INFO - 2017-01-27 18:01:44 --> Language Class Initialized
INFO - 2017-01-27 18:01:44 --> Security Class Initialized
DEBUG - 2017-01-27 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 18:01:44 --> Input Class Initialized
INFO - 2017-01-27 18:01:44 --> Language Class Initialized
INFO - 2017-01-27 18:01:44 --> Loader Class Initialized
INFO - 2017-01-27 18:01:44 --> Database Driver Class Initialized
INFO - 2017-01-27 18:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 18:01:44 --> Controller Class Initialized
INFO - 2017-01-27 18:01:44 --> Loader Class Initialized
INFO - 2017-01-27 18:01:44 --> Helper loaded: url_helper
DEBUG - 2017-01-27 18:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 18:01:44 --> Database Driver Class Initialized
INFO - 2017-01-27 18:01:44 --> Final output sent to browser
DEBUG - 2017-01-27 18:01:44 --> Total execution time: 0.2693
INFO - 2017-01-27 18:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 18:01:44 --> Controller Class Initialized
INFO - 2017-01-27 18:01:44 --> Helper loaded: url_helper
DEBUG - 2017-01-27 18:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 18:01:44 --> Helper loaded: form_helper
INFO - 2017-01-27 18:01:44 --> Form Validation Class Initialized
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-27 18:01:44 --> Final output sent to browser
DEBUG - 2017-01-27 18:01:44 --> Total execution time: 0.6983
INFO - 2017-01-27 18:01:44 --> Config Class Initialized
INFO - 2017-01-27 18:01:44 --> Hooks Class Initialized
DEBUG - 2017-01-27 18:01:44 --> UTF-8 Support Enabled
INFO - 2017-01-27 18:01:44 --> Utf8 Class Initialized
INFO - 2017-01-27 18:01:44 --> URI Class Initialized
INFO - 2017-01-27 18:01:44 --> Router Class Initialized
INFO - 2017-01-27 18:01:44 --> Output Class Initialized
INFO - 2017-01-27 18:01:44 --> Security Class Initialized
DEBUG - 2017-01-27 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 18:01:44 --> Input Class Initialized
INFO - 2017-01-27 18:01:44 --> Language Class Initialized
INFO - 2017-01-27 18:01:44 --> Loader Class Initialized
INFO - 2017-01-27 18:01:44 --> Database Driver Class Initialized
INFO - 2017-01-27 18:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 18:01:44 --> Controller Class Initialized
INFO - 2017-01-27 18:01:44 --> Helper loaded: url_helper
DEBUG - 2017-01-27 18:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 18:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 18:01:44 --> Final output sent to browser
DEBUG - 2017-01-27 18:01:44 --> Total execution time: 0.0147
INFO - 2017-01-27 18:50:27 --> Config Class Initialized
INFO - 2017-01-27 18:50:27 --> Hooks Class Initialized
DEBUG - 2017-01-27 18:50:27 --> UTF-8 Support Enabled
INFO - 2017-01-27 18:50:27 --> Utf8 Class Initialized
INFO - 2017-01-27 18:50:27 --> URI Class Initialized
INFO - 2017-01-27 18:50:27 --> Router Class Initialized
INFO - 2017-01-27 18:50:27 --> Output Class Initialized
INFO - 2017-01-27 18:50:27 --> Security Class Initialized
DEBUG - 2017-01-27 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 18:50:27 --> Input Class Initialized
INFO - 2017-01-27 18:50:27 --> Language Class Initialized
INFO - 2017-01-27 18:50:27 --> Loader Class Initialized
INFO - 2017-01-27 18:50:27 --> Database Driver Class Initialized
INFO - 2017-01-27 18:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 18:50:27 --> Controller Class Initialized
INFO - 2017-01-27 18:50:27 --> Helper loaded: date_helper
DEBUG - 2017-01-27 18:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 18:50:27 --> Helper loaded: url_helper
INFO - 2017-01-27 18:50:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 18:50:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 18:50:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 18:50:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 18:50:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 18:50:28 --> Final output sent to browser
DEBUG - 2017-01-27 18:50:28 --> Total execution time: 0.5186
INFO - 2017-01-27 18:50:34 --> Config Class Initialized
INFO - 2017-01-27 18:50:34 --> Hooks Class Initialized
DEBUG - 2017-01-27 18:50:34 --> UTF-8 Support Enabled
INFO - 2017-01-27 18:50:34 --> Utf8 Class Initialized
INFO - 2017-01-27 18:50:34 --> URI Class Initialized
INFO - 2017-01-27 18:50:34 --> Router Class Initialized
INFO - 2017-01-27 18:50:34 --> Output Class Initialized
INFO - 2017-01-27 18:50:34 --> Security Class Initialized
DEBUG - 2017-01-27 18:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 18:50:34 --> Input Class Initialized
INFO - 2017-01-27 18:50:34 --> Language Class Initialized
INFO - 2017-01-27 18:50:34 --> Loader Class Initialized
INFO - 2017-01-27 18:50:34 --> Database Driver Class Initialized
INFO - 2017-01-27 18:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 18:50:34 --> Controller Class Initialized
INFO - 2017-01-27 18:50:34 --> Helper loaded: url_helper
DEBUG - 2017-01-27 18:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 18:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 18:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 18:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 18:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 18:50:34 --> Final output sent to browser
DEBUG - 2017-01-27 18:50:34 --> Total execution time: 0.0451
INFO - 2017-01-27 18:52:08 --> Config Class Initialized
INFO - 2017-01-27 18:52:08 --> Hooks Class Initialized
DEBUG - 2017-01-27 18:52:08 --> UTF-8 Support Enabled
INFO - 2017-01-27 18:52:08 --> Utf8 Class Initialized
INFO - 2017-01-27 18:52:08 --> URI Class Initialized
DEBUG - 2017-01-27 18:52:08 --> No URI present. Default controller set.
INFO - 2017-01-27 18:52:08 --> Router Class Initialized
INFO - 2017-01-27 18:52:08 --> Output Class Initialized
INFO - 2017-01-27 18:52:08 --> Security Class Initialized
DEBUG - 2017-01-27 18:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 18:52:08 --> Input Class Initialized
INFO - 2017-01-27 18:52:08 --> Language Class Initialized
INFO - 2017-01-27 18:52:08 --> Loader Class Initialized
INFO - 2017-01-27 18:52:08 --> Database Driver Class Initialized
INFO - 2017-01-27 18:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 18:52:08 --> Controller Class Initialized
INFO - 2017-01-27 18:52:08 --> Helper loaded: url_helper
DEBUG - 2017-01-27 18:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 18:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 18:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 18:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 18:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 18:52:08 --> Final output sent to browser
DEBUG - 2017-01-27 18:52:08 --> Total execution time: 0.0135
INFO - 2017-01-27 18:58:44 --> Config Class Initialized
INFO - 2017-01-27 18:58:44 --> Hooks Class Initialized
DEBUG - 2017-01-27 18:58:44 --> UTF-8 Support Enabled
INFO - 2017-01-27 18:58:44 --> Utf8 Class Initialized
INFO - 2017-01-27 18:58:44 --> URI Class Initialized
INFO - 2017-01-27 18:58:44 --> Router Class Initialized
INFO - 2017-01-27 18:58:44 --> Output Class Initialized
INFO - 2017-01-27 18:58:44 --> Security Class Initialized
DEBUG - 2017-01-27 18:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 18:58:44 --> Input Class Initialized
INFO - 2017-01-27 18:58:44 --> Language Class Initialized
INFO - 2017-01-27 18:58:44 --> Loader Class Initialized
INFO - 2017-01-27 18:58:44 --> Database Driver Class Initialized
INFO - 2017-01-27 18:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 18:58:44 --> Controller Class Initialized
INFO - 2017-01-27 18:58:44 --> Helper loaded: url_helper
DEBUG - 2017-01-27 18:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 18:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-27 18:58:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-27 18:58:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-27 18:58:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-27 18:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-27 18:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-27 18:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 18:58:44 --> Final output sent to browser
DEBUG - 2017-01-27 18:58:44 --> Total execution time: 0.0676
INFO - 2017-01-27 21:45:03 --> Config Class Initialized
INFO - 2017-01-27 21:45:03 --> Hooks Class Initialized
DEBUG - 2017-01-27 21:45:03 --> UTF-8 Support Enabled
INFO - 2017-01-27 21:45:03 --> Utf8 Class Initialized
INFO - 2017-01-27 21:45:03 --> URI Class Initialized
INFO - 2017-01-27 21:45:03 --> Router Class Initialized
INFO - 2017-01-27 21:45:03 --> Output Class Initialized
INFO - 2017-01-27 21:45:03 --> Security Class Initialized
DEBUG - 2017-01-27 21:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-27 21:45:03 --> Input Class Initialized
INFO - 2017-01-27 21:45:03 --> Language Class Initialized
INFO - 2017-01-27 21:45:03 --> Loader Class Initialized
INFO - 2017-01-27 21:45:03 --> Database Driver Class Initialized
INFO - 2017-01-27 21:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-27 21:45:03 --> Controller Class Initialized
INFO - 2017-01-27 21:45:03 --> Helper loaded: date_helper
DEBUG - 2017-01-27 21:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-27 21:45:03 --> Helper loaded: url_helper
INFO - 2017-01-27 21:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-27 21:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-27 21:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-27 21:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-27 21:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-27 21:45:03 --> Final output sent to browser
DEBUG - 2017-01-27 21:45:03 --> Total execution time: 0.0938

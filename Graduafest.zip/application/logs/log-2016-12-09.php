<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-09 00:09:15 --> Config Class Initialized
INFO - 2016-12-09 00:09:15 --> Hooks Class Initialized
DEBUG - 2016-12-09 00:09:15 --> UTF-8 Support Enabled
INFO - 2016-12-09 00:09:15 --> Utf8 Class Initialized
INFO - 2016-12-09 00:09:15 --> URI Class Initialized
DEBUG - 2016-12-09 00:09:15 --> No URI present. Default controller set.
INFO - 2016-12-09 00:09:15 --> Router Class Initialized
INFO - 2016-12-09 00:09:15 --> Output Class Initialized
INFO - 2016-12-09 00:09:15 --> Security Class Initialized
DEBUG - 2016-12-09 00:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 00:09:15 --> Input Class Initialized
INFO - 2016-12-09 00:09:15 --> Language Class Initialized
INFO - 2016-12-09 00:09:15 --> Loader Class Initialized
INFO - 2016-12-09 00:09:16 --> Database Driver Class Initialized
INFO - 2016-12-09 00:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 00:09:16 --> Controller Class Initialized
INFO - 2016-12-09 00:09:16 --> Helper loaded: url_helper
DEBUG - 2016-12-09 00:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 00:09:16 --> Final output sent to browser
DEBUG - 2016-12-09 00:09:16 --> Total execution time: 1.2096
INFO - 2016-12-09 00:09:17 --> Config Class Initialized
INFO - 2016-12-09 00:09:17 --> Hooks Class Initialized
DEBUG - 2016-12-09 00:09:17 --> UTF-8 Support Enabled
INFO - 2016-12-09 00:09:17 --> Utf8 Class Initialized
INFO - 2016-12-09 00:09:17 --> URI Class Initialized
INFO - 2016-12-09 00:09:17 --> Router Class Initialized
INFO - 2016-12-09 00:09:17 --> Output Class Initialized
INFO - 2016-12-09 00:09:17 --> Security Class Initialized
DEBUG - 2016-12-09 00:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 00:09:17 --> Input Class Initialized
INFO - 2016-12-09 00:09:17 --> Language Class Initialized
INFO - 2016-12-09 00:09:17 --> Loader Class Initialized
INFO - 2016-12-09 00:09:17 --> Database Driver Class Initialized
INFO - 2016-12-09 00:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 00:09:17 --> Controller Class Initialized
INFO - 2016-12-09 00:09:17 --> Helper loaded: url_helper
DEBUG - 2016-12-09 00:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 00:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 00:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 00:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 00:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 00:09:17 --> Final output sent to browser
DEBUG - 2016-12-09 00:09:17 --> Total execution time: 0.0598
INFO - 2016-12-09 04:09:46 --> Config Class Initialized
INFO - 2016-12-09 04:09:46 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:09:46 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:09:46 --> Utf8 Class Initialized
INFO - 2016-12-09 04:09:46 --> URI Class Initialized
DEBUG - 2016-12-09 04:09:46 --> No URI present. Default controller set.
INFO - 2016-12-09 04:09:46 --> Router Class Initialized
INFO - 2016-12-09 04:09:46 --> Output Class Initialized
INFO - 2016-12-09 04:09:46 --> Security Class Initialized
DEBUG - 2016-12-09 04:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:09:46 --> Input Class Initialized
INFO - 2016-12-09 04:09:46 --> Language Class Initialized
INFO - 2016-12-09 04:09:46 --> Loader Class Initialized
INFO - 2016-12-09 04:09:46 --> Database Driver Class Initialized
INFO - 2016-12-09 04:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:09:46 --> Controller Class Initialized
INFO - 2016-12-09 04:09:46 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:09:46 --> Final output sent to browser
DEBUG - 2016-12-09 04:09:46 --> Total execution time: 0.0132
INFO - 2016-12-09 04:09:51 --> Config Class Initialized
INFO - 2016-12-09 04:09:51 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:09:51 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:09:51 --> Utf8 Class Initialized
INFO - 2016-12-09 04:09:51 --> URI Class Initialized
INFO - 2016-12-09 04:09:51 --> Router Class Initialized
INFO - 2016-12-09 04:09:51 --> Output Class Initialized
INFO - 2016-12-09 04:09:51 --> Security Class Initialized
DEBUG - 2016-12-09 04:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:09:51 --> Input Class Initialized
INFO - 2016-12-09 04:09:51 --> Language Class Initialized
INFO - 2016-12-09 04:09:51 --> Loader Class Initialized
INFO - 2016-12-09 04:09:51 --> Database Driver Class Initialized
INFO - 2016-12-09 04:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:09:51 --> Controller Class Initialized
INFO - 2016-12-09 04:09:51 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:09:51 --> Final output sent to browser
DEBUG - 2016-12-09 04:09:51 --> Total execution time: 0.0131
INFO - 2016-12-09 04:11:34 --> Config Class Initialized
INFO - 2016-12-09 04:11:34 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:11:34 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:11:34 --> Utf8 Class Initialized
INFO - 2016-12-09 04:11:34 --> URI Class Initialized
DEBUG - 2016-12-09 04:11:34 --> No URI present. Default controller set.
INFO - 2016-12-09 04:11:34 --> Router Class Initialized
INFO - 2016-12-09 04:11:34 --> Output Class Initialized
INFO - 2016-12-09 04:11:34 --> Security Class Initialized
DEBUG - 2016-12-09 04:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:11:34 --> Input Class Initialized
INFO - 2016-12-09 04:11:34 --> Language Class Initialized
INFO - 2016-12-09 04:11:34 --> Loader Class Initialized
INFO - 2016-12-09 04:11:34 --> Database Driver Class Initialized
INFO - 2016-12-09 04:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:11:34 --> Controller Class Initialized
INFO - 2016-12-09 04:11:34 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:11:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:11:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:11:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:11:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:11:34 --> Final output sent to browser
DEBUG - 2016-12-09 04:11:34 --> Total execution time: 0.0137
INFO - 2016-12-09 04:11:35 --> Config Class Initialized
INFO - 2016-12-09 04:11:35 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:11:35 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:11:35 --> Utf8 Class Initialized
INFO - 2016-12-09 04:11:35 --> URI Class Initialized
INFO - 2016-12-09 04:11:35 --> Router Class Initialized
INFO - 2016-12-09 04:11:35 --> Output Class Initialized
INFO - 2016-12-09 04:11:35 --> Security Class Initialized
DEBUG - 2016-12-09 04:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:11:35 --> Input Class Initialized
INFO - 2016-12-09 04:11:35 --> Language Class Initialized
INFO - 2016-12-09 04:11:35 --> Loader Class Initialized
INFO - 2016-12-09 04:11:35 --> Database Driver Class Initialized
INFO - 2016-12-09 04:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:11:35 --> Controller Class Initialized
INFO - 2016-12-09 04:11:35 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:11:35 --> Final output sent to browser
DEBUG - 2016-12-09 04:11:35 --> Total execution time: 0.0134
INFO - 2016-12-09 04:14:29 --> Config Class Initialized
INFO - 2016-12-09 04:14:29 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:14:29 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:14:29 --> Utf8 Class Initialized
INFO - 2016-12-09 04:14:29 --> URI Class Initialized
DEBUG - 2016-12-09 04:14:29 --> No URI present. Default controller set.
INFO - 2016-12-09 04:14:29 --> Router Class Initialized
INFO - 2016-12-09 04:14:29 --> Output Class Initialized
INFO - 2016-12-09 04:14:29 --> Security Class Initialized
DEBUG - 2016-12-09 04:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:14:29 --> Input Class Initialized
INFO - 2016-12-09 04:14:29 --> Language Class Initialized
INFO - 2016-12-09 04:14:29 --> Loader Class Initialized
INFO - 2016-12-09 04:14:29 --> Database Driver Class Initialized
INFO - 2016-12-09 04:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:14:29 --> Controller Class Initialized
INFO - 2016-12-09 04:14:29 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:14:29 --> Final output sent to browser
DEBUG - 2016-12-09 04:14:29 --> Total execution time: 0.0138
INFO - 2016-12-09 04:14:29 --> Config Class Initialized
INFO - 2016-12-09 04:14:29 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:14:29 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:14:29 --> Utf8 Class Initialized
INFO - 2016-12-09 04:14:29 --> URI Class Initialized
INFO - 2016-12-09 04:14:29 --> Router Class Initialized
INFO - 2016-12-09 04:14:29 --> Output Class Initialized
INFO - 2016-12-09 04:14:29 --> Security Class Initialized
DEBUG - 2016-12-09 04:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:14:29 --> Input Class Initialized
INFO - 2016-12-09 04:14:29 --> Language Class Initialized
INFO - 2016-12-09 04:14:29 --> Loader Class Initialized
INFO - 2016-12-09 04:14:29 --> Database Driver Class Initialized
INFO - 2016-12-09 04:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:14:29 --> Controller Class Initialized
INFO - 2016-12-09 04:14:29 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:14:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:14:29 --> Final output sent to browser
DEBUG - 2016-12-09 04:14:29 --> Total execution time: 0.0326
INFO - 2016-12-09 04:18:11 --> Config Class Initialized
INFO - 2016-12-09 04:18:11 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:18:11 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:18:11 --> Utf8 Class Initialized
INFO - 2016-12-09 04:18:11 --> URI Class Initialized
DEBUG - 2016-12-09 04:18:11 --> No URI present. Default controller set.
INFO - 2016-12-09 04:18:11 --> Router Class Initialized
INFO - 2016-12-09 04:18:11 --> Output Class Initialized
INFO - 2016-12-09 04:18:11 --> Security Class Initialized
DEBUG - 2016-12-09 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:18:11 --> Input Class Initialized
INFO - 2016-12-09 04:18:11 --> Language Class Initialized
INFO - 2016-12-09 04:18:11 --> Loader Class Initialized
INFO - 2016-12-09 04:18:11 --> Database Driver Class Initialized
INFO - 2016-12-09 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:18:11 --> Controller Class Initialized
INFO - 2016-12-09 04:18:11 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:18:11 --> Final output sent to browser
DEBUG - 2016-12-09 04:18:11 --> Total execution time: 0.0131
INFO - 2016-12-09 04:18:11 --> Config Class Initialized
INFO - 2016-12-09 04:18:11 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:18:11 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:18:11 --> Utf8 Class Initialized
INFO - 2016-12-09 04:18:11 --> URI Class Initialized
INFO - 2016-12-09 04:18:11 --> Router Class Initialized
INFO - 2016-12-09 04:18:11 --> Output Class Initialized
INFO - 2016-12-09 04:18:11 --> Security Class Initialized
DEBUG - 2016-12-09 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:18:11 --> Input Class Initialized
INFO - 2016-12-09 04:18:11 --> Language Class Initialized
INFO - 2016-12-09 04:18:11 --> Loader Class Initialized
INFO - 2016-12-09 04:18:11 --> Database Driver Class Initialized
INFO - 2016-12-09 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:18:11 --> Controller Class Initialized
INFO - 2016-12-09 04:18:11 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:18:11 --> Final output sent to browser
DEBUG - 2016-12-09 04:18:11 --> Total execution time: 0.0129
INFO - 2016-12-09 04:29:06 --> Config Class Initialized
INFO - 2016-12-09 04:29:06 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:29:06 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:29:06 --> Utf8 Class Initialized
INFO - 2016-12-09 04:29:06 --> URI Class Initialized
INFO - 2016-12-09 04:29:06 --> Router Class Initialized
INFO - 2016-12-09 04:29:06 --> Output Class Initialized
INFO - 2016-12-09 04:29:06 --> Security Class Initialized
DEBUG - 2016-12-09 04:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:29:06 --> Input Class Initialized
INFO - 2016-12-09 04:29:06 --> Language Class Initialized
INFO - 2016-12-09 04:29:06 --> Loader Class Initialized
INFO - 2016-12-09 04:29:06 --> Database Driver Class Initialized
INFO - 2016-12-09 04:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:29:06 --> Controller Class Initialized
INFO - 2016-12-09 04:29:06 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:29:06 --> Final output sent to browser
DEBUG - 2016-12-09 04:29:06 --> Total execution time: 0.0182
INFO - 2016-12-09 04:42:14 --> Config Class Initialized
INFO - 2016-12-09 04:42:14 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:42:14 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:42:14 --> Utf8 Class Initialized
INFO - 2016-12-09 04:42:14 --> URI Class Initialized
DEBUG - 2016-12-09 04:42:14 --> No URI present. Default controller set.
INFO - 2016-12-09 04:42:14 --> Router Class Initialized
INFO - 2016-12-09 04:42:14 --> Output Class Initialized
INFO - 2016-12-09 04:42:14 --> Security Class Initialized
DEBUG - 2016-12-09 04:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:42:14 --> Input Class Initialized
INFO - 2016-12-09 04:42:14 --> Language Class Initialized
INFO - 2016-12-09 04:42:14 --> Loader Class Initialized
INFO - 2016-12-09 04:42:14 --> Database Driver Class Initialized
INFO - 2016-12-09 04:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:42:14 --> Controller Class Initialized
INFO - 2016-12-09 04:42:14 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2016-12-09 04:42:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 110
ERROR - 2016-12-09 04:42:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 113
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:42:14 --> Final output sent to browser
DEBUG - 2016-12-09 04:42:14 --> Total execution time: 0.0450
INFO - 2016-12-09 04:42:14 --> Config Class Initialized
INFO - 2016-12-09 04:42:14 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:42:14 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:42:14 --> Utf8 Class Initialized
INFO - 2016-12-09 04:42:14 --> URI Class Initialized
INFO - 2016-12-09 04:42:14 --> Router Class Initialized
INFO - 2016-12-09 04:42:14 --> Output Class Initialized
INFO - 2016-12-09 04:42:14 --> Security Class Initialized
DEBUG - 2016-12-09 04:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:42:14 --> Input Class Initialized
INFO - 2016-12-09 04:42:14 --> Language Class Initialized
INFO - 2016-12-09 04:42:14 --> Loader Class Initialized
INFO - 2016-12-09 04:42:14 --> Database Driver Class Initialized
INFO - 2016-12-09 04:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:42:14 --> Controller Class Initialized
INFO - 2016-12-09 04:42:14 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2016-12-09 04:42:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 110
ERROR - 2016-12-09 04:42:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 113
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:42:14 --> Final output sent to browser
DEBUG - 2016-12-09 04:42:14 --> Total execution time: 0.0148
INFO - 2016-12-09 04:43:11 --> Config Class Initialized
INFO - 2016-12-09 04:43:11 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:43:11 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:43:11 --> Utf8 Class Initialized
INFO - 2016-12-09 04:43:11 --> URI Class Initialized
DEBUG - 2016-12-09 04:43:11 --> No URI present. Default controller set.
INFO - 2016-12-09 04:43:11 --> Router Class Initialized
INFO - 2016-12-09 04:43:11 --> Output Class Initialized
INFO - 2016-12-09 04:43:11 --> Security Class Initialized
DEBUG - 2016-12-09 04:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:43:11 --> Input Class Initialized
INFO - 2016-12-09 04:43:11 --> Language Class Initialized
INFO - 2016-12-09 04:43:11 --> Loader Class Initialized
INFO - 2016-12-09 04:43:11 --> Database Driver Class Initialized
INFO - 2016-12-09 04:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:43:11 --> Controller Class Initialized
INFO - 2016-12-09 04:43:11 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:43:11 --> Final output sent to browser
DEBUG - 2016-12-09 04:43:11 --> Total execution time: 0.0134
INFO - 2016-12-09 04:43:11 --> Config Class Initialized
INFO - 2016-12-09 04:43:11 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:43:11 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:43:11 --> Utf8 Class Initialized
INFO - 2016-12-09 04:43:11 --> URI Class Initialized
INFO - 2016-12-09 04:43:11 --> Router Class Initialized
INFO - 2016-12-09 04:43:11 --> Output Class Initialized
INFO - 2016-12-09 04:43:11 --> Security Class Initialized
DEBUG - 2016-12-09 04:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:43:11 --> Input Class Initialized
INFO - 2016-12-09 04:43:11 --> Language Class Initialized
INFO - 2016-12-09 04:43:11 --> Loader Class Initialized
INFO - 2016-12-09 04:43:11 --> Database Driver Class Initialized
INFO - 2016-12-09 04:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:43:11 --> Controller Class Initialized
INFO - 2016-12-09 04:43:11 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:43:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:43:11 --> Final output sent to browser
DEBUG - 2016-12-09 04:43:11 --> Total execution time: 0.0142
INFO - 2016-12-09 04:47:46 --> Config Class Initialized
INFO - 2016-12-09 04:47:46 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:47:46 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:47:46 --> Utf8 Class Initialized
INFO - 2016-12-09 04:47:46 --> URI Class Initialized
DEBUG - 2016-12-09 04:47:46 --> No URI present. Default controller set.
INFO - 2016-12-09 04:47:46 --> Router Class Initialized
INFO - 2016-12-09 04:47:46 --> Output Class Initialized
INFO - 2016-12-09 04:47:46 --> Security Class Initialized
DEBUG - 2016-12-09 04:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:47:46 --> Input Class Initialized
INFO - 2016-12-09 04:47:46 --> Language Class Initialized
INFO - 2016-12-09 04:47:46 --> Loader Class Initialized
INFO - 2016-12-09 04:47:46 --> Database Driver Class Initialized
INFO - 2016-12-09 04:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:47:46 --> Controller Class Initialized
INFO - 2016-12-09 04:47:46 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:47:46 --> Final output sent to browser
DEBUG - 2016-12-09 04:47:46 --> Total execution time: 0.0136
INFO - 2016-12-09 04:47:46 --> Config Class Initialized
INFO - 2016-12-09 04:47:46 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:47:46 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:47:46 --> Utf8 Class Initialized
INFO - 2016-12-09 04:47:46 --> URI Class Initialized
INFO - 2016-12-09 04:47:46 --> Router Class Initialized
INFO - 2016-12-09 04:47:46 --> Output Class Initialized
INFO - 2016-12-09 04:47:46 --> Security Class Initialized
DEBUG - 2016-12-09 04:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:47:46 --> Input Class Initialized
INFO - 2016-12-09 04:47:46 --> Language Class Initialized
INFO - 2016-12-09 04:47:46 --> Loader Class Initialized
INFO - 2016-12-09 04:47:46 --> Database Driver Class Initialized
INFO - 2016-12-09 04:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:47:46 --> Controller Class Initialized
INFO - 2016-12-09 04:47:46 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:47:46 --> Final output sent to browser
DEBUG - 2016-12-09 04:47:46 --> Total execution time: 0.0130
INFO - 2016-12-09 04:48:03 --> Config Class Initialized
INFO - 2016-12-09 04:48:03 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:48:03 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:48:03 --> Utf8 Class Initialized
INFO - 2016-12-09 04:48:03 --> URI Class Initialized
INFO - 2016-12-09 04:48:03 --> Router Class Initialized
INFO - 2016-12-09 04:48:03 --> Output Class Initialized
INFO - 2016-12-09 04:48:03 --> Security Class Initialized
DEBUG - 2016-12-09 04:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:48:03 --> Input Class Initialized
INFO - 2016-12-09 04:48:03 --> Language Class Initialized
INFO - 2016-12-09 04:48:03 --> Loader Class Initialized
INFO - 2016-12-09 04:48:03 --> Database Driver Class Initialized
INFO - 2016-12-09 04:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:48:03 --> Controller Class Initialized
INFO - 2016-12-09 04:48:03 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:48:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-09 04:48:03 --> Severity: Notice --> Undefined variable: userProfile /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 125
ERROR - 2016-12-09 04:48:03 --> Severity: Notice --> Undefined variable: userProfile /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 126
ERROR - 2016-12-09 04:48:03 --> Severity: Notice --> Undefined variable: userProfile /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 127
ERROR - 2016-12-09 04:48:03 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, ' ')
INFO - 2016-12-09 04:48:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-09 04:48:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-09 04:48:04 --> Config Class Initialized
INFO - 2016-12-09 04:48:04 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:48:04 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:48:04 --> Utf8 Class Initialized
INFO - 2016-12-09 04:48:04 --> URI Class Initialized
INFO - 2016-12-09 04:48:04 --> Router Class Initialized
INFO - 2016-12-09 04:48:04 --> Output Class Initialized
INFO - 2016-12-09 04:48:04 --> Security Class Initialized
DEBUG - 2016-12-09 04:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:48:04 --> Input Class Initialized
INFO - 2016-12-09 04:48:04 --> Language Class Initialized
INFO - 2016-12-09 04:48:04 --> Loader Class Initialized
INFO - 2016-12-09 04:48:04 --> Database Driver Class Initialized
INFO - 2016-12-09 04:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:48:04 --> Controller Class Initialized
INFO - 2016-12-09 04:48:04 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:48:04 --> Final output sent to browser
DEBUG - 2016-12-09 04:48:04 --> Total execution time: 0.0138
INFO - 2016-12-09 04:48:22 --> Config Class Initialized
INFO - 2016-12-09 04:48:22 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:48:22 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:48:22 --> Utf8 Class Initialized
INFO - 2016-12-09 04:48:22 --> URI Class Initialized
INFO - 2016-12-09 04:48:22 --> Router Class Initialized
INFO - 2016-12-09 04:48:22 --> Output Class Initialized
INFO - 2016-12-09 04:48:22 --> Security Class Initialized
DEBUG - 2016-12-09 04:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:48:23 --> Input Class Initialized
INFO - 2016-12-09 04:48:23 --> Language Class Initialized
INFO - 2016-12-09 04:48:23 --> Loader Class Initialized
INFO - 2016-12-09 04:48:23 --> Database Driver Class Initialized
INFO - 2016-12-09 04:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:48:23 --> Controller Class Initialized
INFO - 2016-12-09 04:48:23 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:48:23 --> Final output sent to browser
DEBUG - 2016-12-09 04:48:23 --> Total execution time: 0.0137
INFO - 2016-12-09 04:48:24 --> Config Class Initialized
INFO - 2016-12-09 04:48:24 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:48:24 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:48:24 --> Utf8 Class Initialized
INFO - 2016-12-09 04:48:24 --> URI Class Initialized
INFO - 2016-12-09 04:48:24 --> Router Class Initialized
INFO - 2016-12-09 04:48:24 --> Output Class Initialized
INFO - 2016-12-09 04:48:24 --> Security Class Initialized
DEBUG - 2016-12-09 04:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:48:24 --> Input Class Initialized
INFO - 2016-12-09 04:48:24 --> Language Class Initialized
INFO - 2016-12-09 04:48:24 --> Loader Class Initialized
INFO - 2016-12-09 04:48:24 --> Database Driver Class Initialized
INFO - 2016-12-09 04:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:48:24 --> Controller Class Initialized
INFO - 2016-12-09 04:48:24 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:48:24 --> Final output sent to browser
DEBUG - 2016-12-09 04:48:24 --> Total execution time: 0.0130
INFO - 2016-12-09 04:48:25 --> Config Class Initialized
INFO - 2016-12-09 04:48:25 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:48:25 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:48:25 --> Utf8 Class Initialized
INFO - 2016-12-09 04:48:25 --> URI Class Initialized
INFO - 2016-12-09 04:48:25 --> Router Class Initialized
INFO - 2016-12-09 04:48:25 --> Output Class Initialized
INFO - 2016-12-09 04:48:25 --> Security Class Initialized
DEBUG - 2016-12-09 04:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:48:25 --> Input Class Initialized
INFO - 2016-12-09 04:48:25 --> Language Class Initialized
INFO - 2016-12-09 04:48:25 --> Loader Class Initialized
INFO - 2016-12-09 04:48:25 --> Database Driver Class Initialized
INFO - 2016-12-09 04:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:48:25 --> Controller Class Initialized
INFO - 2016-12-09 04:48:25 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:48:25 --> Final output sent to browser
DEBUG - 2016-12-09 04:48:25 --> Total execution time: 0.0263
INFO - 2016-12-09 04:50:29 --> Config Class Initialized
INFO - 2016-12-09 04:50:29 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:50:29 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:50:29 --> Utf8 Class Initialized
INFO - 2016-12-09 04:50:29 --> URI Class Initialized
INFO - 2016-12-09 04:50:29 --> Router Class Initialized
INFO - 2016-12-09 04:50:29 --> Output Class Initialized
INFO - 2016-12-09 04:50:29 --> Security Class Initialized
DEBUG - 2016-12-09 04:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:50:29 --> Input Class Initialized
INFO - 2016-12-09 04:50:29 --> Language Class Initialized
INFO - 2016-12-09 04:50:29 --> Loader Class Initialized
INFO - 2016-12-09 04:50:29 --> Database Driver Class Initialized
INFO - 2016-12-09 04:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:50:29 --> Controller Class Initialized
INFO - 2016-12-09 04:50:29 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:50:29 --> Final output sent to browser
DEBUG - 2016-12-09 04:50:29 --> Total execution time: 0.0131
INFO - 2016-12-09 04:51:47 --> Config Class Initialized
INFO - 2016-12-09 04:51:47 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:51:47 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:51:47 --> Utf8 Class Initialized
INFO - 2016-12-09 04:51:47 --> URI Class Initialized
INFO - 2016-12-09 04:51:47 --> Router Class Initialized
INFO - 2016-12-09 04:51:47 --> Output Class Initialized
INFO - 2016-12-09 04:51:47 --> Security Class Initialized
DEBUG - 2016-12-09 04:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:51:47 --> Input Class Initialized
INFO - 2016-12-09 04:51:47 --> Language Class Initialized
INFO - 2016-12-09 04:51:47 --> Loader Class Initialized
INFO - 2016-12-09 04:51:47 --> Database Driver Class Initialized
INFO - 2016-12-09 04:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:51:47 --> Controller Class Initialized
INFO - 2016-12-09 04:51:47 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:51:47 --> Final output sent to browser
DEBUG - 2016-12-09 04:51:47 --> Total execution time: 0.0128
INFO - 2016-12-09 04:53:45 --> Config Class Initialized
INFO - 2016-12-09 04:53:45 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:45 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:45 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:45 --> URI Class Initialized
INFO - 2016-12-09 04:53:45 --> Router Class Initialized
INFO - 2016-12-09 04:53:45 --> Output Class Initialized
INFO - 2016-12-09 04:53:45 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:45 --> Input Class Initialized
INFO - 2016-12-09 04:53:45 --> Language Class Initialized
INFO - 2016-12-09 04:53:46 --> Loader Class Initialized
INFO - 2016-12-09 04:53:46 --> Database Driver Class Initialized
INFO - 2016-12-09 04:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:53:46 --> Controller Class Initialized
INFO - 2016-12-09 04:53:46 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:53:46 --> Final output sent to browser
DEBUG - 2016-12-09 04:53:46 --> Total execution time: 0.0131
INFO - 2016-12-09 04:53:49 --> Config Class Initialized
INFO - 2016-12-09 04:53:49 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:49 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:49 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:49 --> URI Class Initialized
DEBUG - 2016-12-09 04:53:49 --> No URI present. Default controller set.
INFO - 2016-12-09 04:53:49 --> Router Class Initialized
INFO - 2016-12-09 04:53:49 --> Output Class Initialized
INFO - 2016-12-09 04:53:49 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:49 --> Input Class Initialized
INFO - 2016-12-09 04:53:49 --> Language Class Initialized
INFO - 2016-12-09 04:53:49 --> Loader Class Initialized
INFO - 2016-12-09 04:53:49 --> Database Driver Class Initialized
INFO - 2016-12-09 04:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:53:49 --> Controller Class Initialized
INFO - 2016-12-09 04:53:49 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:53:49 --> Final output sent to browser
DEBUG - 2016-12-09 04:53:49 --> Total execution time: 0.0134
INFO - 2016-12-09 04:53:49 --> Config Class Initialized
INFO - 2016-12-09 04:53:49 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:49 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:49 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:49 --> URI Class Initialized
INFO - 2016-12-09 04:53:49 --> Router Class Initialized
INFO - 2016-12-09 04:53:49 --> Output Class Initialized
INFO - 2016-12-09 04:53:49 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:49 --> Input Class Initialized
INFO - 2016-12-09 04:53:49 --> Language Class Initialized
INFO - 2016-12-09 04:53:49 --> Loader Class Initialized
INFO - 2016-12-09 04:53:49 --> Database Driver Class Initialized
INFO - 2016-12-09 04:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:53:49 --> Controller Class Initialized
INFO - 2016-12-09 04:53:49 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:53:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:53:49 --> Final output sent to browser
DEBUG - 2016-12-09 04:53:49 --> Total execution time: 0.0136
INFO - 2016-12-09 04:53:56 --> Config Class Initialized
INFO - 2016-12-09 04:53:56 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:56 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:56 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:56 --> URI Class Initialized
INFO - 2016-12-09 04:53:56 --> Router Class Initialized
INFO - 2016-12-09 04:53:56 --> Output Class Initialized
INFO - 2016-12-09 04:53:56 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:56 --> Input Class Initialized
INFO - 2016-12-09 04:53:56 --> Language Class Initialized
INFO - 2016-12-09 04:53:56 --> Loader Class Initialized
INFO - 2016-12-09 04:53:56 --> Database Driver Class Initialized
INFO - 2016-12-09 04:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:53:56 --> Controller Class Initialized
INFO - 2016-12-09 04:53:56 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:53:56 --> Final output sent to browser
DEBUG - 2016-12-09 04:53:56 --> Total execution time: 0.0335
INFO - 2016-12-09 04:53:56 --> Config Class Initialized
INFO - 2016-12-09 04:53:56 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:56 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:56 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:56 --> URI Class Initialized
INFO - 2016-12-09 04:53:56 --> Router Class Initialized
INFO - 2016-12-09 04:53:56 --> Output Class Initialized
INFO - 2016-12-09 04:53:56 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:56 --> Input Class Initialized
INFO - 2016-12-09 04:53:56 --> Language Class Initialized
ERROR - 2016-12-09 04:53:56 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 04:53:56 --> Config Class Initialized
INFO - 2016-12-09 04:53:56 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:56 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:56 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:56 --> URI Class Initialized
INFO - 2016-12-09 04:53:56 --> Router Class Initialized
INFO - 2016-12-09 04:53:56 --> Output Class Initialized
INFO - 2016-12-09 04:53:56 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:56 --> Input Class Initialized
INFO - 2016-12-09 04:53:56 --> Language Class Initialized
ERROR - 2016-12-09 04:53:56 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 04:53:56 --> Config Class Initialized
INFO - 2016-12-09 04:53:56 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:56 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:56 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:56 --> URI Class Initialized
INFO - 2016-12-09 04:53:56 --> Router Class Initialized
INFO - 2016-12-09 04:53:56 --> Output Class Initialized
INFO - 2016-12-09 04:53:56 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:56 --> Input Class Initialized
INFO - 2016-12-09 04:53:56 --> Language Class Initialized
ERROR - 2016-12-09 04:53:56 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 04:53:56 --> Config Class Initialized
INFO - 2016-12-09 04:53:56 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:56 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:56 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:56 --> URI Class Initialized
INFO - 2016-12-09 04:53:56 --> Router Class Initialized
INFO - 2016-12-09 04:53:56 --> Output Class Initialized
INFO - 2016-12-09 04:53:56 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:56 --> Input Class Initialized
INFO - 2016-12-09 04:53:56 --> Language Class Initialized
ERROR - 2016-12-09 04:53:56 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 04:53:56 --> Config Class Initialized
INFO - 2016-12-09 04:53:56 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:53:56 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:53:56 --> Utf8 Class Initialized
INFO - 2016-12-09 04:53:56 --> URI Class Initialized
INFO - 2016-12-09 04:53:56 --> Router Class Initialized
INFO - 2016-12-09 04:53:56 --> Output Class Initialized
INFO - 2016-12-09 04:53:56 --> Security Class Initialized
DEBUG - 2016-12-09 04:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:53:56 --> Input Class Initialized
INFO - 2016-12-09 04:53:56 --> Language Class Initialized
INFO - 2016-12-09 04:53:56 --> Loader Class Initialized
INFO - 2016-12-09 04:53:56 --> Database Driver Class Initialized
INFO - 2016-12-09 04:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:53:56 --> Controller Class Initialized
INFO - 2016-12-09 04:53:56 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 04:53:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 04:53:56 --> Final output sent to browser
DEBUG - 2016-12-09 04:53:56 --> Total execution time: 0.0133
INFO - 2016-12-09 04:54:11 --> Config Class Initialized
INFO - 2016-12-09 04:54:11 --> Hooks Class Initialized
DEBUG - 2016-12-09 04:54:11 --> UTF-8 Support Enabled
INFO - 2016-12-09 04:54:11 --> Utf8 Class Initialized
INFO - 2016-12-09 04:54:11 --> URI Class Initialized
INFO - 2016-12-09 04:54:11 --> Router Class Initialized
INFO - 2016-12-09 04:54:11 --> Output Class Initialized
INFO - 2016-12-09 04:54:11 --> Security Class Initialized
DEBUG - 2016-12-09 04:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 04:54:11 --> Input Class Initialized
INFO - 2016-12-09 04:54:11 --> Language Class Initialized
INFO - 2016-12-09 04:54:11 --> Loader Class Initialized
INFO - 2016-12-09 04:54:11 --> Database Driver Class Initialized
INFO - 2016-12-09 04:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 04:54:11 --> Controller Class Initialized
INFO - 2016-12-09 04:54:11 --> Helper loaded: url_helper
DEBUG - 2016-12-09 04:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 04:54:11 --> Final output sent to browser
DEBUG - 2016-12-09 04:54:11 --> Total execution time: 0.0127
INFO - 2016-12-09 05:00:25 --> Config Class Initialized
INFO - 2016-12-09 05:00:25 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:00:25 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:00:25 --> Utf8 Class Initialized
INFO - 2016-12-09 05:00:25 --> URI Class Initialized
INFO - 2016-12-09 05:00:25 --> Router Class Initialized
INFO - 2016-12-09 05:00:25 --> Output Class Initialized
INFO - 2016-12-09 05:00:25 --> Security Class Initialized
DEBUG - 2016-12-09 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:00:25 --> Input Class Initialized
INFO - 2016-12-09 05:00:25 --> Language Class Initialized
INFO - 2016-12-09 05:00:25 --> Loader Class Initialized
INFO - 2016-12-09 05:00:25 --> Database Driver Class Initialized
INFO - 2016-12-09 05:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:00:25 --> Controller Class Initialized
INFO - 2016-12-09 05:00:25 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:00:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:00:25 --> Final output sent to browser
DEBUG - 2016-12-09 05:00:25 --> Total execution time: 0.0296
INFO - 2016-12-09 05:00:25 --> Config Class Initialized
INFO - 2016-12-09 05:00:25 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:00:25 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:00:25 --> Utf8 Class Initialized
INFO - 2016-12-09 05:00:25 --> URI Class Initialized
INFO - 2016-12-09 05:00:25 --> Router Class Initialized
INFO - 2016-12-09 05:00:25 --> Output Class Initialized
INFO - 2016-12-09 05:00:25 --> Security Class Initialized
DEBUG - 2016-12-09 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:00:25 --> Input Class Initialized
INFO - 2016-12-09 05:00:25 --> Language Class Initialized
ERROR - 2016-12-09 05:00:25 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:00:25 --> Config Class Initialized
INFO - 2016-12-09 05:00:25 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:00:25 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:00:25 --> Utf8 Class Initialized
INFO - 2016-12-09 05:00:25 --> URI Class Initialized
INFO - 2016-12-09 05:00:25 --> Router Class Initialized
INFO - 2016-12-09 05:00:25 --> Output Class Initialized
INFO - 2016-12-09 05:00:25 --> Security Class Initialized
DEBUG - 2016-12-09 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:00:25 --> Input Class Initialized
INFO - 2016-12-09 05:00:25 --> Language Class Initialized
ERROR - 2016-12-09 05:00:25 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:00:25 --> Config Class Initialized
INFO - 2016-12-09 05:00:25 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:00:25 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:00:25 --> Utf8 Class Initialized
INFO - 2016-12-09 05:00:25 --> URI Class Initialized
INFO - 2016-12-09 05:00:25 --> Router Class Initialized
INFO - 2016-12-09 05:00:25 --> Config Class Initialized
INFO - 2016-12-09 05:00:25 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:00:25 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:00:25 --> Utf8 Class Initialized
INFO - 2016-12-09 05:00:25 --> URI Class Initialized
INFO - 2016-12-09 05:00:25 --> Router Class Initialized
INFO - 2016-12-09 05:00:25 --> Output Class Initialized
INFO - 2016-12-09 05:00:25 --> Security Class Initialized
DEBUG - 2016-12-09 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:00:25 --> Input Class Initialized
INFO - 2016-12-09 05:00:25 --> Language Class Initialized
ERROR - 2016-12-09 05:00:25 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:00:26 --> Output Class Initialized
INFO - 2016-12-09 05:00:26 --> Security Class Initialized
DEBUG - 2016-12-09 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:00:26 --> Input Class Initialized
INFO - 2016-12-09 05:00:26 --> Language Class Initialized
ERROR - 2016-12-09 05:00:26 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:00:26 --> Config Class Initialized
INFO - 2016-12-09 05:00:26 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:00:26 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:00:26 --> Utf8 Class Initialized
INFO - 2016-12-09 05:00:26 --> URI Class Initialized
INFO - 2016-12-09 05:00:26 --> Router Class Initialized
INFO - 2016-12-09 05:00:26 --> Output Class Initialized
INFO - 2016-12-09 05:00:26 --> Security Class Initialized
DEBUG - 2016-12-09 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:00:26 --> Input Class Initialized
INFO - 2016-12-09 05:00:26 --> Language Class Initialized
INFO - 2016-12-09 05:00:26 --> Loader Class Initialized
INFO - 2016-12-09 05:00:26 --> Database Driver Class Initialized
INFO - 2016-12-09 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:00:26 --> Controller Class Initialized
INFO - 2016-12-09 05:00:26 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:00:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:00:26 --> Final output sent to browser
DEBUG - 2016-12-09 05:00:26 --> Total execution time: 0.0143
INFO - 2016-12-09 05:02:19 --> Config Class Initialized
INFO - 2016-12-09 05:02:19 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:02:19 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:02:19 --> Utf8 Class Initialized
INFO - 2016-12-09 05:02:19 --> URI Class Initialized
INFO - 2016-12-09 05:02:19 --> Router Class Initialized
INFO - 2016-12-09 05:02:19 --> Output Class Initialized
INFO - 2016-12-09 05:02:19 --> Security Class Initialized
DEBUG - 2016-12-09 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:02:19 --> Input Class Initialized
INFO - 2016-12-09 05:02:19 --> Language Class Initialized
INFO - 2016-12-09 05:02:19 --> Loader Class Initialized
INFO - 2016-12-09 05:02:19 --> Database Driver Class Initialized
INFO - 2016-12-09 05:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:02:19 --> Controller Class Initialized
INFO - 2016-12-09 05:02:19 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:02:19 --> Final output sent to browser
DEBUG - 2016-12-09 05:02:19 --> Total execution time: 0.0142
INFO - 2016-12-09 05:02:19 --> Config Class Initialized
INFO - 2016-12-09 05:02:19 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:02:19 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:02:19 --> Utf8 Class Initialized
INFO - 2016-12-09 05:02:19 --> URI Class Initialized
INFO - 2016-12-09 05:02:19 --> Router Class Initialized
INFO - 2016-12-09 05:02:19 --> Output Class Initialized
INFO - 2016-12-09 05:02:19 --> Security Class Initialized
DEBUG - 2016-12-09 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:02:19 --> Input Class Initialized
INFO - 2016-12-09 05:02:19 --> Language Class Initialized
ERROR - 2016-12-09 05:02:19 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:02:19 --> Config Class Initialized
INFO - 2016-12-09 05:02:19 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:02:19 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:02:19 --> Utf8 Class Initialized
INFO - 2016-12-09 05:02:19 --> URI Class Initialized
INFO - 2016-12-09 05:02:19 --> Router Class Initialized
INFO - 2016-12-09 05:02:19 --> Output Class Initialized
INFO - 2016-12-09 05:02:19 --> Security Class Initialized
DEBUG - 2016-12-09 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:02:19 --> Input Class Initialized
INFO - 2016-12-09 05:02:19 --> Language Class Initialized
ERROR - 2016-12-09 05:02:19 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:02:19 --> Config Class Initialized
INFO - 2016-12-09 05:02:19 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:02:19 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:02:19 --> Utf8 Class Initialized
INFO - 2016-12-09 05:02:19 --> URI Class Initialized
INFO - 2016-12-09 05:02:19 --> Router Class Initialized
INFO - 2016-12-09 05:02:19 --> Output Class Initialized
INFO - 2016-12-09 05:02:19 --> Security Class Initialized
DEBUG - 2016-12-09 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:02:19 --> Input Class Initialized
INFO - 2016-12-09 05:02:19 --> Config Class Initialized
INFO - 2016-12-09 05:02:19 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:02:19 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:02:19 --> Utf8 Class Initialized
INFO - 2016-12-09 05:02:19 --> URI Class Initialized
INFO - 2016-12-09 05:02:19 --> Router Class Initialized
INFO - 2016-12-09 05:02:19 --> Output Class Initialized
INFO - 2016-12-09 05:02:19 --> Security Class Initialized
DEBUG - 2016-12-09 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:02:19 --> Input Class Initialized
INFO - 2016-12-09 05:02:19 --> Language Class Initialized
ERROR - 2016-12-09 05:02:19 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:02:19 --> Language Class Initialized
ERROR - 2016-12-09 05:02:19 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:02:20 --> Config Class Initialized
INFO - 2016-12-09 05:02:20 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:02:20 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:02:20 --> Utf8 Class Initialized
INFO - 2016-12-09 05:02:20 --> URI Class Initialized
INFO - 2016-12-09 05:02:20 --> Router Class Initialized
INFO - 2016-12-09 05:02:20 --> Output Class Initialized
INFO - 2016-12-09 05:02:20 --> Security Class Initialized
DEBUG - 2016-12-09 05:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:02:20 --> Input Class Initialized
INFO - 2016-12-09 05:02:20 --> Language Class Initialized
INFO - 2016-12-09 05:02:20 --> Loader Class Initialized
INFO - 2016-12-09 05:02:20 --> Database Driver Class Initialized
INFO - 2016-12-09 05:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:02:20 --> Controller Class Initialized
INFO - 2016-12-09 05:02:20 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:02:20 --> Final output sent to browser
DEBUG - 2016-12-09 05:02:20 --> Total execution time: 0.0147
INFO - 2016-12-09 05:04:31 --> Config Class Initialized
INFO - 2016-12-09 05:04:31 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:31 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:31 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:31 --> URI Class Initialized
INFO - 2016-12-09 05:04:31 --> Router Class Initialized
INFO - 2016-12-09 05:04:31 --> Output Class Initialized
INFO - 2016-12-09 05:04:31 --> Security Class Initialized
DEBUG - 2016-12-09 05:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:31 --> Input Class Initialized
INFO - 2016-12-09 05:04:31 --> Language Class Initialized
INFO - 2016-12-09 05:04:31 --> Loader Class Initialized
INFO - 2016-12-09 05:04:31 --> Database Driver Class Initialized
INFO - 2016-12-09 05:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:04:31 --> Controller Class Initialized
INFO - 2016-12-09 05:04:31 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:04:31 --> Final output sent to browser
DEBUG - 2016-12-09 05:04:31 --> Total execution time: 0.0291
INFO - 2016-12-09 05:04:31 --> Config Class Initialized
INFO - 2016-12-09 05:04:31 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:31 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:31 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:31 --> URI Class Initialized
INFO - 2016-12-09 05:04:31 --> Router Class Initialized
INFO - 2016-12-09 05:04:31 --> Output Class Initialized
INFO - 2016-12-09 05:04:31 --> Security Class Initialized
DEBUG - 2016-12-09 05:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:31 --> Input Class Initialized
INFO - 2016-12-09 05:04:31 --> Language Class Initialized
ERROR - 2016-12-09 05:04:31 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:04:31 --> Config Class Initialized
INFO - 2016-12-09 05:04:31 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:31 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:31 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:31 --> URI Class Initialized
INFO - 2016-12-09 05:04:31 --> Router Class Initialized
INFO - 2016-12-09 05:04:31 --> Output Class Initialized
INFO - 2016-12-09 05:04:31 --> Security Class Initialized
INFO - 2016-12-09 05:04:32 --> Config Class Initialized
INFO - 2016-12-09 05:04:32 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:32 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:32 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:32 --> URI Class Initialized
INFO - 2016-12-09 05:04:32 --> Router Class Initialized
INFO - 2016-12-09 05:04:32 --> Output Class Initialized
INFO - 2016-12-09 05:04:32 --> Security Class Initialized
DEBUG - 2016-12-09 05:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:32 --> Input Class Initialized
INFO - 2016-12-09 05:04:32 --> Language Class Initialized
ERROR - 2016-12-09 05:04:32 --> 404 Page Not Found: User/templates
DEBUG - 2016-12-09 05:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:32 --> Input Class Initialized
INFO - 2016-12-09 05:04:32 --> Language Class Initialized
ERROR - 2016-12-09 05:04:32 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:04:32 --> Config Class Initialized
INFO - 2016-12-09 05:04:32 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:32 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:32 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:32 --> URI Class Initialized
INFO - 2016-12-09 05:04:32 --> Router Class Initialized
INFO - 2016-12-09 05:04:32 --> Output Class Initialized
INFO - 2016-12-09 05:04:32 --> Security Class Initialized
DEBUG - 2016-12-09 05:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:32 --> Input Class Initialized
INFO - 2016-12-09 05:04:32 --> Language Class Initialized
ERROR - 2016-12-09 05:04:32 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:04:32 --> Config Class Initialized
INFO - 2016-12-09 05:04:32 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:32 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:32 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:32 --> URI Class Initialized
INFO - 2016-12-09 05:04:32 --> Router Class Initialized
INFO - 2016-12-09 05:04:32 --> Output Class Initialized
INFO - 2016-12-09 05:04:32 --> Security Class Initialized
DEBUG - 2016-12-09 05:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:32 --> Input Class Initialized
INFO - 2016-12-09 05:04:32 --> Language Class Initialized
INFO - 2016-12-09 05:04:32 --> Loader Class Initialized
INFO - 2016-12-09 05:04:32 --> Database Driver Class Initialized
INFO - 2016-12-09 05:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:04:32 --> Controller Class Initialized
INFO - 2016-12-09 05:04:32 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:04:32 --> Final output sent to browser
DEBUG - 2016-12-09 05:04:32 --> Total execution time: 0.0148
INFO - 2016-12-09 05:04:52 --> Config Class Initialized
INFO - 2016-12-09 05:04:52 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:52 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:52 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:52 --> URI Class Initialized
DEBUG - 2016-12-09 05:04:52 --> No URI present. Default controller set.
INFO - 2016-12-09 05:04:52 --> Router Class Initialized
INFO - 2016-12-09 05:04:52 --> Output Class Initialized
INFO - 2016-12-09 05:04:52 --> Security Class Initialized
DEBUG - 2016-12-09 05:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:52 --> Input Class Initialized
INFO - 2016-12-09 05:04:52 --> Language Class Initialized
INFO - 2016-12-09 05:04:52 --> Loader Class Initialized
INFO - 2016-12-09 05:04:52 --> Database Driver Class Initialized
INFO - 2016-12-09 05:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:04:52 --> Controller Class Initialized
INFO - 2016-12-09 05:04:52 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:04:52 --> Final output sent to browser
DEBUG - 2016-12-09 05:04:52 --> Total execution time: 0.0151
INFO - 2016-12-09 05:04:53 --> Config Class Initialized
INFO - 2016-12-09 05:04:53 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:04:53 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:04:53 --> Utf8 Class Initialized
INFO - 2016-12-09 05:04:53 --> URI Class Initialized
INFO - 2016-12-09 05:04:53 --> Router Class Initialized
INFO - 2016-12-09 05:04:53 --> Output Class Initialized
INFO - 2016-12-09 05:04:53 --> Security Class Initialized
DEBUG - 2016-12-09 05:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:04:53 --> Input Class Initialized
INFO - 2016-12-09 05:04:53 --> Language Class Initialized
INFO - 2016-12-09 05:04:53 --> Loader Class Initialized
INFO - 2016-12-09 05:04:53 --> Database Driver Class Initialized
INFO - 2016-12-09 05:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:04:53 --> Controller Class Initialized
INFO - 2016-12-09 05:04:53 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:04:53 --> Final output sent to browser
DEBUG - 2016-12-09 05:04:53 --> Total execution time: 0.0718
INFO - 2016-12-09 05:05:08 --> Config Class Initialized
INFO - 2016-12-09 05:05:08 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:08 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:08 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:08 --> URI Class Initialized
DEBUG - 2016-12-09 05:05:08 --> No URI present. Default controller set.
INFO - 2016-12-09 05:05:08 --> Router Class Initialized
INFO - 2016-12-09 05:05:08 --> Output Class Initialized
INFO - 2016-12-09 05:05:08 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:08 --> Input Class Initialized
INFO - 2016-12-09 05:05:08 --> Language Class Initialized
INFO - 2016-12-09 05:05:08 --> Loader Class Initialized
INFO - 2016-12-09 05:05:08 --> Database Driver Class Initialized
INFO - 2016-12-09 05:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:05:08 --> Controller Class Initialized
INFO - 2016-12-09 05:05:08 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:05:08 --> Final output sent to browser
DEBUG - 2016-12-09 05:05:08 --> Total execution time: 0.0130
INFO - 2016-12-09 05:05:08 --> Config Class Initialized
INFO - 2016-12-09 05:05:08 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:08 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:08 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:08 --> URI Class Initialized
INFO - 2016-12-09 05:05:08 --> Router Class Initialized
INFO - 2016-12-09 05:05:08 --> Output Class Initialized
INFO - 2016-12-09 05:05:08 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:08 --> Input Class Initialized
INFO - 2016-12-09 05:05:08 --> Language Class Initialized
INFO - 2016-12-09 05:05:08 --> Loader Class Initialized
INFO - 2016-12-09 05:05:08 --> Database Driver Class Initialized
INFO - 2016-12-09 05:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:05:08 --> Controller Class Initialized
INFO - 2016-12-09 05:05:08 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:05:08 --> Final output sent to browser
DEBUG - 2016-12-09 05:05:08 --> Total execution time: 0.0677
INFO - 2016-12-09 05:05:16 --> Config Class Initialized
INFO - 2016-12-09 05:05:16 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:16 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:16 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:16 --> URI Class Initialized
INFO - 2016-12-09 05:05:16 --> Router Class Initialized
INFO - 2016-12-09 05:05:16 --> Output Class Initialized
INFO - 2016-12-09 05:05:16 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:16 --> Input Class Initialized
INFO - 2016-12-09 05:05:16 --> Language Class Initialized
INFO - 2016-12-09 05:05:16 --> Loader Class Initialized
INFO - 2016-12-09 05:05:16 --> Database Driver Class Initialized
INFO - 2016-12-09 05:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:05:16 --> Controller Class Initialized
INFO - 2016-12-09 05:05:16 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:05:16 --> Final output sent to browser
DEBUG - 2016-12-09 05:05:16 --> Total execution time: 0.0148
INFO - 2016-12-09 05:05:16 --> Config Class Initialized
INFO - 2016-12-09 05:05:16 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:16 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:16 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:16 --> URI Class Initialized
INFO - 2016-12-09 05:05:16 --> Router Class Initialized
INFO - 2016-12-09 05:05:16 --> Output Class Initialized
INFO - 2016-12-09 05:05:16 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:16 --> Input Class Initialized
INFO - 2016-12-09 05:05:16 --> Language Class Initialized
ERROR - 2016-12-09 05:05:16 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:05:16 --> Config Class Initialized
INFO - 2016-12-09 05:05:16 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:16 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:16 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:16 --> URI Class Initialized
INFO - 2016-12-09 05:05:16 --> Router Class Initialized
INFO - 2016-12-09 05:05:16 --> Output Class Initialized
INFO - 2016-12-09 05:05:16 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:16 --> Input Class Initialized
INFO - 2016-12-09 05:05:16 --> Language Class Initialized
ERROR - 2016-12-09 05:05:16 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:05:16 --> Config Class Initialized
INFO - 2016-12-09 05:05:16 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:16 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:16 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:16 --> URI Class Initialized
INFO - 2016-12-09 05:05:16 --> Router Class Initialized
INFO - 2016-12-09 05:05:16 --> Output Class Initialized
INFO - 2016-12-09 05:05:16 --> Config Class Initialized
INFO - 2016-12-09 05:05:16 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:16 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:16 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:16 --> URI Class Initialized
INFO - 2016-12-09 05:05:16 --> Router Class Initialized
INFO - 2016-12-09 05:05:16 --> Output Class Initialized
INFO - 2016-12-09 05:05:16 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:16 --> Input Class Initialized
INFO - 2016-12-09 05:05:16 --> Language Class Initialized
ERROR - 2016-12-09 05:05:16 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:05:16 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:16 --> Input Class Initialized
INFO - 2016-12-09 05:05:16 --> Language Class Initialized
ERROR - 2016-12-09 05:05:16 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:05:17 --> Config Class Initialized
INFO - 2016-12-09 05:05:17 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:05:17 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:05:17 --> Utf8 Class Initialized
INFO - 2016-12-09 05:05:17 --> URI Class Initialized
INFO - 2016-12-09 05:05:17 --> Router Class Initialized
INFO - 2016-12-09 05:05:17 --> Output Class Initialized
INFO - 2016-12-09 05:05:17 --> Security Class Initialized
DEBUG - 2016-12-09 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:05:17 --> Input Class Initialized
INFO - 2016-12-09 05:05:17 --> Language Class Initialized
INFO - 2016-12-09 05:05:17 --> Loader Class Initialized
INFO - 2016-12-09 05:05:17 --> Database Driver Class Initialized
INFO - 2016-12-09 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:05:17 --> Controller Class Initialized
INFO - 2016-12-09 05:05:17 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:05:17 --> Final output sent to browser
DEBUG - 2016-12-09 05:05:17 --> Total execution time: 0.0129
INFO - 2016-12-09 05:06:23 --> Config Class Initialized
INFO - 2016-12-09 05:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:06:23 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:06:23 --> Utf8 Class Initialized
INFO - 2016-12-09 05:06:23 --> URI Class Initialized
INFO - 2016-12-09 05:06:23 --> Router Class Initialized
INFO - 2016-12-09 05:06:23 --> Output Class Initialized
INFO - 2016-12-09 05:06:23 --> Security Class Initialized
DEBUG - 2016-12-09 05:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:06:23 --> Input Class Initialized
INFO - 2016-12-09 05:06:23 --> Language Class Initialized
ERROR - 2016-12-09 05:06:23 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:06:24 --> Config Class Initialized
INFO - 2016-12-09 05:06:24 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:06:24 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:06:24 --> Utf8 Class Initialized
INFO - 2016-12-09 05:06:24 --> URI Class Initialized
INFO - 2016-12-09 05:06:24 --> Router Class Initialized
INFO - 2016-12-09 05:06:24 --> Output Class Initialized
INFO - 2016-12-09 05:06:24 --> Security Class Initialized
DEBUG - 2016-12-09 05:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:06:24 --> Input Class Initialized
INFO - 2016-12-09 05:06:24 --> Language Class Initialized
ERROR - 2016-12-09 05:06:24 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:06:24 --> Config Class Initialized
INFO - 2016-12-09 05:06:24 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:06:24 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:06:24 --> Utf8 Class Initialized
INFO - 2016-12-09 05:06:24 --> URI Class Initialized
INFO - 2016-12-09 05:06:24 --> Router Class Initialized
INFO - 2016-12-09 05:06:24 --> Config Class Initialized
INFO - 2016-12-09 05:06:24 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:06:24 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:06:24 --> Utf8 Class Initialized
INFO - 2016-12-09 05:06:24 --> URI Class Initialized
INFO - 2016-12-09 05:06:24 --> Router Class Initialized
INFO - 2016-12-09 05:06:24 --> Output Class Initialized
INFO - 2016-12-09 05:06:24 --> Security Class Initialized
DEBUG - 2016-12-09 05:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:06:24 --> Input Class Initialized
INFO - 2016-12-09 05:06:24 --> Language Class Initialized
ERROR - 2016-12-09 05:06:24 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:06:24 --> Output Class Initialized
INFO - 2016-12-09 05:06:24 --> Security Class Initialized
DEBUG - 2016-12-09 05:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:06:24 --> Input Class Initialized
INFO - 2016-12-09 05:06:24 --> Language Class Initialized
ERROR - 2016-12-09 05:06:24 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:06:24 --> Config Class Initialized
INFO - 2016-12-09 05:06:24 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:06:24 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:06:24 --> Utf8 Class Initialized
INFO - 2016-12-09 05:06:24 --> URI Class Initialized
INFO - 2016-12-09 05:06:24 --> Router Class Initialized
INFO - 2016-12-09 05:06:24 --> Output Class Initialized
INFO - 2016-12-09 05:06:24 --> Security Class Initialized
DEBUG - 2016-12-09 05:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:06:24 --> Input Class Initialized
INFO - 2016-12-09 05:06:24 --> Language Class Initialized
ERROR - 2016-12-09 05:06:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:08:55 --> Config Class Initialized
INFO - 2016-12-09 05:08:55 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:08:55 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:08:55 --> Utf8 Class Initialized
INFO - 2016-12-09 05:08:55 --> URI Class Initialized
DEBUG - 2016-12-09 05:08:55 --> No URI present. Default controller set.
INFO - 2016-12-09 05:08:55 --> Router Class Initialized
INFO - 2016-12-09 05:08:55 --> Output Class Initialized
INFO - 2016-12-09 05:08:55 --> Security Class Initialized
DEBUG - 2016-12-09 05:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:08:55 --> Input Class Initialized
INFO - 2016-12-09 05:08:55 --> Language Class Initialized
INFO - 2016-12-09 05:08:55 --> Loader Class Initialized
INFO - 2016-12-09 05:08:56 --> Database Driver Class Initialized
INFO - 2016-12-09 05:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:08:56 --> Controller Class Initialized
INFO - 2016-12-09 05:08:56 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:08:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:08:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:08:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:08:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:08:56 --> Final output sent to browser
DEBUG - 2016-12-09 05:08:56 --> Total execution time: 1.1914
INFO - 2016-12-09 05:08:57 --> Config Class Initialized
INFO - 2016-12-09 05:08:57 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:08:57 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:08:57 --> Utf8 Class Initialized
INFO - 2016-12-09 05:08:57 --> URI Class Initialized
INFO - 2016-12-09 05:08:57 --> Router Class Initialized
INFO - 2016-12-09 05:08:57 --> Output Class Initialized
INFO - 2016-12-09 05:08:57 --> Security Class Initialized
DEBUG - 2016-12-09 05:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:08:57 --> Input Class Initialized
INFO - 2016-12-09 05:08:57 --> Language Class Initialized
INFO - 2016-12-09 05:08:57 --> Loader Class Initialized
INFO - 2016-12-09 05:08:57 --> Database Driver Class Initialized
INFO - 2016-12-09 05:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:08:57 --> Controller Class Initialized
INFO - 2016-12-09 05:08:57 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:08:57 --> Final output sent to browser
DEBUG - 2016-12-09 05:08:57 --> Total execution time: 0.0482
INFO - 2016-12-09 05:09:02 --> Config Class Initialized
INFO - 2016-12-09 05:09:02 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:09:02 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:09:02 --> Utf8 Class Initialized
INFO - 2016-12-09 05:09:02 --> URI Class Initialized
INFO - 2016-12-09 05:09:02 --> Router Class Initialized
INFO - 2016-12-09 05:09:02 --> Output Class Initialized
INFO - 2016-12-09 05:09:02 --> Security Class Initialized
DEBUG - 2016-12-09 05:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:09:02 --> Input Class Initialized
INFO - 2016-12-09 05:09:02 --> Language Class Initialized
ERROR - 2016-12-09 05:09:02 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:09:04 --> Config Class Initialized
INFO - 2016-12-09 05:09:04 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:09:04 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:09:04 --> Utf8 Class Initialized
INFO - 2016-12-09 05:09:04 --> URI Class Initialized
DEBUG - 2016-12-09 05:09:04 --> No URI present. Default controller set.
INFO - 2016-12-09 05:09:04 --> Router Class Initialized
INFO - 2016-12-09 05:09:04 --> Output Class Initialized
INFO - 2016-12-09 05:09:04 --> Security Class Initialized
DEBUG - 2016-12-09 05:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:09:04 --> Input Class Initialized
INFO - 2016-12-09 05:09:04 --> Language Class Initialized
INFO - 2016-12-09 05:09:04 --> Loader Class Initialized
INFO - 2016-12-09 05:09:04 --> Database Driver Class Initialized
INFO - 2016-12-09 05:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:09:04 --> Controller Class Initialized
INFO - 2016-12-09 05:09:04 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:09:04 --> Final output sent to browser
DEBUG - 2016-12-09 05:09:04 --> Total execution time: 0.0136
INFO - 2016-12-09 05:09:56 --> Config Class Initialized
INFO - 2016-12-09 05:09:56 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:09:56 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:09:56 --> Utf8 Class Initialized
INFO - 2016-12-09 05:09:56 --> URI Class Initialized
INFO - 2016-12-09 05:09:56 --> Router Class Initialized
INFO - 2016-12-09 05:09:56 --> Output Class Initialized
INFO - 2016-12-09 05:09:56 --> Security Class Initialized
DEBUG - 2016-12-09 05:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:09:56 --> Input Class Initialized
INFO - 2016-12-09 05:09:56 --> Language Class Initialized
INFO - 2016-12-09 05:09:56 --> Loader Class Initialized
INFO - 2016-12-09 05:09:56 --> Database Driver Class Initialized
INFO - 2016-12-09 05:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:09:56 --> Controller Class Initialized
INFO - 2016-12-09 05:09:56 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:09:56 --> Final output sent to browser
DEBUG - 2016-12-09 05:09:56 --> Total execution time: 0.0288
INFO - 2016-12-09 05:13:32 --> Config Class Initialized
INFO - 2016-12-09 05:13:32 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:13:32 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:13:32 --> Utf8 Class Initialized
INFO - 2016-12-09 05:13:32 --> URI Class Initialized
INFO - 2016-12-09 05:13:32 --> Router Class Initialized
INFO - 2016-12-09 05:13:32 --> Output Class Initialized
INFO - 2016-12-09 05:13:32 --> Security Class Initialized
DEBUG - 2016-12-09 05:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:13:32 --> Input Class Initialized
INFO - 2016-12-09 05:13:32 --> Language Class Initialized
INFO - 2016-12-09 05:13:32 --> Loader Class Initialized
INFO - 2016-12-09 05:13:32 --> Database Driver Class Initialized
INFO - 2016-12-09 05:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:13:32 --> Controller Class Initialized
INFO - 2016-12-09 05:13:32 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:13:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:13:32 --> Final output sent to browser
DEBUG - 2016-12-09 05:13:32 --> Total execution time: 0.0140
INFO - 2016-12-09 05:13:33 --> Config Class Initialized
INFO - 2016-12-09 05:13:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:13:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:13:33 --> Utf8 Class Initialized
INFO - 2016-12-09 05:13:33 --> URI Class Initialized
INFO - 2016-12-09 05:13:33 --> Router Class Initialized
INFO - 2016-12-09 05:13:33 --> Output Class Initialized
INFO - 2016-12-09 05:13:33 --> Security Class Initialized
DEBUG - 2016-12-09 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:13:33 --> Input Class Initialized
INFO - 2016-12-09 05:13:33 --> Language Class Initialized
ERROR - 2016-12-09 05:13:33 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:13:33 --> Config Class Initialized
INFO - 2016-12-09 05:13:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:13:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:13:33 --> Utf8 Class Initialized
INFO - 2016-12-09 05:13:33 --> URI Class Initialized
INFO - 2016-12-09 05:13:33 --> Router Class Initialized
INFO - 2016-12-09 05:13:33 --> Output Class Initialized
INFO - 2016-12-09 05:13:33 --> Security Class Initialized
DEBUG - 2016-12-09 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:13:33 --> Input Class Initialized
INFO - 2016-12-09 05:13:33 --> Language Class Initialized
ERROR - 2016-12-09 05:13:33 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:13:33 --> Config Class Initialized
INFO - 2016-12-09 05:13:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:13:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:13:33 --> Utf8 Class Initialized
INFO - 2016-12-09 05:13:33 --> URI Class Initialized
INFO - 2016-12-09 05:13:33 --> Router Class Initialized
INFO - 2016-12-09 05:13:33 --> Output Class Initialized
INFO - 2016-12-09 05:13:33 --> Security Class Initialized
DEBUG - 2016-12-09 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:13:33 --> Input Class Initialized
INFO - 2016-12-09 05:13:33 --> Language Class Initialized
ERROR - 2016-12-09 05:13:33 --> 404 Page Not Found: User/templates
INFO - 2016-12-09 05:13:33 --> Config Class Initialized
INFO - 2016-12-09 05:13:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:13:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:13:33 --> Utf8 Class Initialized
INFO - 2016-12-09 05:13:33 --> URI Class Initialized
INFO - 2016-12-09 05:13:33 --> Router Class Initialized
INFO - 2016-12-09 05:13:33 --> Output Class Initialized
INFO - 2016-12-09 05:13:33 --> Security Class Initialized
DEBUG - 2016-12-09 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:13:33 --> Input Class Initialized
INFO - 2016-12-09 05:13:33 --> Language Class Initialized
ERROR - 2016-12-09 05:13:33 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:13:33 --> Config Class Initialized
INFO - 2016-12-09 05:13:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:13:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:13:33 --> Utf8 Class Initialized
INFO - 2016-12-09 05:13:33 --> URI Class Initialized
INFO - 2016-12-09 05:13:33 --> Router Class Initialized
INFO - 2016-12-09 05:13:33 --> Output Class Initialized
INFO - 2016-12-09 05:13:33 --> Security Class Initialized
DEBUG - 2016-12-09 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:13:33 --> Input Class Initialized
INFO - 2016-12-09 05:13:33 --> Language Class Initialized
INFO - 2016-12-09 05:13:33 --> Loader Class Initialized
INFO - 2016-12-09 05:13:33 --> Database Driver Class Initialized
INFO - 2016-12-09 05:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:13:33 --> Controller Class Initialized
INFO - 2016-12-09 05:13:33 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:13:33 --> Final output sent to browser
DEBUG - 2016-12-09 05:13:33 --> Total execution time: 0.0135
INFO - 2016-12-09 05:14:37 --> Config Class Initialized
INFO - 2016-12-09 05:14:37 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:37 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:37 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:37 --> URI Class Initialized
INFO - 2016-12-09 05:14:37 --> Router Class Initialized
INFO - 2016-12-09 05:14:37 --> Output Class Initialized
INFO - 2016-12-09 05:14:37 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:37 --> Input Class Initialized
INFO - 2016-12-09 05:14:37 --> Language Class Initialized
INFO - 2016-12-09 05:14:37 --> Loader Class Initialized
INFO - 2016-12-09 05:14:37 --> Database Driver Class Initialized
INFO - 2016-12-09 05:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:14:37 --> Controller Class Initialized
INFO - 2016-12-09 05:14:37 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:14:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-09 05:14:37 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`, `contraseña`) VALUES (NULL, NULL, NULL)
INFO - 2016-12-09 05:14:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-09 05:14:37 --> Config Class Initialized
INFO - 2016-12-09 05:14:37 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:37 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:37 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:37 --> URI Class Initialized
INFO - 2016-12-09 05:14:37 --> Router Class Initialized
INFO - 2016-12-09 05:14:37 --> Output Class Initialized
INFO - 2016-12-09 05:14:37 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:37 --> Input Class Initialized
INFO - 2016-12-09 05:14:37 --> Language Class Initialized
INFO - 2016-12-09 05:14:37 --> Loader Class Initialized
INFO - 2016-12-09 05:14:37 --> Database Driver Class Initialized
INFO - 2016-12-09 05:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:14:37 --> Controller Class Initialized
INFO - 2016-12-09 05:14:37 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:14:37 --> Final output sent to browser
DEBUG - 2016-12-09 05:14:37 --> Total execution time: 0.0134
INFO - 2016-12-09 05:14:44 --> Config Class Initialized
INFO - 2016-12-09 05:14:44 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:44 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:44 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:44 --> URI Class Initialized
DEBUG - 2016-12-09 05:14:44 --> No URI present. Default controller set.
INFO - 2016-12-09 05:14:44 --> Router Class Initialized
INFO - 2016-12-09 05:14:44 --> Output Class Initialized
INFO - 2016-12-09 05:14:44 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:44 --> Input Class Initialized
INFO - 2016-12-09 05:14:44 --> Language Class Initialized
INFO - 2016-12-09 05:14:44 --> Loader Class Initialized
INFO - 2016-12-09 05:14:44 --> Database Driver Class Initialized
INFO - 2016-12-09 05:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:14:44 --> Controller Class Initialized
INFO - 2016-12-09 05:14:44 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:14:44 --> Final output sent to browser
DEBUG - 2016-12-09 05:14:44 --> Total execution time: 0.0136
INFO - 2016-12-09 05:14:44 --> Config Class Initialized
INFO - 2016-12-09 05:14:44 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:44 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:44 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:44 --> URI Class Initialized
INFO - 2016-12-09 05:14:44 --> Router Class Initialized
INFO - 2016-12-09 05:14:44 --> Output Class Initialized
INFO - 2016-12-09 05:14:44 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:44 --> Input Class Initialized
INFO - 2016-12-09 05:14:44 --> Language Class Initialized
ERROR - 2016-12-09 05:14:44 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:14:44 --> Config Class Initialized
INFO - 2016-12-09 05:14:44 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:44 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:44 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:44 --> URI Class Initialized
INFO - 2016-12-09 05:14:44 --> Router Class Initialized
INFO - 2016-12-09 05:14:44 --> Output Class Initialized
INFO - 2016-12-09 05:14:44 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:44 --> Input Class Initialized
INFO - 2016-12-09 05:14:44 --> Language Class Initialized
INFO - 2016-12-09 05:14:44 --> Loader Class Initialized
INFO - 2016-12-09 05:14:44 --> Database Driver Class Initialized
INFO - 2016-12-09 05:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:14:44 --> Controller Class Initialized
INFO - 2016-12-09 05:14:44 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:14:44 --> Final output sent to browser
DEBUG - 2016-12-09 05:14:44 --> Total execution time: 0.0147
INFO - 2016-12-09 05:14:52 --> Config Class Initialized
INFO - 2016-12-09 05:14:52 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:52 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:52 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:52 --> URI Class Initialized
DEBUG - 2016-12-09 05:14:52 --> No URI present. Default controller set.
INFO - 2016-12-09 05:14:52 --> Router Class Initialized
INFO - 2016-12-09 05:14:52 --> Output Class Initialized
INFO - 2016-12-09 05:14:52 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:52 --> Input Class Initialized
INFO - 2016-12-09 05:14:52 --> Language Class Initialized
INFO - 2016-12-09 05:14:52 --> Loader Class Initialized
INFO - 2016-12-09 05:14:52 --> Database Driver Class Initialized
INFO - 2016-12-09 05:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:14:52 --> Controller Class Initialized
INFO - 2016-12-09 05:14:52 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:14:52 --> Final output sent to browser
DEBUG - 2016-12-09 05:14:52 --> Total execution time: 0.0141
INFO - 2016-12-09 05:14:52 --> Config Class Initialized
INFO - 2016-12-09 05:14:52 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:52 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:52 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:52 --> URI Class Initialized
INFO - 2016-12-09 05:14:52 --> Router Class Initialized
INFO - 2016-12-09 05:14:52 --> Output Class Initialized
INFO - 2016-12-09 05:14:52 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:52 --> Input Class Initialized
INFO - 2016-12-09 05:14:52 --> Language Class Initialized
ERROR - 2016-12-09 05:14:52 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:14:52 --> Config Class Initialized
INFO - 2016-12-09 05:14:52 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:14:52 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:14:52 --> Utf8 Class Initialized
INFO - 2016-12-09 05:14:52 --> URI Class Initialized
INFO - 2016-12-09 05:14:52 --> Router Class Initialized
INFO - 2016-12-09 05:14:52 --> Output Class Initialized
INFO - 2016-12-09 05:14:52 --> Security Class Initialized
DEBUG - 2016-12-09 05:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:14:52 --> Input Class Initialized
INFO - 2016-12-09 05:14:52 --> Language Class Initialized
INFO - 2016-12-09 05:14:52 --> Loader Class Initialized
INFO - 2016-12-09 05:14:52 --> Database Driver Class Initialized
INFO - 2016-12-09 05:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:14:52 --> Controller Class Initialized
INFO - 2016-12-09 05:14:52 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:14:52 --> Final output sent to browser
DEBUG - 2016-12-09 05:14:52 --> Total execution time: 0.0136
INFO - 2016-12-09 05:15:02 --> Config Class Initialized
INFO - 2016-12-09 05:15:02 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:15:02 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:15:02 --> Utf8 Class Initialized
INFO - 2016-12-09 05:15:02 --> URI Class Initialized
INFO - 2016-12-09 05:15:02 --> Router Class Initialized
INFO - 2016-12-09 05:15:02 --> Output Class Initialized
INFO - 2016-12-09 05:15:02 --> Security Class Initialized
DEBUG - 2016-12-09 05:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:15:02 --> Input Class Initialized
INFO - 2016-12-09 05:15:02 --> Language Class Initialized
INFO - 2016-12-09 05:15:02 --> Loader Class Initialized
INFO - 2016-12-09 05:15:02 --> Database Driver Class Initialized
INFO - 2016-12-09 05:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:15:02 --> Controller Class Initialized
INFO - 2016-12-09 05:15:02 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:15:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:15:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:15:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:15:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:15:02 --> Final output sent to browser
DEBUG - 2016-12-09 05:15:02 --> Total execution time: 0.0146
INFO - 2016-12-09 05:15:03 --> Config Class Initialized
INFO - 2016-12-09 05:15:03 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:15:03 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:15:03 --> Utf8 Class Initialized
INFO - 2016-12-09 05:15:03 --> URI Class Initialized
INFO - 2016-12-09 05:15:03 --> Router Class Initialized
INFO - 2016-12-09 05:15:03 --> Output Class Initialized
INFO - 2016-12-09 05:15:03 --> Security Class Initialized
DEBUG - 2016-12-09 05:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:15:03 --> Input Class Initialized
INFO - 2016-12-09 05:15:03 --> Language Class Initialized
ERROR - 2016-12-09 05:15:03 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:15:03 --> Config Class Initialized
INFO - 2016-12-09 05:15:03 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:15:03 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:15:03 --> Utf8 Class Initialized
INFO - 2016-12-09 05:15:03 --> URI Class Initialized
INFO - 2016-12-09 05:15:03 --> Router Class Initialized
INFO - 2016-12-09 05:15:03 --> Output Class Initialized
INFO - 2016-12-09 05:15:03 --> Security Class Initialized
DEBUG - 2016-12-09 05:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:15:03 --> Input Class Initialized
INFO - 2016-12-09 05:15:03 --> Language Class Initialized
INFO - 2016-12-09 05:15:03 --> Loader Class Initialized
INFO - 2016-12-09 05:15:03 --> Database Driver Class Initialized
INFO - 2016-12-09 05:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:15:03 --> Controller Class Initialized
INFO - 2016-12-09 05:15:03 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:15:03 --> Final output sent to browser
DEBUG - 2016-12-09 05:15:03 --> Total execution time: 0.0134
INFO - 2016-12-09 05:18:23 --> Config Class Initialized
INFO - 2016-12-09 05:18:23 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:18:23 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:18:23 --> Utf8 Class Initialized
INFO - 2016-12-09 05:18:23 --> URI Class Initialized
DEBUG - 2016-12-09 05:18:23 --> No URI present. Default controller set.
INFO - 2016-12-09 05:18:23 --> Router Class Initialized
INFO - 2016-12-09 05:18:23 --> Output Class Initialized
INFO - 2016-12-09 05:18:23 --> Security Class Initialized
DEBUG - 2016-12-09 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:18:23 --> Input Class Initialized
INFO - 2016-12-09 05:18:23 --> Language Class Initialized
INFO - 2016-12-09 05:18:23 --> Loader Class Initialized
INFO - 2016-12-09 05:18:23 --> Database Driver Class Initialized
INFO - 2016-12-09 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:18:23 --> Controller Class Initialized
INFO - 2016-12-09 05:18:23 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:18:23 --> Final output sent to browser
DEBUG - 2016-12-09 05:18:23 --> Total execution time: 0.0134
INFO - 2016-12-09 05:18:23 --> Config Class Initialized
INFO - 2016-12-09 05:18:23 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:18:23 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:18:23 --> Utf8 Class Initialized
INFO - 2016-12-09 05:18:23 --> URI Class Initialized
INFO - 2016-12-09 05:18:23 --> Router Class Initialized
INFO - 2016-12-09 05:18:23 --> Output Class Initialized
INFO - 2016-12-09 05:18:23 --> Security Class Initialized
DEBUG - 2016-12-09 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:18:23 --> Input Class Initialized
INFO - 2016-12-09 05:18:23 --> Language Class Initialized
ERROR - 2016-12-09 05:18:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:18:23 --> Config Class Initialized
INFO - 2016-12-09 05:18:23 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:18:23 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:18:23 --> Utf8 Class Initialized
INFO - 2016-12-09 05:18:23 --> URI Class Initialized
INFO - 2016-12-09 05:18:23 --> Router Class Initialized
INFO - 2016-12-09 05:18:23 --> Output Class Initialized
INFO - 2016-12-09 05:18:23 --> Security Class Initialized
DEBUG - 2016-12-09 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:18:23 --> Input Class Initialized
INFO - 2016-12-09 05:18:23 --> Language Class Initialized
INFO - 2016-12-09 05:18:23 --> Loader Class Initialized
INFO - 2016-12-09 05:18:23 --> Database Driver Class Initialized
INFO - 2016-12-09 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:18:23 --> Controller Class Initialized
INFO - 2016-12-09 05:18:23 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:18:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:18:23 --> Final output sent to browser
DEBUG - 2016-12-09 05:18:23 --> Total execution time: 0.0136
INFO - 2016-12-09 05:18:31 --> Config Class Initialized
INFO - 2016-12-09 05:18:31 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:18:31 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:18:31 --> Utf8 Class Initialized
INFO - 2016-12-09 05:18:31 --> URI Class Initialized
INFO - 2016-12-09 05:18:31 --> Router Class Initialized
INFO - 2016-12-09 05:18:31 --> Output Class Initialized
INFO - 2016-12-09 05:18:31 --> Security Class Initialized
DEBUG - 2016-12-09 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:18:31 --> Input Class Initialized
INFO - 2016-12-09 05:18:31 --> Language Class Initialized
INFO - 2016-12-09 05:18:31 --> Loader Class Initialized
INFO - 2016-12-09 05:18:31 --> Database Driver Class Initialized
INFO - 2016-12-09 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:18:31 --> Controller Class Initialized
INFO - 2016-12-09 05:18:31 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:18:31 --> Final output sent to browser
DEBUG - 2016-12-09 05:18:31 --> Total execution time: 0.0141
INFO - 2016-12-09 05:18:31 --> Config Class Initialized
INFO - 2016-12-09 05:18:31 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:18:31 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:18:31 --> Utf8 Class Initialized
INFO - 2016-12-09 05:18:31 --> URI Class Initialized
INFO - 2016-12-09 05:18:31 --> Router Class Initialized
INFO - 2016-12-09 05:18:31 --> Output Class Initialized
INFO - 2016-12-09 05:18:31 --> Security Class Initialized
DEBUG - 2016-12-09 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:18:31 --> Input Class Initialized
INFO - 2016-12-09 05:18:31 --> Language Class Initialized
ERROR - 2016-12-09 05:18:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:18:31 --> Config Class Initialized
INFO - 2016-12-09 05:18:31 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:18:31 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:18:31 --> Utf8 Class Initialized
INFO - 2016-12-09 05:18:31 --> URI Class Initialized
INFO - 2016-12-09 05:18:31 --> Router Class Initialized
INFO - 2016-12-09 05:18:31 --> Output Class Initialized
INFO - 2016-12-09 05:18:31 --> Security Class Initialized
DEBUG - 2016-12-09 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:18:31 --> Input Class Initialized
INFO - 2016-12-09 05:18:31 --> Language Class Initialized
INFO - 2016-12-09 05:18:31 --> Loader Class Initialized
INFO - 2016-12-09 05:18:31 --> Database Driver Class Initialized
INFO - 2016-12-09 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:18:31 --> Controller Class Initialized
INFO - 2016-12-09 05:18:31 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:18:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:18:31 --> Final output sent to browser
DEBUG - 2016-12-09 05:18:31 --> Total execution time: 0.0138
INFO - 2016-12-09 05:23:12 --> Config Class Initialized
INFO - 2016-12-09 05:23:12 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:23:12 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:23:12 --> Utf8 Class Initialized
INFO - 2016-12-09 05:23:12 --> URI Class Initialized
DEBUG - 2016-12-09 05:23:12 --> No URI present. Default controller set.
INFO - 2016-12-09 05:23:12 --> Router Class Initialized
INFO - 2016-12-09 05:23:12 --> Output Class Initialized
INFO - 2016-12-09 05:23:12 --> Security Class Initialized
DEBUG - 2016-12-09 05:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:23:12 --> Input Class Initialized
INFO - 2016-12-09 05:23:12 --> Language Class Initialized
INFO - 2016-12-09 05:23:12 --> Loader Class Initialized
INFO - 2016-12-09 05:23:13 --> Database Driver Class Initialized
INFO - 2016-12-09 05:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:23:13 --> Controller Class Initialized
INFO - 2016-12-09 05:23:13 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:23:13 --> Final output sent to browser
DEBUG - 2016-12-09 05:23:13 --> Total execution time: 1.0748
INFO - 2016-12-09 05:23:14 --> Config Class Initialized
INFO - 2016-12-09 05:23:14 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:23:14 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:23:14 --> Utf8 Class Initialized
INFO - 2016-12-09 05:23:14 --> URI Class Initialized
INFO - 2016-12-09 05:23:14 --> Router Class Initialized
INFO - 2016-12-09 05:23:14 --> Output Class Initialized
INFO - 2016-12-09 05:23:14 --> Security Class Initialized
DEBUG - 2016-12-09 05:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:23:14 --> Input Class Initialized
INFO - 2016-12-09 05:23:14 --> Language Class Initialized
ERROR - 2016-12-09 05:23:14 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:23:14 --> Config Class Initialized
INFO - 2016-12-09 05:23:14 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:23:14 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:23:14 --> Utf8 Class Initialized
INFO - 2016-12-09 05:23:14 --> URI Class Initialized
INFO - 2016-12-09 05:23:14 --> Router Class Initialized
INFO - 2016-12-09 05:23:14 --> Output Class Initialized
INFO - 2016-12-09 05:23:14 --> Security Class Initialized
DEBUG - 2016-12-09 05:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:23:14 --> Input Class Initialized
INFO - 2016-12-09 05:23:14 --> Language Class Initialized
INFO - 2016-12-09 05:23:14 --> Loader Class Initialized
INFO - 2016-12-09 05:23:14 --> Database Driver Class Initialized
INFO - 2016-12-09 05:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:23:14 --> Controller Class Initialized
INFO - 2016-12-09 05:23:14 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:23:14 --> Final output sent to browser
DEBUG - 2016-12-09 05:23:14 --> Total execution time: 0.0390
INFO - 2016-12-09 05:23:23 --> Config Class Initialized
INFO - 2016-12-09 05:23:23 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:23:23 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:23:23 --> Utf8 Class Initialized
INFO - 2016-12-09 05:23:23 --> URI Class Initialized
INFO - 2016-12-09 05:23:23 --> Router Class Initialized
INFO - 2016-12-09 05:23:23 --> Output Class Initialized
INFO - 2016-12-09 05:23:23 --> Security Class Initialized
DEBUG - 2016-12-09 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:23:23 --> Input Class Initialized
INFO - 2016-12-09 05:23:23 --> Language Class Initialized
INFO - 2016-12-09 05:23:23 --> Loader Class Initialized
INFO - 2016-12-09 05:23:23 --> Database Driver Class Initialized
INFO - 2016-12-09 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:23:23 --> Controller Class Initialized
INFO - 2016-12-09 05:23:23 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:23:23 --> Final output sent to browser
DEBUG - 2016-12-09 05:23:23 --> Total execution time: 0.0144
INFO - 2016-12-09 05:23:23 --> Config Class Initialized
INFO - 2016-12-09 05:23:23 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:23:23 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:23:23 --> Utf8 Class Initialized
INFO - 2016-12-09 05:23:23 --> URI Class Initialized
INFO - 2016-12-09 05:23:23 --> Router Class Initialized
INFO - 2016-12-09 05:23:23 --> Output Class Initialized
INFO - 2016-12-09 05:23:23 --> Security Class Initialized
DEBUG - 2016-12-09 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:23:23 --> Input Class Initialized
INFO - 2016-12-09 05:23:23 --> Language Class Initialized
ERROR - 2016-12-09 05:23:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:23:23 --> Config Class Initialized
INFO - 2016-12-09 05:23:23 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:23:23 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:23:23 --> Utf8 Class Initialized
INFO - 2016-12-09 05:23:23 --> URI Class Initialized
INFO - 2016-12-09 05:23:23 --> Router Class Initialized
INFO - 2016-12-09 05:23:23 --> Output Class Initialized
INFO - 2016-12-09 05:23:23 --> Security Class Initialized
DEBUG - 2016-12-09 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:23:23 --> Input Class Initialized
INFO - 2016-12-09 05:23:23 --> Language Class Initialized
INFO - 2016-12-09 05:23:23 --> Loader Class Initialized
INFO - 2016-12-09 05:23:23 --> Database Driver Class Initialized
INFO - 2016-12-09 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:23:23 --> Controller Class Initialized
INFO - 2016-12-09 05:23:23 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:23:23 --> Final output sent to browser
DEBUG - 2016-12-09 05:23:23 --> Total execution time: 0.0138
INFO - 2016-12-09 05:24:53 --> Config Class Initialized
INFO - 2016-12-09 05:24:53 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:24:53 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:24:53 --> Utf8 Class Initialized
INFO - 2016-12-09 05:24:53 --> URI Class Initialized
DEBUG - 2016-12-09 05:24:53 --> No URI present. Default controller set.
INFO - 2016-12-09 05:24:53 --> Router Class Initialized
INFO - 2016-12-09 05:24:53 --> Output Class Initialized
INFO - 2016-12-09 05:24:53 --> Security Class Initialized
DEBUG - 2016-12-09 05:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:24:53 --> Input Class Initialized
INFO - 2016-12-09 05:24:53 --> Language Class Initialized
INFO - 2016-12-09 05:24:53 --> Loader Class Initialized
INFO - 2016-12-09 05:24:53 --> Database Driver Class Initialized
INFO - 2016-12-09 05:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:24:53 --> Controller Class Initialized
INFO - 2016-12-09 05:24:53 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:24:53 --> Final output sent to browser
DEBUG - 2016-12-09 05:24:53 --> Total execution time: 0.5562
INFO - 2016-12-09 05:24:53 --> Config Class Initialized
INFO - 2016-12-09 05:24:53 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:24:53 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:24:53 --> Utf8 Class Initialized
INFO - 2016-12-09 05:24:53 --> URI Class Initialized
INFO - 2016-12-09 05:24:53 --> Router Class Initialized
INFO - 2016-12-09 05:24:53 --> Output Class Initialized
INFO - 2016-12-09 05:24:53 --> Security Class Initialized
DEBUG - 2016-12-09 05:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:24:53 --> Input Class Initialized
INFO - 2016-12-09 05:24:53 --> Language Class Initialized
ERROR - 2016-12-09 05:24:53 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:24:54 --> Config Class Initialized
INFO - 2016-12-09 05:24:54 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:24:54 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:24:54 --> Utf8 Class Initialized
INFO - 2016-12-09 05:24:54 --> URI Class Initialized
INFO - 2016-12-09 05:24:54 --> Router Class Initialized
INFO - 2016-12-09 05:24:54 --> Output Class Initialized
INFO - 2016-12-09 05:24:54 --> Security Class Initialized
DEBUG - 2016-12-09 05:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:24:54 --> Input Class Initialized
INFO - 2016-12-09 05:24:54 --> Language Class Initialized
INFO - 2016-12-09 05:24:54 --> Loader Class Initialized
INFO - 2016-12-09 05:24:54 --> Database Driver Class Initialized
INFO - 2016-12-09 05:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:24:54 --> Controller Class Initialized
INFO - 2016-12-09 05:24:54 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:24:54 --> Final output sent to browser
DEBUG - 2016-12-09 05:24:54 --> Total execution time: 0.0160
INFO - 2016-12-09 05:24:57 --> Config Class Initialized
INFO - 2016-12-09 05:24:57 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:24:57 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:24:57 --> Utf8 Class Initialized
INFO - 2016-12-09 05:24:57 --> URI Class Initialized
INFO - 2016-12-09 05:24:57 --> Router Class Initialized
INFO - 2016-12-09 05:24:57 --> Output Class Initialized
INFO - 2016-12-09 05:24:57 --> Security Class Initialized
DEBUG - 2016-12-09 05:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:24:57 --> Input Class Initialized
INFO - 2016-12-09 05:24:57 --> Language Class Initialized
INFO - 2016-12-09 05:24:57 --> Loader Class Initialized
INFO - 2016-12-09 05:24:57 --> Database Driver Class Initialized
INFO - 2016-12-09 05:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:24:57 --> Controller Class Initialized
INFO - 2016-12-09 05:24:57 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:24:57 --> Final output sent to browser
DEBUG - 2016-12-09 05:24:57 --> Total execution time: 0.0154
INFO - 2016-12-09 05:24:57 --> Config Class Initialized
INFO - 2016-12-09 05:24:57 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:24:57 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:24:57 --> Utf8 Class Initialized
INFO - 2016-12-09 05:24:57 --> URI Class Initialized
INFO - 2016-12-09 05:24:57 --> Router Class Initialized
INFO - 2016-12-09 05:24:57 --> Output Class Initialized
INFO - 2016-12-09 05:24:57 --> Security Class Initialized
DEBUG - 2016-12-09 05:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:24:57 --> Input Class Initialized
INFO - 2016-12-09 05:24:57 --> Language Class Initialized
ERROR - 2016-12-09 05:24:57 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:24:58 --> Config Class Initialized
INFO - 2016-12-09 05:24:58 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:24:58 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:24:58 --> Utf8 Class Initialized
INFO - 2016-12-09 05:24:58 --> URI Class Initialized
INFO - 2016-12-09 05:24:58 --> Router Class Initialized
INFO - 2016-12-09 05:24:58 --> Output Class Initialized
INFO - 2016-12-09 05:24:58 --> Security Class Initialized
DEBUG - 2016-12-09 05:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:24:58 --> Input Class Initialized
INFO - 2016-12-09 05:24:58 --> Language Class Initialized
INFO - 2016-12-09 05:24:58 --> Loader Class Initialized
INFO - 2016-12-09 05:24:58 --> Database Driver Class Initialized
INFO - 2016-12-09 05:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:24:58 --> Controller Class Initialized
INFO - 2016-12-09 05:24:58 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:24:58 --> Final output sent to browser
DEBUG - 2016-12-09 05:24:58 --> Total execution time: 0.0141
INFO - 2016-12-09 05:25:19 --> Config Class Initialized
INFO - 2016-12-09 05:25:19 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:25:19 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:25:19 --> Utf8 Class Initialized
INFO - 2016-12-09 05:25:19 --> URI Class Initialized
INFO - 2016-12-09 05:25:19 --> Router Class Initialized
INFO - 2016-12-09 05:25:19 --> Output Class Initialized
INFO - 2016-12-09 05:25:19 --> Security Class Initialized
DEBUG - 2016-12-09 05:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:25:19 --> Input Class Initialized
INFO - 2016-12-09 05:25:19 --> Language Class Initialized
INFO - 2016-12-09 05:25:19 --> Loader Class Initialized
INFO - 2016-12-09 05:25:19 --> Database Driver Class Initialized
INFO - 2016-12-09 05:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:25:19 --> Controller Class Initialized
INFO - 2016-12-09 05:25:19 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:25:19 --> Final output sent to browser
DEBUG - 2016-12-09 05:25:19 --> Total execution time: 0.0213
INFO - 2016-12-09 05:25:20 --> Config Class Initialized
INFO - 2016-12-09 05:25:20 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:25:20 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:25:20 --> Utf8 Class Initialized
INFO - 2016-12-09 05:25:20 --> URI Class Initialized
INFO - 2016-12-09 05:25:20 --> Router Class Initialized
INFO - 2016-12-09 05:25:20 --> Output Class Initialized
INFO - 2016-12-09 05:25:20 --> Security Class Initialized
DEBUG - 2016-12-09 05:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:25:20 --> Input Class Initialized
INFO - 2016-12-09 05:25:20 --> Language Class Initialized
ERROR - 2016-12-09 05:25:20 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:25:20 --> Config Class Initialized
INFO - 2016-12-09 05:25:20 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:25:20 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:25:20 --> Utf8 Class Initialized
INFO - 2016-12-09 05:25:20 --> URI Class Initialized
INFO - 2016-12-09 05:25:20 --> Router Class Initialized
INFO - 2016-12-09 05:25:20 --> Output Class Initialized
INFO - 2016-12-09 05:25:20 --> Security Class Initialized
DEBUG - 2016-12-09 05:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:25:20 --> Input Class Initialized
INFO - 2016-12-09 05:25:20 --> Language Class Initialized
INFO - 2016-12-09 05:25:20 --> Loader Class Initialized
INFO - 2016-12-09 05:25:20 --> Database Driver Class Initialized
INFO - 2016-12-09 05:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:25:20 --> Controller Class Initialized
INFO - 2016-12-09 05:25:20 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:25:20 --> Final output sent to browser
DEBUG - 2016-12-09 05:25:20 --> Total execution time: 0.0137
INFO - 2016-12-09 05:25:39 --> Config Class Initialized
INFO - 2016-12-09 05:25:39 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:25:39 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:25:39 --> Utf8 Class Initialized
INFO - 2016-12-09 05:25:39 --> URI Class Initialized
INFO - 2016-12-09 05:25:39 --> Router Class Initialized
INFO - 2016-12-09 05:25:39 --> Output Class Initialized
INFO - 2016-12-09 05:25:39 --> Security Class Initialized
DEBUG - 2016-12-09 05:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:25:39 --> Input Class Initialized
INFO - 2016-12-09 05:25:39 --> Language Class Initialized
INFO - 2016-12-09 05:25:39 --> Loader Class Initialized
INFO - 2016-12-09 05:25:39 --> Database Driver Class Initialized
INFO - 2016-12-09 05:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:25:39 --> Controller Class Initialized
INFO - 2016-12-09 05:25:39 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:25:39 --> Final output sent to browser
DEBUG - 2016-12-09 05:25:39 --> Total execution time: 0.0153
INFO - 2016-12-09 05:25:40 --> Config Class Initialized
INFO - 2016-12-09 05:25:40 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:25:40 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:25:40 --> Utf8 Class Initialized
INFO - 2016-12-09 05:25:40 --> URI Class Initialized
INFO - 2016-12-09 05:25:40 --> Router Class Initialized
INFO - 2016-12-09 05:25:40 --> Output Class Initialized
INFO - 2016-12-09 05:25:40 --> Security Class Initialized
DEBUG - 2016-12-09 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:25:40 --> Input Class Initialized
INFO - 2016-12-09 05:25:40 --> Language Class Initialized
ERROR - 2016-12-09 05:25:40 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:25:40 --> Config Class Initialized
INFO - 2016-12-09 05:25:40 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:25:40 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:25:40 --> Utf8 Class Initialized
INFO - 2016-12-09 05:25:40 --> URI Class Initialized
INFO - 2016-12-09 05:25:40 --> Router Class Initialized
INFO - 2016-12-09 05:25:40 --> Output Class Initialized
INFO - 2016-12-09 05:25:40 --> Security Class Initialized
DEBUG - 2016-12-09 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:25:40 --> Input Class Initialized
INFO - 2016-12-09 05:25:40 --> Language Class Initialized
INFO - 2016-12-09 05:25:40 --> Loader Class Initialized
INFO - 2016-12-09 05:25:40 --> Database Driver Class Initialized
INFO - 2016-12-09 05:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:25:40 --> Controller Class Initialized
INFO - 2016-12-09 05:25:40 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:25:40 --> Final output sent to browser
DEBUG - 2016-12-09 05:25:40 --> Total execution time: 0.0136
INFO - 2016-12-09 05:36:04 --> Config Class Initialized
INFO - 2016-12-09 05:36:04 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:36:04 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:36:04 --> Utf8 Class Initialized
INFO - 2016-12-09 05:36:04 --> URI Class Initialized
DEBUG - 2016-12-09 05:36:04 --> No URI present. Default controller set.
INFO - 2016-12-09 05:36:04 --> Router Class Initialized
INFO - 2016-12-09 05:36:04 --> Output Class Initialized
INFO - 2016-12-09 05:36:04 --> Security Class Initialized
DEBUG - 2016-12-09 05:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:36:04 --> Input Class Initialized
INFO - 2016-12-09 05:36:04 --> Language Class Initialized
INFO - 2016-12-09 05:36:04 --> Loader Class Initialized
INFO - 2016-12-09 05:36:04 --> Database Driver Class Initialized
INFO - 2016-12-09 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:36:05 --> Controller Class Initialized
INFO - 2016-12-09 05:36:05 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:36:05 --> Final output sent to browser
DEBUG - 2016-12-09 05:36:05 --> Total execution time: 0.5868
INFO - 2016-12-09 05:36:05 --> Config Class Initialized
INFO - 2016-12-09 05:36:05 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:36:05 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:36:05 --> Utf8 Class Initialized
INFO - 2016-12-09 05:36:05 --> URI Class Initialized
INFO - 2016-12-09 05:36:05 --> Router Class Initialized
INFO - 2016-12-09 05:36:05 --> Output Class Initialized
INFO - 2016-12-09 05:36:05 --> Security Class Initialized
DEBUG - 2016-12-09 05:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:36:05 --> Input Class Initialized
INFO - 2016-12-09 05:36:05 --> Language Class Initialized
INFO - 2016-12-09 05:36:05 --> Loader Class Initialized
INFO - 2016-12-09 05:36:05 --> Database Driver Class Initialized
INFO - 2016-12-09 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:36:05 --> Controller Class Initialized
INFO - 2016-12-09 05:36:05 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:36:05 --> Final output sent to browser
DEBUG - 2016-12-09 05:36:05 --> Total execution time: 0.0148
INFO - 2016-12-09 05:36:20 --> Config Class Initialized
INFO - 2016-12-09 05:36:20 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:36:20 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:36:20 --> Utf8 Class Initialized
INFO - 2016-12-09 05:36:20 --> URI Class Initialized
INFO - 2016-12-09 05:36:20 --> Router Class Initialized
INFO - 2016-12-09 05:36:20 --> Output Class Initialized
INFO - 2016-12-09 05:36:20 --> Security Class Initialized
DEBUG - 2016-12-09 05:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:36:20 --> Input Class Initialized
INFO - 2016-12-09 05:36:20 --> Language Class Initialized
INFO - 2016-12-09 05:36:20 --> Loader Class Initialized
INFO - 2016-12-09 05:36:20 --> Database Driver Class Initialized
INFO - 2016-12-09 05:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:36:20 --> Controller Class Initialized
INFO - 2016-12-09 05:36:20 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:36:20 --> Final output sent to browser
DEBUG - 2016-12-09 05:36:20 --> Total execution time: 0.0238
INFO - 2016-12-09 05:36:20 --> Config Class Initialized
INFO - 2016-12-09 05:36:20 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:36:20 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:36:20 --> Utf8 Class Initialized
INFO - 2016-12-09 05:36:20 --> URI Class Initialized
INFO - 2016-12-09 05:36:20 --> Router Class Initialized
INFO - 2016-12-09 05:36:20 --> Output Class Initialized
INFO - 2016-12-09 05:36:20 --> Security Class Initialized
DEBUG - 2016-12-09 05:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:36:20 --> Input Class Initialized
INFO - 2016-12-09 05:36:20 --> Language Class Initialized
INFO - 2016-12-09 05:36:20 --> Loader Class Initialized
INFO - 2016-12-09 05:36:20 --> Database Driver Class Initialized
INFO - 2016-12-09 05:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:36:20 --> Controller Class Initialized
INFO - 2016-12-09 05:36:20 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:36:21 --> Final output sent to browser
DEBUG - 2016-12-09 05:36:21 --> Total execution time: 0.0146
INFO - 2016-12-09 05:36:35 --> Config Class Initialized
INFO - 2016-12-09 05:36:35 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:36:35 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:36:35 --> Utf8 Class Initialized
INFO - 2016-12-09 05:36:35 --> URI Class Initialized
INFO - 2016-12-09 05:36:35 --> Router Class Initialized
INFO - 2016-12-09 05:36:35 --> Output Class Initialized
INFO - 2016-12-09 05:36:35 --> Security Class Initialized
DEBUG - 2016-12-09 05:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:36:35 --> Input Class Initialized
INFO - 2016-12-09 05:36:35 --> Language Class Initialized
INFO - 2016-12-09 05:36:35 --> Loader Class Initialized
INFO - 2016-12-09 05:36:35 --> Database Driver Class Initialized
INFO - 2016-12-09 05:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:36:35 --> Controller Class Initialized
INFO - 2016-12-09 05:36:35 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:36:35 --> Final output sent to browser
DEBUG - 2016-12-09 05:36:35 --> Total execution time: 0.0159
INFO - 2016-12-09 05:42:28 --> Config Class Initialized
INFO - 2016-12-09 05:42:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:42:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:42:28 --> Utf8 Class Initialized
INFO - 2016-12-09 05:42:28 --> URI Class Initialized
DEBUG - 2016-12-09 05:42:28 --> No URI present. Default controller set.
INFO - 2016-12-09 05:42:28 --> Router Class Initialized
INFO - 2016-12-09 05:42:28 --> Output Class Initialized
INFO - 2016-12-09 05:42:28 --> Security Class Initialized
DEBUG - 2016-12-09 05:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:42:28 --> Input Class Initialized
INFO - 2016-12-09 05:42:28 --> Language Class Initialized
INFO - 2016-12-09 05:42:28 --> Loader Class Initialized
INFO - 2016-12-09 05:42:28 --> Database Driver Class Initialized
INFO - 2016-12-09 05:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:42:28 --> Controller Class Initialized
INFO - 2016-12-09 05:42:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:42:28 --> Final output sent to browser
DEBUG - 2016-12-09 05:42:28 --> Total execution time: 0.0137
INFO - 2016-12-09 05:42:28 --> Config Class Initialized
INFO - 2016-12-09 05:42:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:42:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:42:28 --> Utf8 Class Initialized
INFO - 2016-12-09 05:42:28 --> URI Class Initialized
INFO - 2016-12-09 05:42:28 --> Router Class Initialized
INFO - 2016-12-09 05:42:28 --> Output Class Initialized
INFO - 2016-12-09 05:42:28 --> Security Class Initialized
DEBUG - 2016-12-09 05:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:42:28 --> Input Class Initialized
INFO - 2016-12-09 05:42:28 --> Language Class Initialized
INFO - 2016-12-09 05:42:28 --> Loader Class Initialized
INFO - 2016-12-09 05:42:28 --> Database Driver Class Initialized
INFO - 2016-12-09 05:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:42:28 --> Controller Class Initialized
INFO - 2016-12-09 05:42:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:42:28 --> Final output sent to browser
DEBUG - 2016-12-09 05:42:28 --> Total execution time: 0.0139
INFO - 2016-12-09 05:42:46 --> Config Class Initialized
INFO - 2016-12-09 05:42:46 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:42:46 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:42:46 --> Utf8 Class Initialized
INFO - 2016-12-09 05:42:46 --> URI Class Initialized
INFO - 2016-12-09 05:42:46 --> Router Class Initialized
INFO - 2016-12-09 05:42:46 --> Output Class Initialized
INFO - 2016-12-09 05:42:46 --> Security Class Initialized
DEBUG - 2016-12-09 05:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:42:46 --> Input Class Initialized
INFO - 2016-12-09 05:42:46 --> Language Class Initialized
INFO - 2016-12-09 05:42:46 --> Loader Class Initialized
INFO - 2016-12-09 05:42:46 --> Database Driver Class Initialized
INFO - 2016-12-09 05:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:42:46 --> Controller Class Initialized
INFO - 2016-12-09 05:42:46 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:42:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-12-09 05:42:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php:130) /home/graduafe/public_html/system/helpers/url_helper.php 564
INFO - 2016-12-09 05:42:47 --> Config Class Initialized
INFO - 2016-12-09 05:42:47 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:42:47 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:42:47 --> Utf8 Class Initialized
INFO - 2016-12-09 05:42:47 --> URI Class Initialized
INFO - 2016-12-09 05:42:47 --> Router Class Initialized
INFO - 2016-12-09 05:42:47 --> Output Class Initialized
INFO - 2016-12-09 05:42:47 --> Security Class Initialized
DEBUG - 2016-12-09 05:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:42:47 --> Input Class Initialized
INFO - 2016-12-09 05:42:47 --> Language Class Initialized
INFO - 2016-12-09 05:42:47 --> Loader Class Initialized
INFO - 2016-12-09 05:42:47 --> Database Driver Class Initialized
INFO - 2016-12-09 05:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:42:47 --> Controller Class Initialized
INFO - 2016-12-09 05:42:47 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:42:47 --> Final output sent to browser
DEBUG - 2016-12-09 05:42:47 --> Total execution time: 0.0145
INFO - 2016-12-09 05:43:49 --> Config Class Initialized
INFO - 2016-12-09 05:43:49 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:43:49 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:43:49 --> Utf8 Class Initialized
INFO - 2016-12-09 05:43:49 --> URI Class Initialized
DEBUG - 2016-12-09 05:43:49 --> No URI present. Default controller set.
INFO - 2016-12-09 05:43:49 --> Router Class Initialized
INFO - 2016-12-09 05:43:49 --> Output Class Initialized
INFO - 2016-12-09 05:43:49 --> Security Class Initialized
DEBUG - 2016-12-09 05:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:43:49 --> Input Class Initialized
INFO - 2016-12-09 05:43:49 --> Language Class Initialized
INFO - 2016-12-09 05:43:49 --> Loader Class Initialized
INFO - 2016-12-09 05:43:49 --> Database Driver Class Initialized
INFO - 2016-12-09 05:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:43:49 --> Controller Class Initialized
INFO - 2016-12-09 05:43:49 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:43:49 --> Final output sent to browser
DEBUG - 2016-12-09 05:43:49 --> Total execution time: 0.0693
INFO - 2016-12-09 05:43:49 --> Config Class Initialized
INFO - 2016-12-09 05:43:49 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:43:49 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:43:49 --> Utf8 Class Initialized
INFO - 2016-12-09 05:43:49 --> URI Class Initialized
DEBUG - 2016-12-09 05:43:49 --> No URI present. Default controller set.
INFO - 2016-12-09 05:43:49 --> Router Class Initialized
INFO - 2016-12-09 05:43:49 --> Output Class Initialized
INFO - 2016-12-09 05:43:49 --> Security Class Initialized
DEBUG - 2016-12-09 05:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:43:49 --> Input Class Initialized
INFO - 2016-12-09 05:43:49 --> Language Class Initialized
INFO - 2016-12-09 05:43:49 --> Loader Class Initialized
INFO - 2016-12-09 05:43:49 --> Database Driver Class Initialized
INFO - 2016-12-09 05:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:43:49 --> Controller Class Initialized
INFO - 2016-12-09 05:43:49 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:43:49 --> Final output sent to browser
DEBUG - 2016-12-09 05:43:49 --> Total execution time: 0.0761
INFO - 2016-12-09 05:43:50 --> Config Class Initialized
INFO - 2016-12-09 05:43:50 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:43:50 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:43:50 --> Utf8 Class Initialized
INFO - 2016-12-09 05:43:50 --> URI Class Initialized
INFO - 2016-12-09 05:43:50 --> Router Class Initialized
INFO - 2016-12-09 05:43:50 --> Output Class Initialized
INFO - 2016-12-09 05:43:50 --> Security Class Initialized
DEBUG - 2016-12-09 05:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:43:50 --> Input Class Initialized
INFO - 2016-12-09 05:43:50 --> Language Class Initialized
INFO - 2016-12-09 05:43:50 --> Loader Class Initialized
INFO - 2016-12-09 05:43:50 --> Database Driver Class Initialized
INFO - 2016-12-09 05:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:43:50 --> Controller Class Initialized
INFO - 2016-12-09 05:43:50 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:43:50 --> Final output sent to browser
DEBUG - 2016-12-09 05:43:50 --> Total execution time: 0.0134
INFO - 2016-12-09 05:43:57 --> Config Class Initialized
INFO - 2016-12-09 05:43:57 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:43:57 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:43:57 --> Utf8 Class Initialized
INFO - 2016-12-09 05:43:57 --> URI Class Initialized
INFO - 2016-12-09 05:43:57 --> Router Class Initialized
INFO - 2016-12-09 05:43:57 --> Output Class Initialized
INFO - 2016-12-09 05:43:57 --> Security Class Initialized
DEBUG - 2016-12-09 05:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:43:57 --> Input Class Initialized
INFO - 2016-12-09 05:43:57 --> Language Class Initialized
INFO - 2016-12-09 05:43:57 --> Loader Class Initialized
INFO - 2016-12-09 05:43:57 --> Database Driver Class Initialized
INFO - 2016-12-09 05:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:43:57 --> Controller Class Initialized
INFO - 2016-12-09 05:43:57 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:43:58 --> Config Class Initialized
INFO - 2016-12-09 05:43:58 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:43:58 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:43:58 --> Utf8 Class Initialized
INFO - 2016-12-09 05:43:58 --> URI Class Initialized
INFO - 2016-12-09 05:43:58 --> Router Class Initialized
INFO - 2016-12-09 05:43:58 --> Output Class Initialized
INFO - 2016-12-09 05:43:58 --> Security Class Initialized
DEBUG - 2016-12-09 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:43:58 --> Input Class Initialized
INFO - 2016-12-09 05:43:58 --> Language Class Initialized
INFO - 2016-12-09 05:43:58 --> Loader Class Initialized
INFO - 2016-12-09 05:43:58 --> Database Driver Class Initialized
INFO - 2016-12-09 05:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:43:58 --> Controller Class Initialized
DEBUG - 2016-12-09 05:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:43:58 --> Helper loaded: url_helper
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:43:58 --> Final output sent to browser
DEBUG - 2016-12-09 05:43:58 --> Total execution time: 0.0467
INFO - 2016-12-09 05:43:58 --> Config Class Initialized
INFO - 2016-12-09 05:43:58 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:43:58 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:43:58 --> Utf8 Class Initialized
INFO - 2016-12-09 05:43:58 --> URI Class Initialized
INFO - 2016-12-09 05:43:58 --> Router Class Initialized
INFO - 2016-12-09 05:43:58 --> Output Class Initialized
INFO - 2016-12-09 05:43:58 --> Security Class Initialized
DEBUG - 2016-12-09 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:43:58 --> Input Class Initialized
INFO - 2016-12-09 05:43:58 --> Language Class Initialized
INFO - 2016-12-09 05:43:58 --> Loader Class Initialized
INFO - 2016-12-09 05:43:58 --> Database Driver Class Initialized
INFO - 2016-12-09 05:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:43:58 --> Controller Class Initialized
INFO - 2016-12-09 05:43:58 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:43:58 --> Final output sent to browser
DEBUG - 2016-12-09 05:43:58 --> Total execution time: 0.0131
INFO - 2016-12-09 05:44:09 --> Config Class Initialized
INFO - 2016-12-09 05:44:09 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:44:09 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:44:09 --> Utf8 Class Initialized
INFO - 2016-12-09 05:44:09 --> URI Class Initialized
INFO - 2016-12-09 05:44:09 --> Router Class Initialized
INFO - 2016-12-09 05:44:09 --> Output Class Initialized
INFO - 2016-12-09 05:44:09 --> Security Class Initialized
DEBUG - 2016-12-09 05:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:44:09 --> Input Class Initialized
INFO - 2016-12-09 05:44:09 --> Language Class Initialized
ERROR - 2016-12-09 05:44:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-09 05:45:10 --> Config Class Initialized
INFO - 2016-12-09 05:45:10 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:45:10 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:45:10 --> Utf8 Class Initialized
INFO - 2016-12-09 05:45:10 --> URI Class Initialized
INFO - 2016-12-09 05:45:10 --> Router Class Initialized
INFO - 2016-12-09 05:45:10 --> Output Class Initialized
INFO - 2016-12-09 05:45:10 --> Security Class Initialized
DEBUG - 2016-12-09 05:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:45:10 --> Input Class Initialized
INFO - 2016-12-09 05:45:10 --> Language Class Initialized
INFO - 2016-12-09 05:45:10 --> Loader Class Initialized
INFO - 2016-12-09 05:45:10 --> Database Driver Class Initialized
INFO - 2016-12-09 05:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:45:10 --> Controller Class Initialized
DEBUG - 2016-12-09 05:45:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:45:10 --> Helper loaded: url_helper
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:45:10 --> Final output sent to browser
DEBUG - 2016-12-09 05:45:10 --> Total execution time: 0.0122
INFO - 2016-12-09 05:45:10 --> Config Class Initialized
INFO - 2016-12-09 05:45:10 --> Hooks Class Initialized
DEBUG - 2016-12-09 05:45:10 --> UTF-8 Support Enabled
INFO - 2016-12-09 05:45:10 --> Utf8 Class Initialized
INFO - 2016-12-09 05:45:10 --> URI Class Initialized
INFO - 2016-12-09 05:45:10 --> Router Class Initialized
INFO - 2016-12-09 05:45:10 --> Output Class Initialized
INFO - 2016-12-09 05:45:10 --> Security Class Initialized
DEBUG - 2016-12-09 05:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 05:45:10 --> Input Class Initialized
INFO - 2016-12-09 05:45:10 --> Language Class Initialized
INFO - 2016-12-09 05:45:10 --> Loader Class Initialized
INFO - 2016-12-09 05:45:10 --> Database Driver Class Initialized
INFO - 2016-12-09 05:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 05:45:10 --> Controller Class Initialized
INFO - 2016-12-09 05:45:10 --> Helper loaded: url_helper
DEBUG - 2016-12-09 05:45:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 05:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 05:45:10 --> Final output sent to browser
DEBUG - 2016-12-09 05:45:10 --> Total execution time: 0.0136
INFO - 2016-12-09 16:23:25 --> Config Class Initialized
INFO - 2016-12-09 16:23:25 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:25 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:25 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:25 --> URI Class Initialized
DEBUG - 2016-12-09 16:23:25 --> No URI present. Default controller set.
INFO - 2016-12-09 16:23:25 --> Router Class Initialized
INFO - 2016-12-09 16:23:25 --> Output Class Initialized
INFO - 2016-12-09 16:23:25 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:26 --> Input Class Initialized
INFO - 2016-12-09 16:23:26 --> Language Class Initialized
INFO - 2016-12-09 16:23:26 --> Loader Class Initialized
INFO - 2016-12-09 16:23:26 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:26 --> Controller Class Initialized
INFO - 2016-12-09 16:23:26 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:26 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:26 --> Total execution time: 1.5809
INFO - 2016-12-09 16:23:27 --> Config Class Initialized
INFO - 2016-12-09 16:23:27 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:27 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:27 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:27 --> URI Class Initialized
INFO - 2016-12-09 16:23:27 --> Router Class Initialized
INFO - 2016-12-09 16:23:27 --> Output Class Initialized
INFO - 2016-12-09 16:23:27 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:27 --> Input Class Initialized
INFO - 2016-12-09 16:23:27 --> Language Class Initialized
INFO - 2016-12-09 16:23:27 --> Loader Class Initialized
INFO - 2016-12-09 16:23:27 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:27 --> Controller Class Initialized
INFO - 2016-12-09 16:23:27 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:27 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:27 --> Total execution time: 0.0143
INFO - 2016-12-09 16:23:27 --> Config Class Initialized
INFO - 2016-12-09 16:23:27 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:27 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:27 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:27 --> URI Class Initialized
INFO - 2016-12-09 16:23:27 --> Router Class Initialized
INFO - 2016-12-09 16:23:27 --> Output Class Initialized
INFO - 2016-12-09 16:23:27 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:27 --> Input Class Initialized
INFO - 2016-12-09 16:23:27 --> Language Class Initialized
INFO - 2016-12-09 16:23:27 --> Loader Class Initialized
INFO - 2016-12-09 16:23:27 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:27 --> Controller Class Initialized
INFO - 2016-12-09 16:23:27 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:27 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:27 --> Total execution time: 0.0150
INFO - 2016-12-09 16:23:27 --> Config Class Initialized
INFO - 2016-12-09 16:23:27 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:27 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:27 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:27 --> URI Class Initialized
INFO - 2016-12-09 16:23:27 --> Router Class Initialized
INFO - 2016-12-09 16:23:27 --> Output Class Initialized
INFO - 2016-12-09 16:23:27 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:27 --> Input Class Initialized
INFO - 2016-12-09 16:23:27 --> Language Class Initialized
INFO - 2016-12-09 16:23:27 --> Loader Class Initialized
INFO - 2016-12-09 16:23:27 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:27 --> Controller Class Initialized
INFO - 2016-12-09 16:23:27 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:27 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:27 --> Total execution time: 0.0560
INFO - 2016-12-09 16:23:27 --> Config Class Initialized
INFO - 2016-12-09 16:23:27 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:27 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:27 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:27 --> URI Class Initialized
INFO - 2016-12-09 16:23:27 --> Router Class Initialized
INFO - 2016-12-09 16:23:27 --> Output Class Initialized
INFO - 2016-12-09 16:23:27 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:27 --> Input Class Initialized
INFO - 2016-12-09 16:23:27 --> Language Class Initialized
INFO - 2016-12-09 16:23:27 --> Loader Class Initialized
INFO - 2016-12-09 16:23:27 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:27 --> Controller Class Initialized
INFO - 2016-12-09 16:23:27 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:27 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:27 --> Total execution time: 0.0144
INFO - 2016-12-09 16:23:27 --> Config Class Initialized
INFO - 2016-12-09 16:23:27 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:27 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:27 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:27 --> URI Class Initialized
INFO - 2016-12-09 16:23:27 --> Router Class Initialized
INFO - 2016-12-09 16:23:27 --> Output Class Initialized
INFO - 2016-12-09 16:23:27 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:27 --> Input Class Initialized
INFO - 2016-12-09 16:23:27 --> Language Class Initialized
INFO - 2016-12-09 16:23:27 --> Loader Class Initialized
INFO - 2016-12-09 16:23:27 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:27 --> Controller Class Initialized
INFO - 2016-12-09 16:23:27 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:27 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:27 --> Total execution time: 0.0137
INFO - 2016-12-09 16:23:28 --> Config Class Initialized
INFO - 2016-12-09 16:23:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:28 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:28 --> URI Class Initialized
INFO - 2016-12-09 16:23:28 --> Router Class Initialized
INFO - 2016-12-09 16:23:28 --> Output Class Initialized
INFO - 2016-12-09 16:23:28 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:28 --> Input Class Initialized
INFO - 2016-12-09 16:23:28 --> Language Class Initialized
INFO - 2016-12-09 16:23:28 --> Loader Class Initialized
INFO - 2016-12-09 16:23:28 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:28 --> Controller Class Initialized
INFO - 2016-12-09 16:23:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:28 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:28 --> Total execution time: 0.0133
INFO - 2016-12-09 16:23:28 --> Config Class Initialized
INFO - 2016-12-09 16:23:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:28 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:28 --> URI Class Initialized
DEBUG - 2016-12-09 16:23:28 --> No URI present. Default controller set.
INFO - 2016-12-09 16:23:28 --> Router Class Initialized
INFO - 2016-12-09 16:23:28 --> Output Class Initialized
INFO - 2016-12-09 16:23:28 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:28 --> Input Class Initialized
INFO - 2016-12-09 16:23:28 --> Language Class Initialized
INFO - 2016-12-09 16:23:28 --> Loader Class Initialized
INFO - 2016-12-09 16:23:28 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:28 --> Controller Class Initialized
INFO - 2016-12-09 16:23:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:28 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:28 --> Total execution time: 0.0134
INFO - 2016-12-09 16:23:28 --> Config Class Initialized
INFO - 2016-12-09 16:23:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:28 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:28 --> URI Class Initialized
INFO - 2016-12-09 16:23:28 --> Router Class Initialized
INFO - 2016-12-09 16:23:28 --> Output Class Initialized
INFO - 2016-12-09 16:23:28 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:28 --> Input Class Initialized
INFO - 2016-12-09 16:23:28 --> Language Class Initialized
INFO - 2016-12-09 16:23:28 --> Loader Class Initialized
INFO - 2016-12-09 16:23:28 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:28 --> Controller Class Initialized
INFO - 2016-12-09 16:23:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:28 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:28 --> Total execution time: 0.0137
INFO - 2016-12-09 16:23:28 --> Config Class Initialized
INFO - 2016-12-09 16:23:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:28 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:28 --> URI Class Initialized
INFO - 2016-12-09 16:23:28 --> Router Class Initialized
INFO - 2016-12-09 16:23:28 --> Output Class Initialized
INFO - 2016-12-09 16:23:28 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:28 --> Input Class Initialized
INFO - 2016-12-09 16:23:28 --> Language Class Initialized
INFO - 2016-12-09 16:23:28 --> Loader Class Initialized
INFO - 2016-12-09 16:23:28 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:28 --> Controller Class Initialized
INFO - 2016-12-09 16:23:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:28 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:28 --> Total execution time: 0.0131
INFO - 2016-12-09 16:23:28 --> Config Class Initialized
INFO - 2016-12-09 16:23:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:28 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:28 --> URI Class Initialized
INFO - 2016-12-09 16:23:28 --> Router Class Initialized
INFO - 2016-12-09 16:23:28 --> Output Class Initialized
INFO - 2016-12-09 16:23:28 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:28 --> Input Class Initialized
INFO - 2016-12-09 16:23:28 --> Language Class Initialized
INFO - 2016-12-09 16:23:28 --> Loader Class Initialized
INFO - 2016-12-09 16:23:28 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:28 --> Controller Class Initialized
INFO - 2016-12-09 16:23:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:28 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:28 --> Total execution time: 0.0139
INFO - 2016-12-09 16:23:29 --> Config Class Initialized
INFO - 2016-12-09 16:23:29 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:29 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:29 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:29 --> URI Class Initialized
INFO - 2016-12-09 16:23:29 --> Router Class Initialized
INFO - 2016-12-09 16:23:29 --> Output Class Initialized
INFO - 2016-12-09 16:23:29 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:29 --> Input Class Initialized
INFO - 2016-12-09 16:23:29 --> Language Class Initialized
INFO - 2016-12-09 16:23:29 --> Loader Class Initialized
INFO - 2016-12-09 16:23:29 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:29 --> Controller Class Initialized
INFO - 2016-12-09 16:23:29 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:29 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:29 --> Total execution time: 0.0141
INFO - 2016-12-09 16:23:29 --> Config Class Initialized
INFO - 2016-12-09 16:23:29 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:29 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:29 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:29 --> URI Class Initialized
INFO - 2016-12-09 16:23:29 --> Router Class Initialized
INFO - 2016-12-09 16:23:29 --> Output Class Initialized
INFO - 2016-12-09 16:23:29 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:29 --> Input Class Initialized
INFO - 2016-12-09 16:23:29 --> Language Class Initialized
INFO - 2016-12-09 16:23:29 --> Loader Class Initialized
INFO - 2016-12-09 16:23:29 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:29 --> Controller Class Initialized
INFO - 2016-12-09 16:23:29 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:29 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:29 --> Total execution time: 0.0150
INFO - 2016-12-09 16:23:29 --> Config Class Initialized
INFO - 2016-12-09 16:23:29 --> Hooks Class Initialized
DEBUG - 2016-12-09 16:23:29 --> UTF-8 Support Enabled
INFO - 2016-12-09 16:23:29 --> Utf8 Class Initialized
INFO - 2016-12-09 16:23:29 --> URI Class Initialized
INFO - 2016-12-09 16:23:29 --> Router Class Initialized
INFO - 2016-12-09 16:23:29 --> Output Class Initialized
INFO - 2016-12-09 16:23:29 --> Security Class Initialized
DEBUG - 2016-12-09 16:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 16:23:29 --> Input Class Initialized
INFO - 2016-12-09 16:23:29 --> Language Class Initialized
INFO - 2016-12-09 16:23:29 --> Loader Class Initialized
INFO - 2016-12-09 16:23:29 --> Database Driver Class Initialized
INFO - 2016-12-09 16:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 16:23:29 --> Controller Class Initialized
INFO - 2016-12-09 16:23:29 --> Helper loaded: url_helper
DEBUG - 2016-12-09 16:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 16:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 16:23:29 --> Final output sent to browser
DEBUG - 2016-12-09 16:23:29 --> Total execution time: 0.0134
INFO - 2016-12-09 17:27:44 --> Config Class Initialized
INFO - 2016-12-09 17:27:44 --> Hooks Class Initialized
DEBUG - 2016-12-09 17:27:44 --> UTF-8 Support Enabled
INFO - 2016-12-09 17:27:44 --> Utf8 Class Initialized
INFO - 2016-12-09 17:27:44 --> URI Class Initialized
DEBUG - 2016-12-09 17:27:44 --> No URI present. Default controller set.
INFO - 2016-12-09 17:27:44 --> Router Class Initialized
INFO - 2016-12-09 17:27:44 --> Output Class Initialized
INFO - 2016-12-09 17:27:44 --> Security Class Initialized
DEBUG - 2016-12-09 17:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 17:27:44 --> Input Class Initialized
INFO - 2016-12-09 17:27:44 --> Language Class Initialized
INFO - 2016-12-09 17:27:44 --> Loader Class Initialized
INFO - 2016-12-09 17:27:44 --> Database Driver Class Initialized
INFO - 2016-12-09 17:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 17:27:44 --> Controller Class Initialized
INFO - 2016-12-09 17:27:44 --> Helper loaded: url_helper
DEBUG - 2016-12-09 17:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 17:27:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 17:27:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 17:27:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 17:27:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 17:27:44 --> Final output sent to browser
DEBUG - 2016-12-09 17:27:44 --> Total execution time: 2.2596
INFO - 2016-12-09 23:49:28 --> Config Class Initialized
INFO - 2016-12-09 23:49:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 23:49:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 23:49:28 --> Utf8 Class Initialized
INFO - 2016-12-09 23:49:28 --> URI Class Initialized
DEBUG - 2016-12-09 23:49:28 --> No URI present. Default controller set.
INFO - 2016-12-09 23:49:28 --> Router Class Initialized
INFO - 2016-12-09 23:49:28 --> Output Class Initialized
INFO - 2016-12-09 23:49:28 --> Security Class Initialized
DEBUG - 2016-12-09 23:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 23:49:28 --> Input Class Initialized
INFO - 2016-12-09 23:49:28 --> Language Class Initialized
INFO - 2016-12-09 23:49:28 --> Loader Class Initialized
INFO - 2016-12-09 23:49:28 --> Database Driver Class Initialized
INFO - 2016-12-09 23:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 23:49:28 --> Controller Class Initialized
INFO - 2016-12-09 23:49:28 --> Helper loaded: url_helper
DEBUG - 2016-12-09 23:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-09 23:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-09 23:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-09 23:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-09 23:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-09 23:49:28 --> Final output sent to browser
DEBUG - 2016-12-09 23:49:28 --> Total execution time: 0.0194

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-03 00:15:41 --> Config Class Initialized
INFO - 2017-01-03 00:15:41 --> Hooks Class Initialized
DEBUG - 2017-01-03 00:15:41 --> UTF-8 Support Enabled
INFO - 2017-01-03 00:15:41 --> Utf8 Class Initialized
INFO - 2017-01-03 00:15:41 --> URI Class Initialized
DEBUG - 2017-01-03 00:15:41 --> No URI present. Default controller set.
INFO - 2017-01-03 00:15:41 --> Router Class Initialized
INFO - 2017-01-03 00:15:41 --> Output Class Initialized
INFO - 2017-01-03 00:15:41 --> Security Class Initialized
DEBUG - 2017-01-03 00:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 00:15:42 --> Input Class Initialized
INFO - 2017-01-03 00:15:42 --> Language Class Initialized
INFO - 2017-01-03 00:15:42 --> Loader Class Initialized
INFO - 2017-01-03 00:15:42 --> Database Driver Class Initialized
INFO - 2017-01-03 00:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 00:15:42 --> Controller Class Initialized
INFO - 2017-01-03 00:15:42 --> Helper loaded: url_helper
DEBUG - 2017-01-03 00:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 00:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 00:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 00:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 00:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 00:15:43 --> Final output sent to browser
DEBUG - 2017-01-03 00:15:43 --> Total execution time: 2.1509
INFO - 2017-01-03 04:34:33 --> Config Class Initialized
INFO - 2017-01-03 04:34:33 --> Hooks Class Initialized
DEBUG - 2017-01-03 04:34:33 --> UTF-8 Support Enabled
INFO - 2017-01-03 04:34:33 --> Utf8 Class Initialized
INFO - 2017-01-03 04:34:33 --> URI Class Initialized
DEBUG - 2017-01-03 04:34:33 --> No URI present. Default controller set.
INFO - 2017-01-03 04:34:33 --> Router Class Initialized
INFO - 2017-01-03 04:34:33 --> Output Class Initialized
INFO - 2017-01-03 04:34:33 --> Security Class Initialized
DEBUG - 2017-01-03 04:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 04:34:33 --> Input Class Initialized
INFO - 2017-01-03 04:34:33 --> Language Class Initialized
INFO - 2017-01-03 04:34:33 --> Loader Class Initialized
INFO - 2017-01-03 04:34:34 --> Database Driver Class Initialized
INFO - 2017-01-03 04:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 04:34:34 --> Controller Class Initialized
INFO - 2017-01-03 04:34:34 --> Helper loaded: url_helper
DEBUG - 2017-01-03 04:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 04:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 04:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 04:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 04:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 04:34:34 --> Final output sent to browser
DEBUG - 2017-01-03 04:34:34 --> Total execution time: 1.6473
INFO - 2017-01-03 14:49:44 --> Config Class Initialized
INFO - 2017-01-03 14:49:44 --> Hooks Class Initialized
DEBUG - 2017-01-03 14:49:44 --> UTF-8 Support Enabled
INFO - 2017-01-03 14:49:44 --> Utf8 Class Initialized
INFO - 2017-01-03 14:49:44 --> URI Class Initialized
DEBUG - 2017-01-03 14:49:44 --> No URI present. Default controller set.
INFO - 2017-01-03 14:49:44 --> Router Class Initialized
INFO - 2017-01-03 14:49:44 --> Output Class Initialized
INFO - 2017-01-03 14:49:44 --> Security Class Initialized
DEBUG - 2017-01-03 14:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 14:49:44 --> Input Class Initialized
INFO - 2017-01-03 14:49:44 --> Language Class Initialized
INFO - 2017-01-03 14:49:44 --> Loader Class Initialized
INFO - 2017-01-03 14:49:45 --> Database Driver Class Initialized
INFO - 2017-01-03 14:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 14:49:45 --> Controller Class Initialized
INFO - 2017-01-03 14:49:45 --> Helper loaded: url_helper
DEBUG - 2017-01-03 14:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 14:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 14:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 14:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 14:49:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 14:49:45 --> Final output sent to browser
DEBUG - 2017-01-03 14:49:45 --> Total execution time: 1.6129
INFO - 2017-01-03 18:49:14 --> Config Class Initialized
INFO - 2017-01-03 18:49:14 --> Hooks Class Initialized
DEBUG - 2017-01-03 18:49:14 --> UTF-8 Support Enabled
INFO - 2017-01-03 18:49:14 --> Utf8 Class Initialized
INFO - 2017-01-03 18:49:14 --> URI Class Initialized
DEBUG - 2017-01-03 18:49:14 --> No URI present. Default controller set.
INFO - 2017-01-03 18:49:14 --> Router Class Initialized
INFO - 2017-01-03 18:49:14 --> Output Class Initialized
INFO - 2017-01-03 18:49:14 --> Security Class Initialized
DEBUG - 2017-01-03 18:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 18:49:15 --> Input Class Initialized
INFO - 2017-01-03 18:49:15 --> Language Class Initialized
INFO - 2017-01-03 18:49:15 --> Loader Class Initialized
INFO - 2017-01-03 18:49:15 --> Database Driver Class Initialized
INFO - 2017-01-03 18:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 18:49:15 --> Controller Class Initialized
INFO - 2017-01-03 18:49:15 --> Helper loaded: url_helper
DEBUG - 2017-01-03 18:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 18:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 18:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 18:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 18:49:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 18:49:16 --> Final output sent to browser
DEBUG - 2017-01-03 18:49:16 --> Total execution time: 1.9108
INFO - 2017-01-03 18:51:58 --> Config Class Initialized
INFO - 2017-01-03 18:51:58 --> Hooks Class Initialized
DEBUG - 2017-01-03 18:51:58 --> UTF-8 Support Enabled
INFO - 2017-01-03 18:51:58 --> Utf8 Class Initialized
INFO - 2017-01-03 18:51:58 --> URI Class Initialized
DEBUG - 2017-01-03 18:51:58 --> No URI present. Default controller set.
INFO - 2017-01-03 18:51:58 --> Router Class Initialized
INFO - 2017-01-03 18:51:58 --> Output Class Initialized
INFO - 2017-01-03 18:51:58 --> Security Class Initialized
DEBUG - 2017-01-03 18:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 18:51:58 --> Input Class Initialized
INFO - 2017-01-03 18:51:58 --> Language Class Initialized
INFO - 2017-01-03 18:51:58 --> Loader Class Initialized
INFO - 2017-01-03 18:51:58 --> Database Driver Class Initialized
INFO - 2017-01-03 18:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 18:51:58 --> Controller Class Initialized
INFO - 2017-01-03 18:51:58 --> Helper loaded: url_helper
DEBUG - 2017-01-03 18:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 18:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 18:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 18:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 18:51:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 18:51:58 --> Final output sent to browser
DEBUG - 2017-01-03 18:51:58 --> Total execution time: 0.0246
INFO - 2017-01-03 18:52:49 --> Config Class Initialized
INFO - 2017-01-03 18:52:49 --> Hooks Class Initialized
DEBUG - 2017-01-03 18:52:49 --> UTF-8 Support Enabled
INFO - 2017-01-03 18:52:49 --> Utf8 Class Initialized
INFO - 2017-01-03 18:52:49 --> URI Class Initialized
DEBUG - 2017-01-03 18:52:49 --> No URI present. Default controller set.
INFO - 2017-01-03 18:52:49 --> Router Class Initialized
INFO - 2017-01-03 18:52:49 --> Output Class Initialized
INFO - 2017-01-03 18:52:49 --> Security Class Initialized
DEBUG - 2017-01-03 18:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 18:52:49 --> Input Class Initialized
INFO - 2017-01-03 18:52:49 --> Language Class Initialized
INFO - 2017-01-03 18:52:49 --> Loader Class Initialized
INFO - 2017-01-03 18:52:49 --> Database Driver Class Initialized
INFO - 2017-01-03 18:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 18:52:49 --> Controller Class Initialized
INFO - 2017-01-03 18:52:49 --> Helper loaded: url_helper
DEBUG - 2017-01-03 18:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 18:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 18:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 18:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 18:52:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 18:52:49 --> Final output sent to browser
DEBUG - 2017-01-03 18:52:49 --> Total execution time: 0.0139
INFO - 2017-01-03 20:54:21 --> Config Class Initialized
INFO - 2017-01-03 20:54:21 --> Hooks Class Initialized
DEBUG - 2017-01-03 20:54:21 --> UTF-8 Support Enabled
INFO - 2017-01-03 20:54:21 --> Utf8 Class Initialized
INFO - 2017-01-03 20:54:21 --> URI Class Initialized
DEBUG - 2017-01-03 20:54:21 --> No URI present. Default controller set.
INFO - 2017-01-03 20:54:21 --> Router Class Initialized
INFO - 2017-01-03 20:54:21 --> Output Class Initialized
INFO - 2017-01-03 20:54:21 --> Security Class Initialized
DEBUG - 2017-01-03 20:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 20:54:21 --> Input Class Initialized
INFO - 2017-01-03 20:54:22 --> Language Class Initialized
INFO - 2017-01-03 20:54:22 --> Loader Class Initialized
INFO - 2017-01-03 20:54:22 --> Database Driver Class Initialized
INFO - 2017-01-03 20:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 20:54:22 --> Controller Class Initialized
INFO - 2017-01-03 20:54:22 --> Helper loaded: url_helper
DEBUG - 2017-01-03 20:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 20:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 20:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 20:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 20:54:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 20:54:23 --> Final output sent to browser
DEBUG - 2017-01-03 20:54:23 --> Total execution time: 1.7543
INFO - 2017-01-03 20:54:25 --> Config Class Initialized
INFO - 2017-01-03 20:54:25 --> Hooks Class Initialized
DEBUG - 2017-01-03 20:54:25 --> UTF-8 Support Enabled
INFO - 2017-01-03 20:54:25 --> Utf8 Class Initialized
INFO - 2017-01-03 20:54:25 --> URI Class Initialized
INFO - 2017-01-03 20:54:25 --> Router Class Initialized
INFO - 2017-01-03 20:54:25 --> Output Class Initialized
INFO - 2017-01-03 20:54:25 --> Security Class Initialized
DEBUG - 2017-01-03 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 20:54:25 --> Input Class Initialized
INFO - 2017-01-03 20:54:25 --> Language Class Initialized
INFO - 2017-01-03 20:54:25 --> Loader Class Initialized
INFO - 2017-01-03 20:54:25 --> Database Driver Class Initialized
INFO - 2017-01-03 20:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 20:54:25 --> Controller Class Initialized
INFO - 2017-01-03 20:54:25 --> Helper loaded: url_helper
DEBUG - 2017-01-03 20:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 20:54:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 20:54:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 20:54:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 20:54:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 20:54:25 --> Final output sent to browser
DEBUG - 2017-01-03 20:54:25 --> Total execution time: 0.0226
INFO - 2017-01-03 21:00:14 --> Config Class Initialized
INFO - 2017-01-03 21:00:14 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:00:14 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:00:14 --> Utf8 Class Initialized
INFO - 2017-01-03 21:00:14 --> URI Class Initialized
DEBUG - 2017-01-03 21:00:14 --> No URI present. Default controller set.
INFO - 2017-01-03 21:00:14 --> Router Class Initialized
INFO - 2017-01-03 21:00:14 --> Output Class Initialized
INFO - 2017-01-03 21:00:14 --> Security Class Initialized
DEBUG - 2017-01-03 21:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:00:14 --> Input Class Initialized
INFO - 2017-01-03 21:00:14 --> Language Class Initialized
INFO - 2017-01-03 21:00:14 --> Loader Class Initialized
INFO - 2017-01-03 21:00:14 --> Database Driver Class Initialized
INFO - 2017-01-03 21:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:00:15 --> Controller Class Initialized
INFO - 2017-01-03 21:00:15 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:00:15 --> Final output sent to browser
DEBUG - 2017-01-03 21:00:15 --> Total execution time: 1.6245
INFO - 2017-01-03 21:00:16 --> Config Class Initialized
INFO - 2017-01-03 21:00:16 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:00:16 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:00:16 --> Utf8 Class Initialized
INFO - 2017-01-03 21:00:16 --> URI Class Initialized
INFO - 2017-01-03 21:00:16 --> Router Class Initialized
INFO - 2017-01-03 21:00:16 --> Output Class Initialized
INFO - 2017-01-03 21:00:16 --> Security Class Initialized
DEBUG - 2017-01-03 21:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:00:16 --> Input Class Initialized
INFO - 2017-01-03 21:00:16 --> Language Class Initialized
INFO - 2017-01-03 21:00:16 --> Loader Class Initialized
INFO - 2017-01-03 21:00:16 --> Database Driver Class Initialized
INFO - 2017-01-03 21:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:00:16 --> Controller Class Initialized
INFO - 2017-01-03 21:00:16 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:00:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:00:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:00:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:00:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:00:16 --> Final output sent to browser
DEBUG - 2017-01-03 21:00:16 --> Total execution time: 0.0131
INFO - 2017-01-03 21:02:37 --> Config Class Initialized
INFO - 2017-01-03 21:02:37 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:02:37 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:02:37 --> Utf8 Class Initialized
INFO - 2017-01-03 21:02:37 --> URI Class Initialized
DEBUG - 2017-01-03 21:02:38 --> No URI present. Default controller set.
INFO - 2017-01-03 21:02:38 --> Router Class Initialized
INFO - 2017-01-03 21:02:38 --> Output Class Initialized
INFO - 2017-01-03 21:02:38 --> Security Class Initialized
DEBUG - 2017-01-03 21:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:02:38 --> Input Class Initialized
INFO - 2017-01-03 21:02:38 --> Language Class Initialized
INFO - 2017-01-03 21:02:38 --> Loader Class Initialized
INFO - 2017-01-03 21:02:38 --> Database Driver Class Initialized
INFO - 2017-01-03 21:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:02:38 --> Controller Class Initialized
INFO - 2017-01-03 21:02:38 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:02:39 --> Final output sent to browser
DEBUG - 2017-01-03 21:02:39 --> Total execution time: 1.4543
INFO - 2017-01-03 21:02:39 --> Config Class Initialized
INFO - 2017-01-03 21:02:39 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:02:39 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:02:39 --> Utf8 Class Initialized
INFO - 2017-01-03 21:02:39 --> URI Class Initialized
INFO - 2017-01-03 21:02:39 --> Router Class Initialized
INFO - 2017-01-03 21:02:39 --> Output Class Initialized
INFO - 2017-01-03 21:02:39 --> Security Class Initialized
DEBUG - 2017-01-03 21:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:02:39 --> Input Class Initialized
INFO - 2017-01-03 21:02:39 --> Language Class Initialized
INFO - 2017-01-03 21:02:39 --> Loader Class Initialized
INFO - 2017-01-03 21:02:39 --> Database Driver Class Initialized
INFO - 2017-01-03 21:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:02:39 --> Controller Class Initialized
INFO - 2017-01-03 21:02:39 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:02:39 --> Final output sent to browser
DEBUG - 2017-01-03 21:02:39 --> Total execution time: 0.0148
INFO - 2017-01-03 21:03:23 --> Config Class Initialized
INFO - 2017-01-03 21:03:23 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:03:24 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:03:24 --> Utf8 Class Initialized
INFO - 2017-01-03 21:03:24 --> URI Class Initialized
INFO - 2017-01-03 21:03:24 --> Router Class Initialized
INFO - 2017-01-03 21:03:24 --> Output Class Initialized
INFO - 2017-01-03 21:03:24 --> Security Class Initialized
DEBUG - 2017-01-03 21:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:03:24 --> Input Class Initialized
INFO - 2017-01-03 21:03:24 --> Language Class Initialized
INFO - 2017-01-03 21:03:24 --> Loader Class Initialized
INFO - 2017-01-03 21:03:24 --> Database Driver Class Initialized
INFO - 2017-01-03 21:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:03:24 --> Controller Class Initialized
INFO - 2017-01-03 21:03:24 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:03:25 --> Final output sent to browser
DEBUG - 2017-01-03 21:03:25 --> Total execution time: 1.4701
INFO - 2017-01-03 21:03:25 --> Config Class Initialized
INFO - 2017-01-03 21:03:25 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:03:25 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:03:25 --> Utf8 Class Initialized
INFO - 2017-01-03 21:03:25 --> URI Class Initialized
INFO - 2017-01-03 21:03:25 --> Router Class Initialized
INFO - 2017-01-03 21:03:25 --> Output Class Initialized
INFO - 2017-01-03 21:03:25 --> Security Class Initialized
DEBUG - 2017-01-03 21:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:03:25 --> Input Class Initialized
INFO - 2017-01-03 21:03:25 --> Language Class Initialized
INFO - 2017-01-03 21:03:25 --> Loader Class Initialized
INFO - 2017-01-03 21:03:25 --> Database Driver Class Initialized
INFO - 2017-01-03 21:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:03:25 --> Controller Class Initialized
INFO - 2017-01-03 21:03:25 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:03:25 --> Final output sent to browser
DEBUG - 2017-01-03 21:03:25 --> Total execution time: 0.0419
INFO - 2017-01-03 21:03:32 --> Config Class Initialized
INFO - 2017-01-03 21:03:32 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:03:32 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:03:32 --> Utf8 Class Initialized
INFO - 2017-01-03 21:03:32 --> URI Class Initialized
INFO - 2017-01-03 21:03:32 --> Router Class Initialized
INFO - 2017-01-03 21:03:32 --> Output Class Initialized
INFO - 2017-01-03 21:03:32 --> Security Class Initialized
DEBUG - 2017-01-03 21:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:03:32 --> Input Class Initialized
INFO - 2017-01-03 21:03:32 --> Language Class Initialized
INFO - 2017-01-03 21:03:32 --> Loader Class Initialized
INFO - 2017-01-03 21:03:32 --> Database Driver Class Initialized
INFO - 2017-01-03 21:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:03:32 --> Controller Class Initialized
INFO - 2017-01-03 21:03:32 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:03:33 --> Helper loaded: form_helper
INFO - 2017-01-03 21:03:33 --> Form Validation Class Initialized
INFO - 2017-01-03 21:03:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-03 21:03:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-03 21:03:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-03 21:03:33 --> Final output sent to browser
DEBUG - 2017-01-03 21:03:33 --> Total execution time: 0.5123
INFO - 2017-01-03 21:03:33 --> Config Class Initialized
INFO - 2017-01-03 21:03:33 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:03:33 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:03:33 --> Utf8 Class Initialized
INFO - 2017-01-03 21:03:33 --> URI Class Initialized
INFO - 2017-01-03 21:03:33 --> Router Class Initialized
INFO - 2017-01-03 21:03:33 --> Output Class Initialized
INFO - 2017-01-03 21:03:33 --> Security Class Initialized
DEBUG - 2017-01-03 21:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:03:33 --> Input Class Initialized
INFO - 2017-01-03 21:03:33 --> Language Class Initialized
INFO - 2017-01-03 21:03:33 --> Loader Class Initialized
INFO - 2017-01-03 21:03:33 --> Database Driver Class Initialized
INFO - 2017-01-03 21:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:03:33 --> Controller Class Initialized
INFO - 2017-01-03 21:03:33 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:03:33 --> Final output sent to browser
DEBUG - 2017-01-03 21:03:33 --> Total execution time: 0.0139
INFO - 2017-01-03 21:04:17 --> Config Class Initialized
INFO - 2017-01-03 21:04:17 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:04:17 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:04:17 --> Utf8 Class Initialized
INFO - 2017-01-03 21:04:17 --> URI Class Initialized
INFO - 2017-01-03 21:04:17 --> Router Class Initialized
INFO - 2017-01-03 21:04:17 --> Output Class Initialized
INFO - 2017-01-03 21:04:17 --> Security Class Initialized
DEBUG - 2017-01-03 21:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:04:17 --> Input Class Initialized
INFO - 2017-01-03 21:04:17 --> Language Class Initialized
INFO - 2017-01-03 21:04:17 --> Loader Class Initialized
INFO - 2017-01-03 21:04:18 --> Database Driver Class Initialized
INFO - 2017-01-03 21:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:04:18 --> Controller Class Initialized
INFO - 2017-01-03 21:04:18 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:04:18 --> Helper loaded: form_helper
INFO - 2017-01-03 21:04:18 --> Form Validation Class Initialized
INFO - 2017-01-03 21:04:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-03 21:04:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-03 21:04:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-03 21:04:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-03 21:04:19 --> Final output sent to browser
DEBUG - 2017-01-03 21:04:19 --> Total execution time: 1.8996
INFO - 2017-01-03 21:04:19 --> Config Class Initialized
INFO - 2017-01-03 21:04:19 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:04:19 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:04:19 --> Utf8 Class Initialized
INFO - 2017-01-03 21:04:19 --> URI Class Initialized
INFO - 2017-01-03 21:04:19 --> Router Class Initialized
INFO - 2017-01-03 21:04:19 --> Output Class Initialized
INFO - 2017-01-03 21:04:19 --> Security Class Initialized
DEBUG - 2017-01-03 21:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:04:19 --> Input Class Initialized
INFO - 2017-01-03 21:04:19 --> Language Class Initialized
INFO - 2017-01-03 21:04:20 --> Loader Class Initialized
INFO - 2017-01-03 21:04:20 --> Database Driver Class Initialized
INFO - 2017-01-03 21:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:04:20 --> Controller Class Initialized
INFO - 2017-01-03 21:04:20 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:04:20 --> Final output sent to browser
DEBUG - 2017-01-03 21:04:20 --> Total execution time: 0.7254
INFO - 2017-01-03 21:05:08 --> Config Class Initialized
INFO - 2017-01-03 21:05:08 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:05:08 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:05:08 --> Utf8 Class Initialized
INFO - 2017-01-03 21:05:08 --> URI Class Initialized
INFO - 2017-01-03 21:05:08 --> Router Class Initialized
INFO - 2017-01-03 21:05:09 --> Output Class Initialized
INFO - 2017-01-03 21:05:09 --> Security Class Initialized
DEBUG - 2017-01-03 21:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:05:09 --> Input Class Initialized
INFO - 2017-01-03 21:05:09 --> Language Class Initialized
INFO - 2017-01-03 21:05:09 --> Loader Class Initialized
INFO - 2017-01-03 21:05:09 --> Database Driver Class Initialized
INFO - 2017-01-03 21:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:05:09 --> Controller Class Initialized
INFO - 2017-01-03 21:05:09 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:05:09 --> Helper loaded: form_helper
INFO - 2017-01-03 21:05:09 --> Form Validation Class Initialized
INFO - 2017-01-03 21:05:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-03 21:05:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-03 21:05:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-03 21:05:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-03 21:05:09 --> Final output sent to browser
DEBUG - 2017-01-03 21:05:09 --> Total execution time: 1.4367
INFO - 2017-01-03 21:05:10 --> Config Class Initialized
INFO - 2017-01-03 21:05:10 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:05:10 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:05:10 --> Utf8 Class Initialized
INFO - 2017-01-03 21:05:10 --> URI Class Initialized
INFO - 2017-01-03 21:05:10 --> Router Class Initialized
INFO - 2017-01-03 21:05:10 --> Output Class Initialized
INFO - 2017-01-03 21:05:10 --> Security Class Initialized
DEBUG - 2017-01-03 21:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:05:10 --> Input Class Initialized
INFO - 2017-01-03 21:05:10 --> Language Class Initialized
INFO - 2017-01-03 21:05:10 --> Loader Class Initialized
INFO - 2017-01-03 21:05:10 --> Database Driver Class Initialized
INFO - 2017-01-03 21:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:05:10 --> Controller Class Initialized
INFO - 2017-01-03 21:05:10 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:05:10 --> Final output sent to browser
DEBUG - 2017-01-03 21:05:10 --> Total execution time: 0.2994
INFO - 2017-01-03 21:17:27 --> Config Class Initialized
INFO - 2017-01-03 21:17:27 --> Hooks Class Initialized
DEBUG - 2017-01-03 21:17:27 --> UTF-8 Support Enabled
INFO - 2017-01-03 21:17:27 --> Utf8 Class Initialized
INFO - 2017-01-03 21:17:27 --> URI Class Initialized
DEBUG - 2017-01-03 21:17:27 --> No URI present. Default controller set.
INFO - 2017-01-03 21:17:27 --> Router Class Initialized
INFO - 2017-01-03 21:17:27 --> Output Class Initialized
INFO - 2017-01-03 21:17:27 --> Security Class Initialized
DEBUG - 2017-01-03 21:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 21:17:27 --> Input Class Initialized
INFO - 2017-01-03 21:17:27 --> Language Class Initialized
INFO - 2017-01-03 21:17:27 --> Loader Class Initialized
INFO - 2017-01-03 21:17:28 --> Database Driver Class Initialized
INFO - 2017-01-03 21:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 21:17:28 --> Controller Class Initialized
INFO - 2017-01-03 21:17:28 --> Helper loaded: url_helper
DEBUG - 2017-01-03 21:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 21:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 21:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 21:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 21:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 21:17:29 --> Final output sent to browser
DEBUG - 2017-01-03 21:17:29 --> Total execution time: 1.9927
INFO - 2017-01-03 22:05:43 --> Config Class Initialized
INFO - 2017-01-03 22:05:43 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:05:43 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:05:43 --> Utf8 Class Initialized
INFO - 2017-01-03 22:05:43 --> URI Class Initialized
DEBUG - 2017-01-03 22:05:43 --> No URI present. Default controller set.
INFO - 2017-01-03 22:05:43 --> Router Class Initialized
INFO - 2017-01-03 22:05:43 --> Output Class Initialized
INFO - 2017-01-03 22:05:43 --> Security Class Initialized
DEBUG - 2017-01-03 22:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:05:43 --> Input Class Initialized
INFO - 2017-01-03 22:05:43 --> Language Class Initialized
INFO - 2017-01-03 22:05:43 --> Loader Class Initialized
INFO - 2017-01-03 22:05:44 --> Database Driver Class Initialized
INFO - 2017-01-03 22:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:05:44 --> Controller Class Initialized
INFO - 2017-01-03 22:05:44 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:05:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:05:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:05:45 --> Final output sent to browser
DEBUG - 2017-01-03 22:05:45 --> Total execution time: 1.9338
INFO - 2017-01-03 22:53:36 --> Config Class Initialized
INFO - 2017-01-03 22:53:36 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:53:36 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:53:36 --> Utf8 Class Initialized
INFO - 2017-01-03 22:53:36 --> URI Class Initialized
DEBUG - 2017-01-03 22:53:36 --> No URI present. Default controller set.
INFO - 2017-01-03 22:53:36 --> Router Class Initialized
INFO - 2017-01-03 22:53:36 --> Output Class Initialized
INFO - 2017-01-03 22:53:36 --> Security Class Initialized
DEBUG - 2017-01-03 22:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:53:37 --> Input Class Initialized
INFO - 2017-01-03 22:53:37 --> Language Class Initialized
INFO - 2017-01-03 22:53:37 --> Loader Class Initialized
INFO - 2017-01-03 22:53:37 --> Database Driver Class Initialized
INFO - 2017-01-03 22:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:53:38 --> Controller Class Initialized
INFO - 2017-01-03 22:53:38 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:53:38 --> Final output sent to browser
DEBUG - 2017-01-03 22:53:38 --> Total execution time: 1.6777
INFO - 2017-01-03 22:54:07 --> Config Class Initialized
INFO - 2017-01-03 22:54:07 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:54:07 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:54:07 --> Utf8 Class Initialized
INFO - 2017-01-03 22:54:07 --> URI Class Initialized
DEBUG - 2017-01-03 22:54:07 --> No URI present. Default controller set.
INFO - 2017-01-03 22:54:07 --> Router Class Initialized
INFO - 2017-01-03 22:54:07 --> Output Class Initialized
INFO - 2017-01-03 22:54:07 --> Security Class Initialized
DEBUG - 2017-01-03 22:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:54:07 --> Input Class Initialized
INFO - 2017-01-03 22:54:07 --> Language Class Initialized
INFO - 2017-01-03 22:54:08 --> Loader Class Initialized
INFO - 2017-01-03 22:54:08 --> Database Driver Class Initialized
INFO - 2017-01-03 22:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:54:08 --> Controller Class Initialized
INFO - 2017-01-03 22:54:08 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:54:08 --> Final output sent to browser
DEBUG - 2017-01-03 22:54:08 --> Total execution time: 1.0004
INFO - 2017-01-03 22:54:09 --> Config Class Initialized
INFO - 2017-01-03 22:54:09 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:54:09 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:54:09 --> Utf8 Class Initialized
INFO - 2017-01-03 22:54:09 --> URI Class Initialized
DEBUG - 2017-01-03 22:54:09 --> No URI present. Default controller set.
INFO - 2017-01-03 22:54:09 --> Router Class Initialized
INFO - 2017-01-03 22:54:09 --> Output Class Initialized
INFO - 2017-01-03 22:54:09 --> Security Class Initialized
DEBUG - 2017-01-03 22:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:54:09 --> Input Class Initialized
INFO - 2017-01-03 22:54:09 --> Language Class Initialized
INFO - 2017-01-03 22:54:09 --> Loader Class Initialized
INFO - 2017-01-03 22:54:10 --> Database Driver Class Initialized
INFO - 2017-01-03 22:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:54:10 --> Controller Class Initialized
INFO - 2017-01-03 22:54:10 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:54:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:54:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:54:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:54:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:54:10 --> Final output sent to browser
DEBUG - 2017-01-03 22:54:10 --> Total execution time: 1.0859
INFO - 2017-01-03 22:54:10 --> Config Class Initialized
INFO - 2017-01-03 22:54:10 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:54:10 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:54:10 --> Utf8 Class Initialized
INFO - 2017-01-03 22:54:10 --> URI Class Initialized
INFO - 2017-01-03 22:54:10 --> Router Class Initialized
INFO - 2017-01-03 22:54:10 --> Output Class Initialized
INFO - 2017-01-03 22:54:10 --> Security Class Initialized
DEBUG - 2017-01-03 22:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:54:10 --> Input Class Initialized
INFO - 2017-01-03 22:54:10 --> Language Class Initialized
INFO - 2017-01-03 22:54:10 --> Loader Class Initialized
INFO - 2017-01-03 22:54:11 --> Database Driver Class Initialized
INFO - 2017-01-03 22:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:54:11 --> Controller Class Initialized
INFO - 2017-01-03 22:54:11 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:54:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:54:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:54:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:54:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:54:11 --> Final output sent to browser
DEBUG - 2017-01-03 22:54:11 --> Total execution time: 1.1372
INFO - 2017-01-03 22:57:51 --> Config Class Initialized
INFO - 2017-01-03 22:57:51 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:57:51 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:57:51 --> Utf8 Class Initialized
INFO - 2017-01-03 22:57:51 --> URI Class Initialized
DEBUG - 2017-01-03 22:57:51 --> No URI present. Default controller set.
INFO - 2017-01-03 22:57:51 --> Router Class Initialized
INFO - 2017-01-03 22:57:52 --> Output Class Initialized
INFO - 2017-01-03 22:57:52 --> Security Class Initialized
DEBUG - 2017-01-03 22:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:57:52 --> Input Class Initialized
INFO - 2017-01-03 22:57:52 --> Language Class Initialized
INFO - 2017-01-03 22:57:52 --> Loader Class Initialized
INFO - 2017-01-03 22:57:52 --> Database Driver Class Initialized
INFO - 2017-01-03 22:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:57:52 --> Controller Class Initialized
INFO - 2017-01-03 22:57:52 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:57:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:57:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:57:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:57:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:57:52 --> Final output sent to browser
DEBUG - 2017-01-03 22:57:52 --> Total execution time: 0.8998
INFO - 2017-01-03 22:57:53 --> Config Class Initialized
INFO - 2017-01-03 22:57:53 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:57:53 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:57:53 --> Utf8 Class Initialized
INFO - 2017-01-03 22:57:53 --> URI Class Initialized
INFO - 2017-01-03 22:57:53 --> Router Class Initialized
INFO - 2017-01-03 22:57:53 --> Output Class Initialized
INFO - 2017-01-03 22:57:53 --> Security Class Initialized
DEBUG - 2017-01-03 22:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:57:53 --> Input Class Initialized
INFO - 2017-01-03 22:57:53 --> Language Class Initialized
INFO - 2017-01-03 22:57:53 --> Loader Class Initialized
INFO - 2017-01-03 22:57:53 --> Database Driver Class Initialized
INFO - 2017-01-03 22:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:57:53 --> Controller Class Initialized
INFO - 2017-01-03 22:57:53 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:57:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:57:53 --> Final output sent to browser
DEBUG - 2017-01-03 22:57:53 --> Total execution time: 0.0138
INFO - 2017-01-03 22:58:36 --> Config Class Initialized
INFO - 2017-01-03 22:58:36 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:58:36 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:58:36 --> Utf8 Class Initialized
INFO - 2017-01-03 22:58:36 --> URI Class Initialized
INFO - 2017-01-03 22:58:36 --> Router Class Initialized
INFO - 2017-01-03 22:58:36 --> Output Class Initialized
INFO - 2017-01-03 22:58:36 --> Security Class Initialized
DEBUG - 2017-01-03 22:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:58:36 --> Input Class Initialized
INFO - 2017-01-03 22:58:36 --> Language Class Initialized
INFO - 2017-01-03 22:58:36 --> Loader Class Initialized
INFO - 2017-01-03 22:58:36 --> Database Driver Class Initialized
INFO - 2017-01-03 22:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:58:36 --> Controller Class Initialized
INFO - 2017-01-03 22:58:36 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:58:38 --> Config Class Initialized
INFO - 2017-01-03 22:58:38 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:58:38 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:58:38 --> Utf8 Class Initialized
INFO - 2017-01-03 22:58:38 --> URI Class Initialized
INFO - 2017-01-03 22:58:38 --> Router Class Initialized
INFO - 2017-01-03 22:58:38 --> Output Class Initialized
INFO - 2017-01-03 22:58:38 --> Security Class Initialized
DEBUG - 2017-01-03 22:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:58:38 --> Input Class Initialized
INFO - 2017-01-03 22:58:38 --> Language Class Initialized
INFO - 2017-01-03 22:58:38 --> Loader Class Initialized
INFO - 2017-01-03 22:58:38 --> Database Driver Class Initialized
INFO - 2017-01-03 22:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:58:38 --> Controller Class Initialized
INFO - 2017-01-03 22:58:39 --> Helper loaded: date_helper
DEBUG - 2017-01-03 22:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:58:39 --> Helper loaded: url_helper
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:58:39 --> Final output sent to browser
DEBUG - 2017-01-03 22:58:39 --> Total execution time: 0.9724
INFO - 2017-01-03 22:58:39 --> Config Class Initialized
INFO - 2017-01-03 22:58:39 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:58:39 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:58:39 --> Utf8 Class Initialized
INFO - 2017-01-03 22:58:39 --> URI Class Initialized
INFO - 2017-01-03 22:58:39 --> Router Class Initialized
INFO - 2017-01-03 22:58:39 --> Output Class Initialized
INFO - 2017-01-03 22:58:39 --> Security Class Initialized
DEBUG - 2017-01-03 22:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:58:39 --> Input Class Initialized
INFO - 2017-01-03 22:58:39 --> Language Class Initialized
INFO - 2017-01-03 22:58:39 --> Loader Class Initialized
INFO - 2017-01-03 22:58:39 --> Database Driver Class Initialized
INFO - 2017-01-03 22:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:58:39 --> Controller Class Initialized
INFO - 2017-01-03 22:58:39 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:58:39 --> Final output sent to browser
DEBUG - 2017-01-03 22:58:39 --> Total execution time: 0.0140
INFO - 2017-01-03 22:58:49 --> Config Class Initialized
INFO - 2017-01-03 22:58:49 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:58:49 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:58:49 --> Utf8 Class Initialized
INFO - 2017-01-03 22:58:49 --> URI Class Initialized
INFO - 2017-01-03 22:58:49 --> Router Class Initialized
INFO - 2017-01-03 22:58:49 --> Output Class Initialized
INFO - 2017-01-03 22:58:49 --> Security Class Initialized
DEBUG - 2017-01-03 22:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:58:49 --> Input Class Initialized
INFO - 2017-01-03 22:58:49 --> Language Class Initialized
INFO - 2017-01-03 22:58:49 --> Loader Class Initialized
INFO - 2017-01-03 22:58:49 --> Database Driver Class Initialized
INFO - 2017-01-03 22:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:58:49 --> Controller Class Initialized
INFO - 2017-01-03 22:58:49 --> Helper loaded: date_helper
DEBUG - 2017-01-03 22:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:58:49 --> Helper loaded: url_helper
INFO - 2017-01-03 22:58:49 --> Helper loaded: download_helper
INFO - 2017-01-03 22:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-03 22:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-03 22:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-03 22:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:58:49 --> Final output sent to browser
DEBUG - 2017-01-03 22:58:49 --> Total execution time: 0.3597
INFO - 2017-01-03 22:58:50 --> Config Class Initialized
INFO - 2017-01-03 22:58:50 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:58:50 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:58:50 --> Utf8 Class Initialized
INFO - 2017-01-03 22:58:50 --> URI Class Initialized
INFO - 2017-01-03 22:58:50 --> Router Class Initialized
INFO - 2017-01-03 22:58:50 --> Output Class Initialized
INFO - 2017-01-03 22:58:50 --> Security Class Initialized
DEBUG - 2017-01-03 22:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:58:50 --> Input Class Initialized
INFO - 2017-01-03 22:58:50 --> Language Class Initialized
INFO - 2017-01-03 22:58:50 --> Loader Class Initialized
INFO - 2017-01-03 22:58:50 --> Database Driver Class Initialized
INFO - 2017-01-03 22:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:58:50 --> Controller Class Initialized
INFO - 2017-01-03 22:58:50 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:58:50 --> Final output sent to browser
DEBUG - 2017-01-03 22:58:50 --> Total execution time: 0.0136
INFO - 2017-01-03 22:59:26 --> Config Class Initialized
INFO - 2017-01-03 22:59:26 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:59:26 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:59:26 --> Utf8 Class Initialized
INFO - 2017-01-03 22:59:26 --> URI Class Initialized
INFO - 2017-01-03 22:59:26 --> Router Class Initialized
INFO - 2017-01-03 22:59:26 --> Output Class Initialized
INFO - 2017-01-03 22:59:26 --> Security Class Initialized
DEBUG - 2017-01-03 22:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:59:26 --> Input Class Initialized
INFO - 2017-01-03 22:59:26 --> Language Class Initialized
INFO - 2017-01-03 22:59:26 --> Loader Class Initialized
INFO - 2017-01-03 22:59:26 --> Database Driver Class Initialized
INFO - 2017-01-03 22:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:59:26 --> Controller Class Initialized
INFO - 2017-01-03 22:59:26 --> Upload Class Initialized
INFO - 2017-01-03 22:59:26 --> Helper loaded: date_helper
DEBUG - 2017-01-03 22:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:59:26 --> Helper loaded: url_helper
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:59:26 --> Final output sent to browser
DEBUG - 2017-01-03 22:59:26 --> Total execution time: 0.1920
INFO - 2017-01-03 22:59:26 --> Config Class Initialized
INFO - 2017-01-03 22:59:26 --> Hooks Class Initialized
DEBUG - 2017-01-03 22:59:26 --> UTF-8 Support Enabled
INFO - 2017-01-03 22:59:26 --> Utf8 Class Initialized
INFO - 2017-01-03 22:59:26 --> URI Class Initialized
INFO - 2017-01-03 22:59:26 --> Router Class Initialized
INFO - 2017-01-03 22:59:26 --> Output Class Initialized
INFO - 2017-01-03 22:59:26 --> Security Class Initialized
DEBUG - 2017-01-03 22:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 22:59:26 --> Input Class Initialized
INFO - 2017-01-03 22:59:26 --> Language Class Initialized
INFO - 2017-01-03 22:59:26 --> Loader Class Initialized
INFO - 2017-01-03 22:59:26 --> Database Driver Class Initialized
INFO - 2017-01-03 22:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 22:59:26 --> Controller Class Initialized
INFO - 2017-01-03 22:59:26 --> Helper loaded: url_helper
DEBUG - 2017-01-03 22:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 22:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 22:59:26 --> Final output sent to browser
DEBUG - 2017-01-03 22:59:26 --> Total execution time: 0.0150
INFO - 2017-01-03 23:39:42 --> Config Class Initialized
INFO - 2017-01-03 23:39:42 --> Hooks Class Initialized
DEBUG - 2017-01-03 23:39:43 --> UTF-8 Support Enabled
INFO - 2017-01-03 23:39:43 --> Utf8 Class Initialized
INFO - 2017-01-03 23:39:43 --> URI Class Initialized
DEBUG - 2017-01-03 23:39:43 --> No URI present. Default controller set.
INFO - 2017-01-03 23:39:43 --> Router Class Initialized
INFO - 2017-01-03 23:39:43 --> Output Class Initialized
INFO - 2017-01-03 23:39:43 --> Security Class Initialized
DEBUG - 2017-01-03 23:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-03 23:39:43 --> Input Class Initialized
INFO - 2017-01-03 23:39:43 --> Language Class Initialized
INFO - 2017-01-03 23:39:43 --> Loader Class Initialized
INFO - 2017-01-03 23:39:43 --> Database Driver Class Initialized
INFO - 2017-01-03 23:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-03 23:39:44 --> Controller Class Initialized
INFO - 2017-01-03 23:39:44 --> Helper loaded: url_helper
DEBUG - 2017-01-03 23:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-03 23:39:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-03 23:39:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-03 23:39:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-03 23:39:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-03 23:39:44 --> Final output sent to browser
DEBUG - 2017-01-03 23:39:44 --> Total execution time: 1.5683

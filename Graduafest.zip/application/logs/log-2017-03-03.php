<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-03 00:01:56 --> Config Class Initialized
INFO - 2017-03-03 00:01:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:01:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:01:57 --> Utf8 Class Initialized
INFO - 2017-03-03 00:01:57 --> URI Class Initialized
DEBUG - 2017-03-03 00:01:57 --> No URI present. Default controller set.
INFO - 2017-03-03 00:01:57 --> Router Class Initialized
INFO - 2017-03-03 00:01:57 --> Output Class Initialized
INFO - 2017-03-03 00:01:57 --> Security Class Initialized
DEBUG - 2017-03-03 00:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:01:57 --> Input Class Initialized
INFO - 2017-03-03 00:01:57 --> Language Class Initialized
INFO - 2017-03-03 00:01:57 --> Loader Class Initialized
INFO - 2017-03-03 00:01:57 --> Database Driver Class Initialized
INFO - 2017-03-03 00:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:01:57 --> Controller Class Initialized
INFO - 2017-03-03 00:01:57 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:01:58 --> Final output sent to browser
DEBUG - 2017-03-03 00:01:58 --> Total execution time: 1.4676
INFO - 2017-03-03 00:03:25 --> Config Class Initialized
INFO - 2017-03-03 00:03:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:03:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:03:25 --> Utf8 Class Initialized
INFO - 2017-03-03 00:03:25 --> URI Class Initialized
INFO - 2017-03-03 00:03:25 --> Router Class Initialized
INFO - 2017-03-03 00:03:25 --> Output Class Initialized
INFO - 2017-03-03 00:03:25 --> Security Class Initialized
DEBUG - 2017-03-03 00:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:03:26 --> Input Class Initialized
INFO - 2017-03-03 00:03:26 --> Language Class Initialized
INFO - 2017-03-03 00:03:26 --> Loader Class Initialized
INFO - 2017-03-03 00:03:26 --> Database Driver Class Initialized
INFO - 2017-03-03 00:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:03:26 --> Controller Class Initialized
INFO - 2017-03-03 00:03:26 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:03:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:03:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:03:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:03:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:03:26 --> Final output sent to browser
DEBUG - 2017-03-03 00:03:26 --> Total execution time: 1.1887
INFO - 2017-03-03 00:06:02 --> Config Class Initialized
INFO - 2017-03-03 00:06:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:06:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:06:02 --> Utf8 Class Initialized
INFO - 2017-03-03 00:06:02 --> URI Class Initialized
INFO - 2017-03-03 00:06:02 --> Router Class Initialized
INFO - 2017-03-03 00:06:02 --> Output Class Initialized
INFO - 2017-03-03 00:06:02 --> Security Class Initialized
DEBUG - 2017-03-03 00:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:06:03 --> Input Class Initialized
INFO - 2017-03-03 00:06:03 --> Language Class Initialized
INFO - 2017-03-03 00:06:03 --> Loader Class Initialized
INFO - 2017-03-03 00:06:03 --> Database Driver Class Initialized
INFO - 2017-03-03 00:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:06:03 --> Controller Class Initialized
INFO - 2017-03-03 00:06:03 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:06:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 00:06:06 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 00:06:06 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liiz Moncada')
INFO - 2017-03-03 00:06:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 00:06:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 00:06:07 --> Config Class Initialized
INFO - 2017-03-03 00:06:07 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:06:07 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:06:07 --> Utf8 Class Initialized
INFO - 2017-03-03 00:06:07 --> URI Class Initialized
INFO - 2017-03-03 00:06:07 --> Router Class Initialized
INFO - 2017-03-03 00:06:07 --> Output Class Initialized
INFO - 2017-03-03 00:06:07 --> Security Class Initialized
DEBUG - 2017-03-03 00:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:06:07 --> Input Class Initialized
INFO - 2017-03-03 00:06:07 --> Language Class Initialized
INFO - 2017-03-03 00:06:07 --> Loader Class Initialized
INFO - 2017-03-03 00:06:07 --> Database Driver Class Initialized
INFO - 2017-03-03 00:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:06:07 --> Controller Class Initialized
INFO - 2017-03-03 00:06:07 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:06:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:06:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:06:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:06:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:06:07 --> Final output sent to browser
DEBUG - 2017-03-03 00:06:07 --> Total execution time: 0.1482
INFO - 2017-03-03 00:06:46 --> Config Class Initialized
INFO - 2017-03-03 00:06:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:06:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:06:46 --> Utf8 Class Initialized
INFO - 2017-03-03 00:06:46 --> URI Class Initialized
INFO - 2017-03-03 00:06:46 --> Router Class Initialized
INFO - 2017-03-03 00:06:46 --> Output Class Initialized
INFO - 2017-03-03 00:06:46 --> Security Class Initialized
DEBUG - 2017-03-03 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:06:46 --> Input Class Initialized
INFO - 2017-03-03 00:06:46 --> Language Class Initialized
INFO - 2017-03-03 00:06:46 --> Loader Class Initialized
INFO - 2017-03-03 00:06:46 --> Database Driver Class Initialized
INFO - 2017-03-03 00:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:06:46 --> Controller Class Initialized
INFO - 2017-03-03 00:06:46 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:06:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 00:06:47 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 00:06:47 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liiz Moncada')
INFO - 2017-03-03 00:06:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 00:06:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 00:06:48 --> Config Class Initialized
INFO - 2017-03-03 00:06:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:06:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:06:48 --> Utf8 Class Initialized
INFO - 2017-03-03 00:06:48 --> URI Class Initialized
INFO - 2017-03-03 00:06:48 --> Router Class Initialized
INFO - 2017-03-03 00:06:48 --> Output Class Initialized
INFO - 2017-03-03 00:06:48 --> Security Class Initialized
DEBUG - 2017-03-03 00:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:06:48 --> Input Class Initialized
INFO - 2017-03-03 00:06:48 --> Language Class Initialized
INFO - 2017-03-03 00:06:48 --> Loader Class Initialized
INFO - 2017-03-03 00:06:48 --> Database Driver Class Initialized
INFO - 2017-03-03 00:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:06:48 --> Controller Class Initialized
INFO - 2017-03-03 00:06:48 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:06:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:06:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:06:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:06:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:06:48 --> Final output sent to browser
DEBUG - 2017-03-03 00:06:48 --> Total execution time: 0.0135
INFO - 2017-03-03 00:06:50 --> Config Class Initialized
INFO - 2017-03-03 00:06:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:06:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:06:50 --> Utf8 Class Initialized
INFO - 2017-03-03 00:06:50 --> URI Class Initialized
INFO - 2017-03-03 00:06:50 --> Router Class Initialized
INFO - 2017-03-03 00:06:50 --> Output Class Initialized
INFO - 2017-03-03 00:06:50 --> Security Class Initialized
DEBUG - 2017-03-03 00:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:06:50 --> Input Class Initialized
INFO - 2017-03-03 00:06:50 --> Language Class Initialized
INFO - 2017-03-03 00:06:50 --> Loader Class Initialized
INFO - 2017-03-03 00:06:50 --> Database Driver Class Initialized
INFO - 2017-03-03 00:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:06:50 --> Controller Class Initialized
INFO - 2017-03-03 00:06:50 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:06:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 00:06:51 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 00:06:51 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liiz Moncada')
INFO - 2017-03-03 00:06:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 00:06:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 00:06:51 --> Config Class Initialized
INFO - 2017-03-03 00:06:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:06:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:06:51 --> Utf8 Class Initialized
INFO - 2017-03-03 00:06:51 --> URI Class Initialized
INFO - 2017-03-03 00:06:51 --> Router Class Initialized
INFO - 2017-03-03 00:06:51 --> Output Class Initialized
INFO - 2017-03-03 00:06:51 --> Security Class Initialized
DEBUG - 2017-03-03 00:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:06:51 --> Input Class Initialized
INFO - 2017-03-03 00:06:51 --> Language Class Initialized
INFO - 2017-03-03 00:06:51 --> Loader Class Initialized
INFO - 2017-03-03 00:06:51 --> Database Driver Class Initialized
INFO - 2017-03-03 00:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:06:51 --> Controller Class Initialized
INFO - 2017-03-03 00:06:51 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:06:51 --> Final output sent to browser
DEBUG - 2017-03-03 00:06:51 --> Total execution time: 0.0134
INFO - 2017-03-03 00:07:14 --> Config Class Initialized
INFO - 2017-03-03 00:07:14 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:07:14 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:07:14 --> Utf8 Class Initialized
INFO - 2017-03-03 00:07:14 --> URI Class Initialized
DEBUG - 2017-03-03 00:07:14 --> No URI present. Default controller set.
INFO - 2017-03-03 00:07:14 --> Router Class Initialized
INFO - 2017-03-03 00:07:14 --> Output Class Initialized
INFO - 2017-03-03 00:07:14 --> Security Class Initialized
DEBUG - 2017-03-03 00:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:07:14 --> Input Class Initialized
INFO - 2017-03-03 00:07:14 --> Language Class Initialized
INFO - 2017-03-03 00:07:14 --> Loader Class Initialized
INFO - 2017-03-03 00:07:14 --> Database Driver Class Initialized
INFO - 2017-03-03 00:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:07:14 --> Controller Class Initialized
INFO - 2017-03-03 00:07:14 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:07:14 --> Final output sent to browser
DEBUG - 2017-03-03 00:07:14 --> Total execution time: 0.0131
INFO - 2017-03-03 00:07:17 --> Config Class Initialized
INFO - 2017-03-03 00:07:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:07:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:07:17 --> Utf8 Class Initialized
INFO - 2017-03-03 00:07:17 --> URI Class Initialized
INFO - 2017-03-03 00:07:17 --> Router Class Initialized
INFO - 2017-03-03 00:07:17 --> Output Class Initialized
INFO - 2017-03-03 00:07:17 --> Security Class Initialized
DEBUG - 2017-03-03 00:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:07:17 --> Input Class Initialized
INFO - 2017-03-03 00:07:17 --> Language Class Initialized
INFO - 2017-03-03 00:07:17 --> Loader Class Initialized
INFO - 2017-03-03 00:07:17 --> Database Driver Class Initialized
INFO - 2017-03-03 00:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:07:17 --> Controller Class Initialized
INFO - 2017-03-03 00:07:17 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:07:17 --> Final output sent to browser
DEBUG - 2017-03-03 00:07:17 --> Total execution time: 0.0132
INFO - 2017-03-03 00:07:53 --> Config Class Initialized
INFO - 2017-03-03 00:07:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:07:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:07:53 --> Utf8 Class Initialized
INFO - 2017-03-03 00:07:53 --> URI Class Initialized
INFO - 2017-03-03 00:07:53 --> Router Class Initialized
INFO - 2017-03-03 00:07:53 --> Output Class Initialized
INFO - 2017-03-03 00:07:53 --> Security Class Initialized
DEBUG - 2017-03-03 00:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:07:53 --> Input Class Initialized
INFO - 2017-03-03 00:07:53 --> Language Class Initialized
INFO - 2017-03-03 00:07:53 --> Loader Class Initialized
INFO - 2017-03-03 00:07:53 --> Database Driver Class Initialized
INFO - 2017-03-03 00:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:07:53 --> Controller Class Initialized
INFO - 2017-03-03 00:07:53 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:07:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 00:07:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 00:07:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liiz Moncada')
INFO - 2017-03-03 00:07:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 00:07:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 00:07:55 --> Config Class Initialized
INFO - 2017-03-03 00:07:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:07:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:07:55 --> Utf8 Class Initialized
INFO - 2017-03-03 00:07:55 --> URI Class Initialized
INFO - 2017-03-03 00:07:55 --> Router Class Initialized
INFO - 2017-03-03 00:07:55 --> Output Class Initialized
INFO - 2017-03-03 00:07:55 --> Security Class Initialized
DEBUG - 2017-03-03 00:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:07:55 --> Input Class Initialized
INFO - 2017-03-03 00:07:55 --> Language Class Initialized
INFO - 2017-03-03 00:07:55 --> Loader Class Initialized
INFO - 2017-03-03 00:07:55 --> Database Driver Class Initialized
INFO - 2017-03-03 00:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:07:55 --> Controller Class Initialized
INFO - 2017-03-03 00:07:55 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:07:55 --> Final output sent to browser
DEBUG - 2017-03-03 00:07:55 --> Total execution time: 0.0133
INFO - 2017-03-03 00:08:52 --> Config Class Initialized
INFO - 2017-03-03 00:08:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:08:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:08:52 --> Utf8 Class Initialized
INFO - 2017-03-03 00:08:52 --> URI Class Initialized
INFO - 2017-03-03 00:08:52 --> Router Class Initialized
INFO - 2017-03-03 00:08:52 --> Output Class Initialized
INFO - 2017-03-03 00:08:52 --> Security Class Initialized
DEBUG - 2017-03-03 00:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:08:52 --> Input Class Initialized
INFO - 2017-03-03 00:08:52 --> Language Class Initialized
INFO - 2017-03-03 00:08:52 --> Loader Class Initialized
INFO - 2017-03-03 00:08:52 --> Database Driver Class Initialized
INFO - 2017-03-03 00:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:08:52 --> Controller Class Initialized
INFO - 2017-03-03 00:08:52 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:08:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 00:08:52 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 00:08:52 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Liiz Moncada')
INFO - 2017-03-03 00:08:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 00:08:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 00:08:53 --> Config Class Initialized
INFO - 2017-03-03 00:08:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 00:08:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 00:08:53 --> Utf8 Class Initialized
INFO - 2017-03-03 00:08:53 --> URI Class Initialized
INFO - 2017-03-03 00:08:53 --> Router Class Initialized
INFO - 2017-03-03 00:08:53 --> Output Class Initialized
INFO - 2017-03-03 00:08:53 --> Security Class Initialized
DEBUG - 2017-03-03 00:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 00:08:53 --> Input Class Initialized
INFO - 2017-03-03 00:08:53 --> Language Class Initialized
INFO - 2017-03-03 00:08:53 --> Loader Class Initialized
INFO - 2017-03-03 00:08:53 --> Database Driver Class Initialized
INFO - 2017-03-03 00:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 00:08:53 --> Controller Class Initialized
INFO - 2017-03-03 00:08:53 --> Helper loaded: url_helper
DEBUG - 2017-03-03 00:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 00:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 00:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 00:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 00:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 00:08:53 --> Final output sent to browser
DEBUG - 2017-03-03 00:08:53 --> Total execution time: 0.1670
INFO - 2017-03-03 01:12:11 --> Config Class Initialized
INFO - 2017-03-03 01:12:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 01:12:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 01:12:11 --> Utf8 Class Initialized
INFO - 2017-03-03 01:12:11 --> URI Class Initialized
INFO - 2017-03-03 01:12:11 --> Router Class Initialized
INFO - 2017-03-03 01:12:11 --> Output Class Initialized
INFO - 2017-03-03 01:12:11 --> Security Class Initialized
DEBUG - 2017-03-03 01:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 01:12:11 --> Input Class Initialized
INFO - 2017-03-03 01:12:11 --> Language Class Initialized
INFO - 2017-03-03 01:12:11 --> Loader Class Initialized
INFO - 2017-03-03 01:12:12 --> Database Driver Class Initialized
INFO - 2017-03-03 01:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 01:12:12 --> Controller Class Initialized
INFO - 2017-03-03 01:12:12 --> Helper loaded: url_helper
DEBUG - 2017-03-03 01:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 01:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 01:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 01:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 01:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 01:12:12 --> Final output sent to browser
DEBUG - 2017-03-03 01:12:12 --> Total execution time: 1.2434
INFO - 2017-03-03 01:12:12 --> Config Class Initialized
INFO - 2017-03-03 01:12:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 01:12:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 01:12:12 --> Utf8 Class Initialized
INFO - 2017-03-03 01:12:12 --> URI Class Initialized
DEBUG - 2017-03-03 01:12:13 --> No URI present. Default controller set.
INFO - 2017-03-03 01:12:13 --> Router Class Initialized
INFO - 2017-03-03 01:12:13 --> Output Class Initialized
INFO - 2017-03-03 01:12:13 --> Security Class Initialized
DEBUG - 2017-03-03 01:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 01:12:13 --> Input Class Initialized
INFO - 2017-03-03 01:12:13 --> Language Class Initialized
INFO - 2017-03-03 01:12:13 --> Loader Class Initialized
INFO - 2017-03-03 01:12:13 --> Database Driver Class Initialized
INFO - 2017-03-03 01:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 01:12:13 --> Controller Class Initialized
INFO - 2017-03-03 01:12:13 --> Helper loaded: url_helper
DEBUG - 2017-03-03 01:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 01:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 01:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 01:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 01:12:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 01:12:13 --> Final output sent to browser
DEBUG - 2017-03-03 01:12:13 --> Total execution time: 0.4216
INFO - 2017-03-03 01:13:11 --> Config Class Initialized
INFO - 2017-03-03 01:13:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 01:13:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 01:13:11 --> Utf8 Class Initialized
INFO - 2017-03-03 01:13:11 --> URI Class Initialized
INFO - 2017-03-03 01:13:11 --> Router Class Initialized
INFO - 2017-03-03 01:13:12 --> Output Class Initialized
INFO - 2017-03-03 01:13:12 --> Security Class Initialized
DEBUG - 2017-03-03 01:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 01:13:12 --> Input Class Initialized
INFO - 2017-03-03 01:13:12 --> Language Class Initialized
INFO - 2017-03-03 01:13:12 --> Loader Class Initialized
INFO - 2017-03-03 01:13:12 --> Database Driver Class Initialized
INFO - 2017-03-03 01:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 01:13:12 --> Controller Class Initialized
INFO - 2017-03-03 01:13:12 --> Helper loaded: url_helper
DEBUG - 2017-03-03 01:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 01:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-03 01:13:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-03 01:13:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-03 01:13:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-03 01:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 01:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 01:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 01:13:13 --> Final output sent to browser
DEBUG - 2017-03-03 01:13:13 --> Total execution time: 1.5343
INFO - 2017-03-03 01:15:25 --> Config Class Initialized
INFO - 2017-03-03 01:15:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 01:15:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 01:15:25 --> Utf8 Class Initialized
INFO - 2017-03-03 01:15:25 --> URI Class Initialized
INFO - 2017-03-03 01:15:25 --> Router Class Initialized
INFO - 2017-03-03 01:15:26 --> Output Class Initialized
INFO - 2017-03-03 01:15:26 --> Security Class Initialized
DEBUG - 2017-03-03 01:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 01:15:26 --> Input Class Initialized
INFO - 2017-03-03 01:15:26 --> Language Class Initialized
INFO - 2017-03-03 01:15:26 --> Loader Class Initialized
INFO - 2017-03-03 01:15:26 --> Database Driver Class Initialized
INFO - 2017-03-03 01:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 01:15:26 --> Controller Class Initialized
INFO - 2017-03-03 01:15:26 --> Helper loaded: url_helper
DEBUG - 2017-03-03 01:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 01:15:26 --> Final output sent to browser
DEBUG - 2017-03-03 01:15:26 --> Total execution time: 1.2171
INFO - 2017-03-03 01:15:26 --> Config Class Initialized
INFO - 2017-03-03 01:15:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 01:15:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 01:15:26 --> Utf8 Class Initialized
INFO - 2017-03-03 01:15:26 --> URI Class Initialized
DEBUG - 2017-03-03 01:15:26 --> No URI present. Default controller set.
INFO - 2017-03-03 01:15:26 --> Router Class Initialized
INFO - 2017-03-03 01:15:26 --> Output Class Initialized
INFO - 2017-03-03 01:15:26 --> Security Class Initialized
DEBUG - 2017-03-03 01:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 01:15:26 --> Input Class Initialized
INFO - 2017-03-03 01:15:26 --> Language Class Initialized
INFO - 2017-03-03 01:15:26 --> Loader Class Initialized
INFO - 2017-03-03 01:15:26 --> Database Driver Class Initialized
INFO - 2017-03-03 01:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 01:15:26 --> Controller Class Initialized
INFO - 2017-03-03 01:15:26 --> Helper loaded: url_helper
DEBUG - 2017-03-03 01:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 01:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 01:15:26 --> Final output sent to browser
DEBUG - 2017-03-03 01:15:26 --> Total execution time: 0.1678
INFO - 2017-03-03 02:08:13 --> Config Class Initialized
INFO - 2017-03-03 02:08:13 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:08:13 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:08:13 --> Utf8 Class Initialized
INFO - 2017-03-03 02:08:13 --> URI Class Initialized
DEBUG - 2017-03-03 02:08:14 --> No URI present. Default controller set.
INFO - 2017-03-03 02:08:14 --> Router Class Initialized
INFO - 2017-03-03 02:08:14 --> Output Class Initialized
INFO - 2017-03-03 02:08:14 --> Security Class Initialized
DEBUG - 2017-03-03 02:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:08:14 --> Input Class Initialized
INFO - 2017-03-03 02:08:14 --> Language Class Initialized
INFO - 2017-03-03 02:08:14 --> Loader Class Initialized
INFO - 2017-03-03 02:08:14 --> Database Driver Class Initialized
INFO - 2017-03-03 02:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:08:14 --> Controller Class Initialized
INFO - 2017-03-03 02:08:14 --> Helper loaded: url_helper
DEBUG - 2017-03-03 02:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 02:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 02:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 02:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 02:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 02:08:15 --> Final output sent to browser
DEBUG - 2017-03-03 02:08:15 --> Total execution time: 1.2121
INFO - 2017-03-03 02:08:56 --> Config Class Initialized
INFO - 2017-03-03 02:08:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:08:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:08:56 --> Utf8 Class Initialized
INFO - 2017-03-03 02:08:56 --> URI Class Initialized
DEBUG - 2017-03-03 02:08:56 --> No URI present. Default controller set.
INFO - 2017-03-03 02:08:56 --> Router Class Initialized
INFO - 2017-03-03 02:08:56 --> Output Class Initialized
INFO - 2017-03-03 02:08:56 --> Security Class Initialized
DEBUG - 2017-03-03 02:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:08:56 --> Input Class Initialized
INFO - 2017-03-03 02:08:56 --> Language Class Initialized
INFO - 2017-03-03 02:08:56 --> Loader Class Initialized
INFO - 2017-03-03 02:08:56 --> Database Driver Class Initialized
INFO - 2017-03-03 02:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:08:57 --> Controller Class Initialized
INFO - 2017-03-03 02:08:57 --> Helper loaded: url_helper
DEBUG - 2017-03-03 02:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 02:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 02:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 02:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 02:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 02:08:57 --> Final output sent to browser
DEBUG - 2017-03-03 02:08:57 --> Total execution time: 1.1342
INFO - 2017-03-03 03:15:24 --> Config Class Initialized
INFO - 2017-03-03 03:15:24 --> Hooks Class Initialized
DEBUG - 2017-03-03 03:15:24 --> UTF-8 Support Enabled
INFO - 2017-03-03 03:15:24 --> Utf8 Class Initialized
INFO - 2017-03-03 03:15:24 --> URI Class Initialized
INFO - 2017-03-03 03:15:24 --> Router Class Initialized
INFO - 2017-03-03 03:15:24 --> Output Class Initialized
INFO - 2017-03-03 03:15:24 --> Security Class Initialized
DEBUG - 2017-03-03 03:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 03:15:24 --> Input Class Initialized
INFO - 2017-03-03 03:15:24 --> Language Class Initialized
INFO - 2017-03-03 03:15:24 --> Loader Class Initialized
INFO - 2017-03-03 03:15:25 --> Database Driver Class Initialized
INFO - 2017-03-03 03:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 03:15:25 --> Controller Class Initialized
INFO - 2017-03-03 03:15:25 --> Helper loaded: url_helper
DEBUG - 2017-03-03 03:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 03:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-03 03:15:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-03 03:15:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-03 03:15:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-03 03:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 03:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 03:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 03:15:25 --> Final output sent to browser
DEBUG - 2017-03-03 03:15:25 --> Total execution time: 1.4926
INFO - 2017-03-03 04:13:26 --> Config Class Initialized
INFO - 2017-03-03 04:13:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 04:13:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 04:13:26 --> Utf8 Class Initialized
INFO - 2017-03-03 04:13:26 --> URI Class Initialized
DEBUG - 2017-03-03 04:13:26 --> No URI present. Default controller set.
INFO - 2017-03-03 04:13:26 --> Router Class Initialized
INFO - 2017-03-03 04:13:26 --> Output Class Initialized
INFO - 2017-03-03 04:13:26 --> Security Class Initialized
DEBUG - 2017-03-03 04:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 04:13:26 --> Input Class Initialized
INFO - 2017-03-03 04:13:26 --> Language Class Initialized
INFO - 2017-03-03 04:13:27 --> Loader Class Initialized
INFO - 2017-03-03 04:13:27 --> Database Driver Class Initialized
INFO - 2017-03-03 04:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 04:13:27 --> Controller Class Initialized
INFO - 2017-03-03 04:13:27 --> Helper loaded: url_helper
DEBUG - 2017-03-03 04:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 04:13:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 04:13:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 04:13:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 04:13:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 04:13:27 --> Final output sent to browser
DEBUG - 2017-03-03 04:13:27 --> Total execution time: 1.2020
INFO - 2017-03-03 04:48:18 --> Config Class Initialized
INFO - 2017-03-03 04:48:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 04:48:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 04:48:18 --> Utf8 Class Initialized
INFO - 2017-03-03 04:48:18 --> URI Class Initialized
INFO - 2017-03-03 04:48:18 --> Router Class Initialized
INFO - 2017-03-03 04:48:18 --> Output Class Initialized
INFO - 2017-03-03 04:48:18 --> Security Class Initialized
DEBUG - 2017-03-03 04:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 04:48:18 --> Input Class Initialized
INFO - 2017-03-03 04:48:18 --> Language Class Initialized
INFO - 2017-03-03 04:48:18 --> Loader Class Initialized
INFO - 2017-03-03 04:48:19 --> Database Driver Class Initialized
INFO - 2017-03-03 04:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 04:48:19 --> Controller Class Initialized
INFO - 2017-03-03 04:48:19 --> Helper loaded: url_helper
DEBUG - 2017-03-03 04:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 04:48:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-03 04:48:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-03 04:48:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-03 04:48:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-03 04:48:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 04:48:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 04:48:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 04:48:19 --> Final output sent to browser
DEBUG - 2017-03-03 04:48:19 --> Total execution time: 1.5182
INFO - 2017-03-03 04:48:29 --> Config Class Initialized
INFO - 2017-03-03 04:48:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 04:48:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 04:48:29 --> Utf8 Class Initialized
INFO - 2017-03-03 04:48:29 --> URI Class Initialized
INFO - 2017-03-03 04:48:29 --> Router Class Initialized
INFO - 2017-03-03 04:48:29 --> Output Class Initialized
INFO - 2017-03-03 04:48:29 --> Security Class Initialized
DEBUG - 2017-03-03 04:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 04:48:29 --> Input Class Initialized
INFO - 2017-03-03 04:48:29 --> Language Class Initialized
INFO - 2017-03-03 04:48:29 --> Loader Class Initialized
INFO - 2017-03-03 04:48:29 --> Database Driver Class Initialized
INFO - 2017-03-03 04:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 04:48:29 --> Controller Class Initialized
INFO - 2017-03-03 04:48:29 --> Helper loaded: url_helper
DEBUG - 2017-03-03 04:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 04:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 04:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 04:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 04:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 04:48:29 --> Final output sent to browser
DEBUG - 2017-03-03 04:48:29 --> Total execution time: 0.0133
INFO - 2017-03-03 11:06:59 --> Config Class Initialized
INFO - 2017-03-03 11:06:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:06:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:06:59 --> Utf8 Class Initialized
INFO - 2017-03-03 11:06:59 --> URI Class Initialized
INFO - 2017-03-03 11:06:59 --> Router Class Initialized
INFO - 2017-03-03 11:06:59 --> Output Class Initialized
INFO - 2017-03-03 11:06:59 --> Security Class Initialized
DEBUG - 2017-03-03 11:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:06:59 --> Input Class Initialized
INFO - 2017-03-03 11:06:59 --> Language Class Initialized
INFO - 2017-03-03 11:06:59 --> Loader Class Initialized
INFO - 2017-03-03 11:06:59 --> Database Driver Class Initialized
INFO - 2017-03-03 11:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:07:00 --> Controller Class Initialized
INFO - 2017-03-03 11:07:00 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:07:00 --> Final output sent to browser
DEBUG - 2017-03-03 11:07:00 --> Total execution time: 1.6161
INFO - 2017-03-03 11:07:01 --> Config Class Initialized
INFO - 2017-03-03 11:07:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:07:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:07:01 --> Utf8 Class Initialized
INFO - 2017-03-03 11:07:01 --> URI Class Initialized
DEBUG - 2017-03-03 11:07:01 --> No URI present. Default controller set.
INFO - 2017-03-03 11:07:01 --> Router Class Initialized
INFO - 2017-03-03 11:07:01 --> Output Class Initialized
INFO - 2017-03-03 11:07:01 --> Security Class Initialized
DEBUG - 2017-03-03 11:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:07:01 --> Input Class Initialized
INFO - 2017-03-03 11:07:01 --> Language Class Initialized
INFO - 2017-03-03 11:07:01 --> Loader Class Initialized
INFO - 2017-03-03 11:07:01 --> Database Driver Class Initialized
INFO - 2017-03-03 11:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:07:01 --> Controller Class Initialized
INFO - 2017-03-03 11:07:01 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:07:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:07:02 --> Final output sent to browser
DEBUG - 2017-03-03 11:07:02 --> Total execution time: 1.2918
INFO - 2017-03-03 11:10:19 --> Config Class Initialized
INFO - 2017-03-03 11:10:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:10:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:10:19 --> Utf8 Class Initialized
INFO - 2017-03-03 11:10:19 --> URI Class Initialized
DEBUG - 2017-03-03 11:10:20 --> No URI present. Default controller set.
INFO - 2017-03-03 11:10:20 --> Router Class Initialized
INFO - 2017-03-03 11:10:20 --> Output Class Initialized
INFO - 2017-03-03 11:10:20 --> Security Class Initialized
DEBUG - 2017-03-03 11:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:10:20 --> Input Class Initialized
INFO - 2017-03-03 11:10:20 --> Language Class Initialized
INFO - 2017-03-03 11:10:20 --> Loader Class Initialized
INFO - 2017-03-03 11:10:20 --> Database Driver Class Initialized
INFO - 2017-03-03 11:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:10:21 --> Controller Class Initialized
INFO - 2017-03-03 11:10:21 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:10:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:10:21 --> Final output sent to browser
DEBUG - 2017-03-03 11:10:21 --> Total execution time: 1.7084
INFO - 2017-03-03 11:10:26 --> Config Class Initialized
INFO - 2017-03-03 11:10:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:10:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:10:26 --> Utf8 Class Initialized
INFO - 2017-03-03 11:10:26 --> URI Class Initialized
INFO - 2017-03-03 11:10:26 --> Router Class Initialized
INFO - 2017-03-03 11:10:26 --> Output Class Initialized
INFO - 2017-03-03 11:10:26 --> Security Class Initialized
DEBUG - 2017-03-03 11:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:10:26 --> Input Class Initialized
INFO - 2017-03-03 11:10:26 --> Language Class Initialized
INFO - 2017-03-03 11:10:26 --> Loader Class Initialized
INFO - 2017-03-03 11:10:27 --> Database Driver Class Initialized
INFO - 2017-03-03 11:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:10:27 --> Controller Class Initialized
INFO - 2017-03-03 11:10:27 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:10:27 --> Final output sent to browser
DEBUG - 2017-03-03 11:10:27 --> Total execution time: 1.2556
INFO - 2017-03-03 11:11:58 --> Config Class Initialized
INFO - 2017-03-03 11:11:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:11:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:11:58 --> Utf8 Class Initialized
INFO - 2017-03-03 11:11:58 --> URI Class Initialized
INFO - 2017-03-03 11:11:58 --> Router Class Initialized
INFO - 2017-03-03 11:11:58 --> Output Class Initialized
INFO - 2017-03-03 11:11:58 --> Security Class Initialized
DEBUG - 2017-03-03 11:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:11:58 --> Input Class Initialized
INFO - 2017-03-03 11:11:58 --> Language Class Initialized
INFO - 2017-03-03 11:11:58 --> Loader Class Initialized
INFO - 2017-03-03 11:11:58 --> Database Driver Class Initialized
INFO - 2017-03-03 11:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:11:59 --> Controller Class Initialized
INFO - 2017-03-03 11:11:59 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:12:00 --> Final output sent to browser
DEBUG - 2017-03-03 11:12:00 --> Total execution time: 1.7260
INFO - 2017-03-03 11:12:02 --> Config Class Initialized
INFO - 2017-03-03 11:12:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:12:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:12:02 --> Utf8 Class Initialized
INFO - 2017-03-03 11:12:02 --> URI Class Initialized
INFO - 2017-03-03 11:12:02 --> Router Class Initialized
INFO - 2017-03-03 11:12:02 --> Output Class Initialized
INFO - 2017-03-03 11:12:02 --> Security Class Initialized
DEBUG - 2017-03-03 11:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:12:02 --> Input Class Initialized
INFO - 2017-03-03 11:12:02 --> Language Class Initialized
INFO - 2017-03-03 11:12:02 --> Loader Class Initialized
INFO - 2017-03-03 11:12:03 --> Database Driver Class Initialized
INFO - 2017-03-03 11:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:12:03 --> Controller Class Initialized
INFO - 2017-03-03 11:12:03 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:12:03 --> Final output sent to browser
DEBUG - 2017-03-03 11:12:03 --> Total execution time: 1.2769
INFO - 2017-03-03 11:12:30 --> Config Class Initialized
INFO - 2017-03-03 11:12:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:12:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:12:30 --> Utf8 Class Initialized
INFO - 2017-03-03 11:12:30 --> URI Class Initialized
INFO - 2017-03-03 11:12:31 --> Router Class Initialized
INFO - 2017-03-03 11:12:31 --> Output Class Initialized
INFO - 2017-03-03 11:12:31 --> Security Class Initialized
DEBUG - 2017-03-03 11:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:12:31 --> Input Class Initialized
INFO - 2017-03-03 11:12:31 --> Language Class Initialized
INFO - 2017-03-03 11:12:31 --> Loader Class Initialized
INFO - 2017-03-03 11:12:31 --> Database Driver Class Initialized
INFO - 2017-03-03 11:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:12:31 --> Controller Class Initialized
INFO - 2017-03-03 11:12:31 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:12:32 --> Final output sent to browser
DEBUG - 2017-03-03 11:12:32 --> Total execution time: 1.5299
INFO - 2017-03-03 11:12:34 --> Config Class Initialized
INFO - 2017-03-03 11:12:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:12:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:12:34 --> Utf8 Class Initialized
INFO - 2017-03-03 11:12:34 --> URI Class Initialized
INFO - 2017-03-03 11:12:34 --> Router Class Initialized
INFO - 2017-03-03 11:12:34 --> Output Class Initialized
INFO - 2017-03-03 11:12:34 --> Security Class Initialized
DEBUG - 2017-03-03 11:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:12:34 --> Input Class Initialized
INFO - 2017-03-03 11:12:34 --> Language Class Initialized
INFO - 2017-03-03 11:12:34 --> Loader Class Initialized
INFO - 2017-03-03 11:12:34 --> Database Driver Class Initialized
INFO - 2017-03-03 11:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:12:34 --> Controller Class Initialized
INFO - 2017-03-03 11:12:34 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:12:35 --> Final output sent to browser
DEBUG - 2017-03-03 11:12:35 --> Total execution time: 0.3538
INFO - 2017-03-03 11:13:00 --> Config Class Initialized
INFO - 2017-03-03 11:13:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:13:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:13:00 --> Utf8 Class Initialized
INFO - 2017-03-03 11:13:00 --> URI Class Initialized
INFO - 2017-03-03 11:13:00 --> Router Class Initialized
INFO - 2017-03-03 11:13:00 --> Output Class Initialized
INFO - 2017-03-03 11:13:00 --> Security Class Initialized
DEBUG - 2017-03-03 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:13:00 --> Input Class Initialized
INFO - 2017-03-03 11:13:00 --> Language Class Initialized
INFO - 2017-03-03 11:13:00 --> Loader Class Initialized
INFO - 2017-03-03 11:13:01 --> Database Driver Class Initialized
INFO - 2017-03-03 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:13:01 --> Controller Class Initialized
INFO - 2017-03-03 11:13:01 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:13:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:13:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:13:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:13:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:13:02 --> Final output sent to browser
DEBUG - 2017-03-03 11:13:02 --> Total execution time: 1.7665
INFO - 2017-03-03 11:13:04 --> Config Class Initialized
INFO - 2017-03-03 11:13:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:13:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:13:04 --> Utf8 Class Initialized
INFO - 2017-03-03 11:13:04 --> URI Class Initialized
INFO - 2017-03-03 11:13:04 --> Router Class Initialized
INFO - 2017-03-03 11:13:04 --> Output Class Initialized
INFO - 2017-03-03 11:13:04 --> Security Class Initialized
DEBUG - 2017-03-03 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:13:04 --> Input Class Initialized
INFO - 2017-03-03 11:13:04 --> Language Class Initialized
INFO - 2017-03-03 11:13:04 --> Loader Class Initialized
INFO - 2017-03-03 11:13:04 --> Database Driver Class Initialized
INFO - 2017-03-03 11:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:13:04 --> Controller Class Initialized
INFO - 2017-03-03 11:13:04 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:13:05 --> Final output sent to browser
DEBUG - 2017-03-03 11:13:05 --> Total execution time: 1.2154
INFO - 2017-03-03 11:13:26 --> Config Class Initialized
INFO - 2017-03-03 11:13:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:13:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:13:26 --> Utf8 Class Initialized
INFO - 2017-03-03 11:13:26 --> URI Class Initialized
INFO - 2017-03-03 11:13:26 --> Router Class Initialized
INFO - 2017-03-03 11:13:26 --> Output Class Initialized
INFO - 2017-03-03 11:13:26 --> Security Class Initialized
DEBUG - 2017-03-03 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:13:26 --> Input Class Initialized
INFO - 2017-03-03 11:13:26 --> Language Class Initialized
INFO - 2017-03-03 11:13:26 --> Loader Class Initialized
INFO - 2017-03-03 11:13:27 --> Database Driver Class Initialized
INFO - 2017-03-03 11:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:13:27 --> Controller Class Initialized
INFO - 2017-03-03 11:13:27 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:13:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:13:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:13:28 --> Final output sent to browser
DEBUG - 2017-03-03 11:13:28 --> Total execution time: 1.5177
INFO - 2017-03-03 11:13:29 --> Config Class Initialized
INFO - 2017-03-03 11:13:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:13:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:13:29 --> Utf8 Class Initialized
INFO - 2017-03-03 11:13:29 --> URI Class Initialized
INFO - 2017-03-03 11:13:30 --> Router Class Initialized
INFO - 2017-03-03 11:13:30 --> Output Class Initialized
INFO - 2017-03-03 11:13:30 --> Security Class Initialized
DEBUG - 2017-03-03 11:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:13:30 --> Input Class Initialized
INFO - 2017-03-03 11:13:30 --> Language Class Initialized
INFO - 2017-03-03 11:13:30 --> Loader Class Initialized
INFO - 2017-03-03 11:13:30 --> Database Driver Class Initialized
INFO - 2017-03-03 11:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:13:30 --> Controller Class Initialized
INFO - 2017-03-03 11:13:30 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:13:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:13:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:13:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:13:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:13:30 --> Final output sent to browser
DEBUG - 2017-03-03 11:13:30 --> Total execution time: 0.4243
INFO - 2017-03-03 11:13:39 --> Config Class Initialized
INFO - 2017-03-03 11:13:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:13:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:13:39 --> Utf8 Class Initialized
INFO - 2017-03-03 11:13:39 --> URI Class Initialized
INFO - 2017-03-03 11:13:39 --> Router Class Initialized
INFO - 2017-03-03 11:13:39 --> Output Class Initialized
INFO - 2017-03-03 11:13:39 --> Security Class Initialized
DEBUG - 2017-03-03 11:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:13:39 --> Input Class Initialized
INFO - 2017-03-03 11:13:39 --> Language Class Initialized
INFO - 2017-03-03 11:13:39 --> Loader Class Initialized
INFO - 2017-03-03 11:13:39 --> Database Driver Class Initialized
INFO - 2017-03-03 11:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:13:39 --> Controller Class Initialized
INFO - 2017-03-03 11:13:39 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:13:43 --> Config Class Initialized
INFO - 2017-03-03 11:13:43 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:13:43 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:13:43 --> Utf8 Class Initialized
INFO - 2017-03-03 11:13:43 --> URI Class Initialized
INFO - 2017-03-03 11:13:43 --> Router Class Initialized
INFO - 2017-03-03 11:13:43 --> Output Class Initialized
INFO - 2017-03-03 11:13:43 --> Security Class Initialized
DEBUG - 2017-03-03 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:13:43 --> Input Class Initialized
INFO - 2017-03-03 11:13:43 --> Language Class Initialized
INFO - 2017-03-03 11:13:43 --> Loader Class Initialized
INFO - 2017-03-03 11:13:43 --> Database Driver Class Initialized
INFO - 2017-03-03 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:13:43 --> Controller Class Initialized
INFO - 2017-03-03 11:13:43 --> Helper loaded: date_helper
DEBUG - 2017-03-03 11:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:13:44 --> Helper loaded: url_helper
INFO - 2017-03-03 11:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 11:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 11:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 11:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:13:44 --> Final output sent to browser
DEBUG - 2017-03-03 11:13:44 --> Total execution time: 1.0127
INFO - 2017-03-03 11:13:45 --> Config Class Initialized
INFO - 2017-03-03 11:13:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:13:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:13:45 --> Utf8 Class Initialized
INFO - 2017-03-03 11:13:45 --> URI Class Initialized
INFO - 2017-03-03 11:13:45 --> Router Class Initialized
INFO - 2017-03-03 11:13:45 --> Output Class Initialized
INFO - 2017-03-03 11:13:45 --> Security Class Initialized
DEBUG - 2017-03-03 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:13:45 --> Input Class Initialized
INFO - 2017-03-03 11:13:45 --> Language Class Initialized
INFO - 2017-03-03 11:13:45 --> Loader Class Initialized
INFO - 2017-03-03 11:13:45 --> Database Driver Class Initialized
INFO - 2017-03-03 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:13:45 --> Controller Class Initialized
INFO - 2017-03-03 11:13:45 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:13:45 --> Final output sent to browser
DEBUG - 2017-03-03 11:13:45 --> Total execution time: 0.2494
INFO - 2017-03-03 11:14:00 --> Config Class Initialized
INFO - 2017-03-03 11:14:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:14:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:14:00 --> Utf8 Class Initialized
INFO - 2017-03-03 11:14:00 --> URI Class Initialized
DEBUG - 2017-03-03 11:14:00 --> No URI present. Default controller set.
INFO - 2017-03-03 11:14:00 --> Router Class Initialized
INFO - 2017-03-03 11:14:00 --> Output Class Initialized
INFO - 2017-03-03 11:14:00 --> Security Class Initialized
DEBUG - 2017-03-03 11:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:14:00 --> Input Class Initialized
INFO - 2017-03-03 11:14:00 --> Language Class Initialized
INFO - 2017-03-03 11:14:00 --> Loader Class Initialized
INFO - 2017-03-03 11:14:00 --> Database Driver Class Initialized
INFO - 2017-03-03 11:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:14:01 --> Controller Class Initialized
INFO - 2017-03-03 11:14:01 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:14:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:14:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:14:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:14:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:14:01 --> Final output sent to browser
DEBUG - 2017-03-03 11:14:01 --> Total execution time: 1.5068
INFO - 2017-03-03 11:14:03 --> Config Class Initialized
INFO - 2017-03-03 11:14:03 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:14:03 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:14:03 --> Utf8 Class Initialized
INFO - 2017-03-03 11:14:03 --> URI Class Initialized
INFO - 2017-03-03 11:14:03 --> Router Class Initialized
INFO - 2017-03-03 11:14:03 --> Output Class Initialized
INFO - 2017-03-03 11:14:03 --> Security Class Initialized
DEBUG - 2017-03-03 11:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:14:03 --> Input Class Initialized
INFO - 2017-03-03 11:14:03 --> Language Class Initialized
INFO - 2017-03-03 11:14:03 --> Loader Class Initialized
INFO - 2017-03-03 11:14:04 --> Database Driver Class Initialized
INFO - 2017-03-03 11:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:14:04 --> Controller Class Initialized
INFO - 2017-03-03 11:14:04 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:14:04 --> Final output sent to browser
DEBUG - 2017-03-03 11:14:04 --> Total execution time: 1.2108
INFO - 2017-03-03 11:14:41 --> Config Class Initialized
INFO - 2017-03-03 11:14:41 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:14:41 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:14:41 --> Utf8 Class Initialized
INFO - 2017-03-03 11:14:41 --> URI Class Initialized
INFO - 2017-03-03 11:14:41 --> Router Class Initialized
INFO - 2017-03-03 11:14:41 --> Output Class Initialized
INFO - 2017-03-03 11:14:41 --> Security Class Initialized
DEBUG - 2017-03-03 11:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:14:41 --> Input Class Initialized
INFO - 2017-03-03 11:14:41 --> Language Class Initialized
INFO - 2017-03-03 11:14:42 --> Loader Class Initialized
INFO - 2017-03-03 11:14:42 --> Database Driver Class Initialized
INFO - 2017-03-03 11:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:14:42 --> Controller Class Initialized
INFO - 2017-03-03 11:14:42 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:14:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:14:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:14:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:14:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:14:43 --> Final output sent to browser
DEBUG - 2017-03-03 11:14:43 --> Total execution time: 1.5188
INFO - 2017-03-03 11:14:45 --> Config Class Initialized
INFO - 2017-03-03 11:14:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:14:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:14:45 --> Utf8 Class Initialized
INFO - 2017-03-03 11:14:45 --> URI Class Initialized
INFO - 2017-03-03 11:14:45 --> Router Class Initialized
INFO - 2017-03-03 11:14:45 --> Output Class Initialized
INFO - 2017-03-03 11:14:45 --> Security Class Initialized
DEBUG - 2017-03-03 11:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:14:45 --> Input Class Initialized
INFO - 2017-03-03 11:14:45 --> Language Class Initialized
INFO - 2017-03-03 11:14:45 --> Loader Class Initialized
INFO - 2017-03-03 11:14:46 --> Database Driver Class Initialized
INFO - 2017-03-03 11:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:14:46 --> Controller Class Initialized
INFO - 2017-03-03 11:14:46 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:14:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:14:46 --> Final output sent to browser
DEBUG - 2017-03-03 11:14:46 --> Total execution time: 0.6890
INFO - 2017-03-03 11:15:06 --> Config Class Initialized
INFO - 2017-03-03 11:15:06 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:15:06 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:15:06 --> Utf8 Class Initialized
INFO - 2017-03-03 11:15:06 --> URI Class Initialized
INFO - 2017-03-03 11:15:06 --> Router Class Initialized
INFO - 2017-03-03 11:15:07 --> Output Class Initialized
INFO - 2017-03-03 11:15:07 --> Security Class Initialized
DEBUG - 2017-03-03 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:15:07 --> Input Class Initialized
INFO - 2017-03-03 11:15:07 --> Language Class Initialized
INFO - 2017-03-03 11:15:07 --> Loader Class Initialized
INFO - 2017-03-03 11:15:07 --> Database Driver Class Initialized
INFO - 2017-03-03 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:15:07 --> Controller Class Initialized
INFO - 2017-03-03 11:15:07 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:15:08 --> Final output sent to browser
DEBUG - 2017-03-03 11:15:08 --> Total execution time: 1.2733
INFO - 2017-03-03 11:15:09 --> Config Class Initialized
INFO - 2017-03-03 11:15:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:15:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:15:09 --> Utf8 Class Initialized
INFO - 2017-03-03 11:15:09 --> URI Class Initialized
INFO - 2017-03-03 11:15:09 --> Router Class Initialized
INFO - 2017-03-03 11:15:09 --> Output Class Initialized
INFO - 2017-03-03 11:15:09 --> Security Class Initialized
DEBUG - 2017-03-03 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:15:09 --> Input Class Initialized
INFO - 2017-03-03 11:15:09 --> Language Class Initialized
INFO - 2017-03-03 11:15:09 --> Loader Class Initialized
INFO - 2017-03-03 11:15:09 --> Database Driver Class Initialized
INFO - 2017-03-03 11:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:15:10 --> Controller Class Initialized
INFO - 2017-03-03 11:15:10 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:15:10 --> Final output sent to browser
DEBUG - 2017-03-03 11:15:10 --> Total execution time: 0.2771
INFO - 2017-03-03 11:15:45 --> Config Class Initialized
INFO - 2017-03-03 11:15:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:15:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:15:45 --> Utf8 Class Initialized
INFO - 2017-03-03 11:15:45 --> URI Class Initialized
INFO - 2017-03-03 11:15:46 --> Router Class Initialized
INFO - 2017-03-03 11:15:46 --> Output Class Initialized
INFO - 2017-03-03 11:15:46 --> Security Class Initialized
DEBUG - 2017-03-03 11:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:15:46 --> Input Class Initialized
INFO - 2017-03-03 11:15:46 --> Language Class Initialized
INFO - 2017-03-03 11:15:46 --> Loader Class Initialized
INFO - 2017-03-03 11:15:46 --> Database Driver Class Initialized
INFO - 2017-03-03 11:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:15:46 --> Controller Class Initialized
INFO - 2017-03-03 11:15:46 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:15:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:15:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:15:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:15:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:15:47 --> Final output sent to browser
DEBUG - 2017-03-03 11:15:47 --> Total execution time: 1.4838
INFO - 2017-03-03 11:15:49 --> Config Class Initialized
INFO - 2017-03-03 11:15:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:15:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:15:49 --> Utf8 Class Initialized
INFO - 2017-03-03 11:15:49 --> URI Class Initialized
INFO - 2017-03-03 11:15:49 --> Router Class Initialized
INFO - 2017-03-03 11:15:49 --> Output Class Initialized
INFO - 2017-03-03 11:15:49 --> Security Class Initialized
DEBUG - 2017-03-03 11:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:15:49 --> Input Class Initialized
INFO - 2017-03-03 11:15:49 --> Language Class Initialized
INFO - 2017-03-03 11:15:49 --> Loader Class Initialized
INFO - 2017-03-03 11:15:50 --> Database Driver Class Initialized
INFO - 2017-03-03 11:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:15:50 --> Controller Class Initialized
INFO - 2017-03-03 11:15:50 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:15:50 --> Final output sent to browser
DEBUG - 2017-03-03 11:15:50 --> Total execution time: 0.9238
INFO - 2017-03-03 11:16:08 --> Config Class Initialized
INFO - 2017-03-03 11:16:08 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:16:08 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:16:08 --> Utf8 Class Initialized
INFO - 2017-03-03 11:16:08 --> URI Class Initialized
DEBUG - 2017-03-03 11:16:08 --> No URI present. Default controller set.
INFO - 2017-03-03 11:16:08 --> Router Class Initialized
INFO - 2017-03-03 11:16:08 --> Output Class Initialized
INFO - 2017-03-03 11:16:08 --> Security Class Initialized
DEBUG - 2017-03-03 11:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:16:09 --> Input Class Initialized
INFO - 2017-03-03 11:16:09 --> Language Class Initialized
INFO - 2017-03-03 11:16:09 --> Loader Class Initialized
INFO - 2017-03-03 11:16:09 --> Database Driver Class Initialized
INFO - 2017-03-03 11:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:16:09 --> Controller Class Initialized
INFO - 2017-03-03 11:16:09 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:16:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:16:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:16:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:16:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:16:09 --> Final output sent to browser
DEBUG - 2017-03-03 11:16:09 --> Total execution time: 1.2678
INFO - 2017-03-03 11:16:13 --> Config Class Initialized
INFO - 2017-03-03 11:16:13 --> Hooks Class Initialized
DEBUG - 2017-03-03 11:16:13 --> UTF-8 Support Enabled
INFO - 2017-03-03 11:16:13 --> Utf8 Class Initialized
INFO - 2017-03-03 11:16:13 --> URI Class Initialized
INFO - 2017-03-03 11:16:13 --> Router Class Initialized
INFO - 2017-03-03 11:16:13 --> Output Class Initialized
INFO - 2017-03-03 11:16:13 --> Security Class Initialized
DEBUG - 2017-03-03 11:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 11:16:13 --> Input Class Initialized
INFO - 2017-03-03 11:16:13 --> Language Class Initialized
INFO - 2017-03-03 11:16:13 --> Loader Class Initialized
INFO - 2017-03-03 11:16:13 --> Database Driver Class Initialized
INFO - 2017-03-03 11:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 11:16:13 --> Controller Class Initialized
INFO - 2017-03-03 11:16:13 --> Helper loaded: url_helper
DEBUG - 2017-03-03 11:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 11:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 11:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 11:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 11:16:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 11:16:13 --> Final output sent to browser
DEBUG - 2017-03-03 11:16:13 --> Total execution time: 0.4723
INFO - 2017-03-03 16:23:04 --> Config Class Initialized
INFO - 2017-03-03 16:23:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:23:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:23:04 --> Utf8 Class Initialized
INFO - 2017-03-03 16:23:04 --> URI Class Initialized
DEBUG - 2017-03-03 16:23:04 --> No URI present. Default controller set.
INFO - 2017-03-03 16:23:04 --> Router Class Initialized
INFO - 2017-03-03 16:23:04 --> Output Class Initialized
INFO - 2017-03-03 16:23:04 --> Security Class Initialized
DEBUG - 2017-03-03 16:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:23:05 --> Input Class Initialized
INFO - 2017-03-03 16:23:05 --> Language Class Initialized
INFO - 2017-03-03 16:23:05 --> Loader Class Initialized
INFO - 2017-03-03 16:23:05 --> Database Driver Class Initialized
INFO - 2017-03-03 16:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:23:05 --> Controller Class Initialized
INFO - 2017-03-03 16:23:05 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 16:23:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 16:23:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:23:06 --> Final output sent to browser
DEBUG - 2017-03-03 16:23:06 --> Total execution time: 1.7485
INFO - 2017-03-03 16:23:09 --> Config Class Initialized
INFO - 2017-03-03 16:23:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:23:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:23:09 --> Utf8 Class Initialized
INFO - 2017-03-03 16:23:09 --> URI Class Initialized
INFO - 2017-03-03 16:23:09 --> Router Class Initialized
INFO - 2017-03-03 16:23:09 --> Output Class Initialized
INFO - 2017-03-03 16:23:09 --> Security Class Initialized
DEBUG - 2017-03-03 16:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:23:09 --> Input Class Initialized
INFO - 2017-03-03 16:23:09 --> Language Class Initialized
INFO - 2017-03-03 16:23:09 --> Loader Class Initialized
INFO - 2017-03-03 16:23:09 --> Database Driver Class Initialized
INFO - 2017-03-03 16:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:23:09 --> Controller Class Initialized
INFO - 2017-03-03 16:23:09 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:23:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:23:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 16:23:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 16:23:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:23:10 --> Final output sent to browser
DEBUG - 2017-03-03 16:23:10 --> Total execution time: 1.2202
INFO - 2017-03-03 16:23:15 --> Config Class Initialized
INFO - 2017-03-03 16:23:15 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:23:15 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:23:15 --> Utf8 Class Initialized
INFO - 2017-03-03 16:23:15 --> URI Class Initialized
INFO - 2017-03-03 16:23:15 --> Router Class Initialized
INFO - 2017-03-03 16:23:15 --> Output Class Initialized
INFO - 2017-03-03 16:23:15 --> Security Class Initialized
DEBUG - 2017-03-03 16:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:23:15 --> Input Class Initialized
INFO - 2017-03-03 16:23:15 --> Language Class Initialized
INFO - 2017-03-03 16:23:15 --> Loader Class Initialized
INFO - 2017-03-03 16:23:16 --> Database Driver Class Initialized
INFO - 2017-03-03 16:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:23:16 --> Controller Class Initialized
INFO - 2017-03-03 16:23:16 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:23:16 --> Config Class Initialized
INFO - 2017-03-03 16:23:16 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:23:16 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:23:16 --> Utf8 Class Initialized
INFO - 2017-03-03 16:23:16 --> URI Class Initialized
INFO - 2017-03-03 16:23:16 --> Router Class Initialized
INFO - 2017-03-03 16:23:16 --> Output Class Initialized
INFO - 2017-03-03 16:23:16 --> Security Class Initialized
DEBUG - 2017-03-03 16:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:23:16 --> Input Class Initialized
INFO - 2017-03-03 16:23:16 --> Language Class Initialized
INFO - 2017-03-03 16:23:16 --> Loader Class Initialized
INFO - 2017-03-03 16:23:16 --> Database Driver Class Initialized
INFO - 2017-03-03 16:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:23:16 --> Controller Class Initialized
INFO - 2017-03-03 16:23:17 --> Helper loaded: date_helper
DEBUG - 2017-03-03 16:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:23:17 --> Helper loaded: url_helper
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:23:17 --> Final output sent to browser
DEBUG - 2017-03-03 16:23:17 --> Total execution time: 0.9969
INFO - 2017-03-03 16:23:17 --> Config Class Initialized
INFO - 2017-03-03 16:23:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:23:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:23:17 --> Utf8 Class Initialized
INFO - 2017-03-03 16:23:17 --> URI Class Initialized
INFO - 2017-03-03 16:23:17 --> Router Class Initialized
INFO - 2017-03-03 16:23:17 --> Output Class Initialized
INFO - 2017-03-03 16:23:17 --> Security Class Initialized
DEBUG - 2017-03-03 16:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:23:17 --> Input Class Initialized
INFO - 2017-03-03 16:23:17 --> Language Class Initialized
INFO - 2017-03-03 16:23:17 --> Loader Class Initialized
INFO - 2017-03-03 16:23:17 --> Database Driver Class Initialized
INFO - 2017-03-03 16:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:23:17 --> Controller Class Initialized
INFO - 2017-03-03 16:23:17 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 16:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:23:17 --> Final output sent to browser
DEBUG - 2017-03-03 16:23:17 --> Total execution time: 0.0214
INFO - 2017-03-03 16:28:08 --> Config Class Initialized
INFO - 2017-03-03 16:28:08 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:28:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:28:09 --> Utf8 Class Initialized
INFO - 2017-03-03 16:28:09 --> URI Class Initialized
DEBUG - 2017-03-03 16:28:09 --> No URI present. Default controller set.
INFO - 2017-03-03 16:28:09 --> Router Class Initialized
INFO - 2017-03-03 16:28:09 --> Output Class Initialized
INFO - 2017-03-03 16:28:09 --> Security Class Initialized
DEBUG - 2017-03-03 16:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:28:09 --> Input Class Initialized
INFO - 2017-03-03 16:28:09 --> Language Class Initialized
INFO - 2017-03-03 16:28:09 --> Loader Class Initialized
INFO - 2017-03-03 16:28:09 --> Database Driver Class Initialized
INFO - 2017-03-03 16:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:28:10 --> Controller Class Initialized
INFO - 2017-03-03 16:28:10 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 16:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 16:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:28:10 --> Final output sent to browser
DEBUG - 2017-03-03 16:28:10 --> Total execution time: 2.0125
INFO - 2017-03-03 16:36:48 --> Config Class Initialized
INFO - 2017-03-03 16:36:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:36:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:36:48 --> Utf8 Class Initialized
INFO - 2017-03-03 16:36:48 --> URI Class Initialized
DEBUG - 2017-03-03 16:36:49 --> No URI present. Default controller set.
INFO - 2017-03-03 16:36:49 --> Router Class Initialized
INFO - 2017-03-03 16:36:49 --> Output Class Initialized
INFO - 2017-03-03 16:36:49 --> Security Class Initialized
DEBUG - 2017-03-03 16:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:36:49 --> Input Class Initialized
INFO - 2017-03-03 16:36:49 --> Language Class Initialized
INFO - 2017-03-03 16:36:49 --> Loader Class Initialized
INFO - 2017-03-03 16:36:49 --> Database Driver Class Initialized
INFO - 2017-03-03 16:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:36:50 --> Controller Class Initialized
INFO - 2017-03-03 16:36:50 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 16:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 16:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:36:50 --> Final output sent to browser
DEBUG - 2017-03-03 16:36:50 --> Total execution time: 2.3824
INFO - 2017-03-03 16:36:57 --> Config Class Initialized
INFO - 2017-03-03 16:36:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:36:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:36:57 --> Utf8 Class Initialized
INFO - 2017-03-03 16:36:57 --> URI Class Initialized
INFO - 2017-03-03 16:36:57 --> Router Class Initialized
INFO - 2017-03-03 16:36:57 --> Output Class Initialized
INFO - 2017-03-03 16:36:57 --> Security Class Initialized
DEBUG - 2017-03-03 16:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:36:57 --> Input Class Initialized
INFO - 2017-03-03 16:36:57 --> Language Class Initialized
INFO - 2017-03-03 16:36:57 --> Loader Class Initialized
INFO - 2017-03-03 16:36:57 --> Database Driver Class Initialized
INFO - 2017-03-03 16:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:36:57 --> Controller Class Initialized
INFO - 2017-03-03 16:36:57 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:36:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:36:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 16:36:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 16:36:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:36:57 --> Final output sent to browser
DEBUG - 2017-03-03 16:36:57 --> Total execution time: 0.0141
INFO - 2017-03-03 16:37:38 --> Config Class Initialized
INFO - 2017-03-03 16:37:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:37:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:37:38 --> Utf8 Class Initialized
INFO - 2017-03-03 16:37:38 --> URI Class Initialized
INFO - 2017-03-03 16:37:38 --> Router Class Initialized
INFO - 2017-03-03 16:37:38 --> Output Class Initialized
INFO - 2017-03-03 16:37:38 --> Security Class Initialized
DEBUG - 2017-03-03 16:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:37:38 --> Input Class Initialized
INFO - 2017-03-03 16:37:38 --> Language Class Initialized
INFO - 2017-03-03 16:37:38 --> Loader Class Initialized
INFO - 2017-03-03 16:37:38 --> Database Driver Class Initialized
INFO - 2017-03-03 16:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:37:38 --> Controller Class Initialized
INFO - 2017-03-03 16:37:38 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:37:39 --> Config Class Initialized
INFO - 2017-03-03 16:37:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:37:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:37:39 --> Utf8 Class Initialized
INFO - 2017-03-03 16:37:39 --> URI Class Initialized
INFO - 2017-03-03 16:37:39 --> Router Class Initialized
INFO - 2017-03-03 16:37:39 --> Output Class Initialized
INFO - 2017-03-03 16:37:39 --> Security Class Initialized
DEBUG - 2017-03-03 16:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:37:39 --> Input Class Initialized
INFO - 2017-03-03 16:37:39 --> Language Class Initialized
INFO - 2017-03-03 16:37:39 --> Loader Class Initialized
INFO - 2017-03-03 16:37:39 --> Database Driver Class Initialized
INFO - 2017-03-03 16:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:37:39 --> Controller Class Initialized
INFO - 2017-03-03 16:37:39 --> Helper loaded: date_helper
DEBUG - 2017-03-03 16:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:37:39 --> Helper loaded: url_helper
INFO - 2017-03-03 16:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 16:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 16:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 16:37:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:37:39 --> Final output sent to browser
DEBUG - 2017-03-03 16:37:39 --> Total execution time: 0.1048
INFO - 2017-03-03 16:37:40 --> Config Class Initialized
INFO - 2017-03-03 16:37:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:37:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:37:40 --> Utf8 Class Initialized
INFO - 2017-03-03 16:37:40 --> URI Class Initialized
INFO - 2017-03-03 16:37:40 --> Router Class Initialized
INFO - 2017-03-03 16:37:40 --> Output Class Initialized
INFO - 2017-03-03 16:37:40 --> Security Class Initialized
DEBUG - 2017-03-03 16:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:37:40 --> Input Class Initialized
INFO - 2017-03-03 16:37:40 --> Language Class Initialized
INFO - 2017-03-03 16:37:40 --> Loader Class Initialized
INFO - 2017-03-03 16:37:40 --> Database Driver Class Initialized
INFO - 2017-03-03 16:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:37:40 --> Controller Class Initialized
INFO - 2017-03-03 16:37:40 --> Helper loaded: url_helper
DEBUG - 2017-03-03 16:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 16:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 16:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 16:37:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 16:37:40 --> Final output sent to browser
DEBUG - 2017-03-03 16:37:40 --> Total execution time: 0.0155
INFO - 2017-03-03 19:06:30 --> Config Class Initialized
INFO - 2017-03-03 19:06:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:06:31 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:06:31 --> Utf8 Class Initialized
INFO - 2017-03-03 19:06:31 --> URI Class Initialized
INFO - 2017-03-03 19:06:31 --> Router Class Initialized
INFO - 2017-03-03 19:06:31 --> Output Class Initialized
INFO - 2017-03-03 19:06:31 --> Security Class Initialized
DEBUG - 2017-03-03 19:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:06:31 --> Input Class Initialized
INFO - 2017-03-03 19:06:31 --> Language Class Initialized
INFO - 2017-03-03 19:06:31 --> Loader Class Initialized
INFO - 2017-03-03 19:06:31 --> Database Driver Class Initialized
INFO - 2017-03-03 19:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:06:32 --> Controller Class Initialized
INFO - 2017-03-03 19:06:32 --> Helper loaded: date_helper
DEBUG - 2017-03-03 19:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:06:32 --> Helper loaded: url_helper
INFO - 2017-03-03 19:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 19:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 19:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 19:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:06:32 --> Final output sent to browser
DEBUG - 2017-03-03 19:06:32 --> Total execution time: 2.1386
INFO - 2017-03-03 19:06:38 --> Config Class Initialized
INFO - 2017-03-03 19:06:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:06:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:06:38 --> Utf8 Class Initialized
INFO - 2017-03-03 19:06:38 --> URI Class Initialized
DEBUG - 2017-03-03 19:06:38 --> No URI present. Default controller set.
INFO - 2017-03-03 19:06:38 --> Router Class Initialized
INFO - 2017-03-03 19:06:38 --> Config Class Initialized
INFO - 2017-03-03 19:06:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:06:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:06:38 --> Utf8 Class Initialized
INFO - 2017-03-03 19:06:38 --> URI Class Initialized
INFO - 2017-03-03 19:06:38 --> Router Class Initialized
INFO - 2017-03-03 19:06:38 --> Output Class Initialized
INFO - 2017-03-03 19:06:38 --> Output Class Initialized
INFO - 2017-03-03 19:06:38 --> Security Class Initialized
INFO - 2017-03-03 19:06:38 --> Security Class Initialized
DEBUG - 2017-03-03 19:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:06:38 --> Input Class Initialized
INFO - 2017-03-03 19:06:38 --> Language Class Initialized
DEBUG - 2017-03-03 19:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:06:38 --> Input Class Initialized
INFO - 2017-03-03 19:06:38 --> Language Class Initialized
INFO - 2017-03-03 19:06:38 --> Loader Class Initialized
INFO - 2017-03-03 19:06:38 --> Loader Class Initialized
INFO - 2017-03-03 19:06:39 --> Database Driver Class Initialized
INFO - 2017-03-03 19:06:39 --> Database Driver Class Initialized
INFO - 2017-03-03 19:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:06:39 --> Controller Class Initialized
INFO - 2017-03-03 19:06:39 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:06:39 --> Final output sent to browser
DEBUG - 2017-03-03 19:06:39 --> Total execution time: 1.2527
INFO - 2017-03-03 19:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:06:39 --> Controller Class Initialized
INFO - 2017-03-03 19:06:39 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:06:39 --> Final output sent to browser
DEBUG - 2017-03-03 19:06:39 --> Total execution time: 1.3790
INFO - 2017-03-03 19:06:48 --> Config Class Initialized
INFO - 2017-03-03 19:06:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:06:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:06:49 --> Utf8 Class Initialized
INFO - 2017-03-03 19:06:49 --> URI Class Initialized
INFO - 2017-03-03 19:06:49 --> Router Class Initialized
INFO - 2017-03-03 19:06:49 --> Output Class Initialized
INFO - 2017-03-03 19:06:49 --> Security Class Initialized
DEBUG - 2017-03-03 19:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:06:49 --> Input Class Initialized
INFO - 2017-03-03 19:06:49 --> Language Class Initialized
INFO - 2017-03-03 19:06:49 --> Loader Class Initialized
INFO - 2017-03-03 19:06:49 --> Database Driver Class Initialized
INFO - 2017-03-03 19:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:06:49 --> Controller Class Initialized
INFO - 2017-03-03 19:06:49 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:06:51 --> Config Class Initialized
INFO - 2017-03-03 19:06:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:06:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:06:51 --> Utf8 Class Initialized
INFO - 2017-03-03 19:06:51 --> URI Class Initialized
INFO - 2017-03-03 19:06:51 --> Router Class Initialized
INFO - 2017-03-03 19:06:51 --> Output Class Initialized
INFO - 2017-03-03 19:06:51 --> Security Class Initialized
DEBUG - 2017-03-03 19:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:06:51 --> Input Class Initialized
INFO - 2017-03-03 19:06:51 --> Language Class Initialized
INFO - 2017-03-03 19:06:51 --> Loader Class Initialized
INFO - 2017-03-03 19:06:51 --> Database Driver Class Initialized
INFO - 2017-03-03 19:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:06:51 --> Controller Class Initialized
INFO - 2017-03-03 19:06:51 --> Helper loaded: date_helper
DEBUG - 2017-03-03 19:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:06:51 --> Helper loaded: url_helper
INFO - 2017-03-03 19:06:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:06:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 19:06:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 19:06:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 19:06:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:06:55 --> Final output sent to browser
DEBUG - 2017-03-03 19:06:55 --> Total execution time: 4.2328
INFO - 2017-03-03 19:06:56 --> Config Class Initialized
INFO - 2017-03-03 19:06:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:06:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:06:56 --> Utf8 Class Initialized
INFO - 2017-03-03 19:06:56 --> URI Class Initialized
INFO - 2017-03-03 19:06:56 --> Router Class Initialized
INFO - 2017-03-03 19:06:56 --> Output Class Initialized
INFO - 2017-03-03 19:06:56 --> Security Class Initialized
DEBUG - 2017-03-03 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:06:56 --> Input Class Initialized
INFO - 2017-03-03 19:06:56 --> Language Class Initialized
INFO - 2017-03-03 19:06:56 --> Loader Class Initialized
INFO - 2017-03-03 19:06:56 --> Database Driver Class Initialized
INFO - 2017-03-03 19:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:06:56 --> Controller Class Initialized
INFO - 2017-03-03 19:06:56 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:06:57 --> Config Class Initialized
INFO - 2017-03-03 19:06:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:06:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:06:57 --> Utf8 Class Initialized
INFO - 2017-03-03 19:06:57 --> URI Class Initialized
INFO - 2017-03-03 19:06:57 --> Router Class Initialized
INFO - 2017-03-03 19:06:57 --> Output Class Initialized
INFO - 2017-03-03 19:06:57 --> Security Class Initialized
DEBUG - 2017-03-03 19:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:06:57 --> Input Class Initialized
INFO - 2017-03-03 19:06:57 --> Language Class Initialized
INFO - 2017-03-03 19:06:57 --> Loader Class Initialized
INFO - 2017-03-03 19:06:57 --> Database Driver Class Initialized
INFO - 2017-03-03 19:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:06:57 --> Controller Class Initialized
INFO - 2017-03-03 19:06:57 --> Helper loaded: date_helper
DEBUG - 2017-03-03 19:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:06:57 --> Helper loaded: url_helper
INFO - 2017-03-03 19:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 19:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 19:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 19:06:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:06:57 --> Final output sent to browser
DEBUG - 2017-03-03 19:06:57 --> Total execution time: 0.0312
INFO - 2017-03-03 19:07:00 --> Config Class Initialized
INFO - 2017-03-03 19:07:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:07:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:07:00 --> Utf8 Class Initialized
INFO - 2017-03-03 19:07:00 --> URI Class Initialized
INFO - 2017-03-03 19:07:00 --> Router Class Initialized
INFO - 2017-03-03 19:07:00 --> Output Class Initialized
INFO - 2017-03-03 19:07:00 --> Security Class Initialized
DEBUG - 2017-03-03 19:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:07:00 --> Input Class Initialized
INFO - 2017-03-03 19:07:00 --> Language Class Initialized
INFO - 2017-03-03 19:07:00 --> Loader Class Initialized
INFO - 2017-03-03 19:07:00 --> Database Driver Class Initialized
INFO - 2017-03-03 19:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:07:00 --> Controller Class Initialized
INFO - 2017-03-03 19:07:00 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:07:00 --> Final output sent to browser
DEBUG - 2017-03-03 19:07:00 --> Total execution time: 0.0309
INFO - 2017-03-03 19:07:16 --> Config Class Initialized
INFO - 2017-03-03 19:07:16 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:07:16 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:07:16 --> Utf8 Class Initialized
INFO - 2017-03-03 19:07:16 --> URI Class Initialized
DEBUG - 2017-03-03 19:07:16 --> No URI present. Default controller set.
INFO - 2017-03-03 19:07:16 --> Router Class Initialized
INFO - 2017-03-03 19:07:16 --> Output Class Initialized
INFO - 2017-03-03 19:07:16 --> Security Class Initialized
DEBUG - 2017-03-03 19:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:07:16 --> Input Class Initialized
INFO - 2017-03-03 19:07:16 --> Language Class Initialized
INFO - 2017-03-03 19:07:16 --> Loader Class Initialized
INFO - 2017-03-03 19:07:16 --> Database Driver Class Initialized
INFO - 2017-03-03 19:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:07:17 --> Controller Class Initialized
INFO - 2017-03-03 19:07:17 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:07:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:07:17 --> Final output sent to browser
DEBUG - 2017-03-03 19:07:17 --> Total execution time: 1.3848
INFO - 2017-03-03 19:08:02 --> Config Class Initialized
INFO - 2017-03-03 19:08:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:08:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:08:02 --> Utf8 Class Initialized
INFO - 2017-03-03 19:08:02 --> URI Class Initialized
INFO - 2017-03-03 19:08:02 --> Router Class Initialized
INFO - 2017-03-03 19:08:02 --> Output Class Initialized
INFO - 2017-03-03 19:08:02 --> Security Class Initialized
DEBUG - 2017-03-03 19:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:08:02 --> Input Class Initialized
INFO - 2017-03-03 19:08:02 --> Language Class Initialized
INFO - 2017-03-03 19:08:02 --> Loader Class Initialized
INFO - 2017-03-03 19:08:02 --> Database Driver Class Initialized
INFO - 2017-03-03 19:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:08:03 --> Controller Class Initialized
INFO - 2017-03-03 19:08:03 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:08:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:08:03 --> Final output sent to browser
DEBUG - 2017-03-03 19:08:03 --> Total execution time: 1.5426
INFO - 2017-03-03 19:08:14 --> Config Class Initialized
INFO - 2017-03-03 19:08:14 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:08:14 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:08:14 --> Utf8 Class Initialized
INFO - 2017-03-03 19:08:14 --> URI Class Initialized
INFO - 2017-03-03 19:08:14 --> Router Class Initialized
INFO - 2017-03-03 19:08:14 --> Output Class Initialized
INFO - 2017-03-03 19:08:14 --> Security Class Initialized
DEBUG - 2017-03-03 19:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:08:14 --> Input Class Initialized
INFO - 2017-03-03 19:08:14 --> Language Class Initialized
INFO - 2017-03-03 19:08:14 --> Loader Class Initialized
INFO - 2017-03-03 19:08:15 --> Database Driver Class Initialized
INFO - 2017-03-03 19:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:08:15 --> Controller Class Initialized
INFO - 2017-03-03 19:08:15 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:08:17 --> Config Class Initialized
INFO - 2017-03-03 19:08:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:08:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:08:17 --> Utf8 Class Initialized
INFO - 2017-03-03 19:08:17 --> URI Class Initialized
INFO - 2017-03-03 19:08:17 --> Router Class Initialized
INFO - 2017-03-03 19:08:17 --> Output Class Initialized
INFO - 2017-03-03 19:08:17 --> Security Class Initialized
DEBUG - 2017-03-03 19:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:08:17 --> Input Class Initialized
INFO - 2017-03-03 19:08:17 --> Language Class Initialized
INFO - 2017-03-03 19:08:17 --> Loader Class Initialized
INFO - 2017-03-03 19:08:17 --> Database Driver Class Initialized
INFO - 2017-03-03 19:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:08:17 --> Controller Class Initialized
INFO - 2017-03-03 19:08:17 --> Helper loaded: date_helper
DEBUG - 2017-03-03 19:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:08:17 --> Helper loaded: url_helper
INFO - 2017-03-03 19:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 19:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 19:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 19:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:08:17 --> Final output sent to browser
DEBUG - 2017-03-03 19:08:17 --> Total execution time: 0.1135
INFO - 2017-03-03 19:08:27 --> Config Class Initialized
INFO - 2017-03-03 19:08:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:08:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:08:27 --> Utf8 Class Initialized
INFO - 2017-03-03 19:08:27 --> URI Class Initialized
DEBUG - 2017-03-03 19:08:27 --> No URI present. Default controller set.
INFO - 2017-03-03 19:08:27 --> Router Class Initialized
INFO - 2017-03-03 19:08:27 --> Output Class Initialized
INFO - 2017-03-03 19:08:27 --> Security Class Initialized
DEBUG - 2017-03-03 19:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:08:27 --> Input Class Initialized
INFO - 2017-03-03 19:08:27 --> Language Class Initialized
INFO - 2017-03-03 19:08:27 --> Loader Class Initialized
INFO - 2017-03-03 19:08:28 --> Database Driver Class Initialized
INFO - 2017-03-03 19:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:08:28 --> Controller Class Initialized
INFO - 2017-03-03 19:08:28 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:08:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:08:29 --> Final output sent to browser
DEBUG - 2017-03-03 19:08:29 --> Total execution time: 1.5509
INFO - 2017-03-03 19:08:56 --> Config Class Initialized
INFO - 2017-03-03 19:08:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:08:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:08:56 --> Utf8 Class Initialized
INFO - 2017-03-03 19:08:56 --> URI Class Initialized
INFO - 2017-03-03 19:08:56 --> Router Class Initialized
INFO - 2017-03-03 19:08:56 --> Output Class Initialized
INFO - 2017-03-03 19:08:56 --> Security Class Initialized
DEBUG - 2017-03-03 19:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:08:56 --> Input Class Initialized
INFO - 2017-03-03 19:08:56 --> Language Class Initialized
INFO - 2017-03-03 19:08:57 --> Loader Class Initialized
INFO - 2017-03-03 19:08:57 --> Database Driver Class Initialized
INFO - 2017-03-03 19:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:08:57 --> Controller Class Initialized
INFO - 2017-03-03 19:08:57 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:08:58 --> Final output sent to browser
DEBUG - 2017-03-03 19:08:58 --> Total execution time: 1.9176
INFO - 2017-03-03 19:09:05 --> Config Class Initialized
INFO - 2017-03-03 19:09:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:09:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:09:05 --> Utf8 Class Initialized
INFO - 2017-03-03 19:09:05 --> URI Class Initialized
INFO - 2017-03-03 19:09:05 --> Router Class Initialized
INFO - 2017-03-03 19:09:05 --> Output Class Initialized
INFO - 2017-03-03 19:09:05 --> Security Class Initialized
DEBUG - 2017-03-03 19:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:09:05 --> Input Class Initialized
INFO - 2017-03-03 19:09:05 --> Language Class Initialized
INFO - 2017-03-03 19:09:06 --> Loader Class Initialized
INFO - 2017-03-03 19:09:06 --> Database Driver Class Initialized
INFO - 2017-03-03 19:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:09:06 --> Controller Class Initialized
INFO - 2017-03-03 19:09:06 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:09:09 --> Config Class Initialized
INFO - 2017-03-03 19:09:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:09:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:09:09 --> Utf8 Class Initialized
INFO - 2017-03-03 19:09:09 --> URI Class Initialized
INFO - 2017-03-03 19:09:09 --> Router Class Initialized
INFO - 2017-03-03 19:09:09 --> Output Class Initialized
INFO - 2017-03-03 19:09:09 --> Security Class Initialized
DEBUG - 2017-03-03 19:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:09:09 --> Input Class Initialized
INFO - 2017-03-03 19:09:09 --> Language Class Initialized
INFO - 2017-03-03 19:09:09 --> Loader Class Initialized
INFO - 2017-03-03 19:09:09 --> Database Driver Class Initialized
INFO - 2017-03-03 19:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:09:10 --> Controller Class Initialized
INFO - 2017-03-03 19:09:10 --> Helper loaded: date_helper
DEBUG - 2017-03-03 19:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:09:10 --> Helper loaded: url_helper
INFO - 2017-03-03 19:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 19:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 19:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 19:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:09:10 --> Final output sent to browser
DEBUG - 2017-03-03 19:09:10 --> Total execution time: 1.3211
INFO - 2017-03-03 19:09:18 --> Config Class Initialized
INFO - 2017-03-03 19:09:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:09:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:09:18 --> Utf8 Class Initialized
INFO - 2017-03-03 19:09:18 --> URI Class Initialized
INFO - 2017-03-03 19:09:18 --> Router Class Initialized
INFO - 2017-03-03 19:09:18 --> Output Class Initialized
INFO - 2017-03-03 19:09:18 --> Security Class Initialized
DEBUG - 2017-03-03 19:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:09:18 --> Input Class Initialized
INFO - 2017-03-03 19:09:18 --> Language Class Initialized
INFO - 2017-03-03 19:09:18 --> Loader Class Initialized
INFO - 2017-03-03 19:09:18 --> Database Driver Class Initialized
INFO - 2017-03-03 19:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:09:19 --> Controller Class Initialized
INFO - 2017-03-03 19:09:19 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:09:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 19:09:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`, `contraseña`) VALUES (NULL, NULL, NULL)
INFO - 2017-03-03 19:09:19 --> Language file loaded: language/english/db_lang.php
INFO - 2017-03-03 19:09:24 --> Config Class Initialized
INFO - 2017-03-03 19:09:24 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:09:24 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:09:24 --> Utf8 Class Initialized
INFO - 2017-03-03 19:09:24 --> URI Class Initialized
DEBUG - 2017-03-03 19:09:24 --> No URI present. Default controller set.
INFO - 2017-03-03 19:09:24 --> Router Class Initialized
INFO - 2017-03-03 19:09:24 --> Output Class Initialized
INFO - 2017-03-03 19:09:24 --> Security Class Initialized
DEBUG - 2017-03-03 19:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:09:24 --> Input Class Initialized
INFO - 2017-03-03 19:09:24 --> Language Class Initialized
INFO - 2017-03-03 19:09:24 --> Loader Class Initialized
INFO - 2017-03-03 19:09:25 --> Database Driver Class Initialized
INFO - 2017-03-03 19:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:09:25 --> Controller Class Initialized
INFO - 2017-03-03 19:09:25 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:09:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:09:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:09:26 --> Final output sent to browser
DEBUG - 2017-03-03 19:09:26 --> Total execution time: 2.0130
INFO - 2017-03-03 19:09:43 --> Config Class Initialized
INFO - 2017-03-03 19:09:43 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:09:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:09:44 --> Utf8 Class Initialized
INFO - 2017-03-03 19:09:44 --> URI Class Initialized
INFO - 2017-03-03 19:09:44 --> Router Class Initialized
INFO - 2017-03-03 19:09:44 --> Output Class Initialized
INFO - 2017-03-03 19:09:44 --> Security Class Initialized
DEBUG - 2017-03-03 19:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:09:44 --> Input Class Initialized
INFO - 2017-03-03 19:09:44 --> Language Class Initialized
INFO - 2017-03-03 19:09:44 --> Loader Class Initialized
INFO - 2017-03-03 19:09:44 --> Database Driver Class Initialized
INFO - 2017-03-03 19:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:09:45 --> Controller Class Initialized
INFO - 2017-03-03 19:09:45 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:09:45 --> Final output sent to browser
DEBUG - 2017-03-03 19:09:45 --> Total execution time: 1.8709
INFO - 2017-03-03 19:09:59 --> Config Class Initialized
INFO - 2017-03-03 19:09:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:10:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:10:00 --> Utf8 Class Initialized
INFO - 2017-03-03 19:10:00 --> URI Class Initialized
INFO - 2017-03-03 19:10:00 --> Router Class Initialized
INFO - 2017-03-03 19:10:00 --> Output Class Initialized
INFO - 2017-03-03 19:10:00 --> Security Class Initialized
DEBUG - 2017-03-03 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:10:00 --> Input Class Initialized
INFO - 2017-03-03 19:10:00 --> Language Class Initialized
INFO - 2017-03-03 19:10:00 --> Loader Class Initialized
INFO - 2017-03-03 19:10:00 --> Database Driver Class Initialized
INFO - 2017-03-03 19:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:10:00 --> Controller Class Initialized
INFO - 2017-03-03 19:10:00 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:10:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:10:00 --> Final output sent to browser
DEBUG - 2017-03-03 19:10:00 --> Total execution time: 0.8834
INFO - 2017-03-03 19:10:34 --> Config Class Initialized
INFO - 2017-03-03 19:10:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:10:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:10:34 --> Utf8 Class Initialized
INFO - 2017-03-03 19:10:34 --> URI Class Initialized
INFO - 2017-03-03 19:10:34 --> Router Class Initialized
INFO - 2017-03-03 19:10:34 --> Output Class Initialized
INFO - 2017-03-03 19:10:34 --> Security Class Initialized
DEBUG - 2017-03-03 19:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:10:35 --> Input Class Initialized
INFO - 2017-03-03 19:10:35 --> Language Class Initialized
INFO - 2017-03-03 19:10:35 --> Loader Class Initialized
INFO - 2017-03-03 19:10:35 --> Database Driver Class Initialized
INFO - 2017-03-03 19:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:10:35 --> Controller Class Initialized
INFO - 2017-03-03 19:10:35 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:10:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:10:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:10:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:10:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:10:36 --> Final output sent to browser
DEBUG - 2017-03-03 19:10:36 --> Total execution time: 1.5264
INFO - 2017-03-03 19:10:54 --> Config Class Initialized
INFO - 2017-03-03 19:10:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 19:10:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 19:10:54 --> Utf8 Class Initialized
INFO - 2017-03-03 19:10:54 --> URI Class Initialized
INFO - 2017-03-03 19:10:54 --> Router Class Initialized
INFO - 2017-03-03 19:10:54 --> Output Class Initialized
INFO - 2017-03-03 19:10:54 --> Security Class Initialized
DEBUG - 2017-03-03 19:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 19:10:54 --> Input Class Initialized
INFO - 2017-03-03 19:10:54 --> Language Class Initialized
INFO - 2017-03-03 19:10:54 --> Loader Class Initialized
INFO - 2017-03-03 19:10:55 --> Database Driver Class Initialized
INFO - 2017-03-03 19:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 19:10:55 --> Controller Class Initialized
INFO - 2017-03-03 19:10:55 --> Helper loaded: url_helper
DEBUG - 2017-03-03 19:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 19:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 19:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 19:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 19:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 19:10:55 --> Final output sent to browser
DEBUG - 2017-03-03 19:10:55 --> Total execution time: 1.4990
INFO - 2017-03-03 21:23:11 --> Config Class Initialized
INFO - 2017-03-03 21:23:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:23:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:23:11 --> Utf8 Class Initialized
INFO - 2017-03-03 21:23:11 --> URI Class Initialized
DEBUG - 2017-03-03 21:23:12 --> No URI present. Default controller set.
INFO - 2017-03-03 21:23:12 --> Router Class Initialized
INFO - 2017-03-03 21:23:12 --> Output Class Initialized
INFO - 2017-03-03 21:23:12 --> Security Class Initialized
DEBUG - 2017-03-03 21:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:23:12 --> Input Class Initialized
INFO - 2017-03-03 21:23:12 --> Language Class Initialized
INFO - 2017-03-03 21:23:12 --> Loader Class Initialized
INFO - 2017-03-03 21:23:12 --> Database Driver Class Initialized
INFO - 2017-03-03 21:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:23:13 --> Controller Class Initialized
INFO - 2017-03-03 21:23:13 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:23:13 --> Final output sent to browser
DEBUG - 2017-03-03 21:23:13 --> Total execution time: 2.0377
INFO - 2017-03-03 21:23:19 --> Config Class Initialized
INFO - 2017-03-03 21:23:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:23:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:23:19 --> Utf8 Class Initialized
INFO - 2017-03-03 21:23:19 --> URI Class Initialized
INFO - 2017-03-03 21:23:19 --> Router Class Initialized
INFO - 2017-03-03 21:23:19 --> Output Class Initialized
INFO - 2017-03-03 21:23:19 --> Security Class Initialized
DEBUG - 2017-03-03 21:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:23:19 --> Input Class Initialized
INFO - 2017-03-03 21:23:19 --> Language Class Initialized
INFO - 2017-03-03 21:23:19 --> Loader Class Initialized
INFO - 2017-03-03 21:23:19 --> Database Driver Class Initialized
INFO - 2017-03-03 21:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:23:19 --> Controller Class Initialized
INFO - 2017-03-03 21:23:19 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:23:19 --> Final output sent to browser
DEBUG - 2017-03-03 21:23:19 --> Total execution time: 0.0138
INFO - 2017-03-03 21:23:27 --> Config Class Initialized
INFO - 2017-03-03 21:23:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:23:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:23:27 --> Utf8 Class Initialized
INFO - 2017-03-03 21:23:27 --> URI Class Initialized
INFO - 2017-03-03 21:23:27 --> Router Class Initialized
INFO - 2017-03-03 21:23:27 --> Output Class Initialized
INFO - 2017-03-03 21:23:27 --> Security Class Initialized
DEBUG - 2017-03-03 21:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:23:27 --> Input Class Initialized
INFO - 2017-03-03 21:23:27 --> Language Class Initialized
INFO - 2017-03-03 21:23:27 --> Loader Class Initialized
INFO - 2017-03-03 21:23:27 --> Database Driver Class Initialized
INFO - 2017-03-03 21:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:23:27 --> Controller Class Initialized
INFO - 2017-03-03 21:23:27 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:23:28 --> Config Class Initialized
INFO - 2017-03-03 21:23:28 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:23:28 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:23:28 --> Utf8 Class Initialized
INFO - 2017-03-03 21:23:28 --> URI Class Initialized
INFO - 2017-03-03 21:23:28 --> Router Class Initialized
INFO - 2017-03-03 21:23:28 --> Output Class Initialized
INFO - 2017-03-03 21:23:28 --> Security Class Initialized
DEBUG - 2017-03-03 21:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:23:28 --> Input Class Initialized
INFO - 2017-03-03 21:23:28 --> Language Class Initialized
INFO - 2017-03-03 21:23:28 --> Loader Class Initialized
INFO - 2017-03-03 21:23:28 --> Database Driver Class Initialized
INFO - 2017-03-03 21:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:23:28 --> Controller Class Initialized
INFO - 2017-03-03 21:23:29 --> Helper loaded: date_helper
DEBUG - 2017-03-03 21:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:23:29 --> Helper loaded: url_helper
INFO - 2017-03-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 21:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:23:29 --> Final output sent to browser
DEBUG - 2017-03-03 21:23:29 --> Total execution time: 0.1490
INFO - 2017-03-03 21:23:30 --> Config Class Initialized
INFO - 2017-03-03 21:23:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:23:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:23:30 --> Utf8 Class Initialized
INFO - 2017-03-03 21:23:30 --> URI Class Initialized
INFO - 2017-03-03 21:23:30 --> Router Class Initialized
INFO - 2017-03-03 21:23:30 --> Output Class Initialized
INFO - 2017-03-03 21:23:30 --> Security Class Initialized
DEBUG - 2017-03-03 21:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:23:30 --> Input Class Initialized
INFO - 2017-03-03 21:23:30 --> Language Class Initialized
INFO - 2017-03-03 21:23:30 --> Loader Class Initialized
INFO - 2017-03-03 21:23:30 --> Database Driver Class Initialized
INFO - 2017-03-03 21:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:23:30 --> Controller Class Initialized
INFO - 2017-03-03 21:23:30 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:23:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:23:30 --> Final output sent to browser
DEBUG - 2017-03-03 21:23:30 --> Total execution time: 0.0142
INFO - 2017-03-03 21:23:37 --> Config Class Initialized
INFO - 2017-03-03 21:23:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:23:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:23:37 --> Utf8 Class Initialized
INFO - 2017-03-03 21:23:37 --> URI Class Initialized
DEBUG - 2017-03-03 21:23:37 --> No URI present. Default controller set.
INFO - 2017-03-03 21:23:37 --> Router Class Initialized
INFO - 2017-03-03 21:23:37 --> Output Class Initialized
INFO - 2017-03-03 21:23:37 --> Security Class Initialized
DEBUG - 2017-03-03 21:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:23:37 --> Input Class Initialized
INFO - 2017-03-03 21:23:37 --> Language Class Initialized
INFO - 2017-03-03 21:23:37 --> Loader Class Initialized
INFO - 2017-03-03 21:23:37 --> Database Driver Class Initialized
INFO - 2017-03-03 21:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:23:37 --> Controller Class Initialized
INFO - 2017-03-03 21:23:37 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:23:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:23:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:23:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:23:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:23:37 --> Final output sent to browser
DEBUG - 2017-03-03 21:23:37 --> Total execution time: 0.0139
INFO - 2017-03-03 21:23:38 --> Config Class Initialized
INFO - 2017-03-03 21:23:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:23:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:23:38 --> Utf8 Class Initialized
INFO - 2017-03-03 21:23:38 --> URI Class Initialized
INFO - 2017-03-03 21:23:38 --> Router Class Initialized
INFO - 2017-03-03 21:23:38 --> Output Class Initialized
INFO - 2017-03-03 21:23:38 --> Security Class Initialized
DEBUG - 2017-03-03 21:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:23:38 --> Input Class Initialized
INFO - 2017-03-03 21:23:38 --> Language Class Initialized
INFO - 2017-03-03 21:23:38 --> Loader Class Initialized
INFO - 2017-03-03 21:23:38 --> Database Driver Class Initialized
INFO - 2017-03-03 21:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:23:38 --> Controller Class Initialized
INFO - 2017-03-03 21:23:38 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:23:38 --> Final output sent to browser
DEBUG - 2017-03-03 21:23:38 --> Total execution time: 0.0138
INFO - 2017-03-03 21:24:36 --> Config Class Initialized
INFO - 2017-03-03 21:24:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:24:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:24:36 --> Utf8 Class Initialized
INFO - 2017-03-03 21:24:36 --> URI Class Initialized
INFO - 2017-03-03 21:24:36 --> Router Class Initialized
INFO - 2017-03-03 21:24:36 --> Output Class Initialized
INFO - 2017-03-03 21:24:36 --> Security Class Initialized
DEBUG - 2017-03-03 21:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:24:36 --> Input Class Initialized
INFO - 2017-03-03 21:24:36 --> Language Class Initialized
INFO - 2017-03-03 21:24:36 --> Loader Class Initialized
INFO - 2017-03-03 21:24:36 --> Database Driver Class Initialized
INFO - 2017-03-03 21:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:24:36 --> Controller Class Initialized
INFO - 2017-03-03 21:24:36 --> Helper loaded: date_helper
DEBUG - 2017-03-03 21:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:24:36 --> Helper loaded: url_helper
INFO - 2017-03-03 21:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 21:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 21:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 21:24:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:24:36 --> Final output sent to browser
DEBUG - 2017-03-03 21:24:36 --> Total execution time: 0.0587
INFO - 2017-03-03 21:30:07 --> Config Class Initialized
INFO - 2017-03-03 21:30:07 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:30:08 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:30:08 --> Utf8 Class Initialized
INFO - 2017-03-03 21:30:08 --> URI Class Initialized
DEBUG - 2017-03-03 21:30:08 --> No URI present. Default controller set.
INFO - 2017-03-03 21:30:08 --> Router Class Initialized
INFO - 2017-03-03 21:30:08 --> Output Class Initialized
INFO - 2017-03-03 21:30:08 --> Security Class Initialized
DEBUG - 2017-03-03 21:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:30:08 --> Input Class Initialized
INFO - 2017-03-03 21:30:08 --> Language Class Initialized
INFO - 2017-03-03 21:30:08 --> Loader Class Initialized
INFO - 2017-03-03 21:30:08 --> Database Driver Class Initialized
INFO - 2017-03-03 21:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:30:09 --> Controller Class Initialized
INFO - 2017-03-03 21:30:09 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:30:09 --> Final output sent to browser
DEBUG - 2017-03-03 21:30:09 --> Total execution time: 2.0323
INFO - 2017-03-03 21:30:48 --> Config Class Initialized
INFO - 2017-03-03 21:30:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:30:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:30:49 --> Utf8 Class Initialized
INFO - 2017-03-03 21:30:49 --> URI Class Initialized
INFO - 2017-03-03 21:30:49 --> Router Class Initialized
INFO - 2017-03-03 21:30:49 --> Output Class Initialized
INFO - 2017-03-03 21:30:49 --> Security Class Initialized
DEBUG - 2017-03-03 21:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:30:49 --> Input Class Initialized
INFO - 2017-03-03 21:30:49 --> Language Class Initialized
INFO - 2017-03-03 21:30:49 --> Loader Class Initialized
INFO - 2017-03-03 21:30:49 --> Database Driver Class Initialized
INFO - 2017-03-03 21:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:30:50 --> Controller Class Initialized
INFO - 2017-03-03 21:30:50 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:30:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 21:30:53 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 21:30:53 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ivon Es')
INFO - 2017-03-03 21:30:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 21:30:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 21:30:54 --> Config Class Initialized
INFO - 2017-03-03 21:30:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:30:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:30:54 --> Utf8 Class Initialized
INFO - 2017-03-03 21:30:54 --> URI Class Initialized
INFO - 2017-03-03 21:30:54 --> Router Class Initialized
INFO - 2017-03-03 21:30:54 --> Output Class Initialized
INFO - 2017-03-03 21:30:54 --> Security Class Initialized
DEBUG - 2017-03-03 21:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:30:54 --> Input Class Initialized
INFO - 2017-03-03 21:30:54 --> Language Class Initialized
INFO - 2017-03-03 21:30:54 --> Loader Class Initialized
INFO - 2017-03-03 21:30:54 --> Database Driver Class Initialized
INFO - 2017-03-03 21:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:30:54 --> Controller Class Initialized
INFO - 2017-03-03 21:30:54 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:30:54 --> Final output sent to browser
DEBUG - 2017-03-03 21:30:54 --> Total execution time: 0.1548
INFO - 2017-03-03 21:31:03 --> Config Class Initialized
INFO - 2017-03-03 21:31:03 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:31:03 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:31:03 --> Utf8 Class Initialized
INFO - 2017-03-03 21:31:03 --> URI Class Initialized
INFO - 2017-03-03 21:31:03 --> Router Class Initialized
INFO - 2017-03-03 21:31:03 --> Output Class Initialized
INFO - 2017-03-03 21:31:03 --> Security Class Initialized
DEBUG - 2017-03-03 21:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:31:03 --> Input Class Initialized
INFO - 2017-03-03 21:31:03 --> Language Class Initialized
INFO - 2017-03-03 21:31:03 --> Loader Class Initialized
INFO - 2017-03-03 21:31:03 --> Database Driver Class Initialized
INFO - 2017-03-03 21:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:31:03 --> Controller Class Initialized
INFO - 2017-03-03 21:31:03 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:31:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 21:31:05 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 21:31:05 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ivon Es')
INFO - 2017-03-03 21:31:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 21:31:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 21:31:08 --> Config Class Initialized
INFO - 2017-03-03 21:31:08 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:31:08 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:31:08 --> Utf8 Class Initialized
INFO - 2017-03-03 21:31:08 --> URI Class Initialized
INFO - 2017-03-03 21:31:08 --> Router Class Initialized
INFO - 2017-03-03 21:31:08 --> Output Class Initialized
INFO - 2017-03-03 21:31:08 --> Security Class Initialized
DEBUG - 2017-03-03 21:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:31:08 --> Input Class Initialized
INFO - 2017-03-03 21:31:08 --> Language Class Initialized
INFO - 2017-03-03 21:31:08 --> Loader Class Initialized
INFO - 2017-03-03 21:31:08 --> Database Driver Class Initialized
INFO - 2017-03-03 21:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:31:09 --> Controller Class Initialized
INFO - 2017-03-03 21:31:09 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:31:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:31:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:31:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:31:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:31:09 --> Final output sent to browser
DEBUG - 2017-03-03 21:31:09 --> Total execution time: 1.2997
INFO - 2017-03-03 21:31:10 --> Config Class Initialized
INFO - 2017-03-03 21:31:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:31:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:31:10 --> Utf8 Class Initialized
INFO - 2017-03-03 21:31:10 --> URI Class Initialized
DEBUG - 2017-03-03 21:31:10 --> No URI present. Default controller set.
INFO - 2017-03-03 21:31:10 --> Router Class Initialized
INFO - 2017-03-03 21:31:10 --> Output Class Initialized
INFO - 2017-03-03 21:31:10 --> Security Class Initialized
DEBUG - 2017-03-03 21:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:31:10 --> Input Class Initialized
INFO - 2017-03-03 21:31:10 --> Language Class Initialized
INFO - 2017-03-03 21:31:10 --> Loader Class Initialized
INFO - 2017-03-03 21:31:10 --> Database Driver Class Initialized
INFO - 2017-03-03 21:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:31:10 --> Controller Class Initialized
INFO - 2017-03-03 21:31:10 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:31:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:31:10 --> Final output sent to browser
DEBUG - 2017-03-03 21:31:10 --> Total execution time: 0.0440
INFO - 2017-03-03 21:31:44 --> Config Class Initialized
INFO - 2017-03-03 21:31:44 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:31:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:31:44 --> Utf8 Class Initialized
INFO - 2017-03-03 21:31:44 --> URI Class Initialized
INFO - 2017-03-03 21:31:44 --> Router Class Initialized
INFO - 2017-03-03 21:31:44 --> Output Class Initialized
INFO - 2017-03-03 21:31:44 --> Security Class Initialized
DEBUG - 2017-03-03 21:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:31:44 --> Input Class Initialized
INFO - 2017-03-03 21:31:44 --> Language Class Initialized
INFO - 2017-03-03 21:31:44 --> Loader Class Initialized
INFO - 2017-03-03 21:31:44 --> Database Driver Class Initialized
INFO - 2017-03-03 21:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:31:44 --> Controller Class Initialized
INFO - 2017-03-03 21:31:44 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:31:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:31:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:31:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:31:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:31:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:31:44 --> Final output sent to browser
DEBUG - 2017-03-03 21:31:44 --> Total execution time: 0.2635
INFO - 2017-03-03 21:32:11 --> Config Class Initialized
INFO - 2017-03-03 21:32:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:32:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:32:11 --> Utf8 Class Initialized
INFO - 2017-03-03 21:32:11 --> URI Class Initialized
INFO - 2017-03-03 21:32:11 --> Router Class Initialized
INFO - 2017-03-03 21:32:11 --> Output Class Initialized
INFO - 2017-03-03 21:32:11 --> Security Class Initialized
DEBUG - 2017-03-03 21:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:32:11 --> Input Class Initialized
INFO - 2017-03-03 21:32:11 --> Language Class Initialized
INFO - 2017-03-03 21:32:11 --> Loader Class Initialized
INFO - 2017-03-03 21:32:11 --> Database Driver Class Initialized
INFO - 2017-03-03 21:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:32:11 --> Controller Class Initialized
INFO - 2017-03-03 21:32:11 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:32:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:32:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:32:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:32:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:32:11 --> Final output sent to browser
DEBUG - 2017-03-03 21:32:11 --> Total execution time: 0.0364
INFO - 2017-03-03 21:32:18 --> Config Class Initialized
INFO - 2017-03-03 21:32:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:32:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:32:18 --> Utf8 Class Initialized
INFO - 2017-03-03 21:32:18 --> URI Class Initialized
INFO - 2017-03-03 21:32:18 --> Router Class Initialized
INFO - 2017-03-03 21:32:18 --> Output Class Initialized
INFO - 2017-03-03 21:32:18 --> Security Class Initialized
DEBUG - 2017-03-03 21:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:32:18 --> Input Class Initialized
INFO - 2017-03-03 21:32:18 --> Language Class Initialized
INFO - 2017-03-03 21:32:18 --> Loader Class Initialized
INFO - 2017-03-03 21:32:18 --> Database Driver Class Initialized
INFO - 2017-03-03 21:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:32:19 --> Controller Class Initialized
INFO - 2017-03-03 21:32:19 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:32:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:32:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:32:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:32:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:32:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:32:19 --> Final output sent to browser
DEBUG - 2017-03-03 21:32:19 --> Total execution time: 0.5899
INFO - 2017-03-03 21:32:55 --> Config Class Initialized
INFO - 2017-03-03 21:32:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:32:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:32:55 --> Utf8 Class Initialized
INFO - 2017-03-03 21:32:55 --> URI Class Initialized
INFO - 2017-03-03 21:32:55 --> Router Class Initialized
INFO - 2017-03-03 21:32:55 --> Output Class Initialized
INFO - 2017-03-03 21:32:55 --> Security Class Initialized
DEBUG - 2017-03-03 21:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:32:55 --> Input Class Initialized
INFO - 2017-03-03 21:32:55 --> Language Class Initialized
INFO - 2017-03-03 21:32:55 --> Loader Class Initialized
INFO - 2017-03-03 21:32:55 --> Database Driver Class Initialized
INFO - 2017-03-03 21:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:32:55 --> Controller Class Initialized
INFO - 2017-03-03 21:32:55 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:32:55 --> Final output sent to browser
DEBUG - 2017-03-03 21:32:55 --> Total execution time: 0.0651
INFO - 2017-03-03 21:33:01 --> Config Class Initialized
INFO - 2017-03-03 21:33:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:33:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:33:01 --> Utf8 Class Initialized
INFO - 2017-03-03 21:33:01 --> URI Class Initialized
INFO - 2017-03-03 21:33:01 --> Router Class Initialized
INFO - 2017-03-03 21:33:01 --> Output Class Initialized
INFO - 2017-03-03 21:33:01 --> Security Class Initialized
DEBUG - 2017-03-03 21:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:33:01 --> Input Class Initialized
INFO - 2017-03-03 21:33:01 --> Language Class Initialized
INFO - 2017-03-03 21:33:01 --> Loader Class Initialized
INFO - 2017-03-03 21:33:01 --> Database Driver Class Initialized
INFO - 2017-03-03 21:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:33:01 --> Controller Class Initialized
INFO - 2017-03-03 21:33:01 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:33:01 --> Final output sent to browser
DEBUG - 2017-03-03 21:33:01 --> Total execution time: 0.0188
INFO - 2017-03-03 21:33:06 --> Config Class Initialized
INFO - 2017-03-03 21:33:06 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:33:06 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:33:06 --> Utf8 Class Initialized
INFO - 2017-03-03 21:33:06 --> URI Class Initialized
INFO - 2017-03-03 21:33:06 --> Router Class Initialized
INFO - 2017-03-03 21:33:06 --> Output Class Initialized
INFO - 2017-03-03 21:33:06 --> Security Class Initialized
DEBUG - 2017-03-03 21:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:33:06 --> Input Class Initialized
INFO - 2017-03-03 21:33:06 --> Language Class Initialized
INFO - 2017-03-03 21:33:06 --> Loader Class Initialized
INFO - 2017-03-03 21:33:06 --> Database Driver Class Initialized
INFO - 2017-03-03 21:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:33:06 --> Controller Class Initialized
INFO - 2017-03-03 21:33:06 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:33:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-03 21:33:10 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-03 21:33:10 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ivon Es')
INFO - 2017-03-03 21:33:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-03 21:33:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-03 21:33:12 --> Config Class Initialized
INFO - 2017-03-03 21:33:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:33:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:33:12 --> Utf8 Class Initialized
INFO - 2017-03-03 21:33:12 --> URI Class Initialized
INFO - 2017-03-03 21:33:12 --> Router Class Initialized
INFO - 2017-03-03 21:33:12 --> Output Class Initialized
INFO - 2017-03-03 21:33:13 --> Security Class Initialized
DEBUG - 2017-03-03 21:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:33:13 --> Input Class Initialized
INFO - 2017-03-03 21:33:13 --> Language Class Initialized
INFO - 2017-03-03 21:33:13 --> Loader Class Initialized
INFO - 2017-03-03 21:33:13 --> Database Driver Class Initialized
INFO - 2017-03-03 21:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:33:13 --> Controller Class Initialized
INFO - 2017-03-03 21:33:13 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:33:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:33:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:33:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:33:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:33:14 --> Final output sent to browser
DEBUG - 2017-03-03 21:33:14 --> Total execution time: 1.3428
INFO - 2017-03-03 21:33:32 --> Config Class Initialized
INFO - 2017-03-03 21:33:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:33:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:33:32 --> Utf8 Class Initialized
INFO - 2017-03-03 21:33:32 --> URI Class Initialized
DEBUG - 2017-03-03 21:33:32 --> No URI present. Default controller set.
INFO - 2017-03-03 21:33:32 --> Router Class Initialized
INFO - 2017-03-03 21:33:32 --> Output Class Initialized
INFO - 2017-03-03 21:33:32 --> Security Class Initialized
DEBUG - 2017-03-03 21:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:33:32 --> Input Class Initialized
INFO - 2017-03-03 21:33:32 --> Language Class Initialized
INFO - 2017-03-03 21:33:32 --> Loader Class Initialized
INFO - 2017-03-03 21:33:32 --> Database Driver Class Initialized
INFO - 2017-03-03 21:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:33:32 --> Controller Class Initialized
INFO - 2017-03-03 21:33:32 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:33:32 --> Final output sent to browser
DEBUG - 2017-03-03 21:33:32 --> Total execution time: 0.9973
INFO - 2017-03-03 21:36:22 --> Config Class Initialized
INFO - 2017-03-03 21:36:22 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:36:22 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:36:22 --> Utf8 Class Initialized
INFO - 2017-03-03 21:36:22 --> URI Class Initialized
DEBUG - 2017-03-03 21:36:23 --> No URI present. Default controller set.
INFO - 2017-03-03 21:36:23 --> Router Class Initialized
INFO - 2017-03-03 21:36:23 --> Output Class Initialized
INFO - 2017-03-03 21:36:23 --> Security Class Initialized
DEBUG - 2017-03-03 21:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:36:23 --> Input Class Initialized
INFO - 2017-03-03 21:36:23 --> Language Class Initialized
INFO - 2017-03-03 21:36:23 --> Loader Class Initialized
INFO - 2017-03-03 21:36:23 --> Database Driver Class Initialized
INFO - 2017-03-03 21:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:36:24 --> Controller Class Initialized
INFO - 2017-03-03 21:36:24 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:36:24 --> Final output sent to browser
DEBUG - 2017-03-03 21:36:24 --> Total execution time: 2.0192
INFO - 2017-03-03 21:37:53 --> Config Class Initialized
INFO - 2017-03-03 21:37:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:37:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:37:53 --> Utf8 Class Initialized
INFO - 2017-03-03 21:37:53 --> URI Class Initialized
INFO - 2017-03-03 21:37:53 --> Router Class Initialized
INFO - 2017-03-03 21:37:54 --> Output Class Initialized
INFO - 2017-03-03 21:37:54 --> Security Class Initialized
DEBUG - 2017-03-03 21:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:37:54 --> Input Class Initialized
INFO - 2017-03-03 21:37:54 --> Language Class Initialized
INFO - 2017-03-03 21:37:54 --> Loader Class Initialized
INFO - 2017-03-03 21:37:54 --> Database Driver Class Initialized
INFO - 2017-03-03 21:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:37:54 --> Controller Class Initialized
INFO - 2017-03-03 21:37:54 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:37:54 --> Final output sent to browser
DEBUG - 2017-03-03 21:37:54 --> Total execution time: 1.4717
INFO - 2017-03-03 21:46:14 --> Config Class Initialized
INFO - 2017-03-03 21:46:14 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:46:14 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:46:14 --> Utf8 Class Initialized
INFO - 2017-03-03 21:46:14 --> URI Class Initialized
DEBUG - 2017-03-03 21:46:14 --> No URI present. Default controller set.
INFO - 2017-03-03 21:46:14 --> Router Class Initialized
INFO - 2017-03-03 21:46:14 --> Output Class Initialized
INFO - 2017-03-03 21:46:14 --> Security Class Initialized
DEBUG - 2017-03-03 21:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:46:14 --> Input Class Initialized
INFO - 2017-03-03 21:46:14 --> Language Class Initialized
INFO - 2017-03-03 21:46:15 --> Loader Class Initialized
INFO - 2017-03-03 21:46:15 --> Database Driver Class Initialized
INFO - 2017-03-03 21:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:46:15 --> Controller Class Initialized
INFO - 2017-03-03 21:46:15 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:46:15 --> Final output sent to browser
DEBUG - 2017-03-03 21:46:15 --> Total execution time: 1.5259
INFO - 2017-03-03 21:46:26 --> Config Class Initialized
INFO - 2017-03-03 21:46:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:46:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:46:26 --> Utf8 Class Initialized
INFO - 2017-03-03 21:46:26 --> URI Class Initialized
INFO - 2017-03-03 21:46:26 --> Router Class Initialized
INFO - 2017-03-03 21:46:27 --> Output Class Initialized
INFO - 2017-03-03 21:46:27 --> Security Class Initialized
DEBUG - 2017-03-03 21:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:46:27 --> Input Class Initialized
INFO - 2017-03-03 21:46:27 --> Language Class Initialized
INFO - 2017-03-03 21:46:27 --> Loader Class Initialized
INFO - 2017-03-03 21:46:27 --> Database Driver Class Initialized
INFO - 2017-03-03 21:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:46:28 --> Controller Class Initialized
INFO - 2017-03-03 21:46:28 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:46:29 --> Final output sent to browser
DEBUG - 2017-03-03 21:46:29 --> Total execution time: 2.6815
INFO - 2017-03-03 21:46:55 --> Config Class Initialized
INFO - 2017-03-03 21:46:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:46:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:46:55 --> Utf8 Class Initialized
INFO - 2017-03-03 21:46:55 --> URI Class Initialized
INFO - 2017-03-03 21:46:55 --> Router Class Initialized
INFO - 2017-03-03 21:46:55 --> Output Class Initialized
INFO - 2017-03-03 21:46:55 --> Security Class Initialized
DEBUG - 2017-03-03 21:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:46:55 --> Input Class Initialized
INFO - 2017-03-03 21:46:55 --> Language Class Initialized
INFO - 2017-03-03 21:46:55 --> Loader Class Initialized
INFO - 2017-03-03 21:46:56 --> Database Driver Class Initialized
INFO - 2017-03-03 21:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:46:56 --> Controller Class Initialized
INFO - 2017-03-03 21:46:56 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:46:56 --> Final output sent to browser
DEBUG - 2017-03-03 21:46:56 --> Total execution time: 1.5327
INFO - 2017-03-03 21:47:01 --> Config Class Initialized
INFO - 2017-03-03 21:47:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:01 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:01 --> URI Class Initialized
INFO - 2017-03-03 21:47:01 --> Router Class Initialized
INFO - 2017-03-03 21:47:01 --> Output Class Initialized
INFO - 2017-03-03 21:47:01 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:02 --> Input Class Initialized
INFO - 2017-03-03 21:47:02 --> Language Class Initialized
INFO - 2017-03-03 21:47:02 --> Loader Class Initialized
INFO - 2017-03-03 21:47:02 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:02 --> Controller Class Initialized
INFO - 2017-03-03 21:47:02 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:03 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:03 --> Total execution time: 1.9667
INFO - 2017-03-03 21:47:12 --> Config Class Initialized
INFO - 2017-03-03 21:47:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:13 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:13 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:13 --> URI Class Initialized
INFO - 2017-03-03 21:47:13 --> Router Class Initialized
INFO - 2017-03-03 21:47:13 --> Output Class Initialized
INFO - 2017-03-03 21:47:13 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:13 --> Input Class Initialized
INFO - 2017-03-03 21:47:13 --> Language Class Initialized
INFO - 2017-03-03 21:47:13 --> Loader Class Initialized
INFO - 2017-03-03 21:47:13 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:14 --> Controller Class Initialized
INFO - 2017-03-03 21:47:14 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:14 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:14 --> Total execution time: 1.9793
INFO - 2017-03-03 21:47:30 --> Config Class Initialized
INFO - 2017-03-03 21:47:30 --> Config Class Initialized
INFO - 2017-03-03 21:47:30 --> Hooks Class Initialized
INFO - 2017-03-03 21:47:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:30 --> UTF-8 Support Enabled
DEBUG - 2017-03-03 21:47:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:30 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:30 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:30 --> URI Class Initialized
INFO - 2017-03-03 21:47:30 --> URI Class Initialized
INFO - 2017-03-03 21:47:30 --> Router Class Initialized
INFO - 2017-03-03 21:47:30 --> Router Class Initialized
INFO - 2017-03-03 21:47:30 --> Output Class Initialized
INFO - 2017-03-03 21:47:30 --> Output Class Initialized
INFO - 2017-03-03 21:47:30 --> Security Class Initialized
INFO - 2017-03-03 21:47:31 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:31 --> Input Class Initialized
INFO - 2017-03-03 21:47:31 --> Language Class Initialized
DEBUG - 2017-03-03 21:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:31 --> Input Class Initialized
INFO - 2017-03-03 21:47:31 --> Language Class Initialized
INFO - 2017-03-03 21:47:31 --> Loader Class Initialized
INFO - 2017-03-03 21:47:31 --> Loader Class Initialized
INFO - 2017-03-03 21:47:31 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:31 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:31 --> Controller Class Initialized
INFO - 2017-03-03 21:47:31 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:31 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:31 --> Total execution time: 2.1295
INFO - 2017-03-03 21:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:31 --> Controller Class Initialized
INFO - 2017-03-03 21:47:31 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:31 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:31 --> Total execution time: 2.1328
INFO - 2017-03-03 21:47:35 --> Config Class Initialized
INFO - 2017-03-03 21:47:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:42 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:42 --> Config Class Initialized
INFO - 2017-03-03 21:47:42 --> Hooks Class Initialized
INFO - 2017-03-03 21:47:42 --> URI Class Initialized
DEBUG - 2017-03-03 21:47:42 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:42 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:42 --> Router Class Initialized
INFO - 2017-03-03 21:47:42 --> URI Class Initialized
INFO - 2017-03-03 21:47:45 --> Output Class Initialized
INFO - 2017-03-03 21:47:46 --> Router Class Initialized
INFO - 2017-03-03 21:47:46 --> Security Class Initialized
INFO - 2017-03-03 21:47:46 --> Output Class Initialized
DEBUG - 2017-03-03 21:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:46 --> Input Class Initialized
INFO - 2017-03-03 21:47:46 --> Security Class Initialized
INFO - 2017-03-03 21:47:46 --> Language Class Initialized
DEBUG - 2017-03-03 21:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:46 --> Input Class Initialized
INFO - 2017-03-03 21:47:46 --> Language Class Initialized
INFO - 2017-03-03 21:47:46 --> Loader Class Initialized
INFO - 2017-03-03 21:47:46 --> Loader Class Initialized
INFO - 2017-03-03 21:47:46 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:46 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:47 --> Controller Class Initialized
INFO - 2017-03-03 21:47:47 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:47 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:47 --> Total execution time: 6.9020
INFO - 2017-03-03 21:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:47 --> Controller Class Initialized
INFO - 2017-03-03 21:47:47 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:47 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:47 --> Total execution time: 11.8852
INFO - 2017-03-03 21:47:49 --> Config Class Initialized
INFO - 2017-03-03 21:47:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:49 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:49 --> URI Class Initialized
INFO - 2017-03-03 21:47:49 --> Router Class Initialized
INFO - 2017-03-03 21:47:49 --> Output Class Initialized
INFO - 2017-03-03 21:47:49 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:49 --> Input Class Initialized
INFO - 2017-03-03 21:47:49 --> Language Class Initialized
INFO - 2017-03-03 21:47:49 --> Loader Class Initialized
INFO - 2017-03-03 21:47:49 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:49 --> Controller Class Initialized
INFO - 2017-03-03 21:47:49 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:49 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:49 --> Total execution time: 0.5754
INFO - 2017-03-03 21:47:51 --> Config Class Initialized
INFO - 2017-03-03 21:47:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:51 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:51 --> URI Class Initialized
INFO - 2017-03-03 21:47:51 --> Router Class Initialized
INFO - 2017-03-03 21:47:51 --> Output Class Initialized
INFO - 2017-03-03 21:47:51 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:51 --> Input Class Initialized
INFO - 2017-03-03 21:47:51 --> Language Class Initialized
INFO - 2017-03-03 21:47:51 --> Loader Class Initialized
INFO - 2017-03-03 21:47:51 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:51 --> Controller Class Initialized
INFO - 2017-03-03 21:47:51 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:51 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:51 --> Total execution time: 0.0424
INFO - 2017-03-03 21:47:52 --> Config Class Initialized
INFO - 2017-03-03 21:47:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:52 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:52 --> URI Class Initialized
INFO - 2017-03-03 21:47:52 --> Router Class Initialized
INFO - 2017-03-03 21:47:52 --> Output Class Initialized
INFO - 2017-03-03 21:47:52 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:52 --> Input Class Initialized
INFO - 2017-03-03 21:47:52 --> Language Class Initialized
INFO - 2017-03-03 21:47:52 --> Loader Class Initialized
INFO - 2017-03-03 21:47:52 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:52 --> Controller Class Initialized
INFO - 2017-03-03 21:47:52 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:52 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:52 --> Total execution time: 0.0141
INFO - 2017-03-03 21:47:56 --> Config Class Initialized
INFO - 2017-03-03 21:47:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:56 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:56 --> URI Class Initialized
INFO - 2017-03-03 21:47:56 --> Router Class Initialized
INFO - 2017-03-03 21:47:56 --> Output Class Initialized
INFO - 2017-03-03 21:47:56 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:56 --> Input Class Initialized
INFO - 2017-03-03 21:47:56 --> Language Class Initialized
INFO - 2017-03-03 21:47:56 --> Loader Class Initialized
INFO - 2017-03-03 21:47:56 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:56 --> Controller Class Initialized
INFO - 2017-03-03 21:47:56 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:56 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:56 --> Total execution time: 2.1380
INFO - 2017-03-03 21:47:57 --> Config Class Initialized
INFO - 2017-03-03 21:47:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:47:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:47:57 --> Utf8 Class Initialized
INFO - 2017-03-03 21:47:57 --> URI Class Initialized
INFO - 2017-03-03 21:47:57 --> Router Class Initialized
INFO - 2017-03-03 21:47:57 --> Output Class Initialized
INFO - 2017-03-03 21:47:57 --> Security Class Initialized
DEBUG - 2017-03-03 21:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:47:57 --> Input Class Initialized
INFO - 2017-03-03 21:47:57 --> Language Class Initialized
INFO - 2017-03-03 21:47:57 --> Loader Class Initialized
INFO - 2017-03-03 21:47:57 --> Database Driver Class Initialized
INFO - 2017-03-03 21:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:47:57 --> Controller Class Initialized
INFO - 2017-03-03 21:47:57 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:47:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:47:57 --> Final output sent to browser
DEBUG - 2017-03-03 21:47:57 --> Total execution time: 0.2723
INFO - 2017-03-03 21:48:11 --> Config Class Initialized
INFO - 2017-03-03 21:48:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:48:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:48:11 --> Utf8 Class Initialized
INFO - 2017-03-03 21:48:11 --> URI Class Initialized
INFO - 2017-03-03 21:48:11 --> Router Class Initialized
INFO - 2017-03-03 21:48:11 --> Output Class Initialized
INFO - 2017-03-03 21:48:11 --> Security Class Initialized
DEBUG - 2017-03-03 21:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:48:11 --> Input Class Initialized
INFO - 2017-03-03 21:48:11 --> Language Class Initialized
INFO - 2017-03-03 21:48:11 --> Loader Class Initialized
INFO - 2017-03-03 21:48:11 --> Database Driver Class Initialized
INFO - 2017-03-03 21:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:48:11 --> Controller Class Initialized
INFO - 2017-03-03 21:48:11 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:48:11 --> Final output sent to browser
DEBUG - 2017-03-03 21:48:11 --> Total execution time: 0.0149
INFO - 2017-03-03 21:48:12 --> Config Class Initialized
INFO - 2017-03-03 21:48:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:48:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:48:12 --> Utf8 Class Initialized
INFO - 2017-03-03 21:48:12 --> URI Class Initialized
INFO - 2017-03-03 21:48:12 --> Router Class Initialized
INFO - 2017-03-03 21:48:12 --> Output Class Initialized
INFO - 2017-03-03 21:48:12 --> Security Class Initialized
DEBUG - 2017-03-03 21:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:48:12 --> Input Class Initialized
INFO - 2017-03-03 21:48:12 --> Language Class Initialized
INFO - 2017-03-03 21:48:12 --> Loader Class Initialized
INFO - 2017-03-03 21:48:12 --> Database Driver Class Initialized
INFO - 2017-03-03 21:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:48:12 --> Controller Class Initialized
INFO - 2017-03-03 21:48:12 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:48:12 --> Final output sent to browser
DEBUG - 2017-03-03 21:48:12 --> Total execution time: 0.0137
INFO - 2017-03-03 21:48:22 --> Config Class Initialized
INFO - 2017-03-03 21:48:22 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:48:22 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:48:22 --> Utf8 Class Initialized
INFO - 2017-03-03 21:48:22 --> URI Class Initialized
INFO - 2017-03-03 21:48:22 --> Router Class Initialized
INFO - 2017-03-03 21:48:22 --> Output Class Initialized
INFO - 2017-03-03 21:48:22 --> Security Class Initialized
DEBUG - 2017-03-03 21:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:48:22 --> Input Class Initialized
INFO - 2017-03-03 21:48:22 --> Language Class Initialized
INFO - 2017-03-03 21:48:22 --> Loader Class Initialized
INFO - 2017-03-03 21:48:22 --> Database Driver Class Initialized
INFO - 2017-03-03 21:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:48:22 --> Controller Class Initialized
INFO - 2017-03-03 21:48:22 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:48:24 --> Config Class Initialized
INFO - 2017-03-03 21:48:24 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:48:24 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:48:24 --> Utf8 Class Initialized
INFO - 2017-03-03 21:48:24 --> URI Class Initialized
INFO - 2017-03-03 21:48:24 --> Router Class Initialized
INFO - 2017-03-03 21:48:24 --> Output Class Initialized
INFO - 2017-03-03 21:48:24 --> Security Class Initialized
DEBUG - 2017-03-03 21:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:48:24 --> Input Class Initialized
INFO - 2017-03-03 21:48:24 --> Language Class Initialized
INFO - 2017-03-03 21:48:24 --> Loader Class Initialized
INFO - 2017-03-03 21:48:24 --> Database Driver Class Initialized
INFO - 2017-03-03 21:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:48:24 --> Controller Class Initialized
INFO - 2017-03-03 21:48:24 --> Helper loaded: date_helper
DEBUG - 2017-03-03 21:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:48:24 --> Helper loaded: url_helper
INFO - 2017-03-03 21:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 21:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 21:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 21:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:48:24 --> Final output sent to browser
DEBUG - 2017-03-03 21:48:24 --> Total execution time: 0.0983
INFO - 2017-03-03 21:48:25 --> Config Class Initialized
INFO - 2017-03-03 21:48:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:48:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:48:25 --> Utf8 Class Initialized
INFO - 2017-03-03 21:48:25 --> URI Class Initialized
INFO - 2017-03-03 21:48:25 --> Router Class Initialized
INFO - 2017-03-03 21:48:25 --> Output Class Initialized
INFO - 2017-03-03 21:48:25 --> Security Class Initialized
DEBUG - 2017-03-03 21:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:48:25 --> Input Class Initialized
INFO - 2017-03-03 21:48:25 --> Language Class Initialized
INFO - 2017-03-03 21:48:25 --> Loader Class Initialized
INFO - 2017-03-03 21:48:25 --> Database Driver Class Initialized
INFO - 2017-03-03 21:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:48:25 --> Controller Class Initialized
INFO - 2017-03-03 21:48:25 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:48:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:48:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:48:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:48:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:48:25 --> Final output sent to browser
DEBUG - 2017-03-03 21:48:25 --> Total execution time: 0.0141
INFO - 2017-03-03 21:48:29 --> Config Class Initialized
INFO - 2017-03-03 21:48:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:48:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:48:29 --> Utf8 Class Initialized
INFO - 2017-03-03 21:48:29 --> URI Class Initialized
DEBUG - 2017-03-03 21:48:29 --> No URI present. Default controller set.
INFO - 2017-03-03 21:48:29 --> Router Class Initialized
INFO - 2017-03-03 21:48:29 --> Output Class Initialized
INFO - 2017-03-03 21:48:29 --> Security Class Initialized
DEBUG - 2017-03-03 21:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:48:29 --> Input Class Initialized
INFO - 2017-03-03 21:48:29 --> Language Class Initialized
INFO - 2017-03-03 21:48:29 --> Loader Class Initialized
INFO - 2017-03-03 21:48:29 --> Database Driver Class Initialized
INFO - 2017-03-03 21:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:48:29 --> Controller Class Initialized
INFO - 2017-03-03 21:48:29 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:48:29 --> Final output sent to browser
DEBUG - 2017-03-03 21:48:29 --> Total execution time: 0.0144
INFO - 2017-03-03 21:48:30 --> Config Class Initialized
INFO - 2017-03-03 21:48:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:48:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:48:30 --> Utf8 Class Initialized
INFO - 2017-03-03 21:48:30 --> URI Class Initialized
INFO - 2017-03-03 21:48:30 --> Router Class Initialized
INFO - 2017-03-03 21:48:30 --> Output Class Initialized
INFO - 2017-03-03 21:48:30 --> Security Class Initialized
DEBUG - 2017-03-03 21:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:48:30 --> Input Class Initialized
INFO - 2017-03-03 21:48:30 --> Language Class Initialized
INFO - 2017-03-03 21:48:30 --> Loader Class Initialized
INFO - 2017-03-03 21:48:30 --> Database Driver Class Initialized
INFO - 2017-03-03 21:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:48:30 --> Controller Class Initialized
INFO - 2017-03-03 21:48:30 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:48:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:48:30 --> Final output sent to browser
DEBUG - 2017-03-03 21:48:30 --> Total execution time: 0.0148
INFO - 2017-03-03 21:49:37 --> Config Class Initialized
INFO - 2017-03-03 21:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:49:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:49:37 --> Utf8 Class Initialized
INFO - 2017-03-03 21:49:37 --> URI Class Initialized
INFO - 2017-03-03 21:49:37 --> Router Class Initialized
INFO - 2017-03-03 21:49:37 --> Output Class Initialized
INFO - 2017-03-03 21:49:37 --> Security Class Initialized
DEBUG - 2017-03-03 21:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:49:37 --> Input Class Initialized
INFO - 2017-03-03 21:49:37 --> Language Class Initialized
INFO - 2017-03-03 21:49:37 --> Loader Class Initialized
INFO - 2017-03-03 21:49:37 --> Database Driver Class Initialized
INFO - 2017-03-03 21:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:49:37 --> Controller Class Initialized
INFO - 2017-03-03 21:49:37 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:49:37 --> Final output sent to browser
DEBUG - 2017-03-03 21:49:37 --> Total execution time: 0.0151
INFO - 2017-03-03 21:49:38 --> Config Class Initialized
INFO - 2017-03-03 21:49:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:49:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:49:38 --> Utf8 Class Initialized
INFO - 2017-03-03 21:49:38 --> URI Class Initialized
INFO - 2017-03-03 21:49:38 --> Router Class Initialized
INFO - 2017-03-03 21:49:38 --> Output Class Initialized
INFO - 2017-03-03 21:49:38 --> Security Class Initialized
DEBUG - 2017-03-03 21:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:49:38 --> Input Class Initialized
INFO - 2017-03-03 21:49:38 --> Language Class Initialized
INFO - 2017-03-03 21:49:38 --> Loader Class Initialized
INFO - 2017-03-03 21:49:38 --> Database Driver Class Initialized
INFO - 2017-03-03 21:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:49:38 --> Controller Class Initialized
INFO - 2017-03-03 21:49:38 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:49:38 --> Final output sent to browser
DEBUG - 2017-03-03 21:49:38 --> Total execution time: 0.0352
INFO - 2017-03-03 21:49:48 --> Config Class Initialized
INFO - 2017-03-03 21:49:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:49:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:49:48 --> Utf8 Class Initialized
INFO - 2017-03-03 21:49:48 --> URI Class Initialized
INFO - 2017-03-03 21:49:48 --> Router Class Initialized
INFO - 2017-03-03 21:49:48 --> Output Class Initialized
INFO - 2017-03-03 21:49:48 --> Security Class Initialized
DEBUG - 2017-03-03 21:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:49:48 --> Input Class Initialized
INFO - 2017-03-03 21:49:48 --> Language Class Initialized
INFO - 2017-03-03 21:49:48 --> Loader Class Initialized
INFO - 2017-03-03 21:49:48 --> Database Driver Class Initialized
INFO - 2017-03-03 21:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:49:48 --> Controller Class Initialized
INFO - 2017-03-03 21:49:48 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:49:48 --> Final output sent to browser
DEBUG - 2017-03-03 21:49:48 --> Total execution time: 0.0156
INFO - 2017-03-03 21:49:50 --> Config Class Initialized
INFO - 2017-03-03 21:49:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:49:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:49:50 --> Utf8 Class Initialized
INFO - 2017-03-03 21:49:50 --> URI Class Initialized
INFO - 2017-03-03 21:49:50 --> Router Class Initialized
INFO - 2017-03-03 21:49:50 --> Output Class Initialized
INFO - 2017-03-03 21:49:50 --> Security Class Initialized
DEBUG - 2017-03-03 21:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:49:50 --> Input Class Initialized
INFO - 2017-03-03 21:49:50 --> Language Class Initialized
INFO - 2017-03-03 21:49:50 --> Loader Class Initialized
INFO - 2017-03-03 21:49:50 --> Database Driver Class Initialized
INFO - 2017-03-03 21:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:49:50 --> Controller Class Initialized
INFO - 2017-03-03 21:49:50 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:49:50 --> Final output sent to browser
DEBUG - 2017-03-03 21:49:50 --> Total execution time: 0.0209
INFO - 2017-03-03 21:52:40 --> Config Class Initialized
INFO - 2017-03-03 21:52:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:52:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:52:40 --> Utf8 Class Initialized
INFO - 2017-03-03 21:52:40 --> URI Class Initialized
INFO - 2017-03-03 21:52:40 --> Router Class Initialized
INFO - 2017-03-03 21:52:40 --> Output Class Initialized
INFO - 2017-03-03 21:52:40 --> Security Class Initialized
DEBUG - 2017-03-03 21:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:52:40 --> Input Class Initialized
INFO - 2017-03-03 21:52:40 --> Language Class Initialized
INFO - 2017-03-03 21:52:41 --> Loader Class Initialized
INFO - 2017-03-03 21:52:41 --> Database Driver Class Initialized
INFO - 2017-03-03 21:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:52:41 --> Controller Class Initialized
INFO - 2017-03-03 21:52:41 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:52:41 --> Final output sent to browser
DEBUG - 2017-03-03 21:52:41 --> Total execution time: 1.2654
INFO - 2017-03-03 21:53:09 --> Config Class Initialized
INFO - 2017-03-03 21:53:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:53:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:53:09 --> Utf8 Class Initialized
INFO - 2017-03-03 21:53:09 --> URI Class Initialized
INFO - 2017-03-03 21:53:09 --> Router Class Initialized
INFO - 2017-03-03 21:53:09 --> Output Class Initialized
INFO - 2017-03-03 21:53:09 --> Security Class Initialized
DEBUG - 2017-03-03 21:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:53:09 --> Input Class Initialized
INFO - 2017-03-03 21:53:09 --> Language Class Initialized
INFO - 2017-03-03 21:53:09 --> Loader Class Initialized
INFO - 2017-03-03 21:53:09 --> Database Driver Class Initialized
INFO - 2017-03-03 21:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:53:09 --> Controller Class Initialized
INFO - 2017-03-03 21:53:09 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:53:10 --> Config Class Initialized
INFO - 2017-03-03 21:53:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:53:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:53:10 --> Utf8 Class Initialized
INFO - 2017-03-03 21:53:10 --> URI Class Initialized
INFO - 2017-03-03 21:53:10 --> Router Class Initialized
INFO - 2017-03-03 21:53:10 --> Output Class Initialized
INFO - 2017-03-03 21:53:10 --> Security Class Initialized
DEBUG - 2017-03-03 21:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:53:10 --> Input Class Initialized
INFO - 2017-03-03 21:53:10 --> Language Class Initialized
INFO - 2017-03-03 21:53:10 --> Loader Class Initialized
INFO - 2017-03-03 21:53:10 --> Database Driver Class Initialized
INFO - 2017-03-03 21:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:53:10 --> Controller Class Initialized
INFO - 2017-03-03 21:53:10 --> Helper loaded: date_helper
DEBUG - 2017-03-03 21:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:53:10 --> Helper loaded: url_helper
INFO - 2017-03-03 21:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-03 21:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-03 21:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-03 21:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:53:10 --> Final output sent to browser
DEBUG - 2017-03-03 21:53:10 --> Total execution time: 0.1087
INFO - 2017-03-03 21:53:11 --> Config Class Initialized
INFO - 2017-03-03 21:53:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:53:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:53:11 --> Utf8 Class Initialized
INFO - 2017-03-03 21:53:11 --> URI Class Initialized
INFO - 2017-03-03 21:53:11 --> Router Class Initialized
INFO - 2017-03-03 21:53:11 --> Output Class Initialized
INFO - 2017-03-03 21:53:11 --> Security Class Initialized
DEBUG - 2017-03-03 21:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:53:11 --> Input Class Initialized
INFO - 2017-03-03 21:53:11 --> Language Class Initialized
INFO - 2017-03-03 21:53:11 --> Loader Class Initialized
INFO - 2017-03-03 21:53:11 --> Database Driver Class Initialized
INFO - 2017-03-03 21:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:53:11 --> Controller Class Initialized
INFO - 2017-03-03 21:53:11 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:53:11 --> Final output sent to browser
DEBUG - 2017-03-03 21:53:11 --> Total execution time: 0.0830
INFO - 2017-03-03 21:53:14 --> Config Class Initialized
INFO - 2017-03-03 21:53:14 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:53:14 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:53:14 --> Utf8 Class Initialized
INFO - 2017-03-03 21:53:14 --> URI Class Initialized
DEBUG - 2017-03-03 21:53:14 --> No URI present. Default controller set.
INFO - 2017-03-03 21:53:14 --> Router Class Initialized
INFO - 2017-03-03 21:53:14 --> Output Class Initialized
INFO - 2017-03-03 21:53:14 --> Security Class Initialized
DEBUG - 2017-03-03 21:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:53:14 --> Input Class Initialized
INFO - 2017-03-03 21:53:14 --> Language Class Initialized
INFO - 2017-03-03 21:53:14 --> Loader Class Initialized
INFO - 2017-03-03 21:53:14 --> Database Driver Class Initialized
INFO - 2017-03-03 21:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:53:14 --> Controller Class Initialized
INFO - 2017-03-03 21:53:14 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:53:14 --> Final output sent to browser
DEBUG - 2017-03-03 21:53:14 --> Total execution time: 0.0137
INFO - 2017-03-03 21:53:15 --> Config Class Initialized
INFO - 2017-03-03 21:53:15 --> Hooks Class Initialized
DEBUG - 2017-03-03 21:53:15 --> UTF-8 Support Enabled
INFO - 2017-03-03 21:53:15 --> Utf8 Class Initialized
INFO - 2017-03-03 21:53:15 --> URI Class Initialized
INFO - 2017-03-03 21:53:15 --> Router Class Initialized
INFO - 2017-03-03 21:53:15 --> Output Class Initialized
INFO - 2017-03-03 21:53:15 --> Security Class Initialized
DEBUG - 2017-03-03 21:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 21:53:15 --> Input Class Initialized
INFO - 2017-03-03 21:53:15 --> Language Class Initialized
INFO - 2017-03-03 21:53:15 --> Loader Class Initialized
INFO - 2017-03-03 21:53:15 --> Database Driver Class Initialized
INFO - 2017-03-03 21:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 21:53:15 --> Controller Class Initialized
INFO - 2017-03-03 21:53:15 --> Helper loaded: url_helper
DEBUG - 2017-03-03 21:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 21:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 21:53:15 --> Final output sent to browser
DEBUG - 2017-03-03 21:53:15 --> Total execution time: 0.0158
INFO - 2017-03-03 22:10:48 --> Config Class Initialized
INFO - 2017-03-03 22:10:49 --> Config Class Initialized
INFO - 2017-03-03 22:10:49 --> Hooks Class Initialized
INFO - 2017-03-03 22:10:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 22:10:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 22:10:49 --> Utf8 Class Initialized
DEBUG - 2017-03-03 22:10:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 22:10:49 --> Utf8 Class Initialized
INFO - 2017-03-03 22:10:49 --> URI Class Initialized
INFO - 2017-03-03 22:10:49 --> URI Class Initialized
DEBUG - 2017-03-03 22:10:49 --> No URI present. Default controller set.
INFO - 2017-03-03 22:10:49 --> Router Class Initialized
DEBUG - 2017-03-03 22:10:49 --> No URI present. Default controller set.
INFO - 2017-03-03 22:10:49 --> Router Class Initialized
INFO - 2017-03-03 22:10:49 --> Output Class Initialized
INFO - 2017-03-03 22:10:49 --> Output Class Initialized
INFO - 2017-03-03 22:10:49 --> Security Class Initialized
INFO - 2017-03-03 22:10:49 --> Security Class Initialized
DEBUG - 2017-03-03 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 22:10:49 --> Input Class Initialized
INFO - 2017-03-03 22:10:49 --> Language Class Initialized
DEBUG - 2017-03-03 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 22:10:49 --> Input Class Initialized
INFO - 2017-03-03 22:10:49 --> Language Class Initialized
INFO - 2017-03-03 22:10:49 --> Loader Class Initialized
INFO - 2017-03-03 22:10:49 --> Loader Class Initialized
INFO - 2017-03-03 22:10:50 --> Database Driver Class Initialized
INFO - 2017-03-03 22:10:50 --> Database Driver Class Initialized
INFO - 2017-03-03 22:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 22:10:50 --> Controller Class Initialized
INFO - 2017-03-03 22:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 22:10:50 --> Helper loaded: url_helper
INFO - 2017-03-03 22:10:50 --> Controller Class Initialized
INFO - 2017-03-03 22:10:50 --> Helper loaded: url_helper
DEBUG - 2017-03-03 22:10:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-03 22:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 22:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-03 22:10:50 --> Final output sent to browser
DEBUG - 2017-03-03 22:10:50 --> Total execution time: 1.5710
INFO - 2017-03-03 22:10:50 --> Final output sent to browser
DEBUG - 2017-03-03 22:10:50 --> Total execution time: 1.5710

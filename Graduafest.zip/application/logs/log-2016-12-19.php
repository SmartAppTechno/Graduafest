<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-19 00:42:32 --> Config Class Initialized
INFO - 2016-12-19 00:42:32 --> Hooks Class Initialized
DEBUG - 2016-12-19 00:42:32 --> UTF-8 Support Enabled
INFO - 2016-12-19 00:42:32 --> Utf8 Class Initialized
INFO - 2016-12-19 00:42:32 --> URI Class Initialized
INFO - 2016-12-19 00:42:32 --> Router Class Initialized
INFO - 2016-12-19 00:42:32 --> Output Class Initialized
INFO - 2016-12-19 00:42:32 --> Security Class Initialized
DEBUG - 2016-12-19 00:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 00:42:32 --> Input Class Initialized
INFO - 2016-12-19 00:42:32 --> Language Class Initialized
INFO - 2016-12-19 00:42:32 --> Loader Class Initialized
INFO - 2016-12-19 00:42:33 --> Database Driver Class Initialized
INFO - 2016-12-19 00:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 00:42:33 --> Controller Class Initialized
INFO - 2016-12-19 00:42:33 --> Helper loaded: url_helper
DEBUG - 2016-12-19 00:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 00:42:33 --> Helper loaded: form_helper
INFO - 2016-12-19 00:42:33 --> Form Validation Class Initialized
INFO - 2016-12-19 00:42:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-19 00:42:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-19 00:42:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-19 00:42:33 --> Final output sent to browser
DEBUG - 2016-12-19 00:42:33 --> Total execution time: 1.0927
INFO - 2016-12-19 00:42:37 --> Config Class Initialized
INFO - 2016-12-19 00:42:37 --> Hooks Class Initialized
DEBUG - 2016-12-19 00:42:37 --> UTF-8 Support Enabled
INFO - 2016-12-19 00:42:37 --> Utf8 Class Initialized
INFO - 2016-12-19 00:42:37 --> URI Class Initialized
INFO - 2016-12-19 00:42:37 --> Router Class Initialized
INFO - 2016-12-19 00:42:37 --> Output Class Initialized
INFO - 2016-12-19 00:42:37 --> Security Class Initialized
DEBUG - 2016-12-19 00:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 00:42:37 --> Input Class Initialized
INFO - 2016-12-19 00:42:37 --> Language Class Initialized
INFO - 2016-12-19 00:42:37 --> Loader Class Initialized
INFO - 2016-12-19 00:42:37 --> Database Driver Class Initialized
INFO - 2016-12-19 00:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 00:42:37 --> Controller Class Initialized
INFO - 2016-12-19 00:42:37 --> Helper loaded: url_helper
DEBUG - 2016-12-19 00:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 00:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 00:42:37 --> Final output sent to browser
DEBUG - 2016-12-19 00:42:37 --> Total execution time: 0.2141
INFO - 2016-12-19 00:42:41 --> Config Class Initialized
INFO - 2016-12-19 00:42:41 --> Hooks Class Initialized
DEBUG - 2016-12-19 00:42:41 --> UTF-8 Support Enabled
INFO - 2016-12-19 00:42:41 --> Utf8 Class Initialized
INFO - 2016-12-19 00:42:41 --> URI Class Initialized
INFO - 2016-12-19 00:42:41 --> Router Class Initialized
INFO - 2016-12-19 00:42:41 --> Output Class Initialized
INFO - 2016-12-19 00:42:41 --> Security Class Initialized
DEBUG - 2016-12-19 00:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 00:42:41 --> Input Class Initialized
INFO - 2016-12-19 00:42:41 --> Language Class Initialized
INFO - 2016-12-19 00:42:41 --> Loader Class Initialized
INFO - 2016-12-19 00:42:41 --> Database Driver Class Initialized
INFO - 2016-12-19 00:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 00:42:41 --> Controller Class Initialized
INFO - 2016-12-19 00:42:41 --> Helper loaded: url_helper
DEBUG - 2016-12-19 00:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 00:42:41 --> Helper loaded: form_helper
INFO - 2016-12-19 00:42:41 --> Form Validation Class Initialized
INFO - 2016-12-19 00:42:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-19 00:42:41 --> Config Class Initialized
INFO - 2016-12-19 00:42:41 --> Hooks Class Initialized
DEBUG - 2016-12-19 00:42:41 --> UTF-8 Support Enabled
INFO - 2016-12-19 00:42:41 --> Utf8 Class Initialized
INFO - 2016-12-19 00:42:41 --> URI Class Initialized
INFO - 2016-12-19 00:42:41 --> Router Class Initialized
INFO - 2016-12-19 00:42:41 --> Output Class Initialized
INFO - 2016-12-19 00:42:41 --> Security Class Initialized
DEBUG - 2016-12-19 00:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 00:42:41 --> Input Class Initialized
INFO - 2016-12-19 00:42:41 --> Language Class Initialized
INFO - 2016-12-19 00:42:41 --> Loader Class Initialized
INFO - 2016-12-19 00:42:41 --> Database Driver Class Initialized
INFO - 2016-12-19 00:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 00:42:41 --> Controller Class Initialized
INFO - 2016-12-19 00:42:41 --> Helper loaded: date_helper
INFO - 2016-12-19 00:42:41 --> Helper loaded: url_helper
DEBUG - 2016-12-19 00:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 00:42:41 --> Helper loaded: form_helper
INFO - 2016-12-19 00:42:41 --> Form Validation Class Initialized
INFO - 2016-12-19 00:42:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-19 00:42:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-19 00:42:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-19 00:42:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-19 00:42:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-19 00:42:41 --> Final output sent to browser
DEBUG - 2016-12-19 00:42:41 --> Total execution time: 0.1177
INFO - 2016-12-19 00:42:42 --> Config Class Initialized
INFO - 2016-12-19 00:42:42 --> Hooks Class Initialized
DEBUG - 2016-12-19 00:42:42 --> UTF-8 Support Enabled
INFO - 2016-12-19 00:42:42 --> Utf8 Class Initialized
INFO - 2016-12-19 00:42:42 --> URI Class Initialized
INFO - 2016-12-19 00:42:42 --> Router Class Initialized
INFO - 2016-12-19 00:42:42 --> Output Class Initialized
INFO - 2016-12-19 00:42:42 --> Security Class Initialized
DEBUG - 2016-12-19 00:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 00:42:42 --> Input Class Initialized
INFO - 2016-12-19 00:42:42 --> Language Class Initialized
INFO - 2016-12-19 00:42:42 --> Loader Class Initialized
INFO - 2016-12-19 00:42:42 --> Database Driver Class Initialized
INFO - 2016-12-19 00:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 00:42:42 --> Controller Class Initialized
INFO - 2016-12-19 00:42:42 --> Helper loaded: date_helper
INFO - 2016-12-19 00:42:42 --> Helper loaded: url_helper
DEBUG - 2016-12-19 00:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 00:42:42 --> Config Class Initialized
INFO - 2016-12-19 00:42:42 --> Hooks Class Initialized
DEBUG - 2016-12-19 00:42:42 --> UTF-8 Support Enabled
INFO - 2016-12-19 00:42:42 --> Utf8 Class Initialized
INFO - 2016-12-19 00:42:42 --> URI Class Initialized
INFO - 2016-12-19 00:42:42 --> Helper loaded: form_helper
INFO - 2016-12-19 00:42:42 --> Form Validation Class Initialized
INFO - 2016-12-19 00:42:42 --> Router Class Initialized
INFO - 2016-12-19 00:42:42 --> Output Class Initialized
INFO - 2016-12-19 00:42:42 --> Security Class Initialized
DEBUG - 2016-12-19 00:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 00:42:42 --> Input Class Initialized
INFO - 2016-12-19 00:42:42 --> Language Class Initialized
INFO - 2016-12-19 00:42:42 --> Loader Class Initialized
INFO - 2016-12-19 00:42:42 --> Database Driver Class Initialized
INFO - 2016-12-19 00:42:42 --> Final output sent to browser
DEBUG - 2016-12-19 00:42:42 --> Total execution time: 0.0784
INFO - 2016-12-19 00:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 00:42:42 --> Controller Class Initialized
INFO - 2016-12-19 00:42:42 --> Helper loaded: url_helper
DEBUG - 2016-12-19 00:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 00:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 00:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 00:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 00:42:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 00:42:42 --> Final output sent to browser
DEBUG - 2016-12-19 00:42:42 --> Total execution time: 0.0785
INFO - 2016-12-19 00:42:46 --> Config Class Initialized
INFO - 2016-12-19 00:42:46 --> Hooks Class Initialized
DEBUG - 2016-12-19 00:42:46 --> UTF-8 Support Enabled
INFO - 2016-12-19 00:42:46 --> Utf8 Class Initialized
INFO - 2016-12-19 00:42:46 --> URI Class Initialized
INFO - 2016-12-19 00:42:46 --> Router Class Initialized
INFO - 2016-12-19 00:42:46 --> Output Class Initialized
INFO - 2016-12-19 00:42:46 --> Security Class Initialized
DEBUG - 2016-12-19 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 00:42:46 --> Input Class Initialized
INFO - 2016-12-19 00:42:46 --> Language Class Initialized
INFO - 2016-12-19 00:42:46 --> Loader Class Initialized
INFO - 2016-12-19 00:42:46 --> Database Driver Class Initialized
INFO - 2016-12-19 00:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 00:42:46 --> Controller Class Initialized
INFO - 2016-12-19 00:42:46 --> Helper loaded: url_helper
DEBUG - 2016-12-19 00:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 00:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 00:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 00:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 00:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 00:42:46 --> Final output sent to browser
DEBUG - 2016-12-19 00:42:46 --> Total execution time: 0.0132
INFO - 2016-12-19 01:08:48 --> Config Class Initialized
INFO - 2016-12-19 01:08:48 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:08:48 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:08:48 --> Utf8 Class Initialized
INFO - 2016-12-19 01:08:48 --> URI Class Initialized
INFO - 2016-12-19 01:08:48 --> Router Class Initialized
INFO - 2016-12-19 01:08:48 --> Output Class Initialized
INFO - 2016-12-19 01:08:48 --> Security Class Initialized
DEBUG - 2016-12-19 01:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:08:48 --> Input Class Initialized
INFO - 2016-12-19 01:08:48 --> Language Class Initialized
INFO - 2016-12-19 01:08:48 --> Loader Class Initialized
INFO - 2016-12-19 01:08:49 --> Database Driver Class Initialized
INFO - 2016-12-19 01:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:08:49 --> Controller Class Initialized
INFO - 2016-12-19 01:08:49 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:08:49 --> Config Class Initialized
INFO - 2016-12-19 01:08:49 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:08:49 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:08:49 --> Utf8 Class Initialized
INFO - 2016-12-19 01:08:49 --> URI Class Initialized
INFO - 2016-12-19 01:08:49 --> Router Class Initialized
INFO - 2016-12-19 01:08:49 --> Output Class Initialized
INFO - 2016-12-19 01:08:49 --> Security Class Initialized
DEBUG - 2016-12-19 01:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:08:49 --> Input Class Initialized
INFO - 2016-12-19 01:08:49 --> Language Class Initialized
INFO - 2016-12-19 01:08:49 --> Loader Class Initialized
INFO - 2016-12-19 01:08:49 --> Database Driver Class Initialized
INFO - 2016-12-19 01:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:08:49 --> Controller Class Initialized
INFO - 2016-12-19 01:08:49 --> Helper loaded: date_helper
INFO - 2016-12-19 01:08:49 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:08:49 --> Helper loaded: form_helper
INFO - 2016-12-19 01:08:49 --> Form Validation Class Initialized
INFO - 2016-12-19 01:08:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-19 01:08:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-19 01:08:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-19 01:08:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-19 01:08:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-19 01:08:49 --> Final output sent to browser
DEBUG - 2016-12-19 01:08:49 --> Total execution time: 0.2713
INFO - 2016-12-19 01:08:50 --> Config Class Initialized
INFO - 2016-12-19 01:08:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:08:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:08:50 --> Utf8 Class Initialized
INFO - 2016-12-19 01:08:50 --> URI Class Initialized
INFO - 2016-12-19 01:08:50 --> Router Class Initialized
INFO - 2016-12-19 01:08:50 --> Output Class Initialized
INFO - 2016-12-19 01:08:50 --> Security Class Initialized
DEBUG - 2016-12-19 01:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:08:50 --> Input Class Initialized
INFO - 2016-12-19 01:08:50 --> Language Class Initialized
INFO - 2016-12-19 01:08:50 --> Loader Class Initialized
INFO - 2016-12-19 01:08:50 --> Database Driver Class Initialized
INFO - 2016-12-19 01:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:08:50 --> Controller Class Initialized
INFO - 2016-12-19 01:08:50 --> Helper loaded: date_helper
INFO - 2016-12-19 01:08:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:08:50 --> Helper loaded: form_helper
INFO - 2016-12-19 01:08:50 --> Form Validation Class Initialized
INFO - 2016-12-19 01:08:50 --> Final output sent to browser
DEBUG - 2016-12-19 01:08:50 --> Total execution time: 0.0148
INFO - 2016-12-19 01:08:50 --> Config Class Initialized
INFO - 2016-12-19 01:08:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:08:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:08:50 --> Utf8 Class Initialized
INFO - 2016-12-19 01:08:50 --> URI Class Initialized
INFO - 2016-12-19 01:08:50 --> Router Class Initialized
INFO - 2016-12-19 01:08:50 --> Output Class Initialized
INFO - 2016-12-19 01:08:50 --> Security Class Initialized
DEBUG - 2016-12-19 01:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:08:50 --> Input Class Initialized
INFO - 2016-12-19 01:08:50 --> Language Class Initialized
INFO - 2016-12-19 01:08:50 --> Loader Class Initialized
INFO - 2016-12-19 01:08:50 --> Database Driver Class Initialized
INFO - 2016-12-19 01:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:08:50 --> Controller Class Initialized
INFO - 2016-12-19 01:08:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:08:50 --> Final output sent to browser
DEBUG - 2016-12-19 01:08:50 --> Total execution time: 0.1507
INFO - 2016-12-19 01:16:22 --> Config Class Initialized
INFO - 2016-12-19 01:16:22 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:16:22 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:16:22 --> Utf8 Class Initialized
INFO - 2016-12-19 01:16:22 --> URI Class Initialized
DEBUG - 2016-12-19 01:16:22 --> No URI present. Default controller set.
INFO - 2016-12-19 01:16:22 --> Router Class Initialized
INFO - 2016-12-19 01:16:22 --> Output Class Initialized
INFO - 2016-12-19 01:16:22 --> Security Class Initialized
DEBUG - 2016-12-19 01:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:16:22 --> Input Class Initialized
INFO - 2016-12-19 01:16:22 --> Language Class Initialized
INFO - 2016-12-19 01:16:22 --> Loader Class Initialized
INFO - 2016-12-19 01:16:22 --> Database Driver Class Initialized
INFO - 2016-12-19 01:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:16:22 --> Controller Class Initialized
INFO - 2016-12-19 01:16:22 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:16:22 --> Final output sent to browser
DEBUG - 2016-12-19 01:16:22 --> Total execution time: 0.0504
INFO - 2016-12-19 01:16:28 --> Config Class Initialized
INFO - 2016-12-19 01:16:28 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:16:28 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:16:28 --> Utf8 Class Initialized
INFO - 2016-12-19 01:16:28 --> URI Class Initialized
INFO - 2016-12-19 01:16:28 --> Router Class Initialized
INFO - 2016-12-19 01:16:28 --> Output Class Initialized
INFO - 2016-12-19 01:16:28 --> Security Class Initialized
DEBUG - 2016-12-19 01:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:16:28 --> Input Class Initialized
INFO - 2016-12-19 01:16:28 --> Language Class Initialized
INFO - 2016-12-19 01:16:28 --> Loader Class Initialized
INFO - 2016-12-19 01:16:28 --> Database Driver Class Initialized
INFO - 2016-12-19 01:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:16:28 --> Controller Class Initialized
INFO - 2016-12-19 01:16:28 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:16:28 --> Final output sent to browser
DEBUG - 2016-12-19 01:16:28 --> Total execution time: 0.0132
INFO - 2016-12-19 01:16:50 --> Config Class Initialized
INFO - 2016-12-19 01:16:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:16:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:16:50 --> Utf8 Class Initialized
INFO - 2016-12-19 01:16:50 --> URI Class Initialized
DEBUG - 2016-12-19 01:16:50 --> No URI present. Default controller set.
INFO - 2016-12-19 01:16:50 --> Router Class Initialized
INFO - 2016-12-19 01:16:50 --> Output Class Initialized
INFO - 2016-12-19 01:16:50 --> Security Class Initialized
DEBUG - 2016-12-19 01:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:16:50 --> Input Class Initialized
INFO - 2016-12-19 01:16:50 --> Language Class Initialized
INFO - 2016-12-19 01:16:50 --> Loader Class Initialized
INFO - 2016-12-19 01:16:50 --> Database Driver Class Initialized
INFO - 2016-12-19 01:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:16:50 --> Controller Class Initialized
INFO - 2016-12-19 01:16:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:16:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:16:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:16:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:16:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:16:50 --> Final output sent to browser
DEBUG - 2016-12-19 01:16:50 --> Total execution time: 0.0136
INFO - 2016-12-19 01:16:51 --> Config Class Initialized
INFO - 2016-12-19 01:16:51 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:16:51 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:16:51 --> Utf8 Class Initialized
INFO - 2016-12-19 01:16:51 --> URI Class Initialized
INFO - 2016-12-19 01:16:51 --> Router Class Initialized
INFO - 2016-12-19 01:16:51 --> Output Class Initialized
INFO - 2016-12-19 01:16:51 --> Security Class Initialized
DEBUG - 2016-12-19 01:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:16:51 --> Input Class Initialized
INFO - 2016-12-19 01:16:51 --> Language Class Initialized
INFO - 2016-12-19 01:16:51 --> Loader Class Initialized
INFO - 2016-12-19 01:16:51 --> Database Driver Class Initialized
INFO - 2016-12-19 01:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:16:51 --> Controller Class Initialized
INFO - 2016-12-19 01:16:51 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:16:51 --> Final output sent to browser
DEBUG - 2016-12-19 01:16:51 --> Total execution time: 0.0130
INFO - 2016-12-19 01:17:05 --> Config Class Initialized
INFO - 2016-12-19 01:17:05 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:17:05 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:17:05 --> Utf8 Class Initialized
INFO - 2016-12-19 01:17:05 --> URI Class Initialized
DEBUG - 2016-12-19 01:17:05 --> No URI present. Default controller set.
INFO - 2016-12-19 01:17:05 --> Router Class Initialized
INFO - 2016-12-19 01:17:05 --> Output Class Initialized
INFO - 2016-12-19 01:17:05 --> Security Class Initialized
DEBUG - 2016-12-19 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:17:05 --> Input Class Initialized
INFO - 2016-12-19 01:17:05 --> Language Class Initialized
INFO - 2016-12-19 01:17:05 --> Loader Class Initialized
INFO - 2016-12-19 01:17:05 --> Database Driver Class Initialized
INFO - 2016-12-19 01:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:17:05 --> Controller Class Initialized
INFO - 2016-12-19 01:17:05 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:17:05 --> Final output sent to browser
DEBUG - 2016-12-19 01:17:05 --> Total execution time: 0.0132
INFO - 2016-12-19 01:17:09 --> Config Class Initialized
INFO - 2016-12-19 01:17:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:17:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:17:09 --> Utf8 Class Initialized
INFO - 2016-12-19 01:17:09 --> URI Class Initialized
INFO - 2016-12-19 01:17:09 --> Router Class Initialized
INFO - 2016-12-19 01:17:09 --> Output Class Initialized
INFO - 2016-12-19 01:17:09 --> Security Class Initialized
DEBUG - 2016-12-19 01:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:17:09 --> Input Class Initialized
INFO - 2016-12-19 01:17:09 --> Language Class Initialized
INFO - 2016-12-19 01:17:09 --> Loader Class Initialized
INFO - 2016-12-19 01:17:09 --> Database Driver Class Initialized
INFO - 2016-12-19 01:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:17:09 --> Controller Class Initialized
INFO - 2016-12-19 01:17:09 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:17:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:17:09 --> Final output sent to browser
DEBUG - 2016-12-19 01:17:09 --> Total execution time: 0.0147
INFO - 2016-12-19 01:17:29 --> Config Class Initialized
INFO - 2016-12-19 01:17:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:17:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:17:29 --> Utf8 Class Initialized
INFO - 2016-12-19 01:17:29 --> URI Class Initialized
DEBUG - 2016-12-19 01:17:29 --> No URI present. Default controller set.
INFO - 2016-12-19 01:17:29 --> Router Class Initialized
INFO - 2016-12-19 01:17:29 --> Output Class Initialized
INFO - 2016-12-19 01:17:29 --> Security Class Initialized
DEBUG - 2016-12-19 01:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:17:29 --> Input Class Initialized
INFO - 2016-12-19 01:17:29 --> Language Class Initialized
INFO - 2016-12-19 01:17:29 --> Loader Class Initialized
INFO - 2016-12-19 01:17:29 --> Database Driver Class Initialized
INFO - 2016-12-19 01:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:17:29 --> Controller Class Initialized
INFO - 2016-12-19 01:17:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:17:29 --> Final output sent to browser
DEBUG - 2016-12-19 01:17:29 --> Total execution time: 0.0128
INFO - 2016-12-19 01:17:29 --> Config Class Initialized
INFO - 2016-12-19 01:17:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:17:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:17:29 --> Utf8 Class Initialized
INFO - 2016-12-19 01:17:29 --> URI Class Initialized
INFO - 2016-12-19 01:17:29 --> Router Class Initialized
INFO - 2016-12-19 01:17:29 --> Output Class Initialized
INFO - 2016-12-19 01:17:29 --> Security Class Initialized
DEBUG - 2016-12-19 01:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:17:29 --> Input Class Initialized
INFO - 2016-12-19 01:17:29 --> Language Class Initialized
INFO - 2016-12-19 01:17:29 --> Loader Class Initialized
INFO - 2016-12-19 01:17:29 --> Database Driver Class Initialized
INFO - 2016-12-19 01:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:17:29 --> Controller Class Initialized
INFO - 2016-12-19 01:17:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:17:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:17:29 --> Final output sent to browser
DEBUG - 2016-12-19 01:17:29 --> Total execution time: 0.0141
INFO - 2016-12-19 01:18:29 --> Config Class Initialized
INFO - 2016-12-19 01:18:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:18:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:18:29 --> Utf8 Class Initialized
INFO - 2016-12-19 01:18:29 --> URI Class Initialized
DEBUG - 2016-12-19 01:18:29 --> No URI present. Default controller set.
INFO - 2016-12-19 01:18:29 --> Router Class Initialized
INFO - 2016-12-19 01:18:29 --> Output Class Initialized
INFO - 2016-12-19 01:18:29 --> Security Class Initialized
DEBUG - 2016-12-19 01:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:18:29 --> Input Class Initialized
INFO - 2016-12-19 01:18:29 --> Language Class Initialized
INFO - 2016-12-19 01:18:29 --> Loader Class Initialized
INFO - 2016-12-19 01:18:29 --> Database Driver Class Initialized
INFO - 2016-12-19 01:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:18:29 --> Controller Class Initialized
INFO - 2016-12-19 01:18:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:18:29 --> Final output sent to browser
DEBUG - 2016-12-19 01:18:29 --> Total execution time: 0.0138
INFO - 2016-12-19 01:18:44 --> Config Class Initialized
INFO - 2016-12-19 01:18:44 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:18:44 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:18:44 --> Utf8 Class Initialized
INFO - 2016-12-19 01:18:44 --> URI Class Initialized
DEBUG - 2016-12-19 01:18:44 --> No URI present. Default controller set.
INFO - 2016-12-19 01:18:44 --> Router Class Initialized
INFO - 2016-12-19 01:18:44 --> Output Class Initialized
INFO - 2016-12-19 01:18:44 --> Security Class Initialized
DEBUG - 2016-12-19 01:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:18:44 --> Input Class Initialized
INFO - 2016-12-19 01:18:44 --> Language Class Initialized
INFO - 2016-12-19 01:18:44 --> Loader Class Initialized
INFO - 2016-12-19 01:18:44 --> Database Driver Class Initialized
INFO - 2016-12-19 01:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:18:44 --> Controller Class Initialized
INFO - 2016-12-19 01:18:44 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:18:44 --> Final output sent to browser
DEBUG - 2016-12-19 01:18:44 --> Total execution time: 0.0224
INFO - 2016-12-19 01:18:55 --> Config Class Initialized
INFO - 2016-12-19 01:18:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:18:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:18:55 --> Utf8 Class Initialized
INFO - 2016-12-19 01:18:55 --> URI Class Initialized
DEBUG - 2016-12-19 01:18:55 --> No URI present. Default controller set.
INFO - 2016-12-19 01:18:55 --> Router Class Initialized
INFO - 2016-12-19 01:18:55 --> Output Class Initialized
INFO - 2016-12-19 01:18:55 --> Security Class Initialized
DEBUG - 2016-12-19 01:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:18:55 --> Input Class Initialized
INFO - 2016-12-19 01:18:55 --> Language Class Initialized
INFO - 2016-12-19 01:18:55 --> Loader Class Initialized
INFO - 2016-12-19 01:18:55 --> Database Driver Class Initialized
INFO - 2016-12-19 01:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:18:55 --> Controller Class Initialized
INFO - 2016-12-19 01:18:55 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:18:55 --> Final output sent to browser
DEBUG - 2016-12-19 01:18:55 --> Total execution time: 0.0132
INFO - 2016-12-19 01:19:15 --> Config Class Initialized
INFO - 2016-12-19 01:19:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:19:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:19:15 --> Utf8 Class Initialized
INFO - 2016-12-19 01:19:15 --> URI Class Initialized
DEBUG - 2016-12-19 01:19:15 --> No URI present. Default controller set.
INFO - 2016-12-19 01:19:15 --> Router Class Initialized
INFO - 2016-12-19 01:19:15 --> Output Class Initialized
INFO - 2016-12-19 01:19:15 --> Security Class Initialized
DEBUG - 2016-12-19 01:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:19:15 --> Input Class Initialized
INFO - 2016-12-19 01:19:15 --> Language Class Initialized
INFO - 2016-12-19 01:19:15 --> Loader Class Initialized
INFO - 2016-12-19 01:19:15 --> Database Driver Class Initialized
INFO - 2016-12-19 01:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:19:15 --> Controller Class Initialized
INFO - 2016-12-19 01:19:15 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:19:15 --> Final output sent to browser
DEBUG - 2016-12-19 01:19:15 --> Total execution time: 0.0273
INFO - 2016-12-19 01:19:25 --> Config Class Initialized
INFO - 2016-12-19 01:19:25 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:19:25 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:19:25 --> Utf8 Class Initialized
INFO - 2016-12-19 01:19:25 --> URI Class Initialized
DEBUG - 2016-12-19 01:19:25 --> No URI present. Default controller set.
INFO - 2016-12-19 01:19:25 --> Router Class Initialized
INFO - 2016-12-19 01:19:25 --> Output Class Initialized
INFO - 2016-12-19 01:19:25 --> Security Class Initialized
DEBUG - 2016-12-19 01:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:19:25 --> Input Class Initialized
INFO - 2016-12-19 01:19:25 --> Language Class Initialized
INFO - 2016-12-19 01:19:25 --> Loader Class Initialized
INFO - 2016-12-19 01:19:25 --> Database Driver Class Initialized
INFO - 2016-12-19 01:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:19:25 --> Controller Class Initialized
INFO - 2016-12-19 01:19:25 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:19:25 --> Final output sent to browser
DEBUG - 2016-12-19 01:19:25 --> Total execution time: 0.0126
INFO - 2016-12-19 01:19:27 --> Config Class Initialized
INFO - 2016-12-19 01:19:27 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:19:27 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:19:27 --> Utf8 Class Initialized
INFO - 2016-12-19 01:19:27 --> URI Class Initialized
DEBUG - 2016-12-19 01:19:27 --> No URI present. Default controller set.
INFO - 2016-12-19 01:19:27 --> Router Class Initialized
INFO - 2016-12-19 01:19:27 --> Output Class Initialized
INFO - 2016-12-19 01:19:27 --> Security Class Initialized
DEBUG - 2016-12-19 01:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:19:27 --> Input Class Initialized
INFO - 2016-12-19 01:19:27 --> Language Class Initialized
INFO - 2016-12-19 01:19:27 --> Loader Class Initialized
INFO - 2016-12-19 01:19:27 --> Database Driver Class Initialized
INFO - 2016-12-19 01:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:19:27 --> Controller Class Initialized
INFO - 2016-12-19 01:19:27 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:19:27 --> Final output sent to browser
DEBUG - 2016-12-19 01:19:27 --> Total execution time: 0.0128
INFO - 2016-12-19 01:19:28 --> Config Class Initialized
INFO - 2016-12-19 01:19:28 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:19:28 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:19:28 --> Utf8 Class Initialized
INFO - 2016-12-19 01:19:28 --> URI Class Initialized
INFO - 2016-12-19 01:19:28 --> Router Class Initialized
INFO - 2016-12-19 01:19:28 --> Output Class Initialized
INFO - 2016-12-19 01:19:28 --> Security Class Initialized
DEBUG - 2016-12-19 01:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:19:28 --> Input Class Initialized
INFO - 2016-12-19 01:19:28 --> Language Class Initialized
INFO - 2016-12-19 01:19:28 --> Loader Class Initialized
INFO - 2016-12-19 01:19:28 --> Database Driver Class Initialized
INFO - 2016-12-19 01:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:19:28 --> Controller Class Initialized
INFO - 2016-12-19 01:19:28 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:19:28 --> Final output sent to browser
DEBUG - 2016-12-19 01:19:28 --> Total execution time: 0.0130
INFO - 2016-12-19 01:19:31 --> Config Class Initialized
INFO - 2016-12-19 01:19:31 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:19:31 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:19:31 --> Utf8 Class Initialized
INFO - 2016-12-19 01:19:31 --> URI Class Initialized
DEBUG - 2016-12-19 01:19:31 --> No URI present. Default controller set.
INFO - 2016-12-19 01:19:31 --> Router Class Initialized
INFO - 2016-12-19 01:19:31 --> Output Class Initialized
INFO - 2016-12-19 01:19:31 --> Security Class Initialized
DEBUG - 2016-12-19 01:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:19:31 --> Input Class Initialized
INFO - 2016-12-19 01:19:31 --> Language Class Initialized
INFO - 2016-12-19 01:19:31 --> Loader Class Initialized
INFO - 2016-12-19 01:19:31 --> Database Driver Class Initialized
INFO - 2016-12-19 01:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:19:31 --> Controller Class Initialized
INFO - 2016-12-19 01:19:31 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:19:31 --> Final output sent to browser
DEBUG - 2016-12-19 01:19:31 --> Total execution time: 0.0129
INFO - 2016-12-19 01:24:28 --> Config Class Initialized
INFO - 2016-12-19 01:24:28 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:24:28 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:24:28 --> Utf8 Class Initialized
INFO - 2016-12-19 01:24:28 --> URI Class Initialized
DEBUG - 2016-12-19 01:24:28 --> No URI present. Default controller set.
INFO - 2016-12-19 01:24:28 --> Router Class Initialized
INFO - 2016-12-19 01:24:28 --> Output Class Initialized
INFO - 2016-12-19 01:24:28 --> Security Class Initialized
DEBUG - 2016-12-19 01:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:24:28 --> Input Class Initialized
INFO - 2016-12-19 01:24:28 --> Language Class Initialized
INFO - 2016-12-19 01:24:28 --> Loader Class Initialized
INFO - 2016-12-19 01:24:28 --> Database Driver Class Initialized
INFO - 2016-12-19 01:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:24:28 --> Controller Class Initialized
INFO - 2016-12-19 01:24:28 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:24:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:24:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:24:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:24:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:24:28 --> Final output sent to browser
DEBUG - 2016-12-19 01:24:28 --> Total execution time: 0.0368
INFO - 2016-12-19 01:24:29 --> Config Class Initialized
INFO - 2016-12-19 01:24:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:24:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:24:29 --> Utf8 Class Initialized
INFO - 2016-12-19 01:24:29 --> URI Class Initialized
INFO - 2016-12-19 01:24:29 --> Router Class Initialized
INFO - 2016-12-19 01:24:29 --> Output Class Initialized
INFO - 2016-12-19 01:24:29 --> Security Class Initialized
DEBUG - 2016-12-19 01:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:24:29 --> Input Class Initialized
INFO - 2016-12-19 01:24:29 --> Language Class Initialized
INFO - 2016-12-19 01:24:29 --> Loader Class Initialized
INFO - 2016-12-19 01:24:29 --> Database Driver Class Initialized
INFO - 2016-12-19 01:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:24:29 --> Controller Class Initialized
INFO - 2016-12-19 01:24:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:24:29 --> Final output sent to browser
DEBUG - 2016-12-19 01:24:29 --> Total execution time: 0.0136
INFO - 2016-12-19 01:24:32 --> Config Class Initialized
INFO - 2016-12-19 01:24:32 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:24:32 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:24:32 --> Utf8 Class Initialized
INFO - 2016-12-19 01:24:32 --> URI Class Initialized
DEBUG - 2016-12-19 01:24:32 --> No URI present. Default controller set.
INFO - 2016-12-19 01:24:32 --> Router Class Initialized
INFO - 2016-12-19 01:24:32 --> Output Class Initialized
INFO - 2016-12-19 01:24:32 --> Security Class Initialized
DEBUG - 2016-12-19 01:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:24:32 --> Input Class Initialized
INFO - 2016-12-19 01:24:32 --> Language Class Initialized
INFO - 2016-12-19 01:24:32 --> Loader Class Initialized
INFO - 2016-12-19 01:24:32 --> Database Driver Class Initialized
INFO - 2016-12-19 01:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:24:32 --> Controller Class Initialized
INFO - 2016-12-19 01:24:32 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:24:32 --> Final output sent to browser
DEBUG - 2016-12-19 01:24:32 --> Total execution time: 0.0129
INFO - 2016-12-19 01:24:32 --> Config Class Initialized
INFO - 2016-12-19 01:24:32 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:24:32 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:24:32 --> Utf8 Class Initialized
INFO - 2016-12-19 01:24:32 --> URI Class Initialized
INFO - 2016-12-19 01:24:32 --> Router Class Initialized
INFO - 2016-12-19 01:24:32 --> Output Class Initialized
INFO - 2016-12-19 01:24:32 --> Security Class Initialized
DEBUG - 2016-12-19 01:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:24:32 --> Input Class Initialized
INFO - 2016-12-19 01:24:32 --> Language Class Initialized
INFO - 2016-12-19 01:24:32 --> Loader Class Initialized
INFO - 2016-12-19 01:24:32 --> Database Driver Class Initialized
INFO - 2016-12-19 01:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:24:32 --> Controller Class Initialized
INFO - 2016-12-19 01:24:32 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:24:32 --> Final output sent to browser
DEBUG - 2016-12-19 01:24:32 --> Total execution time: 0.0131
INFO - 2016-12-19 01:25:00 --> Config Class Initialized
INFO - 2016-12-19 01:25:00 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:25:00 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:25:00 --> Utf8 Class Initialized
INFO - 2016-12-19 01:25:00 --> URI Class Initialized
DEBUG - 2016-12-19 01:25:00 --> No URI present. Default controller set.
INFO - 2016-12-19 01:25:00 --> Router Class Initialized
INFO - 2016-12-19 01:25:00 --> Output Class Initialized
INFO - 2016-12-19 01:25:00 --> Security Class Initialized
DEBUG - 2016-12-19 01:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:25:00 --> Input Class Initialized
INFO - 2016-12-19 01:25:00 --> Language Class Initialized
INFO - 2016-12-19 01:25:00 --> Loader Class Initialized
INFO - 2016-12-19 01:25:00 --> Database Driver Class Initialized
INFO - 2016-12-19 01:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:25:00 --> Controller Class Initialized
INFO - 2016-12-19 01:25:00 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:25:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:25:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:25:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:25:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:25:00 --> Final output sent to browser
DEBUG - 2016-12-19 01:25:00 --> Total execution time: 0.0132
INFO - 2016-12-19 01:25:01 --> Config Class Initialized
INFO - 2016-12-19 01:25:01 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:25:01 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:25:01 --> Utf8 Class Initialized
INFO - 2016-12-19 01:25:01 --> URI Class Initialized
INFO - 2016-12-19 01:25:01 --> Router Class Initialized
INFO - 2016-12-19 01:25:01 --> Output Class Initialized
INFO - 2016-12-19 01:25:01 --> Security Class Initialized
DEBUG - 2016-12-19 01:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:25:01 --> Input Class Initialized
INFO - 2016-12-19 01:25:01 --> Language Class Initialized
INFO - 2016-12-19 01:25:01 --> Loader Class Initialized
INFO - 2016-12-19 01:25:01 --> Database Driver Class Initialized
INFO - 2016-12-19 01:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:25:01 --> Controller Class Initialized
INFO - 2016-12-19 01:25:01 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:25:01 --> Final output sent to browser
DEBUG - 2016-12-19 01:25:01 --> Total execution time: 0.0131
INFO - 2016-12-19 01:26:03 --> Config Class Initialized
INFO - 2016-12-19 01:26:03 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:26:03 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:26:03 --> Utf8 Class Initialized
INFO - 2016-12-19 01:26:03 --> URI Class Initialized
DEBUG - 2016-12-19 01:26:03 --> No URI present. Default controller set.
INFO - 2016-12-19 01:26:03 --> Router Class Initialized
INFO - 2016-12-19 01:26:03 --> Output Class Initialized
INFO - 2016-12-19 01:26:03 --> Security Class Initialized
DEBUG - 2016-12-19 01:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:26:03 --> Input Class Initialized
INFO - 2016-12-19 01:26:03 --> Language Class Initialized
INFO - 2016-12-19 01:26:03 --> Loader Class Initialized
INFO - 2016-12-19 01:26:03 --> Database Driver Class Initialized
INFO - 2016-12-19 01:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:26:03 --> Controller Class Initialized
INFO - 2016-12-19 01:26:03 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:26:03 --> Final output sent to browser
DEBUG - 2016-12-19 01:26:03 --> Total execution time: 0.0128
INFO - 2016-12-19 01:26:04 --> Config Class Initialized
INFO - 2016-12-19 01:26:04 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:26:04 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:26:04 --> Utf8 Class Initialized
INFO - 2016-12-19 01:26:04 --> URI Class Initialized
INFO - 2016-12-19 01:26:04 --> Router Class Initialized
INFO - 2016-12-19 01:26:04 --> Output Class Initialized
INFO - 2016-12-19 01:26:04 --> Security Class Initialized
DEBUG - 2016-12-19 01:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:26:04 --> Input Class Initialized
INFO - 2016-12-19 01:26:04 --> Language Class Initialized
INFO - 2016-12-19 01:26:04 --> Loader Class Initialized
INFO - 2016-12-19 01:26:04 --> Database Driver Class Initialized
INFO - 2016-12-19 01:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:26:04 --> Controller Class Initialized
INFO - 2016-12-19 01:26:04 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:26:04 --> Final output sent to browser
DEBUG - 2016-12-19 01:26:04 --> Total execution time: 0.0131
INFO - 2016-12-19 01:27:35 --> Config Class Initialized
INFO - 2016-12-19 01:27:35 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:27:35 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:27:35 --> Utf8 Class Initialized
INFO - 2016-12-19 01:27:35 --> URI Class Initialized
DEBUG - 2016-12-19 01:27:35 --> No URI present. Default controller set.
INFO - 2016-12-19 01:27:35 --> Router Class Initialized
INFO - 2016-12-19 01:27:35 --> Output Class Initialized
INFO - 2016-12-19 01:27:35 --> Security Class Initialized
DEBUG - 2016-12-19 01:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:27:35 --> Input Class Initialized
INFO - 2016-12-19 01:27:35 --> Language Class Initialized
INFO - 2016-12-19 01:27:35 --> Loader Class Initialized
INFO - 2016-12-19 01:27:35 --> Database Driver Class Initialized
INFO - 2016-12-19 01:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:27:35 --> Controller Class Initialized
INFO - 2016-12-19 01:27:35 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:27:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:27:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:27:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:27:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:27:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:27:35 --> Final output sent to browser
DEBUG - 2016-12-19 01:27:35 --> Total execution time: 0.0137
INFO - 2016-12-19 01:27:36 --> Config Class Initialized
INFO - 2016-12-19 01:27:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:27:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:27:36 --> Utf8 Class Initialized
INFO - 2016-12-19 01:27:36 --> URI Class Initialized
INFO - 2016-12-19 01:27:36 --> Router Class Initialized
INFO - 2016-12-19 01:27:36 --> Output Class Initialized
INFO - 2016-12-19 01:27:36 --> Security Class Initialized
DEBUG - 2016-12-19 01:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:27:36 --> Input Class Initialized
INFO - 2016-12-19 01:27:36 --> Language Class Initialized
INFO - 2016-12-19 01:27:36 --> Loader Class Initialized
INFO - 2016-12-19 01:27:36 --> Database Driver Class Initialized
INFO - 2016-12-19 01:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:27:36 --> Controller Class Initialized
INFO - 2016-12-19 01:27:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:27:36 --> Final output sent to browser
DEBUG - 2016-12-19 01:27:36 --> Total execution time: 0.0147
INFO - 2016-12-19 01:35:17 --> Config Class Initialized
INFO - 2016-12-19 01:35:17 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:35:17 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:35:17 --> Utf8 Class Initialized
INFO - 2016-12-19 01:35:17 --> URI Class Initialized
DEBUG - 2016-12-19 01:35:17 --> No URI present. Default controller set.
INFO - 2016-12-19 01:35:17 --> Router Class Initialized
INFO - 2016-12-19 01:35:17 --> Output Class Initialized
INFO - 2016-12-19 01:35:17 --> Security Class Initialized
DEBUG - 2016-12-19 01:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:35:17 --> Input Class Initialized
INFO - 2016-12-19 01:35:17 --> Language Class Initialized
INFO - 2016-12-19 01:35:17 --> Loader Class Initialized
INFO - 2016-12-19 01:35:17 --> Database Driver Class Initialized
INFO - 2016-12-19 01:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:35:17 --> Controller Class Initialized
INFO - 2016-12-19 01:35:17 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:35:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:35:17 --> Final output sent to browser
DEBUG - 2016-12-19 01:35:17 --> Total execution time: 0.0145
INFO - 2016-12-19 01:35:18 --> Config Class Initialized
INFO - 2016-12-19 01:35:18 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:35:18 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:35:18 --> Utf8 Class Initialized
INFO - 2016-12-19 01:35:18 --> URI Class Initialized
INFO - 2016-12-19 01:35:18 --> Router Class Initialized
INFO - 2016-12-19 01:35:18 --> Output Class Initialized
INFO - 2016-12-19 01:35:18 --> Security Class Initialized
DEBUG - 2016-12-19 01:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:35:18 --> Input Class Initialized
INFO - 2016-12-19 01:35:18 --> Language Class Initialized
INFO - 2016-12-19 01:35:18 --> Loader Class Initialized
INFO - 2016-12-19 01:35:18 --> Database Driver Class Initialized
INFO - 2016-12-19 01:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:35:18 --> Controller Class Initialized
INFO - 2016-12-19 01:35:18 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:35:18 --> Final output sent to browser
DEBUG - 2016-12-19 01:35:18 --> Total execution time: 0.0130
INFO - 2016-12-19 01:35:20 --> Config Class Initialized
INFO - 2016-12-19 01:35:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:35:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:35:20 --> Utf8 Class Initialized
INFO - 2016-12-19 01:35:20 --> URI Class Initialized
DEBUG - 2016-12-19 01:35:20 --> No URI present. Default controller set.
INFO - 2016-12-19 01:35:20 --> Router Class Initialized
INFO - 2016-12-19 01:35:20 --> Output Class Initialized
INFO - 2016-12-19 01:35:20 --> Security Class Initialized
DEBUG - 2016-12-19 01:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:35:20 --> Input Class Initialized
INFO - 2016-12-19 01:35:20 --> Language Class Initialized
INFO - 2016-12-19 01:35:20 --> Loader Class Initialized
INFO - 2016-12-19 01:35:20 --> Database Driver Class Initialized
INFO - 2016-12-19 01:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:35:20 --> Controller Class Initialized
INFO - 2016-12-19 01:35:20 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:35:20 --> Final output sent to browser
DEBUG - 2016-12-19 01:35:20 --> Total execution time: 0.0132
INFO - 2016-12-19 01:35:20 --> Config Class Initialized
INFO - 2016-12-19 01:35:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:35:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:35:20 --> Utf8 Class Initialized
INFO - 2016-12-19 01:35:20 --> URI Class Initialized
INFO - 2016-12-19 01:35:20 --> Router Class Initialized
INFO - 2016-12-19 01:35:20 --> Output Class Initialized
INFO - 2016-12-19 01:35:20 --> Security Class Initialized
DEBUG - 2016-12-19 01:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:35:20 --> Input Class Initialized
INFO - 2016-12-19 01:35:20 --> Language Class Initialized
INFO - 2016-12-19 01:35:20 --> Loader Class Initialized
INFO - 2016-12-19 01:35:20 --> Database Driver Class Initialized
INFO - 2016-12-19 01:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:35:20 --> Controller Class Initialized
INFO - 2016-12-19 01:35:20 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:35:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:35:20 --> Final output sent to browser
DEBUG - 2016-12-19 01:35:20 --> Total execution time: 0.0134
INFO - 2016-12-19 01:39:02 --> Config Class Initialized
INFO - 2016-12-19 01:39:02 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:02 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:02 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:02 --> URI Class Initialized
DEBUG - 2016-12-19 01:39:02 --> No URI present. Default controller set.
INFO - 2016-12-19 01:39:02 --> Router Class Initialized
INFO - 2016-12-19 01:39:02 --> Output Class Initialized
INFO - 2016-12-19 01:39:02 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:02 --> Input Class Initialized
INFO - 2016-12-19 01:39:02 --> Language Class Initialized
INFO - 2016-12-19 01:39:02 --> Loader Class Initialized
INFO - 2016-12-19 01:39:02 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:02 --> Controller Class Initialized
INFO - 2016-12-19 01:39:02 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:02 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:02 --> Total execution time: 0.0131
INFO - 2016-12-19 01:39:02 --> Config Class Initialized
INFO - 2016-12-19 01:39:02 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:02 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:02 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:02 --> URI Class Initialized
INFO - 2016-12-19 01:39:02 --> Router Class Initialized
INFO - 2016-12-19 01:39:02 --> Output Class Initialized
INFO - 2016-12-19 01:39:02 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:02 --> Input Class Initialized
INFO - 2016-12-19 01:39:02 --> Language Class Initialized
INFO - 2016-12-19 01:39:02 --> Loader Class Initialized
INFO - 2016-12-19 01:39:02 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:02 --> Controller Class Initialized
INFO - 2016-12-19 01:39:02 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:02 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:02 --> Total execution time: 0.0132
INFO - 2016-12-19 01:39:29 --> Config Class Initialized
INFO - 2016-12-19 01:39:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:29 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:29 --> URI Class Initialized
DEBUG - 2016-12-19 01:39:29 --> No URI present. Default controller set.
INFO - 2016-12-19 01:39:29 --> Router Class Initialized
INFO - 2016-12-19 01:39:29 --> Output Class Initialized
INFO - 2016-12-19 01:39:29 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:29 --> Input Class Initialized
INFO - 2016-12-19 01:39:29 --> Language Class Initialized
INFO - 2016-12-19 01:39:29 --> Loader Class Initialized
INFO - 2016-12-19 01:39:29 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:29 --> Controller Class Initialized
INFO - 2016-12-19 01:39:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:29 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:29 --> Total execution time: 0.0129
INFO - 2016-12-19 01:39:29 --> Config Class Initialized
INFO - 2016-12-19 01:39:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:29 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:29 --> URI Class Initialized
INFO - 2016-12-19 01:39:29 --> Router Class Initialized
INFO - 2016-12-19 01:39:29 --> Output Class Initialized
INFO - 2016-12-19 01:39:29 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:29 --> Input Class Initialized
INFO - 2016-12-19 01:39:29 --> Language Class Initialized
INFO - 2016-12-19 01:39:29 --> Loader Class Initialized
INFO - 2016-12-19 01:39:29 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:29 --> Controller Class Initialized
INFO - 2016-12-19 01:39:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:29 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:29 --> Total execution time: 0.0131
INFO - 2016-12-19 01:39:40 --> Config Class Initialized
INFO - 2016-12-19 01:39:40 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:40 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:40 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:40 --> URI Class Initialized
DEBUG - 2016-12-19 01:39:40 --> No URI present. Default controller set.
INFO - 2016-12-19 01:39:40 --> Router Class Initialized
INFO - 2016-12-19 01:39:40 --> Output Class Initialized
INFO - 2016-12-19 01:39:40 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:40 --> Input Class Initialized
INFO - 2016-12-19 01:39:40 --> Language Class Initialized
INFO - 2016-12-19 01:39:40 --> Loader Class Initialized
INFO - 2016-12-19 01:39:40 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:40 --> Controller Class Initialized
INFO - 2016-12-19 01:39:40 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:40 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:40 --> Total execution time: 0.0130
INFO - 2016-12-19 01:39:40 --> Config Class Initialized
INFO - 2016-12-19 01:39:40 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:40 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:40 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:40 --> URI Class Initialized
INFO - 2016-12-19 01:39:40 --> Router Class Initialized
INFO - 2016-12-19 01:39:40 --> Output Class Initialized
INFO - 2016-12-19 01:39:40 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:40 --> Input Class Initialized
INFO - 2016-12-19 01:39:40 --> Language Class Initialized
INFO - 2016-12-19 01:39:40 --> Loader Class Initialized
INFO - 2016-12-19 01:39:40 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:40 --> Controller Class Initialized
INFO - 2016-12-19 01:39:40 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:40 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:40 --> Total execution time: 0.0135
INFO - 2016-12-19 01:39:50 --> Config Class Initialized
INFO - 2016-12-19 01:39:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:50 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:50 --> URI Class Initialized
DEBUG - 2016-12-19 01:39:50 --> No URI present. Default controller set.
INFO - 2016-12-19 01:39:50 --> Router Class Initialized
INFO - 2016-12-19 01:39:50 --> Output Class Initialized
INFO - 2016-12-19 01:39:50 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:50 --> Input Class Initialized
INFO - 2016-12-19 01:39:50 --> Language Class Initialized
INFO - 2016-12-19 01:39:50 --> Loader Class Initialized
INFO - 2016-12-19 01:39:50 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:50 --> Controller Class Initialized
INFO - 2016-12-19 01:39:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:50 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:50 --> Total execution time: 0.0129
INFO - 2016-12-19 01:39:50 --> Config Class Initialized
INFO - 2016-12-19 01:39:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:39:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:39:50 --> Utf8 Class Initialized
INFO - 2016-12-19 01:39:50 --> URI Class Initialized
INFO - 2016-12-19 01:39:50 --> Router Class Initialized
INFO - 2016-12-19 01:39:50 --> Output Class Initialized
INFO - 2016-12-19 01:39:50 --> Security Class Initialized
DEBUG - 2016-12-19 01:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:39:50 --> Input Class Initialized
INFO - 2016-12-19 01:39:50 --> Language Class Initialized
INFO - 2016-12-19 01:39:50 --> Loader Class Initialized
INFO - 2016-12-19 01:39:50 --> Database Driver Class Initialized
INFO - 2016-12-19 01:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:39:50 --> Controller Class Initialized
INFO - 2016-12-19 01:39:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:39:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:39:50 --> Final output sent to browser
DEBUG - 2016-12-19 01:39:50 --> Total execution time: 0.0130
INFO - 2016-12-19 01:42:32 --> Config Class Initialized
INFO - 2016-12-19 01:42:32 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:42:32 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:42:32 --> Utf8 Class Initialized
INFO - 2016-12-19 01:42:32 --> URI Class Initialized
DEBUG - 2016-12-19 01:42:32 --> No URI present. Default controller set.
INFO - 2016-12-19 01:42:32 --> Router Class Initialized
INFO - 2016-12-19 01:42:32 --> Output Class Initialized
INFO - 2016-12-19 01:42:32 --> Security Class Initialized
DEBUG - 2016-12-19 01:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:42:32 --> Input Class Initialized
INFO - 2016-12-19 01:42:32 --> Language Class Initialized
INFO - 2016-12-19 01:42:32 --> Loader Class Initialized
INFO - 2016-12-19 01:42:32 --> Database Driver Class Initialized
INFO - 2016-12-19 01:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:42:32 --> Controller Class Initialized
INFO - 2016-12-19 01:42:32 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:42:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:42:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:42:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:42:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:42:32 --> Final output sent to browser
DEBUG - 2016-12-19 01:42:32 --> Total execution time: 0.0134
INFO - 2016-12-19 01:42:33 --> Config Class Initialized
INFO - 2016-12-19 01:42:33 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:42:33 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:42:33 --> Utf8 Class Initialized
INFO - 2016-12-19 01:42:33 --> URI Class Initialized
INFO - 2016-12-19 01:42:33 --> Router Class Initialized
INFO - 2016-12-19 01:42:33 --> Output Class Initialized
INFO - 2016-12-19 01:42:33 --> Security Class Initialized
DEBUG - 2016-12-19 01:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:42:33 --> Input Class Initialized
INFO - 2016-12-19 01:42:33 --> Language Class Initialized
INFO - 2016-12-19 01:42:33 --> Loader Class Initialized
INFO - 2016-12-19 01:42:33 --> Database Driver Class Initialized
INFO - 2016-12-19 01:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:42:33 --> Controller Class Initialized
INFO - 2016-12-19 01:42:33 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:42:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:42:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:42:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:42:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:42:33 --> Final output sent to browser
DEBUG - 2016-12-19 01:42:33 --> Total execution time: 0.0137
INFO - 2016-12-19 01:47:21 --> Config Class Initialized
INFO - 2016-12-19 01:47:21 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:47:21 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:47:21 --> Utf8 Class Initialized
INFO - 2016-12-19 01:47:21 --> URI Class Initialized
DEBUG - 2016-12-19 01:47:21 --> No URI present. Default controller set.
INFO - 2016-12-19 01:47:21 --> Router Class Initialized
INFO - 2016-12-19 01:47:21 --> Output Class Initialized
INFO - 2016-12-19 01:47:21 --> Security Class Initialized
DEBUG - 2016-12-19 01:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:47:21 --> Input Class Initialized
INFO - 2016-12-19 01:47:21 --> Language Class Initialized
INFO - 2016-12-19 01:47:21 --> Loader Class Initialized
INFO - 2016-12-19 01:47:21 --> Database Driver Class Initialized
INFO - 2016-12-19 01:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:47:21 --> Controller Class Initialized
INFO - 2016-12-19 01:47:21 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:47:21 --> Final output sent to browser
DEBUG - 2016-12-19 01:47:21 --> Total execution time: 0.0138
INFO - 2016-12-19 01:47:22 --> Config Class Initialized
INFO - 2016-12-19 01:47:22 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:47:22 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:47:22 --> Utf8 Class Initialized
INFO - 2016-12-19 01:47:22 --> URI Class Initialized
INFO - 2016-12-19 01:47:22 --> Router Class Initialized
INFO - 2016-12-19 01:47:22 --> Output Class Initialized
INFO - 2016-12-19 01:47:22 --> Security Class Initialized
DEBUG - 2016-12-19 01:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:47:22 --> Input Class Initialized
INFO - 2016-12-19 01:47:22 --> Language Class Initialized
INFO - 2016-12-19 01:47:22 --> Loader Class Initialized
INFO - 2016-12-19 01:47:22 --> Database Driver Class Initialized
INFO - 2016-12-19 01:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:47:22 --> Controller Class Initialized
INFO - 2016-12-19 01:47:22 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:47:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:47:22 --> Final output sent to browser
DEBUG - 2016-12-19 01:47:22 --> Total execution time: 0.0141
INFO - 2016-12-19 01:47:44 --> Config Class Initialized
INFO - 2016-12-19 01:47:44 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:47:44 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:47:44 --> Utf8 Class Initialized
INFO - 2016-12-19 01:47:44 --> URI Class Initialized
DEBUG - 2016-12-19 01:47:44 --> No URI present. Default controller set.
INFO - 2016-12-19 01:47:44 --> Router Class Initialized
INFO - 2016-12-19 01:47:44 --> Output Class Initialized
INFO - 2016-12-19 01:47:44 --> Security Class Initialized
DEBUG - 2016-12-19 01:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:47:44 --> Input Class Initialized
INFO - 2016-12-19 01:47:44 --> Language Class Initialized
INFO - 2016-12-19 01:47:44 --> Loader Class Initialized
INFO - 2016-12-19 01:47:44 --> Database Driver Class Initialized
INFO - 2016-12-19 01:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:47:44 --> Controller Class Initialized
INFO - 2016-12-19 01:47:44 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:47:44 --> Final output sent to browser
DEBUG - 2016-12-19 01:47:44 --> Total execution time: 0.0184
INFO - 2016-12-19 01:47:44 --> Config Class Initialized
INFO - 2016-12-19 01:47:44 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:47:44 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:47:44 --> Utf8 Class Initialized
INFO - 2016-12-19 01:47:44 --> URI Class Initialized
INFO - 2016-12-19 01:47:44 --> Router Class Initialized
INFO - 2016-12-19 01:47:44 --> Output Class Initialized
INFO - 2016-12-19 01:47:44 --> Security Class Initialized
DEBUG - 2016-12-19 01:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:47:44 --> Input Class Initialized
INFO - 2016-12-19 01:47:44 --> Language Class Initialized
INFO - 2016-12-19 01:47:44 --> Loader Class Initialized
INFO - 2016-12-19 01:47:44 --> Database Driver Class Initialized
INFO - 2016-12-19 01:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:47:44 --> Controller Class Initialized
INFO - 2016-12-19 01:47:44 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:47:44 --> Final output sent to browser
DEBUG - 2016-12-19 01:47:44 --> Total execution time: 0.0131
INFO - 2016-12-19 01:48:02 --> Config Class Initialized
INFO - 2016-12-19 01:48:02 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:48:02 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:48:02 --> Utf8 Class Initialized
INFO - 2016-12-19 01:48:02 --> URI Class Initialized
DEBUG - 2016-12-19 01:48:02 --> No URI present. Default controller set.
INFO - 2016-12-19 01:48:02 --> Router Class Initialized
INFO - 2016-12-19 01:48:02 --> Output Class Initialized
INFO - 2016-12-19 01:48:02 --> Security Class Initialized
DEBUG - 2016-12-19 01:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:48:02 --> Input Class Initialized
INFO - 2016-12-19 01:48:02 --> Language Class Initialized
INFO - 2016-12-19 01:48:02 --> Loader Class Initialized
INFO - 2016-12-19 01:48:02 --> Database Driver Class Initialized
INFO - 2016-12-19 01:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:48:02 --> Controller Class Initialized
INFO - 2016-12-19 01:48:02 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:48:02 --> Final output sent to browser
DEBUG - 2016-12-19 01:48:02 --> Total execution time: 0.0134
INFO - 2016-12-19 01:48:02 --> Config Class Initialized
INFO - 2016-12-19 01:48:02 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:48:02 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:48:02 --> Utf8 Class Initialized
INFO - 2016-12-19 01:48:02 --> URI Class Initialized
INFO - 2016-12-19 01:48:02 --> Router Class Initialized
INFO - 2016-12-19 01:48:02 --> Output Class Initialized
INFO - 2016-12-19 01:48:02 --> Security Class Initialized
DEBUG - 2016-12-19 01:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:48:02 --> Input Class Initialized
INFO - 2016-12-19 01:48:02 --> Language Class Initialized
INFO - 2016-12-19 01:48:02 --> Loader Class Initialized
INFO - 2016-12-19 01:48:02 --> Database Driver Class Initialized
INFO - 2016-12-19 01:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:48:02 --> Controller Class Initialized
INFO - 2016-12-19 01:48:02 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:48:02 --> Final output sent to browser
DEBUG - 2016-12-19 01:48:02 --> Total execution time: 0.0133
INFO - 2016-12-19 01:49:08 --> Config Class Initialized
INFO - 2016-12-19 01:49:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:49:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:49:08 --> Utf8 Class Initialized
INFO - 2016-12-19 01:49:08 --> URI Class Initialized
DEBUG - 2016-12-19 01:49:08 --> No URI present. Default controller set.
INFO - 2016-12-19 01:49:08 --> Router Class Initialized
INFO - 2016-12-19 01:49:08 --> Output Class Initialized
INFO - 2016-12-19 01:49:08 --> Security Class Initialized
DEBUG - 2016-12-19 01:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:49:08 --> Input Class Initialized
INFO - 2016-12-19 01:49:08 --> Language Class Initialized
INFO - 2016-12-19 01:49:08 --> Loader Class Initialized
INFO - 2016-12-19 01:49:08 --> Database Driver Class Initialized
INFO - 2016-12-19 01:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:49:08 --> Controller Class Initialized
INFO - 2016-12-19 01:49:08 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:49:08 --> Final output sent to browser
DEBUG - 2016-12-19 01:49:08 --> Total execution time: 0.0132
INFO - 2016-12-19 01:49:08 --> Config Class Initialized
INFO - 2016-12-19 01:49:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:49:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:49:08 --> Utf8 Class Initialized
INFO - 2016-12-19 01:49:08 --> URI Class Initialized
INFO - 2016-12-19 01:49:08 --> Router Class Initialized
INFO - 2016-12-19 01:49:08 --> Output Class Initialized
INFO - 2016-12-19 01:49:08 --> Security Class Initialized
DEBUG - 2016-12-19 01:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:49:09 --> Input Class Initialized
INFO - 2016-12-19 01:49:09 --> Language Class Initialized
INFO - 2016-12-19 01:49:09 --> Loader Class Initialized
INFO - 2016-12-19 01:49:09 --> Database Driver Class Initialized
INFO - 2016-12-19 01:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:49:09 --> Controller Class Initialized
INFO - 2016-12-19 01:49:09 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:49:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:49:09 --> Final output sent to browser
DEBUG - 2016-12-19 01:49:09 --> Total execution time: 0.0142
INFO - 2016-12-19 01:49:46 --> Config Class Initialized
INFO - 2016-12-19 01:49:46 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:49:46 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:49:46 --> Utf8 Class Initialized
INFO - 2016-12-19 01:49:46 --> URI Class Initialized
DEBUG - 2016-12-19 01:49:46 --> No URI present. Default controller set.
INFO - 2016-12-19 01:49:46 --> Router Class Initialized
INFO - 2016-12-19 01:49:46 --> Output Class Initialized
INFO - 2016-12-19 01:49:46 --> Security Class Initialized
DEBUG - 2016-12-19 01:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:49:46 --> Input Class Initialized
INFO - 2016-12-19 01:49:46 --> Language Class Initialized
INFO - 2016-12-19 01:49:46 --> Loader Class Initialized
INFO - 2016-12-19 01:49:46 --> Database Driver Class Initialized
INFO - 2016-12-19 01:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:49:46 --> Controller Class Initialized
INFO - 2016-12-19 01:49:46 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:49:46 --> Final output sent to browser
DEBUG - 2016-12-19 01:49:46 --> Total execution time: 0.0131
INFO - 2016-12-19 01:49:47 --> Config Class Initialized
INFO - 2016-12-19 01:49:47 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:49:47 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:49:47 --> Utf8 Class Initialized
INFO - 2016-12-19 01:49:47 --> URI Class Initialized
INFO - 2016-12-19 01:49:47 --> Router Class Initialized
INFO - 2016-12-19 01:49:47 --> Output Class Initialized
INFO - 2016-12-19 01:49:47 --> Security Class Initialized
DEBUG - 2016-12-19 01:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:49:47 --> Input Class Initialized
INFO - 2016-12-19 01:49:47 --> Language Class Initialized
INFO - 2016-12-19 01:49:47 --> Loader Class Initialized
INFO - 2016-12-19 01:49:47 --> Database Driver Class Initialized
INFO - 2016-12-19 01:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:49:47 --> Controller Class Initialized
INFO - 2016-12-19 01:49:47 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:49:47 --> Final output sent to browser
DEBUG - 2016-12-19 01:49:47 --> Total execution time: 0.0134
INFO - 2016-12-19 01:50:20 --> Config Class Initialized
INFO - 2016-12-19 01:50:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:50:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:50:20 --> Utf8 Class Initialized
INFO - 2016-12-19 01:50:20 --> URI Class Initialized
DEBUG - 2016-12-19 01:50:20 --> No URI present. Default controller set.
INFO - 2016-12-19 01:50:20 --> Router Class Initialized
INFO - 2016-12-19 01:50:20 --> Output Class Initialized
INFO - 2016-12-19 01:50:20 --> Security Class Initialized
DEBUG - 2016-12-19 01:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:50:20 --> Input Class Initialized
INFO - 2016-12-19 01:50:20 --> Language Class Initialized
INFO - 2016-12-19 01:50:20 --> Loader Class Initialized
INFO - 2016-12-19 01:50:20 --> Database Driver Class Initialized
INFO - 2016-12-19 01:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:50:20 --> Controller Class Initialized
INFO - 2016-12-19 01:50:20 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:50:20 --> Final output sent to browser
DEBUG - 2016-12-19 01:50:20 --> Total execution time: 0.0132
INFO - 2016-12-19 01:50:20 --> Config Class Initialized
INFO - 2016-12-19 01:50:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:50:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:50:20 --> Utf8 Class Initialized
INFO - 2016-12-19 01:50:20 --> URI Class Initialized
INFO - 2016-12-19 01:50:20 --> Router Class Initialized
INFO - 2016-12-19 01:50:20 --> Output Class Initialized
INFO - 2016-12-19 01:50:20 --> Security Class Initialized
DEBUG - 2016-12-19 01:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:50:20 --> Input Class Initialized
INFO - 2016-12-19 01:50:20 --> Language Class Initialized
INFO - 2016-12-19 01:50:20 --> Loader Class Initialized
INFO - 2016-12-19 01:50:20 --> Database Driver Class Initialized
INFO - 2016-12-19 01:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:50:20 --> Controller Class Initialized
INFO - 2016-12-19 01:50:20 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:50:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:50:20 --> Final output sent to browser
DEBUG - 2016-12-19 01:50:20 --> Total execution time: 0.0135
INFO - 2016-12-19 01:50:52 --> Config Class Initialized
INFO - 2016-12-19 01:50:52 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:50:52 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:50:52 --> Utf8 Class Initialized
INFO - 2016-12-19 01:50:52 --> URI Class Initialized
DEBUG - 2016-12-19 01:50:52 --> No URI present. Default controller set.
INFO - 2016-12-19 01:50:52 --> Router Class Initialized
INFO - 2016-12-19 01:50:52 --> Output Class Initialized
INFO - 2016-12-19 01:50:52 --> Security Class Initialized
DEBUG - 2016-12-19 01:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:50:52 --> Input Class Initialized
INFO - 2016-12-19 01:50:52 --> Language Class Initialized
INFO - 2016-12-19 01:50:52 --> Loader Class Initialized
INFO - 2016-12-19 01:50:52 --> Database Driver Class Initialized
INFO - 2016-12-19 01:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:50:52 --> Controller Class Initialized
INFO - 2016-12-19 01:50:52 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:50:52 --> Final output sent to browser
DEBUG - 2016-12-19 01:50:52 --> Total execution time: 0.0131
INFO - 2016-12-19 01:50:53 --> Config Class Initialized
INFO - 2016-12-19 01:50:53 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:50:53 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:50:53 --> Utf8 Class Initialized
INFO - 2016-12-19 01:50:53 --> URI Class Initialized
INFO - 2016-12-19 01:50:53 --> Router Class Initialized
INFO - 2016-12-19 01:50:53 --> Output Class Initialized
INFO - 2016-12-19 01:50:53 --> Security Class Initialized
DEBUG - 2016-12-19 01:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:50:53 --> Input Class Initialized
INFO - 2016-12-19 01:50:53 --> Language Class Initialized
INFO - 2016-12-19 01:50:53 --> Loader Class Initialized
INFO - 2016-12-19 01:50:53 --> Database Driver Class Initialized
INFO - 2016-12-19 01:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:50:53 --> Controller Class Initialized
INFO - 2016-12-19 01:50:53 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:50:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:50:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:50:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:50:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:50:53 --> Final output sent to browser
DEBUG - 2016-12-19 01:50:53 --> Total execution time: 0.0146
INFO - 2016-12-19 01:51:19 --> Config Class Initialized
INFO - 2016-12-19 01:51:19 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:51:19 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:51:19 --> Utf8 Class Initialized
INFO - 2016-12-19 01:51:19 --> URI Class Initialized
DEBUG - 2016-12-19 01:51:19 --> No URI present. Default controller set.
INFO - 2016-12-19 01:51:19 --> Router Class Initialized
INFO - 2016-12-19 01:51:19 --> Output Class Initialized
INFO - 2016-12-19 01:51:19 --> Security Class Initialized
DEBUG - 2016-12-19 01:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:51:19 --> Input Class Initialized
INFO - 2016-12-19 01:51:19 --> Language Class Initialized
INFO - 2016-12-19 01:51:19 --> Loader Class Initialized
INFO - 2016-12-19 01:51:19 --> Database Driver Class Initialized
INFO - 2016-12-19 01:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:51:19 --> Controller Class Initialized
INFO - 2016-12-19 01:51:19 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:51:19 --> Final output sent to browser
DEBUG - 2016-12-19 01:51:19 --> Total execution time: 0.0135
INFO - 2016-12-19 01:51:20 --> Config Class Initialized
INFO - 2016-12-19 01:51:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:51:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:51:20 --> Utf8 Class Initialized
INFO - 2016-12-19 01:51:20 --> URI Class Initialized
INFO - 2016-12-19 01:51:20 --> Router Class Initialized
INFO - 2016-12-19 01:51:20 --> Output Class Initialized
INFO - 2016-12-19 01:51:20 --> Security Class Initialized
DEBUG - 2016-12-19 01:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:51:20 --> Input Class Initialized
INFO - 2016-12-19 01:51:20 --> Language Class Initialized
INFO - 2016-12-19 01:51:20 --> Loader Class Initialized
INFO - 2016-12-19 01:51:20 --> Database Driver Class Initialized
INFO - 2016-12-19 01:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:51:20 --> Controller Class Initialized
INFO - 2016-12-19 01:51:20 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:51:20 --> Final output sent to browser
DEBUG - 2016-12-19 01:51:20 --> Total execution time: 0.0130
INFO - 2016-12-19 01:51:35 --> Config Class Initialized
INFO - 2016-12-19 01:51:35 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:51:35 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:51:35 --> Utf8 Class Initialized
INFO - 2016-12-19 01:51:35 --> URI Class Initialized
DEBUG - 2016-12-19 01:51:35 --> No URI present. Default controller set.
INFO - 2016-12-19 01:51:35 --> Router Class Initialized
INFO - 2016-12-19 01:51:35 --> Output Class Initialized
INFO - 2016-12-19 01:51:35 --> Security Class Initialized
DEBUG - 2016-12-19 01:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:51:35 --> Input Class Initialized
INFO - 2016-12-19 01:51:35 --> Language Class Initialized
INFO - 2016-12-19 01:51:35 --> Loader Class Initialized
INFO - 2016-12-19 01:51:35 --> Database Driver Class Initialized
INFO - 2016-12-19 01:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:51:35 --> Controller Class Initialized
INFO - 2016-12-19 01:51:35 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:51:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:51:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:51:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:51:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:51:35 --> Final output sent to browser
DEBUG - 2016-12-19 01:51:35 --> Total execution time: 0.0126
INFO - 2016-12-19 01:51:36 --> Config Class Initialized
INFO - 2016-12-19 01:51:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:51:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:51:36 --> Utf8 Class Initialized
INFO - 2016-12-19 01:51:36 --> URI Class Initialized
INFO - 2016-12-19 01:51:36 --> Router Class Initialized
INFO - 2016-12-19 01:51:36 --> Output Class Initialized
INFO - 2016-12-19 01:51:36 --> Security Class Initialized
DEBUG - 2016-12-19 01:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:51:36 --> Input Class Initialized
INFO - 2016-12-19 01:51:36 --> Language Class Initialized
INFO - 2016-12-19 01:51:36 --> Loader Class Initialized
INFO - 2016-12-19 01:51:36 --> Database Driver Class Initialized
INFO - 2016-12-19 01:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:51:36 --> Controller Class Initialized
INFO - 2016-12-19 01:51:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:51:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:51:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:51:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:51:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:51:36 --> Final output sent to browser
DEBUG - 2016-12-19 01:51:36 --> Total execution time: 0.0129
INFO - 2016-12-19 01:51:38 --> Config Class Initialized
INFO - 2016-12-19 01:51:38 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:51:38 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:51:38 --> Utf8 Class Initialized
INFO - 2016-12-19 01:51:38 --> URI Class Initialized
DEBUG - 2016-12-19 01:51:38 --> No URI present. Default controller set.
INFO - 2016-12-19 01:51:38 --> Router Class Initialized
INFO - 2016-12-19 01:51:38 --> Output Class Initialized
INFO - 2016-12-19 01:51:38 --> Security Class Initialized
DEBUG - 2016-12-19 01:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:51:38 --> Input Class Initialized
INFO - 2016-12-19 01:51:38 --> Language Class Initialized
INFO - 2016-12-19 01:51:38 --> Loader Class Initialized
INFO - 2016-12-19 01:51:38 --> Database Driver Class Initialized
INFO - 2016-12-19 01:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:51:38 --> Controller Class Initialized
INFO - 2016-12-19 01:51:38 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:51:38 --> Final output sent to browser
DEBUG - 2016-12-19 01:51:38 --> Total execution time: 0.0132
INFO - 2016-12-19 01:51:39 --> Config Class Initialized
INFO - 2016-12-19 01:51:39 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:51:39 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:51:39 --> Utf8 Class Initialized
INFO - 2016-12-19 01:51:39 --> URI Class Initialized
INFO - 2016-12-19 01:51:39 --> Router Class Initialized
INFO - 2016-12-19 01:51:39 --> Output Class Initialized
INFO - 2016-12-19 01:51:39 --> Security Class Initialized
DEBUG - 2016-12-19 01:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:51:39 --> Input Class Initialized
INFO - 2016-12-19 01:51:39 --> Language Class Initialized
INFO - 2016-12-19 01:51:39 --> Loader Class Initialized
INFO - 2016-12-19 01:51:39 --> Database Driver Class Initialized
INFO - 2016-12-19 01:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:51:39 --> Controller Class Initialized
INFO - 2016-12-19 01:51:39 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:51:39 --> Final output sent to browser
DEBUG - 2016-12-19 01:51:39 --> Total execution time: 0.0130
INFO - 2016-12-19 01:52:05 --> Config Class Initialized
INFO - 2016-12-19 01:52:05 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:52:05 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:52:05 --> Utf8 Class Initialized
INFO - 2016-12-19 01:52:05 --> URI Class Initialized
DEBUG - 2016-12-19 01:52:05 --> No URI present. Default controller set.
INFO - 2016-12-19 01:52:05 --> Router Class Initialized
INFO - 2016-12-19 01:52:05 --> Output Class Initialized
INFO - 2016-12-19 01:52:05 --> Security Class Initialized
DEBUG - 2016-12-19 01:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:52:05 --> Input Class Initialized
INFO - 2016-12-19 01:52:05 --> Language Class Initialized
INFO - 2016-12-19 01:52:05 --> Loader Class Initialized
INFO - 2016-12-19 01:52:05 --> Database Driver Class Initialized
INFO - 2016-12-19 01:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:52:05 --> Controller Class Initialized
INFO - 2016-12-19 01:52:05 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:52:05 --> Final output sent to browser
DEBUG - 2016-12-19 01:52:05 --> Total execution time: 0.0130
INFO - 2016-12-19 01:52:06 --> Config Class Initialized
INFO - 2016-12-19 01:52:06 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:52:06 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:52:06 --> Utf8 Class Initialized
INFO - 2016-12-19 01:52:06 --> URI Class Initialized
INFO - 2016-12-19 01:52:06 --> Router Class Initialized
INFO - 2016-12-19 01:52:06 --> Output Class Initialized
INFO - 2016-12-19 01:52:06 --> Security Class Initialized
DEBUG - 2016-12-19 01:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:52:06 --> Input Class Initialized
INFO - 2016-12-19 01:52:06 --> Language Class Initialized
INFO - 2016-12-19 01:52:06 --> Loader Class Initialized
INFO - 2016-12-19 01:52:06 --> Database Driver Class Initialized
INFO - 2016-12-19 01:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:52:06 --> Controller Class Initialized
INFO - 2016-12-19 01:52:06 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:52:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:52:06 --> Final output sent to browser
DEBUG - 2016-12-19 01:52:06 --> Total execution time: 0.0134
INFO - 2016-12-19 01:52:07 --> Config Class Initialized
INFO - 2016-12-19 01:52:07 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:52:07 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:52:07 --> Utf8 Class Initialized
INFO - 2016-12-19 01:52:07 --> URI Class Initialized
DEBUG - 2016-12-19 01:52:07 --> No URI present. Default controller set.
INFO - 2016-12-19 01:52:07 --> Router Class Initialized
INFO - 2016-12-19 01:52:07 --> Output Class Initialized
INFO - 2016-12-19 01:52:07 --> Security Class Initialized
DEBUG - 2016-12-19 01:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:52:07 --> Input Class Initialized
INFO - 2016-12-19 01:52:07 --> Language Class Initialized
INFO - 2016-12-19 01:52:07 --> Loader Class Initialized
INFO - 2016-12-19 01:52:07 --> Database Driver Class Initialized
INFO - 2016-12-19 01:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:52:07 --> Controller Class Initialized
INFO - 2016-12-19 01:52:07 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:52:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:52:07 --> Final output sent to browser
DEBUG - 2016-12-19 01:52:07 --> Total execution time: 0.0130
INFO - 2016-12-19 01:52:08 --> Config Class Initialized
INFO - 2016-12-19 01:52:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:52:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:52:08 --> Utf8 Class Initialized
INFO - 2016-12-19 01:52:08 --> URI Class Initialized
INFO - 2016-12-19 01:52:08 --> Router Class Initialized
INFO - 2016-12-19 01:52:08 --> Output Class Initialized
INFO - 2016-12-19 01:52:08 --> Security Class Initialized
DEBUG - 2016-12-19 01:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:52:08 --> Input Class Initialized
INFO - 2016-12-19 01:52:08 --> Language Class Initialized
INFO - 2016-12-19 01:52:08 --> Loader Class Initialized
INFO - 2016-12-19 01:52:08 --> Database Driver Class Initialized
INFO - 2016-12-19 01:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:52:08 --> Controller Class Initialized
INFO - 2016-12-19 01:52:08 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:52:08 --> Final output sent to browser
DEBUG - 2016-12-19 01:52:08 --> Total execution time: 0.0126
INFO - 2016-12-19 01:52:08 --> Config Class Initialized
INFO - 2016-12-19 01:52:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:52:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:52:08 --> Utf8 Class Initialized
INFO - 2016-12-19 01:52:08 --> URI Class Initialized
DEBUG - 2016-12-19 01:52:08 --> No URI present. Default controller set.
INFO - 2016-12-19 01:52:08 --> Router Class Initialized
INFO - 2016-12-19 01:52:08 --> Output Class Initialized
INFO - 2016-12-19 01:52:08 --> Security Class Initialized
DEBUG - 2016-12-19 01:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:52:08 --> Input Class Initialized
INFO - 2016-12-19 01:52:08 --> Language Class Initialized
INFO - 2016-12-19 01:52:08 --> Loader Class Initialized
INFO - 2016-12-19 01:52:08 --> Database Driver Class Initialized
INFO - 2016-12-19 01:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:52:08 --> Controller Class Initialized
INFO - 2016-12-19 01:52:08 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:52:08 --> Final output sent to browser
DEBUG - 2016-12-19 01:52:08 --> Total execution time: 0.0134
INFO - 2016-12-19 01:52:08 --> Config Class Initialized
INFO - 2016-12-19 01:52:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:52:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:52:08 --> Utf8 Class Initialized
INFO - 2016-12-19 01:52:08 --> URI Class Initialized
INFO - 2016-12-19 01:52:08 --> Router Class Initialized
INFO - 2016-12-19 01:52:08 --> Output Class Initialized
INFO - 2016-12-19 01:52:08 --> Security Class Initialized
DEBUG - 2016-12-19 01:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:52:08 --> Input Class Initialized
INFO - 2016-12-19 01:52:08 --> Language Class Initialized
INFO - 2016-12-19 01:52:08 --> Loader Class Initialized
INFO - 2016-12-19 01:52:08 --> Database Driver Class Initialized
INFO - 2016-12-19 01:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:52:08 --> Controller Class Initialized
INFO - 2016-12-19 01:52:08 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:52:08 --> Final output sent to browser
DEBUG - 2016-12-19 01:52:08 --> Total execution time: 0.0129
INFO - 2016-12-19 01:52:20 --> Config Class Initialized
INFO - 2016-12-19 01:52:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:52:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:52:20 --> Utf8 Class Initialized
INFO - 2016-12-19 01:52:20 --> URI Class Initialized
INFO - 2016-12-19 01:52:20 --> Router Class Initialized
INFO - 2016-12-19 01:52:20 --> Output Class Initialized
INFO - 2016-12-19 01:52:20 --> Security Class Initialized
DEBUG - 2016-12-19 01:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:52:20 --> Input Class Initialized
INFO - 2016-12-19 01:52:20 --> Language Class Initialized
ERROR - 2016-12-19 01:52:20 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:53:18 --> Config Class Initialized
INFO - 2016-12-19 01:53:18 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:53:18 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:53:18 --> Utf8 Class Initialized
INFO - 2016-12-19 01:53:18 --> URI Class Initialized
DEBUG - 2016-12-19 01:53:18 --> No URI present. Default controller set.
INFO - 2016-12-19 01:53:18 --> Router Class Initialized
INFO - 2016-12-19 01:53:18 --> Output Class Initialized
INFO - 2016-12-19 01:53:18 --> Security Class Initialized
DEBUG - 2016-12-19 01:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:53:18 --> Input Class Initialized
INFO - 2016-12-19 01:53:18 --> Language Class Initialized
INFO - 2016-12-19 01:53:18 --> Loader Class Initialized
INFO - 2016-12-19 01:53:18 --> Database Driver Class Initialized
INFO - 2016-12-19 01:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:53:18 --> Controller Class Initialized
INFO - 2016-12-19 01:53:18 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:53:18 --> Final output sent to browser
DEBUG - 2016-12-19 01:53:18 --> Total execution time: 0.0132
INFO - 2016-12-19 01:53:18 --> Config Class Initialized
INFO - 2016-12-19 01:53:18 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:53:18 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:53:18 --> Utf8 Class Initialized
INFO - 2016-12-19 01:53:18 --> URI Class Initialized
INFO - 2016-12-19 01:53:18 --> Router Class Initialized
INFO - 2016-12-19 01:53:18 --> Output Class Initialized
INFO - 2016-12-19 01:53:18 --> Security Class Initialized
DEBUG - 2016-12-19 01:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:53:18 --> Input Class Initialized
INFO - 2016-12-19 01:53:18 --> Language Class Initialized
INFO - 2016-12-19 01:53:18 --> Loader Class Initialized
INFO - 2016-12-19 01:53:18 --> Database Driver Class Initialized
INFO - 2016-12-19 01:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:53:18 --> Controller Class Initialized
INFO - 2016-12-19 01:53:18 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:53:18 --> Final output sent to browser
DEBUG - 2016-12-19 01:53:18 --> Total execution time: 0.0131
INFO - 2016-12-19 01:53:44 --> Config Class Initialized
INFO - 2016-12-19 01:53:44 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:53:44 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:53:44 --> Utf8 Class Initialized
INFO - 2016-12-19 01:53:44 --> URI Class Initialized
DEBUG - 2016-12-19 01:53:44 --> No URI present. Default controller set.
INFO - 2016-12-19 01:53:44 --> Router Class Initialized
INFO - 2016-12-19 01:53:44 --> Output Class Initialized
INFO - 2016-12-19 01:53:44 --> Security Class Initialized
DEBUG - 2016-12-19 01:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:53:44 --> Input Class Initialized
INFO - 2016-12-19 01:53:44 --> Language Class Initialized
INFO - 2016-12-19 01:53:44 --> Loader Class Initialized
INFO - 2016-12-19 01:53:44 --> Database Driver Class Initialized
INFO - 2016-12-19 01:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:53:44 --> Controller Class Initialized
INFO - 2016-12-19 01:53:44 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:53:44 --> Final output sent to browser
DEBUG - 2016-12-19 01:53:44 --> Total execution time: 0.0135
INFO - 2016-12-19 01:53:45 --> Config Class Initialized
INFO - 2016-12-19 01:53:45 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:53:45 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:53:45 --> Utf8 Class Initialized
INFO - 2016-12-19 01:53:45 --> URI Class Initialized
INFO - 2016-12-19 01:53:45 --> Router Class Initialized
INFO - 2016-12-19 01:53:45 --> Output Class Initialized
INFO - 2016-12-19 01:53:45 --> Security Class Initialized
DEBUG - 2016-12-19 01:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:53:45 --> Input Class Initialized
INFO - 2016-12-19 01:53:45 --> Language Class Initialized
INFO - 2016-12-19 01:53:45 --> Loader Class Initialized
INFO - 2016-12-19 01:53:45 --> Database Driver Class Initialized
INFO - 2016-12-19 01:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:53:45 --> Controller Class Initialized
INFO - 2016-12-19 01:53:45 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:53:45 --> Final output sent to browser
DEBUG - 2016-12-19 01:53:45 --> Total execution time: 0.0136
INFO - 2016-12-19 01:53:59 --> Config Class Initialized
INFO - 2016-12-19 01:53:59 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:53:59 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:53:59 --> Utf8 Class Initialized
INFO - 2016-12-19 01:53:59 --> URI Class Initialized
DEBUG - 2016-12-19 01:53:59 --> No URI present. Default controller set.
INFO - 2016-12-19 01:53:59 --> Router Class Initialized
INFO - 2016-12-19 01:53:59 --> Output Class Initialized
INFO - 2016-12-19 01:53:59 --> Security Class Initialized
DEBUG - 2016-12-19 01:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:53:59 --> Input Class Initialized
INFO - 2016-12-19 01:53:59 --> Language Class Initialized
INFO - 2016-12-19 01:53:59 --> Loader Class Initialized
INFO - 2016-12-19 01:53:59 --> Database Driver Class Initialized
INFO - 2016-12-19 01:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:53:59 --> Controller Class Initialized
INFO - 2016-12-19 01:53:59 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:53:59 --> Final output sent to browser
DEBUG - 2016-12-19 01:53:59 --> Total execution time: 0.0132
INFO - 2016-12-19 01:53:59 --> Config Class Initialized
INFO - 2016-12-19 01:53:59 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:53:59 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:53:59 --> Utf8 Class Initialized
INFO - 2016-12-19 01:53:59 --> URI Class Initialized
INFO - 2016-12-19 01:53:59 --> Router Class Initialized
INFO - 2016-12-19 01:53:59 --> Output Class Initialized
INFO - 2016-12-19 01:53:59 --> Security Class Initialized
DEBUG - 2016-12-19 01:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:53:59 --> Input Class Initialized
INFO - 2016-12-19 01:53:59 --> Language Class Initialized
INFO - 2016-12-19 01:53:59 --> Loader Class Initialized
INFO - 2016-12-19 01:53:59 --> Database Driver Class Initialized
INFO - 2016-12-19 01:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:53:59 --> Controller Class Initialized
INFO - 2016-12-19 01:53:59 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:53:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:53:59 --> Final output sent to browser
DEBUG - 2016-12-19 01:53:59 --> Total execution time: 0.0178
INFO - 2016-12-19 01:54:02 --> Config Class Initialized
INFO - 2016-12-19 01:54:02 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:02 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:02 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:02 --> URI Class Initialized
INFO - 2016-12-19 01:54:02 --> Router Class Initialized
INFO - 2016-12-19 01:54:02 --> Output Class Initialized
INFO - 2016-12-19 01:54:02 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:02 --> Input Class Initialized
INFO - 2016-12-19 01:54:02 --> Language Class Initialized
ERROR - 2016-12-19 01:54:02 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:54:38 --> Config Class Initialized
INFO - 2016-12-19 01:54:38 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:38 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:38 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:38 --> URI Class Initialized
DEBUG - 2016-12-19 01:54:38 --> No URI present. Default controller set.
INFO - 2016-12-19 01:54:38 --> Router Class Initialized
INFO - 2016-12-19 01:54:38 --> Output Class Initialized
INFO - 2016-12-19 01:54:38 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:38 --> Input Class Initialized
INFO - 2016-12-19 01:54:38 --> Language Class Initialized
INFO - 2016-12-19 01:54:38 --> Loader Class Initialized
INFO - 2016-12-19 01:54:38 --> Database Driver Class Initialized
INFO - 2016-12-19 01:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:54:38 --> Controller Class Initialized
INFO - 2016-12-19 01:54:38 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:54:38 --> Final output sent to browser
DEBUG - 2016-12-19 01:54:38 --> Total execution time: 0.0131
INFO - 2016-12-19 01:54:38 --> Config Class Initialized
INFO - 2016-12-19 01:54:38 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:38 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:38 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:38 --> URI Class Initialized
INFO - 2016-12-19 01:54:38 --> Router Class Initialized
INFO - 2016-12-19 01:54:38 --> Output Class Initialized
INFO - 2016-12-19 01:54:38 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:38 --> Input Class Initialized
INFO - 2016-12-19 01:54:38 --> Language Class Initialized
ERROR - 2016-12-19 01:54:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:54:38 --> Config Class Initialized
INFO - 2016-12-19 01:54:38 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:38 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:38 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:38 --> URI Class Initialized
INFO - 2016-12-19 01:54:38 --> Router Class Initialized
INFO - 2016-12-19 01:54:38 --> Output Class Initialized
INFO - 2016-12-19 01:54:38 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:38 --> Input Class Initialized
INFO - 2016-12-19 01:54:38 --> Language Class Initialized
INFO - 2016-12-19 01:54:38 --> Loader Class Initialized
INFO - 2016-12-19 01:54:38 --> Database Driver Class Initialized
INFO - 2016-12-19 01:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:54:38 --> Controller Class Initialized
INFO - 2016-12-19 01:54:38 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:54:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:54:38 --> Final output sent to browser
DEBUG - 2016-12-19 01:54:38 --> Total execution time: 0.0131
INFO - 2016-12-19 01:54:46 --> Config Class Initialized
INFO - 2016-12-19 01:54:46 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:46 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:46 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:46 --> URI Class Initialized
DEBUG - 2016-12-19 01:54:46 --> No URI present. Default controller set.
INFO - 2016-12-19 01:54:46 --> Router Class Initialized
INFO - 2016-12-19 01:54:46 --> Output Class Initialized
INFO - 2016-12-19 01:54:46 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:46 --> Input Class Initialized
INFO - 2016-12-19 01:54:46 --> Language Class Initialized
INFO - 2016-12-19 01:54:46 --> Loader Class Initialized
INFO - 2016-12-19 01:54:46 --> Database Driver Class Initialized
INFO - 2016-12-19 01:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:54:46 --> Controller Class Initialized
INFO - 2016-12-19 01:54:46 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:54:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:54:46 --> Final output sent to browser
DEBUG - 2016-12-19 01:54:46 --> Total execution time: 0.0128
INFO - 2016-12-19 01:54:47 --> Config Class Initialized
INFO - 2016-12-19 01:54:47 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:47 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:47 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:47 --> URI Class Initialized
INFO - 2016-12-19 01:54:47 --> Router Class Initialized
INFO - 2016-12-19 01:54:47 --> Output Class Initialized
INFO - 2016-12-19 01:54:47 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:47 --> Input Class Initialized
INFO - 2016-12-19 01:54:47 --> Language Class Initialized
ERROR - 2016-12-19 01:54:47 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:54:47 --> Config Class Initialized
INFO - 2016-12-19 01:54:47 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:47 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:47 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:47 --> URI Class Initialized
INFO - 2016-12-19 01:54:47 --> Router Class Initialized
INFO - 2016-12-19 01:54:47 --> Output Class Initialized
INFO - 2016-12-19 01:54:47 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:47 --> Input Class Initialized
INFO - 2016-12-19 01:54:47 --> Language Class Initialized
INFO - 2016-12-19 01:54:47 --> Loader Class Initialized
INFO - 2016-12-19 01:54:47 --> Database Driver Class Initialized
INFO - 2016-12-19 01:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:54:47 --> Controller Class Initialized
INFO - 2016-12-19 01:54:47 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:54:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:54:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:54:47 --> Final output sent to browser
DEBUG - 2016-12-19 01:54:47 --> Total execution time: 0.0135
INFO - 2016-12-19 01:54:54 --> Config Class Initialized
INFO - 2016-12-19 01:54:54 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:54 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:54 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:54 --> URI Class Initialized
DEBUG - 2016-12-19 01:54:54 --> No URI present. Default controller set.
INFO - 2016-12-19 01:54:54 --> Router Class Initialized
INFO - 2016-12-19 01:54:54 --> Output Class Initialized
INFO - 2016-12-19 01:54:54 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:54 --> Input Class Initialized
INFO - 2016-12-19 01:54:54 --> Language Class Initialized
INFO - 2016-12-19 01:54:54 --> Loader Class Initialized
INFO - 2016-12-19 01:54:54 --> Database Driver Class Initialized
INFO - 2016-12-19 01:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:54:54 --> Controller Class Initialized
INFO - 2016-12-19 01:54:54 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:54:54 --> Final output sent to browser
DEBUG - 2016-12-19 01:54:54 --> Total execution time: 0.0132
INFO - 2016-12-19 01:54:55 --> Config Class Initialized
INFO - 2016-12-19 01:54:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:55 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:55 --> URI Class Initialized
INFO - 2016-12-19 01:54:55 --> Router Class Initialized
INFO - 2016-12-19 01:54:55 --> Output Class Initialized
INFO - 2016-12-19 01:54:55 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:55 --> Input Class Initialized
INFO - 2016-12-19 01:54:55 --> Language Class Initialized
ERROR - 2016-12-19 01:54:55 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:54:55 --> Config Class Initialized
INFO - 2016-12-19 01:54:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:54:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:54:55 --> Utf8 Class Initialized
INFO - 2016-12-19 01:54:55 --> URI Class Initialized
INFO - 2016-12-19 01:54:55 --> Router Class Initialized
INFO - 2016-12-19 01:54:55 --> Output Class Initialized
INFO - 2016-12-19 01:54:55 --> Security Class Initialized
DEBUG - 2016-12-19 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:54:55 --> Input Class Initialized
INFO - 2016-12-19 01:54:55 --> Language Class Initialized
INFO - 2016-12-19 01:54:55 --> Loader Class Initialized
INFO - 2016-12-19 01:54:55 --> Database Driver Class Initialized
INFO - 2016-12-19 01:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:54:55 --> Controller Class Initialized
INFO - 2016-12-19 01:54:55 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:54:55 --> Final output sent to browser
DEBUG - 2016-12-19 01:54:55 --> Total execution time: 0.0131
INFO - 2016-12-19 01:55:04 --> Config Class Initialized
INFO - 2016-12-19 01:55:04 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:04 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:04 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:04 --> URI Class Initialized
DEBUG - 2016-12-19 01:55:04 --> No URI present. Default controller set.
INFO - 2016-12-19 01:55:04 --> Router Class Initialized
INFO - 2016-12-19 01:55:04 --> Output Class Initialized
INFO - 2016-12-19 01:55:04 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:04 --> Input Class Initialized
INFO - 2016-12-19 01:55:04 --> Language Class Initialized
INFO - 2016-12-19 01:55:04 --> Loader Class Initialized
INFO - 2016-12-19 01:55:04 --> Database Driver Class Initialized
INFO - 2016-12-19 01:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:55:04 --> Controller Class Initialized
INFO - 2016-12-19 01:55:04 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:55:04 --> Final output sent to browser
DEBUG - 2016-12-19 01:55:04 --> Total execution time: 0.0131
INFO - 2016-12-19 01:55:04 --> Config Class Initialized
INFO - 2016-12-19 01:55:04 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:04 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:04 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:04 --> URI Class Initialized
INFO - 2016-12-19 01:55:04 --> Router Class Initialized
INFO - 2016-12-19 01:55:04 --> Output Class Initialized
INFO - 2016-12-19 01:55:04 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:04 --> Input Class Initialized
INFO - 2016-12-19 01:55:04 --> Language Class Initialized
ERROR - 2016-12-19 01:55:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:55:05 --> Config Class Initialized
INFO - 2016-12-19 01:55:05 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:05 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:05 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:05 --> URI Class Initialized
INFO - 2016-12-19 01:55:05 --> Router Class Initialized
INFO - 2016-12-19 01:55:05 --> Output Class Initialized
INFO - 2016-12-19 01:55:05 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:05 --> Input Class Initialized
INFO - 2016-12-19 01:55:05 --> Language Class Initialized
INFO - 2016-12-19 01:55:05 --> Loader Class Initialized
INFO - 2016-12-19 01:55:05 --> Database Driver Class Initialized
INFO - 2016-12-19 01:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:55:05 --> Controller Class Initialized
INFO - 2016-12-19 01:55:05 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:55:05 --> Final output sent to browser
DEBUG - 2016-12-19 01:55:05 --> Total execution time: 0.0133
INFO - 2016-12-19 01:55:36 --> Config Class Initialized
INFO - 2016-12-19 01:55:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:36 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:36 --> URI Class Initialized
DEBUG - 2016-12-19 01:55:36 --> No URI present. Default controller set.
INFO - 2016-12-19 01:55:36 --> Router Class Initialized
INFO - 2016-12-19 01:55:36 --> Output Class Initialized
INFO - 2016-12-19 01:55:36 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:36 --> Input Class Initialized
INFO - 2016-12-19 01:55:36 --> Language Class Initialized
INFO - 2016-12-19 01:55:36 --> Loader Class Initialized
INFO - 2016-12-19 01:55:36 --> Database Driver Class Initialized
INFO - 2016-12-19 01:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:55:36 --> Controller Class Initialized
INFO - 2016-12-19 01:55:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:55:36 --> Final output sent to browser
DEBUG - 2016-12-19 01:55:36 --> Total execution time: 0.0128
INFO - 2016-12-19 01:55:37 --> Config Class Initialized
INFO - 2016-12-19 01:55:37 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:37 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:37 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:37 --> URI Class Initialized
INFO - 2016-12-19 01:55:37 --> Router Class Initialized
INFO - 2016-12-19 01:55:37 --> Output Class Initialized
INFO - 2016-12-19 01:55:37 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:37 --> Input Class Initialized
INFO - 2016-12-19 01:55:37 --> Language Class Initialized
ERROR - 2016-12-19 01:55:37 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:55:37 --> Config Class Initialized
INFO - 2016-12-19 01:55:37 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:37 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:37 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:37 --> URI Class Initialized
INFO - 2016-12-19 01:55:37 --> Router Class Initialized
INFO - 2016-12-19 01:55:37 --> Output Class Initialized
INFO - 2016-12-19 01:55:37 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:37 --> Input Class Initialized
INFO - 2016-12-19 01:55:37 --> Language Class Initialized
INFO - 2016-12-19 01:55:37 --> Loader Class Initialized
INFO - 2016-12-19 01:55:37 --> Database Driver Class Initialized
INFO - 2016-12-19 01:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:55:37 --> Controller Class Initialized
INFO - 2016-12-19 01:55:37 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:55:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:55:37 --> Final output sent to browser
DEBUG - 2016-12-19 01:55:37 --> Total execution time: 0.0134
INFO - 2016-12-19 01:55:49 --> Config Class Initialized
INFO - 2016-12-19 01:55:49 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:49 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:49 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:49 --> URI Class Initialized
DEBUG - 2016-12-19 01:55:49 --> No URI present. Default controller set.
INFO - 2016-12-19 01:55:49 --> Router Class Initialized
INFO - 2016-12-19 01:55:49 --> Output Class Initialized
INFO - 2016-12-19 01:55:49 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:49 --> Input Class Initialized
INFO - 2016-12-19 01:55:49 --> Language Class Initialized
INFO - 2016-12-19 01:55:49 --> Loader Class Initialized
INFO - 2016-12-19 01:55:49 --> Database Driver Class Initialized
INFO - 2016-12-19 01:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:55:49 --> Controller Class Initialized
INFO - 2016-12-19 01:55:49 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:55:49 --> Final output sent to browser
DEBUG - 2016-12-19 01:55:49 --> Total execution time: 0.0128
INFO - 2016-12-19 01:55:50 --> Config Class Initialized
INFO - 2016-12-19 01:55:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:50 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:50 --> URI Class Initialized
INFO - 2016-12-19 01:55:50 --> Router Class Initialized
INFO - 2016-12-19 01:55:50 --> Output Class Initialized
INFO - 2016-12-19 01:55:50 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:50 --> Input Class Initialized
INFO - 2016-12-19 01:55:50 --> Language Class Initialized
ERROR - 2016-12-19 01:55:50 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:55:50 --> Config Class Initialized
INFO - 2016-12-19 01:55:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:55:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:55:50 --> Utf8 Class Initialized
INFO - 2016-12-19 01:55:50 --> URI Class Initialized
INFO - 2016-12-19 01:55:50 --> Router Class Initialized
INFO - 2016-12-19 01:55:50 --> Output Class Initialized
INFO - 2016-12-19 01:55:50 --> Security Class Initialized
DEBUG - 2016-12-19 01:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:55:50 --> Input Class Initialized
INFO - 2016-12-19 01:55:50 --> Language Class Initialized
INFO - 2016-12-19 01:55:50 --> Loader Class Initialized
INFO - 2016-12-19 01:55:50 --> Database Driver Class Initialized
INFO - 2016-12-19 01:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:55:50 --> Controller Class Initialized
INFO - 2016-12-19 01:55:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:55:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:55:50 --> Final output sent to browser
DEBUG - 2016-12-19 01:55:50 --> Total execution time: 0.0130
INFO - 2016-12-19 01:58:08 --> Config Class Initialized
INFO - 2016-12-19 01:58:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:58:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:58:08 --> Utf8 Class Initialized
INFO - 2016-12-19 01:58:08 --> URI Class Initialized
DEBUG - 2016-12-19 01:58:08 --> No URI present. Default controller set.
INFO - 2016-12-19 01:58:08 --> Router Class Initialized
INFO - 2016-12-19 01:58:08 --> Output Class Initialized
INFO - 2016-12-19 01:58:08 --> Security Class Initialized
DEBUG - 2016-12-19 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:58:08 --> Input Class Initialized
INFO - 2016-12-19 01:58:08 --> Language Class Initialized
INFO - 2016-12-19 01:58:08 --> Loader Class Initialized
INFO - 2016-12-19 01:58:08 --> Database Driver Class Initialized
INFO - 2016-12-19 01:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:58:08 --> Controller Class Initialized
INFO - 2016-12-19 01:58:08 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:58:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:58:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:58:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:58:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:58:08 --> Final output sent to browser
DEBUG - 2016-12-19 01:58:08 --> Total execution time: 0.0127
INFO - 2016-12-19 01:58:09 --> Config Class Initialized
INFO - 2016-12-19 01:58:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:58:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:58:09 --> Utf8 Class Initialized
INFO - 2016-12-19 01:58:09 --> URI Class Initialized
INFO - 2016-12-19 01:58:09 --> Router Class Initialized
INFO - 2016-12-19 01:58:09 --> Output Class Initialized
INFO - 2016-12-19 01:58:09 --> Security Class Initialized
DEBUG - 2016-12-19 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:58:09 --> Input Class Initialized
INFO - 2016-12-19 01:58:09 --> Language Class Initialized
ERROR - 2016-12-19 01:58:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 01:58:09 --> Config Class Initialized
INFO - 2016-12-19 01:58:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 01:58:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 01:58:09 --> Utf8 Class Initialized
INFO - 2016-12-19 01:58:09 --> URI Class Initialized
INFO - 2016-12-19 01:58:09 --> Router Class Initialized
INFO - 2016-12-19 01:58:09 --> Output Class Initialized
INFO - 2016-12-19 01:58:09 --> Security Class Initialized
DEBUG - 2016-12-19 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 01:58:09 --> Input Class Initialized
INFO - 2016-12-19 01:58:09 --> Language Class Initialized
INFO - 2016-12-19 01:58:09 --> Loader Class Initialized
INFO - 2016-12-19 01:58:09 --> Database Driver Class Initialized
INFO - 2016-12-19 01:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 01:58:09 --> Controller Class Initialized
INFO - 2016-12-19 01:58:09 --> Helper loaded: url_helper
DEBUG - 2016-12-19 01:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 01:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 01:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 01:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 01:58:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 01:58:09 --> Final output sent to browser
DEBUG - 2016-12-19 01:58:09 --> Total execution time: 0.0134
INFO - 2016-12-19 02:00:09 --> Config Class Initialized
INFO - 2016-12-19 02:00:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:00:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:00:09 --> Utf8 Class Initialized
INFO - 2016-12-19 02:00:09 --> URI Class Initialized
DEBUG - 2016-12-19 02:00:09 --> No URI present. Default controller set.
INFO - 2016-12-19 02:00:09 --> Router Class Initialized
INFO - 2016-12-19 02:00:09 --> Output Class Initialized
INFO - 2016-12-19 02:00:09 --> Security Class Initialized
DEBUG - 2016-12-19 02:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:00:09 --> Input Class Initialized
INFO - 2016-12-19 02:00:09 --> Language Class Initialized
INFO - 2016-12-19 02:00:09 --> Loader Class Initialized
INFO - 2016-12-19 02:00:09 --> Database Driver Class Initialized
INFO - 2016-12-19 02:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:00:09 --> Controller Class Initialized
INFO - 2016-12-19 02:00:09 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:00:09 --> Final output sent to browser
DEBUG - 2016-12-19 02:00:09 --> Total execution time: 0.0249
INFO - 2016-12-19 02:00:09 --> Config Class Initialized
INFO - 2016-12-19 02:00:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:00:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:00:09 --> Utf8 Class Initialized
INFO - 2016-12-19 02:00:09 --> URI Class Initialized
INFO - 2016-12-19 02:00:09 --> Router Class Initialized
INFO - 2016-12-19 02:00:09 --> Output Class Initialized
INFO - 2016-12-19 02:00:09 --> Security Class Initialized
DEBUG - 2016-12-19 02:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:00:09 --> Input Class Initialized
INFO - 2016-12-19 02:00:09 --> Language Class Initialized
ERROR - 2016-12-19 02:00:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:00:09 --> Config Class Initialized
INFO - 2016-12-19 02:00:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:00:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:00:09 --> Utf8 Class Initialized
INFO - 2016-12-19 02:00:09 --> URI Class Initialized
INFO - 2016-12-19 02:00:09 --> Router Class Initialized
INFO - 2016-12-19 02:00:09 --> Output Class Initialized
INFO - 2016-12-19 02:00:09 --> Security Class Initialized
DEBUG - 2016-12-19 02:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:00:09 --> Input Class Initialized
INFO - 2016-12-19 02:00:09 --> Language Class Initialized
INFO - 2016-12-19 02:00:09 --> Loader Class Initialized
INFO - 2016-12-19 02:00:09 --> Database Driver Class Initialized
INFO - 2016-12-19 02:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:00:09 --> Controller Class Initialized
INFO - 2016-12-19 02:00:09 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:00:09 --> Final output sent to browser
DEBUG - 2016-12-19 02:00:09 --> Total execution time: 0.0135
INFO - 2016-12-19 02:00:12 --> Config Class Initialized
INFO - 2016-12-19 02:00:12 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:00:12 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:00:12 --> Utf8 Class Initialized
INFO - 2016-12-19 02:00:12 --> URI Class Initialized
INFO - 2016-12-19 02:00:12 --> Router Class Initialized
INFO - 2016-12-19 02:00:12 --> Output Class Initialized
INFO - 2016-12-19 02:00:12 --> Security Class Initialized
DEBUG - 2016-12-19 02:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:00:12 --> Input Class Initialized
INFO - 2016-12-19 02:00:12 --> Language Class Initialized
INFO - 2016-12-19 02:00:12 --> Loader Class Initialized
INFO - 2016-12-19 02:00:12 --> Database Driver Class Initialized
INFO - 2016-12-19 02:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:00:12 --> Controller Class Initialized
INFO - 2016-12-19 02:00:12 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:00:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:00:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:00:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:00:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:00:12 --> Final output sent to browser
DEBUG - 2016-12-19 02:00:12 --> Total execution time: 0.0127
INFO - 2016-12-19 02:00:17 --> Config Class Initialized
INFO - 2016-12-19 02:00:17 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:00:17 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:00:17 --> Utf8 Class Initialized
INFO - 2016-12-19 02:00:17 --> URI Class Initialized
INFO - 2016-12-19 02:00:17 --> Router Class Initialized
INFO - 2016-12-19 02:00:17 --> Output Class Initialized
INFO - 2016-12-19 02:00:17 --> Security Class Initialized
DEBUG - 2016-12-19 02:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:00:17 --> Input Class Initialized
INFO - 2016-12-19 02:00:17 --> Language Class Initialized
INFO - 2016-12-19 02:00:17 --> Loader Class Initialized
INFO - 2016-12-19 02:00:17 --> Database Driver Class Initialized
INFO - 2016-12-19 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:00:17 --> Controller Class Initialized
INFO - 2016-12-19 02:00:17 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:00:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:00:17 --> Final output sent to browser
DEBUG - 2016-12-19 02:00:17 --> Total execution time: 0.0132
INFO - 2016-12-19 02:02:55 --> Config Class Initialized
INFO - 2016-12-19 02:02:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:02:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:02:55 --> Utf8 Class Initialized
INFO - 2016-12-19 02:02:55 --> URI Class Initialized
DEBUG - 2016-12-19 02:02:55 --> No URI present. Default controller set.
INFO - 2016-12-19 02:02:55 --> Router Class Initialized
INFO - 2016-12-19 02:02:55 --> Output Class Initialized
INFO - 2016-12-19 02:02:55 --> Security Class Initialized
DEBUG - 2016-12-19 02:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:02:55 --> Input Class Initialized
INFO - 2016-12-19 02:02:55 --> Language Class Initialized
INFO - 2016-12-19 02:02:55 --> Loader Class Initialized
INFO - 2016-12-19 02:02:55 --> Database Driver Class Initialized
INFO - 2016-12-19 02:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:02:55 --> Controller Class Initialized
INFO - 2016-12-19 02:02:55 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:02:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:02:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:02:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:02:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:02:55 --> Final output sent to browser
DEBUG - 2016-12-19 02:02:55 --> Total execution time: 0.0203
INFO - 2016-12-19 02:02:56 --> Config Class Initialized
INFO - 2016-12-19 02:02:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:02:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:02:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:02:56 --> URI Class Initialized
INFO - 2016-12-19 02:02:56 --> Router Class Initialized
INFO - 2016-12-19 02:02:56 --> Output Class Initialized
INFO - 2016-12-19 02:02:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:02:56 --> Input Class Initialized
INFO - 2016-12-19 02:02:56 --> Language Class Initialized
ERROR - 2016-12-19 02:02:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:02:56 --> Config Class Initialized
INFO - 2016-12-19 02:02:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:02:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:02:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:02:56 --> URI Class Initialized
INFO - 2016-12-19 02:02:56 --> Router Class Initialized
INFO - 2016-12-19 02:02:56 --> Output Class Initialized
INFO - 2016-12-19 02:02:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:02:56 --> Input Class Initialized
INFO - 2016-12-19 02:02:56 --> Language Class Initialized
INFO - 2016-12-19 02:02:56 --> Loader Class Initialized
INFO - 2016-12-19 02:02:56 --> Database Driver Class Initialized
INFO - 2016-12-19 02:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:02:56 --> Controller Class Initialized
INFO - 2016-12-19 02:02:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:02:56 --> Final output sent to browser
DEBUG - 2016-12-19 02:02:56 --> Total execution time: 0.0132
INFO - 2016-12-19 02:08:46 --> Config Class Initialized
INFO - 2016-12-19 02:08:46 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:08:46 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:08:46 --> Utf8 Class Initialized
INFO - 2016-12-19 02:08:46 --> URI Class Initialized
DEBUG - 2016-12-19 02:08:46 --> No URI present. Default controller set.
INFO - 2016-12-19 02:08:46 --> Router Class Initialized
INFO - 2016-12-19 02:08:46 --> Output Class Initialized
INFO - 2016-12-19 02:08:46 --> Security Class Initialized
DEBUG - 2016-12-19 02:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:08:46 --> Input Class Initialized
INFO - 2016-12-19 02:08:46 --> Language Class Initialized
INFO - 2016-12-19 02:08:46 --> Loader Class Initialized
INFO - 2016-12-19 02:08:46 --> Database Driver Class Initialized
INFO - 2016-12-19 02:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:08:46 --> Controller Class Initialized
INFO - 2016-12-19 02:08:46 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:08:46 --> Final output sent to browser
DEBUG - 2016-12-19 02:08:46 --> Total execution time: 0.0136
INFO - 2016-12-19 02:08:46 --> Config Class Initialized
INFO - 2016-12-19 02:08:46 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:08:46 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:08:46 --> Utf8 Class Initialized
INFO - 2016-12-19 02:08:46 --> URI Class Initialized
INFO - 2016-12-19 02:08:46 --> Router Class Initialized
INFO - 2016-12-19 02:08:46 --> Output Class Initialized
INFO - 2016-12-19 02:08:46 --> Security Class Initialized
DEBUG - 2016-12-19 02:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:08:46 --> Input Class Initialized
INFO - 2016-12-19 02:08:46 --> Language Class Initialized
ERROR - 2016-12-19 02:08:46 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:08:46 --> Config Class Initialized
INFO - 2016-12-19 02:08:46 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:08:46 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:08:46 --> Utf8 Class Initialized
INFO - 2016-12-19 02:08:46 --> URI Class Initialized
INFO - 2016-12-19 02:08:46 --> Router Class Initialized
INFO - 2016-12-19 02:08:46 --> Output Class Initialized
INFO - 2016-12-19 02:08:46 --> Security Class Initialized
DEBUG - 2016-12-19 02:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:08:46 --> Input Class Initialized
INFO - 2016-12-19 02:08:46 --> Language Class Initialized
INFO - 2016-12-19 02:08:46 --> Loader Class Initialized
INFO - 2016-12-19 02:08:46 --> Database Driver Class Initialized
INFO - 2016-12-19 02:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:08:46 --> Controller Class Initialized
INFO - 2016-12-19 02:08:46 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:08:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:08:46 --> Final output sent to browser
DEBUG - 2016-12-19 02:08:46 --> Total execution time: 0.0129
INFO - 2016-12-19 02:12:23 --> Config Class Initialized
INFO - 2016-12-19 02:12:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:12:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:12:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:12:23 --> URI Class Initialized
DEBUG - 2016-12-19 02:12:23 --> No URI present. Default controller set.
INFO - 2016-12-19 02:12:23 --> Router Class Initialized
INFO - 2016-12-19 02:12:23 --> Output Class Initialized
INFO - 2016-12-19 02:12:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:12:23 --> Input Class Initialized
INFO - 2016-12-19 02:12:23 --> Language Class Initialized
INFO - 2016-12-19 02:12:23 --> Loader Class Initialized
INFO - 2016-12-19 02:12:23 --> Database Driver Class Initialized
INFO - 2016-12-19 02:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:12:23 --> Controller Class Initialized
INFO - 2016-12-19 02:12:23 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:12:23 --> Final output sent to browser
DEBUG - 2016-12-19 02:12:23 --> Total execution time: 0.0128
INFO - 2016-12-19 02:12:24 --> Config Class Initialized
INFO - 2016-12-19 02:12:24 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:12:24 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:12:24 --> Utf8 Class Initialized
INFO - 2016-12-19 02:12:24 --> URI Class Initialized
INFO - 2016-12-19 02:12:24 --> Router Class Initialized
INFO - 2016-12-19 02:12:24 --> Output Class Initialized
INFO - 2016-12-19 02:12:24 --> Security Class Initialized
DEBUG - 2016-12-19 02:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:12:24 --> Input Class Initialized
INFO - 2016-12-19 02:12:24 --> Language Class Initialized
ERROR - 2016-12-19 02:12:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:12:24 --> Config Class Initialized
INFO - 2016-12-19 02:12:24 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:12:24 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:12:24 --> Utf8 Class Initialized
INFO - 2016-12-19 02:12:24 --> URI Class Initialized
INFO - 2016-12-19 02:12:24 --> Router Class Initialized
INFO - 2016-12-19 02:12:24 --> Output Class Initialized
INFO - 2016-12-19 02:12:24 --> Security Class Initialized
DEBUG - 2016-12-19 02:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:12:24 --> Input Class Initialized
INFO - 2016-12-19 02:12:24 --> Language Class Initialized
INFO - 2016-12-19 02:12:24 --> Loader Class Initialized
INFO - 2016-12-19 02:12:24 --> Database Driver Class Initialized
INFO - 2016-12-19 02:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:12:24 --> Controller Class Initialized
INFO - 2016-12-19 02:12:24 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:12:24 --> Final output sent to browser
DEBUG - 2016-12-19 02:12:24 --> Total execution time: 0.0138
INFO - 2016-12-19 02:12:29 --> Config Class Initialized
INFO - 2016-12-19 02:12:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:12:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:12:29 --> Utf8 Class Initialized
INFO - 2016-12-19 02:12:29 --> URI Class Initialized
DEBUG - 2016-12-19 02:12:29 --> No URI present. Default controller set.
INFO - 2016-12-19 02:12:29 --> Router Class Initialized
INFO - 2016-12-19 02:12:29 --> Output Class Initialized
INFO - 2016-12-19 02:12:29 --> Security Class Initialized
DEBUG - 2016-12-19 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:12:29 --> Input Class Initialized
INFO - 2016-12-19 02:12:29 --> Language Class Initialized
INFO - 2016-12-19 02:12:29 --> Loader Class Initialized
INFO - 2016-12-19 02:12:29 --> Database Driver Class Initialized
INFO - 2016-12-19 02:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:12:29 --> Controller Class Initialized
INFO - 2016-12-19 02:12:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:12:29 --> Final output sent to browser
DEBUG - 2016-12-19 02:12:29 --> Total execution time: 0.0131
INFO - 2016-12-19 02:12:30 --> Config Class Initialized
INFO - 2016-12-19 02:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:12:30 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:12:30 --> Utf8 Class Initialized
INFO - 2016-12-19 02:12:30 --> URI Class Initialized
INFO - 2016-12-19 02:12:30 --> Router Class Initialized
INFO - 2016-12-19 02:12:30 --> Output Class Initialized
INFO - 2016-12-19 02:12:30 --> Security Class Initialized
DEBUG - 2016-12-19 02:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:12:30 --> Input Class Initialized
INFO - 2016-12-19 02:12:30 --> Language Class Initialized
ERROR - 2016-12-19 02:12:30 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:12:30 --> Config Class Initialized
INFO - 2016-12-19 02:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:12:30 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:12:30 --> Utf8 Class Initialized
INFO - 2016-12-19 02:12:30 --> URI Class Initialized
INFO - 2016-12-19 02:12:30 --> Router Class Initialized
INFO - 2016-12-19 02:12:30 --> Output Class Initialized
INFO - 2016-12-19 02:12:30 --> Security Class Initialized
DEBUG - 2016-12-19 02:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:12:30 --> Input Class Initialized
INFO - 2016-12-19 02:12:30 --> Language Class Initialized
INFO - 2016-12-19 02:12:30 --> Loader Class Initialized
INFO - 2016-12-19 02:12:30 --> Database Driver Class Initialized
INFO - 2016-12-19 02:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:12:30 --> Controller Class Initialized
INFO - 2016-12-19 02:12:30 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:12:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:12:30 --> Final output sent to browser
DEBUG - 2016-12-19 02:12:30 --> Total execution time: 0.0136
INFO - 2016-12-19 02:14:22 --> Config Class Initialized
INFO - 2016-12-19 02:14:22 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:14:22 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:14:22 --> Utf8 Class Initialized
INFO - 2016-12-19 02:14:22 --> URI Class Initialized
DEBUG - 2016-12-19 02:14:22 --> No URI present. Default controller set.
INFO - 2016-12-19 02:14:22 --> Router Class Initialized
INFO - 2016-12-19 02:14:22 --> Output Class Initialized
INFO - 2016-12-19 02:14:22 --> Security Class Initialized
DEBUG - 2016-12-19 02:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:14:22 --> Input Class Initialized
INFO - 2016-12-19 02:14:22 --> Language Class Initialized
INFO - 2016-12-19 02:14:22 --> Loader Class Initialized
INFO - 2016-12-19 02:14:22 --> Database Driver Class Initialized
INFO - 2016-12-19 02:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:14:22 --> Controller Class Initialized
INFO - 2016-12-19 02:14:22 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:14:22 --> Final output sent to browser
DEBUG - 2016-12-19 02:14:22 --> Total execution time: 0.0129
INFO - 2016-12-19 02:14:22 --> Config Class Initialized
INFO - 2016-12-19 02:14:22 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:14:22 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:14:22 --> Utf8 Class Initialized
INFO - 2016-12-19 02:14:22 --> URI Class Initialized
INFO - 2016-12-19 02:14:22 --> Router Class Initialized
INFO - 2016-12-19 02:14:22 --> Output Class Initialized
INFO - 2016-12-19 02:14:22 --> Security Class Initialized
DEBUG - 2016-12-19 02:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:14:22 --> Input Class Initialized
INFO - 2016-12-19 02:14:22 --> Language Class Initialized
ERROR - 2016-12-19 02:14:22 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:14:22 --> Config Class Initialized
INFO - 2016-12-19 02:14:22 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:14:22 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:14:22 --> Utf8 Class Initialized
INFO - 2016-12-19 02:14:22 --> URI Class Initialized
INFO - 2016-12-19 02:14:22 --> Router Class Initialized
INFO - 2016-12-19 02:14:22 --> Output Class Initialized
INFO - 2016-12-19 02:14:22 --> Security Class Initialized
DEBUG - 2016-12-19 02:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:14:22 --> Input Class Initialized
INFO - 2016-12-19 02:14:22 --> Language Class Initialized
INFO - 2016-12-19 02:14:22 --> Loader Class Initialized
INFO - 2016-12-19 02:14:22 --> Database Driver Class Initialized
INFO - 2016-12-19 02:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:14:22 --> Controller Class Initialized
INFO - 2016-12-19 02:14:22 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:14:22 --> Final output sent to browser
DEBUG - 2016-12-19 02:14:22 --> Total execution time: 0.0130
INFO - 2016-12-19 02:14:56 --> Config Class Initialized
INFO - 2016-12-19 02:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:14:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:14:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:14:56 --> URI Class Initialized
DEBUG - 2016-12-19 02:14:56 --> No URI present. Default controller set.
INFO - 2016-12-19 02:14:56 --> Router Class Initialized
INFO - 2016-12-19 02:14:56 --> Output Class Initialized
INFO - 2016-12-19 02:14:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:14:56 --> Input Class Initialized
INFO - 2016-12-19 02:14:56 --> Language Class Initialized
INFO - 2016-12-19 02:14:56 --> Loader Class Initialized
INFO - 2016-12-19 02:14:56 --> Database Driver Class Initialized
INFO - 2016-12-19 02:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:14:56 --> Controller Class Initialized
INFO - 2016-12-19 02:14:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:14:56 --> Final output sent to browser
DEBUG - 2016-12-19 02:14:56 --> Total execution time: 0.0128
INFO - 2016-12-19 02:14:56 --> Config Class Initialized
INFO - 2016-12-19 02:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:14:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:14:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:14:56 --> URI Class Initialized
INFO - 2016-12-19 02:14:56 --> Router Class Initialized
INFO - 2016-12-19 02:14:56 --> Output Class Initialized
INFO - 2016-12-19 02:14:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:14:56 --> Input Class Initialized
INFO - 2016-12-19 02:14:56 --> Language Class Initialized
ERROR - 2016-12-19 02:14:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:14:56 --> Config Class Initialized
INFO - 2016-12-19 02:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:14:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:14:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:14:56 --> URI Class Initialized
INFO - 2016-12-19 02:14:56 --> Router Class Initialized
INFO - 2016-12-19 02:14:56 --> Output Class Initialized
INFO - 2016-12-19 02:14:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:14:56 --> Input Class Initialized
INFO - 2016-12-19 02:14:56 --> Language Class Initialized
INFO - 2016-12-19 02:14:56 --> Loader Class Initialized
INFO - 2016-12-19 02:14:56 --> Database Driver Class Initialized
INFO - 2016-12-19 02:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:14:56 --> Controller Class Initialized
INFO - 2016-12-19 02:14:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:14:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:14:56 --> Final output sent to browser
DEBUG - 2016-12-19 02:14:56 --> Total execution time: 0.0131
INFO - 2016-12-19 02:20:57 --> Config Class Initialized
INFO - 2016-12-19 02:20:57 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:20:57 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:20:57 --> Utf8 Class Initialized
INFO - 2016-12-19 02:20:57 --> URI Class Initialized
DEBUG - 2016-12-19 02:20:57 --> No URI present. Default controller set.
INFO - 2016-12-19 02:20:57 --> Router Class Initialized
INFO - 2016-12-19 02:20:57 --> Output Class Initialized
INFO - 2016-12-19 02:20:57 --> Security Class Initialized
DEBUG - 2016-12-19 02:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:20:57 --> Input Class Initialized
INFO - 2016-12-19 02:20:57 --> Language Class Initialized
INFO - 2016-12-19 02:20:57 --> Loader Class Initialized
INFO - 2016-12-19 02:20:57 --> Database Driver Class Initialized
INFO - 2016-12-19 02:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:20:57 --> Controller Class Initialized
INFO - 2016-12-19 02:20:57 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:20:57 --> Final output sent to browser
DEBUG - 2016-12-19 02:20:57 --> Total execution time: 0.0128
INFO - 2016-12-19 02:20:57 --> Config Class Initialized
INFO - 2016-12-19 02:20:57 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:20:57 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:20:57 --> Utf8 Class Initialized
INFO - 2016-12-19 02:20:57 --> URI Class Initialized
INFO - 2016-12-19 02:20:57 --> Router Class Initialized
INFO - 2016-12-19 02:20:57 --> Output Class Initialized
INFO - 2016-12-19 02:20:57 --> Security Class Initialized
DEBUG - 2016-12-19 02:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:20:57 --> Input Class Initialized
INFO - 2016-12-19 02:20:57 --> Language Class Initialized
ERROR - 2016-12-19 02:20:57 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:20:57 --> Config Class Initialized
INFO - 2016-12-19 02:20:57 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:20:57 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:20:57 --> Utf8 Class Initialized
INFO - 2016-12-19 02:20:57 --> URI Class Initialized
INFO - 2016-12-19 02:20:57 --> Router Class Initialized
INFO - 2016-12-19 02:20:57 --> Output Class Initialized
INFO - 2016-12-19 02:20:57 --> Security Class Initialized
DEBUG - 2016-12-19 02:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:20:57 --> Input Class Initialized
INFO - 2016-12-19 02:20:57 --> Language Class Initialized
INFO - 2016-12-19 02:20:57 --> Loader Class Initialized
INFO - 2016-12-19 02:20:57 --> Database Driver Class Initialized
INFO - 2016-12-19 02:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:20:57 --> Controller Class Initialized
INFO - 2016-12-19 02:20:57 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:20:57 --> Final output sent to browser
DEBUG - 2016-12-19 02:20:57 --> Total execution time: 0.0131
INFO - 2016-12-19 02:28:25 --> Config Class Initialized
INFO - 2016-12-19 02:28:25 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:28:25 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:28:25 --> Utf8 Class Initialized
INFO - 2016-12-19 02:28:25 --> URI Class Initialized
DEBUG - 2016-12-19 02:28:25 --> No URI present. Default controller set.
INFO - 2016-12-19 02:28:25 --> Router Class Initialized
INFO - 2016-12-19 02:28:25 --> Output Class Initialized
INFO - 2016-12-19 02:28:25 --> Security Class Initialized
DEBUG - 2016-12-19 02:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:28:25 --> Input Class Initialized
INFO - 2016-12-19 02:28:25 --> Language Class Initialized
INFO - 2016-12-19 02:28:25 --> Loader Class Initialized
INFO - 2016-12-19 02:28:25 --> Database Driver Class Initialized
INFO - 2016-12-19 02:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:28:25 --> Controller Class Initialized
INFO - 2016-12-19 02:28:25 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:28:25 --> Final output sent to browser
DEBUG - 2016-12-19 02:28:25 --> Total execution time: 0.0258
INFO - 2016-12-19 02:28:25 --> Config Class Initialized
INFO - 2016-12-19 02:28:25 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:28:25 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:28:25 --> Utf8 Class Initialized
INFO - 2016-12-19 02:28:25 --> URI Class Initialized
INFO - 2016-12-19 02:28:25 --> Router Class Initialized
INFO - 2016-12-19 02:28:25 --> Output Class Initialized
INFO - 2016-12-19 02:28:25 --> Security Class Initialized
DEBUG - 2016-12-19 02:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:28:25 --> Input Class Initialized
INFO - 2016-12-19 02:28:25 --> Language Class Initialized
ERROR - 2016-12-19 02:28:25 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:28:26 --> Config Class Initialized
INFO - 2016-12-19 02:28:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:28:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:28:26 --> Utf8 Class Initialized
INFO - 2016-12-19 02:28:26 --> URI Class Initialized
INFO - 2016-12-19 02:28:26 --> Router Class Initialized
INFO - 2016-12-19 02:28:26 --> Output Class Initialized
INFO - 2016-12-19 02:28:26 --> Security Class Initialized
DEBUG - 2016-12-19 02:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:28:26 --> Input Class Initialized
INFO - 2016-12-19 02:28:26 --> Language Class Initialized
INFO - 2016-12-19 02:28:26 --> Loader Class Initialized
INFO - 2016-12-19 02:28:26 --> Database Driver Class Initialized
INFO - 2016-12-19 02:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:28:26 --> Controller Class Initialized
INFO - 2016-12-19 02:28:26 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:28:26 --> Final output sent to browser
DEBUG - 2016-12-19 02:28:26 --> Total execution time: 0.0131
INFO - 2016-12-19 02:31:27 --> Config Class Initialized
INFO - 2016-12-19 02:31:27 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:31:27 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:31:27 --> Utf8 Class Initialized
INFO - 2016-12-19 02:31:27 --> URI Class Initialized
DEBUG - 2016-12-19 02:31:27 --> No URI present. Default controller set.
INFO - 2016-12-19 02:31:27 --> Router Class Initialized
INFO - 2016-12-19 02:31:27 --> Output Class Initialized
INFO - 2016-12-19 02:31:27 --> Security Class Initialized
DEBUG - 2016-12-19 02:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:31:27 --> Input Class Initialized
INFO - 2016-12-19 02:31:27 --> Language Class Initialized
INFO - 2016-12-19 02:31:27 --> Loader Class Initialized
INFO - 2016-12-19 02:31:27 --> Database Driver Class Initialized
INFO - 2016-12-19 02:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:31:27 --> Controller Class Initialized
INFO - 2016-12-19 02:31:27 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:31:27 --> Final output sent to browser
DEBUG - 2016-12-19 02:31:27 --> Total execution time: 0.0134
INFO - 2016-12-19 02:31:27 --> Config Class Initialized
INFO - 2016-12-19 02:31:27 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:31:27 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:31:27 --> Utf8 Class Initialized
INFO - 2016-12-19 02:31:27 --> URI Class Initialized
INFO - 2016-12-19 02:31:27 --> Router Class Initialized
INFO - 2016-12-19 02:31:27 --> Output Class Initialized
INFO - 2016-12-19 02:31:27 --> Security Class Initialized
DEBUG - 2016-12-19 02:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:31:27 --> Input Class Initialized
INFO - 2016-12-19 02:31:27 --> Language Class Initialized
ERROR - 2016-12-19 02:31:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:31:28 --> Config Class Initialized
INFO - 2016-12-19 02:31:28 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:31:28 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:31:28 --> Utf8 Class Initialized
INFO - 2016-12-19 02:31:28 --> URI Class Initialized
INFO - 2016-12-19 02:31:28 --> Router Class Initialized
INFO - 2016-12-19 02:31:28 --> Output Class Initialized
INFO - 2016-12-19 02:31:28 --> Security Class Initialized
DEBUG - 2016-12-19 02:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:31:28 --> Input Class Initialized
INFO - 2016-12-19 02:31:28 --> Language Class Initialized
ERROR - 2016-12-19 02:31:28 --> 404 Page Not Found: Js/creative.min.js
INFO - 2016-12-19 02:31:28 --> Config Class Initialized
INFO - 2016-12-19 02:31:28 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:31:28 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:31:28 --> Utf8 Class Initialized
INFO - 2016-12-19 02:31:28 --> URI Class Initialized
INFO - 2016-12-19 02:31:28 --> Router Class Initialized
INFO - 2016-12-19 02:31:28 --> Output Class Initialized
INFO - 2016-12-19 02:31:28 --> Security Class Initialized
DEBUG - 2016-12-19 02:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:31:28 --> Input Class Initialized
INFO - 2016-12-19 02:31:28 --> Language Class Initialized
INFO - 2016-12-19 02:31:28 --> Loader Class Initialized
INFO - 2016-12-19 02:31:28 --> Database Driver Class Initialized
INFO - 2016-12-19 02:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:31:28 --> Controller Class Initialized
INFO - 2016-12-19 02:31:28 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:31:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:31:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:31:28 --> Final output sent to browser
DEBUG - 2016-12-19 02:31:28 --> Total execution time: 0.0131
INFO - 2016-12-19 02:33:07 --> Config Class Initialized
INFO - 2016-12-19 02:33:07 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:33:07 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:33:07 --> Utf8 Class Initialized
INFO - 2016-12-19 02:33:07 --> URI Class Initialized
DEBUG - 2016-12-19 02:33:07 --> No URI present. Default controller set.
INFO - 2016-12-19 02:33:07 --> Router Class Initialized
INFO - 2016-12-19 02:33:07 --> Output Class Initialized
INFO - 2016-12-19 02:33:07 --> Security Class Initialized
DEBUG - 2016-12-19 02:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:33:07 --> Input Class Initialized
INFO - 2016-12-19 02:33:07 --> Language Class Initialized
INFO - 2016-12-19 02:33:07 --> Loader Class Initialized
INFO - 2016-12-19 02:33:07 --> Database Driver Class Initialized
INFO - 2016-12-19 02:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:33:07 --> Controller Class Initialized
INFO - 2016-12-19 02:33:07 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:33:07 --> Final output sent to browser
DEBUG - 2016-12-19 02:33:07 --> Total execution time: 0.0128
INFO - 2016-12-19 02:33:07 --> Config Class Initialized
INFO - 2016-12-19 02:33:07 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:33:07 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:33:07 --> Utf8 Class Initialized
INFO - 2016-12-19 02:33:07 --> URI Class Initialized
INFO - 2016-12-19 02:33:07 --> Router Class Initialized
INFO - 2016-12-19 02:33:07 --> Output Class Initialized
INFO - 2016-12-19 02:33:07 --> Security Class Initialized
DEBUG - 2016-12-19 02:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:33:07 --> Input Class Initialized
INFO - 2016-12-19 02:33:07 --> Language Class Initialized
ERROR - 2016-12-19 02:33:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:33:07 --> Config Class Initialized
INFO - 2016-12-19 02:33:07 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:33:07 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:33:07 --> Utf8 Class Initialized
INFO - 2016-12-19 02:33:07 --> URI Class Initialized
INFO - 2016-12-19 02:33:07 --> Router Class Initialized
INFO - 2016-12-19 02:33:07 --> Output Class Initialized
INFO - 2016-12-19 02:33:07 --> Security Class Initialized
DEBUG - 2016-12-19 02:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:33:07 --> Input Class Initialized
INFO - 2016-12-19 02:33:07 --> Language Class Initialized
INFO - 2016-12-19 02:33:07 --> Loader Class Initialized
INFO - 2016-12-19 02:33:07 --> Database Driver Class Initialized
INFO - 2016-12-19 02:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:33:07 --> Controller Class Initialized
INFO - 2016-12-19 02:33:07 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:33:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:33:07 --> Final output sent to browser
DEBUG - 2016-12-19 02:33:07 --> Total execution time: 0.0131
INFO - 2016-12-19 02:33:23 --> Config Class Initialized
INFO - 2016-12-19 02:33:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:33:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:33:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:33:23 --> URI Class Initialized
INFO - 2016-12-19 02:33:23 --> Router Class Initialized
INFO - 2016-12-19 02:33:23 --> Output Class Initialized
INFO - 2016-12-19 02:33:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:33:23 --> Input Class Initialized
INFO - 2016-12-19 02:33:23 --> Language Class Initialized
ERROR - 2016-12-19 02:33:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:33:23 --> Config Class Initialized
INFO - 2016-12-19 02:33:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:33:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:33:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:33:23 --> URI Class Initialized
INFO - 2016-12-19 02:33:23 --> Router Class Initialized
INFO - 2016-12-19 02:33:23 --> Output Class Initialized
INFO - 2016-12-19 02:33:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:33:23 --> Input Class Initialized
INFO - 2016-12-19 02:33:23 --> Language Class Initialized
ERROR - 2016-12-19 02:33:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:36:26 --> Config Class Initialized
INFO - 2016-12-19 02:36:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:36:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:36:26 --> Utf8 Class Initialized
INFO - 2016-12-19 02:36:26 --> URI Class Initialized
INFO - 2016-12-19 02:36:26 --> Router Class Initialized
INFO - 2016-12-19 02:36:26 --> Output Class Initialized
INFO - 2016-12-19 02:36:26 --> Security Class Initialized
DEBUG - 2016-12-19 02:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:36:26 --> Input Class Initialized
INFO - 2016-12-19 02:36:26 --> Language Class Initialized
ERROR - 2016-12-19 02:36:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:04 --> Config Class Initialized
INFO - 2016-12-19 02:37:04 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:04 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:04 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:04 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:04 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:04 --> Router Class Initialized
INFO - 2016-12-19 02:37:04 --> Output Class Initialized
INFO - 2016-12-19 02:37:04 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:04 --> Input Class Initialized
INFO - 2016-12-19 02:37:04 --> Language Class Initialized
INFO - 2016-12-19 02:37:04 --> Loader Class Initialized
INFO - 2016-12-19 02:37:04 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:04 --> Controller Class Initialized
INFO - 2016-12-19 02:37:04 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:04 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:04 --> Total execution time: 0.0131
INFO - 2016-12-19 02:37:05 --> Config Class Initialized
INFO - 2016-12-19 02:37:05 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:05 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:05 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:05 --> URI Class Initialized
INFO - 2016-12-19 02:37:05 --> Router Class Initialized
INFO - 2016-12-19 02:37:05 --> Output Class Initialized
INFO - 2016-12-19 02:37:05 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:05 --> Input Class Initialized
INFO - 2016-12-19 02:37:05 --> Language Class Initialized
ERROR - 2016-12-19 02:37:05 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:05 --> Config Class Initialized
INFO - 2016-12-19 02:37:05 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:05 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:05 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:05 --> URI Class Initialized
INFO - 2016-12-19 02:37:05 --> Router Class Initialized
INFO - 2016-12-19 02:37:05 --> Output Class Initialized
INFO - 2016-12-19 02:37:05 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:05 --> Input Class Initialized
INFO - 2016-12-19 02:37:05 --> Language Class Initialized
ERROR - 2016-12-19 02:37:05 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:05 --> Config Class Initialized
INFO - 2016-12-19 02:37:05 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:05 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:05 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:05 --> URI Class Initialized
INFO - 2016-12-19 02:37:05 --> Router Class Initialized
INFO - 2016-12-19 02:37:05 --> Output Class Initialized
INFO - 2016-12-19 02:37:05 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:05 --> Input Class Initialized
INFO - 2016-12-19 02:37:05 --> Language Class Initialized
INFO - 2016-12-19 02:37:05 --> Loader Class Initialized
INFO - 2016-12-19 02:37:05 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:05 --> Controller Class Initialized
INFO - 2016-12-19 02:37:05 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:05 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:05 --> Total execution time: 0.0131
INFO - 2016-12-19 02:37:15 --> Config Class Initialized
INFO - 2016-12-19 02:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:15 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:15 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:15 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:15 --> Router Class Initialized
INFO - 2016-12-19 02:37:15 --> Output Class Initialized
INFO - 2016-12-19 02:37:15 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:15 --> Input Class Initialized
INFO - 2016-12-19 02:37:15 --> Language Class Initialized
INFO - 2016-12-19 02:37:15 --> Loader Class Initialized
INFO - 2016-12-19 02:37:15 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:15 --> Controller Class Initialized
INFO - 2016-12-19 02:37:15 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:15 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:15 --> Total execution time: 0.0130
INFO - 2016-12-19 02:37:15 --> Config Class Initialized
INFO - 2016-12-19 02:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:15 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:15 --> URI Class Initialized
INFO - 2016-12-19 02:37:15 --> Router Class Initialized
INFO - 2016-12-19 02:37:15 --> Output Class Initialized
INFO - 2016-12-19 02:37:15 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:15 --> Input Class Initialized
INFO - 2016-12-19 02:37:15 --> Language Class Initialized
ERROR - 2016-12-19 02:37:15 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:15 --> Config Class Initialized
INFO - 2016-12-19 02:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:15 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:15 --> URI Class Initialized
INFO - 2016-12-19 02:37:15 --> Router Class Initialized
INFO - 2016-12-19 02:37:15 --> Output Class Initialized
INFO - 2016-12-19 02:37:15 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:15 --> Input Class Initialized
INFO - 2016-12-19 02:37:15 --> Language Class Initialized
ERROR - 2016-12-19 02:37:15 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:15 --> Config Class Initialized
INFO - 2016-12-19 02:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:15 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:15 --> URI Class Initialized
INFO - 2016-12-19 02:37:15 --> Router Class Initialized
INFO - 2016-12-19 02:37:15 --> Output Class Initialized
INFO - 2016-12-19 02:37:15 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:15 --> Input Class Initialized
INFO - 2016-12-19 02:37:15 --> Language Class Initialized
INFO - 2016-12-19 02:37:15 --> Loader Class Initialized
INFO - 2016-12-19 02:37:15 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:15 --> Controller Class Initialized
INFO - 2016-12-19 02:37:15 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:15 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:15 --> Total execution time: 0.0136
INFO - 2016-12-19 02:37:17 --> Config Class Initialized
INFO - 2016-12-19 02:37:17 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:17 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:17 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:17 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:17 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:17 --> Router Class Initialized
INFO - 2016-12-19 02:37:17 --> Output Class Initialized
INFO - 2016-12-19 02:37:17 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:17 --> Input Class Initialized
INFO - 2016-12-19 02:37:17 --> Language Class Initialized
INFO - 2016-12-19 02:37:17 --> Loader Class Initialized
INFO - 2016-12-19 02:37:17 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:17 --> Controller Class Initialized
INFO - 2016-12-19 02:37:17 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:17 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:17 --> Total execution time: 0.0135
INFO - 2016-12-19 02:37:18 --> Config Class Initialized
INFO - 2016-12-19 02:37:18 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:18 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:18 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:18 --> URI Class Initialized
INFO - 2016-12-19 02:37:18 --> Router Class Initialized
INFO - 2016-12-19 02:37:18 --> Output Class Initialized
INFO - 2016-12-19 02:37:18 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:18 --> Input Class Initialized
INFO - 2016-12-19 02:37:18 --> Language Class Initialized
ERROR - 2016-12-19 02:37:18 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:18 --> Config Class Initialized
INFO - 2016-12-19 02:37:18 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:18 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:18 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:18 --> URI Class Initialized
INFO - 2016-12-19 02:37:18 --> Router Class Initialized
INFO - 2016-12-19 02:37:18 --> Output Class Initialized
INFO - 2016-12-19 02:37:18 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:18 --> Input Class Initialized
INFO - 2016-12-19 02:37:18 --> Language Class Initialized
ERROR - 2016-12-19 02:37:18 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:18 --> Config Class Initialized
INFO - 2016-12-19 02:37:18 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:18 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:18 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:18 --> URI Class Initialized
INFO - 2016-12-19 02:37:18 --> Router Class Initialized
INFO - 2016-12-19 02:37:18 --> Output Class Initialized
INFO - 2016-12-19 02:37:18 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:18 --> Input Class Initialized
INFO - 2016-12-19 02:37:18 --> Language Class Initialized
INFO - 2016-12-19 02:37:18 --> Loader Class Initialized
INFO - 2016-12-19 02:37:18 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:18 --> Controller Class Initialized
INFO - 2016-12-19 02:37:18 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:18 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:18 --> Total execution time: 0.0133
INFO - 2016-12-19 02:37:20 --> Config Class Initialized
INFO - 2016-12-19 02:37:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:20 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:20 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:20 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:20 --> Router Class Initialized
INFO - 2016-12-19 02:37:20 --> Output Class Initialized
INFO - 2016-12-19 02:37:20 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:20 --> Input Class Initialized
INFO - 2016-12-19 02:37:20 --> Language Class Initialized
INFO - 2016-12-19 02:37:20 --> Loader Class Initialized
INFO - 2016-12-19 02:37:20 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:20 --> Controller Class Initialized
INFO - 2016-12-19 02:37:20 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:20 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:20 --> Total execution time: 0.0131
INFO - 2016-12-19 02:37:21 --> Config Class Initialized
INFO - 2016-12-19 02:37:21 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:21 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:21 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:21 --> URI Class Initialized
INFO - 2016-12-19 02:37:21 --> Router Class Initialized
INFO - 2016-12-19 02:37:21 --> Output Class Initialized
INFO - 2016-12-19 02:37:21 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:21 --> Input Class Initialized
INFO - 2016-12-19 02:37:21 --> Language Class Initialized
ERROR - 2016-12-19 02:37:21 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:21 --> Config Class Initialized
INFO - 2016-12-19 02:37:21 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:21 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:21 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:21 --> URI Class Initialized
INFO - 2016-12-19 02:37:21 --> Router Class Initialized
INFO - 2016-12-19 02:37:21 --> Output Class Initialized
INFO - 2016-12-19 02:37:21 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:21 --> Input Class Initialized
INFO - 2016-12-19 02:37:21 --> Language Class Initialized
ERROR - 2016-12-19 02:37:21 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:21 --> Config Class Initialized
INFO - 2016-12-19 02:37:21 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:21 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:21 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:21 --> URI Class Initialized
INFO - 2016-12-19 02:37:21 --> Router Class Initialized
INFO - 2016-12-19 02:37:21 --> Output Class Initialized
INFO - 2016-12-19 02:37:21 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:21 --> Input Class Initialized
INFO - 2016-12-19 02:37:21 --> Language Class Initialized
INFO - 2016-12-19 02:37:21 --> Loader Class Initialized
INFO - 2016-12-19 02:37:21 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:21 --> Controller Class Initialized
INFO - 2016-12-19 02:37:21 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:21 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:21 --> Total execution time: 0.0130
INFO - 2016-12-19 02:37:23 --> Config Class Initialized
INFO - 2016-12-19 02:37:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:23 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:23 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:23 --> Router Class Initialized
INFO - 2016-12-19 02:37:23 --> Output Class Initialized
INFO - 2016-12-19 02:37:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:23 --> Input Class Initialized
INFO - 2016-12-19 02:37:23 --> Language Class Initialized
INFO - 2016-12-19 02:37:23 --> Loader Class Initialized
INFO - 2016-12-19 02:37:23 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:23 --> Controller Class Initialized
INFO - 2016-12-19 02:37:23 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:23 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:23 --> Total execution time: 0.0133
INFO - 2016-12-19 02:37:23 --> Config Class Initialized
INFO - 2016-12-19 02:37:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:23 --> URI Class Initialized
INFO - 2016-12-19 02:37:23 --> Router Class Initialized
INFO - 2016-12-19 02:37:23 --> Output Class Initialized
INFO - 2016-12-19 02:37:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:23 --> Input Class Initialized
INFO - 2016-12-19 02:37:23 --> Language Class Initialized
ERROR - 2016-12-19 02:37:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:23 --> Config Class Initialized
INFO - 2016-12-19 02:37:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:23 --> URI Class Initialized
INFO - 2016-12-19 02:37:23 --> Router Class Initialized
INFO - 2016-12-19 02:37:23 --> Output Class Initialized
INFO - 2016-12-19 02:37:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:24 --> Input Class Initialized
INFO - 2016-12-19 02:37:24 --> Language Class Initialized
ERROR - 2016-12-19 02:37:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:24 --> Config Class Initialized
INFO - 2016-12-19 02:37:24 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:24 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:24 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:24 --> URI Class Initialized
INFO - 2016-12-19 02:37:24 --> Router Class Initialized
INFO - 2016-12-19 02:37:24 --> Output Class Initialized
INFO - 2016-12-19 02:37:24 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:24 --> Input Class Initialized
INFO - 2016-12-19 02:37:24 --> Language Class Initialized
INFO - 2016-12-19 02:37:24 --> Loader Class Initialized
INFO - 2016-12-19 02:37:24 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:24 --> Controller Class Initialized
INFO - 2016-12-19 02:37:24 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:24 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:24 --> Total execution time: 0.0130
INFO - 2016-12-19 02:37:26 --> Config Class Initialized
INFO - 2016-12-19 02:37:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:26 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:26 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:26 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:26 --> Router Class Initialized
INFO - 2016-12-19 02:37:26 --> Output Class Initialized
INFO - 2016-12-19 02:37:26 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:26 --> Input Class Initialized
INFO - 2016-12-19 02:37:26 --> Language Class Initialized
INFO - 2016-12-19 02:37:26 --> Loader Class Initialized
INFO - 2016-12-19 02:37:26 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:26 --> Controller Class Initialized
INFO - 2016-12-19 02:37:26 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:26 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:26 --> Total execution time: 0.0134
INFO - 2016-12-19 02:37:26 --> Config Class Initialized
INFO - 2016-12-19 02:37:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:26 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:26 --> URI Class Initialized
INFO - 2016-12-19 02:37:26 --> Router Class Initialized
INFO - 2016-12-19 02:37:26 --> Output Class Initialized
INFO - 2016-12-19 02:37:26 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:26 --> Input Class Initialized
INFO - 2016-12-19 02:37:26 --> Language Class Initialized
ERROR - 2016-12-19 02:37:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:26 --> Config Class Initialized
INFO - 2016-12-19 02:37:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:26 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:26 --> URI Class Initialized
INFO - 2016-12-19 02:37:26 --> Router Class Initialized
INFO - 2016-12-19 02:37:26 --> Output Class Initialized
INFO - 2016-12-19 02:37:26 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:26 --> Input Class Initialized
INFO - 2016-12-19 02:37:26 --> Language Class Initialized
ERROR - 2016-12-19 02:37:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:27 --> Config Class Initialized
INFO - 2016-12-19 02:37:27 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:27 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:27 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:27 --> URI Class Initialized
INFO - 2016-12-19 02:37:27 --> Router Class Initialized
INFO - 2016-12-19 02:37:27 --> Output Class Initialized
INFO - 2016-12-19 02:37:27 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:27 --> Input Class Initialized
INFO - 2016-12-19 02:37:27 --> Language Class Initialized
INFO - 2016-12-19 02:37:27 --> Loader Class Initialized
INFO - 2016-12-19 02:37:27 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:27 --> Controller Class Initialized
INFO - 2016-12-19 02:37:27 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:27 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:27 --> Total execution time: 0.0134
INFO - 2016-12-19 02:37:29 --> Config Class Initialized
INFO - 2016-12-19 02:37:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:29 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:29 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:29 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:29 --> Router Class Initialized
INFO - 2016-12-19 02:37:29 --> Output Class Initialized
INFO - 2016-12-19 02:37:29 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:29 --> Input Class Initialized
INFO - 2016-12-19 02:37:29 --> Language Class Initialized
INFO - 2016-12-19 02:37:29 --> Loader Class Initialized
INFO - 2016-12-19 02:37:29 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:29 --> Controller Class Initialized
INFO - 2016-12-19 02:37:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:29 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:29 --> Total execution time: 0.0135
INFO - 2016-12-19 02:37:29 --> Config Class Initialized
INFO - 2016-12-19 02:37:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:29 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:29 --> URI Class Initialized
INFO - 2016-12-19 02:37:29 --> Router Class Initialized
INFO - 2016-12-19 02:37:29 --> Output Class Initialized
INFO - 2016-12-19 02:37:29 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:29 --> Input Class Initialized
INFO - 2016-12-19 02:37:29 --> Language Class Initialized
ERROR - 2016-12-19 02:37:29 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:29 --> Config Class Initialized
INFO - 2016-12-19 02:37:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:29 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:29 --> URI Class Initialized
INFO - 2016-12-19 02:37:29 --> Router Class Initialized
INFO - 2016-12-19 02:37:29 --> Output Class Initialized
INFO - 2016-12-19 02:37:29 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:29 --> Input Class Initialized
INFO - 2016-12-19 02:37:29 --> Language Class Initialized
ERROR - 2016-12-19 02:37:29 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:29 --> Config Class Initialized
INFO - 2016-12-19 02:37:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:29 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:29 --> URI Class Initialized
INFO - 2016-12-19 02:37:29 --> Router Class Initialized
INFO - 2016-12-19 02:37:29 --> Output Class Initialized
INFO - 2016-12-19 02:37:29 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:29 --> Input Class Initialized
INFO - 2016-12-19 02:37:29 --> Language Class Initialized
INFO - 2016-12-19 02:37:29 --> Loader Class Initialized
INFO - 2016-12-19 02:37:29 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:29 --> Controller Class Initialized
INFO - 2016-12-19 02:37:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:29 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:29 --> Total execution time: 0.0149
INFO - 2016-12-19 02:37:31 --> Config Class Initialized
INFO - 2016-12-19 02:37:31 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:31 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:31 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:31 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:31 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:31 --> Router Class Initialized
INFO - 2016-12-19 02:37:31 --> Output Class Initialized
INFO - 2016-12-19 02:37:31 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:31 --> Input Class Initialized
INFO - 2016-12-19 02:37:31 --> Language Class Initialized
INFO - 2016-12-19 02:37:31 --> Loader Class Initialized
INFO - 2016-12-19 02:37:31 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:31 --> Controller Class Initialized
INFO - 2016-12-19 02:37:31 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:31 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:31 --> Total execution time: 0.0138
INFO - 2016-12-19 02:37:31 --> Config Class Initialized
INFO - 2016-12-19 02:37:31 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:31 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:31 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:31 --> URI Class Initialized
INFO - 2016-12-19 02:37:31 --> Router Class Initialized
INFO - 2016-12-19 02:37:31 --> Output Class Initialized
INFO - 2016-12-19 02:37:31 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:31 --> Input Class Initialized
INFO - 2016-12-19 02:37:31 --> Language Class Initialized
ERROR - 2016-12-19 02:37:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:31 --> Config Class Initialized
INFO - 2016-12-19 02:37:31 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:31 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:31 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:31 --> URI Class Initialized
INFO - 2016-12-19 02:37:31 --> Router Class Initialized
INFO - 2016-12-19 02:37:31 --> Output Class Initialized
INFO - 2016-12-19 02:37:31 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:31 --> Input Class Initialized
INFO - 2016-12-19 02:37:31 --> Language Class Initialized
ERROR - 2016-12-19 02:37:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:32 --> Config Class Initialized
INFO - 2016-12-19 02:37:32 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:32 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:32 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:32 --> URI Class Initialized
INFO - 2016-12-19 02:37:32 --> Router Class Initialized
INFO - 2016-12-19 02:37:32 --> Output Class Initialized
INFO - 2016-12-19 02:37:32 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:32 --> Input Class Initialized
INFO - 2016-12-19 02:37:32 --> Language Class Initialized
INFO - 2016-12-19 02:37:32 --> Loader Class Initialized
INFO - 2016-12-19 02:37:32 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:32 --> Controller Class Initialized
INFO - 2016-12-19 02:37:32 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:32 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:32 --> Total execution time: 0.0144
INFO - 2016-12-19 02:37:53 --> Config Class Initialized
INFO - 2016-12-19 02:37:53 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:53 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:53 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:53 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:53 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:53 --> Router Class Initialized
INFO - 2016-12-19 02:37:53 --> Output Class Initialized
INFO - 2016-12-19 02:37:53 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:53 --> Input Class Initialized
INFO - 2016-12-19 02:37:53 --> Language Class Initialized
INFO - 2016-12-19 02:37:53 --> Loader Class Initialized
INFO - 2016-12-19 02:37:53 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:53 --> Controller Class Initialized
INFO - 2016-12-19 02:37:53 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:53 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:53 --> Total execution time: 0.0128
INFO - 2016-12-19 02:37:54 --> Config Class Initialized
INFO - 2016-12-19 02:37:54 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:54 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:54 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:54 --> URI Class Initialized
INFO - 2016-12-19 02:37:54 --> Router Class Initialized
INFO - 2016-12-19 02:37:54 --> Output Class Initialized
INFO - 2016-12-19 02:37:54 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:54 --> Input Class Initialized
INFO - 2016-12-19 02:37:54 --> Language Class Initialized
ERROR - 2016-12-19 02:37:54 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:54 --> Config Class Initialized
INFO - 2016-12-19 02:37:54 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:54 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:54 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:54 --> URI Class Initialized
INFO - 2016-12-19 02:37:54 --> Router Class Initialized
INFO - 2016-12-19 02:37:54 --> Output Class Initialized
INFO - 2016-12-19 02:37:54 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:54 --> Input Class Initialized
INFO - 2016-12-19 02:37:54 --> Language Class Initialized
INFO - 2016-12-19 02:37:54 --> Loader Class Initialized
INFO - 2016-12-19 02:37:54 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:54 --> Controller Class Initialized
INFO - 2016-12-19 02:37:54 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:54 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:54 --> Total execution time: 0.0131
INFO - 2016-12-19 02:37:56 --> Config Class Initialized
INFO - 2016-12-19 02:37:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:56 --> URI Class Initialized
DEBUG - 2016-12-19 02:37:56 --> No URI present. Default controller set.
INFO - 2016-12-19 02:37:56 --> Router Class Initialized
INFO - 2016-12-19 02:37:56 --> Output Class Initialized
INFO - 2016-12-19 02:37:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:56 --> Input Class Initialized
INFO - 2016-12-19 02:37:56 --> Language Class Initialized
INFO - 2016-12-19 02:37:56 --> Loader Class Initialized
INFO - 2016-12-19 02:37:56 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:56 --> Controller Class Initialized
INFO - 2016-12-19 02:37:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:56 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:56 --> Total execution time: 0.0128
INFO - 2016-12-19 02:37:56 --> Config Class Initialized
INFO - 2016-12-19 02:37:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:56 --> URI Class Initialized
INFO - 2016-12-19 02:37:56 --> Router Class Initialized
INFO - 2016-12-19 02:37:56 --> Output Class Initialized
INFO - 2016-12-19 02:37:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:56 --> Input Class Initialized
INFO - 2016-12-19 02:37:56 --> Language Class Initialized
ERROR - 2016-12-19 02:37:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:37:57 --> Config Class Initialized
INFO - 2016-12-19 02:37:57 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:37:57 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:37:57 --> Utf8 Class Initialized
INFO - 2016-12-19 02:37:57 --> URI Class Initialized
INFO - 2016-12-19 02:37:57 --> Router Class Initialized
INFO - 2016-12-19 02:37:57 --> Output Class Initialized
INFO - 2016-12-19 02:37:57 --> Security Class Initialized
DEBUG - 2016-12-19 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:37:57 --> Input Class Initialized
INFO - 2016-12-19 02:37:57 --> Language Class Initialized
INFO - 2016-12-19 02:37:57 --> Loader Class Initialized
INFO - 2016-12-19 02:37:57 --> Database Driver Class Initialized
INFO - 2016-12-19 02:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:37:57 --> Controller Class Initialized
INFO - 2016-12-19 02:37:57 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:37:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:37:57 --> Final output sent to browser
DEBUG - 2016-12-19 02:37:57 --> Total execution time: 0.0132
INFO - 2016-12-19 02:41:46 --> Config Class Initialized
INFO - 2016-12-19 02:41:46 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:41:46 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:41:46 --> Utf8 Class Initialized
INFO - 2016-12-19 02:41:46 --> URI Class Initialized
DEBUG - 2016-12-19 02:41:46 --> No URI present. Default controller set.
INFO - 2016-12-19 02:41:46 --> Router Class Initialized
INFO - 2016-12-19 02:41:46 --> Output Class Initialized
INFO - 2016-12-19 02:41:46 --> Security Class Initialized
DEBUG - 2016-12-19 02:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:41:46 --> Input Class Initialized
INFO - 2016-12-19 02:41:46 --> Language Class Initialized
INFO - 2016-12-19 02:41:46 --> Loader Class Initialized
INFO - 2016-12-19 02:41:47 --> Database Driver Class Initialized
INFO - 2016-12-19 02:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:41:47 --> Controller Class Initialized
INFO - 2016-12-19 02:41:47 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:41:47 --> Final output sent to browser
DEBUG - 2016-12-19 02:41:47 --> Total execution time: 0.0128
INFO - 2016-12-19 02:41:47 --> Config Class Initialized
INFO - 2016-12-19 02:41:47 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:41:47 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:41:47 --> Utf8 Class Initialized
INFO - 2016-12-19 02:41:47 --> URI Class Initialized
INFO - 2016-12-19 02:41:47 --> Router Class Initialized
INFO - 2016-12-19 02:41:47 --> Output Class Initialized
INFO - 2016-12-19 02:41:47 --> Security Class Initialized
DEBUG - 2016-12-19 02:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:41:47 --> Input Class Initialized
INFO - 2016-12-19 02:41:47 --> Language Class Initialized
INFO - 2016-12-19 02:41:47 --> Loader Class Initialized
INFO - 2016-12-19 02:41:47 --> Database Driver Class Initialized
INFO - 2016-12-19 02:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:41:47 --> Controller Class Initialized
INFO - 2016-12-19 02:41:47 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:41:47 --> Final output sent to browser
DEBUG - 2016-12-19 02:41:47 --> Total execution time: 0.0130
INFO - 2016-12-19 02:46:14 --> Config Class Initialized
INFO - 2016-12-19 02:46:14 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:14 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:14 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:14 --> URI Class Initialized
DEBUG - 2016-12-19 02:46:14 --> No URI present. Default controller set.
INFO - 2016-12-19 02:46:14 --> Router Class Initialized
INFO - 2016-12-19 02:46:14 --> Output Class Initialized
INFO - 2016-12-19 02:46:14 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:14 --> Input Class Initialized
INFO - 2016-12-19 02:46:14 --> Language Class Initialized
INFO - 2016-12-19 02:46:14 --> Loader Class Initialized
INFO - 2016-12-19 02:46:14 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:14 --> Controller Class Initialized
INFO - 2016-12-19 02:46:14 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:14 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:14 --> Total execution time: 0.0147
INFO - 2016-12-19 02:46:14 --> Config Class Initialized
INFO - 2016-12-19 02:46:14 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:14 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:14 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:14 --> URI Class Initialized
INFO - 2016-12-19 02:46:14 --> Router Class Initialized
INFO - 2016-12-19 02:46:14 --> Output Class Initialized
INFO - 2016-12-19 02:46:14 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:14 --> Input Class Initialized
INFO - 2016-12-19 02:46:14 --> Language Class Initialized
ERROR - 2016-12-19 02:46:14 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:46:14 --> Config Class Initialized
INFO - 2016-12-19 02:46:14 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:14 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:14 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:14 --> URI Class Initialized
INFO - 2016-12-19 02:46:14 --> Router Class Initialized
INFO - 2016-12-19 02:46:14 --> Output Class Initialized
INFO - 2016-12-19 02:46:14 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:14 --> Input Class Initialized
INFO - 2016-12-19 02:46:14 --> Language Class Initialized
INFO - 2016-12-19 02:46:14 --> Loader Class Initialized
INFO - 2016-12-19 02:46:14 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:14 --> Controller Class Initialized
INFO - 2016-12-19 02:46:14 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:14 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:14 --> Total execution time: 0.0131
INFO - 2016-12-19 02:46:23 --> Config Class Initialized
INFO - 2016-12-19 02:46:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:23 --> URI Class Initialized
DEBUG - 2016-12-19 02:46:23 --> No URI present. Default controller set.
INFO - 2016-12-19 02:46:23 --> Router Class Initialized
INFO - 2016-12-19 02:46:23 --> Output Class Initialized
INFO - 2016-12-19 02:46:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:23 --> Input Class Initialized
INFO - 2016-12-19 02:46:23 --> Language Class Initialized
INFO - 2016-12-19 02:46:23 --> Loader Class Initialized
INFO - 2016-12-19 02:46:23 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:23 --> Controller Class Initialized
INFO - 2016-12-19 02:46:23 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:23 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:23 --> Total execution time: 0.0131
INFO - 2016-12-19 02:46:23 --> Config Class Initialized
INFO - 2016-12-19 02:46:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:23 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:23 --> URI Class Initialized
INFO - 2016-12-19 02:46:23 --> Router Class Initialized
INFO - 2016-12-19 02:46:23 --> Output Class Initialized
INFO - 2016-12-19 02:46:23 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:23 --> Input Class Initialized
INFO - 2016-12-19 02:46:23 --> Language Class Initialized
ERROR - 2016-12-19 02:46:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:46:24 --> Config Class Initialized
INFO - 2016-12-19 02:46:24 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:24 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:24 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:24 --> URI Class Initialized
INFO - 2016-12-19 02:46:24 --> Router Class Initialized
INFO - 2016-12-19 02:46:24 --> Output Class Initialized
INFO - 2016-12-19 02:46:24 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:24 --> Input Class Initialized
INFO - 2016-12-19 02:46:24 --> Language Class Initialized
INFO - 2016-12-19 02:46:24 --> Loader Class Initialized
INFO - 2016-12-19 02:46:24 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:24 --> Controller Class Initialized
INFO - 2016-12-19 02:46:24 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:24 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:24 --> Total execution time: 0.0130
INFO - 2016-12-19 02:46:25 --> Config Class Initialized
INFO - 2016-12-19 02:46:25 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:25 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:25 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:25 --> URI Class Initialized
INFO - 2016-12-19 02:46:25 --> Router Class Initialized
INFO - 2016-12-19 02:46:25 --> Output Class Initialized
INFO - 2016-12-19 02:46:25 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:25 --> Input Class Initialized
INFO - 2016-12-19 02:46:25 --> Language Class Initialized
ERROR - 2016-12-19 02:46:25 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:46:42 --> Config Class Initialized
INFO - 2016-12-19 02:46:42 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:42 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:42 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:42 --> URI Class Initialized
DEBUG - 2016-12-19 02:46:42 --> No URI present. Default controller set.
INFO - 2016-12-19 02:46:42 --> Router Class Initialized
INFO - 2016-12-19 02:46:42 --> Output Class Initialized
INFO - 2016-12-19 02:46:42 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:42 --> Input Class Initialized
INFO - 2016-12-19 02:46:42 --> Language Class Initialized
INFO - 2016-12-19 02:46:42 --> Loader Class Initialized
INFO - 2016-12-19 02:46:42 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:42 --> Controller Class Initialized
INFO - 2016-12-19 02:46:42 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:42 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:42 --> Total execution time: 0.0133
INFO - 2016-12-19 02:46:42 --> Config Class Initialized
INFO - 2016-12-19 02:46:42 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:42 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:42 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:42 --> URI Class Initialized
INFO - 2016-12-19 02:46:42 --> Router Class Initialized
INFO - 2016-12-19 02:46:42 --> Output Class Initialized
INFO - 2016-12-19 02:46:42 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:42 --> Input Class Initialized
INFO - 2016-12-19 02:46:42 --> Language Class Initialized
ERROR - 2016-12-19 02:46:42 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:46:43 --> Config Class Initialized
INFO - 2016-12-19 02:46:43 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:43 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:43 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:43 --> URI Class Initialized
INFO - 2016-12-19 02:46:43 --> Router Class Initialized
INFO - 2016-12-19 02:46:43 --> Output Class Initialized
INFO - 2016-12-19 02:46:43 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:43 --> Input Class Initialized
INFO - 2016-12-19 02:46:43 --> Language Class Initialized
INFO - 2016-12-19 02:46:43 --> Loader Class Initialized
INFO - 2016-12-19 02:46:43 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:43 --> Controller Class Initialized
INFO - 2016-12-19 02:46:43 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:43 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:43 --> Total execution time: 0.0134
INFO - 2016-12-19 02:46:51 --> Config Class Initialized
INFO - 2016-12-19 02:46:51 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:51 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:51 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:51 --> URI Class Initialized
DEBUG - 2016-12-19 02:46:51 --> No URI present. Default controller set.
INFO - 2016-12-19 02:46:51 --> Router Class Initialized
INFO - 2016-12-19 02:46:51 --> Output Class Initialized
INFO - 2016-12-19 02:46:51 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:51 --> Input Class Initialized
INFO - 2016-12-19 02:46:51 --> Language Class Initialized
INFO - 2016-12-19 02:46:51 --> Loader Class Initialized
INFO - 2016-12-19 02:46:51 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:51 --> Controller Class Initialized
INFO - 2016-12-19 02:46:51 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:51 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:51 --> Total execution time: 0.0129
INFO - 2016-12-19 02:46:51 --> Config Class Initialized
INFO - 2016-12-19 02:46:51 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:51 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:51 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:51 --> URI Class Initialized
INFO - 2016-12-19 02:46:51 --> Router Class Initialized
INFO - 2016-12-19 02:46:51 --> Output Class Initialized
INFO - 2016-12-19 02:46:51 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:51 --> Input Class Initialized
INFO - 2016-12-19 02:46:51 --> Language Class Initialized
INFO - 2016-12-19 02:46:51 --> Loader Class Initialized
INFO - 2016-12-19 02:46:51 --> Database Driver Class Initialized
INFO - 2016-12-19 02:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:46:51 --> Controller Class Initialized
INFO - 2016-12-19 02:46:51 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:46:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:46:51 --> Final output sent to browser
DEBUG - 2016-12-19 02:46:51 --> Total execution time: 0.0131
INFO - 2016-12-19 02:46:58 --> Config Class Initialized
INFO - 2016-12-19 02:46:58 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:46:58 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:46:58 --> Utf8 Class Initialized
INFO - 2016-12-19 02:46:58 --> URI Class Initialized
INFO - 2016-12-19 02:46:58 --> Router Class Initialized
INFO - 2016-12-19 02:46:58 --> Output Class Initialized
INFO - 2016-12-19 02:46:58 --> Security Class Initialized
DEBUG - 2016-12-19 02:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:46:58 --> Input Class Initialized
INFO - 2016-12-19 02:46:58 --> Language Class Initialized
ERROR - 2016-12-19 02:46:58 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:47:49 --> Config Class Initialized
INFO - 2016-12-19 02:47:49 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:47:49 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:47:49 --> Utf8 Class Initialized
INFO - 2016-12-19 02:47:49 --> URI Class Initialized
DEBUG - 2016-12-19 02:47:49 --> No URI present. Default controller set.
INFO - 2016-12-19 02:47:49 --> Router Class Initialized
INFO - 2016-12-19 02:47:49 --> Output Class Initialized
INFO - 2016-12-19 02:47:49 --> Security Class Initialized
DEBUG - 2016-12-19 02:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:47:49 --> Input Class Initialized
INFO - 2016-12-19 02:47:49 --> Language Class Initialized
INFO - 2016-12-19 02:47:49 --> Loader Class Initialized
INFO - 2016-12-19 02:47:50 --> Database Driver Class Initialized
INFO - 2016-12-19 02:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:47:50 --> Controller Class Initialized
INFO - 2016-12-19 02:47:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:47:50 --> Final output sent to browser
DEBUG - 2016-12-19 02:47:50 --> Total execution time: 0.8978
INFO - 2016-12-19 02:47:51 --> Config Class Initialized
INFO - 2016-12-19 02:47:51 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:47:51 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:47:51 --> Utf8 Class Initialized
INFO - 2016-12-19 02:47:51 --> URI Class Initialized
INFO - 2016-12-19 02:47:51 --> Router Class Initialized
INFO - 2016-12-19 02:47:51 --> Output Class Initialized
INFO - 2016-12-19 02:47:51 --> Security Class Initialized
DEBUG - 2016-12-19 02:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:47:51 --> Input Class Initialized
INFO - 2016-12-19 02:47:51 --> Language Class Initialized
INFO - 2016-12-19 02:47:51 --> Loader Class Initialized
INFO - 2016-12-19 02:47:51 --> Database Driver Class Initialized
INFO - 2016-12-19 02:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:47:51 --> Controller Class Initialized
INFO - 2016-12-19 02:47:51 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:47:51 --> Final output sent to browser
DEBUG - 2016-12-19 02:47:51 --> Total execution time: 0.0132
INFO - 2016-12-19 02:47:52 --> Config Class Initialized
INFO - 2016-12-19 02:47:52 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:47:52 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:47:52 --> Utf8 Class Initialized
INFO - 2016-12-19 02:47:52 --> URI Class Initialized
INFO - 2016-12-19 02:47:52 --> Router Class Initialized
INFO - 2016-12-19 02:47:52 --> Output Class Initialized
INFO - 2016-12-19 02:47:52 --> Security Class Initialized
DEBUG - 2016-12-19 02:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:47:52 --> Input Class Initialized
INFO - 2016-12-19 02:47:52 --> Language Class Initialized
ERROR - 2016-12-19 02:47:52 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:48:49 --> Config Class Initialized
INFO - 2016-12-19 02:48:49 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:48:49 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:48:49 --> Utf8 Class Initialized
INFO - 2016-12-19 02:48:49 --> URI Class Initialized
DEBUG - 2016-12-19 02:48:49 --> No URI present. Default controller set.
INFO - 2016-12-19 02:48:49 --> Router Class Initialized
INFO - 2016-12-19 02:48:49 --> Output Class Initialized
INFO - 2016-12-19 02:48:49 --> Security Class Initialized
DEBUG - 2016-12-19 02:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:48:49 --> Input Class Initialized
INFO - 2016-12-19 02:48:49 --> Language Class Initialized
INFO - 2016-12-19 02:48:49 --> Loader Class Initialized
INFO - 2016-12-19 02:48:49 --> Database Driver Class Initialized
INFO - 2016-12-19 02:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:48:49 --> Controller Class Initialized
INFO - 2016-12-19 02:48:49 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:48:50 --> Final output sent to browser
DEBUG - 2016-12-19 02:48:50 --> Total execution time: 1.0785
INFO - 2016-12-19 02:48:50 --> Config Class Initialized
INFO - 2016-12-19 02:48:50 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:48:50 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:48:50 --> Utf8 Class Initialized
INFO - 2016-12-19 02:48:50 --> URI Class Initialized
INFO - 2016-12-19 02:48:50 --> Router Class Initialized
INFO - 2016-12-19 02:48:50 --> Output Class Initialized
INFO - 2016-12-19 02:48:50 --> Security Class Initialized
DEBUG - 2016-12-19 02:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:48:50 --> Input Class Initialized
INFO - 2016-12-19 02:48:50 --> Language Class Initialized
INFO - 2016-12-19 02:48:50 --> Loader Class Initialized
INFO - 2016-12-19 02:48:50 --> Database Driver Class Initialized
INFO - 2016-12-19 02:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:48:50 --> Controller Class Initialized
INFO - 2016-12-19 02:48:50 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:48:50 --> Final output sent to browser
DEBUG - 2016-12-19 02:48:50 --> Total execution time: 0.0131
INFO - 2016-12-19 02:51:42 --> Config Class Initialized
INFO - 2016-12-19 02:51:42 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:51:42 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:51:42 --> Utf8 Class Initialized
INFO - 2016-12-19 02:51:42 --> URI Class Initialized
DEBUG - 2016-12-19 02:51:42 --> No URI present. Default controller set.
INFO - 2016-12-19 02:51:42 --> Router Class Initialized
INFO - 2016-12-19 02:51:42 --> Output Class Initialized
INFO - 2016-12-19 02:51:42 --> Security Class Initialized
DEBUG - 2016-12-19 02:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:51:42 --> Input Class Initialized
INFO - 2016-12-19 02:51:42 --> Language Class Initialized
INFO - 2016-12-19 02:51:42 --> Loader Class Initialized
INFO - 2016-12-19 02:51:42 --> Database Driver Class Initialized
INFO - 2016-12-19 02:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:51:42 --> Controller Class Initialized
INFO - 2016-12-19 02:51:42 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:51:42 --> Final output sent to browser
DEBUG - 2016-12-19 02:51:42 --> Total execution time: 0.6401
INFO - 2016-12-19 02:51:45 --> Config Class Initialized
INFO - 2016-12-19 02:51:45 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:51:45 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:51:45 --> Utf8 Class Initialized
INFO - 2016-12-19 02:51:45 --> URI Class Initialized
INFO - 2016-12-19 02:51:45 --> Router Class Initialized
INFO - 2016-12-19 02:51:45 --> Output Class Initialized
INFO - 2016-12-19 02:51:45 --> Security Class Initialized
DEBUG - 2016-12-19 02:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:51:45 --> Input Class Initialized
INFO - 2016-12-19 02:51:45 --> Language Class Initialized
ERROR - 2016-12-19 02:51:45 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:51:45 --> Config Class Initialized
INFO - 2016-12-19 02:51:45 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:51:45 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:51:45 --> Utf8 Class Initialized
INFO - 2016-12-19 02:51:45 --> URI Class Initialized
INFO - 2016-12-19 02:51:45 --> Router Class Initialized
INFO - 2016-12-19 02:51:45 --> Output Class Initialized
INFO - 2016-12-19 02:51:45 --> Security Class Initialized
DEBUG - 2016-12-19 02:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:51:45 --> Input Class Initialized
INFO - 2016-12-19 02:51:45 --> Language Class Initialized
INFO - 2016-12-19 02:51:45 --> Loader Class Initialized
INFO - 2016-12-19 02:51:45 --> Database Driver Class Initialized
INFO - 2016-12-19 02:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:51:45 --> Controller Class Initialized
INFO - 2016-12-19 02:51:45 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:51:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:51:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:51:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:51:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:51:45 --> Final output sent to browser
DEBUG - 2016-12-19 02:51:45 --> Total execution time: 0.0129
INFO - 2016-12-19 02:53:03 --> Config Class Initialized
INFO - 2016-12-19 02:53:03 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:53:03 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:53:03 --> Utf8 Class Initialized
INFO - 2016-12-19 02:53:03 --> URI Class Initialized
DEBUG - 2016-12-19 02:53:03 --> No URI present. Default controller set.
INFO - 2016-12-19 02:53:03 --> Router Class Initialized
INFO - 2016-12-19 02:53:03 --> Output Class Initialized
INFO - 2016-12-19 02:53:03 --> Security Class Initialized
DEBUG - 2016-12-19 02:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:53:03 --> Input Class Initialized
INFO - 2016-12-19 02:53:03 --> Language Class Initialized
INFO - 2016-12-19 02:53:03 --> Loader Class Initialized
INFO - 2016-12-19 02:53:03 --> Database Driver Class Initialized
INFO - 2016-12-19 02:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:53:03 --> Controller Class Initialized
INFO - 2016-12-19 02:53:03 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:53:03 --> Final output sent to browser
DEBUG - 2016-12-19 02:53:03 --> Total execution time: 0.6696
INFO - 2016-12-19 02:53:04 --> Config Class Initialized
INFO - 2016-12-19 02:53:04 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:53:04 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:53:04 --> Utf8 Class Initialized
INFO - 2016-12-19 02:53:04 --> URI Class Initialized
INFO - 2016-12-19 02:53:04 --> Router Class Initialized
INFO - 2016-12-19 02:53:04 --> Output Class Initialized
INFO - 2016-12-19 02:53:04 --> Security Class Initialized
DEBUG - 2016-12-19 02:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:53:04 --> Input Class Initialized
INFO - 2016-12-19 02:53:04 --> Language Class Initialized
ERROR - 2016-12-19 02:53:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:53:04 --> Config Class Initialized
INFO - 2016-12-19 02:53:04 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:53:04 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:53:04 --> Utf8 Class Initialized
INFO - 2016-12-19 02:53:04 --> URI Class Initialized
INFO - 2016-12-19 02:53:04 --> Router Class Initialized
INFO - 2016-12-19 02:53:04 --> Output Class Initialized
INFO - 2016-12-19 02:53:04 --> Security Class Initialized
DEBUG - 2016-12-19 02:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:53:04 --> Input Class Initialized
INFO - 2016-12-19 02:53:04 --> Language Class Initialized
INFO - 2016-12-19 02:53:04 --> Loader Class Initialized
INFO - 2016-12-19 02:53:04 --> Database Driver Class Initialized
INFO - 2016-12-19 02:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:53:04 --> Controller Class Initialized
INFO - 2016-12-19 02:53:04 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:53:04 --> Final output sent to browser
DEBUG - 2016-12-19 02:53:04 --> Total execution time: 0.0130
INFO - 2016-12-19 02:53:12 --> Config Class Initialized
INFO - 2016-12-19 02:53:12 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:53:12 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:53:12 --> Utf8 Class Initialized
INFO - 2016-12-19 02:53:12 --> URI Class Initialized
DEBUG - 2016-12-19 02:53:12 --> No URI present. Default controller set.
INFO - 2016-12-19 02:53:12 --> Router Class Initialized
INFO - 2016-12-19 02:53:12 --> Output Class Initialized
INFO - 2016-12-19 02:53:12 --> Security Class Initialized
DEBUG - 2016-12-19 02:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:53:12 --> Input Class Initialized
INFO - 2016-12-19 02:53:12 --> Language Class Initialized
INFO - 2016-12-19 02:53:12 --> Loader Class Initialized
INFO - 2016-12-19 02:53:12 --> Database Driver Class Initialized
INFO - 2016-12-19 02:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:53:12 --> Controller Class Initialized
INFO - 2016-12-19 02:53:12 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:53:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:53:12 --> Final output sent to browser
DEBUG - 2016-12-19 02:53:12 --> Total execution time: 0.6515
INFO - 2016-12-19 02:53:13 --> Config Class Initialized
INFO - 2016-12-19 02:53:13 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:53:13 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:53:13 --> Utf8 Class Initialized
INFO - 2016-12-19 02:53:13 --> URI Class Initialized
INFO - 2016-12-19 02:53:13 --> Router Class Initialized
INFO - 2016-12-19 02:53:13 --> Output Class Initialized
INFO - 2016-12-19 02:53:13 --> Security Class Initialized
DEBUG - 2016-12-19 02:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:53:13 --> Input Class Initialized
INFO - 2016-12-19 02:53:13 --> Language Class Initialized
ERROR - 2016-12-19 02:53:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:53:13 --> Config Class Initialized
INFO - 2016-12-19 02:53:13 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:53:13 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:53:13 --> Utf8 Class Initialized
INFO - 2016-12-19 02:53:13 --> URI Class Initialized
INFO - 2016-12-19 02:53:13 --> Router Class Initialized
INFO - 2016-12-19 02:53:13 --> Output Class Initialized
INFO - 2016-12-19 02:53:13 --> Security Class Initialized
DEBUG - 2016-12-19 02:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:53:13 --> Input Class Initialized
INFO - 2016-12-19 02:53:13 --> Language Class Initialized
INFO - 2016-12-19 02:53:13 --> Loader Class Initialized
INFO - 2016-12-19 02:53:13 --> Database Driver Class Initialized
INFO - 2016-12-19 02:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:53:13 --> Controller Class Initialized
INFO - 2016-12-19 02:53:13 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:53:13 --> Final output sent to browser
DEBUG - 2016-12-19 02:53:13 --> Total execution time: 0.0130
INFO - 2016-12-19 02:54:14 --> Config Class Initialized
INFO - 2016-12-19 02:54:14 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:54:14 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:54:14 --> Utf8 Class Initialized
INFO - 2016-12-19 02:54:14 --> URI Class Initialized
DEBUG - 2016-12-19 02:54:14 --> No URI present. Default controller set.
INFO - 2016-12-19 02:54:14 --> Router Class Initialized
INFO - 2016-12-19 02:54:14 --> Output Class Initialized
INFO - 2016-12-19 02:54:14 --> Security Class Initialized
DEBUG - 2016-12-19 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:54:14 --> Input Class Initialized
INFO - 2016-12-19 02:54:14 --> Language Class Initialized
INFO - 2016-12-19 02:54:14 --> Loader Class Initialized
INFO - 2016-12-19 02:54:14 --> Database Driver Class Initialized
INFO - 2016-12-19 02:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:54:14 --> Controller Class Initialized
INFO - 2016-12-19 02:54:14 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:54:14 --> Final output sent to browser
DEBUG - 2016-12-19 02:54:14 --> Total execution time: 0.0128
INFO - 2016-12-19 02:54:14 --> Config Class Initialized
INFO - 2016-12-19 02:54:14 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:54:14 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:54:14 --> Utf8 Class Initialized
INFO - 2016-12-19 02:54:14 --> URI Class Initialized
INFO - 2016-12-19 02:54:14 --> Router Class Initialized
INFO - 2016-12-19 02:54:14 --> Output Class Initialized
INFO - 2016-12-19 02:54:14 --> Security Class Initialized
DEBUG - 2016-12-19 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:54:14 --> Input Class Initialized
INFO - 2016-12-19 02:54:14 --> Language Class Initialized
ERROR - 2016-12-19 02:54:14 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:54:14 --> Config Class Initialized
INFO - 2016-12-19 02:54:14 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:54:14 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:54:14 --> Utf8 Class Initialized
INFO - 2016-12-19 02:54:14 --> URI Class Initialized
INFO - 2016-12-19 02:54:14 --> Router Class Initialized
INFO - 2016-12-19 02:54:14 --> Output Class Initialized
INFO - 2016-12-19 02:54:14 --> Security Class Initialized
DEBUG - 2016-12-19 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:54:14 --> Input Class Initialized
INFO - 2016-12-19 02:54:14 --> Language Class Initialized
INFO - 2016-12-19 02:54:14 --> Loader Class Initialized
INFO - 2016-12-19 02:54:14 --> Database Driver Class Initialized
INFO - 2016-12-19 02:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:54:14 --> Controller Class Initialized
INFO - 2016-12-19 02:54:14 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:54:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:54:14 --> Final output sent to browser
DEBUG - 2016-12-19 02:54:14 --> Total execution time: 0.0137
INFO - 2016-12-19 02:55:36 --> Config Class Initialized
INFO - 2016-12-19 02:55:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:55:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:55:36 --> Utf8 Class Initialized
INFO - 2016-12-19 02:55:36 --> URI Class Initialized
DEBUG - 2016-12-19 02:55:36 --> No URI present. Default controller set.
INFO - 2016-12-19 02:55:36 --> Router Class Initialized
INFO - 2016-12-19 02:55:36 --> Output Class Initialized
INFO - 2016-12-19 02:55:36 --> Security Class Initialized
DEBUG - 2016-12-19 02:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:55:36 --> Input Class Initialized
INFO - 2016-12-19 02:55:36 --> Language Class Initialized
INFO - 2016-12-19 02:55:36 --> Loader Class Initialized
INFO - 2016-12-19 02:55:36 --> Database Driver Class Initialized
INFO - 2016-12-19 02:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:55:36 --> Controller Class Initialized
INFO - 2016-12-19 02:55:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:55:36 --> Final output sent to browser
DEBUG - 2016-12-19 02:55:36 --> Total execution time: 0.0128
INFO - 2016-12-19 02:55:36 --> Config Class Initialized
INFO - 2016-12-19 02:55:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:55:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:55:36 --> Utf8 Class Initialized
INFO - 2016-12-19 02:55:36 --> URI Class Initialized
INFO - 2016-12-19 02:55:36 --> Router Class Initialized
INFO - 2016-12-19 02:55:36 --> Output Class Initialized
INFO - 2016-12-19 02:55:36 --> Security Class Initialized
DEBUG - 2016-12-19 02:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:55:36 --> Input Class Initialized
INFO - 2016-12-19 02:55:36 --> Language Class Initialized
ERROR - 2016-12-19 02:55:36 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:55:36 --> Config Class Initialized
INFO - 2016-12-19 02:55:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:55:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:55:36 --> Utf8 Class Initialized
INFO - 2016-12-19 02:55:36 --> URI Class Initialized
INFO - 2016-12-19 02:55:36 --> Router Class Initialized
INFO - 2016-12-19 02:55:36 --> Output Class Initialized
INFO - 2016-12-19 02:55:36 --> Security Class Initialized
DEBUG - 2016-12-19 02:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:55:36 --> Input Class Initialized
INFO - 2016-12-19 02:55:36 --> Language Class Initialized
INFO - 2016-12-19 02:55:36 --> Loader Class Initialized
INFO - 2016-12-19 02:55:36 --> Database Driver Class Initialized
INFO - 2016-12-19 02:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:55:36 --> Controller Class Initialized
INFO - 2016-12-19 02:55:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:55:36 --> Final output sent to browser
DEBUG - 2016-12-19 02:55:36 --> Total execution time: 0.0215
INFO - 2016-12-19 02:58:19 --> Config Class Initialized
INFO - 2016-12-19 02:58:19 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:19 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:19 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:19 --> URI Class Initialized
DEBUG - 2016-12-19 02:58:19 --> No URI present. Default controller set.
INFO - 2016-12-19 02:58:19 --> Router Class Initialized
INFO - 2016-12-19 02:58:19 --> Output Class Initialized
INFO - 2016-12-19 02:58:19 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:19 --> Input Class Initialized
INFO - 2016-12-19 02:58:19 --> Language Class Initialized
INFO - 2016-12-19 02:58:19 --> Loader Class Initialized
INFO - 2016-12-19 02:58:20 --> Database Driver Class Initialized
INFO - 2016-12-19 02:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:58:20 --> Controller Class Initialized
INFO - 2016-12-19 02:58:20 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:58:20 --> Final output sent to browser
DEBUG - 2016-12-19 02:58:20 --> Total execution time: 0.7481
INFO - 2016-12-19 02:58:20 --> Config Class Initialized
INFO - 2016-12-19 02:58:20 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:20 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:20 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:20 --> URI Class Initialized
INFO - 2016-12-19 02:58:20 --> Router Class Initialized
INFO - 2016-12-19 02:58:20 --> Output Class Initialized
INFO - 2016-12-19 02:58:20 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:20 --> Input Class Initialized
INFO - 2016-12-19 02:58:20 --> Language Class Initialized
ERROR - 2016-12-19 02:58:20 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:58:21 --> Config Class Initialized
INFO - 2016-12-19 02:58:21 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:21 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:21 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:21 --> URI Class Initialized
INFO - 2016-12-19 02:58:21 --> Router Class Initialized
INFO - 2016-12-19 02:58:21 --> Output Class Initialized
INFO - 2016-12-19 02:58:21 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:21 --> Input Class Initialized
INFO - 2016-12-19 02:58:21 --> Language Class Initialized
INFO - 2016-12-19 02:58:21 --> Loader Class Initialized
INFO - 2016-12-19 02:58:21 --> Database Driver Class Initialized
INFO - 2016-12-19 02:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:58:21 --> Controller Class Initialized
INFO - 2016-12-19 02:58:21 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:58:21 --> Final output sent to browser
DEBUG - 2016-12-19 02:58:21 --> Total execution time: 0.0131
INFO - 2016-12-19 02:58:48 --> Config Class Initialized
INFO - 2016-12-19 02:58:48 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:48 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:48 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:48 --> URI Class Initialized
DEBUG - 2016-12-19 02:58:48 --> No URI present. Default controller set.
INFO - 2016-12-19 02:58:48 --> Router Class Initialized
INFO - 2016-12-19 02:58:48 --> Output Class Initialized
INFO - 2016-12-19 02:58:48 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:48 --> Input Class Initialized
INFO - 2016-12-19 02:58:48 --> Language Class Initialized
INFO - 2016-12-19 02:58:48 --> Loader Class Initialized
INFO - 2016-12-19 02:58:48 --> Database Driver Class Initialized
INFO - 2016-12-19 02:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:58:48 --> Controller Class Initialized
INFO - 2016-12-19 02:58:48 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:58:48 --> Final output sent to browser
DEBUG - 2016-12-19 02:58:48 --> Total execution time: 0.0129
INFO - 2016-12-19 02:58:48 --> Config Class Initialized
INFO - 2016-12-19 02:58:48 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:48 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:48 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:48 --> URI Class Initialized
INFO - 2016-12-19 02:58:48 --> Router Class Initialized
INFO - 2016-12-19 02:58:48 --> Output Class Initialized
INFO - 2016-12-19 02:58:48 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:48 --> Input Class Initialized
INFO - 2016-12-19 02:58:48 --> Language Class Initialized
ERROR - 2016-12-19 02:58:48 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:58:48 --> Config Class Initialized
INFO - 2016-12-19 02:58:48 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:48 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:48 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:48 --> URI Class Initialized
INFO - 2016-12-19 02:58:48 --> Router Class Initialized
INFO - 2016-12-19 02:58:48 --> Output Class Initialized
INFO - 2016-12-19 02:58:48 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:48 --> Input Class Initialized
INFO - 2016-12-19 02:58:48 --> Language Class Initialized
INFO - 2016-12-19 02:58:48 --> Loader Class Initialized
INFO - 2016-12-19 02:58:48 --> Database Driver Class Initialized
INFO - 2016-12-19 02:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:58:48 --> Controller Class Initialized
INFO - 2016-12-19 02:58:48 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:58:48 --> Final output sent to browser
DEBUG - 2016-12-19 02:58:48 --> Total execution time: 0.0130
INFO - 2016-12-19 02:58:56 --> Config Class Initialized
INFO - 2016-12-19 02:58:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:56 --> URI Class Initialized
DEBUG - 2016-12-19 02:58:56 --> No URI present. Default controller set.
INFO - 2016-12-19 02:58:56 --> Router Class Initialized
INFO - 2016-12-19 02:58:56 --> Output Class Initialized
INFO - 2016-12-19 02:58:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:56 --> Input Class Initialized
INFO - 2016-12-19 02:58:56 --> Language Class Initialized
INFO - 2016-12-19 02:58:56 --> Loader Class Initialized
INFO - 2016-12-19 02:58:56 --> Database Driver Class Initialized
INFO - 2016-12-19 02:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:58:56 --> Controller Class Initialized
INFO - 2016-12-19 02:58:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:58:56 --> Final output sent to browser
DEBUG - 2016-12-19 02:58:56 --> Total execution time: 0.0134
INFO - 2016-12-19 02:58:56 --> Config Class Initialized
INFO - 2016-12-19 02:58:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:56 --> URI Class Initialized
INFO - 2016-12-19 02:58:56 --> Router Class Initialized
INFO - 2016-12-19 02:58:56 --> Output Class Initialized
INFO - 2016-12-19 02:58:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:56 --> Input Class Initialized
INFO - 2016-12-19 02:58:56 --> Language Class Initialized
ERROR - 2016-12-19 02:58:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:58:56 --> Config Class Initialized
INFO - 2016-12-19 02:58:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:58:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:58:56 --> Utf8 Class Initialized
INFO - 2016-12-19 02:58:56 --> URI Class Initialized
INFO - 2016-12-19 02:58:56 --> Router Class Initialized
INFO - 2016-12-19 02:58:56 --> Output Class Initialized
INFO - 2016-12-19 02:58:56 --> Security Class Initialized
DEBUG - 2016-12-19 02:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:58:56 --> Input Class Initialized
INFO - 2016-12-19 02:58:56 --> Language Class Initialized
INFO - 2016-12-19 02:58:56 --> Loader Class Initialized
INFO - 2016-12-19 02:58:56 --> Database Driver Class Initialized
INFO - 2016-12-19 02:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:58:56 --> Controller Class Initialized
INFO - 2016-12-19 02:58:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:58:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:58:56 --> Final output sent to browser
DEBUG - 2016-12-19 02:58:56 --> Total execution time: 0.0131
INFO - 2016-12-19 02:59:01 --> Config Class Initialized
INFO - 2016-12-19 02:59:01 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:59:01 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:59:01 --> Utf8 Class Initialized
INFO - 2016-12-19 02:59:01 --> URI Class Initialized
DEBUG - 2016-12-19 02:59:01 --> No URI present. Default controller set.
INFO - 2016-12-19 02:59:01 --> Router Class Initialized
INFO - 2016-12-19 02:59:01 --> Output Class Initialized
INFO - 2016-12-19 02:59:01 --> Security Class Initialized
DEBUG - 2016-12-19 02:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:59:01 --> Input Class Initialized
INFO - 2016-12-19 02:59:01 --> Language Class Initialized
INFO - 2016-12-19 02:59:01 --> Loader Class Initialized
INFO - 2016-12-19 02:59:01 --> Database Driver Class Initialized
INFO - 2016-12-19 02:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:59:01 --> Controller Class Initialized
INFO - 2016-12-19 02:59:01 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:59:01 --> Final output sent to browser
DEBUG - 2016-12-19 02:59:01 --> Total execution time: 0.0135
INFO - 2016-12-19 02:59:01 --> Config Class Initialized
INFO - 2016-12-19 02:59:01 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:59:01 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:59:01 --> Utf8 Class Initialized
INFO - 2016-12-19 02:59:01 --> URI Class Initialized
INFO - 2016-12-19 02:59:01 --> Router Class Initialized
INFO - 2016-12-19 02:59:01 --> Output Class Initialized
INFO - 2016-12-19 02:59:01 --> Security Class Initialized
DEBUG - 2016-12-19 02:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:59:01 --> Input Class Initialized
INFO - 2016-12-19 02:59:01 --> Language Class Initialized
ERROR - 2016-12-19 02:59:01 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 02:59:02 --> Config Class Initialized
INFO - 2016-12-19 02:59:02 --> Hooks Class Initialized
DEBUG - 2016-12-19 02:59:02 --> UTF-8 Support Enabled
INFO - 2016-12-19 02:59:02 --> Utf8 Class Initialized
INFO - 2016-12-19 02:59:02 --> URI Class Initialized
INFO - 2016-12-19 02:59:02 --> Router Class Initialized
INFO - 2016-12-19 02:59:02 --> Output Class Initialized
INFO - 2016-12-19 02:59:02 --> Security Class Initialized
DEBUG - 2016-12-19 02:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 02:59:02 --> Input Class Initialized
INFO - 2016-12-19 02:59:02 --> Language Class Initialized
INFO - 2016-12-19 02:59:02 --> Loader Class Initialized
INFO - 2016-12-19 02:59:02 --> Database Driver Class Initialized
INFO - 2016-12-19 02:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 02:59:02 --> Controller Class Initialized
INFO - 2016-12-19 02:59:02 --> Helper loaded: url_helper
DEBUG - 2016-12-19 02:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 02:59:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 02:59:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 02:59:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 02:59:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 02:59:02 --> Final output sent to browser
DEBUG - 2016-12-19 02:59:02 --> Total execution time: 0.0135
INFO - 2016-12-19 03:01:35 --> Config Class Initialized
INFO - 2016-12-19 03:01:35 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:01:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:01:36 --> Utf8 Class Initialized
INFO - 2016-12-19 03:01:36 --> URI Class Initialized
DEBUG - 2016-12-19 03:01:36 --> No URI present. Default controller set.
INFO - 2016-12-19 03:01:36 --> Router Class Initialized
INFO - 2016-12-19 03:01:36 --> Output Class Initialized
INFO - 2016-12-19 03:01:36 --> Security Class Initialized
DEBUG - 2016-12-19 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:01:36 --> Input Class Initialized
INFO - 2016-12-19 03:01:36 --> Language Class Initialized
INFO - 2016-12-19 03:01:36 --> Loader Class Initialized
INFO - 2016-12-19 03:01:36 --> Database Driver Class Initialized
INFO - 2016-12-19 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:01:36 --> Controller Class Initialized
INFO - 2016-12-19 03:01:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:01:36 --> Final output sent to browser
DEBUG - 2016-12-19 03:01:36 --> Total execution time: 0.2388
INFO - 2016-12-19 03:01:36 --> Config Class Initialized
INFO - 2016-12-19 03:01:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:01:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:01:36 --> Utf8 Class Initialized
INFO - 2016-12-19 03:01:36 --> URI Class Initialized
INFO - 2016-12-19 03:01:36 --> Router Class Initialized
INFO - 2016-12-19 03:01:36 --> Output Class Initialized
INFO - 2016-12-19 03:01:36 --> Security Class Initialized
DEBUG - 2016-12-19 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:01:36 --> Input Class Initialized
INFO - 2016-12-19 03:01:36 --> Language Class Initialized
ERROR - 2016-12-19 03:01:36 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 03:01:36 --> Config Class Initialized
INFO - 2016-12-19 03:01:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:01:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:01:36 --> Utf8 Class Initialized
INFO - 2016-12-19 03:01:36 --> URI Class Initialized
INFO - 2016-12-19 03:01:36 --> Router Class Initialized
INFO - 2016-12-19 03:01:36 --> Output Class Initialized
INFO - 2016-12-19 03:01:36 --> Security Class Initialized
DEBUG - 2016-12-19 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:01:36 --> Input Class Initialized
INFO - 2016-12-19 03:01:36 --> Language Class Initialized
INFO - 2016-12-19 03:01:36 --> Loader Class Initialized
INFO - 2016-12-19 03:01:36 --> Database Driver Class Initialized
INFO - 2016-12-19 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:01:36 --> Controller Class Initialized
INFO - 2016-12-19 03:01:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:01:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:01:36 --> Final output sent to browser
DEBUG - 2016-12-19 03:01:36 --> Total execution time: 0.0130
INFO - 2016-12-19 03:03:42 --> Config Class Initialized
INFO - 2016-12-19 03:03:42 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:03:42 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:03:42 --> Utf8 Class Initialized
INFO - 2016-12-19 03:03:42 --> URI Class Initialized
DEBUG - 2016-12-19 03:03:42 --> No URI present. Default controller set.
INFO - 2016-12-19 03:03:42 --> Router Class Initialized
INFO - 2016-12-19 03:03:42 --> Output Class Initialized
INFO - 2016-12-19 03:03:42 --> Security Class Initialized
DEBUG - 2016-12-19 03:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:03:42 --> Input Class Initialized
INFO - 2016-12-19 03:03:42 --> Language Class Initialized
INFO - 2016-12-19 03:03:42 --> Loader Class Initialized
INFO - 2016-12-19 03:03:42 --> Database Driver Class Initialized
INFO - 2016-12-19 03:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:03:42 --> Controller Class Initialized
INFO - 2016-12-19 03:03:42 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:03:43 --> Final output sent to browser
DEBUG - 2016-12-19 03:03:43 --> Total execution time: 0.2926
INFO - 2016-12-19 03:03:43 --> Config Class Initialized
INFO - 2016-12-19 03:03:43 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:03:43 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:03:43 --> Utf8 Class Initialized
INFO - 2016-12-19 03:03:43 --> URI Class Initialized
INFO - 2016-12-19 03:03:43 --> Router Class Initialized
INFO - 2016-12-19 03:03:43 --> Output Class Initialized
INFO - 2016-12-19 03:03:43 --> Security Class Initialized
DEBUG - 2016-12-19 03:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:03:43 --> Input Class Initialized
INFO - 2016-12-19 03:03:43 --> Language Class Initialized
INFO - 2016-12-19 03:03:43 --> Loader Class Initialized
INFO - 2016-12-19 03:03:43 --> Database Driver Class Initialized
INFO - 2016-12-19 03:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:03:43 --> Controller Class Initialized
INFO - 2016-12-19 03:03:43 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:03:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:03:43 --> Final output sent to browser
DEBUG - 2016-12-19 03:03:43 --> Total execution time: 0.0138
INFO - 2016-12-19 03:03:54 --> Config Class Initialized
INFO - 2016-12-19 03:03:54 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:03:54 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:03:54 --> Utf8 Class Initialized
INFO - 2016-12-19 03:03:54 --> URI Class Initialized
INFO - 2016-12-19 03:03:54 --> Router Class Initialized
INFO - 2016-12-19 03:03:54 --> Output Class Initialized
INFO - 2016-12-19 03:03:54 --> Security Class Initialized
DEBUG - 2016-12-19 03:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:03:54 --> Input Class Initialized
INFO - 2016-12-19 03:03:54 --> Language Class Initialized
ERROR - 2016-12-19 03:03:54 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-19 03:04:52 --> Config Class Initialized
INFO - 2016-12-19 03:04:52 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:04:52 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:04:52 --> Utf8 Class Initialized
INFO - 2016-12-19 03:04:52 --> URI Class Initialized
DEBUG - 2016-12-19 03:04:52 --> No URI present. Default controller set.
INFO - 2016-12-19 03:04:52 --> Router Class Initialized
INFO - 2016-12-19 03:04:52 --> Output Class Initialized
INFO - 2016-12-19 03:04:52 --> Security Class Initialized
DEBUG - 2016-12-19 03:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:04:52 --> Input Class Initialized
INFO - 2016-12-19 03:04:52 --> Language Class Initialized
INFO - 2016-12-19 03:04:52 --> Loader Class Initialized
INFO - 2016-12-19 03:04:52 --> Database Driver Class Initialized
INFO - 2016-12-19 03:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:04:52 --> Controller Class Initialized
INFO - 2016-12-19 03:04:52 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:04:52 --> Final output sent to browser
DEBUG - 2016-12-19 03:04:52 --> Total execution time: 0.0133
INFO - 2016-12-19 03:04:53 --> Config Class Initialized
INFO - 2016-12-19 03:04:53 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:04:53 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:04:53 --> Utf8 Class Initialized
INFO - 2016-12-19 03:04:53 --> URI Class Initialized
INFO - 2016-12-19 03:04:53 --> Router Class Initialized
INFO - 2016-12-19 03:04:53 --> Output Class Initialized
INFO - 2016-12-19 03:04:53 --> Security Class Initialized
DEBUG - 2016-12-19 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:04:53 --> Input Class Initialized
INFO - 2016-12-19 03:04:53 --> Language Class Initialized
INFO - 2016-12-19 03:04:53 --> Loader Class Initialized
INFO - 2016-12-19 03:04:53 --> Database Driver Class Initialized
INFO - 2016-12-19 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:04:53 --> Controller Class Initialized
INFO - 2016-12-19 03:04:53 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:04:53 --> Final output sent to browser
DEBUG - 2016-12-19 03:04:53 --> Total execution time: 0.0132
INFO - 2016-12-19 03:05:32 --> Config Class Initialized
INFO - 2016-12-19 03:05:32 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:05:32 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:05:32 --> Utf8 Class Initialized
INFO - 2016-12-19 03:05:32 --> URI Class Initialized
DEBUG - 2016-12-19 03:05:32 --> No URI present. Default controller set.
INFO - 2016-12-19 03:05:32 --> Router Class Initialized
INFO - 2016-12-19 03:05:32 --> Output Class Initialized
INFO - 2016-12-19 03:05:32 --> Security Class Initialized
DEBUG - 2016-12-19 03:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:05:32 --> Input Class Initialized
INFO - 2016-12-19 03:05:32 --> Language Class Initialized
INFO - 2016-12-19 03:05:32 --> Loader Class Initialized
INFO - 2016-12-19 03:05:32 --> Database Driver Class Initialized
INFO - 2016-12-19 03:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:05:32 --> Controller Class Initialized
INFO - 2016-12-19 03:05:32 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:05:32 --> Final output sent to browser
DEBUG - 2016-12-19 03:05:32 --> Total execution time: 0.0129
INFO - 2016-12-19 03:05:32 --> Config Class Initialized
INFO - 2016-12-19 03:05:32 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:05:32 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:05:32 --> Utf8 Class Initialized
INFO - 2016-12-19 03:05:32 --> URI Class Initialized
INFO - 2016-12-19 03:05:32 --> Router Class Initialized
INFO - 2016-12-19 03:05:32 --> Output Class Initialized
INFO - 2016-12-19 03:05:32 --> Security Class Initialized
DEBUG - 2016-12-19 03:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:05:32 --> Input Class Initialized
INFO - 2016-12-19 03:05:32 --> Language Class Initialized
INFO - 2016-12-19 03:05:32 --> Loader Class Initialized
INFO - 2016-12-19 03:05:32 --> Database Driver Class Initialized
INFO - 2016-12-19 03:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:05:32 --> Controller Class Initialized
INFO - 2016-12-19 03:05:32 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:05:32 --> Final output sent to browser
DEBUG - 2016-12-19 03:05:32 --> Total execution time: 0.0144
INFO - 2016-12-19 03:06:10 --> Config Class Initialized
INFO - 2016-12-19 03:06:10 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:06:10 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:06:10 --> Utf8 Class Initialized
INFO - 2016-12-19 03:06:10 --> URI Class Initialized
DEBUG - 2016-12-19 03:06:10 --> No URI present. Default controller set.
INFO - 2016-12-19 03:06:10 --> Router Class Initialized
INFO - 2016-12-19 03:06:10 --> Output Class Initialized
INFO - 2016-12-19 03:06:10 --> Security Class Initialized
DEBUG - 2016-12-19 03:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:06:10 --> Input Class Initialized
INFO - 2016-12-19 03:06:10 --> Language Class Initialized
INFO - 2016-12-19 03:06:10 --> Loader Class Initialized
INFO - 2016-12-19 03:06:10 --> Database Driver Class Initialized
INFO - 2016-12-19 03:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:06:10 --> Controller Class Initialized
INFO - 2016-12-19 03:06:10 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:06:10 --> Final output sent to browser
DEBUG - 2016-12-19 03:06:10 --> Total execution time: 0.0132
INFO - 2016-12-19 03:06:10 --> Config Class Initialized
INFO - 2016-12-19 03:06:10 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:06:10 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:06:10 --> Utf8 Class Initialized
INFO - 2016-12-19 03:06:10 --> URI Class Initialized
INFO - 2016-12-19 03:06:10 --> Router Class Initialized
INFO - 2016-12-19 03:06:10 --> Output Class Initialized
INFO - 2016-12-19 03:06:10 --> Security Class Initialized
DEBUG - 2016-12-19 03:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:06:10 --> Input Class Initialized
INFO - 2016-12-19 03:06:10 --> Language Class Initialized
INFO - 2016-12-19 03:06:10 --> Loader Class Initialized
INFO - 2016-12-19 03:06:10 --> Database Driver Class Initialized
INFO - 2016-12-19 03:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:06:10 --> Controller Class Initialized
INFO - 2016-12-19 03:06:10 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:06:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:06:10 --> Final output sent to browser
DEBUG - 2016-12-19 03:06:10 --> Total execution time: 0.0134
INFO - 2016-12-19 03:06:15 --> Config Class Initialized
INFO - 2016-12-19 03:06:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:06:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:06:15 --> Utf8 Class Initialized
INFO - 2016-12-19 03:06:15 --> URI Class Initialized
DEBUG - 2016-12-19 03:06:15 --> No URI present. Default controller set.
INFO - 2016-12-19 03:06:15 --> Router Class Initialized
INFO - 2016-12-19 03:06:15 --> Output Class Initialized
INFO - 2016-12-19 03:06:15 --> Security Class Initialized
DEBUG - 2016-12-19 03:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:06:15 --> Input Class Initialized
INFO - 2016-12-19 03:06:15 --> Language Class Initialized
INFO - 2016-12-19 03:06:15 --> Loader Class Initialized
INFO - 2016-12-19 03:06:15 --> Database Driver Class Initialized
INFO - 2016-12-19 03:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:06:15 --> Controller Class Initialized
INFO - 2016-12-19 03:06:15 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:06:15 --> Final output sent to browser
DEBUG - 2016-12-19 03:06:15 --> Total execution time: 0.0146
INFO - 2016-12-19 03:06:15 --> Config Class Initialized
INFO - 2016-12-19 03:06:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:06:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:06:15 --> Utf8 Class Initialized
INFO - 2016-12-19 03:06:15 --> URI Class Initialized
INFO - 2016-12-19 03:06:15 --> Router Class Initialized
INFO - 2016-12-19 03:06:15 --> Output Class Initialized
INFO - 2016-12-19 03:06:15 --> Security Class Initialized
DEBUG - 2016-12-19 03:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:06:15 --> Input Class Initialized
INFO - 2016-12-19 03:06:15 --> Language Class Initialized
INFO - 2016-12-19 03:06:15 --> Loader Class Initialized
INFO - 2016-12-19 03:06:15 --> Database Driver Class Initialized
INFO - 2016-12-19 03:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:06:15 --> Controller Class Initialized
INFO - 2016-12-19 03:06:15 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:06:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:06:15 --> Final output sent to browser
DEBUG - 2016-12-19 03:06:15 --> Total execution time: 0.0131
INFO - 2016-12-19 03:07:06 --> Config Class Initialized
INFO - 2016-12-19 03:07:06 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:06 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:06 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:06 --> URI Class Initialized
INFO - 2016-12-19 03:07:06 --> Router Class Initialized
INFO - 2016-12-19 03:07:06 --> Output Class Initialized
INFO - 2016-12-19 03:07:06 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:06 --> Input Class Initialized
INFO - 2016-12-19 03:07:06 --> Language Class Initialized
INFO - 2016-12-19 03:07:06 --> Loader Class Initialized
INFO - 2016-12-19 03:07:06 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:06 --> Controller Class Initialized
INFO - 2016-12-19 03:07:06 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:08 --> Config Class Initialized
INFO - 2016-12-19 03:07:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:08 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:08 --> URI Class Initialized
INFO - 2016-12-19 03:07:08 --> Router Class Initialized
INFO - 2016-12-19 03:07:08 --> Output Class Initialized
INFO - 2016-12-19 03:07:08 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:08 --> Input Class Initialized
INFO - 2016-12-19 03:07:08 --> Language Class Initialized
INFO - 2016-12-19 03:07:08 --> Loader Class Initialized
INFO - 2016-12-19 03:07:08 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:08 --> Controller Class Initialized
INFO - 2016-12-19 03:07:08 --> Helper loaded: date_helper
DEBUG - 2016-12-19 03:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:08 --> Helper loaded: url_helper
INFO - 2016-12-19 03:07:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 03:07:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-19 03:07:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-19 03:07:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:08 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:08 --> Total execution time: 0.0369
INFO - 2016-12-19 03:07:09 --> Config Class Initialized
INFO - 2016-12-19 03:07:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:09 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:09 --> URI Class Initialized
INFO - 2016-12-19 03:07:09 --> Router Class Initialized
INFO - 2016-12-19 03:07:09 --> Output Class Initialized
INFO - 2016-12-19 03:07:09 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:09 --> Input Class Initialized
INFO - 2016-12-19 03:07:09 --> Language Class Initialized
INFO - 2016-12-19 03:07:09 --> Loader Class Initialized
INFO - 2016-12-19 03:07:09 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:09 --> Controller Class Initialized
INFO - 2016-12-19 03:07:09 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:09 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:09 --> Total execution time: 0.0131
INFO - 2016-12-19 03:07:14 --> Config Class Initialized
INFO - 2016-12-19 03:07:14 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:14 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:14 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:14 --> URI Class Initialized
INFO - 2016-12-19 03:07:14 --> Router Class Initialized
INFO - 2016-12-19 03:07:14 --> Output Class Initialized
INFO - 2016-12-19 03:07:14 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:14 --> Input Class Initialized
INFO - 2016-12-19 03:07:14 --> Language Class Initialized
INFO - 2016-12-19 03:07:14 --> Loader Class Initialized
INFO - 2016-12-19 03:07:14 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:14 --> Controller Class Initialized
INFO - 2016-12-19 03:07:14 --> Helper loaded: date_helper
DEBUG - 2016-12-19 03:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:14 --> Helper loaded: url_helper
INFO - 2016-12-19 03:07:14 --> Helper loaded: download_helper
INFO - 2016-12-19 03:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 03:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-19 03:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-19 03:07:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:14 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:14 --> Total execution time: 0.1056
INFO - 2016-12-19 03:07:15 --> Config Class Initialized
INFO - 2016-12-19 03:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:15 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:15 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:15 --> URI Class Initialized
INFO - 2016-12-19 03:07:15 --> Router Class Initialized
INFO - 2016-12-19 03:07:15 --> Output Class Initialized
INFO - 2016-12-19 03:07:15 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:15 --> Input Class Initialized
INFO - 2016-12-19 03:07:15 --> Language Class Initialized
INFO - 2016-12-19 03:07:15 --> Loader Class Initialized
INFO - 2016-12-19 03:07:15 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:15 --> Controller Class Initialized
INFO - 2016-12-19 03:07:15 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:07:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:07:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:15 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:15 --> Total execution time: 0.0132
INFO - 2016-12-19 03:07:26 --> Config Class Initialized
INFO - 2016-12-19 03:07:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:26 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:26 --> URI Class Initialized
INFO - 2016-12-19 03:07:26 --> Router Class Initialized
INFO - 2016-12-19 03:07:26 --> Output Class Initialized
INFO - 2016-12-19 03:07:26 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:26 --> Input Class Initialized
INFO - 2016-12-19 03:07:26 --> Language Class Initialized
INFO - 2016-12-19 03:07:26 --> Loader Class Initialized
INFO - 2016-12-19 03:07:26 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:26 --> Controller Class Initialized
INFO - 2016-12-19 03:07:26 --> Helper loaded: date_helper
DEBUG - 2016-12-19 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:26 --> Helper loaded: url_helper
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:26 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:26 --> Total execution time: 0.0548
INFO - 2016-12-19 03:07:26 --> Config Class Initialized
INFO - 2016-12-19 03:07:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:26 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:26 --> URI Class Initialized
INFO - 2016-12-19 03:07:26 --> Router Class Initialized
INFO - 2016-12-19 03:07:26 --> Output Class Initialized
INFO - 2016-12-19 03:07:26 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:26 --> Input Class Initialized
INFO - 2016-12-19 03:07:26 --> Language Class Initialized
INFO - 2016-12-19 03:07:26 --> Loader Class Initialized
INFO - 2016-12-19 03:07:26 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:26 --> Controller Class Initialized
INFO - 2016-12-19 03:07:26 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:26 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:26 --> Total execution time: 0.0132
INFO - 2016-12-19 03:07:29 --> Config Class Initialized
INFO - 2016-12-19 03:07:29 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:29 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:29 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:29 --> URI Class Initialized
INFO - 2016-12-19 03:07:29 --> Router Class Initialized
INFO - 2016-12-19 03:07:29 --> Output Class Initialized
INFO - 2016-12-19 03:07:29 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:29 --> Input Class Initialized
INFO - 2016-12-19 03:07:29 --> Language Class Initialized
INFO - 2016-12-19 03:07:29 --> Loader Class Initialized
INFO - 2016-12-19 03:07:29 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:29 --> Controller Class Initialized
INFO - 2016-12-19 03:07:29 --> Upload Class Initialized
INFO - 2016-12-19 03:07:29 --> Helper loaded: date_helper
DEBUG - 2016-12-19 03:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:29 --> Helper loaded: url_helper
INFO - 2016-12-19 03:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 03:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-19 03:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-19 03:07:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-19 03:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:29 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:29 --> Total execution time: 0.0484
INFO - 2016-12-19 03:07:30 --> Config Class Initialized
INFO - 2016-12-19 03:07:30 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:07:30 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:07:30 --> Utf8 Class Initialized
INFO - 2016-12-19 03:07:30 --> URI Class Initialized
INFO - 2016-12-19 03:07:30 --> Router Class Initialized
INFO - 2016-12-19 03:07:30 --> Output Class Initialized
INFO - 2016-12-19 03:07:30 --> Security Class Initialized
DEBUG - 2016-12-19 03:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:07:30 --> Input Class Initialized
INFO - 2016-12-19 03:07:30 --> Language Class Initialized
INFO - 2016-12-19 03:07:30 --> Loader Class Initialized
INFO - 2016-12-19 03:07:30 --> Database Driver Class Initialized
INFO - 2016-12-19 03:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:07:30 --> Controller Class Initialized
INFO - 2016-12-19 03:07:30 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:07:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:07:30 --> Final output sent to browser
DEBUG - 2016-12-19 03:07:30 --> Total execution time: 0.0133
INFO - 2016-12-19 03:08:11 --> Config Class Initialized
INFO - 2016-12-19 03:08:11 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:08:11 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:08:11 --> Utf8 Class Initialized
INFO - 2016-12-19 03:08:11 --> URI Class Initialized
INFO - 2016-12-19 03:08:11 --> Router Class Initialized
INFO - 2016-12-19 03:08:11 --> Output Class Initialized
INFO - 2016-12-19 03:08:11 --> Security Class Initialized
DEBUG - 2016-12-19 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:08:11 --> Input Class Initialized
INFO - 2016-12-19 03:08:11 --> Language Class Initialized
INFO - 2016-12-19 03:08:11 --> Loader Class Initialized
INFO - 2016-12-19 03:08:11 --> Database Driver Class Initialized
INFO - 2016-12-19 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:08:11 --> Controller Class Initialized
INFO - 2016-12-19 03:08:11 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:08:11 --> Config Class Initialized
INFO - 2016-12-19 03:08:11 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:08:11 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:08:11 --> Utf8 Class Initialized
INFO - 2016-12-19 03:08:11 --> URI Class Initialized
DEBUG - 2016-12-19 03:08:11 --> No URI present. Default controller set.
INFO - 2016-12-19 03:08:11 --> Router Class Initialized
INFO - 2016-12-19 03:08:11 --> Output Class Initialized
INFO - 2016-12-19 03:08:11 --> Security Class Initialized
DEBUG - 2016-12-19 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:08:11 --> Input Class Initialized
INFO - 2016-12-19 03:08:11 --> Language Class Initialized
INFO - 2016-12-19 03:08:11 --> Loader Class Initialized
INFO - 2016-12-19 03:08:11 --> Database Driver Class Initialized
INFO - 2016-12-19 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:08:11 --> Controller Class Initialized
INFO - 2016-12-19 03:08:11 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:08:11 --> Final output sent to browser
DEBUG - 2016-12-19 03:08:11 --> Total execution time: 0.0129
INFO - 2016-12-19 03:08:11 --> Config Class Initialized
INFO - 2016-12-19 03:08:11 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:08:11 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:08:11 --> Utf8 Class Initialized
INFO - 2016-12-19 03:08:11 --> URI Class Initialized
INFO - 2016-12-19 03:08:11 --> Router Class Initialized
INFO - 2016-12-19 03:08:11 --> Output Class Initialized
INFO - 2016-12-19 03:08:11 --> Security Class Initialized
DEBUG - 2016-12-19 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:08:11 --> Input Class Initialized
INFO - 2016-12-19 03:08:11 --> Language Class Initialized
INFO - 2016-12-19 03:08:11 --> Loader Class Initialized
INFO - 2016-12-19 03:08:11 --> Database Driver Class Initialized
INFO - 2016-12-19 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:08:11 --> Controller Class Initialized
INFO - 2016-12-19 03:08:11 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:08:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:08:11 --> Final output sent to browser
DEBUG - 2016-12-19 03:08:11 --> Total execution time: 0.0369
INFO - 2016-12-19 03:08:12 --> Config Class Initialized
INFO - 2016-12-19 03:08:12 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:08:12 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:08:12 --> Utf8 Class Initialized
INFO - 2016-12-19 03:08:12 --> URI Class Initialized
INFO - 2016-12-19 03:08:12 --> Router Class Initialized
INFO - 2016-12-19 03:08:12 --> Output Class Initialized
INFO - 2016-12-19 03:08:12 --> Security Class Initialized
DEBUG - 2016-12-19 03:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:08:12 --> Input Class Initialized
INFO - 2016-12-19 03:08:12 --> Language Class Initialized
INFO - 2016-12-19 03:08:12 --> Loader Class Initialized
INFO - 2016-12-19 03:08:12 --> Database Driver Class Initialized
INFO - 2016-12-19 03:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:08:12 --> Controller Class Initialized
INFO - 2016-12-19 03:08:12 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:08:12 --> Final output sent to browser
DEBUG - 2016-12-19 03:08:12 --> Total execution time: 0.0128
INFO - 2016-12-19 03:08:55 --> Config Class Initialized
INFO - 2016-12-19 03:08:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:08:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:08:55 --> Utf8 Class Initialized
INFO - 2016-12-19 03:08:55 --> URI Class Initialized
DEBUG - 2016-12-19 03:08:55 --> No URI present. Default controller set.
INFO - 2016-12-19 03:08:55 --> Router Class Initialized
INFO - 2016-12-19 03:08:55 --> Output Class Initialized
INFO - 2016-12-19 03:08:55 --> Security Class Initialized
DEBUG - 2016-12-19 03:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:08:55 --> Input Class Initialized
INFO - 2016-12-19 03:08:55 --> Language Class Initialized
INFO - 2016-12-19 03:08:55 --> Loader Class Initialized
INFO - 2016-12-19 03:08:55 --> Database Driver Class Initialized
INFO - 2016-12-19 03:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:08:55 --> Controller Class Initialized
INFO - 2016-12-19 03:08:55 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:08:55 --> Final output sent to browser
DEBUG - 2016-12-19 03:08:55 --> Total execution time: 0.0128
INFO - 2016-12-19 03:08:55 --> Config Class Initialized
INFO - 2016-12-19 03:08:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:08:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:08:55 --> Utf8 Class Initialized
INFO - 2016-12-19 03:08:55 --> URI Class Initialized
INFO - 2016-12-19 03:08:55 --> Router Class Initialized
INFO - 2016-12-19 03:08:55 --> Output Class Initialized
INFO - 2016-12-19 03:08:55 --> Security Class Initialized
DEBUG - 2016-12-19 03:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:08:55 --> Input Class Initialized
INFO - 2016-12-19 03:08:55 --> Language Class Initialized
INFO - 2016-12-19 03:08:55 --> Loader Class Initialized
INFO - 2016-12-19 03:08:55 --> Database Driver Class Initialized
INFO - 2016-12-19 03:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:08:55 --> Controller Class Initialized
INFO - 2016-12-19 03:08:55 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:08:55 --> Final output sent to browser
DEBUG - 2016-12-19 03:08:55 --> Total execution time: 0.0161
INFO - 2016-12-19 03:36:51 --> Config Class Initialized
INFO - 2016-12-19 03:36:51 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:36:51 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:36:51 --> Utf8 Class Initialized
INFO - 2016-12-19 03:36:51 --> URI Class Initialized
INFO - 2016-12-19 03:36:51 --> Router Class Initialized
INFO - 2016-12-19 03:36:51 --> Output Class Initialized
INFO - 2016-12-19 03:36:51 --> Security Class Initialized
DEBUG - 2016-12-19 03:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:36:51 --> Input Class Initialized
INFO - 2016-12-19 03:36:51 --> Language Class Initialized
INFO - 2016-12-19 03:36:51 --> Loader Class Initialized
INFO - 2016-12-19 03:36:51 --> Database Driver Class Initialized
INFO - 2016-12-19 03:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:36:51 --> Controller Class Initialized
INFO - 2016-12-19 03:36:51 --> Helper loaded: date_helper
DEBUG - 2016-12-19 03:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:36:51 --> Helper loaded: url_helper
INFO - 2016-12-19 03:36:51 --> Helper loaded: download_helper
INFO - 2016-12-19 03:36:51 --> Config Class Initialized
INFO - 2016-12-19 03:36:51 --> Hooks Class Initialized
DEBUG - 2016-12-19 03:36:51 --> UTF-8 Support Enabled
INFO - 2016-12-19 03:36:51 --> Utf8 Class Initialized
INFO - 2016-12-19 03:36:51 --> URI Class Initialized
DEBUG - 2016-12-19 03:36:51 --> No URI present. Default controller set.
INFO - 2016-12-19 03:36:51 --> Router Class Initialized
INFO - 2016-12-19 03:36:51 --> Output Class Initialized
INFO - 2016-12-19 03:36:51 --> Security Class Initialized
DEBUG - 2016-12-19 03:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 03:36:51 --> Input Class Initialized
INFO - 2016-12-19 03:36:51 --> Language Class Initialized
INFO - 2016-12-19 03:36:51 --> Loader Class Initialized
INFO - 2016-12-19 03:36:51 --> Database Driver Class Initialized
INFO - 2016-12-19 03:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 03:36:51 --> Controller Class Initialized
INFO - 2016-12-19 03:36:51 --> Helper loaded: url_helper
DEBUG - 2016-12-19 03:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 03:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 03:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 03:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 03:36:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 03:36:51 --> Final output sent to browser
DEBUG - 2016-12-19 03:36:51 --> Total execution time: 0.0129
INFO - 2016-12-19 04:15:38 --> Config Class Initialized
INFO - 2016-12-19 04:15:38 --> Hooks Class Initialized
DEBUG - 2016-12-19 04:15:38 --> UTF-8 Support Enabled
INFO - 2016-12-19 04:15:38 --> Utf8 Class Initialized
INFO - 2016-12-19 04:15:38 --> URI Class Initialized
DEBUG - 2016-12-19 04:15:38 --> No URI present. Default controller set.
INFO - 2016-12-19 04:15:38 --> Router Class Initialized
INFO - 2016-12-19 04:15:38 --> Output Class Initialized
INFO - 2016-12-19 04:15:38 --> Security Class Initialized
DEBUG - 2016-12-19 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 04:15:38 --> Input Class Initialized
INFO - 2016-12-19 04:15:38 --> Language Class Initialized
INFO - 2016-12-19 04:15:38 --> Loader Class Initialized
INFO - 2016-12-19 04:15:38 --> Database Driver Class Initialized
INFO - 2016-12-19 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 04:15:38 --> Controller Class Initialized
INFO - 2016-12-19 04:15:38 --> Helper loaded: url_helper
DEBUG - 2016-12-19 04:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 04:15:38 --> Final output sent to browser
DEBUG - 2016-12-19 04:15:38 --> Total execution time: 0.1504
INFO - 2016-12-19 04:15:38 --> Config Class Initialized
INFO - 2016-12-19 04:15:38 --> Hooks Class Initialized
DEBUG - 2016-12-19 04:15:38 --> UTF-8 Support Enabled
INFO - 2016-12-19 04:15:38 --> Utf8 Class Initialized
INFO - 2016-12-19 04:15:38 --> URI Class Initialized
INFO - 2016-12-19 04:15:38 --> Router Class Initialized
INFO - 2016-12-19 04:15:38 --> Output Class Initialized
INFO - 2016-12-19 04:15:38 --> Security Class Initialized
DEBUG - 2016-12-19 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 04:15:38 --> Input Class Initialized
INFO - 2016-12-19 04:15:38 --> Language Class Initialized
INFO - 2016-12-19 04:15:38 --> Loader Class Initialized
INFO - 2016-12-19 04:15:38 --> Database Driver Class Initialized
INFO - 2016-12-19 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 04:15:38 --> Controller Class Initialized
INFO - 2016-12-19 04:15:38 --> Helper loaded: url_helper
DEBUG - 2016-12-19 04:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 04:15:38 --> Final output sent to browser
DEBUG - 2016-12-19 04:15:38 --> Total execution time: 0.0131
INFO - 2016-12-19 04:56:28 --> Config Class Initialized
INFO - 2016-12-19 04:56:28 --> Hooks Class Initialized
DEBUG - 2016-12-19 04:56:28 --> UTF-8 Support Enabled
INFO - 2016-12-19 04:56:28 --> Utf8 Class Initialized
INFO - 2016-12-19 04:56:28 --> URI Class Initialized
DEBUG - 2016-12-19 04:56:28 --> No URI present. Default controller set.
INFO - 2016-12-19 04:56:28 --> Router Class Initialized
INFO - 2016-12-19 04:56:28 --> Output Class Initialized
INFO - 2016-12-19 04:56:28 --> Security Class Initialized
DEBUG - 2016-12-19 04:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 04:56:28 --> Input Class Initialized
INFO - 2016-12-19 04:56:28 --> Language Class Initialized
INFO - 2016-12-19 04:56:28 --> Loader Class Initialized
INFO - 2016-12-19 04:56:28 --> Database Driver Class Initialized
INFO - 2016-12-19 04:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 04:56:28 --> Controller Class Initialized
INFO - 2016-12-19 04:56:28 --> Helper loaded: url_helper
DEBUG - 2016-12-19 04:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 04:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 04:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 04:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 04:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 04:56:28 --> Final output sent to browser
DEBUG - 2016-12-19 04:56:28 --> Total execution time: 0.1526
INFO - 2016-12-19 13:39:53 --> Config Class Initialized
INFO - 2016-12-19 13:39:53 --> Hooks Class Initialized
DEBUG - 2016-12-19 13:39:53 --> UTF-8 Support Enabled
INFO - 2016-12-19 13:39:53 --> Utf8 Class Initialized
INFO - 2016-12-19 13:39:53 --> URI Class Initialized
DEBUG - 2016-12-19 13:39:53 --> No URI present. Default controller set.
INFO - 2016-12-19 13:39:53 --> Router Class Initialized
INFO - 2016-12-19 13:39:53 --> Output Class Initialized
INFO - 2016-12-19 13:39:53 --> Security Class Initialized
DEBUG - 2016-12-19 13:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 13:39:53 --> Input Class Initialized
INFO - 2016-12-19 13:39:53 --> Language Class Initialized
INFO - 2016-12-19 13:39:53 --> Loader Class Initialized
INFO - 2016-12-19 13:39:54 --> Database Driver Class Initialized
INFO - 2016-12-19 13:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 13:39:54 --> Controller Class Initialized
INFO - 2016-12-19 13:39:54 --> Helper loaded: url_helper
DEBUG - 2016-12-19 13:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 13:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 13:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 13:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 13:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 13:39:54 --> Final output sent to browser
DEBUG - 2016-12-19 13:39:54 --> Total execution time: 1.5980
INFO - 2016-12-19 13:41:17 --> Config Class Initialized
INFO - 2016-12-19 13:41:17 --> Hooks Class Initialized
DEBUG - 2016-12-19 13:41:17 --> UTF-8 Support Enabled
INFO - 2016-12-19 13:41:17 --> Utf8 Class Initialized
INFO - 2016-12-19 13:41:17 --> URI Class Initialized
DEBUG - 2016-12-19 13:41:17 --> No URI present. Default controller set.
INFO - 2016-12-19 13:41:17 --> Router Class Initialized
INFO - 2016-12-19 13:41:17 --> Output Class Initialized
INFO - 2016-12-19 13:41:17 --> Security Class Initialized
DEBUG - 2016-12-19 13:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 13:41:17 --> Input Class Initialized
INFO - 2016-12-19 13:41:17 --> Language Class Initialized
INFO - 2016-12-19 13:41:17 --> Loader Class Initialized
INFO - 2016-12-19 13:41:17 --> Database Driver Class Initialized
INFO - 2016-12-19 13:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 13:41:17 --> Controller Class Initialized
INFO - 2016-12-19 13:41:17 --> Helper loaded: url_helper
DEBUG - 2016-12-19 13:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 13:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 13:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 13:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 13:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 13:41:17 --> Final output sent to browser
DEBUG - 2016-12-19 13:41:17 --> Total execution time: 0.0128
INFO - 2016-12-19 13:41:54 --> Config Class Initialized
INFO - 2016-12-19 13:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-19 13:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-19 13:41:54 --> Utf8 Class Initialized
INFO - 2016-12-19 13:41:54 --> URI Class Initialized
DEBUG - 2016-12-19 13:41:54 --> No URI present. Default controller set.
INFO - 2016-12-19 13:41:54 --> Router Class Initialized
INFO - 2016-12-19 13:41:54 --> Output Class Initialized
INFO - 2016-12-19 13:41:54 --> Security Class Initialized
DEBUG - 2016-12-19 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 13:41:54 --> Input Class Initialized
INFO - 2016-12-19 13:41:54 --> Language Class Initialized
INFO - 2016-12-19 13:41:54 --> Loader Class Initialized
INFO - 2016-12-19 13:41:54 --> Database Driver Class Initialized
INFO - 2016-12-19 13:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 13:41:54 --> Controller Class Initialized
INFO - 2016-12-19 13:41:54 --> Helper loaded: url_helper
DEBUG - 2016-12-19 13:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 13:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 13:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 13:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 13:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 13:41:54 --> Final output sent to browser
DEBUG - 2016-12-19 13:41:54 --> Total execution time: 0.0131
INFO - 2016-12-19 13:45:08 --> Config Class Initialized
INFO - 2016-12-19 13:45:08 --> Hooks Class Initialized
DEBUG - 2016-12-19 13:45:08 --> UTF-8 Support Enabled
INFO - 2016-12-19 13:45:08 --> Utf8 Class Initialized
INFO - 2016-12-19 13:45:08 --> URI Class Initialized
DEBUG - 2016-12-19 13:45:08 --> No URI present. Default controller set.
INFO - 2016-12-19 13:45:08 --> Router Class Initialized
INFO - 2016-12-19 13:45:08 --> Output Class Initialized
INFO - 2016-12-19 13:45:08 --> Security Class Initialized
DEBUG - 2016-12-19 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 13:45:08 --> Input Class Initialized
INFO - 2016-12-19 13:45:08 --> Language Class Initialized
INFO - 2016-12-19 13:45:09 --> Loader Class Initialized
INFO - 2016-12-19 13:45:09 --> Database Driver Class Initialized
INFO - 2016-12-19 13:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 13:45:09 --> Controller Class Initialized
INFO - 2016-12-19 13:45:09 --> Helper loaded: url_helper
DEBUG - 2016-12-19 13:45:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 13:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 13:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 13:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 13:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 13:45:09 --> Final output sent to browser
DEBUG - 2016-12-19 13:45:09 --> Total execution time: 0.0819
INFO - 2016-12-19 13:48:45 --> Config Class Initialized
INFO - 2016-12-19 13:48:45 --> Hooks Class Initialized
DEBUG - 2016-12-19 13:48:45 --> UTF-8 Support Enabled
INFO - 2016-12-19 13:48:45 --> Utf8 Class Initialized
INFO - 2016-12-19 13:48:45 --> URI Class Initialized
DEBUG - 2016-12-19 13:48:45 --> No URI present. Default controller set.
INFO - 2016-12-19 13:48:45 --> Router Class Initialized
INFO - 2016-12-19 13:48:45 --> Output Class Initialized
INFO - 2016-12-19 13:48:45 --> Security Class Initialized
DEBUG - 2016-12-19 13:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 13:48:45 --> Input Class Initialized
INFO - 2016-12-19 13:48:45 --> Language Class Initialized
INFO - 2016-12-19 13:48:45 --> Loader Class Initialized
INFO - 2016-12-19 13:48:45 --> Database Driver Class Initialized
INFO - 2016-12-19 13:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 13:48:45 --> Controller Class Initialized
INFO - 2016-12-19 13:48:45 --> Helper loaded: url_helper
DEBUG - 2016-12-19 13:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 13:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 13:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 13:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 13:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 13:48:45 --> Final output sent to browser
DEBUG - 2016-12-19 13:48:45 --> Total execution time: 0.1080
INFO - 2016-12-19 13:49:10 --> Config Class Initialized
INFO - 2016-12-19 13:49:10 --> Hooks Class Initialized
DEBUG - 2016-12-19 13:49:10 --> UTF-8 Support Enabled
INFO - 2016-12-19 13:49:10 --> Utf8 Class Initialized
INFO - 2016-12-19 13:49:10 --> URI Class Initialized
INFO - 2016-12-19 13:49:10 --> Router Class Initialized
INFO - 2016-12-19 13:49:10 --> Output Class Initialized
INFO - 2016-12-19 13:49:10 --> Security Class Initialized
DEBUG - 2016-12-19 13:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 13:49:10 --> Input Class Initialized
INFO - 2016-12-19 13:49:10 --> Language Class Initialized
INFO - 2016-12-19 13:49:10 --> Loader Class Initialized
INFO - 2016-12-19 13:49:10 --> Database Driver Class Initialized
INFO - 2016-12-19 13:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 13:49:10 --> Controller Class Initialized
INFO - 2016-12-19 13:49:10 --> Helper loaded: url_helper
DEBUG - 2016-12-19 13:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 13:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 13:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 13:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 13:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 13:49:10 --> Final output sent to browser
DEBUG - 2016-12-19 13:49:10 --> Total execution time: 0.0135
INFO - 2016-12-19 16:29:31 --> Config Class Initialized
INFO - 2016-12-19 16:29:31 --> Hooks Class Initialized
DEBUG - 2016-12-19 16:29:31 --> UTF-8 Support Enabled
INFO - 2016-12-19 16:29:31 --> Utf8 Class Initialized
INFO - 2016-12-19 16:29:31 --> URI Class Initialized
DEBUG - 2016-12-19 16:29:31 --> No URI present. Default controller set.
INFO - 2016-12-19 16:29:31 --> Router Class Initialized
INFO - 2016-12-19 16:29:31 --> Output Class Initialized
INFO - 2016-12-19 16:29:31 --> Security Class Initialized
DEBUG - 2016-12-19 16:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 16:29:31 --> Input Class Initialized
INFO - 2016-12-19 16:29:31 --> Language Class Initialized
INFO - 2016-12-19 16:29:31 --> Loader Class Initialized
INFO - 2016-12-19 16:29:31 --> Database Driver Class Initialized
INFO - 2016-12-19 16:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 16:29:32 --> Controller Class Initialized
INFO - 2016-12-19 16:29:32 --> Helper loaded: url_helper
DEBUG - 2016-12-19 16:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 16:29:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 16:29:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 16:29:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 16:29:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 16:29:32 --> Final output sent to browser
DEBUG - 2016-12-19 16:29:32 --> Total execution time: 1.8178
INFO - 2016-12-19 16:30:10 --> Config Class Initialized
INFO - 2016-12-19 16:30:10 --> Hooks Class Initialized
DEBUG - 2016-12-19 16:30:10 --> UTF-8 Support Enabled
INFO - 2016-12-19 16:30:10 --> Utf8 Class Initialized
INFO - 2016-12-19 16:30:10 --> URI Class Initialized
INFO - 2016-12-19 16:30:10 --> Router Class Initialized
INFO - 2016-12-19 16:30:10 --> Output Class Initialized
INFO - 2016-12-19 16:30:10 --> Security Class Initialized
DEBUG - 2016-12-19 16:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 16:30:10 --> Input Class Initialized
INFO - 2016-12-19 16:30:10 --> Language Class Initialized
INFO - 2016-12-19 16:30:10 --> Loader Class Initialized
INFO - 2016-12-19 16:30:10 --> Database Driver Class Initialized
INFO - 2016-12-19 16:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 16:30:10 --> Controller Class Initialized
INFO - 2016-12-19 16:30:10 --> Helper loaded: url_helper
DEBUG - 2016-12-19 16:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 16:30:12 --> Config Class Initialized
INFO - 2016-12-19 16:30:12 --> Hooks Class Initialized
DEBUG - 2016-12-19 16:30:12 --> UTF-8 Support Enabled
INFO - 2016-12-19 16:30:12 --> Utf8 Class Initialized
INFO - 2016-12-19 16:30:12 --> URI Class Initialized
INFO - 2016-12-19 16:30:12 --> Router Class Initialized
INFO - 2016-12-19 16:30:12 --> Output Class Initialized
INFO - 2016-12-19 16:30:12 --> Security Class Initialized
DEBUG - 2016-12-19 16:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 16:30:12 --> Input Class Initialized
INFO - 2016-12-19 16:30:12 --> Language Class Initialized
INFO - 2016-12-19 16:30:12 --> Loader Class Initialized
INFO - 2016-12-19 16:30:12 --> Database Driver Class Initialized
INFO - 2016-12-19 16:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 16:30:12 --> Controller Class Initialized
INFO - 2016-12-19 16:30:13 --> Helper loaded: date_helper
DEBUG - 2016-12-19 16:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 16:30:13 --> Helper loaded: url_helper
INFO - 2016-12-19 16:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 16:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 16:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-19 16:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-19 16:30:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 16:30:13 --> Final output sent to browser
DEBUG - 2016-12-19 16:30:13 --> Total execution time: 0.3718
INFO - 2016-12-19 16:30:25 --> Config Class Initialized
INFO - 2016-12-19 16:30:25 --> Hooks Class Initialized
DEBUG - 2016-12-19 16:30:25 --> UTF-8 Support Enabled
INFO - 2016-12-19 16:30:25 --> Utf8 Class Initialized
INFO - 2016-12-19 16:30:25 --> URI Class Initialized
DEBUG - 2016-12-19 16:30:25 --> No URI present. Default controller set.
INFO - 2016-12-19 16:30:25 --> Router Class Initialized
INFO - 2016-12-19 16:30:25 --> Output Class Initialized
INFO - 2016-12-19 16:30:25 --> Security Class Initialized
DEBUG - 2016-12-19 16:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 16:30:25 --> Input Class Initialized
INFO - 2016-12-19 16:30:25 --> Language Class Initialized
INFO - 2016-12-19 16:30:25 --> Loader Class Initialized
INFO - 2016-12-19 16:30:25 --> Database Driver Class Initialized
INFO - 2016-12-19 16:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 16:30:25 --> Controller Class Initialized
INFO - 2016-12-19 16:30:25 --> Helper loaded: url_helper
DEBUG - 2016-12-19 16:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 16:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 16:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 16:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 16:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 16:30:25 --> Final output sent to browser
DEBUG - 2016-12-19 16:30:25 --> Total execution time: 0.0127
INFO - 2016-12-19 16:30:27 --> Config Class Initialized
INFO - 2016-12-19 16:30:27 --> Hooks Class Initialized
DEBUG - 2016-12-19 16:30:27 --> UTF-8 Support Enabled
INFO - 2016-12-19 16:30:27 --> Utf8 Class Initialized
INFO - 2016-12-19 16:30:27 --> URI Class Initialized
INFO - 2016-12-19 16:30:27 --> Router Class Initialized
INFO - 2016-12-19 16:30:27 --> Output Class Initialized
INFO - 2016-12-19 16:30:27 --> Security Class Initialized
DEBUG - 2016-12-19 16:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 16:30:27 --> Input Class Initialized
INFO - 2016-12-19 16:30:27 --> Language Class Initialized
INFO - 2016-12-19 16:30:27 --> Loader Class Initialized
INFO - 2016-12-19 16:30:27 --> Database Driver Class Initialized
INFO - 2016-12-19 16:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 16:30:27 --> Controller Class Initialized
INFO - 2016-12-19 16:30:27 --> Helper loaded: date_helper
DEBUG - 2016-12-19 16:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 16:30:27 --> Helper loaded: url_helper
INFO - 2016-12-19 16:30:27 --> Helper loaded: download_helper
INFO - 2016-12-19 16:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 16:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 16:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-19 16:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-19 16:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 16:30:27 --> Final output sent to browser
DEBUG - 2016-12-19 16:30:27 --> Total execution time: 0.1341
INFO - 2016-12-19 16:33:06 --> Config Class Initialized
INFO - 2016-12-19 16:33:06 --> Hooks Class Initialized
DEBUG - 2016-12-19 16:33:06 --> UTF-8 Support Enabled
INFO - 2016-12-19 16:33:06 --> Utf8 Class Initialized
INFO - 2016-12-19 16:33:06 --> URI Class Initialized
INFO - 2016-12-19 16:33:06 --> Router Class Initialized
INFO - 2016-12-19 16:33:06 --> Output Class Initialized
INFO - 2016-12-19 16:33:06 --> Security Class Initialized
DEBUG - 2016-12-19 16:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 16:33:06 --> Input Class Initialized
INFO - 2016-12-19 16:33:06 --> Language Class Initialized
INFO - 2016-12-19 16:33:06 --> Loader Class Initialized
INFO - 2016-12-19 16:33:06 --> Database Driver Class Initialized
INFO - 2016-12-19 16:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 16:33:06 --> Controller Class Initialized
INFO - 2016-12-19 16:33:06 --> Helper loaded: date_helper
DEBUG - 2016-12-19 16:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 16:33:06 --> Helper loaded: url_helper
INFO - 2016-12-19 16:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 16:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 16:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-19 16:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-19 16:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 16:33:06 --> Final output sent to browser
DEBUG - 2016-12-19 16:33:06 --> Total execution time: 0.0136
INFO - 2016-12-19 17:51:28 --> Config Class Initialized
INFO - 2016-12-19 17:51:28 --> Hooks Class Initialized
DEBUG - 2016-12-19 17:51:28 --> UTF-8 Support Enabled
INFO - 2016-12-19 17:51:28 --> Utf8 Class Initialized
INFO - 2016-12-19 17:51:28 --> URI Class Initialized
DEBUG - 2016-12-19 17:51:28 --> No URI present. Default controller set.
INFO - 2016-12-19 17:51:28 --> Router Class Initialized
INFO - 2016-12-19 17:51:28 --> Output Class Initialized
INFO - 2016-12-19 17:51:28 --> Security Class Initialized
DEBUG - 2016-12-19 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 17:51:28 --> Input Class Initialized
INFO - 2016-12-19 17:51:28 --> Language Class Initialized
INFO - 2016-12-19 17:51:28 --> Loader Class Initialized
INFO - 2016-12-19 17:51:29 --> Database Driver Class Initialized
INFO - 2016-12-19 17:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 17:51:29 --> Controller Class Initialized
INFO - 2016-12-19 17:51:29 --> Helper loaded: url_helper
DEBUG - 2016-12-19 17:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 17:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 17:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 17:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 17:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 17:51:29 --> Final output sent to browser
DEBUG - 2016-12-19 17:51:29 --> Total execution time: 1.7176
INFO - 2016-12-19 17:56:06 --> Config Class Initialized
INFO - 2016-12-19 17:56:06 --> Hooks Class Initialized
DEBUG - 2016-12-19 17:56:07 --> UTF-8 Support Enabled
INFO - 2016-12-19 17:56:07 --> Utf8 Class Initialized
INFO - 2016-12-19 17:56:07 --> URI Class Initialized
INFO - 2016-12-19 17:56:07 --> Router Class Initialized
INFO - 2016-12-19 17:56:07 --> Output Class Initialized
INFO - 2016-12-19 17:56:07 --> Security Class Initialized
DEBUG - 2016-12-19 17:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 17:56:07 --> Input Class Initialized
INFO - 2016-12-19 17:56:07 --> Language Class Initialized
INFO - 2016-12-19 17:56:07 --> Loader Class Initialized
INFO - 2016-12-19 17:56:07 --> Database Driver Class Initialized
INFO - 2016-12-19 17:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 17:56:07 --> Controller Class Initialized
INFO - 2016-12-19 17:56:07 --> Helper loaded: url_helper
DEBUG - 2016-12-19 17:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 17:56:07 --> Config Class Initialized
INFO - 2016-12-19 17:56:07 --> Hooks Class Initialized
DEBUG - 2016-12-19 17:56:07 --> UTF-8 Support Enabled
INFO - 2016-12-19 17:56:07 --> Utf8 Class Initialized
INFO - 2016-12-19 17:56:07 --> URI Class Initialized
DEBUG - 2016-12-19 17:56:07 --> No URI present. Default controller set.
INFO - 2016-12-19 17:56:07 --> Router Class Initialized
INFO - 2016-12-19 17:56:07 --> Output Class Initialized
INFO - 2016-12-19 17:56:07 --> Security Class Initialized
DEBUG - 2016-12-19 17:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 17:56:07 --> Input Class Initialized
INFO - 2016-12-19 17:56:07 --> Language Class Initialized
INFO - 2016-12-19 17:56:07 --> Loader Class Initialized
INFO - 2016-12-19 17:56:07 --> Database Driver Class Initialized
INFO - 2016-12-19 17:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 17:56:07 --> Controller Class Initialized
INFO - 2016-12-19 17:56:07 --> Helper loaded: url_helper
DEBUG - 2016-12-19 17:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 17:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 17:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 17:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 17:56:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 17:56:07 --> Final output sent to browser
DEBUG - 2016-12-19 17:56:07 --> Total execution time: 0.0133
INFO - 2016-12-19 19:37:15 --> Config Class Initialized
INFO - 2016-12-19 19:37:15 --> Hooks Class Initialized
DEBUG - 2016-12-19 19:37:16 --> UTF-8 Support Enabled
INFO - 2016-12-19 19:37:16 --> Utf8 Class Initialized
INFO - 2016-12-19 19:37:16 --> URI Class Initialized
DEBUG - 2016-12-19 19:37:16 --> No URI present. Default controller set.
INFO - 2016-12-19 19:37:16 --> Router Class Initialized
INFO - 2016-12-19 19:37:16 --> Output Class Initialized
INFO - 2016-12-19 19:37:16 --> Security Class Initialized
DEBUG - 2016-12-19 19:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 19:37:16 --> Input Class Initialized
INFO - 2016-12-19 19:37:16 --> Language Class Initialized
INFO - 2016-12-19 19:37:16 --> Loader Class Initialized
INFO - 2016-12-19 19:37:16 --> Database Driver Class Initialized
INFO - 2016-12-19 19:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 19:37:16 --> Controller Class Initialized
INFO - 2016-12-19 19:37:16 --> Helper loaded: url_helper
DEBUG - 2016-12-19 19:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 19:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 19:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 19:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 19:37:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 19:37:17 --> Final output sent to browser
DEBUG - 2016-12-19 19:37:17 --> Total execution time: 1.7142
INFO - 2016-12-19 22:20:40 --> Config Class Initialized
INFO - 2016-12-19 22:20:40 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:20:40 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:20:40 --> Utf8 Class Initialized
INFO - 2016-12-19 22:20:40 --> URI Class Initialized
DEBUG - 2016-12-19 22:20:40 --> No URI present. Default controller set.
INFO - 2016-12-19 22:20:40 --> Router Class Initialized
INFO - 2016-12-19 22:20:41 --> Output Class Initialized
INFO - 2016-12-19 22:20:41 --> Security Class Initialized
DEBUG - 2016-12-19 22:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:20:41 --> Input Class Initialized
INFO - 2016-12-19 22:20:41 --> Language Class Initialized
INFO - 2016-12-19 22:20:41 --> Loader Class Initialized
INFO - 2016-12-19 22:20:41 --> Database Driver Class Initialized
INFO - 2016-12-19 22:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:20:41 --> Controller Class Initialized
INFO - 2016-12-19 22:20:41 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:20:42 --> Final output sent to browser
DEBUG - 2016-12-19 22:20:42 --> Total execution time: 1.6294
INFO - 2016-12-19 22:33:52 --> Config Class Initialized
INFO - 2016-12-19 22:33:52 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:33:52 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:33:52 --> Utf8 Class Initialized
INFO - 2016-12-19 22:33:52 --> URI Class Initialized
DEBUG - 2016-12-19 22:33:52 --> No URI present. Default controller set.
INFO - 2016-12-19 22:33:52 --> Router Class Initialized
INFO - 2016-12-19 22:33:52 --> Output Class Initialized
INFO - 2016-12-19 22:33:52 --> Security Class Initialized
DEBUG - 2016-12-19 22:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:33:52 --> Input Class Initialized
INFO - 2016-12-19 22:33:52 --> Language Class Initialized
INFO - 2016-12-19 22:33:52 --> Loader Class Initialized
INFO - 2016-12-19 22:33:52 --> Database Driver Class Initialized
INFO - 2016-12-19 22:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:33:52 --> Controller Class Initialized
INFO - 2016-12-19 22:33:52 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:33:52 --> Final output sent to browser
DEBUG - 2016-12-19 22:33:52 --> Total execution time: 0.5449
INFO - 2016-12-19 22:33:53 --> Config Class Initialized
INFO - 2016-12-19 22:33:53 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:33:53 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:33:53 --> Utf8 Class Initialized
INFO - 2016-12-19 22:33:53 --> URI Class Initialized
INFO - 2016-12-19 22:33:53 --> Router Class Initialized
INFO - 2016-12-19 22:33:53 --> Output Class Initialized
INFO - 2016-12-19 22:33:53 --> Security Class Initialized
DEBUG - 2016-12-19 22:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:33:53 --> Input Class Initialized
INFO - 2016-12-19 22:33:53 --> Language Class Initialized
INFO - 2016-12-19 22:33:53 --> Loader Class Initialized
INFO - 2016-12-19 22:33:53 --> Database Driver Class Initialized
INFO - 2016-12-19 22:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:33:53 --> Controller Class Initialized
INFO - 2016-12-19 22:33:53 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:33:53 --> Final output sent to browser
DEBUG - 2016-12-19 22:33:53 --> Total execution time: 0.0252
INFO - 2016-12-19 22:34:56 --> Config Class Initialized
INFO - 2016-12-19 22:34:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:34:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:34:56 --> Utf8 Class Initialized
INFO - 2016-12-19 22:34:56 --> URI Class Initialized
DEBUG - 2016-12-19 22:34:56 --> No URI present. Default controller set.
INFO - 2016-12-19 22:34:56 --> Router Class Initialized
INFO - 2016-12-19 22:34:56 --> Output Class Initialized
INFO - 2016-12-19 22:34:56 --> Security Class Initialized
DEBUG - 2016-12-19 22:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:34:56 --> Input Class Initialized
INFO - 2016-12-19 22:34:56 --> Language Class Initialized
INFO - 2016-12-19 22:34:56 --> Loader Class Initialized
INFO - 2016-12-19 22:34:56 --> Database Driver Class Initialized
INFO - 2016-12-19 22:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:34:56 --> Controller Class Initialized
INFO - 2016-12-19 22:34:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:34:56 --> Final output sent to browser
DEBUG - 2016-12-19 22:34:56 --> Total execution time: 0.0136
INFO - 2016-12-19 22:34:56 --> Config Class Initialized
INFO - 2016-12-19 22:34:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:34:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:34:56 --> Utf8 Class Initialized
INFO - 2016-12-19 22:34:56 --> URI Class Initialized
INFO - 2016-12-19 22:34:56 --> Router Class Initialized
INFO - 2016-12-19 22:34:56 --> Output Class Initialized
INFO - 2016-12-19 22:34:56 --> Security Class Initialized
DEBUG - 2016-12-19 22:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:34:56 --> Input Class Initialized
INFO - 2016-12-19 22:34:56 --> Language Class Initialized
INFO - 2016-12-19 22:34:56 --> Loader Class Initialized
INFO - 2016-12-19 22:34:56 --> Database Driver Class Initialized
INFO - 2016-12-19 22:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:34:56 --> Controller Class Initialized
INFO - 2016-12-19 22:34:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:34:56 --> Final output sent to browser
DEBUG - 2016-12-19 22:34:56 --> Total execution time: 0.0147
INFO - 2016-12-19 22:35:42 --> Config Class Initialized
INFO - 2016-12-19 22:35:42 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:35:42 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:35:42 --> Utf8 Class Initialized
INFO - 2016-12-19 22:35:42 --> URI Class Initialized
DEBUG - 2016-12-19 22:35:42 --> No URI present. Default controller set.
INFO - 2016-12-19 22:35:42 --> Router Class Initialized
INFO - 2016-12-19 22:35:42 --> Output Class Initialized
INFO - 2016-12-19 22:35:42 --> Security Class Initialized
DEBUG - 2016-12-19 22:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:35:42 --> Input Class Initialized
INFO - 2016-12-19 22:35:42 --> Language Class Initialized
INFO - 2016-12-19 22:35:42 --> Loader Class Initialized
INFO - 2016-12-19 22:35:42 --> Database Driver Class Initialized
INFO - 2016-12-19 22:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:35:43 --> Controller Class Initialized
INFO - 2016-12-19 22:35:43 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:35:43 --> Final output sent to browser
DEBUG - 2016-12-19 22:35:43 --> Total execution time: 0.0532
INFO - 2016-12-19 22:35:43 --> Config Class Initialized
INFO - 2016-12-19 22:35:43 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:35:43 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:35:43 --> Utf8 Class Initialized
INFO - 2016-12-19 22:35:43 --> URI Class Initialized
INFO - 2016-12-19 22:35:43 --> Router Class Initialized
INFO - 2016-12-19 22:35:43 --> Output Class Initialized
INFO - 2016-12-19 22:35:43 --> Security Class Initialized
DEBUG - 2016-12-19 22:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:35:43 --> Input Class Initialized
INFO - 2016-12-19 22:35:43 --> Language Class Initialized
INFO - 2016-12-19 22:35:43 --> Loader Class Initialized
INFO - 2016-12-19 22:35:43 --> Database Driver Class Initialized
INFO - 2016-12-19 22:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:35:43 --> Controller Class Initialized
INFO - 2016-12-19 22:35:43 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:35:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:35:43 --> Final output sent to browser
DEBUG - 2016-12-19 22:35:43 --> Total execution time: 0.0135
INFO - 2016-12-19 22:35:55 --> Config Class Initialized
INFO - 2016-12-19 22:35:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:35:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:35:55 --> Utf8 Class Initialized
INFO - 2016-12-19 22:35:55 --> URI Class Initialized
DEBUG - 2016-12-19 22:35:55 --> No URI present. Default controller set.
INFO - 2016-12-19 22:35:55 --> Router Class Initialized
INFO - 2016-12-19 22:35:55 --> Output Class Initialized
INFO - 2016-12-19 22:35:55 --> Security Class Initialized
DEBUG - 2016-12-19 22:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:35:55 --> Input Class Initialized
INFO - 2016-12-19 22:35:55 --> Language Class Initialized
INFO - 2016-12-19 22:35:55 --> Loader Class Initialized
INFO - 2016-12-19 22:35:55 --> Database Driver Class Initialized
INFO - 2016-12-19 22:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:35:55 --> Controller Class Initialized
INFO - 2016-12-19 22:35:55 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:35:55 --> Final output sent to browser
DEBUG - 2016-12-19 22:35:55 --> Total execution time: 0.0127
INFO - 2016-12-19 22:35:55 --> Config Class Initialized
INFO - 2016-12-19 22:35:55 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:35:55 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:35:55 --> Utf8 Class Initialized
INFO - 2016-12-19 22:35:55 --> URI Class Initialized
INFO - 2016-12-19 22:35:55 --> Router Class Initialized
INFO - 2016-12-19 22:35:55 --> Output Class Initialized
INFO - 2016-12-19 22:35:55 --> Security Class Initialized
DEBUG - 2016-12-19 22:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:35:55 --> Input Class Initialized
INFO - 2016-12-19 22:35:55 --> Language Class Initialized
INFO - 2016-12-19 22:35:55 --> Loader Class Initialized
INFO - 2016-12-19 22:35:55 --> Database Driver Class Initialized
INFO - 2016-12-19 22:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:35:55 --> Controller Class Initialized
INFO - 2016-12-19 22:35:55 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:35:55 --> Final output sent to browser
DEBUG - 2016-12-19 22:35:55 --> Total execution time: 0.0128
INFO - 2016-12-19 22:36:07 --> Config Class Initialized
INFO - 2016-12-19 22:36:07 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:07 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:07 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:07 --> URI Class Initialized
INFO - 2016-12-19 22:36:07 --> Router Class Initialized
INFO - 2016-12-19 22:36:07 --> Output Class Initialized
INFO - 2016-12-19 22:36:07 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:07 --> Input Class Initialized
INFO - 2016-12-19 22:36:07 --> Language Class Initialized
INFO - 2016-12-19 22:36:07 --> Loader Class Initialized
INFO - 2016-12-19 22:36:07 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:07 --> Controller Class Initialized
INFO - 2016-12-19 22:36:07 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:10 --> Config Class Initialized
INFO - 2016-12-19 22:36:10 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:10 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:10 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:10 --> URI Class Initialized
INFO - 2016-12-19 22:36:10 --> Router Class Initialized
INFO - 2016-12-19 22:36:10 --> Output Class Initialized
INFO - 2016-12-19 22:36:10 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:10 --> Input Class Initialized
INFO - 2016-12-19 22:36:10 --> Language Class Initialized
INFO - 2016-12-19 22:36:10 --> Loader Class Initialized
INFO - 2016-12-19 22:36:10 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:10 --> Controller Class Initialized
INFO - 2016-12-19 22:36:10 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:11 --> Config Class Initialized
INFO - 2016-12-19 22:36:11 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:11 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:11 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:11 --> URI Class Initialized
INFO - 2016-12-19 22:36:11 --> Router Class Initialized
INFO - 2016-12-19 22:36:11 --> Output Class Initialized
INFO - 2016-12-19 22:36:11 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:11 --> Input Class Initialized
INFO - 2016-12-19 22:36:11 --> Language Class Initialized
INFO - 2016-12-19 22:36:12 --> Loader Class Initialized
INFO - 2016-12-19 22:36:12 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:12 --> Controller Class Initialized
INFO - 2016-12-19 22:36:12 --> Helper loaded: date_helper
DEBUG - 2016-12-19 22:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:12 --> Helper loaded: url_helper
INFO - 2016-12-19 22:36:12 --> Config Class Initialized
INFO - 2016-12-19 22:36:12 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:12 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:12 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:12 --> URI Class Initialized
INFO - 2016-12-19 22:36:12 --> Router Class Initialized
INFO - 2016-12-19 22:36:12 --> Output Class Initialized
INFO - 2016-12-19 22:36:12 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:12 --> Input Class Initialized
INFO - 2016-12-19 22:36:12 --> Language Class Initialized
INFO - 2016-12-19 22:36:12 --> Loader Class Initialized
INFO - 2016-12-19 22:36:12 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:36:12 --> Final output sent to browser
DEBUG - 2016-12-19 22:36:12 --> Total execution time: 0.6436
INFO - 2016-12-19 22:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:12 --> Controller Class Initialized
INFO - 2016-12-19 22:36:12 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:12 --> Config Class Initialized
INFO - 2016-12-19 22:36:12 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:12 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:12 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:12 --> URI Class Initialized
INFO - 2016-12-19 22:36:12 --> Router Class Initialized
INFO - 2016-12-19 22:36:12 --> Output Class Initialized
INFO - 2016-12-19 22:36:12 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:12 --> Input Class Initialized
INFO - 2016-12-19 22:36:12 --> Language Class Initialized
INFO - 2016-12-19 22:36:12 --> Loader Class Initialized
INFO - 2016-12-19 22:36:12 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:12 --> Controller Class Initialized
INFO - 2016-12-19 22:36:12 --> Helper loaded: date_helper
DEBUG - 2016-12-19 22:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:12 --> Helper loaded: url_helper
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-19 22:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:36:12 --> Final output sent to browser
DEBUG - 2016-12-19 22:36:12 --> Total execution time: 0.0158
INFO - 2016-12-19 22:36:13 --> Config Class Initialized
INFO - 2016-12-19 22:36:13 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:13 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:13 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:13 --> URI Class Initialized
INFO - 2016-12-19 22:36:13 --> Router Class Initialized
INFO - 2016-12-19 22:36:13 --> Output Class Initialized
INFO - 2016-12-19 22:36:13 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:13 --> Input Class Initialized
INFO - 2016-12-19 22:36:13 --> Language Class Initialized
INFO - 2016-12-19 22:36:13 --> Loader Class Initialized
INFO - 2016-12-19 22:36:13 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:13 --> Controller Class Initialized
INFO - 2016-12-19 22:36:13 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:36:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:36:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:36:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:36:13 --> Final output sent to browser
DEBUG - 2016-12-19 22:36:13 --> Total execution time: 0.0132
INFO - 2016-12-19 22:36:25 --> Config Class Initialized
INFO - 2016-12-19 22:36:25 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:25 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:25 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:25 --> URI Class Initialized
INFO - 2016-12-19 22:36:25 --> Router Class Initialized
INFO - 2016-12-19 22:36:25 --> Output Class Initialized
INFO - 2016-12-19 22:36:25 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:25 --> Input Class Initialized
INFO - 2016-12-19 22:36:25 --> Language Class Initialized
INFO - 2016-12-19 22:36:25 --> Loader Class Initialized
INFO - 2016-12-19 22:36:25 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:25 --> Controller Class Initialized
INFO - 2016-12-19 22:36:25 --> Helper loaded: date_helper
DEBUG - 2016-12-19 22:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:25 --> Helper loaded: url_helper
INFO - 2016-12-19 22:36:25 --> Helper loaded: download_helper
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:36:25 --> Final output sent to browser
DEBUG - 2016-12-19 22:36:25 --> Total execution time: 0.1359
INFO - 2016-12-19 22:36:25 --> Config Class Initialized
INFO - 2016-12-19 22:36:25 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:25 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:25 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:25 --> URI Class Initialized
INFO - 2016-12-19 22:36:25 --> Router Class Initialized
INFO - 2016-12-19 22:36:25 --> Output Class Initialized
INFO - 2016-12-19 22:36:25 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:25 --> Input Class Initialized
INFO - 2016-12-19 22:36:25 --> Language Class Initialized
INFO - 2016-12-19 22:36:25 --> Loader Class Initialized
INFO - 2016-12-19 22:36:25 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:25 --> Controller Class Initialized
INFO - 2016-12-19 22:36:25 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:36:25 --> Final output sent to browser
DEBUG - 2016-12-19 22:36:25 --> Total execution time: 0.0465
INFO - 2016-12-19 22:36:33 --> Config Class Initialized
INFO - 2016-12-19 22:36:33 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:33 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:33 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:33 --> URI Class Initialized
INFO - 2016-12-19 22:36:33 --> Router Class Initialized
INFO - 2016-12-19 22:36:33 --> Output Class Initialized
INFO - 2016-12-19 22:36:33 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:33 --> Input Class Initialized
INFO - 2016-12-19 22:36:33 --> Language Class Initialized
INFO - 2016-12-19 22:36:33 --> Loader Class Initialized
INFO - 2016-12-19 22:36:33 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:33 --> Controller Class Initialized
INFO - 2016-12-19 22:36:33 --> Helper loaded: date_helper
DEBUG - 2016-12-19 22:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:33 --> Helper loaded: url_helper
INFO - 2016-12-19 22:36:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:36:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-19 22:36:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 22:36:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-19 22:36:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-19 22:36:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:36:33 --> Final output sent to browser
DEBUG - 2016-12-19 22:36:33 --> Total execution time: 0.1246
INFO - 2016-12-19 22:36:34 --> Config Class Initialized
INFO - 2016-12-19 22:36:34 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:36:34 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:36:34 --> Utf8 Class Initialized
INFO - 2016-12-19 22:36:34 --> URI Class Initialized
INFO - 2016-12-19 22:36:34 --> Router Class Initialized
INFO - 2016-12-19 22:36:34 --> Output Class Initialized
INFO - 2016-12-19 22:36:34 --> Security Class Initialized
DEBUG - 2016-12-19 22:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:36:34 --> Input Class Initialized
INFO - 2016-12-19 22:36:34 --> Language Class Initialized
INFO - 2016-12-19 22:36:34 --> Loader Class Initialized
INFO - 2016-12-19 22:36:34 --> Database Driver Class Initialized
INFO - 2016-12-19 22:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:36:34 --> Controller Class Initialized
INFO - 2016-12-19 22:36:34 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:36:34 --> Final output sent to browser
DEBUG - 2016-12-19 22:36:34 --> Total execution time: 0.0410
INFO - 2016-12-19 22:42:56 --> Config Class Initialized
INFO - 2016-12-19 22:42:56 --> Hooks Class Initialized
DEBUG - 2016-12-19 22:42:56 --> UTF-8 Support Enabled
INFO - 2016-12-19 22:42:56 --> Utf8 Class Initialized
INFO - 2016-12-19 22:42:56 --> URI Class Initialized
DEBUG - 2016-12-19 22:42:56 --> No URI present. Default controller set.
INFO - 2016-12-19 22:42:56 --> Router Class Initialized
INFO - 2016-12-19 22:42:56 --> Output Class Initialized
INFO - 2016-12-19 22:42:56 --> Security Class Initialized
DEBUG - 2016-12-19 22:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 22:42:56 --> Input Class Initialized
INFO - 2016-12-19 22:42:56 --> Language Class Initialized
INFO - 2016-12-19 22:42:56 --> Loader Class Initialized
INFO - 2016-12-19 22:42:56 --> Database Driver Class Initialized
INFO - 2016-12-19 22:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 22:42:56 --> Controller Class Initialized
INFO - 2016-12-19 22:42:56 --> Helper loaded: url_helper
DEBUG - 2016-12-19 22:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 22:42:57 --> Final output sent to browser
DEBUG - 2016-12-19 22:42:57 --> Total execution time: 0.0203
INFO - 2016-12-19 23:20:59 --> Config Class Initialized
INFO - 2016-12-19 23:20:59 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:20:59 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:20:59 --> Utf8 Class Initialized
INFO - 2016-12-19 23:20:59 --> URI Class Initialized
INFO - 2016-12-19 23:20:59 --> Router Class Initialized
INFO - 2016-12-19 23:20:59 --> Output Class Initialized
INFO - 2016-12-19 23:20:59 --> Security Class Initialized
DEBUG - 2016-12-19 23:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:20:59 --> Input Class Initialized
INFO - 2016-12-19 23:20:59 --> Language Class Initialized
INFO - 2016-12-19 23:20:59 --> Loader Class Initialized
INFO - 2016-12-19 23:21:00 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:00 --> Controller Class Initialized
INFO - 2016-12-19 23:21:00 --> Helper loaded: url_helper
DEBUG - 2016-12-19 23:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:04 --> Config Class Initialized
INFO - 2016-12-19 23:21:04 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:21:04 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:21:04 --> Utf8 Class Initialized
INFO - 2016-12-19 23:21:04 --> URI Class Initialized
INFO - 2016-12-19 23:21:04 --> Router Class Initialized
INFO - 2016-12-19 23:21:04 --> Output Class Initialized
INFO - 2016-12-19 23:21:04 --> Security Class Initialized
DEBUG - 2016-12-19 23:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:21:04 --> Input Class Initialized
INFO - 2016-12-19 23:21:04 --> Language Class Initialized
INFO - 2016-12-19 23:21:04 --> Loader Class Initialized
INFO - 2016-12-19 23:21:04 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:04 --> Controller Class Initialized
INFO - 2016-12-19 23:21:04 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:04 --> Helper loaded: url_helper
INFO - 2016-12-19 23:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 23:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-19 23:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-19 23:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:21:04 --> Final output sent to browser
DEBUG - 2016-12-19 23:21:04 --> Total execution time: 0.1730
INFO - 2016-12-19 23:21:18 --> Config Class Initialized
INFO - 2016-12-19 23:21:18 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:21:18 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:21:18 --> Utf8 Class Initialized
INFO - 2016-12-19 23:21:18 --> URI Class Initialized
INFO - 2016-12-19 23:21:18 --> Router Class Initialized
INFO - 2016-12-19 23:21:18 --> Output Class Initialized
INFO - 2016-12-19 23:21:18 --> Security Class Initialized
DEBUG - 2016-12-19 23:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:21:18 --> Input Class Initialized
INFO - 2016-12-19 23:21:18 --> Language Class Initialized
INFO - 2016-12-19 23:21:18 --> Loader Class Initialized
INFO - 2016-12-19 23:21:18 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:18 --> Controller Class Initialized
INFO - 2016-12-19 23:21:18 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:18 --> Helper loaded: url_helper
INFO - 2016-12-19 23:21:18 --> Final output sent to browser
DEBUG - 2016-12-19 23:21:18 --> Total execution time: 0.0122
INFO - 2016-12-19 23:21:23 --> Config Class Initialized
INFO - 2016-12-19 23:21:23 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:21:23 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:21:23 --> Utf8 Class Initialized
INFO - 2016-12-19 23:21:23 --> URI Class Initialized
INFO - 2016-12-19 23:21:23 --> Router Class Initialized
INFO - 2016-12-19 23:21:23 --> Output Class Initialized
INFO - 2016-12-19 23:21:23 --> Security Class Initialized
DEBUG - 2016-12-19 23:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:21:23 --> Input Class Initialized
INFO - 2016-12-19 23:21:23 --> Language Class Initialized
INFO - 2016-12-19 23:21:23 --> Loader Class Initialized
INFO - 2016-12-19 23:21:23 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:23 --> Controller Class Initialized
INFO - 2016-12-19 23:21:23 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:23 --> Helper loaded: url_helper
INFO - 2016-12-19 23:21:23 --> Final output sent to browser
DEBUG - 2016-12-19 23:21:23 --> Total execution time: 0.0122
INFO - 2016-12-19 23:21:26 --> Config Class Initialized
INFO - 2016-12-19 23:21:26 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:21:26 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:21:26 --> Utf8 Class Initialized
INFO - 2016-12-19 23:21:26 --> URI Class Initialized
INFO - 2016-12-19 23:21:26 --> Router Class Initialized
INFO - 2016-12-19 23:21:26 --> Output Class Initialized
INFO - 2016-12-19 23:21:26 --> Security Class Initialized
DEBUG - 2016-12-19 23:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:21:26 --> Input Class Initialized
INFO - 2016-12-19 23:21:26 --> Language Class Initialized
INFO - 2016-12-19 23:21:26 --> Loader Class Initialized
INFO - 2016-12-19 23:21:26 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:26 --> Controller Class Initialized
INFO - 2016-12-19 23:21:26 --> Upload Class Initialized
INFO - 2016-12-19 23:21:26 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:26 --> Helper loaded: url_helper
INFO - 2016-12-19 23:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 23:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-19 23:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:21:27 --> Final output sent to browser
DEBUG - 2016-12-19 23:21:27 --> Total execution time: 0.4531
INFO - 2016-12-19 23:21:27 --> Config Class Initialized
INFO - 2016-12-19 23:21:27 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:21:27 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:21:27 --> Utf8 Class Initialized
INFO - 2016-12-19 23:21:27 --> URI Class Initialized
INFO - 2016-12-19 23:21:27 --> Router Class Initialized
INFO - 2016-12-19 23:21:27 --> Output Class Initialized
INFO - 2016-12-19 23:21:27 --> Security Class Initialized
DEBUG - 2016-12-19 23:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:21:27 --> Input Class Initialized
INFO - 2016-12-19 23:21:27 --> Language Class Initialized
INFO - 2016-12-19 23:21:27 --> Loader Class Initialized
INFO - 2016-12-19 23:21:27 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:27 --> Controller Class Initialized
INFO - 2016-12-19 23:21:27 --> Upload Class Initialized
INFO - 2016-12-19 23:21:27 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:27 --> Helper loaded: url_helper
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-19 23:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:21:27 --> Final output sent to browser
DEBUG - 2016-12-19 23:21:27 --> Total execution time: 0.0159
INFO - 2016-12-19 23:21:44 --> Config Class Initialized
INFO - 2016-12-19 23:21:44 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:21:44 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:21:44 --> Utf8 Class Initialized
INFO - 2016-12-19 23:21:44 --> URI Class Initialized
INFO - 2016-12-19 23:21:44 --> Router Class Initialized
INFO - 2016-12-19 23:21:44 --> Output Class Initialized
INFO - 2016-12-19 23:21:44 --> Security Class Initialized
DEBUG - 2016-12-19 23:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:21:44 --> Input Class Initialized
INFO - 2016-12-19 23:21:44 --> Language Class Initialized
INFO - 2016-12-19 23:21:44 --> Loader Class Initialized
INFO - 2016-12-19 23:21:44 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:44 --> Controller Class Initialized
INFO - 2016-12-19 23:21:44 --> Upload Class Initialized
INFO - 2016-12-19 23:21:44 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:44 --> Helper loaded: url_helper
INFO - 2016-12-19 23:21:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:21:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 23:21:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-19 23:21:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-19 23:21:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-19 23:21:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:21:44 --> Final output sent to browser
DEBUG - 2016-12-19 23:21:44 --> Total execution time: 0.0195
INFO - 2016-12-19 23:21:54 --> Config Class Initialized
INFO - 2016-12-19 23:21:54 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:21:54 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:21:54 --> Utf8 Class Initialized
INFO - 2016-12-19 23:21:54 --> URI Class Initialized
INFO - 2016-12-19 23:21:54 --> Router Class Initialized
INFO - 2016-12-19 23:21:54 --> Output Class Initialized
INFO - 2016-12-19 23:21:54 --> Security Class Initialized
DEBUG - 2016-12-19 23:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:21:54 --> Input Class Initialized
INFO - 2016-12-19 23:21:54 --> Language Class Initialized
INFO - 2016-12-19 23:21:54 --> Loader Class Initialized
INFO - 2016-12-19 23:21:54 --> Database Driver Class Initialized
INFO - 2016-12-19 23:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:21:54 --> Controller Class Initialized
INFO - 2016-12-19 23:21:54 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:21:54 --> Helper loaded: url_helper
INFO - 2016-12-19 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-19 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-19 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:21:54 --> Final output sent to browser
DEBUG - 2016-12-19 23:21:54 --> Total execution time: 0.0138
INFO - 2016-12-19 23:22:09 --> Config Class Initialized
INFO - 2016-12-19 23:22:09 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:22:09 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:22:09 --> Utf8 Class Initialized
INFO - 2016-12-19 23:22:09 --> URI Class Initialized
INFO - 2016-12-19 23:22:09 --> Router Class Initialized
INFO - 2016-12-19 23:22:09 --> Output Class Initialized
INFO - 2016-12-19 23:22:09 --> Security Class Initialized
DEBUG - 2016-12-19 23:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:22:09 --> Input Class Initialized
INFO - 2016-12-19 23:22:09 --> Language Class Initialized
INFO - 2016-12-19 23:22:09 --> Loader Class Initialized
INFO - 2016-12-19 23:22:09 --> Database Driver Class Initialized
INFO - 2016-12-19 23:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:22:09 --> Controller Class Initialized
INFO - 2016-12-19 23:22:09 --> Helper loaded: date_helper
DEBUG - 2016-12-19 23:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:22:09 --> Helper loaded: url_helper
INFO - 2016-12-19 23:22:09 --> Helper loaded: download_helper
INFO - 2016-12-19 23:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-19 23:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-19 23:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-19 23:22:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:22:09 --> Final output sent to browser
DEBUG - 2016-12-19 23:22:09 --> Total execution time: 0.1978
INFO - 2016-12-19 23:47:47 --> Config Class Initialized
INFO - 2016-12-19 23:47:47 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:47:47 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:47:47 --> Utf8 Class Initialized
INFO - 2016-12-19 23:47:47 --> URI Class Initialized
DEBUG - 2016-12-19 23:47:47 --> No URI present. Default controller set.
INFO - 2016-12-19 23:47:47 --> Router Class Initialized
INFO - 2016-12-19 23:47:47 --> Output Class Initialized
INFO - 2016-12-19 23:47:47 --> Security Class Initialized
DEBUG - 2016-12-19 23:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:47:47 --> Input Class Initialized
INFO - 2016-12-19 23:47:47 --> Language Class Initialized
INFO - 2016-12-19 23:47:47 --> Loader Class Initialized
INFO - 2016-12-19 23:47:47 --> Database Driver Class Initialized
INFO - 2016-12-19 23:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:47:48 --> Controller Class Initialized
INFO - 2016-12-19 23:47:48 --> Helper loaded: url_helper
DEBUG - 2016-12-19 23:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:47:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:47:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 23:47:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 23:47:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:47:48 --> Final output sent to browser
DEBUG - 2016-12-19 23:47:48 --> Total execution time: 1.4825
INFO - 2016-12-19 23:48:22 --> Config Class Initialized
INFO - 2016-12-19 23:48:22 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:48:22 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:48:22 --> Utf8 Class Initialized
INFO - 2016-12-19 23:48:22 --> URI Class Initialized
DEBUG - 2016-12-19 23:48:22 --> No URI present. Default controller set.
INFO - 2016-12-19 23:48:22 --> Router Class Initialized
INFO - 2016-12-19 23:48:22 --> Output Class Initialized
INFO - 2016-12-19 23:48:22 --> Security Class Initialized
DEBUG - 2016-12-19 23:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:48:22 --> Input Class Initialized
INFO - 2016-12-19 23:48:22 --> Language Class Initialized
INFO - 2016-12-19 23:48:22 --> Loader Class Initialized
INFO - 2016-12-19 23:48:22 --> Database Driver Class Initialized
INFO - 2016-12-19 23:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:48:22 --> Controller Class Initialized
INFO - 2016-12-19 23:48:22 --> Helper loaded: url_helper
DEBUG - 2016-12-19 23:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 23:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 23:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:48:22 --> Final output sent to browser
DEBUG - 2016-12-19 23:48:22 --> Total execution time: 0.0447
INFO - 2016-12-19 23:48:24 --> Config Class Initialized
INFO - 2016-12-19 23:48:24 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:48:24 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:48:24 --> Utf8 Class Initialized
INFO - 2016-12-19 23:48:24 --> URI Class Initialized
INFO - 2016-12-19 23:48:24 --> Router Class Initialized
INFO - 2016-12-19 23:48:24 --> Output Class Initialized
INFO - 2016-12-19 23:48:24 --> Security Class Initialized
DEBUG - 2016-12-19 23:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:48:24 --> Input Class Initialized
INFO - 2016-12-19 23:48:24 --> Language Class Initialized
INFO - 2016-12-19 23:48:24 --> Loader Class Initialized
INFO - 2016-12-19 23:48:24 --> Database Driver Class Initialized
INFO - 2016-12-19 23:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:48:24 --> Controller Class Initialized
INFO - 2016-12-19 23:48:24 --> Helper loaded: url_helper
DEBUG - 2016-12-19 23:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 23:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 23:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:48:24 --> Final output sent to browser
DEBUG - 2016-12-19 23:48:24 --> Total execution time: 0.0143
INFO - 2016-12-19 23:48:36 --> Config Class Initialized
INFO - 2016-12-19 23:48:36 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:48:36 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:48:36 --> Utf8 Class Initialized
INFO - 2016-12-19 23:48:36 --> URI Class Initialized
DEBUG - 2016-12-19 23:48:36 --> No URI present. Default controller set.
INFO - 2016-12-19 23:48:36 --> Router Class Initialized
INFO - 2016-12-19 23:48:36 --> Output Class Initialized
INFO - 2016-12-19 23:48:36 --> Security Class Initialized
DEBUG - 2016-12-19 23:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:48:36 --> Input Class Initialized
INFO - 2016-12-19 23:48:36 --> Language Class Initialized
INFO - 2016-12-19 23:48:36 --> Loader Class Initialized
INFO - 2016-12-19 23:48:36 --> Database Driver Class Initialized
INFO - 2016-12-19 23:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:48:36 --> Controller Class Initialized
INFO - 2016-12-19 23:48:36 --> Helper loaded: url_helper
DEBUG - 2016-12-19 23:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:48:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:48:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 23:48:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 23:48:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:48:36 --> Final output sent to browser
DEBUG - 2016-12-19 23:48:36 --> Total execution time: 0.0196
INFO - 2016-12-19 23:48:37 --> Config Class Initialized
INFO - 2016-12-19 23:48:37 --> Hooks Class Initialized
DEBUG - 2016-12-19 23:48:37 --> UTF-8 Support Enabled
INFO - 2016-12-19 23:48:37 --> Utf8 Class Initialized
INFO - 2016-12-19 23:48:37 --> URI Class Initialized
INFO - 2016-12-19 23:48:37 --> Router Class Initialized
INFO - 2016-12-19 23:48:37 --> Output Class Initialized
INFO - 2016-12-19 23:48:37 --> Security Class Initialized
DEBUG - 2016-12-19 23:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-19 23:48:37 --> Input Class Initialized
INFO - 2016-12-19 23:48:37 --> Language Class Initialized
INFO - 2016-12-19 23:48:37 --> Loader Class Initialized
INFO - 2016-12-19 23:48:37 --> Database Driver Class Initialized
INFO - 2016-12-19 23:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-19 23:48:37 --> Controller Class Initialized
INFO - 2016-12-19 23:48:37 --> Helper loaded: url_helper
DEBUG - 2016-12-19 23:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-19 23:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-19 23:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-19 23:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-19 23:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-19 23:48:37 --> Final output sent to browser
DEBUG - 2016-12-19 23:48:37 --> Total execution time: 0.0143

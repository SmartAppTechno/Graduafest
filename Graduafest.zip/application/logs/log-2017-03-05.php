<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-05 01:32:00 --> Config Class Initialized
INFO - 2017-03-05 01:32:00 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:32:00 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:32:00 --> Utf8 Class Initialized
INFO - 2017-03-05 01:32:00 --> URI Class Initialized
DEBUG - 2017-03-05 01:32:00 --> No URI present. Default controller set.
INFO - 2017-03-05 01:32:00 --> Router Class Initialized
INFO - 2017-03-05 01:32:01 --> Output Class Initialized
INFO - 2017-03-05 01:32:01 --> Security Class Initialized
DEBUG - 2017-03-05 01:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:32:01 --> Input Class Initialized
INFO - 2017-03-05 01:32:01 --> Language Class Initialized
INFO - 2017-03-05 01:32:01 --> Loader Class Initialized
INFO - 2017-03-05 01:32:01 --> Database Driver Class Initialized
INFO - 2017-03-05 01:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:32:01 --> Controller Class Initialized
INFO - 2017-03-05 01:32:01 --> Helper loaded: url_helper
DEBUG - 2017-03-05 01:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 01:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 01:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 01:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 01:32:02 --> Final output sent to browser
DEBUG - 2017-03-05 01:32:02 --> Total execution time: 2.2459
INFO - 2017-03-05 01:33:15 --> Config Class Initialized
INFO - 2017-03-05 01:33:15 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:33:15 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:33:15 --> Utf8 Class Initialized
INFO - 2017-03-05 01:33:15 --> URI Class Initialized
INFO - 2017-03-05 01:33:15 --> Router Class Initialized
INFO - 2017-03-05 01:33:15 --> Output Class Initialized
INFO - 2017-03-05 01:33:15 --> Security Class Initialized
DEBUG - 2017-03-05 01:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:33:15 --> Input Class Initialized
INFO - 2017-03-05 01:33:15 --> Language Class Initialized
INFO - 2017-03-05 01:33:15 --> Loader Class Initialized
INFO - 2017-03-05 01:33:15 --> Database Driver Class Initialized
INFO - 2017-03-05 01:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:33:15 --> Controller Class Initialized
INFO - 2017-03-05 01:33:15 --> Helper loaded: url_helper
DEBUG - 2017-03-05 01:33:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:33:16 --> Config Class Initialized
INFO - 2017-03-05 01:33:16 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:33:16 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:33:16 --> Utf8 Class Initialized
INFO - 2017-03-05 01:33:16 --> URI Class Initialized
INFO - 2017-03-05 01:33:16 --> Router Class Initialized
INFO - 2017-03-05 01:33:16 --> Output Class Initialized
INFO - 2017-03-05 01:33:16 --> Security Class Initialized
DEBUG - 2017-03-05 01:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:33:16 --> Input Class Initialized
INFO - 2017-03-05 01:33:16 --> Language Class Initialized
INFO - 2017-03-05 01:33:16 --> Loader Class Initialized
INFO - 2017-03-05 01:33:16 --> Database Driver Class Initialized
INFO - 2017-03-05 01:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:33:16 --> Controller Class Initialized
INFO - 2017-03-05 01:33:16 --> Helper loaded: date_helper
DEBUG - 2017-03-05 01:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:33:16 --> Helper loaded: url_helper
INFO - 2017-03-05 01:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 01:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-05 01:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-05 01:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 01:33:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 01:33:16 --> Final output sent to browser
DEBUG - 2017-03-05 01:33:16 --> Total execution time: 0.4212
INFO - 2017-03-05 01:36:04 --> Config Class Initialized
INFO - 2017-03-05 01:36:04 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:36:04 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:36:04 --> Utf8 Class Initialized
INFO - 2017-03-05 01:36:04 --> URI Class Initialized
INFO - 2017-03-05 01:36:04 --> Router Class Initialized
INFO - 2017-03-05 01:36:04 --> Output Class Initialized
INFO - 2017-03-05 01:36:04 --> Security Class Initialized
DEBUG - 2017-03-05 01:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:36:04 --> Input Class Initialized
INFO - 2017-03-05 01:36:04 --> Language Class Initialized
INFO - 2017-03-05 01:36:05 --> Loader Class Initialized
INFO - 2017-03-05 01:36:05 --> Database Driver Class Initialized
INFO - 2017-03-05 01:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:36:05 --> Controller Class Initialized
INFO - 2017-03-05 01:36:05 --> Helper loaded: date_helper
DEBUG - 2017-03-05 01:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:36:06 --> Helper loaded: url_helper
INFO - 2017-03-05 01:36:06 --> Helper loaded: download_helper
INFO - 2017-03-05 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-05 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-05 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-05 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 01:36:06 --> Final output sent to browser
DEBUG - 2017-03-05 01:36:06 --> Total execution time: 2.1959
INFO - 2017-03-05 01:37:13 --> Config Class Initialized
INFO - 2017-03-05 01:37:13 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:37:13 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:37:13 --> Utf8 Class Initialized
INFO - 2017-03-05 01:37:13 --> URI Class Initialized
INFO - 2017-03-05 01:37:13 --> Router Class Initialized
INFO - 2017-03-05 01:37:13 --> Output Class Initialized
INFO - 2017-03-05 01:37:13 --> Security Class Initialized
DEBUG - 2017-03-05 01:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:37:13 --> Input Class Initialized
INFO - 2017-03-05 01:37:13 --> Language Class Initialized
INFO - 2017-03-05 01:37:13 --> Loader Class Initialized
INFO - 2017-03-05 01:37:14 --> Database Driver Class Initialized
INFO - 2017-03-05 01:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:37:14 --> Controller Class Initialized
INFO - 2017-03-05 01:37:14 --> Upload Class Initialized
INFO - 2017-03-05 01:37:14 --> Helper loaded: date_helper
DEBUG - 2017-03-05 01:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:37:15 --> Helper loaded: url_helper
INFO - 2017-03-05 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-05 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-05 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-05 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-05 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 01:37:15 --> Final output sent to browser
DEBUG - 2017-03-05 01:37:15 --> Total execution time: 2.2260
INFO - 2017-03-05 01:37:48 --> Config Class Initialized
INFO - 2017-03-05 01:37:48 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:37:48 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:37:48 --> Utf8 Class Initialized
INFO - 2017-03-05 01:37:48 --> URI Class Initialized
INFO - 2017-03-05 01:37:48 --> Router Class Initialized
INFO - 2017-03-05 01:37:49 --> Output Class Initialized
INFO - 2017-03-05 01:37:49 --> Security Class Initialized
DEBUG - 2017-03-05 01:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:37:49 --> Input Class Initialized
INFO - 2017-03-05 01:37:49 --> Language Class Initialized
INFO - 2017-03-05 01:37:49 --> Loader Class Initialized
INFO - 2017-03-05 01:37:49 --> Database Driver Class Initialized
INFO - 2017-03-05 01:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:37:49 --> Controller Class Initialized
INFO - 2017-03-05 01:37:49 --> Helper loaded: date_helper
DEBUG - 2017-03-05 01:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:37:49 --> Helper loaded: url_helper
INFO - 2017-03-05 01:37:49 --> Helper loaded: download_helper
INFO - 2017-03-05 01:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 01:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-05 01:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-05 01:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-05 01:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 01:37:49 --> Final output sent to browser
DEBUG - 2017-03-05 01:37:49 --> Total execution time: 1.1566
INFO - 2017-03-05 01:37:59 --> Config Class Initialized
INFO - 2017-03-05 01:37:59 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:37:59 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:37:59 --> Utf8 Class Initialized
INFO - 2017-03-05 01:37:59 --> URI Class Initialized
INFO - 2017-03-05 01:38:00 --> Router Class Initialized
INFO - 2017-03-05 01:38:00 --> Output Class Initialized
INFO - 2017-03-05 01:38:00 --> Security Class Initialized
DEBUG - 2017-03-05 01:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:38:00 --> Input Class Initialized
INFO - 2017-03-05 01:38:00 --> Language Class Initialized
INFO - 2017-03-05 01:38:00 --> Loader Class Initialized
INFO - 2017-03-05 01:38:00 --> Database Driver Class Initialized
INFO - 2017-03-05 01:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:38:00 --> Controller Class Initialized
INFO - 2017-03-05 01:38:00 --> Helper loaded: date_helper
INFO - 2017-03-05 01:38:01 --> Helper loaded: url_helper
DEBUG - 2017-03-05 01:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:38:01 --> Helper loaded: form_helper
INFO - 2017-03-05 01:38:01 --> Form Validation Class Initialized
INFO - 2017-03-05 01:38:01 --> Final output sent to browser
DEBUG - 2017-03-05 01:38:01 --> Total execution time: 1.7008
INFO - 2017-03-05 01:38:06 --> Config Class Initialized
INFO - 2017-03-05 01:38:06 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:38:06 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:38:06 --> Utf8 Class Initialized
INFO - 2017-03-05 01:38:06 --> URI Class Initialized
INFO - 2017-03-05 01:38:06 --> Router Class Initialized
INFO - 2017-03-05 01:38:06 --> Output Class Initialized
INFO - 2017-03-05 01:38:06 --> Security Class Initialized
DEBUG - 2017-03-05 01:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:38:07 --> Input Class Initialized
INFO - 2017-03-05 01:38:07 --> Language Class Initialized
INFO - 2017-03-05 01:38:07 --> Loader Class Initialized
INFO - 2017-03-05 01:38:07 --> Database Driver Class Initialized
INFO - 2017-03-05 01:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:38:07 --> Controller Class Initialized
INFO - 2017-03-05 01:38:07 --> Upload Class Initialized
INFO - 2017-03-05 01:38:07 --> Helper loaded: date_helper
DEBUG - 2017-03-05 01:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:38:07 --> Helper loaded: url_helper
INFO - 2017-03-05 01:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 01:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-05 01:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-05 01:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-05 01:38:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-05 01:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 01:38:07 --> Final output sent to browser
DEBUG - 2017-03-05 01:38:07 --> Total execution time: 1.2157
INFO - 2017-03-05 01:38:27 --> Config Class Initialized
INFO - 2017-03-05 01:38:27 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:38:27 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:38:27 --> Utf8 Class Initialized
INFO - 2017-03-05 01:38:27 --> URI Class Initialized
INFO - 2017-03-05 01:38:27 --> Router Class Initialized
INFO - 2017-03-05 01:38:27 --> Output Class Initialized
INFO - 2017-03-05 01:38:27 --> Security Class Initialized
DEBUG - 2017-03-05 01:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:38:27 --> Input Class Initialized
INFO - 2017-03-05 01:38:27 --> Language Class Initialized
INFO - 2017-03-05 01:38:27 --> Loader Class Initialized
INFO - 2017-03-05 01:38:28 --> Database Driver Class Initialized
INFO - 2017-03-05 01:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:38:28 --> Controller Class Initialized
INFO - 2017-03-05 01:38:28 --> Helper loaded: url_helper
DEBUG - 2017-03-05 01:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:38:29 --> Config Class Initialized
INFO - 2017-03-05 01:38:29 --> Hooks Class Initialized
DEBUG - 2017-03-05 01:38:29 --> UTF-8 Support Enabled
INFO - 2017-03-05 01:38:29 --> Utf8 Class Initialized
INFO - 2017-03-05 01:38:29 --> URI Class Initialized
DEBUG - 2017-03-05 01:38:29 --> No URI present. Default controller set.
INFO - 2017-03-05 01:38:29 --> Router Class Initialized
INFO - 2017-03-05 01:38:29 --> Output Class Initialized
INFO - 2017-03-05 01:38:29 --> Security Class Initialized
DEBUG - 2017-03-05 01:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 01:38:29 --> Input Class Initialized
INFO - 2017-03-05 01:38:29 --> Language Class Initialized
INFO - 2017-03-05 01:38:29 --> Loader Class Initialized
INFO - 2017-03-05 01:38:29 --> Database Driver Class Initialized
INFO - 2017-03-05 01:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 01:38:29 --> Controller Class Initialized
INFO - 2017-03-05 01:38:29 --> Helper loaded: url_helper
DEBUG - 2017-03-05 01:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 01:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 01:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 01:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 01:38:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 01:38:29 --> Final output sent to browser
DEBUG - 2017-03-05 01:38:29 --> Total execution time: 0.2254
INFO - 2017-03-05 02:42:44 --> Config Class Initialized
INFO - 2017-03-05 02:42:44 --> Hooks Class Initialized
DEBUG - 2017-03-05 02:42:44 --> UTF-8 Support Enabled
INFO - 2017-03-05 02:42:44 --> Utf8 Class Initialized
INFO - 2017-03-05 02:42:44 --> URI Class Initialized
DEBUG - 2017-03-05 02:42:44 --> No URI present. Default controller set.
INFO - 2017-03-05 02:42:44 --> Router Class Initialized
INFO - 2017-03-05 02:42:45 --> Output Class Initialized
INFO - 2017-03-05 02:42:45 --> Security Class Initialized
DEBUG - 2017-03-05 02:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 02:42:45 --> Input Class Initialized
INFO - 2017-03-05 02:42:45 --> Language Class Initialized
INFO - 2017-03-05 02:42:45 --> Loader Class Initialized
INFO - 2017-03-05 02:42:45 --> Database Driver Class Initialized
INFO - 2017-03-05 02:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 02:42:45 --> Controller Class Initialized
INFO - 2017-03-05 02:42:45 --> Helper loaded: url_helper
DEBUG - 2017-03-05 02:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 02:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 02:42:46 --> Final output sent to browser
DEBUG - 2017-03-05 02:42:46 --> Total execution time: 1.5329
INFO - 2017-03-05 02:43:01 --> Config Class Initialized
INFO - 2017-03-05 02:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-05 02:43:02 --> UTF-8 Support Enabled
INFO - 2017-03-05 02:43:02 --> Utf8 Class Initialized
INFO - 2017-03-05 02:43:02 --> URI Class Initialized
INFO - 2017-03-05 02:43:02 --> Router Class Initialized
INFO - 2017-03-05 02:43:02 --> Output Class Initialized
INFO - 2017-03-05 02:43:02 --> Security Class Initialized
DEBUG - 2017-03-05 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 02:43:02 --> Input Class Initialized
INFO - 2017-03-05 02:43:02 --> Language Class Initialized
INFO - 2017-03-05 02:43:02 --> Loader Class Initialized
INFO - 2017-03-05 02:43:02 --> Database Driver Class Initialized
INFO - 2017-03-05 02:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 02:43:02 --> Controller Class Initialized
INFO - 2017-03-05 02:43:02 --> Helper loaded: url_helper
DEBUG - 2017-03-05 02:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 02:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 02:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 02:43:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 02:43:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 02:43:03 --> Final output sent to browser
DEBUG - 2017-03-05 02:43:03 --> Total execution time: 1.2503
INFO - 2017-03-05 02:43:38 --> Config Class Initialized
INFO - 2017-03-05 02:43:38 --> Hooks Class Initialized
DEBUG - 2017-03-05 02:43:38 --> UTF-8 Support Enabled
INFO - 2017-03-05 02:43:38 --> Utf8 Class Initialized
INFO - 2017-03-05 02:43:38 --> URI Class Initialized
INFO - 2017-03-05 02:43:38 --> Router Class Initialized
INFO - 2017-03-05 02:43:38 --> Output Class Initialized
INFO - 2017-03-05 02:43:38 --> Security Class Initialized
DEBUG - 2017-03-05 02:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 02:43:38 --> Input Class Initialized
INFO - 2017-03-05 02:43:38 --> Language Class Initialized
INFO - 2017-03-05 02:43:38 --> Loader Class Initialized
INFO - 2017-03-05 02:43:39 --> Database Driver Class Initialized
INFO - 2017-03-05 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 02:43:39 --> Controller Class Initialized
INFO - 2017-03-05 02:43:39 --> Helper loaded: url_helper
DEBUG - 2017-03-05 02:43:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-05 02:43:41 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-05 02:43:41 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-05 02:43:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-05 02:43:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-05 02:43:42 --> Config Class Initialized
INFO - 2017-03-05 02:43:42 --> Hooks Class Initialized
DEBUG - 2017-03-05 02:43:42 --> UTF-8 Support Enabled
INFO - 2017-03-05 02:43:42 --> Utf8 Class Initialized
INFO - 2017-03-05 02:43:42 --> URI Class Initialized
INFO - 2017-03-05 02:43:42 --> Router Class Initialized
INFO - 2017-03-05 02:43:42 --> Output Class Initialized
INFO - 2017-03-05 02:43:42 --> Security Class Initialized
DEBUG - 2017-03-05 02:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 02:43:42 --> Input Class Initialized
INFO - 2017-03-05 02:43:42 --> Language Class Initialized
INFO - 2017-03-05 02:43:42 --> Loader Class Initialized
INFO - 2017-03-05 02:43:43 --> Database Driver Class Initialized
INFO - 2017-03-05 02:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 02:43:43 --> Controller Class Initialized
INFO - 2017-03-05 02:43:43 --> Helper loaded: url_helper
DEBUG - 2017-03-05 02:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 02:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 02:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 02:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 02:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 02:43:43 --> Final output sent to browser
DEBUG - 2017-03-05 02:43:43 --> Total execution time: 1.1760
INFO - 2017-03-05 02:43:58 --> Config Class Initialized
INFO - 2017-03-05 02:43:58 --> Hooks Class Initialized
DEBUG - 2017-03-05 02:43:58 --> UTF-8 Support Enabled
INFO - 2017-03-05 02:43:58 --> Utf8 Class Initialized
INFO - 2017-03-05 02:43:58 --> URI Class Initialized
INFO - 2017-03-05 02:43:58 --> Router Class Initialized
INFO - 2017-03-05 02:43:59 --> Output Class Initialized
INFO - 2017-03-05 02:43:59 --> Security Class Initialized
DEBUG - 2017-03-05 02:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 02:43:59 --> Input Class Initialized
INFO - 2017-03-05 02:43:59 --> Language Class Initialized
INFO - 2017-03-05 02:43:59 --> Loader Class Initialized
INFO - 2017-03-05 02:43:59 --> Database Driver Class Initialized
INFO - 2017-03-05 02:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 02:43:59 --> Controller Class Initialized
INFO - 2017-03-05 02:43:59 --> Helper loaded: url_helper
DEBUG - 2017-03-05 02:43:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-05 02:44:00 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-05 02:44:00 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-05 02:44:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-05 02:44:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-05 02:44:01 --> Config Class Initialized
INFO - 2017-03-05 02:44:01 --> Hooks Class Initialized
DEBUG - 2017-03-05 02:44:01 --> UTF-8 Support Enabled
INFO - 2017-03-05 02:44:01 --> Utf8 Class Initialized
INFO - 2017-03-05 02:44:01 --> URI Class Initialized
INFO - 2017-03-05 02:44:01 --> Router Class Initialized
INFO - 2017-03-05 02:44:01 --> Output Class Initialized
INFO - 2017-03-05 02:44:01 --> Security Class Initialized
DEBUG - 2017-03-05 02:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 02:44:01 --> Input Class Initialized
INFO - 2017-03-05 02:44:01 --> Language Class Initialized
INFO - 2017-03-05 02:44:01 --> Loader Class Initialized
INFO - 2017-03-05 02:44:01 --> Database Driver Class Initialized
INFO - 2017-03-05 02:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 02:44:01 --> Controller Class Initialized
INFO - 2017-03-05 02:44:01 --> Helper loaded: url_helper
DEBUG - 2017-03-05 02:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 02:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 02:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 02:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 02:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 02:44:01 --> Final output sent to browser
DEBUG - 2017-03-05 02:44:01 --> Total execution time: 0.0256
INFO - 2017-03-05 03:06:35 --> Config Class Initialized
INFO - 2017-03-05 03:06:35 --> Hooks Class Initialized
DEBUG - 2017-03-05 03:06:35 --> UTF-8 Support Enabled
INFO - 2017-03-05 03:06:35 --> Utf8 Class Initialized
INFO - 2017-03-05 03:06:35 --> URI Class Initialized
DEBUG - 2017-03-05 03:06:35 --> No URI present. Default controller set.
INFO - 2017-03-05 03:06:35 --> Router Class Initialized
INFO - 2017-03-05 03:06:35 --> Output Class Initialized
INFO - 2017-03-05 03:06:35 --> Security Class Initialized
DEBUG - 2017-03-05 03:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 03:06:35 --> Input Class Initialized
INFO - 2017-03-05 03:06:35 --> Language Class Initialized
INFO - 2017-03-05 03:06:35 --> Loader Class Initialized
INFO - 2017-03-05 03:06:36 --> Database Driver Class Initialized
INFO - 2017-03-05 03:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 03:06:36 --> Controller Class Initialized
INFO - 2017-03-05 03:06:36 --> Helper loaded: url_helper
DEBUG - 2017-03-05 03:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 03:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 03:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 03:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 03:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 03:06:36 --> Final output sent to browser
DEBUG - 2017-03-05 03:06:36 --> Total execution time: 1.5393
INFO - 2017-03-05 03:06:41 --> Config Class Initialized
INFO - 2017-03-05 03:06:41 --> Hooks Class Initialized
DEBUG - 2017-03-05 03:06:41 --> UTF-8 Support Enabled
INFO - 2017-03-05 03:06:41 --> Utf8 Class Initialized
INFO - 2017-03-05 03:06:41 --> URI Class Initialized
INFO - 2017-03-05 03:06:41 --> Router Class Initialized
INFO - 2017-03-05 03:06:41 --> Output Class Initialized
INFO - 2017-03-05 03:06:41 --> Security Class Initialized
DEBUG - 2017-03-05 03:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 03:06:41 --> Input Class Initialized
INFO - 2017-03-05 03:06:41 --> Language Class Initialized
INFO - 2017-03-05 03:06:41 --> Loader Class Initialized
INFO - 2017-03-05 03:06:41 --> Database Driver Class Initialized
INFO - 2017-03-05 03:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 03:06:41 --> Controller Class Initialized
INFO - 2017-03-05 03:06:41 --> Helper loaded: url_helper
DEBUG - 2017-03-05 03:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 03:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 03:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 03:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 03:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 03:06:41 --> Final output sent to browser
DEBUG - 2017-03-05 03:06:41 --> Total execution time: 0.0143
INFO - 2017-03-05 03:06:47 --> Config Class Initialized
INFO - 2017-03-05 03:06:47 --> Hooks Class Initialized
DEBUG - 2017-03-05 03:06:47 --> UTF-8 Support Enabled
INFO - 2017-03-05 03:06:47 --> Utf8 Class Initialized
INFO - 2017-03-05 03:06:47 --> URI Class Initialized
INFO - 2017-03-05 03:06:47 --> Router Class Initialized
INFO - 2017-03-05 03:06:47 --> Output Class Initialized
INFO - 2017-03-05 03:06:47 --> Security Class Initialized
DEBUG - 2017-03-05 03:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 03:06:47 --> Input Class Initialized
INFO - 2017-03-05 03:06:47 --> Language Class Initialized
INFO - 2017-03-05 03:06:47 --> Loader Class Initialized
INFO - 2017-03-05 03:06:48 --> Database Driver Class Initialized
INFO - 2017-03-05 03:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 03:06:48 --> Controller Class Initialized
INFO - 2017-03-05 03:06:48 --> Helper loaded: url_helper
DEBUG - 2017-03-05 03:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 03:06:49 --> Config Class Initialized
INFO - 2017-03-05 03:06:49 --> Hooks Class Initialized
DEBUG - 2017-03-05 03:06:49 --> UTF-8 Support Enabled
INFO - 2017-03-05 03:06:49 --> Utf8 Class Initialized
INFO - 2017-03-05 03:06:49 --> URI Class Initialized
INFO - 2017-03-05 03:06:49 --> Router Class Initialized
INFO - 2017-03-05 03:06:49 --> Output Class Initialized
INFO - 2017-03-05 03:06:49 --> Security Class Initialized
DEBUG - 2017-03-05 03:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 03:06:49 --> Input Class Initialized
INFO - 2017-03-05 03:06:49 --> Language Class Initialized
INFO - 2017-03-05 03:06:49 --> Loader Class Initialized
INFO - 2017-03-05 03:06:49 --> Database Driver Class Initialized
INFO - 2017-03-05 03:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 03:06:49 --> Controller Class Initialized
INFO - 2017-03-05 03:06:49 --> Helper loaded: date_helper
DEBUG - 2017-03-05 03:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 03:06:49 --> Helper loaded: url_helper
INFO - 2017-03-05 03:06:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 03:06:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 03:06:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 03:06:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 03:06:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 03:06:49 --> Final output sent to browser
DEBUG - 2017-03-05 03:06:49 --> Total execution time: 0.1220
INFO - 2017-03-05 03:06:50 --> Config Class Initialized
INFO - 2017-03-05 03:06:50 --> Hooks Class Initialized
DEBUG - 2017-03-05 03:06:50 --> UTF-8 Support Enabled
INFO - 2017-03-05 03:06:50 --> Utf8 Class Initialized
INFO - 2017-03-05 03:06:50 --> URI Class Initialized
INFO - 2017-03-05 03:06:50 --> Router Class Initialized
INFO - 2017-03-05 03:06:50 --> Output Class Initialized
INFO - 2017-03-05 03:06:50 --> Security Class Initialized
DEBUG - 2017-03-05 03:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 03:06:50 --> Input Class Initialized
INFO - 2017-03-05 03:06:50 --> Language Class Initialized
INFO - 2017-03-05 03:06:50 --> Loader Class Initialized
INFO - 2017-03-05 03:06:50 --> Database Driver Class Initialized
INFO - 2017-03-05 03:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 03:06:50 --> Controller Class Initialized
INFO - 2017-03-05 03:06:50 --> Helper loaded: url_helper
DEBUG - 2017-03-05 03:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 03:06:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 03:06:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 03:06:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 03:06:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 03:06:50 --> Final output sent to browser
DEBUG - 2017-03-05 03:06:50 --> Total execution time: 0.0297
INFO - 2017-03-05 05:19:04 --> Config Class Initialized
INFO - 2017-03-05 05:19:04 --> Hooks Class Initialized
DEBUG - 2017-03-05 05:19:05 --> UTF-8 Support Enabled
INFO - 2017-03-05 05:19:05 --> Utf8 Class Initialized
INFO - 2017-03-05 05:19:05 --> URI Class Initialized
DEBUG - 2017-03-05 05:19:05 --> No URI present. Default controller set.
INFO - 2017-03-05 05:19:05 --> Router Class Initialized
INFO - 2017-03-05 05:19:05 --> Output Class Initialized
INFO - 2017-03-05 05:19:05 --> Security Class Initialized
DEBUG - 2017-03-05 05:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 05:19:05 --> Input Class Initialized
INFO - 2017-03-05 05:19:05 --> Language Class Initialized
INFO - 2017-03-05 05:19:05 --> Loader Class Initialized
INFO - 2017-03-05 05:19:05 --> Database Driver Class Initialized
INFO - 2017-03-05 05:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 05:19:06 --> Controller Class Initialized
INFO - 2017-03-05 05:19:06 --> Helper loaded: url_helper
DEBUG - 2017-03-05 05:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 05:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 05:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 05:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 05:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 05:19:07 --> Final output sent to browser
DEBUG - 2017-03-05 05:19:07 --> Total execution time: 2.2296
INFO - 2017-03-05 14:18:41 --> Config Class Initialized
INFO - 2017-03-05 14:18:41 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:41 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:41 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:41 --> URI Class Initialized
DEBUG - 2017-03-05 14:18:41 --> No URI present. Default controller set.
INFO - 2017-03-05 14:18:41 --> Router Class Initialized
INFO - 2017-03-05 14:18:41 --> Output Class Initialized
INFO - 2017-03-05 14:18:41 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:42 --> Input Class Initialized
INFO - 2017-03-05 14:18:42 --> Language Class Initialized
INFO - 2017-03-05 14:18:42 --> Loader Class Initialized
INFO - 2017-03-05 14:18:42 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:43 --> Controller Class Initialized
INFO - 2017-03-05 14:18:43 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 14:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 14:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 14:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 14:18:43 --> Final output sent to browser
DEBUG - 2017-03-05 14:18:43 --> Total execution time: 2.0092
INFO - 2017-03-05 14:18:47 --> Config Class Initialized
INFO - 2017-03-05 14:18:47 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:47 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:47 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:47 --> URI Class Initialized
INFO - 2017-03-05 14:18:47 --> Router Class Initialized
INFO - 2017-03-05 14:18:47 --> Output Class Initialized
INFO - 2017-03-05 14:18:47 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:47 --> Input Class Initialized
INFO - 2017-03-05 14:18:47 --> Language Class Initialized
INFO - 2017-03-05 14:18:47 --> Loader Class Initialized
INFO - 2017-03-05 14:18:47 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:47 --> Controller Class Initialized
INFO - 2017-03-05 14:18:47 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 14:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 14:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 14:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 14:18:47 --> Final output sent to browser
DEBUG - 2017-03-05 14:18:47 --> Total execution time: 0.1293
INFO - 2017-03-05 14:18:51 --> Config Class Initialized
INFO - 2017-03-05 14:18:51 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:51 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:51 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:51 --> URI Class Initialized
INFO - 2017-03-05 14:18:51 --> Router Class Initialized
INFO - 2017-03-05 14:18:51 --> Output Class Initialized
INFO - 2017-03-05 14:18:51 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:51 --> Input Class Initialized
INFO - 2017-03-05 14:18:51 --> Language Class Initialized
INFO - 2017-03-05 14:18:51 --> Loader Class Initialized
INFO - 2017-03-05 14:18:51 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:51 --> Controller Class Initialized
INFO - 2017-03-05 14:18:51 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:53 --> Config Class Initialized
INFO - 2017-03-05 14:18:53 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:53 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:53 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:53 --> URI Class Initialized
INFO - 2017-03-05 14:18:54 --> Router Class Initialized
INFO - 2017-03-05 14:18:54 --> Output Class Initialized
INFO - 2017-03-05 14:18:54 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:54 --> Input Class Initialized
INFO - 2017-03-05 14:18:54 --> Language Class Initialized
INFO - 2017-03-05 14:18:54 --> Loader Class Initialized
INFO - 2017-03-05 14:18:55 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:55 --> Controller Class Initialized
INFO - 2017-03-05 14:18:55 --> Helper loaded: date_helper
DEBUG - 2017-03-05 14:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:55 --> Helper loaded: url_helper
INFO - 2017-03-05 14:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 14:18:56 --> Config Class Initialized
INFO - 2017-03-05 14:18:56 --> Config Class Initialized
INFO - 2017-03-05 14:18:56 --> Hooks Class Initialized
INFO - 2017-03-05 14:18:56 --> Hooks Class Initialized
INFO - 2017-03-05 14:18:56 --> Config Class Initialized
INFO - 2017-03-05 14:18:56 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:56 --> UTF-8 Support Enabled
DEBUG - 2017-03-05 14:18:56 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:56 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:56 --> Utf8 Class Initialized
DEBUG - 2017-03-05 14:18:56 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:56 --> URI Class Initialized
INFO - 2017-03-05 14:18:56 --> URI Class Initialized
INFO - 2017-03-05 14:18:56 --> Router Class Initialized
INFO - 2017-03-05 14:18:56 --> Router Class Initialized
INFO - 2017-03-05 14:18:56 --> Output Class Initialized
INFO - 2017-03-05 14:18:56 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:56 --> URI Class Initialized
INFO - 2017-03-05 14:18:56 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:56 --> Input Class Initialized
INFO - 2017-03-05 14:18:56 --> Router Class Initialized
INFO - 2017-03-05 14:18:56 --> Language Class Initialized
INFO - 2017-03-05 14:18:56 --> Output Class Initialized
INFO - 2017-03-05 14:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 14:18:56 --> Loader Class Initialized
INFO - 2017-03-05 14:18:56 --> Security Class Initialized
INFO - 2017-03-05 14:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
DEBUG - 2017-03-05 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:56 --> Output Class Initialized
INFO - 2017-03-05 14:18:56 --> Security Class Initialized
INFO - 2017-03-05 14:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 14:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 14:18:56 --> Final output sent to browser
DEBUG - 2017-03-05 14:18:56 --> Total execution time: 2.3156
DEBUG - 2017-03-05 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:56 --> Input Class Initialized
INFO - 2017-03-05 14:18:56 --> Language Class Initialized
INFO - 2017-03-05 14:18:56 --> Loader Class Initialized
INFO - 2017-03-05 14:18:56 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:56 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:56 --> Input Class Initialized
INFO - 2017-03-05 14:18:56 --> Language Class Initialized
INFO - 2017-03-05 14:18:56 --> Loader Class Initialized
INFO - 2017-03-05 14:18:56 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:56 --> Controller Class Initialized
INFO - 2017-03-05 14:18:56 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:56 --> Config Class Initialized
INFO - 2017-03-05 14:18:56 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:56 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:56 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:56 --> URI Class Initialized
INFO - 2017-03-05 14:18:56 --> Router Class Initialized
INFO - 2017-03-05 14:18:56 --> Output Class Initialized
INFO - 2017-03-05 14:18:56 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:56 --> Input Class Initialized
INFO - 2017-03-05 14:18:56 --> Language Class Initialized
INFO - 2017-03-05 14:18:56 --> Loader Class Initialized
INFO - 2017-03-05 14:18:56 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:57 --> Controller Class Initialized
INFO - 2017-03-05 14:18:57 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:58 --> Controller Class Initialized
INFO - 2017-03-05 14:18:58 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:58 --> Config Class Initialized
INFO - 2017-03-05 14:18:58 --> Hooks Class Initialized
INFO - 2017-03-05 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:58 --> Controller Class Initialized
DEBUG - 2017-03-05 14:18:58 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:58 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:58 --> Helper loaded: url_helper
INFO - 2017-03-05 14:18:58 --> URI Class Initialized
DEBUG - 2017-03-05 14:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:58 --> Router Class Initialized
INFO - 2017-03-05 14:18:58 --> Output Class Initialized
INFO - 2017-03-05 14:18:58 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:58 --> Input Class Initialized
INFO - 2017-03-05 14:18:58 --> Language Class Initialized
INFO - 2017-03-05 14:18:58 --> Loader Class Initialized
INFO - 2017-03-05 14:18:59 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:59 --> Controller Class Initialized
INFO - 2017-03-05 14:18:59 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:59 --> Config Class Initialized
INFO - 2017-03-05 14:18:59 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:59 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:59 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:59 --> URI Class Initialized
INFO - 2017-03-05 14:18:59 --> Router Class Initialized
INFO - 2017-03-05 14:18:59 --> Output Class Initialized
INFO - 2017-03-05 14:18:59 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:59 --> Input Class Initialized
INFO - 2017-03-05 14:18:59 --> Language Class Initialized
INFO - 2017-03-05 14:18:59 --> Loader Class Initialized
INFO - 2017-03-05 14:18:59 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:59 --> Controller Class Initialized
INFO - 2017-03-05 14:18:59 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:18:59 --> Config Class Initialized
INFO - 2017-03-05 14:18:59 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:18:59 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:18:59 --> Utf8 Class Initialized
INFO - 2017-03-05 14:18:59 --> URI Class Initialized
INFO - 2017-03-05 14:18:59 --> Router Class Initialized
INFO - 2017-03-05 14:18:59 --> Output Class Initialized
INFO - 2017-03-05 14:18:59 --> Security Class Initialized
DEBUG - 2017-03-05 14:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:18:59 --> Input Class Initialized
INFO - 2017-03-05 14:18:59 --> Language Class Initialized
INFO - 2017-03-05 14:18:59 --> Loader Class Initialized
INFO - 2017-03-05 14:18:59 --> Database Driver Class Initialized
INFO - 2017-03-05 14:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:18:59 --> Controller Class Initialized
INFO - 2017-03-05 14:19:00 --> Helper loaded: date_helper
DEBUG - 2017-03-05 14:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:19:00 --> Helper loaded: url_helper
INFO - 2017-03-05 14:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 14:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 14:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 14:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 14:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 14:19:00 --> Final output sent to browser
DEBUG - 2017-03-05 14:19:00 --> Total execution time: 0.0519
INFO - 2017-03-05 14:19:01 --> Config Class Initialized
INFO - 2017-03-05 14:19:01 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:19:01 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:19:01 --> Utf8 Class Initialized
INFO - 2017-03-05 14:19:01 --> URI Class Initialized
INFO - 2017-03-05 14:19:01 --> Router Class Initialized
INFO - 2017-03-05 14:19:01 --> Output Class Initialized
INFO - 2017-03-05 14:19:01 --> Security Class Initialized
DEBUG - 2017-03-05 14:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:19:01 --> Input Class Initialized
INFO - 2017-03-05 14:19:01 --> Language Class Initialized
INFO - 2017-03-05 14:19:01 --> Loader Class Initialized
INFO - 2017-03-05 14:19:01 --> Database Driver Class Initialized
INFO - 2017-03-05 14:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:19:01 --> Controller Class Initialized
INFO - 2017-03-05 14:19:01 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 14:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 14:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 14:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 14:19:01 --> Final output sent to browser
DEBUG - 2017-03-05 14:19:01 --> Total execution time: 0.1337
INFO - 2017-03-05 14:19:05 --> Config Class Initialized
INFO - 2017-03-05 14:19:05 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:19:05 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:19:05 --> Utf8 Class Initialized
INFO - 2017-03-05 14:19:05 --> URI Class Initialized
DEBUG - 2017-03-05 14:19:05 --> No URI present. Default controller set.
INFO - 2017-03-05 14:19:05 --> Router Class Initialized
INFO - 2017-03-05 14:19:05 --> Output Class Initialized
INFO - 2017-03-05 14:19:05 --> Security Class Initialized
DEBUG - 2017-03-05 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:19:05 --> Input Class Initialized
INFO - 2017-03-05 14:19:05 --> Language Class Initialized
INFO - 2017-03-05 14:19:06 --> Loader Class Initialized
INFO - 2017-03-05 14:19:06 --> Database Driver Class Initialized
INFO - 2017-03-05 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:19:06 --> Controller Class Initialized
INFO - 2017-03-05 14:19:06 --> Helper loaded: url_helper
DEBUG - 2017-03-05 14:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 14:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 14:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 14:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 14:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 14:19:06 --> Final output sent to browser
DEBUG - 2017-03-05 14:19:06 --> Total execution time: 0.8634
INFO - 2017-03-05 17:46:03 --> Config Class Initialized
INFO - 2017-03-05 17:46:03 --> Hooks Class Initialized
DEBUG - 2017-03-05 17:46:03 --> UTF-8 Support Enabled
INFO - 2017-03-05 17:46:03 --> Utf8 Class Initialized
INFO - 2017-03-05 17:46:03 --> URI Class Initialized
DEBUG - 2017-03-05 17:46:03 --> No URI present. Default controller set.
INFO - 2017-03-05 17:46:03 --> Router Class Initialized
INFO - 2017-03-05 17:46:04 --> Output Class Initialized
INFO - 2017-03-05 17:46:04 --> Security Class Initialized
DEBUG - 2017-03-05 17:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 17:46:04 --> Input Class Initialized
INFO - 2017-03-05 17:46:04 --> Language Class Initialized
INFO - 2017-03-05 17:46:04 --> Loader Class Initialized
INFO - 2017-03-05 17:46:04 --> Database Driver Class Initialized
INFO - 2017-03-05 17:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 17:46:05 --> Controller Class Initialized
INFO - 2017-03-05 17:46:05 --> Helper loaded: url_helper
DEBUG - 2017-03-05 17:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 17:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 17:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 17:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 17:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 17:46:05 --> Final output sent to browser
DEBUG - 2017-03-05 17:46:05 --> Total execution time: 1.7692
INFO - 2017-03-05 17:46:07 --> Config Class Initialized
INFO - 2017-03-05 17:46:07 --> Hooks Class Initialized
DEBUG - 2017-03-05 17:46:07 --> UTF-8 Support Enabled
INFO - 2017-03-05 17:46:07 --> Utf8 Class Initialized
INFO - 2017-03-05 17:46:07 --> URI Class Initialized
INFO - 2017-03-05 17:46:07 --> Router Class Initialized
INFO - 2017-03-05 17:46:07 --> Output Class Initialized
INFO - 2017-03-05 17:46:07 --> Security Class Initialized
DEBUG - 2017-03-05 17:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 17:46:07 --> Input Class Initialized
INFO - 2017-03-05 17:46:07 --> Language Class Initialized
INFO - 2017-03-05 17:46:07 --> Loader Class Initialized
INFO - 2017-03-05 17:46:07 --> Database Driver Class Initialized
INFO - 2017-03-05 17:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 17:46:07 --> Controller Class Initialized
INFO - 2017-03-05 17:46:07 --> Helper loaded: url_helper
DEBUG - 2017-03-05 17:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 17:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 17:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 17:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 17:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 17:46:07 --> Final output sent to browser
DEBUG - 2017-03-05 17:46:07 --> Total execution time: 0.0137
INFO - 2017-03-05 17:46:12 --> Config Class Initialized
INFO - 2017-03-05 17:46:12 --> Hooks Class Initialized
DEBUG - 2017-03-05 17:46:12 --> UTF-8 Support Enabled
INFO - 2017-03-05 17:46:12 --> Utf8 Class Initialized
INFO - 2017-03-05 17:46:12 --> URI Class Initialized
INFO - 2017-03-05 17:46:12 --> Router Class Initialized
INFO - 2017-03-05 17:46:12 --> Output Class Initialized
INFO - 2017-03-05 17:46:12 --> Security Class Initialized
DEBUG - 2017-03-05 17:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 17:46:12 --> Input Class Initialized
INFO - 2017-03-05 17:46:12 --> Language Class Initialized
INFO - 2017-03-05 17:46:12 --> Loader Class Initialized
INFO - 2017-03-05 17:46:12 --> Database Driver Class Initialized
INFO - 2017-03-05 17:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 17:46:12 --> Controller Class Initialized
INFO - 2017-03-05 17:46:12 --> Helper loaded: url_helper
DEBUG - 2017-03-05 17:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 17:46:14 --> Config Class Initialized
INFO - 2017-03-05 17:46:14 --> Hooks Class Initialized
DEBUG - 2017-03-05 17:46:14 --> UTF-8 Support Enabled
INFO - 2017-03-05 17:46:14 --> Utf8 Class Initialized
INFO - 2017-03-05 17:46:14 --> URI Class Initialized
INFO - 2017-03-05 17:46:14 --> Router Class Initialized
INFO - 2017-03-05 17:46:14 --> Output Class Initialized
INFO - 2017-03-05 17:46:14 --> Security Class Initialized
DEBUG - 2017-03-05 17:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 17:46:14 --> Input Class Initialized
INFO - 2017-03-05 17:46:14 --> Language Class Initialized
INFO - 2017-03-05 17:46:14 --> Loader Class Initialized
INFO - 2017-03-05 17:46:14 --> Database Driver Class Initialized
INFO - 2017-03-05 17:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 17:46:14 --> Controller Class Initialized
INFO - 2017-03-05 17:46:14 --> Helper loaded: date_helper
DEBUG - 2017-03-05 17:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 17:46:14 --> Helper loaded: url_helper
INFO - 2017-03-05 17:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 17:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 17:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 17:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 17:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 17:46:14 --> Final output sent to browser
DEBUG - 2017-03-05 17:46:14 --> Total execution time: 0.1128
INFO - 2017-03-05 17:46:15 --> Config Class Initialized
INFO - 2017-03-05 17:46:15 --> Hooks Class Initialized
DEBUG - 2017-03-05 17:46:15 --> UTF-8 Support Enabled
INFO - 2017-03-05 17:46:15 --> Utf8 Class Initialized
INFO - 2017-03-05 17:46:15 --> URI Class Initialized
INFO - 2017-03-05 17:46:15 --> Router Class Initialized
INFO - 2017-03-05 17:46:15 --> Output Class Initialized
INFO - 2017-03-05 17:46:15 --> Security Class Initialized
DEBUG - 2017-03-05 17:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 17:46:15 --> Input Class Initialized
INFO - 2017-03-05 17:46:15 --> Language Class Initialized
INFO - 2017-03-05 17:46:15 --> Loader Class Initialized
INFO - 2017-03-05 17:46:15 --> Database Driver Class Initialized
INFO - 2017-03-05 17:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 17:46:15 --> Controller Class Initialized
INFO - 2017-03-05 17:46:15 --> Helper loaded: url_helper
DEBUG - 2017-03-05 17:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 17:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 17:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 17:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 17:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 17:46:15 --> Final output sent to browser
DEBUG - 2017-03-05 17:46:15 --> Total execution time: 0.0146
INFO - 2017-03-05 18:22:22 --> Config Class Initialized
INFO - 2017-03-05 18:22:22 --> Hooks Class Initialized
DEBUG - 2017-03-05 18:22:22 --> UTF-8 Support Enabled
INFO - 2017-03-05 18:22:22 --> Utf8 Class Initialized
INFO - 2017-03-05 18:22:22 --> URI Class Initialized
INFO - 2017-03-05 18:22:22 --> Router Class Initialized
INFO - 2017-03-05 18:22:22 --> Output Class Initialized
INFO - 2017-03-05 18:22:22 --> Security Class Initialized
DEBUG - 2017-03-05 18:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 18:22:22 --> Input Class Initialized
INFO - 2017-03-05 18:22:22 --> Language Class Initialized
INFO - 2017-03-05 18:22:22 --> Loader Class Initialized
INFO - 2017-03-05 18:22:23 --> Database Driver Class Initialized
INFO - 2017-03-05 18:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 18:22:23 --> Controller Class Initialized
INFO - 2017-03-05 18:22:24 --> Helper loaded: date_helper
DEBUG - 2017-03-05 18:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 18:22:24 --> Helper loaded: url_helper
INFO - 2017-03-05 18:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 18:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 18:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 18:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 18:22:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 18:22:24 --> Final output sent to browser
DEBUG - 2017-03-05 18:22:24 --> Total execution time: 2.4457
INFO - 2017-03-05 18:22:27 --> Config Class Initialized
INFO - 2017-03-05 18:22:27 --> Hooks Class Initialized
DEBUG - 2017-03-05 18:22:27 --> UTF-8 Support Enabled
INFO - 2017-03-05 18:22:27 --> Utf8 Class Initialized
INFO - 2017-03-05 18:22:27 --> URI Class Initialized
INFO - 2017-03-05 18:22:27 --> Router Class Initialized
INFO - 2017-03-05 18:22:27 --> Output Class Initialized
INFO - 2017-03-05 18:22:27 --> Security Class Initialized
DEBUG - 2017-03-05 18:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 18:22:27 --> Input Class Initialized
INFO - 2017-03-05 18:22:27 --> Language Class Initialized
INFO - 2017-03-05 18:22:27 --> Loader Class Initialized
INFO - 2017-03-05 18:22:27 --> Database Driver Class Initialized
INFO - 2017-03-05 18:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 18:22:27 --> Controller Class Initialized
INFO - 2017-03-05 18:22:27 --> Helper loaded: url_helper
DEBUG - 2017-03-05 18:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 18:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 18:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 18:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 18:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 18:22:28 --> Final output sent to browser
DEBUG - 2017-03-05 18:22:28 --> Total execution time: 1.1960
INFO - 2017-03-05 18:32:38 --> Config Class Initialized
INFO - 2017-03-05 18:32:38 --> Hooks Class Initialized
DEBUG - 2017-03-05 18:32:39 --> UTF-8 Support Enabled
INFO - 2017-03-05 18:32:39 --> Utf8 Class Initialized
INFO - 2017-03-05 18:32:39 --> URI Class Initialized
DEBUG - 2017-03-05 18:32:39 --> No URI present. Default controller set.
INFO - 2017-03-05 18:32:39 --> Router Class Initialized
INFO - 2017-03-05 18:32:39 --> Output Class Initialized
INFO - 2017-03-05 18:32:39 --> Security Class Initialized
DEBUG - 2017-03-05 18:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 18:32:39 --> Input Class Initialized
INFO - 2017-03-05 18:32:39 --> Language Class Initialized
INFO - 2017-03-05 18:32:39 --> Loader Class Initialized
INFO - 2017-03-05 18:32:39 --> Database Driver Class Initialized
INFO - 2017-03-05 18:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 18:32:40 --> Controller Class Initialized
INFO - 2017-03-05 18:32:40 --> Helper loaded: url_helper
DEBUG - 2017-03-05 18:32:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 18:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 18:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 18:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 18:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 18:32:41 --> Final output sent to browser
DEBUG - 2017-03-05 18:32:41 --> Total execution time: 4.1496
INFO - 2017-03-05 18:32:54 --> Config Class Initialized
INFO - 2017-03-05 18:32:54 --> Hooks Class Initialized
DEBUG - 2017-03-05 18:32:54 --> UTF-8 Support Enabled
INFO - 2017-03-05 18:32:54 --> Utf8 Class Initialized
INFO - 2017-03-05 18:32:54 --> URI Class Initialized
INFO - 2017-03-05 18:32:54 --> Router Class Initialized
INFO - 2017-03-05 18:32:55 --> Output Class Initialized
INFO - 2017-03-05 18:32:55 --> Security Class Initialized
DEBUG - 2017-03-05 18:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 18:32:55 --> Input Class Initialized
INFO - 2017-03-05 18:32:55 --> Language Class Initialized
INFO - 2017-03-05 18:32:55 --> Loader Class Initialized
INFO - 2017-03-05 18:32:55 --> Database Driver Class Initialized
INFO - 2017-03-05 18:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 18:32:55 --> Controller Class Initialized
INFO - 2017-03-05 18:32:55 --> Helper loaded: url_helper
DEBUG - 2017-03-05 18:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 18:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 18:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 18:32:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 18:32:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 18:32:56 --> Final output sent to browser
DEBUG - 2017-03-05 18:32:56 --> Total execution time: 1.8385
INFO - 2017-03-05 19:05:34 --> Config Class Initialized
INFO - 2017-03-05 19:05:34 --> Hooks Class Initialized
DEBUG - 2017-03-05 19:05:34 --> UTF-8 Support Enabled
INFO - 2017-03-05 19:05:34 --> Utf8 Class Initialized
INFO - 2017-03-05 19:05:34 --> URI Class Initialized
DEBUG - 2017-03-05 19:05:34 --> No URI present. Default controller set.
INFO - 2017-03-05 19:05:34 --> Router Class Initialized
INFO - 2017-03-05 19:05:34 --> Output Class Initialized
INFO - 2017-03-05 19:05:34 --> Security Class Initialized
DEBUG - 2017-03-05 19:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 19:05:34 --> Input Class Initialized
INFO - 2017-03-05 19:05:34 --> Language Class Initialized
INFO - 2017-03-05 19:05:34 --> Loader Class Initialized
INFO - 2017-03-05 19:05:34 --> Database Driver Class Initialized
INFO - 2017-03-05 19:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 19:05:35 --> Controller Class Initialized
INFO - 2017-03-05 19:05:35 --> Helper loaded: url_helper
DEBUG - 2017-03-05 19:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 19:05:35 --> Final output sent to browser
DEBUG - 2017-03-05 19:05:35 --> Total execution time: 1.5530
INFO - 2017-03-05 19:05:49 --> Config Class Initialized
INFO - 2017-03-05 19:05:49 --> Hooks Class Initialized
DEBUG - 2017-03-05 19:05:50 --> UTF-8 Support Enabled
INFO - 2017-03-05 19:05:50 --> Utf8 Class Initialized
INFO - 2017-03-05 19:05:50 --> URI Class Initialized
INFO - 2017-03-05 19:05:50 --> Router Class Initialized
INFO - 2017-03-05 19:05:50 --> Output Class Initialized
INFO - 2017-03-05 19:05:50 --> Security Class Initialized
DEBUG - 2017-03-05 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 19:05:50 --> Input Class Initialized
INFO - 2017-03-05 19:05:50 --> Language Class Initialized
INFO - 2017-03-05 19:05:50 --> Loader Class Initialized
INFO - 2017-03-05 19:05:50 --> Database Driver Class Initialized
INFO - 2017-03-05 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 19:05:51 --> Controller Class Initialized
INFO - 2017-03-05 19:05:51 --> Helper loaded: url_helper
DEBUG - 2017-03-05 19:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 19:05:51 --> Final output sent to browser
DEBUG - 2017-03-05 19:05:51 --> Total execution time: 1.7927
INFO - 2017-03-05 19:28:40 --> Config Class Initialized
INFO - 2017-03-05 19:28:40 --> Hooks Class Initialized
DEBUG - 2017-03-05 19:28:40 --> UTF-8 Support Enabled
INFO - 2017-03-05 19:28:40 --> Utf8 Class Initialized
INFO - 2017-03-05 19:28:40 --> URI Class Initialized
DEBUG - 2017-03-05 19:28:41 --> No URI present. Default controller set.
INFO - 2017-03-05 19:28:41 --> Router Class Initialized
INFO - 2017-03-05 19:28:41 --> Output Class Initialized
INFO - 2017-03-05 19:28:41 --> Security Class Initialized
DEBUG - 2017-03-05 19:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 19:28:41 --> Input Class Initialized
INFO - 2017-03-05 19:28:41 --> Language Class Initialized
INFO - 2017-03-05 19:28:41 --> Loader Class Initialized
INFO - 2017-03-05 19:28:41 --> Database Driver Class Initialized
INFO - 2017-03-05 19:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 19:28:41 --> Controller Class Initialized
INFO - 2017-03-05 19:28:41 --> Helper loaded: url_helper
DEBUG - 2017-03-05 19:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 19:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 19:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 19:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 19:28:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 19:28:42 --> Final output sent to browser
DEBUG - 2017-03-05 19:28:42 --> Total execution time: 1.7593
INFO - 2017-03-05 20:04:24 --> Config Class Initialized
INFO - 2017-03-05 20:04:24 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:04:24 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:04:24 --> Utf8 Class Initialized
INFO - 2017-03-05 20:04:24 --> URI Class Initialized
DEBUG - 2017-03-05 20:04:24 --> No URI present. Default controller set.
INFO - 2017-03-05 20:04:24 --> Router Class Initialized
INFO - 2017-03-05 20:04:24 --> Output Class Initialized
INFO - 2017-03-05 20:04:24 --> Security Class Initialized
DEBUG - 2017-03-05 20:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:04:24 --> Input Class Initialized
INFO - 2017-03-05 20:04:24 --> Language Class Initialized
INFO - 2017-03-05 20:04:24 --> Loader Class Initialized
INFO - 2017-03-05 20:04:25 --> Database Driver Class Initialized
INFO - 2017-03-05 20:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:04:25 --> Controller Class Initialized
INFO - 2017-03-05 20:04:25 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:04:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:04:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:04:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:04:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:04:26 --> Final output sent to browser
DEBUG - 2017-03-05 20:04:26 --> Total execution time: 2.0175
INFO - 2017-03-05 20:04:43 --> Config Class Initialized
INFO - 2017-03-05 20:04:43 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:04:43 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:04:43 --> Utf8 Class Initialized
INFO - 2017-03-05 20:04:43 --> URI Class Initialized
INFO - 2017-03-05 20:04:43 --> Router Class Initialized
INFO - 2017-03-05 20:04:43 --> Output Class Initialized
INFO - 2017-03-05 20:04:43 --> Security Class Initialized
DEBUG - 2017-03-05 20:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:04:43 --> Input Class Initialized
INFO - 2017-03-05 20:04:43 --> Language Class Initialized
INFO - 2017-03-05 20:04:43 --> Loader Class Initialized
INFO - 2017-03-05 20:04:43 --> Database Driver Class Initialized
INFO - 2017-03-05 20:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:04:44 --> Controller Class Initialized
INFO - 2017-03-05 20:04:44 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:04:44 --> Final output sent to browser
DEBUG - 2017-03-05 20:04:44 --> Total execution time: 1.8043
INFO - 2017-03-05 20:04:54 --> Config Class Initialized
INFO - 2017-03-05 20:04:54 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:04:54 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:04:54 --> Utf8 Class Initialized
INFO - 2017-03-05 20:04:55 --> URI Class Initialized
DEBUG - 2017-03-05 20:04:55 --> No URI present. Default controller set.
INFO - 2017-03-05 20:04:55 --> Router Class Initialized
INFO - 2017-03-05 20:04:55 --> Output Class Initialized
INFO - 2017-03-05 20:04:55 --> Security Class Initialized
DEBUG - 2017-03-05 20:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:04:55 --> Input Class Initialized
INFO - 2017-03-05 20:04:55 --> Language Class Initialized
INFO - 2017-03-05 20:04:55 --> Loader Class Initialized
INFO - 2017-03-05 20:04:55 --> Database Driver Class Initialized
INFO - 2017-03-05 20:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:04:56 --> Controller Class Initialized
INFO - 2017-03-05 20:04:56 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:04:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:04:56 --> Final output sent to browser
DEBUG - 2017-03-05 20:04:56 --> Total execution time: 1.8288
INFO - 2017-03-05 20:05:04 --> Config Class Initialized
INFO - 2017-03-05 20:05:04 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:05:04 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:05:04 --> Utf8 Class Initialized
INFO - 2017-03-05 20:05:04 --> URI Class Initialized
INFO - 2017-03-05 20:05:04 --> Router Class Initialized
INFO - 2017-03-05 20:05:04 --> Output Class Initialized
INFO - 2017-03-05 20:05:04 --> Security Class Initialized
DEBUG - 2017-03-05 20:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:05:04 --> Input Class Initialized
INFO - 2017-03-05 20:05:04 --> Language Class Initialized
INFO - 2017-03-05 20:05:04 --> Loader Class Initialized
INFO - 2017-03-05 20:05:05 --> Database Driver Class Initialized
INFO - 2017-03-05 20:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:05:05 --> Controller Class Initialized
INFO - 2017-03-05 20:05:05 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:05:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:05:05 --> Final output sent to browser
DEBUG - 2017-03-05 20:05:05 --> Total execution time: 1.5044
INFO - 2017-03-05 20:05:11 --> Config Class Initialized
INFO - 2017-03-05 20:05:11 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:05:11 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:05:11 --> Utf8 Class Initialized
INFO - 2017-03-05 20:05:11 --> URI Class Initialized
INFO - 2017-03-05 20:05:11 --> Router Class Initialized
INFO - 2017-03-05 20:05:11 --> Output Class Initialized
INFO - 2017-03-05 20:05:11 --> Security Class Initialized
DEBUG - 2017-03-05 20:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:05:11 --> Input Class Initialized
INFO - 2017-03-05 20:05:11 --> Language Class Initialized
INFO - 2017-03-05 20:05:12 --> Loader Class Initialized
INFO - 2017-03-05 20:05:12 --> Database Driver Class Initialized
INFO - 2017-03-05 20:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:05:12 --> Controller Class Initialized
INFO - 2017-03-05 20:05:12 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:05:15 --> Config Class Initialized
INFO - 2017-03-05 20:05:15 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:05:15 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:05:15 --> Utf8 Class Initialized
INFO - 2017-03-05 20:05:15 --> URI Class Initialized
INFO - 2017-03-05 20:05:15 --> Router Class Initialized
INFO - 2017-03-05 20:05:15 --> Output Class Initialized
INFO - 2017-03-05 20:05:15 --> Security Class Initialized
DEBUG - 2017-03-05 20:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:05:15 --> Input Class Initialized
INFO - 2017-03-05 20:05:15 --> Language Class Initialized
INFO - 2017-03-05 20:05:15 --> Loader Class Initialized
INFO - 2017-03-05 20:05:15 --> Database Driver Class Initialized
INFO - 2017-03-05 20:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:05:15 --> Controller Class Initialized
INFO - 2017-03-05 20:05:15 --> Helper loaded: date_helper
DEBUG - 2017-03-05 20:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:05:15 --> Helper loaded: url_helper
INFO - 2017-03-05 20:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 20:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 20:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 20:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:05:15 --> Final output sent to browser
DEBUG - 2017-03-05 20:05:15 --> Total execution time: 0.1296
INFO - 2017-03-05 20:05:18 --> Config Class Initialized
INFO - 2017-03-05 20:05:18 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:05:18 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:05:18 --> Utf8 Class Initialized
INFO - 2017-03-05 20:05:18 --> URI Class Initialized
INFO - 2017-03-05 20:05:18 --> Router Class Initialized
INFO - 2017-03-05 20:05:18 --> Output Class Initialized
INFO - 2017-03-05 20:05:18 --> Security Class Initialized
DEBUG - 2017-03-05 20:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:05:18 --> Input Class Initialized
INFO - 2017-03-05 20:05:18 --> Language Class Initialized
INFO - 2017-03-05 20:05:18 --> Loader Class Initialized
INFO - 2017-03-05 20:05:18 --> Database Driver Class Initialized
INFO - 2017-03-05 20:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:05:18 --> Controller Class Initialized
INFO - 2017-03-05 20:05:18 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:05:18 --> Final output sent to browser
DEBUG - 2017-03-05 20:05:18 --> Total execution time: 0.0390
INFO - 2017-03-05 20:05:22 --> Config Class Initialized
INFO - 2017-03-05 20:05:22 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:05:22 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:05:22 --> Utf8 Class Initialized
INFO - 2017-03-05 20:05:22 --> URI Class Initialized
DEBUG - 2017-03-05 20:05:22 --> No URI present. Default controller set.
INFO - 2017-03-05 20:05:22 --> Router Class Initialized
INFO - 2017-03-05 20:05:22 --> Output Class Initialized
INFO - 2017-03-05 20:05:23 --> Security Class Initialized
DEBUG - 2017-03-05 20:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:05:23 --> Input Class Initialized
INFO - 2017-03-05 20:05:23 --> Language Class Initialized
INFO - 2017-03-05 20:05:23 --> Loader Class Initialized
INFO - 2017-03-05 20:05:23 --> Database Driver Class Initialized
INFO - 2017-03-05 20:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:05:23 --> Controller Class Initialized
INFO - 2017-03-05 20:05:23 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:05:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:05:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:05:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:05:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:05:24 --> Final output sent to browser
DEBUG - 2017-03-05 20:05:24 --> Total execution time: 1.6745
INFO - 2017-03-05 20:05:28 --> Config Class Initialized
INFO - 2017-03-05 20:05:28 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:05:28 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:05:28 --> Utf8 Class Initialized
INFO - 2017-03-05 20:05:28 --> URI Class Initialized
INFO - 2017-03-05 20:05:28 --> Router Class Initialized
INFO - 2017-03-05 20:05:28 --> Output Class Initialized
INFO - 2017-03-05 20:05:28 --> Security Class Initialized
DEBUG - 2017-03-05 20:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:05:28 --> Input Class Initialized
INFO - 2017-03-05 20:05:28 --> Language Class Initialized
INFO - 2017-03-05 20:05:28 --> Loader Class Initialized
INFO - 2017-03-05 20:05:28 --> Database Driver Class Initialized
INFO - 2017-03-05 20:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:05:29 --> Controller Class Initialized
INFO - 2017-03-05 20:05:29 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:05:29 --> Final output sent to browser
DEBUG - 2017-03-05 20:05:29 --> Total execution time: 1.3075
INFO - 2017-03-05 20:06:20 --> Config Class Initialized
INFO - 2017-03-05 20:06:20 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:06:20 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:06:20 --> Utf8 Class Initialized
INFO - 2017-03-05 20:06:20 --> URI Class Initialized
DEBUG - 2017-03-05 20:06:20 --> No URI present. Default controller set.
INFO - 2017-03-05 20:06:20 --> Router Class Initialized
INFO - 2017-03-05 20:06:20 --> Output Class Initialized
INFO - 2017-03-05 20:06:20 --> Security Class Initialized
DEBUG - 2017-03-05 20:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:06:20 --> Input Class Initialized
INFO - 2017-03-05 20:06:20 --> Language Class Initialized
INFO - 2017-03-05 20:06:20 --> Loader Class Initialized
INFO - 2017-03-05 20:06:20 --> Database Driver Class Initialized
INFO - 2017-03-05 20:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:06:21 --> Controller Class Initialized
INFO - 2017-03-05 20:06:21 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:06:21 --> Final output sent to browser
DEBUG - 2017-03-05 20:06:21 --> Total execution time: 1.4798
INFO - 2017-03-05 20:07:50 --> Config Class Initialized
INFO - 2017-03-05 20:07:50 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:07:50 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:07:50 --> Utf8 Class Initialized
INFO - 2017-03-05 20:07:50 --> URI Class Initialized
INFO - 2017-03-05 20:07:50 --> Router Class Initialized
INFO - 2017-03-05 20:07:51 --> Output Class Initialized
INFO - 2017-03-05 20:07:51 --> Security Class Initialized
DEBUG - 2017-03-05 20:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:07:51 --> Input Class Initialized
INFO - 2017-03-05 20:07:51 --> Language Class Initialized
INFO - 2017-03-05 20:07:51 --> Loader Class Initialized
INFO - 2017-03-05 20:07:51 --> Database Driver Class Initialized
INFO - 2017-03-05 20:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:07:51 --> Controller Class Initialized
INFO - 2017-03-05 20:07:51 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:07:59 --> Config Class Initialized
INFO - 2017-03-05 20:07:59 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:07:59 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:07:59 --> Utf8 Class Initialized
INFO - 2017-03-05 20:07:59 --> URI Class Initialized
INFO - 2017-03-05 20:07:59 --> Router Class Initialized
INFO - 2017-03-05 20:07:59 --> Output Class Initialized
INFO - 2017-03-05 20:07:59 --> Security Class Initialized
DEBUG - 2017-03-05 20:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:08:00 --> Input Class Initialized
INFO - 2017-03-05 20:08:00 --> Language Class Initialized
INFO - 2017-03-05 20:08:00 --> Loader Class Initialized
INFO - 2017-03-05 20:08:00 --> Database Driver Class Initialized
INFO - 2017-03-05 20:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:08:00 --> Controller Class Initialized
INFO - 2017-03-05 20:08:00 --> Helper loaded: date_helper
DEBUG - 2017-03-05 20:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:08:00 --> Helper loaded: url_helper
INFO - 2017-03-05 20:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 20:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 20:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 20:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:08:00 --> Final output sent to browser
DEBUG - 2017-03-05 20:08:00 --> Total execution time: 0.8021
INFO - 2017-03-05 20:08:41 --> Config Class Initialized
INFO - 2017-03-05 20:08:41 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:08:41 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:08:41 --> Utf8 Class Initialized
INFO - 2017-03-05 20:08:41 --> URI Class Initialized
INFO - 2017-03-05 20:08:41 --> Router Class Initialized
INFO - 2017-03-05 20:08:41 --> Output Class Initialized
INFO - 2017-03-05 20:08:41 --> Security Class Initialized
DEBUG - 2017-03-05 20:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:08:41 --> Input Class Initialized
INFO - 2017-03-05 20:08:41 --> Language Class Initialized
INFO - 2017-03-05 20:08:41 --> Loader Class Initialized
INFO - 2017-03-05 20:08:41 --> Database Driver Class Initialized
INFO - 2017-03-05 20:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:08:41 --> Controller Class Initialized
INFO - 2017-03-05 20:08:41 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:08:41 --> Final output sent to browser
DEBUG - 2017-03-05 20:08:41 --> Total execution time: 0.3009
INFO - 2017-03-05 20:20:16 --> Config Class Initialized
INFO - 2017-03-05 20:20:16 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:20:16 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:20:16 --> Utf8 Class Initialized
INFO - 2017-03-05 20:20:16 --> URI Class Initialized
DEBUG - 2017-03-05 20:20:16 --> No URI present. Default controller set.
INFO - 2017-03-05 20:20:16 --> Router Class Initialized
INFO - 2017-03-05 20:20:16 --> Output Class Initialized
INFO - 2017-03-05 20:20:16 --> Security Class Initialized
DEBUG - 2017-03-05 20:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:20:16 --> Input Class Initialized
INFO - 2017-03-05 20:20:16 --> Language Class Initialized
INFO - 2017-03-05 20:20:16 --> Loader Class Initialized
INFO - 2017-03-05 20:20:16 --> Database Driver Class Initialized
INFO - 2017-03-05 20:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:20:17 --> Controller Class Initialized
INFO - 2017-03-05 20:20:17 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:20:17 --> Final output sent to browser
DEBUG - 2017-03-05 20:20:17 --> Total execution time: 1.4692
INFO - 2017-03-05 20:20:22 --> Config Class Initialized
INFO - 2017-03-05 20:20:22 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:20:22 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:20:22 --> Utf8 Class Initialized
INFO - 2017-03-05 20:20:22 --> URI Class Initialized
INFO - 2017-03-05 20:20:22 --> Router Class Initialized
INFO - 2017-03-05 20:20:22 --> Output Class Initialized
INFO - 2017-03-05 20:20:22 --> Security Class Initialized
DEBUG - 2017-03-05 20:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:20:22 --> Input Class Initialized
INFO - 2017-03-05 20:20:22 --> Language Class Initialized
INFO - 2017-03-05 20:20:22 --> Loader Class Initialized
INFO - 2017-03-05 20:20:22 --> Database Driver Class Initialized
INFO - 2017-03-05 20:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:20:22 --> Controller Class Initialized
INFO - 2017-03-05 20:20:22 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:20:22 --> Final output sent to browser
DEBUG - 2017-03-05 20:20:22 --> Total execution time: 0.2690
INFO - 2017-03-05 20:20:25 --> Config Class Initialized
INFO - 2017-03-05 20:20:25 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:20:25 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:20:25 --> Utf8 Class Initialized
INFO - 2017-03-05 20:20:25 --> URI Class Initialized
INFO - 2017-03-05 20:20:25 --> Router Class Initialized
INFO - 2017-03-05 20:20:25 --> Output Class Initialized
INFO - 2017-03-05 20:20:25 --> Security Class Initialized
DEBUG - 2017-03-05 20:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:20:26 --> Input Class Initialized
INFO - 2017-03-05 20:20:26 --> Language Class Initialized
INFO - 2017-03-05 20:20:26 --> Loader Class Initialized
INFO - 2017-03-05 20:20:26 --> Database Driver Class Initialized
INFO - 2017-03-05 20:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:20:26 --> Controller Class Initialized
INFO - 2017-03-05 20:20:26 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:20:27 --> Config Class Initialized
INFO - 2017-03-05 20:20:27 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:20:27 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:20:27 --> Utf8 Class Initialized
INFO - 2017-03-05 20:20:27 --> URI Class Initialized
INFO - 2017-03-05 20:20:27 --> Router Class Initialized
INFO - 2017-03-05 20:20:27 --> Output Class Initialized
INFO - 2017-03-05 20:20:27 --> Security Class Initialized
DEBUG - 2017-03-05 20:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:20:27 --> Input Class Initialized
INFO - 2017-03-05 20:20:27 --> Language Class Initialized
INFO - 2017-03-05 20:20:27 --> Loader Class Initialized
INFO - 2017-03-05 20:20:27 --> Database Driver Class Initialized
INFO - 2017-03-05 20:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:20:27 --> Controller Class Initialized
INFO - 2017-03-05 20:20:27 --> Helper loaded: date_helper
DEBUG - 2017-03-05 20:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:20:27 --> Helper loaded: url_helper
INFO - 2017-03-05 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:20:27 --> Final output sent to browser
DEBUG - 2017-03-05 20:20:27 --> Total execution time: 0.1100
INFO - 2017-03-05 20:20:29 --> Config Class Initialized
INFO - 2017-03-05 20:20:29 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:20:29 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:20:29 --> Utf8 Class Initialized
INFO - 2017-03-05 20:20:29 --> URI Class Initialized
INFO - 2017-03-05 20:20:29 --> Router Class Initialized
INFO - 2017-03-05 20:20:29 --> Output Class Initialized
INFO - 2017-03-05 20:20:29 --> Security Class Initialized
DEBUG - 2017-03-05 20:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:20:29 --> Input Class Initialized
INFO - 2017-03-05 20:20:29 --> Language Class Initialized
INFO - 2017-03-05 20:20:29 --> Loader Class Initialized
INFO - 2017-03-05 20:20:29 --> Database Driver Class Initialized
INFO - 2017-03-05 20:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:20:29 --> Controller Class Initialized
INFO - 2017-03-05 20:20:29 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:20:29 --> Final output sent to browser
DEBUG - 2017-03-05 20:20:29 --> Total execution time: 0.0433
INFO - 2017-03-05 20:20:37 --> Config Class Initialized
INFO - 2017-03-05 20:20:37 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:20:37 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:20:37 --> Utf8 Class Initialized
INFO - 2017-03-05 20:20:37 --> URI Class Initialized
INFO - 2017-03-05 20:20:37 --> Router Class Initialized
INFO - 2017-03-05 20:20:37 --> Output Class Initialized
INFO - 2017-03-05 20:20:37 --> Security Class Initialized
DEBUG - 2017-03-05 20:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:20:37 --> Input Class Initialized
INFO - 2017-03-05 20:20:37 --> Language Class Initialized
INFO - 2017-03-05 20:20:37 --> Loader Class Initialized
INFO - 2017-03-05 20:20:37 --> Database Driver Class Initialized
INFO - 2017-03-05 20:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:20:37 --> Controller Class Initialized
INFO - 2017-03-05 20:20:37 --> Helper loaded: date_helper
DEBUG - 2017-03-05 20:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:20:37 --> Helper loaded: url_helper
INFO - 2017-03-05 20:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 20:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 20:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 20:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:20:37 --> Final output sent to browser
DEBUG - 2017-03-05 20:20:37 --> Total execution time: 0.0149
INFO - 2017-03-05 20:20:38 --> Config Class Initialized
INFO - 2017-03-05 20:20:38 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:20:38 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:20:38 --> Utf8 Class Initialized
INFO - 2017-03-05 20:20:38 --> URI Class Initialized
INFO - 2017-03-05 20:20:38 --> Router Class Initialized
INFO - 2017-03-05 20:20:38 --> Output Class Initialized
INFO - 2017-03-05 20:20:38 --> Security Class Initialized
DEBUG - 2017-03-05 20:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:20:38 --> Input Class Initialized
INFO - 2017-03-05 20:20:38 --> Language Class Initialized
INFO - 2017-03-05 20:20:38 --> Loader Class Initialized
INFO - 2017-03-05 20:20:38 --> Database Driver Class Initialized
INFO - 2017-03-05 20:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:20:38 --> Controller Class Initialized
INFO - 2017-03-05 20:20:38 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:20:38 --> Final output sent to browser
DEBUG - 2017-03-05 20:20:38 --> Total execution time: 0.0144
INFO - 2017-03-05 20:42:09 --> Config Class Initialized
INFO - 2017-03-05 20:42:09 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:42:09 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:42:09 --> Utf8 Class Initialized
INFO - 2017-03-05 20:42:09 --> URI Class Initialized
DEBUG - 2017-03-05 20:42:09 --> No URI present. Default controller set.
INFO - 2017-03-05 20:42:09 --> Router Class Initialized
INFO - 2017-03-05 20:42:09 --> Output Class Initialized
INFO - 2017-03-05 20:42:09 --> Security Class Initialized
DEBUG - 2017-03-05 20:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:42:09 --> Input Class Initialized
INFO - 2017-03-05 20:42:09 --> Language Class Initialized
INFO - 2017-03-05 20:42:09 --> Loader Class Initialized
INFO - 2017-03-05 20:42:09 --> Database Driver Class Initialized
INFO - 2017-03-05 20:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:42:10 --> Controller Class Initialized
INFO - 2017-03-05 20:42:10 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:42:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:42:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:42:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:42:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:42:10 --> Final output sent to browser
DEBUG - 2017-03-05 20:42:10 --> Total execution time: 1.4844
INFO - 2017-03-05 20:42:36 --> Config Class Initialized
INFO - 2017-03-05 20:42:36 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:42:36 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:42:36 --> Utf8 Class Initialized
INFO - 2017-03-05 20:42:36 --> URI Class Initialized
INFO - 2017-03-05 20:42:36 --> Router Class Initialized
INFO - 2017-03-05 20:42:36 --> Output Class Initialized
INFO - 2017-03-05 20:42:36 --> Security Class Initialized
DEBUG - 2017-03-05 20:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:42:36 --> Input Class Initialized
INFO - 2017-03-05 20:42:36 --> Language Class Initialized
INFO - 2017-03-05 20:42:36 --> Loader Class Initialized
INFO - 2017-03-05 20:42:36 --> Database Driver Class Initialized
INFO - 2017-03-05 20:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:42:36 --> Controller Class Initialized
INFO - 2017-03-05 20:42:36 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:42:36 --> Final output sent to browser
DEBUG - 2017-03-05 20:42:36 --> Total execution time: 0.0299
INFO - 2017-03-05 20:44:50 --> Config Class Initialized
INFO - 2017-03-05 20:44:50 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:44:51 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:44:51 --> Utf8 Class Initialized
INFO - 2017-03-05 20:44:51 --> URI Class Initialized
INFO - 2017-03-05 20:44:51 --> Router Class Initialized
INFO - 2017-03-05 20:44:51 --> Output Class Initialized
INFO - 2017-03-05 20:44:51 --> Security Class Initialized
DEBUG - 2017-03-05 20:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:44:51 --> Input Class Initialized
INFO - 2017-03-05 20:44:51 --> Language Class Initialized
INFO - 2017-03-05 20:44:51 --> Loader Class Initialized
INFO - 2017-03-05 20:44:51 --> Database Driver Class Initialized
INFO - 2017-03-05 20:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:44:51 --> Controller Class Initialized
INFO - 2017-03-05 20:44:51 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:44:53 --> Config Class Initialized
INFO - 2017-03-05 20:44:53 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:44:53 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:44:53 --> Utf8 Class Initialized
INFO - 2017-03-05 20:44:53 --> URI Class Initialized
INFO - 2017-03-05 20:44:53 --> Router Class Initialized
INFO - 2017-03-05 20:44:53 --> Output Class Initialized
INFO - 2017-03-05 20:44:53 --> Security Class Initialized
DEBUG - 2017-03-05 20:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:44:53 --> Input Class Initialized
INFO - 2017-03-05 20:44:53 --> Language Class Initialized
INFO - 2017-03-05 20:44:53 --> Loader Class Initialized
INFO - 2017-03-05 20:44:53 --> Database Driver Class Initialized
INFO - 2017-03-05 20:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:44:53 --> Controller Class Initialized
INFO - 2017-03-05 20:44:53 --> Helper loaded: date_helper
DEBUG - 2017-03-05 20:44:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:44:53 --> Helper loaded: url_helper
INFO - 2017-03-05 20:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 20:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 20:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 20:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:44:53 --> Final output sent to browser
DEBUG - 2017-03-05 20:44:53 --> Total execution time: 0.1203
INFO - 2017-03-05 20:44:56 --> Config Class Initialized
INFO - 2017-03-05 20:44:56 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:44:56 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:44:56 --> Utf8 Class Initialized
INFO - 2017-03-05 20:44:56 --> URI Class Initialized
INFO - 2017-03-05 20:44:56 --> Router Class Initialized
INFO - 2017-03-05 20:44:56 --> Output Class Initialized
INFO - 2017-03-05 20:44:56 --> Security Class Initialized
DEBUG - 2017-03-05 20:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:44:56 --> Input Class Initialized
INFO - 2017-03-05 20:44:56 --> Language Class Initialized
INFO - 2017-03-05 20:44:56 --> Loader Class Initialized
INFO - 2017-03-05 20:44:56 --> Database Driver Class Initialized
INFO - 2017-03-05 20:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:44:56 --> Controller Class Initialized
INFO - 2017-03-05 20:44:56 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:44:56 --> Final output sent to browser
DEBUG - 2017-03-05 20:44:56 --> Total execution time: 0.0365
INFO - 2017-03-05 20:45:09 --> Config Class Initialized
INFO - 2017-03-05 20:45:09 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:45:09 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:45:09 --> Utf8 Class Initialized
INFO - 2017-03-05 20:45:09 --> URI Class Initialized
INFO - 2017-03-05 20:45:09 --> Router Class Initialized
INFO - 2017-03-05 20:45:09 --> Output Class Initialized
INFO - 2017-03-05 20:45:09 --> Security Class Initialized
DEBUG - 2017-03-05 20:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:45:09 --> Input Class Initialized
INFO - 2017-03-05 20:45:09 --> Language Class Initialized
INFO - 2017-03-05 20:45:09 --> Loader Class Initialized
INFO - 2017-03-05 20:45:09 --> Database Driver Class Initialized
INFO - 2017-03-05 20:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:45:09 --> Controller Class Initialized
INFO - 2017-03-05 20:45:09 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:45:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:45:09 --> Config Class Initialized
INFO - 2017-03-05 20:45:09 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:45:09 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:45:09 --> Utf8 Class Initialized
INFO - 2017-03-05 20:45:09 --> URI Class Initialized
INFO - 2017-03-05 20:45:09 --> Router Class Initialized
INFO - 2017-03-05 20:45:09 --> Output Class Initialized
INFO - 2017-03-05 20:45:09 --> Security Class Initialized
DEBUG - 2017-03-05 20:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:45:09 --> Input Class Initialized
INFO - 2017-03-05 20:45:09 --> Language Class Initialized
INFO - 2017-03-05 20:45:09 --> Loader Class Initialized
INFO - 2017-03-05 20:45:09 --> Database Driver Class Initialized
INFO - 2017-03-05 20:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:45:09 --> Controller Class Initialized
INFO - 2017-03-05 20:45:09 --> Helper loaded: date_helper
DEBUG - 2017-03-05 20:45:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:45:09 --> Helper loaded: url_helper
INFO - 2017-03-05 20:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 20:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 20:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 20:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:45:09 --> Final output sent to browser
DEBUG - 2017-03-05 20:45:09 --> Total execution time: 0.0151
INFO - 2017-03-05 20:45:11 --> Config Class Initialized
INFO - 2017-03-05 20:45:11 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:45:11 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:45:11 --> Utf8 Class Initialized
INFO - 2017-03-05 20:45:11 --> URI Class Initialized
INFO - 2017-03-05 20:45:11 --> Router Class Initialized
INFO - 2017-03-05 20:45:11 --> Output Class Initialized
INFO - 2017-03-05 20:45:11 --> Security Class Initialized
DEBUG - 2017-03-05 20:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:45:11 --> Input Class Initialized
INFO - 2017-03-05 20:45:11 --> Language Class Initialized
INFO - 2017-03-05 20:45:11 --> Loader Class Initialized
INFO - 2017-03-05 20:45:11 --> Database Driver Class Initialized
INFO - 2017-03-05 20:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:45:11 --> Controller Class Initialized
INFO - 2017-03-05 20:45:11 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:45:11 --> Final output sent to browser
DEBUG - 2017-03-05 20:45:11 --> Total execution time: 0.0133
INFO - 2017-03-05 20:45:23 --> Config Class Initialized
INFO - 2017-03-05 20:45:23 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:45:23 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:45:23 --> Utf8 Class Initialized
INFO - 2017-03-05 20:45:23 --> URI Class Initialized
DEBUG - 2017-03-05 20:45:23 --> No URI present. Default controller set.
INFO - 2017-03-05 20:45:23 --> Router Class Initialized
INFO - 2017-03-05 20:45:23 --> Output Class Initialized
INFO - 2017-03-05 20:45:23 --> Security Class Initialized
DEBUG - 2017-03-05 20:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:45:23 --> Input Class Initialized
INFO - 2017-03-05 20:45:23 --> Language Class Initialized
INFO - 2017-03-05 20:45:23 --> Loader Class Initialized
INFO - 2017-03-05 20:45:23 --> Database Driver Class Initialized
INFO - 2017-03-05 20:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:45:23 --> Controller Class Initialized
INFO - 2017-03-05 20:45:23 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:45:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:45:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:45:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:45:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:45:24 --> Final output sent to browser
DEBUG - 2017-03-05 20:45:24 --> Total execution time: 1.2293
INFO - 2017-03-05 20:45:30 --> Config Class Initialized
INFO - 2017-03-05 20:45:30 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:45:30 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:45:30 --> Utf8 Class Initialized
INFO - 2017-03-05 20:45:30 --> URI Class Initialized
INFO - 2017-03-05 20:45:30 --> Router Class Initialized
INFO - 2017-03-05 20:45:30 --> Output Class Initialized
INFO - 2017-03-05 20:45:30 --> Security Class Initialized
DEBUG - 2017-03-05 20:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:45:30 --> Input Class Initialized
INFO - 2017-03-05 20:45:30 --> Language Class Initialized
INFO - 2017-03-05 20:45:30 --> Loader Class Initialized
INFO - 2017-03-05 20:45:30 --> Database Driver Class Initialized
INFO - 2017-03-05 20:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:45:30 --> Controller Class Initialized
INFO - 2017-03-05 20:45:30 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:45:30 --> Final output sent to browser
DEBUG - 2017-03-05 20:45:30 --> Total execution time: 0.0139
INFO - 2017-03-05 20:46:27 --> Config Class Initialized
INFO - 2017-03-05 20:46:27 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:46:27 --> Utf8 Class Initialized
INFO - 2017-03-05 20:46:27 --> URI Class Initialized
INFO - 2017-03-05 20:46:27 --> Router Class Initialized
INFO - 2017-03-05 20:46:27 --> Output Class Initialized
INFO - 2017-03-05 20:46:27 --> Security Class Initialized
DEBUG - 2017-03-05 20:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:46:27 --> Input Class Initialized
INFO - 2017-03-05 20:46:27 --> Language Class Initialized
INFO - 2017-03-05 20:46:27 --> Loader Class Initialized
INFO - 2017-03-05 20:46:27 --> Database Driver Class Initialized
INFO - 2017-03-05 20:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:46:28 --> Controller Class Initialized
INFO - 2017-03-05 20:46:28 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:46:28 --> Final output sent to browser
DEBUG - 2017-03-05 20:46:28 --> Total execution time: 1.3153
INFO - 2017-03-05 20:46:31 --> Config Class Initialized
INFO - 2017-03-05 20:46:31 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:46:31 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:46:31 --> Utf8 Class Initialized
INFO - 2017-03-05 20:46:31 --> URI Class Initialized
INFO - 2017-03-05 20:46:31 --> Router Class Initialized
INFO - 2017-03-05 20:46:31 --> Output Class Initialized
INFO - 2017-03-05 20:46:31 --> Security Class Initialized
DEBUG - 2017-03-05 20:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:46:31 --> Input Class Initialized
INFO - 2017-03-05 20:46:31 --> Language Class Initialized
INFO - 2017-03-05 20:46:31 --> Loader Class Initialized
INFO - 2017-03-05 20:46:31 --> Database Driver Class Initialized
INFO - 2017-03-05 20:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:46:31 --> Controller Class Initialized
INFO - 2017-03-05 20:46:31 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:46:31 --> Final output sent to browser
DEBUG - 2017-03-05 20:46:31 --> Total execution time: 0.0142
INFO - 2017-03-05 20:46:58 --> Config Class Initialized
INFO - 2017-03-05 20:46:58 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:46:58 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:46:58 --> Utf8 Class Initialized
INFO - 2017-03-05 20:46:58 --> URI Class Initialized
INFO - 2017-03-05 20:46:58 --> Router Class Initialized
INFO - 2017-03-05 20:46:58 --> Output Class Initialized
INFO - 2017-03-05 20:46:58 --> Security Class Initialized
DEBUG - 2017-03-05 20:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:46:58 --> Input Class Initialized
INFO - 2017-03-05 20:46:58 --> Language Class Initialized
INFO - 2017-03-05 20:46:58 --> Loader Class Initialized
INFO - 2017-03-05 20:46:59 --> Database Driver Class Initialized
INFO - 2017-03-05 20:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:46:59 --> Controller Class Initialized
INFO - 2017-03-05 20:46:59 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:46:59 --> Final output sent to browser
DEBUG - 2017-03-05 20:46:59 --> Total execution time: 1.3929
INFO - 2017-03-05 20:47:22 --> Config Class Initialized
INFO - 2017-03-05 20:47:22 --> Config Class Initialized
INFO - 2017-03-05 20:47:22 --> Hooks Class Initialized
INFO - 2017-03-05 20:47:22 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:47:22 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:47:22 --> Utf8 Class Initialized
DEBUG - 2017-03-05 20:47:22 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:47:22 --> URI Class Initialized
INFO - 2017-03-05 20:47:22 --> Utf8 Class Initialized
INFO - 2017-03-05 20:47:22 --> URI Class Initialized
INFO - 2017-03-05 20:47:22 --> Router Class Initialized
INFO - 2017-03-05 20:47:22 --> Router Class Initialized
INFO - 2017-03-05 20:47:22 --> Output Class Initialized
INFO - 2017-03-05 20:47:22 --> Output Class Initialized
INFO - 2017-03-05 20:47:22 --> Security Class Initialized
INFO - 2017-03-05 20:47:22 --> Security Class Initialized
DEBUG - 2017-03-05 20:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:47:22 --> Input Class Initialized
INFO - 2017-03-05 20:47:22 --> Language Class Initialized
DEBUG - 2017-03-05 20:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:47:22 --> Input Class Initialized
INFO - 2017-03-05 20:47:22 --> Language Class Initialized
INFO - 2017-03-05 20:47:22 --> Loader Class Initialized
INFO - 2017-03-05 20:47:23 --> Loader Class Initialized
INFO - 2017-03-05 20:47:23 --> Database Driver Class Initialized
INFO - 2017-03-05 20:47:23 --> Database Driver Class Initialized
INFO - 2017-03-05 20:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:47:23 --> Controller Class Initialized
INFO - 2017-03-05 20:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:47:23 --> Controller Class Initialized
INFO - 2017-03-05 20:47:23 --> Helper loaded: url_helper
INFO - 2017-03-05 20:47:23 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:47:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-05 20:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:47:24 --> Final output sent to browser
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
DEBUG - 2017-03-05 20:47:24 --> Total execution time: 2.4449
INFO - 2017-03-05 20:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:47:24 --> Final output sent to browser
DEBUG - 2017-03-05 20:47:25 --> Total execution time: 2.4138
INFO - 2017-03-05 20:47:36 --> Config Class Initialized
INFO - 2017-03-05 20:47:36 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:47:36 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:47:36 --> Utf8 Class Initialized
INFO - 2017-03-05 20:47:36 --> URI Class Initialized
INFO - 2017-03-05 20:47:36 --> Router Class Initialized
INFO - 2017-03-05 20:47:36 --> Output Class Initialized
INFO - 2017-03-05 20:47:36 --> Security Class Initialized
DEBUG - 2017-03-05 20:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:47:37 --> Input Class Initialized
INFO - 2017-03-05 20:47:37 --> Language Class Initialized
INFO - 2017-03-05 20:47:37 --> Loader Class Initialized
INFO - 2017-03-05 20:47:37 --> Database Driver Class Initialized
INFO - 2017-03-05 20:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:47:37 --> Controller Class Initialized
INFO - 2017-03-05 20:47:37 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:47:37 --> Final output sent to browser
DEBUG - 2017-03-05 20:47:37 --> Total execution time: 1.2293
INFO - 2017-03-05 20:48:39 --> Config Class Initialized
INFO - 2017-03-05 20:48:39 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:48:39 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:48:39 --> Utf8 Class Initialized
INFO - 2017-03-05 20:48:39 --> URI Class Initialized
INFO - 2017-03-05 20:48:39 --> Router Class Initialized
INFO - 2017-03-05 20:48:40 --> Output Class Initialized
INFO - 2017-03-05 20:48:40 --> Security Class Initialized
DEBUG - 2017-03-05 20:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:48:40 --> Input Class Initialized
INFO - 2017-03-05 20:48:40 --> Language Class Initialized
INFO - 2017-03-05 20:48:40 --> Loader Class Initialized
INFO - 2017-03-05 20:48:40 --> Database Driver Class Initialized
INFO - 2017-03-05 20:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:48:40 --> Controller Class Initialized
INFO - 2017-03-05 20:48:40 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:48:42 --> Config Class Initialized
INFO - 2017-03-05 20:48:42 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:48:42 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:48:42 --> Utf8 Class Initialized
INFO - 2017-03-05 20:48:42 --> URI Class Initialized
INFO - 2017-03-05 20:48:42 --> Router Class Initialized
INFO - 2017-03-05 20:48:42 --> Output Class Initialized
INFO - 2017-03-05 20:48:42 --> Security Class Initialized
DEBUG - 2017-03-05 20:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:48:42 --> Input Class Initialized
INFO - 2017-03-05 20:48:42 --> Language Class Initialized
INFO - 2017-03-05 20:48:42 --> Loader Class Initialized
INFO - 2017-03-05 20:48:42 --> Database Driver Class Initialized
INFO - 2017-03-05 20:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:48:42 --> Controller Class Initialized
INFO - 2017-03-05 20:48:42 --> Helper loaded: date_helper
DEBUG - 2017-03-05 20:48:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:48:42 --> Helper loaded: url_helper
INFO - 2017-03-05 20:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-05 20:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-05 20:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-05 20:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:48:42 --> Final output sent to browser
DEBUG - 2017-03-05 20:48:42 --> Total execution time: 0.1363
INFO - 2017-03-05 20:48:44 --> Config Class Initialized
INFO - 2017-03-05 20:48:44 --> Hooks Class Initialized
DEBUG - 2017-03-05 20:48:44 --> UTF-8 Support Enabled
INFO - 2017-03-05 20:48:44 --> Utf8 Class Initialized
INFO - 2017-03-05 20:48:44 --> URI Class Initialized
INFO - 2017-03-05 20:48:44 --> Router Class Initialized
INFO - 2017-03-05 20:48:44 --> Output Class Initialized
INFO - 2017-03-05 20:48:44 --> Security Class Initialized
DEBUG - 2017-03-05 20:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 20:48:44 --> Input Class Initialized
INFO - 2017-03-05 20:48:44 --> Language Class Initialized
INFO - 2017-03-05 20:48:44 --> Loader Class Initialized
INFO - 2017-03-05 20:48:44 --> Database Driver Class Initialized
INFO - 2017-03-05 20:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 20:48:44 --> Controller Class Initialized
INFO - 2017-03-05 20:48:44 --> Helper loaded: url_helper
DEBUG - 2017-03-05 20:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 20:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-05 20:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-05 20:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-05 20:48:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-05 20:48:44 --> Final output sent to browser
DEBUG - 2017-03-05 20:48:44 --> Total execution time: 0.0939

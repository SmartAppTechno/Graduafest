<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-30 00:05:33 --> Config Class Initialized
INFO - 2016-11-30 00:05:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 00:05:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 00:05:33 --> Utf8 Class Initialized
INFO - 2016-11-30 00:05:33 --> URI Class Initialized
DEBUG - 2016-11-30 00:05:33 --> No URI present. Default controller set.
INFO - 2016-11-30 00:05:33 --> Router Class Initialized
INFO - 2016-11-30 00:05:33 --> Output Class Initialized
INFO - 2016-11-30 00:05:33 --> Security Class Initialized
DEBUG - 2016-11-30 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 00:05:33 --> Input Class Initialized
INFO - 2016-11-30 00:05:33 --> Language Class Initialized
INFO - 2016-11-30 00:05:33 --> Loader Class Initialized
INFO - 2016-11-30 00:05:33 --> Database Driver Class Initialized
INFO - 2016-11-30 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 00:05:33 --> Controller Class Initialized
INFO - 2016-11-30 00:05:33 --> Helper loaded: url_helper
DEBUG - 2016-11-30 00:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 00:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 00:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 00:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 00:05:33 --> Final output sent to browser
DEBUG - 2016-11-30 00:05:33 --> Total execution time: 0.0392
INFO - 2016-11-30 00:05:33 --> Config Class Initialized
INFO - 2016-11-30 00:05:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 00:05:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 00:05:33 --> Utf8 Class Initialized
INFO - 2016-11-30 00:05:33 --> URI Class Initialized
INFO - 2016-11-30 00:05:33 --> Router Class Initialized
INFO - 2016-11-30 00:05:33 --> Output Class Initialized
INFO - 2016-11-30 00:05:33 --> Security Class Initialized
DEBUG - 2016-11-30 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 00:05:33 --> Input Class Initialized
INFO - 2016-11-30 00:05:33 --> Language Class Initialized
ERROR - 2016-11-30 00:05:33 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-30 00:05:33 --> Config Class Initialized
INFO - 2016-11-30 00:05:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 00:05:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 00:05:33 --> Utf8 Class Initialized
INFO - 2016-11-30 00:05:33 --> URI Class Initialized
INFO - 2016-11-30 00:05:33 --> Router Class Initialized
INFO - 2016-11-30 00:05:33 --> Output Class Initialized
INFO - 2016-11-30 00:05:33 --> Security Class Initialized
DEBUG - 2016-11-30 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 00:05:33 --> Input Class Initialized
INFO - 2016-11-30 00:05:33 --> Language Class Initialized
ERROR - 2016-11-30 00:05:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-30 00:05:33 --> Config Class Initialized
INFO - 2016-11-30 00:05:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 00:05:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 00:05:33 --> Utf8 Class Initialized
INFO - 2016-11-30 00:05:33 --> URI Class Initialized
INFO - 2016-11-30 00:05:33 --> Router Class Initialized
INFO - 2016-11-30 00:05:33 --> Output Class Initialized
INFO - 2016-11-30 00:05:33 --> Security Class Initialized
DEBUG - 2016-11-30 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 00:05:33 --> Input Class Initialized
INFO - 2016-11-30 00:05:33 --> Language Class Initialized
ERROR - 2016-11-30 00:05:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-30 00:05:33 --> Config Class Initialized
INFO - 2016-11-30 00:05:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 00:05:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 00:05:33 --> Utf8 Class Initialized
INFO - 2016-11-30 00:05:33 --> URI Class Initialized
INFO - 2016-11-30 00:05:33 --> Router Class Initialized
INFO - 2016-11-30 00:05:33 --> Output Class Initialized
INFO - 2016-11-30 00:05:33 --> Security Class Initialized
DEBUG - 2016-11-30 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 00:05:33 --> Input Class Initialized
INFO - 2016-11-30 00:05:33 --> Language Class Initialized
ERROR - 2016-11-30 00:05:33 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-30 00:05:33 --> Config Class Initialized
INFO - 2016-11-30 00:05:33 --> Hooks Class Initialized
DEBUG - 2016-11-30 00:05:33 --> UTF-8 Support Enabled
INFO - 2016-11-30 00:05:33 --> Utf8 Class Initialized
INFO - 2016-11-30 00:05:33 --> URI Class Initialized
INFO - 2016-11-30 00:05:33 --> Router Class Initialized
INFO - 2016-11-30 00:05:33 --> Output Class Initialized
INFO - 2016-11-30 00:05:33 --> Security Class Initialized
DEBUG - 2016-11-30 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 00:05:33 --> Input Class Initialized
INFO - 2016-11-30 00:05:33 --> Language Class Initialized
INFO - 2016-11-30 00:05:33 --> Loader Class Initialized
INFO - 2016-11-30 00:05:33 --> Database Driver Class Initialized
INFO - 2016-11-30 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 00:05:33 --> Controller Class Initialized
INFO - 2016-11-30 00:05:33 --> Helper loaded: url_helper
DEBUG - 2016-11-30 00:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 00:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 00:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 00:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 00:05:33 --> Final output sent to browser
DEBUG - 2016-11-30 00:05:33 --> Total execution time: 0.0134
INFO - 2016-11-30 06:41:51 --> Config Class Initialized
INFO - 2016-11-30 06:41:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 06:41:51 --> UTF-8 Support Enabled
INFO - 2016-11-30 06:41:51 --> Utf8 Class Initialized
INFO - 2016-11-30 06:41:51 --> URI Class Initialized
INFO - 2016-11-30 06:41:51 --> Router Class Initialized
INFO - 2016-11-30 06:41:51 --> Output Class Initialized
INFO - 2016-11-30 06:41:51 --> Security Class Initialized
DEBUG - 2016-11-30 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 06:41:51 --> Input Class Initialized
INFO - 2016-11-30 06:41:51 --> Language Class Initialized
INFO - 2016-11-30 06:41:51 --> Loader Class Initialized
INFO - 2016-11-30 06:41:51 --> Database Driver Class Initialized
INFO - 2016-11-30 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 06:41:51 --> Controller Class Initialized
INFO - 2016-11-30 06:41:51 --> Helper loaded: url_helper
DEBUG - 2016-11-30 06:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 06:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 06:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 06:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 06:41:51 --> Final output sent to browser
DEBUG - 2016-11-30 06:41:51 --> Total execution time: 0.0457
INFO - 2016-11-30 06:41:51 --> Config Class Initialized
INFO - 2016-11-30 06:41:51 --> Hooks Class Initialized
DEBUG - 2016-11-30 06:41:51 --> UTF-8 Support Enabled
INFO - 2016-11-30 06:41:51 --> Utf8 Class Initialized
INFO - 2016-11-30 06:41:51 --> URI Class Initialized
INFO - 2016-11-30 06:41:51 --> Router Class Initialized
INFO - 2016-11-30 06:41:51 --> Output Class Initialized
INFO - 2016-11-30 06:41:51 --> Security Class Initialized
DEBUG - 2016-11-30 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 06:41:51 --> Input Class Initialized
INFO - 2016-11-30 06:41:51 --> Language Class Initialized
INFO - 2016-11-30 06:41:51 --> Loader Class Initialized
INFO - 2016-11-30 06:41:51 --> Database Driver Class Initialized
INFO - 2016-11-30 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 06:41:51 --> Controller Class Initialized
INFO - 2016-11-30 06:41:51 --> Helper loaded: url_helper
DEBUG - 2016-11-30 06:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 06:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 06:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 06:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 06:41:51 --> Final output sent to browser
DEBUG - 2016-11-30 06:41:51 --> Total execution time: 0.0198
INFO - 2016-11-30 06:41:55 --> Config Class Initialized
INFO - 2016-11-30 06:41:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 06:41:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 06:41:55 --> Utf8 Class Initialized
INFO - 2016-11-30 06:41:55 --> URI Class Initialized
DEBUG - 2016-11-30 06:41:55 --> No URI present. Default controller set.
INFO - 2016-11-30 06:41:55 --> Router Class Initialized
INFO - 2016-11-30 06:41:55 --> Output Class Initialized
INFO - 2016-11-30 06:41:55 --> Security Class Initialized
DEBUG - 2016-11-30 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 06:41:55 --> Input Class Initialized
INFO - 2016-11-30 06:41:55 --> Language Class Initialized
INFO - 2016-11-30 06:41:55 --> Loader Class Initialized
INFO - 2016-11-30 06:41:55 --> Database Driver Class Initialized
INFO - 2016-11-30 06:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 06:41:55 --> Controller Class Initialized
INFO - 2016-11-30 06:41:55 --> Helper loaded: url_helper
DEBUG - 2016-11-30 06:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 06:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 06:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 06:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 06:41:55 --> Final output sent to browser
DEBUG - 2016-11-30 06:41:55 --> Total execution time: 0.0675
INFO - 2016-11-30 06:41:55 --> Config Class Initialized
INFO - 2016-11-30 06:41:55 --> Hooks Class Initialized
DEBUG - 2016-11-30 06:41:55 --> UTF-8 Support Enabled
INFO - 2016-11-30 06:41:55 --> Utf8 Class Initialized
INFO - 2016-11-30 06:41:55 --> URI Class Initialized
DEBUG - 2016-11-30 06:41:55 --> No URI present. Default controller set.
INFO - 2016-11-30 06:41:55 --> Router Class Initialized
INFO - 2016-11-30 06:41:55 --> Output Class Initialized
INFO - 2016-11-30 06:41:55 --> Security Class Initialized
DEBUG - 2016-11-30 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 06:41:55 --> Input Class Initialized
INFO - 2016-11-30 06:41:55 --> Language Class Initialized
INFO - 2016-11-30 06:41:55 --> Loader Class Initialized
INFO - 2016-11-30 06:41:55 --> Database Driver Class Initialized
INFO - 2016-11-30 06:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 06:41:55 --> Controller Class Initialized
INFO - 2016-11-30 06:41:55 --> Helper loaded: url_helper
DEBUG - 2016-11-30 06:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 06:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 06:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 06:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 06:41:55 --> Final output sent to browser
DEBUG - 2016-11-30 06:41:55 --> Total execution time: 0.0319
INFO - 2016-11-30 15:35:11 --> Config Class Initialized
INFO - 2016-11-30 15:35:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:35:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:35:11 --> Utf8 Class Initialized
INFO - 2016-11-30 15:35:11 --> URI Class Initialized
DEBUG - 2016-11-30 15:35:11 --> No URI present. Default controller set.
INFO - 2016-11-30 15:35:11 --> Router Class Initialized
INFO - 2016-11-30 15:35:11 --> Output Class Initialized
INFO - 2016-11-30 15:35:11 --> Security Class Initialized
DEBUG - 2016-11-30 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:35:11 --> Input Class Initialized
INFO - 2016-11-30 15:35:11 --> Language Class Initialized
INFO - 2016-11-30 15:35:11 --> Loader Class Initialized
INFO - 2016-11-30 15:35:11 --> Database Driver Class Initialized
INFO - 2016-11-30 15:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:35:11 --> Controller Class Initialized
INFO - 2016-11-30 15:35:11 --> Helper loaded: url_helper
DEBUG - 2016-11-30 15:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 15:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 15:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 15:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 15:35:11 --> Final output sent to browser
DEBUG - 2016-11-30 15:35:11 --> Total execution time: 0.0962
INFO - 2016-11-30 15:35:11 --> Config Class Initialized
INFO - 2016-11-30 15:35:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:35:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:35:11 --> Utf8 Class Initialized
INFO - 2016-11-30 15:35:11 --> URI Class Initialized
INFO - 2016-11-30 15:35:11 --> Router Class Initialized
INFO - 2016-11-30 15:35:11 --> Output Class Initialized
INFO - 2016-11-30 15:35:11 --> Security Class Initialized
DEBUG - 2016-11-30 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:35:11 --> Input Class Initialized
INFO - 2016-11-30 15:35:11 --> Language Class Initialized
ERROR - 2016-11-30 15:35:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-30 15:35:11 --> Config Class Initialized
INFO - 2016-11-30 15:35:11 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:35:11 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:35:11 --> Utf8 Class Initialized
INFO - 2016-11-30 15:35:11 --> URI Class Initialized
INFO - 2016-11-30 15:35:11 --> Router Class Initialized
INFO - 2016-11-30 15:35:11 --> Output Class Initialized
INFO - 2016-11-30 15:35:11 --> Security Class Initialized
DEBUG - 2016-11-30 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:35:11 --> Input Class Initialized
INFO - 2016-11-30 15:35:11 --> Language Class Initialized
ERROR - 2016-11-30 15:35:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-30 15:35:12 --> Config Class Initialized
INFO - 2016-11-30 15:35:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:35:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:35:12 --> Utf8 Class Initialized
INFO - 2016-11-30 15:35:12 --> URI Class Initialized
INFO - 2016-11-30 15:35:12 --> Router Class Initialized
INFO - 2016-11-30 15:35:12 --> Output Class Initialized
INFO - 2016-11-30 15:35:12 --> Security Class Initialized
DEBUG - 2016-11-30 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:35:12 --> Input Class Initialized
INFO - 2016-11-30 15:35:12 --> Language Class Initialized
ERROR - 2016-11-30 15:35:12 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-30 15:35:12 --> Config Class Initialized
INFO - 2016-11-30 15:35:12 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:35:12 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:35:12 --> Utf8 Class Initialized
INFO - 2016-11-30 15:35:12 --> URI Class Initialized
INFO - 2016-11-30 15:35:12 --> Router Class Initialized
INFO - 2016-11-30 15:35:12 --> Output Class Initialized
INFO - 2016-11-30 15:35:12 --> Security Class Initialized
DEBUG - 2016-11-30 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:35:12 --> Input Class Initialized
INFO - 2016-11-30 15:35:12 --> Language Class Initialized
ERROR - 2016-11-30 15:35:12 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-30 15:35:13 --> Config Class Initialized
INFO - 2016-11-30 15:35:13 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:35:13 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:35:13 --> Utf8 Class Initialized
INFO - 2016-11-30 15:35:13 --> URI Class Initialized
INFO - 2016-11-30 15:35:13 --> Router Class Initialized
INFO - 2016-11-30 15:35:13 --> Output Class Initialized
INFO - 2016-11-30 15:35:13 --> Security Class Initialized
DEBUG - 2016-11-30 15:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:35:13 --> Input Class Initialized
INFO - 2016-11-30 15:35:13 --> Language Class Initialized
INFO - 2016-11-30 15:35:13 --> Loader Class Initialized
INFO - 2016-11-30 15:35:13 --> Database Driver Class Initialized
INFO - 2016-11-30 15:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:35:13 --> Controller Class Initialized
INFO - 2016-11-30 15:35:13 --> Helper loaded: url_helper
DEBUG - 2016-11-30 15:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 15:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 15:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 15:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 15:35:13 --> Final output sent to browser
DEBUG - 2016-11-30 15:35:13 --> Total execution time: 0.0146
INFO - 2016-11-30 15:56:37 --> Config Class Initialized
INFO - 2016-11-30 15:56:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:56:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:56:37 --> Utf8 Class Initialized
INFO - 2016-11-30 15:56:37 --> URI Class Initialized
DEBUG - 2016-11-30 15:56:37 --> No URI present. Default controller set.
INFO - 2016-11-30 15:56:37 --> Router Class Initialized
INFO - 2016-11-30 15:56:37 --> Output Class Initialized
INFO - 2016-11-30 15:56:37 --> Security Class Initialized
DEBUG - 2016-11-30 15:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:56:37 --> Input Class Initialized
INFO - 2016-11-30 15:56:37 --> Language Class Initialized
INFO - 2016-11-30 15:56:37 --> Loader Class Initialized
INFO - 2016-11-30 15:56:37 --> Database Driver Class Initialized
INFO - 2016-11-30 15:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:56:37 --> Controller Class Initialized
INFO - 2016-11-30 15:56:37 --> Helper loaded: url_helper
DEBUG - 2016-11-30 15:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 15:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 15:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 15:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 15:56:37 --> Final output sent to browser
DEBUG - 2016-11-30 15:56:37 --> Total execution time: 0.0142
INFO - 2016-11-30 15:56:37 --> Config Class Initialized
INFO - 2016-11-30 15:56:37 --> Hooks Class Initialized
DEBUG - 2016-11-30 15:56:37 --> UTF-8 Support Enabled
INFO - 2016-11-30 15:56:37 --> Utf8 Class Initialized
INFO - 2016-11-30 15:56:37 --> URI Class Initialized
INFO - 2016-11-30 15:56:37 --> Router Class Initialized
INFO - 2016-11-30 15:56:37 --> Output Class Initialized
INFO - 2016-11-30 15:56:37 --> Security Class Initialized
DEBUG - 2016-11-30 15:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-30 15:56:37 --> Input Class Initialized
INFO - 2016-11-30 15:56:37 --> Language Class Initialized
INFO - 2016-11-30 15:56:37 --> Loader Class Initialized
INFO - 2016-11-30 15:56:37 --> Database Driver Class Initialized
INFO - 2016-11-30 15:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-30 15:56:37 --> Controller Class Initialized
INFO - 2016-11-30 15:56:37 --> Helper loaded: url_helper
DEBUG - 2016-11-30 15:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-30 15:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-30 15:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-30 15:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-30 15:56:37 --> Final output sent to browser
DEBUG - 2016-11-30 15:56:37 --> Total execution time: 0.0191

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-26 06:14:21 --> Config Class Initialized
INFO - 2016-12-26 06:14:21 --> Hooks Class Initialized
DEBUG - 2016-12-26 06:14:21 --> UTF-8 Support Enabled
INFO - 2016-12-26 06:14:21 --> Utf8 Class Initialized
INFO - 2016-12-26 06:14:21 --> URI Class Initialized
DEBUG - 2016-12-26 06:14:21 --> No URI present. Default controller set.
INFO - 2016-12-26 06:14:21 --> Router Class Initialized
INFO - 2016-12-26 06:14:21 --> Output Class Initialized
INFO - 2016-12-26 06:14:21 --> Security Class Initialized
DEBUG - 2016-12-26 06:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 06:14:21 --> Input Class Initialized
INFO - 2016-12-26 06:14:21 --> Language Class Initialized
INFO - 2016-12-26 06:14:21 --> Loader Class Initialized
INFO - 2016-12-26 06:14:22 --> Database Driver Class Initialized
INFO - 2016-12-26 06:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 06:14:22 --> Controller Class Initialized
INFO - 2016-12-26 06:14:22 --> Helper loaded: url_helper
DEBUG - 2016-12-26 06:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 06:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 06:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 06:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 06:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 06:14:22 --> Final output sent to browser
DEBUG - 2016-12-26 06:14:22 --> Total execution time: 1.6781
INFO - 2016-12-26 06:15:05 --> Config Class Initialized
INFO - 2016-12-26 06:15:05 --> Hooks Class Initialized
DEBUG - 2016-12-26 06:15:05 --> UTF-8 Support Enabled
INFO - 2016-12-26 06:15:05 --> Utf8 Class Initialized
INFO - 2016-12-26 06:15:05 --> URI Class Initialized
DEBUG - 2016-12-26 06:15:05 --> No URI present. Default controller set.
INFO - 2016-12-26 06:15:05 --> Router Class Initialized
INFO - 2016-12-26 06:15:05 --> Output Class Initialized
INFO - 2016-12-26 06:15:05 --> Security Class Initialized
DEBUG - 2016-12-26 06:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 06:15:05 --> Input Class Initialized
INFO - 2016-12-26 06:15:05 --> Language Class Initialized
INFO - 2016-12-26 06:15:05 --> Loader Class Initialized
INFO - 2016-12-26 06:15:05 --> Database Driver Class Initialized
INFO - 2016-12-26 06:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 06:15:05 --> Controller Class Initialized
INFO - 2016-12-26 06:15:05 --> Helper loaded: url_helper
DEBUG - 2016-12-26 06:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 06:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 06:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 06:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 06:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 06:15:05 --> Final output sent to browser
DEBUG - 2016-12-26 06:15:05 --> Total execution time: 0.4035
INFO - 2016-12-26 06:35:29 --> Config Class Initialized
INFO - 2016-12-26 06:35:29 --> Hooks Class Initialized
DEBUG - 2016-12-26 06:35:29 --> UTF-8 Support Enabled
INFO - 2016-12-26 06:35:29 --> Utf8 Class Initialized
INFO - 2016-12-26 06:35:29 --> URI Class Initialized
DEBUG - 2016-12-26 06:35:29 --> No URI present. Default controller set.
INFO - 2016-12-26 06:35:29 --> Router Class Initialized
INFO - 2016-12-26 06:35:29 --> Output Class Initialized
INFO - 2016-12-26 06:35:29 --> Security Class Initialized
DEBUG - 2016-12-26 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 06:35:29 --> Input Class Initialized
INFO - 2016-12-26 06:35:29 --> Language Class Initialized
INFO - 2016-12-26 06:35:29 --> Loader Class Initialized
INFO - 2016-12-26 06:35:29 --> Database Driver Class Initialized
INFO - 2016-12-26 06:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 06:35:30 --> Controller Class Initialized
INFO - 2016-12-26 06:35:30 --> Helper loaded: url_helper
DEBUG - 2016-12-26 06:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 06:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 06:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 06:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 06:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 06:35:30 --> Final output sent to browser
DEBUG - 2016-12-26 06:35:30 --> Total execution time: 1.4166
INFO - 2016-12-26 06:35:43 --> Config Class Initialized
INFO - 2016-12-26 06:35:43 --> Hooks Class Initialized
DEBUG - 2016-12-26 06:35:43 --> UTF-8 Support Enabled
INFO - 2016-12-26 06:35:43 --> Utf8 Class Initialized
INFO - 2016-12-26 06:35:43 --> URI Class Initialized
INFO - 2016-12-26 06:35:43 --> Router Class Initialized
INFO - 2016-12-26 06:35:43 --> Output Class Initialized
INFO - 2016-12-26 06:35:43 --> Security Class Initialized
DEBUG - 2016-12-26 06:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 06:35:44 --> Input Class Initialized
INFO - 2016-12-26 06:35:44 --> Language Class Initialized
INFO - 2016-12-26 06:35:44 --> Loader Class Initialized
INFO - 2016-12-26 06:35:44 --> Database Driver Class Initialized
INFO - 2016-12-26 06:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 06:35:44 --> Controller Class Initialized
INFO - 2016-12-26 06:35:44 --> Helper loaded: url_helper
DEBUG - 2016-12-26 06:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 06:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 06:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 06:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 06:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 06:35:44 --> Final output sent to browser
DEBUG - 2016-12-26 06:35:44 --> Total execution time: 1.2039
INFO - 2016-12-26 21:14:48 --> Config Class Initialized
INFO - 2016-12-26 21:14:49 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:14:49 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:14:49 --> Utf8 Class Initialized
INFO - 2016-12-26 21:14:49 --> URI Class Initialized
DEBUG - 2016-12-26 21:14:49 --> No URI present. Default controller set.
INFO - 2016-12-26 21:14:49 --> Router Class Initialized
INFO - 2016-12-26 21:14:49 --> Output Class Initialized
INFO - 2016-12-26 21:14:49 --> Security Class Initialized
DEBUG - 2016-12-26 21:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:14:49 --> Input Class Initialized
INFO - 2016-12-26 21:14:49 --> Language Class Initialized
INFO - 2016-12-26 21:14:49 --> Loader Class Initialized
INFO - 2016-12-26 21:14:49 --> Database Driver Class Initialized
INFO - 2016-12-26 21:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:14:50 --> Controller Class Initialized
INFO - 2016-12-26 21:14:50 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:14:50 --> Final output sent to browser
DEBUG - 2016-12-26 21:14:50 --> Total execution time: 1.6927
INFO - 2016-12-26 21:15:06 --> Config Class Initialized
INFO - 2016-12-26 21:15:06 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:15:06 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:15:06 --> Utf8 Class Initialized
INFO - 2016-12-26 21:15:06 --> URI Class Initialized
INFO - 2016-12-26 21:15:06 --> Router Class Initialized
INFO - 2016-12-26 21:15:06 --> Output Class Initialized
INFO - 2016-12-26 21:15:06 --> Security Class Initialized
DEBUG - 2016-12-26 21:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:15:06 --> Input Class Initialized
INFO - 2016-12-26 21:15:06 --> Language Class Initialized
INFO - 2016-12-26 21:15:06 --> Loader Class Initialized
INFO - 2016-12-26 21:15:06 --> Database Driver Class Initialized
INFO - 2016-12-26 21:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:15:06 --> Controller Class Initialized
INFO - 2016-12-26 21:15:06 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:15:06 --> Final output sent to browser
DEBUG - 2016-12-26 21:15:06 --> Total execution time: 0.0362
INFO - 2016-12-26 21:19:26 --> Config Class Initialized
INFO - 2016-12-26 21:19:26 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:19:26 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:19:26 --> Utf8 Class Initialized
INFO - 2016-12-26 21:19:26 --> URI Class Initialized
DEBUG - 2016-12-26 21:19:26 --> No URI present. Default controller set.
INFO - 2016-12-26 21:19:26 --> Router Class Initialized
INFO - 2016-12-26 21:19:26 --> Output Class Initialized
INFO - 2016-12-26 21:19:26 --> Security Class Initialized
DEBUG - 2016-12-26 21:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:19:26 --> Input Class Initialized
INFO - 2016-12-26 21:19:26 --> Language Class Initialized
INFO - 2016-12-26 21:19:26 --> Loader Class Initialized
INFO - 2016-12-26 21:19:26 --> Database Driver Class Initialized
INFO - 2016-12-26 21:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:19:26 --> Controller Class Initialized
INFO - 2016-12-26 21:19:26 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:19:26 --> Final output sent to browser
DEBUG - 2016-12-26 21:19:26 --> Total execution time: 0.0139
INFO - 2016-12-26 21:19:27 --> Config Class Initialized
INFO - 2016-12-26 21:19:27 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:19:27 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:19:27 --> Utf8 Class Initialized
INFO - 2016-12-26 21:19:27 --> URI Class Initialized
INFO - 2016-12-26 21:19:27 --> Router Class Initialized
INFO - 2016-12-26 21:19:27 --> Output Class Initialized
INFO - 2016-12-26 21:19:27 --> Security Class Initialized
DEBUG - 2016-12-26 21:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:19:27 --> Input Class Initialized
INFO - 2016-12-26 21:19:27 --> Language Class Initialized
INFO - 2016-12-26 21:19:27 --> Loader Class Initialized
INFO - 2016-12-26 21:19:27 --> Database Driver Class Initialized
INFO - 2016-12-26 21:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:19:27 --> Controller Class Initialized
INFO - 2016-12-26 21:19:27 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:19:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:19:27 --> Final output sent to browser
DEBUG - 2016-12-26 21:19:27 --> Total execution time: 0.0486
INFO - 2016-12-26 21:22:13 --> Config Class Initialized
INFO - 2016-12-26 21:22:13 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:22:13 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:13 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:13 --> URI Class Initialized
DEBUG - 2016-12-26 21:22:13 --> No URI present. Default controller set.
INFO - 2016-12-26 21:22:13 --> Router Class Initialized
INFO - 2016-12-26 21:22:13 --> Output Class Initialized
INFO - 2016-12-26 21:22:13 --> Security Class Initialized
DEBUG - 2016-12-26 21:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:13 --> Input Class Initialized
INFO - 2016-12-26 21:22:13 --> Language Class Initialized
INFO - 2016-12-26 21:22:13 --> Loader Class Initialized
INFO - 2016-12-26 21:22:14 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:15 --> Controller Class Initialized
INFO - 2016-12-26 21:22:15 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:15 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:15 --> Total execution time: 1.8376
INFO - 2016-12-26 21:22:18 --> Config Class Initialized
INFO - 2016-12-26 21:22:18 --> Config Class Initialized
INFO - 2016-12-26 21:22:18 --> Hooks Class Initialized
INFO - 2016-12-26 21:22:18 --> Hooks Class Initialized
INFO - 2016-12-26 21:22:18 --> Config Class Initialized
INFO - 2016-12-26 21:22:18 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:22:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:22:19 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:19 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:19 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:22:19 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:19 --> URI Class Initialized
INFO - 2016-12-26 21:22:19 --> URI Class Initialized
INFO - 2016-12-26 21:22:19 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:19 --> URI Class Initialized
INFO - 2016-12-26 21:22:19 --> Router Class Initialized
INFO - 2016-12-26 21:22:19 --> Router Class Initialized
INFO - 2016-12-26 21:22:19 --> Router Class Initialized
INFO - 2016-12-26 21:22:19 --> Output Class Initialized
INFO - 2016-12-26 21:22:19 --> Output Class Initialized
INFO - 2016-12-26 21:22:19 --> Output Class Initialized
INFO - 2016-12-26 21:22:19 --> Security Class Initialized
INFO - 2016-12-26 21:22:19 --> Security Class Initialized
INFO - 2016-12-26 21:22:19 --> Security Class Initialized
DEBUG - 2016-12-26 21:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:19 --> Input Class Initialized
INFO - 2016-12-26 21:22:19 --> Language Class Initialized
DEBUG - 2016-12-26 21:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:19 --> Input Class Initialized
INFO - 2016-12-26 21:22:19 --> Language Class Initialized
DEBUG - 2016-12-26 21:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:19 --> Input Class Initialized
INFO - 2016-12-26 21:22:19 --> Language Class Initialized
INFO - 2016-12-26 21:22:19 --> Loader Class Initialized
INFO - 2016-12-26 21:22:19 --> Loader Class Initialized
INFO - 2016-12-26 21:22:19 --> Loader Class Initialized
INFO - 2016-12-26 21:22:19 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:19 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:19 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:19 --> Controller Class Initialized
INFO - 2016-12-26 21:22:19 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:19 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:19 --> Total execution time: 1.0348
INFO - 2016-12-26 21:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:19 --> Controller Class Initialized
INFO - 2016-12-26 21:22:19 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:19 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:19 --> Total execution time: 1.0367
INFO - 2016-12-26 21:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:19 --> Controller Class Initialized
INFO - 2016-12-26 21:22:19 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:20 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:20 --> Total execution time: 1.0501
INFO - 2016-12-26 21:22:20 --> Config Class Initialized
INFO - 2016-12-26 21:22:20 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:22:20 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:20 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:20 --> URI Class Initialized
INFO - 2016-12-26 21:22:20 --> Router Class Initialized
INFO - 2016-12-26 21:22:20 --> Output Class Initialized
INFO - 2016-12-26 21:22:20 --> Security Class Initialized
DEBUG - 2016-12-26 21:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:20 --> Input Class Initialized
INFO - 2016-12-26 21:22:20 --> Language Class Initialized
INFO - 2016-12-26 21:22:20 --> Loader Class Initialized
INFO - 2016-12-26 21:22:20 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:20 --> Controller Class Initialized
INFO - 2016-12-26 21:22:20 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:20 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:20 --> Total execution time: 0.0137
INFO - 2016-12-26 21:22:41 --> Config Class Initialized
INFO - 2016-12-26 21:22:41 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:22:41 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:41 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:41 --> URI Class Initialized
DEBUG - 2016-12-26 21:22:41 --> No URI present. Default controller set.
INFO - 2016-12-26 21:22:41 --> Router Class Initialized
INFO - 2016-12-26 21:22:41 --> Output Class Initialized
INFO - 2016-12-26 21:22:41 --> Security Class Initialized
DEBUG - 2016-12-26 21:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:41 --> Input Class Initialized
INFO - 2016-12-26 21:22:41 --> Language Class Initialized
INFO - 2016-12-26 21:22:41 --> Loader Class Initialized
INFO - 2016-12-26 21:22:41 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:41 --> Controller Class Initialized
INFO - 2016-12-26 21:22:41 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:42 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:42 --> Total execution time: 0.9868
INFO - 2016-12-26 21:22:43 --> Config Class Initialized
INFO - 2016-12-26 21:22:43 --> Hooks Class Initialized
INFO - 2016-12-26 21:22:44 --> Config Class Initialized
INFO - 2016-12-26 21:22:44 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:22:44 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:44 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:22:44 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:44 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:44 --> URI Class Initialized
INFO - 2016-12-26 21:22:44 --> Config Class Initialized
INFO - 2016-12-26 21:22:44 --> Hooks Class Initialized
INFO - 2016-12-26 21:22:44 --> URI Class Initialized
INFO - 2016-12-26 21:22:44 --> Router Class Initialized
INFO - 2016-12-26 21:22:44 --> Router Class Initialized
DEBUG - 2016-12-26 21:22:44 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:44 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:44 --> URI Class Initialized
INFO - 2016-12-26 21:22:44 --> Router Class Initialized
INFO - 2016-12-26 21:22:44 --> Output Class Initialized
INFO - 2016-12-26 21:22:44 --> Output Class Initialized
INFO - 2016-12-26 21:22:44 --> Output Class Initialized
INFO - 2016-12-26 21:22:44 --> Security Class Initialized
INFO - 2016-12-26 21:22:44 --> Security Class Initialized
INFO - 2016-12-26 21:22:44 --> Security Class Initialized
DEBUG - 2016-12-26 21:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-12-26 21:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:44 --> Input Class Initialized
INFO - 2016-12-26 21:22:44 --> Input Class Initialized
DEBUG - 2016-12-26 21:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:44 --> Input Class Initialized
INFO - 2016-12-26 21:22:44 --> Language Class Initialized
INFO - 2016-12-26 21:22:44 --> Language Class Initialized
INFO - 2016-12-26 21:22:44 --> Language Class Initialized
INFO - 2016-12-26 21:22:44 --> Loader Class Initialized
INFO - 2016-12-26 21:22:44 --> Loader Class Initialized
INFO - 2016-12-26 21:22:44 --> Loader Class Initialized
INFO - 2016-12-26 21:22:44 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:44 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:44 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:44 --> Controller Class Initialized
INFO - 2016-12-26 21:22:44 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:44 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:44 --> Total execution time: 0.4344
INFO - 2016-12-26 21:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:44 --> Controller Class Initialized
INFO - 2016-12-26 21:22:44 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:44 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:44 --> Total execution time: 0.4425
INFO - 2016-12-26 21:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:44 --> Controller Class Initialized
INFO - 2016-12-26 21:22:44 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:44 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:44 --> Total execution time: 0.4508
INFO - 2016-12-26 21:22:44 --> Config Class Initialized
INFO - 2016-12-26 21:22:44 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:22:44 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:22:44 --> Utf8 Class Initialized
INFO - 2016-12-26 21:22:44 --> URI Class Initialized
INFO - 2016-12-26 21:22:44 --> Router Class Initialized
INFO - 2016-12-26 21:22:44 --> Output Class Initialized
INFO - 2016-12-26 21:22:44 --> Security Class Initialized
DEBUG - 2016-12-26 21:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:22:44 --> Input Class Initialized
INFO - 2016-12-26 21:22:44 --> Language Class Initialized
INFO - 2016-12-26 21:22:44 --> Loader Class Initialized
INFO - 2016-12-26 21:22:44 --> Database Driver Class Initialized
INFO - 2016-12-26 21:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:22:44 --> Controller Class Initialized
INFO - 2016-12-26 21:22:44 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:22:44 --> Final output sent to browser
DEBUG - 2016-12-26 21:22:44 --> Total execution time: 0.0140
INFO - 2016-12-26 21:24:08 --> Config Class Initialized
INFO - 2016-12-26 21:24:08 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:24:08 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:24:08 --> Utf8 Class Initialized
INFO - 2016-12-26 21:24:08 --> URI Class Initialized
DEBUG - 2016-12-26 21:24:08 --> No URI present. Default controller set.
INFO - 2016-12-26 21:24:08 --> Router Class Initialized
INFO - 2016-12-26 21:24:08 --> Output Class Initialized
INFO - 2016-12-26 21:24:08 --> Security Class Initialized
DEBUG - 2016-12-26 21:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:24:08 --> Input Class Initialized
INFO - 2016-12-26 21:24:08 --> Language Class Initialized
INFO - 2016-12-26 21:24:08 --> Loader Class Initialized
INFO - 2016-12-26 21:24:08 --> Database Driver Class Initialized
INFO - 2016-12-26 21:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:24:09 --> Controller Class Initialized
INFO - 2016-12-26 21:24:09 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:24:09 --> Final output sent to browser
DEBUG - 2016-12-26 21:24:09 --> Total execution time: 1.2044
INFO - 2016-12-26 21:24:09 --> Config Class Initialized
INFO - 2016-12-26 21:24:09 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:24:09 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:24:09 --> Utf8 Class Initialized
INFO - 2016-12-26 21:24:09 --> URI Class Initialized
INFO - 2016-12-26 21:24:09 --> Router Class Initialized
INFO - 2016-12-26 21:24:09 --> Output Class Initialized
INFO - 2016-12-26 21:24:09 --> Security Class Initialized
DEBUG - 2016-12-26 21:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:24:09 --> Input Class Initialized
INFO - 2016-12-26 21:24:09 --> Language Class Initialized
INFO - 2016-12-26 21:24:09 --> Loader Class Initialized
INFO - 2016-12-26 21:24:09 --> Database Driver Class Initialized
INFO - 2016-12-26 21:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:24:09 --> Controller Class Initialized
INFO - 2016-12-26 21:24:09 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:24:09 --> Final output sent to browser
DEBUG - 2016-12-26 21:24:09 --> Total execution time: 0.0145
INFO - 2016-12-26 21:25:34 --> Config Class Initialized
INFO - 2016-12-26 21:25:34 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:25:34 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:25:34 --> Utf8 Class Initialized
INFO - 2016-12-26 21:25:34 --> URI Class Initialized
DEBUG - 2016-12-26 21:25:34 --> No URI present. Default controller set.
INFO - 2016-12-26 21:25:34 --> Router Class Initialized
INFO - 2016-12-26 21:25:34 --> Output Class Initialized
INFO - 2016-12-26 21:25:34 --> Security Class Initialized
DEBUG - 2016-12-26 21:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:25:34 --> Input Class Initialized
INFO - 2016-12-26 21:25:34 --> Language Class Initialized
INFO - 2016-12-26 21:25:34 --> Loader Class Initialized
INFO - 2016-12-26 21:25:34 --> Database Driver Class Initialized
INFO - 2016-12-26 21:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:25:35 --> Controller Class Initialized
INFO - 2016-12-26 21:25:35 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:25:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:25:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:25:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:25:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:25:35 --> Final output sent to browser
DEBUG - 2016-12-26 21:25:35 --> Total execution time: 1.0716
INFO - 2016-12-26 21:25:38 --> Config Class Initialized
INFO - 2016-12-26 21:25:38 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:25:38 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:25:38 --> Utf8 Class Initialized
INFO - 2016-12-26 21:25:38 --> URI Class Initialized
INFO - 2016-12-26 21:25:38 --> Router Class Initialized
INFO - 2016-12-26 21:25:39 --> Output Class Initialized
INFO - 2016-12-26 21:25:39 --> Security Class Initialized
DEBUG - 2016-12-26 21:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:25:39 --> Input Class Initialized
INFO - 2016-12-26 21:25:39 --> Language Class Initialized
INFO - 2016-12-26 21:25:39 --> Loader Class Initialized
INFO - 2016-12-26 21:25:39 --> Database Driver Class Initialized
INFO - 2016-12-26 21:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:25:39 --> Controller Class Initialized
INFO - 2016-12-26 21:25:39 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:25:39 --> Final output sent to browser
DEBUG - 2016-12-26 21:25:39 --> Total execution time: 1.3414
INFO - 2016-12-26 21:26:41 --> Config Class Initialized
INFO - 2016-12-26 21:26:41 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:26:41 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:26:41 --> Utf8 Class Initialized
INFO - 2016-12-26 21:26:41 --> URI Class Initialized
DEBUG - 2016-12-26 21:26:41 --> No URI present. Default controller set.
INFO - 2016-12-26 21:26:41 --> Router Class Initialized
INFO - 2016-12-26 21:26:42 --> Output Class Initialized
INFO - 2016-12-26 21:26:42 --> Security Class Initialized
DEBUG - 2016-12-26 21:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:26:42 --> Input Class Initialized
INFO - 2016-12-26 21:26:42 --> Language Class Initialized
INFO - 2016-12-26 21:26:42 --> Loader Class Initialized
INFO - 2016-12-26 21:26:42 --> Database Driver Class Initialized
INFO - 2016-12-26 21:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:26:42 --> Controller Class Initialized
INFO - 2016-12-26 21:26:42 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:26:42 --> Final output sent to browser
DEBUG - 2016-12-26 21:26:42 --> Total execution time: 0.7064
INFO - 2016-12-26 21:26:42 --> Config Class Initialized
INFO - 2016-12-26 21:26:42 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:26:42 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:26:42 --> Utf8 Class Initialized
INFO - 2016-12-26 21:26:42 --> URI Class Initialized
INFO - 2016-12-26 21:26:42 --> Router Class Initialized
INFO - 2016-12-26 21:26:42 --> Output Class Initialized
INFO - 2016-12-26 21:26:42 --> Security Class Initialized
DEBUG - 2016-12-26 21:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:26:42 --> Input Class Initialized
INFO - 2016-12-26 21:26:42 --> Language Class Initialized
INFO - 2016-12-26 21:26:42 --> Loader Class Initialized
INFO - 2016-12-26 21:26:42 --> Database Driver Class Initialized
INFO - 2016-12-26 21:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:26:42 --> Controller Class Initialized
INFO - 2016-12-26 21:26:42 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:26:42 --> Final output sent to browser
DEBUG - 2016-12-26 21:26:42 --> Total execution time: 0.0136
INFO - 2016-12-26 21:27:18 --> Config Class Initialized
INFO - 2016-12-26 21:27:18 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:27:18 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:27:18 --> Utf8 Class Initialized
INFO - 2016-12-26 21:27:18 --> URI Class Initialized
DEBUG - 2016-12-26 21:27:18 --> No URI present. Default controller set.
INFO - 2016-12-26 21:27:18 --> Router Class Initialized
INFO - 2016-12-26 21:27:18 --> Output Class Initialized
INFO - 2016-12-26 21:27:18 --> Security Class Initialized
DEBUG - 2016-12-26 21:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:27:18 --> Input Class Initialized
INFO - 2016-12-26 21:27:18 --> Language Class Initialized
INFO - 2016-12-26 21:27:18 --> Loader Class Initialized
INFO - 2016-12-26 21:27:19 --> Database Driver Class Initialized
INFO - 2016-12-26 21:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:27:19 --> Controller Class Initialized
INFO - 2016-12-26 21:27:19 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:27:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:27:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:27:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:27:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:27:19 --> Final output sent to browser
DEBUG - 2016-12-26 21:27:19 --> Total execution time: 0.8016
INFO - 2016-12-26 21:27:20 --> Config Class Initialized
INFO - 2016-12-26 21:27:20 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:27:20 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:27:20 --> Utf8 Class Initialized
INFO - 2016-12-26 21:27:20 --> URI Class Initialized
INFO - 2016-12-26 21:27:20 --> Router Class Initialized
INFO - 2016-12-26 21:27:20 --> Output Class Initialized
INFO - 2016-12-26 21:27:20 --> Security Class Initialized
DEBUG - 2016-12-26 21:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:27:20 --> Input Class Initialized
INFO - 2016-12-26 21:27:20 --> Language Class Initialized
INFO - 2016-12-26 21:27:20 --> Loader Class Initialized
INFO - 2016-12-26 21:27:20 --> Database Driver Class Initialized
INFO - 2016-12-26 21:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:27:20 --> Controller Class Initialized
INFO - 2016-12-26 21:27:20 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:27:21 --> Final output sent to browser
DEBUG - 2016-12-26 21:27:21 --> Total execution time: 0.6228
INFO - 2016-12-26 21:29:11 --> Config Class Initialized
INFO - 2016-12-26 21:29:11 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:29:11 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:29:11 --> Utf8 Class Initialized
INFO - 2016-12-26 21:29:11 --> URI Class Initialized
DEBUG - 2016-12-26 21:29:12 --> No URI present. Default controller set.
INFO - 2016-12-26 21:29:12 --> Router Class Initialized
INFO - 2016-12-26 21:29:12 --> Output Class Initialized
INFO - 2016-12-26 21:29:12 --> Security Class Initialized
DEBUG - 2016-12-26 21:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:29:12 --> Input Class Initialized
INFO - 2016-12-26 21:29:12 --> Language Class Initialized
INFO - 2016-12-26 21:29:12 --> Loader Class Initialized
INFO - 2016-12-26 21:29:12 --> Database Driver Class Initialized
INFO - 2016-12-26 21:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:29:12 --> Controller Class Initialized
INFO - 2016-12-26 21:29:12 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:29:12 --> Final output sent to browser
DEBUG - 2016-12-26 21:29:12 --> Total execution time: 0.5695
INFO - 2016-12-26 21:29:13 --> Config Class Initialized
INFO - 2016-12-26 21:29:13 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:29:13 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:29:13 --> Utf8 Class Initialized
INFO - 2016-12-26 21:29:13 --> URI Class Initialized
INFO - 2016-12-26 21:29:13 --> Router Class Initialized
INFO - 2016-12-26 21:29:13 --> Output Class Initialized
INFO - 2016-12-26 21:29:13 --> Security Class Initialized
DEBUG - 2016-12-26 21:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:29:13 --> Input Class Initialized
INFO - 2016-12-26 21:29:13 --> Language Class Initialized
INFO - 2016-12-26 21:29:13 --> Loader Class Initialized
INFO - 2016-12-26 21:29:13 --> Database Driver Class Initialized
INFO - 2016-12-26 21:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:29:13 --> Controller Class Initialized
INFO - 2016-12-26 21:29:13 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:29:13 --> Final output sent to browser
DEBUG - 2016-12-26 21:29:13 --> Total execution time: 0.5244
INFO - 2016-12-26 21:32:54 --> Config Class Initialized
INFO - 2016-12-26 21:32:54 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:32:54 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:32:54 --> Utf8 Class Initialized
INFO - 2016-12-26 21:32:54 --> URI Class Initialized
DEBUG - 2016-12-26 21:32:54 --> No URI present. Default controller set.
INFO - 2016-12-26 21:32:54 --> Router Class Initialized
INFO - 2016-12-26 21:32:54 --> Output Class Initialized
INFO - 2016-12-26 21:32:54 --> Security Class Initialized
DEBUG - 2016-12-26 21:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:32:54 --> Input Class Initialized
INFO - 2016-12-26 21:32:54 --> Language Class Initialized
INFO - 2016-12-26 21:32:54 --> Loader Class Initialized
INFO - 2016-12-26 21:32:54 --> Database Driver Class Initialized
INFO - 2016-12-26 21:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:32:54 --> Controller Class Initialized
INFO - 2016-12-26 21:32:54 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:32:54 --> Final output sent to browser
DEBUG - 2016-12-26 21:32:54 --> Total execution time: 0.5780
INFO - 2016-12-26 21:32:55 --> Config Class Initialized
INFO - 2016-12-26 21:32:55 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:32:55 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:32:55 --> Utf8 Class Initialized
INFO - 2016-12-26 21:32:55 --> URI Class Initialized
INFO - 2016-12-26 21:32:55 --> Router Class Initialized
INFO - 2016-12-26 21:32:55 --> Output Class Initialized
INFO - 2016-12-26 21:32:55 --> Security Class Initialized
DEBUG - 2016-12-26 21:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:32:55 --> Input Class Initialized
INFO - 2016-12-26 21:32:55 --> Language Class Initialized
INFO - 2016-12-26 21:32:55 --> Loader Class Initialized
INFO - 2016-12-26 21:32:55 --> Database Driver Class Initialized
INFO - 2016-12-26 21:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:32:55 --> Controller Class Initialized
INFO - 2016-12-26 21:32:55 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:32:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:32:55 --> Final output sent to browser
DEBUG - 2016-12-26 21:32:55 --> Total execution time: 0.5434
INFO - 2016-12-26 21:35:29 --> Config Class Initialized
INFO - 2016-12-26 21:35:29 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:35:29 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:35:29 --> Utf8 Class Initialized
INFO - 2016-12-26 21:35:29 --> URI Class Initialized
DEBUG - 2016-12-26 21:35:29 --> No URI present. Default controller set.
INFO - 2016-12-26 21:35:29 --> Router Class Initialized
INFO - 2016-12-26 21:35:29 --> Output Class Initialized
INFO - 2016-12-26 21:35:29 --> Security Class Initialized
DEBUG - 2016-12-26 21:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:35:29 --> Input Class Initialized
INFO - 2016-12-26 21:35:29 --> Language Class Initialized
INFO - 2016-12-26 21:35:29 --> Loader Class Initialized
INFO - 2016-12-26 21:35:29 --> Database Driver Class Initialized
INFO - 2016-12-26 21:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:35:29 --> Controller Class Initialized
INFO - 2016-12-26 21:35:29 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:35:29 --> Final output sent to browser
DEBUG - 2016-12-26 21:35:29 --> Total execution time: 0.6061
INFO - 2016-12-26 21:35:30 --> Config Class Initialized
INFO - 2016-12-26 21:35:30 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:35:30 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:35:30 --> Utf8 Class Initialized
INFO - 2016-12-26 21:35:30 --> URI Class Initialized
INFO - 2016-12-26 21:35:30 --> Router Class Initialized
INFO - 2016-12-26 21:35:30 --> Output Class Initialized
INFO - 2016-12-26 21:35:30 --> Security Class Initialized
DEBUG - 2016-12-26 21:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:35:30 --> Input Class Initialized
INFO - 2016-12-26 21:35:30 --> Language Class Initialized
INFO - 2016-12-26 21:35:30 --> Loader Class Initialized
INFO - 2016-12-26 21:35:30 --> Database Driver Class Initialized
INFO - 2016-12-26 21:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:35:30 --> Controller Class Initialized
INFO - 2016-12-26 21:35:30 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:35:30 --> Final output sent to browser
DEBUG - 2016-12-26 21:35:30 --> Total execution time: 0.0138
INFO - 2016-12-26 21:38:50 --> Config Class Initialized
INFO - 2016-12-26 21:38:50 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:38:50 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:38:50 --> Utf8 Class Initialized
INFO - 2016-12-26 21:38:50 --> URI Class Initialized
DEBUG - 2016-12-26 21:38:50 --> No URI present. Default controller set.
INFO - 2016-12-26 21:38:50 --> Router Class Initialized
INFO - 2016-12-26 21:38:50 --> Output Class Initialized
INFO - 2016-12-26 21:38:50 --> Security Class Initialized
DEBUG - 2016-12-26 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:38:50 --> Input Class Initialized
INFO - 2016-12-26 21:38:50 --> Language Class Initialized
INFO - 2016-12-26 21:38:50 --> Loader Class Initialized
INFO - 2016-12-26 21:38:50 --> Database Driver Class Initialized
INFO - 2016-12-26 21:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:38:50 --> Controller Class Initialized
INFO - 2016-12-26 21:38:50 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:38:50 --> Final output sent to browser
DEBUG - 2016-12-26 21:38:50 --> Total execution time: 0.0294
INFO - 2016-12-26 21:38:50 --> Config Class Initialized
INFO - 2016-12-26 21:38:50 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:38:50 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:38:50 --> Utf8 Class Initialized
INFO - 2016-12-26 21:38:50 --> URI Class Initialized
INFO - 2016-12-26 21:38:50 --> Router Class Initialized
INFO - 2016-12-26 21:38:50 --> Output Class Initialized
INFO - 2016-12-26 21:38:50 --> Security Class Initialized
DEBUG - 2016-12-26 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:38:50 --> Input Class Initialized
INFO - 2016-12-26 21:38:50 --> Language Class Initialized
INFO - 2016-12-26 21:38:50 --> Loader Class Initialized
INFO - 2016-12-26 21:38:50 --> Database Driver Class Initialized
INFO - 2016-12-26 21:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:38:50 --> Controller Class Initialized
INFO - 2016-12-26 21:38:50 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:38:50 --> Final output sent to browser
DEBUG - 2016-12-26 21:38:50 --> Total execution time: 0.0144
INFO - 2016-12-26 21:40:21 --> Config Class Initialized
INFO - 2016-12-26 21:40:21 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:40:21 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:40:21 --> Utf8 Class Initialized
INFO - 2016-12-26 21:40:21 --> URI Class Initialized
DEBUG - 2016-12-26 21:40:21 --> No URI present. Default controller set.
INFO - 2016-12-26 21:40:21 --> Router Class Initialized
INFO - 2016-12-26 21:40:21 --> Output Class Initialized
INFO - 2016-12-26 21:40:21 --> Security Class Initialized
DEBUG - 2016-12-26 21:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:40:21 --> Input Class Initialized
INFO - 2016-12-26 21:40:21 --> Language Class Initialized
INFO - 2016-12-26 21:40:21 --> Loader Class Initialized
INFO - 2016-12-26 21:40:21 --> Database Driver Class Initialized
INFO - 2016-12-26 21:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:40:21 --> Controller Class Initialized
INFO - 2016-12-26 21:40:21 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:40:21 --> Final output sent to browser
DEBUG - 2016-12-26 21:40:21 --> Total execution time: 0.0642
INFO - 2016-12-26 21:40:21 --> Config Class Initialized
INFO - 2016-12-26 21:40:21 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:40:21 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:40:21 --> Utf8 Class Initialized
INFO - 2016-12-26 21:40:21 --> URI Class Initialized
INFO - 2016-12-26 21:40:21 --> Router Class Initialized
INFO - 2016-12-26 21:40:21 --> Output Class Initialized
INFO - 2016-12-26 21:40:21 --> Security Class Initialized
DEBUG - 2016-12-26 21:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:40:21 --> Input Class Initialized
INFO - 2016-12-26 21:40:21 --> Language Class Initialized
INFO - 2016-12-26 21:40:21 --> Loader Class Initialized
INFO - 2016-12-26 21:40:21 --> Database Driver Class Initialized
INFO - 2016-12-26 21:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:40:21 --> Controller Class Initialized
INFO - 2016-12-26 21:40:21 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:40:21 --> Final output sent to browser
DEBUG - 2016-12-26 21:40:21 --> Total execution time: 0.0146
INFO - 2016-12-26 21:45:28 --> Config Class Initialized
INFO - 2016-12-26 21:45:28 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:45:28 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:45:28 --> Utf8 Class Initialized
INFO - 2016-12-26 21:45:28 --> URI Class Initialized
DEBUG - 2016-12-26 21:45:28 --> No URI present. Default controller set.
INFO - 2016-12-26 21:45:28 --> Router Class Initialized
INFO - 2016-12-26 21:45:28 --> Output Class Initialized
INFO - 2016-12-26 21:45:28 --> Security Class Initialized
DEBUG - 2016-12-26 21:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:45:28 --> Input Class Initialized
INFO - 2016-12-26 21:45:28 --> Language Class Initialized
INFO - 2016-12-26 21:45:28 --> Loader Class Initialized
INFO - 2016-12-26 21:45:28 --> Database Driver Class Initialized
INFO - 2016-12-26 21:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:45:28 --> Controller Class Initialized
INFO - 2016-12-26 21:45:28 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:45:28 --> Final output sent to browser
DEBUG - 2016-12-26 21:45:28 --> Total execution time: 0.0135
INFO - 2016-12-26 21:45:28 --> Config Class Initialized
INFO - 2016-12-26 21:45:28 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:45:28 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:45:28 --> Utf8 Class Initialized
INFO - 2016-12-26 21:45:28 --> URI Class Initialized
INFO - 2016-12-26 21:45:28 --> Router Class Initialized
INFO - 2016-12-26 21:45:28 --> Output Class Initialized
INFO - 2016-12-26 21:45:28 --> Security Class Initialized
DEBUG - 2016-12-26 21:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:45:28 --> Input Class Initialized
INFO - 2016-12-26 21:45:28 --> Language Class Initialized
INFO - 2016-12-26 21:45:28 --> Loader Class Initialized
INFO - 2016-12-26 21:45:28 --> Database Driver Class Initialized
INFO - 2016-12-26 21:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:45:28 --> Controller Class Initialized
INFO - 2016-12-26 21:45:28 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:45:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:45:28 --> Final output sent to browser
DEBUG - 2016-12-26 21:45:28 --> Total execution time: 0.0168
INFO - 2016-12-26 21:46:12 --> Config Class Initialized
INFO - 2016-12-26 21:46:12 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:12 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:12 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:12 --> URI Class Initialized
DEBUG - 2016-12-26 21:46:12 --> No URI present. Default controller set.
INFO - 2016-12-26 21:46:12 --> Router Class Initialized
INFO - 2016-12-26 21:46:12 --> Output Class Initialized
INFO - 2016-12-26 21:46:12 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:12 --> Input Class Initialized
INFO - 2016-12-26 21:46:12 --> Language Class Initialized
INFO - 2016-12-26 21:46:12 --> Loader Class Initialized
INFO - 2016-12-26 21:46:12 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:12 --> Controller Class Initialized
INFO - 2016-12-26 21:46:12 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:12 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:12 --> Total execution time: 0.0132
INFO - 2016-12-26 21:46:12 --> Config Class Initialized
INFO - 2016-12-26 21:46:12 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:12 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:12 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:12 --> URI Class Initialized
INFO - 2016-12-26 21:46:12 --> Router Class Initialized
INFO - 2016-12-26 21:46:12 --> Output Class Initialized
INFO - 2016-12-26 21:46:12 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:12 --> Input Class Initialized
INFO - 2016-12-26 21:46:12 --> Language Class Initialized
INFO - 2016-12-26 21:46:12 --> Loader Class Initialized
INFO - 2016-12-26 21:46:12 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:12 --> Controller Class Initialized
INFO - 2016-12-26 21:46:12 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:12 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:12 --> Total execution time: 0.0212
INFO - 2016-12-26 21:46:20 --> Config Class Initialized
INFO - 2016-12-26 21:46:20 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:20 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:20 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:20 --> URI Class Initialized
DEBUG - 2016-12-26 21:46:20 --> No URI present. Default controller set.
INFO - 2016-12-26 21:46:20 --> Router Class Initialized
INFO - 2016-12-26 21:46:20 --> Output Class Initialized
INFO - 2016-12-26 21:46:20 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:20 --> Input Class Initialized
INFO - 2016-12-26 21:46:20 --> Language Class Initialized
INFO - 2016-12-26 21:46:20 --> Loader Class Initialized
INFO - 2016-12-26 21:46:20 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:20 --> Controller Class Initialized
INFO - 2016-12-26 21:46:20 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:20 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:20 --> Total execution time: 0.0145
INFO - 2016-12-26 21:46:20 --> Config Class Initialized
INFO - 2016-12-26 21:46:20 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:20 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:20 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:20 --> URI Class Initialized
INFO - 2016-12-26 21:46:20 --> Router Class Initialized
INFO - 2016-12-26 21:46:20 --> Output Class Initialized
INFO - 2016-12-26 21:46:20 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:20 --> Input Class Initialized
INFO - 2016-12-26 21:46:20 --> Language Class Initialized
INFO - 2016-12-26 21:46:20 --> Loader Class Initialized
INFO - 2016-12-26 21:46:20 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:20 --> Controller Class Initialized
INFO - 2016-12-26 21:46:20 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:20 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:20 --> Total execution time: 0.0150
INFO - 2016-12-26 21:46:29 --> Config Class Initialized
INFO - 2016-12-26 21:46:29 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:29 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:29 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:29 --> URI Class Initialized
DEBUG - 2016-12-26 21:46:29 --> No URI present. Default controller set.
INFO - 2016-12-26 21:46:29 --> Router Class Initialized
INFO - 2016-12-26 21:46:29 --> Output Class Initialized
INFO - 2016-12-26 21:46:29 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:29 --> Input Class Initialized
INFO - 2016-12-26 21:46:29 --> Language Class Initialized
INFO - 2016-12-26 21:46:29 --> Loader Class Initialized
INFO - 2016-12-26 21:46:29 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:29 --> Controller Class Initialized
INFO - 2016-12-26 21:46:29 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:29 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:29 --> Total execution time: 0.0140
INFO - 2016-12-26 21:46:29 --> Config Class Initialized
INFO - 2016-12-26 21:46:29 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:29 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:29 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:29 --> URI Class Initialized
INFO - 2016-12-26 21:46:29 --> Router Class Initialized
INFO - 2016-12-26 21:46:29 --> Output Class Initialized
INFO - 2016-12-26 21:46:29 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:29 --> Input Class Initialized
INFO - 2016-12-26 21:46:29 --> Language Class Initialized
INFO - 2016-12-26 21:46:29 --> Loader Class Initialized
INFO - 2016-12-26 21:46:29 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:29 --> Controller Class Initialized
INFO - 2016-12-26 21:46:29 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:29 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:29 --> Total execution time: 0.0133
INFO - 2016-12-26 21:46:38 --> Config Class Initialized
INFO - 2016-12-26 21:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:38 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:38 --> URI Class Initialized
DEBUG - 2016-12-26 21:46:38 --> No URI present. Default controller set.
INFO - 2016-12-26 21:46:38 --> Router Class Initialized
INFO - 2016-12-26 21:46:38 --> Output Class Initialized
INFO - 2016-12-26 21:46:38 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:38 --> Input Class Initialized
INFO - 2016-12-26 21:46:38 --> Language Class Initialized
INFO - 2016-12-26 21:46:38 --> Loader Class Initialized
INFO - 2016-12-26 21:46:38 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:38 --> Controller Class Initialized
INFO - 2016-12-26 21:46:38 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:38 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:38 --> Total execution time: 0.0133
INFO - 2016-12-26 21:46:39 --> Config Class Initialized
INFO - 2016-12-26 21:46:39 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:46:39 --> UTF-8 Support Enabled
INFO - 2016-12-26 21:46:39 --> Utf8 Class Initialized
INFO - 2016-12-26 21:46:39 --> URI Class Initialized
INFO - 2016-12-26 21:46:39 --> Router Class Initialized
INFO - 2016-12-26 21:46:39 --> Output Class Initialized
INFO - 2016-12-26 21:46:39 --> Security Class Initialized
DEBUG - 2016-12-26 21:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 21:46:39 --> Input Class Initialized
INFO - 2016-12-26 21:46:39 --> Language Class Initialized
INFO - 2016-12-26 21:46:39 --> Loader Class Initialized
INFO - 2016-12-26 21:46:39 --> Database Driver Class Initialized
INFO - 2016-12-26 21:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 21:46:39 --> Controller Class Initialized
INFO - 2016-12-26 21:46:39 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 21:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 21:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 21:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 21:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 21:46:39 --> Final output sent to browser
DEBUG - 2016-12-26 21:46:39 --> Total execution time: 0.0138
INFO - 2016-12-26 22:09:31 --> Config Class Initialized
INFO - 2016-12-26 22:09:31 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:09:31 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:09:31 --> Utf8 Class Initialized
INFO - 2016-12-26 22:09:31 --> URI Class Initialized
DEBUG - 2016-12-26 22:09:31 --> No URI present. Default controller set.
INFO - 2016-12-26 22:09:31 --> Router Class Initialized
INFO - 2016-12-26 22:09:31 --> Output Class Initialized
INFO - 2016-12-26 22:09:31 --> Security Class Initialized
DEBUG - 2016-12-26 22:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:09:31 --> Input Class Initialized
INFO - 2016-12-26 22:09:31 --> Language Class Initialized
INFO - 2016-12-26 22:09:31 --> Loader Class Initialized
INFO - 2016-12-26 22:09:31 --> Database Driver Class Initialized
INFO - 2016-12-26 22:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:09:31 --> Controller Class Initialized
INFO - 2016-12-26 22:09:31 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:09:31 --> Final output sent to browser
DEBUG - 2016-12-26 22:09:31 --> Total execution time: 0.6148
INFO - 2016-12-26 22:09:32 --> Config Class Initialized
INFO - 2016-12-26 22:09:32 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:09:32 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:09:32 --> Utf8 Class Initialized
INFO - 2016-12-26 22:09:32 --> URI Class Initialized
INFO - 2016-12-26 22:09:32 --> Router Class Initialized
INFO - 2016-12-26 22:09:32 --> Output Class Initialized
INFO - 2016-12-26 22:09:32 --> Security Class Initialized
DEBUG - 2016-12-26 22:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:09:32 --> Input Class Initialized
INFO - 2016-12-26 22:09:32 --> Language Class Initialized
INFO - 2016-12-26 22:09:32 --> Loader Class Initialized
INFO - 2016-12-26 22:09:32 --> Database Driver Class Initialized
INFO - 2016-12-26 22:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:09:32 --> Controller Class Initialized
INFO - 2016-12-26 22:09:32 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:09:32 --> Final output sent to browser
DEBUG - 2016-12-26 22:09:32 --> Total execution time: 0.0159
INFO - 2016-12-26 22:09:57 --> Config Class Initialized
INFO - 2016-12-26 22:09:57 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:09:57 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:09:57 --> Utf8 Class Initialized
INFO - 2016-12-26 22:09:57 --> URI Class Initialized
DEBUG - 2016-12-26 22:09:57 --> No URI present. Default controller set.
INFO - 2016-12-26 22:09:57 --> Router Class Initialized
INFO - 2016-12-26 22:09:57 --> Output Class Initialized
INFO - 2016-12-26 22:09:57 --> Security Class Initialized
DEBUG - 2016-12-26 22:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:09:57 --> Input Class Initialized
INFO - 2016-12-26 22:09:57 --> Language Class Initialized
INFO - 2016-12-26 22:09:57 --> Loader Class Initialized
INFO - 2016-12-26 22:09:57 --> Database Driver Class Initialized
INFO - 2016-12-26 22:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:09:57 --> Controller Class Initialized
INFO - 2016-12-26 22:09:57 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:09:57 --> Final output sent to browser
DEBUG - 2016-12-26 22:09:57 --> Total execution time: 0.0154
INFO - 2016-12-26 22:09:58 --> Config Class Initialized
INFO - 2016-12-26 22:09:58 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:09:58 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:09:58 --> Utf8 Class Initialized
INFO - 2016-12-26 22:09:58 --> URI Class Initialized
INFO - 2016-12-26 22:09:58 --> Router Class Initialized
INFO - 2016-12-26 22:09:58 --> Output Class Initialized
INFO - 2016-12-26 22:09:58 --> Security Class Initialized
DEBUG - 2016-12-26 22:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:09:58 --> Input Class Initialized
INFO - 2016-12-26 22:09:58 --> Language Class Initialized
INFO - 2016-12-26 22:09:58 --> Loader Class Initialized
INFO - 2016-12-26 22:09:58 --> Database Driver Class Initialized
INFO - 2016-12-26 22:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:09:58 --> Controller Class Initialized
INFO - 2016-12-26 22:09:58 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:09:58 --> Final output sent to browser
DEBUG - 2016-12-26 22:09:58 --> Total execution time: 0.0142
INFO - 2016-12-26 22:10:08 --> Config Class Initialized
INFO - 2016-12-26 22:10:08 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:10:08 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:10:08 --> Utf8 Class Initialized
INFO - 2016-12-26 22:10:08 --> URI Class Initialized
DEBUG - 2016-12-26 22:10:08 --> No URI present. Default controller set.
INFO - 2016-12-26 22:10:08 --> Router Class Initialized
INFO - 2016-12-26 22:10:08 --> Output Class Initialized
INFO - 2016-12-26 22:10:08 --> Security Class Initialized
DEBUG - 2016-12-26 22:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:10:08 --> Input Class Initialized
INFO - 2016-12-26 22:10:08 --> Language Class Initialized
INFO - 2016-12-26 22:10:08 --> Loader Class Initialized
INFO - 2016-12-26 22:10:08 --> Database Driver Class Initialized
INFO - 2016-12-26 22:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:10:08 --> Controller Class Initialized
INFO - 2016-12-26 22:10:08 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:10:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:10:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:10:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:10:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:10:08 --> Final output sent to browser
DEBUG - 2016-12-26 22:10:08 --> Total execution time: 0.0126
INFO - 2016-12-26 22:10:09 --> Config Class Initialized
INFO - 2016-12-26 22:10:09 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:10:09 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:10:09 --> Utf8 Class Initialized
INFO - 2016-12-26 22:10:09 --> URI Class Initialized
INFO - 2016-12-26 22:10:09 --> Router Class Initialized
INFO - 2016-12-26 22:10:09 --> Output Class Initialized
INFO - 2016-12-26 22:10:09 --> Security Class Initialized
DEBUG - 2016-12-26 22:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:10:09 --> Input Class Initialized
INFO - 2016-12-26 22:10:09 --> Language Class Initialized
INFO - 2016-12-26 22:10:09 --> Loader Class Initialized
INFO - 2016-12-26 22:10:09 --> Database Driver Class Initialized
INFO - 2016-12-26 22:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:10:09 --> Controller Class Initialized
INFO - 2016-12-26 22:10:09 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:10:09 --> Final output sent to browser
DEBUG - 2016-12-26 22:10:09 --> Total execution time: 0.0142
INFO - 2016-12-26 22:10:25 --> Config Class Initialized
INFO - 2016-12-26 22:10:25 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:10:25 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:10:25 --> Utf8 Class Initialized
INFO - 2016-12-26 22:10:25 --> URI Class Initialized
DEBUG - 2016-12-26 22:10:25 --> No URI present. Default controller set.
INFO - 2016-12-26 22:10:25 --> Router Class Initialized
INFO - 2016-12-26 22:10:25 --> Output Class Initialized
INFO - 2016-12-26 22:10:25 --> Security Class Initialized
DEBUG - 2016-12-26 22:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:10:25 --> Input Class Initialized
INFO - 2016-12-26 22:10:25 --> Language Class Initialized
INFO - 2016-12-26 22:10:25 --> Loader Class Initialized
INFO - 2016-12-26 22:10:25 --> Database Driver Class Initialized
INFO - 2016-12-26 22:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:10:25 --> Controller Class Initialized
INFO - 2016-12-26 22:10:25 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:10:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:10:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:10:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:10:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:10:25 --> Final output sent to browser
DEBUG - 2016-12-26 22:10:25 --> Total execution time: 0.0598
INFO - 2016-12-26 22:10:25 --> Config Class Initialized
INFO - 2016-12-26 22:10:25 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:10:25 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:10:25 --> Utf8 Class Initialized
INFO - 2016-12-26 22:10:25 --> URI Class Initialized
INFO - 2016-12-26 22:10:25 --> Router Class Initialized
INFO - 2016-12-26 22:10:25 --> Output Class Initialized
INFO - 2016-12-26 22:10:25 --> Security Class Initialized
DEBUG - 2016-12-26 22:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:10:25 --> Input Class Initialized
INFO - 2016-12-26 22:10:25 --> Language Class Initialized
INFO - 2016-12-26 22:10:25 --> Loader Class Initialized
INFO - 2016-12-26 22:10:26 --> Database Driver Class Initialized
INFO - 2016-12-26 22:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:10:26 --> Controller Class Initialized
INFO - 2016-12-26 22:10:26 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:10:26 --> Final output sent to browser
DEBUG - 2016-12-26 22:10:26 --> Total execution time: 0.0647
INFO - 2016-12-26 22:11:36 --> Config Class Initialized
INFO - 2016-12-26 22:11:36 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:11:36 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:11:36 --> Utf8 Class Initialized
INFO - 2016-12-26 22:11:36 --> URI Class Initialized
DEBUG - 2016-12-26 22:11:36 --> No URI present. Default controller set.
INFO - 2016-12-26 22:11:36 --> Router Class Initialized
INFO - 2016-12-26 22:11:36 --> Output Class Initialized
INFO - 2016-12-26 22:11:36 --> Security Class Initialized
DEBUG - 2016-12-26 22:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:11:36 --> Input Class Initialized
INFO - 2016-12-26 22:11:36 --> Language Class Initialized
INFO - 2016-12-26 22:11:36 --> Loader Class Initialized
INFO - 2016-12-26 22:11:36 --> Database Driver Class Initialized
INFO - 2016-12-26 22:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:11:36 --> Controller Class Initialized
INFO - 2016-12-26 22:11:36 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:11:36 --> Final output sent to browser
DEBUG - 2016-12-26 22:11:36 --> Total execution time: 0.0136
INFO - 2016-12-26 22:11:36 --> Config Class Initialized
INFO - 2016-12-26 22:11:36 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:11:36 --> UTF-8 Support Enabled
INFO - 2016-12-26 22:11:36 --> Utf8 Class Initialized
INFO - 2016-12-26 22:11:36 --> URI Class Initialized
INFO - 2016-12-26 22:11:36 --> Router Class Initialized
INFO - 2016-12-26 22:11:36 --> Output Class Initialized
INFO - 2016-12-26 22:11:36 --> Security Class Initialized
DEBUG - 2016-12-26 22:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-26 22:11:36 --> Input Class Initialized
INFO - 2016-12-26 22:11:36 --> Language Class Initialized
INFO - 2016-12-26 22:11:36 --> Loader Class Initialized
INFO - 2016-12-26 22:11:36 --> Database Driver Class Initialized
INFO - 2016-12-26 22:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-26 22:11:36 --> Controller Class Initialized
INFO - 2016-12-26 22:11:36 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-26 22:11:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-26 22:11:36 --> Final output sent to browser
DEBUG - 2016-12-26 22:11:36 --> Total execution time: 0.0142

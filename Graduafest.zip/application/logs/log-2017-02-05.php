<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-05 03:11:20 --> Config Class Initialized
INFO - 2017-02-05 03:11:21 --> Hooks Class Initialized
DEBUG - 2017-02-05 03:11:21 --> UTF-8 Support Enabled
INFO - 2017-02-05 03:11:21 --> Utf8 Class Initialized
INFO - 2017-02-05 03:11:21 --> URI Class Initialized
DEBUG - 2017-02-05 03:11:21 --> No URI present. Default controller set.
INFO - 2017-02-05 03:11:21 --> Router Class Initialized
INFO - 2017-02-05 03:11:21 --> Output Class Initialized
INFO - 2017-02-05 03:11:21 --> Security Class Initialized
DEBUG - 2017-02-05 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 03:11:21 --> Input Class Initialized
INFO - 2017-02-05 03:11:21 --> Language Class Initialized
INFO - 2017-02-05 03:11:21 --> Loader Class Initialized
INFO - 2017-02-05 03:11:21 --> Database Driver Class Initialized
INFO - 2017-02-05 03:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 03:11:22 --> Controller Class Initialized
INFO - 2017-02-05 03:11:22 --> Helper loaded: url_helper
DEBUG - 2017-02-05 03:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 03:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 03:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 03:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 03:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 03:11:22 --> Final output sent to browser
DEBUG - 2017-02-05 03:11:22 --> Total execution time: 2.0877
INFO - 2017-02-05 03:11:29 --> Config Class Initialized
INFO - 2017-02-05 03:11:29 --> Hooks Class Initialized
DEBUG - 2017-02-05 03:11:29 --> UTF-8 Support Enabled
INFO - 2017-02-05 03:11:29 --> Utf8 Class Initialized
INFO - 2017-02-05 03:11:29 --> URI Class Initialized
INFO - 2017-02-05 03:11:29 --> Router Class Initialized
INFO - 2017-02-05 03:11:29 --> Output Class Initialized
INFO - 2017-02-05 03:11:29 --> Security Class Initialized
DEBUG - 2017-02-05 03:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 03:11:29 --> Input Class Initialized
INFO - 2017-02-05 03:11:29 --> Language Class Initialized
INFO - 2017-02-05 03:11:29 --> Loader Class Initialized
INFO - 2017-02-05 03:11:29 --> Database Driver Class Initialized
INFO - 2017-02-05 03:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 03:11:29 --> Controller Class Initialized
INFO - 2017-02-05 03:11:29 --> Helper loaded: url_helper
DEBUG - 2017-02-05 03:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 03:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 03:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 03:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 03:11:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 03:11:29 --> Final output sent to browser
DEBUG - 2017-02-05 03:11:29 --> Total execution time: 0.0136
INFO - 2017-02-05 03:12:07 --> Config Class Initialized
INFO - 2017-02-05 03:12:07 --> Hooks Class Initialized
DEBUG - 2017-02-05 03:12:07 --> UTF-8 Support Enabled
INFO - 2017-02-05 03:12:07 --> Utf8 Class Initialized
INFO - 2017-02-05 03:12:07 --> URI Class Initialized
INFO - 2017-02-05 03:12:07 --> Router Class Initialized
INFO - 2017-02-05 03:12:07 --> Output Class Initialized
INFO - 2017-02-05 03:12:07 --> Security Class Initialized
DEBUG - 2017-02-05 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 03:12:07 --> Input Class Initialized
INFO - 2017-02-05 03:12:07 --> Language Class Initialized
INFO - 2017-02-05 03:12:07 --> Loader Class Initialized
INFO - 2017-02-05 03:12:08 --> Database Driver Class Initialized
INFO - 2017-02-05 03:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 03:12:08 --> Controller Class Initialized
INFO - 2017-02-05 03:12:08 --> Helper loaded: url_helper
DEBUG - 2017-02-05 03:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 03:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-05 03:12:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-05 03:12:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-05 03:12:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-05 03:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 03:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 03:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 03:12:08 --> Final output sent to browser
DEBUG - 2017-02-05 03:12:08 --> Total execution time: 1.3762
INFO - 2017-02-05 03:12:11 --> Config Class Initialized
INFO - 2017-02-05 03:12:11 --> Hooks Class Initialized
DEBUG - 2017-02-05 03:12:11 --> UTF-8 Support Enabled
INFO - 2017-02-05 03:12:11 --> Utf8 Class Initialized
INFO - 2017-02-05 03:12:11 --> URI Class Initialized
INFO - 2017-02-05 03:12:11 --> Router Class Initialized
INFO - 2017-02-05 03:12:11 --> Output Class Initialized
INFO - 2017-02-05 03:12:11 --> Security Class Initialized
DEBUG - 2017-02-05 03:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 03:12:11 --> Input Class Initialized
INFO - 2017-02-05 03:12:11 --> Language Class Initialized
INFO - 2017-02-05 03:12:11 --> Loader Class Initialized
INFO - 2017-02-05 03:12:11 --> Database Driver Class Initialized
INFO - 2017-02-05 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 03:12:11 --> Controller Class Initialized
INFO - 2017-02-05 03:12:11 --> Helper loaded: url_helper
DEBUG - 2017-02-05 03:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 03:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 03:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 03:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 03:12:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 03:12:11 --> Final output sent to browser
DEBUG - 2017-02-05 03:12:11 --> Total execution time: 0.4381
INFO - 2017-02-05 04:43:46 --> Config Class Initialized
INFO - 2017-02-05 04:43:46 --> Hooks Class Initialized
DEBUG - 2017-02-05 04:43:46 --> UTF-8 Support Enabled
INFO - 2017-02-05 04:43:46 --> Utf8 Class Initialized
INFO - 2017-02-05 04:43:46 --> URI Class Initialized
INFO - 2017-02-05 04:43:46 --> Router Class Initialized
INFO - 2017-02-05 04:43:46 --> Output Class Initialized
INFO - 2017-02-05 04:43:46 --> Security Class Initialized
DEBUG - 2017-02-05 04:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 04:43:46 --> Input Class Initialized
INFO - 2017-02-05 04:43:46 --> Language Class Initialized
INFO - 2017-02-05 04:43:46 --> Loader Class Initialized
INFO - 2017-02-05 04:43:46 --> Database Driver Class Initialized
INFO - 2017-02-05 04:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 04:43:46 --> Controller Class Initialized
INFO - 2017-02-05 04:43:47 --> Helper loaded: date_helper
DEBUG - 2017-02-05 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 04:43:47 --> Helper loaded: url_helper
INFO - 2017-02-05 04:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 04:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-05 04:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-05 04:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-05 04:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 04:43:47 --> Final output sent to browser
DEBUG - 2017-02-05 04:43:47 --> Total execution time: 1.8119
INFO - 2017-02-05 04:43:56 --> Config Class Initialized
INFO - 2017-02-05 04:43:56 --> Hooks Class Initialized
DEBUG - 2017-02-05 04:43:56 --> UTF-8 Support Enabled
INFO - 2017-02-05 04:43:56 --> Utf8 Class Initialized
INFO - 2017-02-05 04:43:56 --> URI Class Initialized
INFO - 2017-02-05 04:43:56 --> Router Class Initialized
INFO - 2017-02-05 04:43:56 --> Output Class Initialized
INFO - 2017-02-05 04:43:56 --> Security Class Initialized
DEBUG - 2017-02-05 04:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 04:43:56 --> Input Class Initialized
INFO - 2017-02-05 04:43:56 --> Language Class Initialized
INFO - 2017-02-05 04:43:56 --> Loader Class Initialized
INFO - 2017-02-05 04:43:56 --> Database Driver Class Initialized
INFO - 2017-02-05 04:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 04:43:56 --> Controller Class Initialized
INFO - 2017-02-05 04:43:56 --> Helper loaded: url_helper
DEBUG - 2017-02-05 04:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 04:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 04:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 04:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 04:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 04:43:56 --> Final output sent to browser
DEBUG - 2017-02-05 04:43:56 --> Total execution time: 0.5460
INFO - 2017-02-05 07:29:27 --> Config Class Initialized
INFO - 2017-02-05 07:29:27 --> Hooks Class Initialized
DEBUG - 2017-02-05 07:29:27 --> UTF-8 Support Enabled
INFO - 2017-02-05 07:29:27 --> Utf8 Class Initialized
INFO - 2017-02-05 07:29:27 --> URI Class Initialized
DEBUG - 2017-02-05 07:29:27 --> No URI present. Default controller set.
INFO - 2017-02-05 07:29:27 --> Router Class Initialized
INFO - 2017-02-05 07:29:27 --> Output Class Initialized
INFO - 2017-02-05 07:29:27 --> Security Class Initialized
DEBUG - 2017-02-05 07:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 07:29:27 --> Input Class Initialized
INFO - 2017-02-05 07:29:27 --> Language Class Initialized
INFO - 2017-02-05 07:29:27 --> Loader Class Initialized
INFO - 2017-02-05 07:29:27 --> Database Driver Class Initialized
INFO - 2017-02-05 07:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 07:29:28 --> Controller Class Initialized
INFO - 2017-02-05 07:29:28 --> Helper loaded: url_helper
DEBUG - 2017-02-05 07:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 07:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 07:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 07:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 07:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 07:29:28 --> Final output sent to browser
DEBUG - 2017-02-05 07:29:28 --> Total execution time: 1.0696
INFO - 2017-02-05 07:29:36 --> Config Class Initialized
INFO - 2017-02-05 07:29:36 --> Hooks Class Initialized
DEBUG - 2017-02-05 07:29:36 --> UTF-8 Support Enabled
INFO - 2017-02-05 07:29:36 --> Utf8 Class Initialized
INFO - 2017-02-05 07:29:36 --> URI Class Initialized
INFO - 2017-02-05 07:29:36 --> Router Class Initialized
INFO - 2017-02-05 07:29:36 --> Output Class Initialized
INFO - 2017-02-05 07:29:36 --> Security Class Initialized
DEBUG - 2017-02-05 07:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 07:29:36 --> Input Class Initialized
INFO - 2017-02-05 07:29:36 --> Language Class Initialized
INFO - 2017-02-05 07:29:36 --> Loader Class Initialized
INFO - 2017-02-05 07:29:36 --> Database Driver Class Initialized
INFO - 2017-02-05 07:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 07:29:36 --> Controller Class Initialized
INFO - 2017-02-05 07:29:36 --> Helper loaded: url_helper
DEBUG - 2017-02-05 07:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 07:29:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 07:29:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 07:29:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 07:29:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 07:29:36 --> Final output sent to browser
DEBUG - 2017-02-05 07:29:36 --> Total execution time: 0.0136
INFO - 2017-02-05 14:00:47 --> Config Class Initialized
INFO - 2017-02-05 14:00:47 --> Hooks Class Initialized
DEBUG - 2017-02-05 14:00:48 --> UTF-8 Support Enabled
INFO - 2017-02-05 14:00:48 --> Utf8 Class Initialized
INFO - 2017-02-05 14:00:48 --> URI Class Initialized
INFO - 2017-02-05 14:00:48 --> Router Class Initialized
INFO - 2017-02-05 14:00:48 --> Output Class Initialized
INFO - 2017-02-05 14:00:48 --> Security Class Initialized
DEBUG - 2017-02-05 14:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 14:00:48 --> Input Class Initialized
INFO - 2017-02-05 14:00:48 --> Language Class Initialized
INFO - 2017-02-05 14:00:48 --> Loader Class Initialized
INFO - 2017-02-05 14:00:48 --> Database Driver Class Initialized
INFO - 2017-02-05 14:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 14:00:48 --> Controller Class Initialized
INFO - 2017-02-05 14:00:48 --> Helper loaded: url_helper
DEBUG - 2017-02-05 14:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 14:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 14:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 14:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 14:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 14:00:49 --> Final output sent to browser
DEBUG - 2017-02-05 14:00:49 --> Total execution time: 1.3626
INFO - 2017-02-05 20:02:34 --> Config Class Initialized
INFO - 2017-02-05 20:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:02:34 --> Utf8 Class Initialized
INFO - 2017-02-05 20:02:34 --> URI Class Initialized
DEBUG - 2017-02-05 20:02:35 --> No URI present. Default controller set.
INFO - 2017-02-05 20:02:35 --> Router Class Initialized
INFO - 2017-02-05 20:02:35 --> Output Class Initialized
INFO - 2017-02-05 20:02:35 --> Security Class Initialized
DEBUG - 2017-02-05 20:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:02:35 --> Input Class Initialized
INFO - 2017-02-05 20:02:35 --> Language Class Initialized
INFO - 2017-02-05 20:02:35 --> Loader Class Initialized
INFO - 2017-02-05 20:02:35 --> Database Driver Class Initialized
INFO - 2017-02-05 20:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:02:35 --> Controller Class Initialized
INFO - 2017-02-05 20:02:35 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:02:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:02:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:02:36 --> Final output sent to browser
DEBUG - 2017-02-05 20:02:36 --> Total execution time: 1.4946
INFO - 2017-02-05 20:03:25 --> Config Class Initialized
INFO - 2017-02-05 20:03:25 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:03:25 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:03:25 --> Utf8 Class Initialized
INFO - 2017-02-05 20:03:25 --> URI Class Initialized
INFO - 2017-02-05 20:03:25 --> Router Class Initialized
INFO - 2017-02-05 20:03:25 --> Output Class Initialized
INFO - 2017-02-05 20:03:25 --> Security Class Initialized
DEBUG - 2017-02-05 20:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:03:25 --> Input Class Initialized
INFO - 2017-02-05 20:03:25 --> Language Class Initialized
INFO - 2017-02-05 20:03:25 --> Loader Class Initialized
INFO - 2017-02-05 20:03:25 --> Database Driver Class Initialized
INFO - 2017-02-05 20:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:03:25 --> Controller Class Initialized
INFO - 2017-02-05 20:03:25 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:03:25 --> Final output sent to browser
DEBUG - 2017-02-05 20:03:25 --> Total execution time: 0.0145
INFO - 2017-02-05 20:23:36 --> Config Class Initialized
INFO - 2017-02-05 20:23:36 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:23:36 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:23:36 --> Utf8 Class Initialized
INFO - 2017-02-05 20:23:36 --> URI Class Initialized
DEBUG - 2017-02-05 20:23:36 --> No URI present. Default controller set.
INFO - 2017-02-05 20:23:36 --> Router Class Initialized
INFO - 2017-02-05 20:23:36 --> Output Class Initialized
INFO - 2017-02-05 20:23:36 --> Security Class Initialized
DEBUG - 2017-02-05 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:23:36 --> Input Class Initialized
INFO - 2017-02-05 20:23:36 --> Language Class Initialized
INFO - 2017-02-05 20:23:36 --> Loader Class Initialized
INFO - 2017-02-05 20:23:36 --> Database Driver Class Initialized
INFO - 2017-02-05 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:23:36 --> Controller Class Initialized
INFO - 2017-02-05 20:23:36 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:23:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:23:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:23:36 --> Final output sent to browser
DEBUG - 2017-02-05 20:23:36 --> Total execution time: 0.0219
INFO - 2017-02-05 20:24:40 --> Config Class Initialized
INFO - 2017-02-05 20:24:40 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:24:40 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:24:40 --> Utf8 Class Initialized
INFO - 2017-02-05 20:24:40 --> URI Class Initialized
DEBUG - 2017-02-05 20:24:40 --> No URI present. Default controller set.
INFO - 2017-02-05 20:24:40 --> Router Class Initialized
INFO - 2017-02-05 20:24:40 --> Output Class Initialized
INFO - 2017-02-05 20:24:40 --> Security Class Initialized
DEBUG - 2017-02-05 20:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:24:40 --> Input Class Initialized
INFO - 2017-02-05 20:24:40 --> Language Class Initialized
INFO - 2017-02-05 20:24:40 --> Loader Class Initialized
INFO - 2017-02-05 20:24:40 --> Database Driver Class Initialized
INFO - 2017-02-05 20:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:24:40 --> Controller Class Initialized
INFO - 2017-02-05 20:24:40 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:24:40 --> Final output sent to browser
DEBUG - 2017-02-05 20:24:40 --> Total execution time: 0.0136
INFO - 2017-02-05 20:24:52 --> Config Class Initialized
INFO - 2017-02-05 20:24:52 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:24:52 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:24:52 --> Utf8 Class Initialized
INFO - 2017-02-05 20:24:52 --> URI Class Initialized
INFO - 2017-02-05 20:24:52 --> Router Class Initialized
INFO - 2017-02-05 20:24:52 --> Output Class Initialized
INFO - 2017-02-05 20:24:52 --> Security Class Initialized
DEBUG - 2017-02-05 20:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:24:52 --> Input Class Initialized
INFO - 2017-02-05 20:24:52 --> Language Class Initialized
INFO - 2017-02-05 20:24:52 --> Loader Class Initialized
INFO - 2017-02-05 20:24:52 --> Database Driver Class Initialized
INFO - 2017-02-05 20:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:24:52 --> Controller Class Initialized
INFO - 2017-02-05 20:24:52 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:24:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:24:52 --> Final output sent to browser
DEBUG - 2017-02-05 20:24:52 --> Total execution time: 0.0133
INFO - 2017-02-05 20:26:02 --> Config Class Initialized
INFO - 2017-02-05 20:26:02 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:26:02 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:26:02 --> Utf8 Class Initialized
INFO - 2017-02-05 20:26:02 --> URI Class Initialized
INFO - 2017-02-05 20:26:02 --> Router Class Initialized
INFO - 2017-02-05 20:26:02 --> Output Class Initialized
INFO - 2017-02-05 20:26:02 --> Security Class Initialized
DEBUG - 2017-02-05 20:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:26:02 --> Input Class Initialized
INFO - 2017-02-05 20:26:02 --> Language Class Initialized
INFO - 2017-02-05 20:26:02 --> Loader Class Initialized
INFO - 2017-02-05 20:26:02 --> Database Driver Class Initialized
INFO - 2017-02-05 20:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:26:02 --> Controller Class Initialized
INFO - 2017-02-05 20:26:02 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:26:04 --> Config Class Initialized
INFO - 2017-02-05 20:26:04 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:26:04 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:26:04 --> Utf8 Class Initialized
INFO - 2017-02-05 20:26:04 --> URI Class Initialized
INFO - 2017-02-05 20:26:04 --> Router Class Initialized
INFO - 2017-02-05 20:26:04 --> Output Class Initialized
INFO - 2017-02-05 20:26:04 --> Security Class Initialized
DEBUG - 2017-02-05 20:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:26:04 --> Input Class Initialized
INFO - 2017-02-05 20:26:04 --> Language Class Initialized
INFO - 2017-02-05 20:26:04 --> Loader Class Initialized
INFO - 2017-02-05 20:26:04 --> Database Driver Class Initialized
INFO - 2017-02-05 20:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:26:04 --> Controller Class Initialized
INFO - 2017-02-05 20:26:04 --> Helper loaded: date_helper
DEBUG - 2017-02-05 20:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:26:04 --> Helper loaded: url_helper
INFO - 2017-02-05 20:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-05 20:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-05 20:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-05 20:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:26:04 --> Final output sent to browser
DEBUG - 2017-02-05 20:26:04 --> Total execution time: 0.3049
INFO - 2017-02-05 20:26:42 --> Config Class Initialized
INFO - 2017-02-05 20:26:42 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:26:42 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:26:42 --> Utf8 Class Initialized
INFO - 2017-02-05 20:26:42 --> URI Class Initialized
INFO - 2017-02-05 20:26:42 --> Router Class Initialized
INFO - 2017-02-05 20:26:42 --> Output Class Initialized
INFO - 2017-02-05 20:26:42 --> Security Class Initialized
DEBUG - 2017-02-05 20:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:26:42 --> Input Class Initialized
INFO - 2017-02-05 20:26:42 --> Language Class Initialized
INFO - 2017-02-05 20:26:42 --> Loader Class Initialized
INFO - 2017-02-05 20:26:42 --> Database Driver Class Initialized
INFO - 2017-02-05 20:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:26:42 --> Controller Class Initialized
INFO - 2017-02-05 20:26:42 --> Upload Class Initialized
INFO - 2017-02-05 20:26:42 --> Helper loaded: date_helper
DEBUG - 2017-02-05 20:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:26:42 --> Helper loaded: url_helper
INFO - 2017-02-05 20:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-05 20:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-02-05 20:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-02-05 20:26:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-05 20:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:26:42 --> Final output sent to browser
DEBUG - 2017-02-05 20:26:42 --> Total execution time: 0.0899
INFO - 2017-02-05 20:26:44 --> Config Class Initialized
INFO - 2017-02-05 20:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:26:44 --> Utf8 Class Initialized
INFO - 2017-02-05 20:26:44 --> URI Class Initialized
INFO - 2017-02-05 20:26:44 --> Router Class Initialized
INFO - 2017-02-05 20:26:44 --> Output Class Initialized
INFO - 2017-02-05 20:26:44 --> Security Class Initialized
DEBUG - 2017-02-05 20:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:26:44 --> Input Class Initialized
INFO - 2017-02-05 20:26:44 --> Language Class Initialized
INFO - 2017-02-05 20:26:44 --> Loader Class Initialized
INFO - 2017-02-05 20:26:44 --> Database Driver Class Initialized
INFO - 2017-02-05 20:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:26:44 --> Controller Class Initialized
INFO - 2017-02-05 20:26:44 --> Upload Class Initialized
INFO - 2017-02-05 20:26:44 --> Helper loaded: date_helper
DEBUG - 2017-02-05 20:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:26:44 --> Helper loaded: url_helper
INFO - 2017-02-05 20:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-05 20:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-02-05 20:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-02-05 20:26:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-05 20:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:26:44 --> Final output sent to browser
DEBUG - 2017-02-05 20:26:44 --> Total execution time: 0.0157
INFO - 2017-02-05 20:27:10 --> Config Class Initialized
INFO - 2017-02-05 20:27:10 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:27:10 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:27:10 --> Utf8 Class Initialized
INFO - 2017-02-05 20:27:10 --> URI Class Initialized
INFO - 2017-02-05 20:27:10 --> Router Class Initialized
INFO - 2017-02-05 20:27:10 --> Output Class Initialized
INFO - 2017-02-05 20:27:10 --> Security Class Initialized
DEBUG - 2017-02-05 20:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:27:10 --> Input Class Initialized
INFO - 2017-02-05 20:27:10 --> Language Class Initialized
INFO - 2017-02-05 20:27:10 --> Loader Class Initialized
INFO - 2017-02-05 20:27:10 --> Database Driver Class Initialized
INFO - 2017-02-05 20:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:27:10 --> Controller Class Initialized
INFO - 2017-02-05 20:27:10 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:27:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:27:10 --> Final output sent to browser
DEBUG - 2017-02-05 20:27:10 --> Total execution time: 0.0157
INFO - 2017-02-05 20:27:31 --> Config Class Initialized
INFO - 2017-02-05 20:27:31 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:27:31 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:27:31 --> Utf8 Class Initialized
INFO - 2017-02-05 20:27:31 --> URI Class Initialized
INFO - 2017-02-05 20:27:31 --> Router Class Initialized
INFO - 2017-02-05 20:27:31 --> Output Class Initialized
INFO - 2017-02-05 20:27:31 --> Security Class Initialized
DEBUG - 2017-02-05 20:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:27:31 --> Input Class Initialized
INFO - 2017-02-05 20:27:31 --> Language Class Initialized
INFO - 2017-02-05 20:27:31 --> Loader Class Initialized
INFO - 2017-02-05 20:27:31 --> Database Driver Class Initialized
INFO - 2017-02-05 20:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:27:31 --> Controller Class Initialized
INFO - 2017-02-05 20:27:31 --> Helper loaded: date_helper
DEBUG - 2017-02-05 20:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:27:31 --> Helper loaded: url_helper
INFO - 2017-02-05 20:27:31 --> Helper loaded: download_helper
INFO - 2017-02-05 20:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-05 20:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-05 20:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-05 20:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:27:31 --> Final output sent to browser
DEBUG - 2017-02-05 20:27:31 --> Total execution time: 0.0981
INFO - 2017-02-05 20:27:38 --> Config Class Initialized
INFO - 2017-02-05 20:27:38 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:27:38 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:27:38 --> Utf8 Class Initialized
INFO - 2017-02-05 20:27:38 --> URI Class Initialized
INFO - 2017-02-05 20:27:38 --> Router Class Initialized
INFO - 2017-02-05 20:27:38 --> Output Class Initialized
INFO - 2017-02-05 20:27:38 --> Security Class Initialized
DEBUG - 2017-02-05 20:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:27:38 --> Input Class Initialized
INFO - 2017-02-05 20:27:38 --> Language Class Initialized
INFO - 2017-02-05 20:27:38 --> Loader Class Initialized
INFO - 2017-02-05 20:27:38 --> Database Driver Class Initialized
INFO - 2017-02-05 20:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:27:38 --> Controller Class Initialized
INFO - 2017-02-05 20:27:38 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:27:38 --> Final output sent to browser
DEBUG - 2017-02-05 20:27:38 --> Total execution time: 0.0156
INFO - 2017-02-05 20:56:29 --> Config Class Initialized
INFO - 2017-02-05 20:56:29 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:56:29 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:56:29 --> Utf8 Class Initialized
INFO - 2017-02-05 20:56:29 --> URI Class Initialized
DEBUG - 2017-02-05 20:56:29 --> No URI present. Default controller set.
INFO - 2017-02-05 20:56:29 --> Router Class Initialized
INFO - 2017-02-05 20:56:29 --> Output Class Initialized
INFO - 2017-02-05 20:56:29 --> Security Class Initialized
DEBUG - 2017-02-05 20:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:56:29 --> Input Class Initialized
INFO - 2017-02-05 20:56:29 --> Language Class Initialized
INFO - 2017-02-05 20:56:29 --> Loader Class Initialized
INFO - 2017-02-05 20:56:29 --> Database Driver Class Initialized
INFO - 2017-02-05 20:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:56:29 --> Controller Class Initialized
INFO - 2017-02-05 20:56:29 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:56:29 --> Final output sent to browser
DEBUG - 2017-02-05 20:56:29 --> Total execution time: 0.0589
INFO - 2017-02-05 20:58:24 --> Config Class Initialized
INFO - 2017-02-05 20:58:24 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:58:24 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:58:24 --> Utf8 Class Initialized
INFO - 2017-02-05 20:58:24 --> URI Class Initialized
DEBUG - 2017-02-05 20:58:24 --> No URI present. Default controller set.
INFO - 2017-02-05 20:58:24 --> Router Class Initialized
INFO - 2017-02-05 20:58:24 --> Output Class Initialized
INFO - 2017-02-05 20:58:24 --> Security Class Initialized
DEBUG - 2017-02-05 20:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:58:24 --> Input Class Initialized
INFO - 2017-02-05 20:58:24 --> Language Class Initialized
INFO - 2017-02-05 20:58:24 --> Loader Class Initialized
INFO - 2017-02-05 20:58:24 --> Database Driver Class Initialized
INFO - 2017-02-05 20:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:58:24 --> Controller Class Initialized
INFO - 2017-02-05 20:58:24 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:58:24 --> Final output sent to browser
DEBUG - 2017-02-05 20:58:24 --> Total execution time: 0.0134
INFO - 2017-02-05 20:58:28 --> Config Class Initialized
INFO - 2017-02-05 20:58:28 --> Hooks Class Initialized
DEBUG - 2017-02-05 20:58:28 --> UTF-8 Support Enabled
INFO - 2017-02-05 20:58:28 --> Utf8 Class Initialized
INFO - 2017-02-05 20:58:28 --> URI Class Initialized
INFO - 2017-02-05 20:58:28 --> Router Class Initialized
INFO - 2017-02-05 20:58:28 --> Output Class Initialized
INFO - 2017-02-05 20:58:28 --> Security Class Initialized
DEBUG - 2017-02-05 20:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 20:58:28 --> Input Class Initialized
INFO - 2017-02-05 20:58:28 --> Language Class Initialized
INFO - 2017-02-05 20:58:28 --> Loader Class Initialized
INFO - 2017-02-05 20:58:28 --> Database Driver Class Initialized
INFO - 2017-02-05 20:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 20:58:28 --> Controller Class Initialized
INFO - 2017-02-05 20:58:28 --> Helper loaded: url_helper
DEBUG - 2017-02-05 20:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 20:58:28 --> Final output sent to browser
DEBUG - 2017-02-05 20:58:28 --> Total execution time: 0.0135
INFO - 2017-02-05 21:00:05 --> Config Class Initialized
INFO - 2017-02-05 21:00:05 --> Hooks Class Initialized
DEBUG - 2017-02-05 21:00:05 --> UTF-8 Support Enabled
INFO - 2017-02-05 21:00:05 --> Utf8 Class Initialized
INFO - 2017-02-05 21:00:05 --> URI Class Initialized
DEBUG - 2017-02-05 21:00:05 --> No URI present. Default controller set.
INFO - 2017-02-05 21:00:05 --> Router Class Initialized
INFO - 2017-02-05 21:00:05 --> Output Class Initialized
INFO - 2017-02-05 21:00:05 --> Security Class Initialized
DEBUG - 2017-02-05 21:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 21:00:05 --> Input Class Initialized
INFO - 2017-02-05 21:00:05 --> Language Class Initialized
INFO - 2017-02-05 21:00:05 --> Loader Class Initialized
INFO - 2017-02-05 21:00:05 --> Database Driver Class Initialized
INFO - 2017-02-05 21:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 21:00:05 --> Controller Class Initialized
INFO - 2017-02-05 21:00:05 --> Helper loaded: url_helper
DEBUG - 2017-02-05 21:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 21:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 21:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 21:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 21:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 21:00:05 --> Final output sent to browser
DEBUG - 2017-02-05 21:00:05 --> Total execution time: 0.0136
INFO - 2017-02-05 21:00:09 --> Config Class Initialized
INFO - 2017-02-05 21:00:09 --> Hooks Class Initialized
DEBUG - 2017-02-05 21:00:09 --> UTF-8 Support Enabled
INFO - 2017-02-05 21:00:09 --> Utf8 Class Initialized
INFO - 2017-02-05 21:00:09 --> URI Class Initialized
INFO - 2017-02-05 21:00:09 --> Router Class Initialized
INFO - 2017-02-05 21:00:09 --> Output Class Initialized
INFO - 2017-02-05 21:00:09 --> Security Class Initialized
DEBUG - 2017-02-05 21:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 21:00:09 --> Input Class Initialized
INFO - 2017-02-05 21:00:09 --> Language Class Initialized
INFO - 2017-02-05 21:00:09 --> Loader Class Initialized
INFO - 2017-02-05 21:00:09 --> Database Driver Class Initialized
INFO - 2017-02-05 21:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 21:00:09 --> Controller Class Initialized
INFO - 2017-02-05 21:00:09 --> Helper loaded: url_helper
DEBUG - 2017-02-05 21:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 21:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 21:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 21:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 21:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 21:00:09 --> Final output sent to browser
DEBUG - 2017-02-05 21:00:09 --> Total execution time: 0.0131
INFO - 2017-02-05 22:57:19 --> Config Class Initialized
INFO - 2017-02-05 22:57:19 --> Hooks Class Initialized
DEBUG - 2017-02-05 22:57:20 --> UTF-8 Support Enabled
INFO - 2017-02-05 22:57:20 --> Utf8 Class Initialized
INFO - 2017-02-05 22:57:20 --> URI Class Initialized
DEBUG - 2017-02-05 22:57:20 --> No URI present. Default controller set.
INFO - 2017-02-05 22:57:20 --> Router Class Initialized
INFO - 2017-02-05 22:57:20 --> Output Class Initialized
INFO - 2017-02-05 22:57:20 --> Security Class Initialized
DEBUG - 2017-02-05 22:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 22:57:20 --> Input Class Initialized
INFO - 2017-02-05 22:57:20 --> Language Class Initialized
INFO - 2017-02-05 22:57:20 --> Loader Class Initialized
INFO - 2017-02-05 22:57:20 --> Database Driver Class Initialized
INFO - 2017-02-05 22:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 22:57:20 --> Controller Class Initialized
INFO - 2017-02-05 22:57:20 --> Helper loaded: url_helper
DEBUG - 2017-02-05 22:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 22:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 22:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 22:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 22:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 22:57:21 --> Final output sent to browser
DEBUG - 2017-02-05 22:57:21 --> Total execution time: 1.4628
INFO - 2017-02-05 22:57:26 --> Config Class Initialized
INFO - 2017-02-05 22:57:26 --> Hooks Class Initialized
DEBUG - 2017-02-05 22:57:26 --> UTF-8 Support Enabled
INFO - 2017-02-05 22:57:26 --> Utf8 Class Initialized
INFO - 2017-02-05 22:57:26 --> URI Class Initialized
INFO - 2017-02-05 22:57:26 --> Router Class Initialized
INFO - 2017-02-05 22:57:26 --> Output Class Initialized
INFO - 2017-02-05 22:57:26 --> Security Class Initialized
DEBUG - 2017-02-05 22:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 22:57:26 --> Input Class Initialized
INFO - 2017-02-05 22:57:26 --> Language Class Initialized
INFO - 2017-02-05 22:57:26 --> Loader Class Initialized
INFO - 2017-02-05 22:57:26 --> Database Driver Class Initialized
INFO - 2017-02-05 22:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 22:57:26 --> Controller Class Initialized
INFO - 2017-02-05 22:57:26 --> Helper loaded: url_helper
DEBUG - 2017-02-05 22:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 22:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 22:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 22:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 22:57:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 22:57:26 --> Final output sent to browser
DEBUG - 2017-02-05 22:57:26 --> Total execution time: 0.0132
INFO - 2017-02-05 22:57:30 --> Config Class Initialized
INFO - 2017-02-05 22:57:30 --> Hooks Class Initialized
DEBUG - 2017-02-05 22:57:30 --> UTF-8 Support Enabled
INFO - 2017-02-05 22:57:30 --> Utf8 Class Initialized
INFO - 2017-02-05 22:57:30 --> URI Class Initialized
INFO - 2017-02-05 22:57:30 --> Router Class Initialized
INFO - 2017-02-05 22:57:30 --> Output Class Initialized
INFO - 2017-02-05 22:57:30 --> Security Class Initialized
DEBUG - 2017-02-05 22:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 22:57:30 --> Input Class Initialized
INFO - 2017-02-05 22:57:30 --> Language Class Initialized
INFO - 2017-02-05 22:57:30 --> Loader Class Initialized
INFO - 2017-02-05 22:57:30 --> Database Driver Class Initialized
INFO - 2017-02-05 22:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 22:57:30 --> Controller Class Initialized
INFO - 2017-02-05 22:57:30 --> Helper loaded: url_helper
DEBUG - 2017-02-05 22:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 22:57:32 --> Config Class Initialized
INFO - 2017-02-05 22:57:32 --> Hooks Class Initialized
DEBUG - 2017-02-05 22:57:32 --> UTF-8 Support Enabled
INFO - 2017-02-05 22:57:32 --> Utf8 Class Initialized
INFO - 2017-02-05 22:57:32 --> URI Class Initialized
INFO - 2017-02-05 22:57:32 --> Router Class Initialized
INFO - 2017-02-05 22:57:32 --> Output Class Initialized
INFO - 2017-02-05 22:57:32 --> Security Class Initialized
DEBUG - 2017-02-05 22:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 22:57:32 --> Input Class Initialized
INFO - 2017-02-05 22:57:32 --> Language Class Initialized
INFO - 2017-02-05 22:57:32 --> Loader Class Initialized
INFO - 2017-02-05 22:57:32 --> Database Driver Class Initialized
INFO - 2017-02-05 22:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 22:57:32 --> Controller Class Initialized
INFO - 2017-02-05 22:57:32 --> Helper loaded: date_helper
DEBUG - 2017-02-05 22:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 22:57:32 --> Helper loaded: url_helper
INFO - 2017-02-05 22:57:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 22:57:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-05 22:57:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-05 22:57:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-05 22:57:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 22:57:32 --> Final output sent to browser
DEBUG - 2017-02-05 22:57:32 --> Total execution time: 0.1176
INFO - 2017-02-05 22:57:33 --> Config Class Initialized
INFO - 2017-02-05 22:57:33 --> Hooks Class Initialized
DEBUG - 2017-02-05 22:57:33 --> UTF-8 Support Enabled
INFO - 2017-02-05 22:57:33 --> Utf8 Class Initialized
INFO - 2017-02-05 22:57:33 --> URI Class Initialized
INFO - 2017-02-05 22:57:33 --> Router Class Initialized
INFO - 2017-02-05 22:57:33 --> Output Class Initialized
INFO - 2017-02-05 22:57:33 --> Security Class Initialized
DEBUG - 2017-02-05 22:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 22:57:33 --> Input Class Initialized
INFO - 2017-02-05 22:57:33 --> Language Class Initialized
INFO - 2017-02-05 22:57:33 --> Loader Class Initialized
INFO - 2017-02-05 22:57:33 --> Database Driver Class Initialized
INFO - 2017-02-05 22:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 22:57:33 --> Controller Class Initialized
INFO - 2017-02-05 22:57:33 --> Helper loaded: url_helper
DEBUG - 2017-02-05 22:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 22:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 22:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 22:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 22:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 22:57:33 --> Final output sent to browser
DEBUG - 2017-02-05 22:57:33 --> Total execution time: 0.0140
INFO - 2017-02-05 22:57:37 --> Config Class Initialized
INFO - 2017-02-05 22:57:37 --> Hooks Class Initialized
DEBUG - 2017-02-05 22:57:37 --> UTF-8 Support Enabled
INFO - 2017-02-05 22:57:37 --> Utf8 Class Initialized
INFO - 2017-02-05 22:57:37 --> URI Class Initialized
DEBUG - 2017-02-05 22:57:37 --> No URI present. Default controller set.
INFO - 2017-02-05 22:57:37 --> Router Class Initialized
INFO - 2017-02-05 22:57:37 --> Output Class Initialized
INFO - 2017-02-05 22:57:37 --> Security Class Initialized
DEBUG - 2017-02-05 22:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 22:57:37 --> Input Class Initialized
INFO - 2017-02-05 22:57:37 --> Language Class Initialized
INFO - 2017-02-05 22:57:37 --> Loader Class Initialized
INFO - 2017-02-05 22:57:37 --> Database Driver Class Initialized
INFO - 2017-02-05 22:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 22:57:37 --> Controller Class Initialized
INFO - 2017-02-05 22:57:37 --> Helper loaded: url_helper
DEBUG - 2017-02-05 22:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 22:57:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 22:57:37 --> Final output sent to browser
DEBUG - 2017-02-05 22:57:37 --> Total execution time: 0.0149
INFO - 2017-02-05 22:57:38 --> Config Class Initialized
INFO - 2017-02-05 22:57:38 --> Hooks Class Initialized
DEBUG - 2017-02-05 22:57:38 --> UTF-8 Support Enabled
INFO - 2017-02-05 22:57:38 --> Utf8 Class Initialized
INFO - 2017-02-05 22:57:38 --> URI Class Initialized
INFO - 2017-02-05 22:57:38 --> Router Class Initialized
INFO - 2017-02-05 22:57:38 --> Output Class Initialized
INFO - 2017-02-05 22:57:38 --> Security Class Initialized
DEBUG - 2017-02-05 22:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-05 22:57:38 --> Input Class Initialized
INFO - 2017-02-05 22:57:38 --> Language Class Initialized
INFO - 2017-02-05 22:57:38 --> Loader Class Initialized
INFO - 2017-02-05 22:57:38 --> Database Driver Class Initialized
INFO - 2017-02-05 22:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-05 22:57:38 --> Controller Class Initialized
INFO - 2017-02-05 22:57:38 --> Helper loaded: url_helper
DEBUG - 2017-02-05 22:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-05 22:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-05 22:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-05 22:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-05 22:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-05 22:57:38 --> Final output sent to browser
DEBUG - 2017-02-05 22:57:38 --> Total execution time: 0.0139

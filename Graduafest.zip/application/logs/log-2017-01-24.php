<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-24 00:22:21 --> Config Class Initialized
INFO - 2017-01-24 00:22:21 --> Hooks Class Initialized
DEBUG - 2017-01-24 00:22:21 --> UTF-8 Support Enabled
INFO - 2017-01-24 00:22:21 --> Utf8 Class Initialized
INFO - 2017-01-24 00:22:21 --> URI Class Initialized
INFO - 2017-01-24 00:22:21 --> Router Class Initialized
INFO - 2017-01-24 00:22:21 --> Output Class Initialized
INFO - 2017-01-24 00:22:21 --> Security Class Initialized
DEBUG - 2017-01-24 00:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 00:22:21 --> Input Class Initialized
INFO - 2017-01-24 00:22:21 --> Language Class Initialized
INFO - 2017-01-24 00:22:21 --> Loader Class Initialized
INFO - 2017-01-24 00:22:21 --> Database Driver Class Initialized
INFO - 2017-01-24 00:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 00:22:21 --> Controller Class Initialized
INFO - 2017-01-24 00:22:21 --> Helper loaded: url_helper
DEBUG - 2017-01-24 00:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 00:22:22 --> Config Class Initialized
INFO - 2017-01-24 00:22:22 --> Hooks Class Initialized
DEBUG - 2017-01-24 00:22:22 --> UTF-8 Support Enabled
INFO - 2017-01-24 00:22:22 --> Utf8 Class Initialized
INFO - 2017-01-24 00:22:22 --> URI Class Initialized
INFO - 2017-01-24 00:22:22 --> Router Class Initialized
INFO - 2017-01-24 00:22:22 --> Output Class Initialized
INFO - 2017-01-24 00:22:22 --> Security Class Initialized
DEBUG - 2017-01-24 00:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 00:22:22 --> Input Class Initialized
INFO - 2017-01-24 00:22:22 --> Language Class Initialized
INFO - 2017-01-24 00:22:22 --> Loader Class Initialized
INFO - 2017-01-24 00:22:22 --> Database Driver Class Initialized
INFO - 2017-01-24 00:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 00:22:22 --> Controller Class Initialized
INFO - 2017-01-24 00:22:22 --> Helper loaded: date_helper
DEBUG - 2017-01-24 00:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 00:22:22 --> Helper loaded: url_helper
INFO - 2017-01-24 00:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 00:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 00:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 00:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 00:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 00:22:22 --> Final output sent to browser
DEBUG - 2017-01-24 00:22:22 --> Total execution time: 0.0150
INFO - 2017-01-24 00:22:23 --> Config Class Initialized
INFO - 2017-01-24 00:22:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 00:22:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 00:22:23 --> Utf8 Class Initialized
INFO - 2017-01-24 00:22:23 --> URI Class Initialized
INFO - 2017-01-24 00:22:23 --> Router Class Initialized
INFO - 2017-01-24 00:22:23 --> Output Class Initialized
INFO - 2017-01-24 00:22:23 --> Security Class Initialized
DEBUG - 2017-01-24 00:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 00:22:23 --> Input Class Initialized
INFO - 2017-01-24 00:22:23 --> Language Class Initialized
INFO - 2017-01-24 00:22:23 --> Loader Class Initialized
INFO - 2017-01-24 00:22:23 --> Database Driver Class Initialized
INFO - 2017-01-24 00:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 00:22:23 --> Controller Class Initialized
INFO - 2017-01-24 00:22:23 --> Helper loaded: url_helper
DEBUG - 2017-01-24 00:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 00:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 00:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 00:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 00:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 00:22:23 --> Final output sent to browser
DEBUG - 2017-01-24 00:22:23 --> Total execution time: 0.0148
INFO - 2017-01-24 00:30:54 --> Config Class Initialized
INFO - 2017-01-24 00:30:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 00:30:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 00:30:54 --> Utf8 Class Initialized
INFO - 2017-01-24 00:30:54 --> URI Class Initialized
INFO - 2017-01-24 00:30:54 --> Router Class Initialized
INFO - 2017-01-24 00:30:54 --> Output Class Initialized
INFO - 2017-01-24 00:30:54 --> Security Class Initialized
DEBUG - 2017-01-24 00:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 00:30:54 --> Input Class Initialized
INFO - 2017-01-24 00:30:54 --> Language Class Initialized
INFO - 2017-01-24 00:30:54 --> Loader Class Initialized
INFO - 2017-01-24 00:30:54 --> Database Driver Class Initialized
INFO - 2017-01-24 00:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 00:30:54 --> Controller Class Initialized
INFO - 2017-01-24 00:30:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 00:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 00:30:54 --> Config Class Initialized
INFO - 2017-01-24 00:30:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 00:30:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 00:30:54 --> Utf8 Class Initialized
INFO - 2017-01-24 00:30:54 --> URI Class Initialized
INFO - 2017-01-24 00:30:54 --> Router Class Initialized
INFO - 2017-01-24 00:30:54 --> Output Class Initialized
INFO - 2017-01-24 00:30:54 --> Security Class Initialized
DEBUG - 2017-01-24 00:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 00:30:54 --> Input Class Initialized
INFO - 2017-01-24 00:30:54 --> Language Class Initialized
INFO - 2017-01-24 00:30:54 --> Loader Class Initialized
INFO - 2017-01-24 00:30:54 --> Database Driver Class Initialized
INFO - 2017-01-24 00:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 00:30:54 --> Controller Class Initialized
INFO - 2017-01-24 00:30:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 00:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 00:30:54 --> Helper loaded: form_helper
INFO - 2017-01-24 00:30:54 --> Form Validation Class Initialized
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 00:30:54 --> Final output sent to browser
DEBUG - 2017-01-24 00:30:54 --> Total execution time: 0.0136
INFO - 2017-01-24 00:30:54 --> Config Class Initialized
INFO - 2017-01-24 00:30:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 00:30:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 00:30:54 --> Utf8 Class Initialized
INFO - 2017-01-24 00:30:54 --> URI Class Initialized
INFO - 2017-01-24 00:30:54 --> Router Class Initialized
INFO - 2017-01-24 00:30:54 --> Output Class Initialized
INFO - 2017-01-24 00:30:54 --> Security Class Initialized
DEBUG - 2017-01-24 00:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 00:30:54 --> Input Class Initialized
INFO - 2017-01-24 00:30:54 --> Language Class Initialized
INFO - 2017-01-24 00:30:54 --> Loader Class Initialized
INFO - 2017-01-24 00:30:54 --> Database Driver Class Initialized
INFO - 2017-01-24 00:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 00:30:54 --> Controller Class Initialized
INFO - 2017-01-24 00:30:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 00:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 00:30:54 --> Final output sent to browser
DEBUG - 2017-01-24 00:30:54 --> Total execution time: 0.0138
INFO - 2017-01-24 00:30:54 --> Config Class Initialized
INFO - 2017-01-24 00:30:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 00:30:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 00:30:54 --> Utf8 Class Initialized
INFO - 2017-01-24 00:30:54 --> URI Class Initialized
INFO - 2017-01-24 00:30:54 --> Router Class Initialized
INFO - 2017-01-24 00:30:54 --> Output Class Initialized
INFO - 2017-01-24 00:30:54 --> Security Class Initialized
DEBUG - 2017-01-24 00:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 00:30:54 --> Input Class Initialized
INFO - 2017-01-24 00:30:54 --> Language Class Initialized
INFO - 2017-01-24 00:30:54 --> Loader Class Initialized
INFO - 2017-01-24 00:30:54 --> Database Driver Class Initialized
INFO - 2017-01-24 00:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 00:30:54 --> Controller Class Initialized
INFO - 2017-01-24 00:30:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 00:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 00:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 00:30:54 --> Final output sent to browser
DEBUG - 2017-01-24 00:30:54 --> Total execution time: 0.0479
INFO - 2017-01-24 03:04:04 --> Config Class Initialized
INFO - 2017-01-24 03:04:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 03:04:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 03:04:04 --> Utf8 Class Initialized
INFO - 2017-01-24 03:04:04 --> URI Class Initialized
DEBUG - 2017-01-24 03:04:04 --> No URI present. Default controller set.
INFO - 2017-01-24 03:04:04 --> Router Class Initialized
INFO - 2017-01-24 03:04:04 --> Output Class Initialized
INFO - 2017-01-24 03:04:04 --> Security Class Initialized
DEBUG - 2017-01-24 03:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 03:04:04 --> Input Class Initialized
INFO - 2017-01-24 03:04:04 --> Language Class Initialized
INFO - 2017-01-24 03:04:04 --> Loader Class Initialized
INFO - 2017-01-24 03:04:04 --> Database Driver Class Initialized
INFO - 2017-01-24 03:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 03:04:04 --> Controller Class Initialized
INFO - 2017-01-24 03:04:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 03:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 03:04:04 --> Final output sent to browser
DEBUG - 2017-01-24 03:04:04 --> Total execution time: 0.2024
INFO - 2017-01-24 03:04:04 --> Config Class Initialized
INFO - 2017-01-24 03:04:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 03:04:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 03:04:04 --> Utf8 Class Initialized
INFO - 2017-01-24 03:04:04 --> URI Class Initialized
DEBUG - 2017-01-24 03:04:04 --> No URI present. Default controller set.
INFO - 2017-01-24 03:04:04 --> Router Class Initialized
INFO - 2017-01-24 03:04:04 --> Output Class Initialized
INFO - 2017-01-24 03:04:04 --> Security Class Initialized
DEBUG - 2017-01-24 03:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 03:04:04 --> Input Class Initialized
INFO - 2017-01-24 03:04:04 --> Language Class Initialized
INFO - 2017-01-24 03:04:04 --> Loader Class Initialized
INFO - 2017-01-24 03:04:04 --> Database Driver Class Initialized
INFO - 2017-01-24 03:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 03:04:04 --> Controller Class Initialized
INFO - 2017-01-24 03:04:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 03:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 03:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 03:04:04 --> Final output sent to browser
DEBUG - 2017-01-24 03:04:04 --> Total execution time: 0.0133
INFO - 2017-01-24 03:05:09 --> Config Class Initialized
INFO - 2017-01-24 03:05:09 --> Hooks Class Initialized
DEBUG - 2017-01-24 03:05:09 --> UTF-8 Support Enabled
INFO - 2017-01-24 03:05:09 --> Utf8 Class Initialized
INFO - 2017-01-24 03:05:09 --> URI Class Initialized
INFO - 2017-01-24 03:05:09 --> Router Class Initialized
INFO - 2017-01-24 03:05:09 --> Output Class Initialized
INFO - 2017-01-24 03:05:09 --> Security Class Initialized
DEBUG - 2017-01-24 03:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 03:05:09 --> Input Class Initialized
INFO - 2017-01-24 03:05:09 --> Language Class Initialized
INFO - 2017-01-24 03:05:09 --> Loader Class Initialized
INFO - 2017-01-24 03:05:09 --> Database Driver Class Initialized
INFO - 2017-01-24 03:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 03:05:09 --> Controller Class Initialized
INFO - 2017-01-24 03:05:09 --> Helper loaded: url_helper
DEBUG - 2017-01-24 03:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 03:05:10 --> Config Class Initialized
INFO - 2017-01-24 03:05:10 --> Hooks Class Initialized
DEBUG - 2017-01-24 03:05:10 --> UTF-8 Support Enabled
INFO - 2017-01-24 03:05:10 --> Utf8 Class Initialized
INFO - 2017-01-24 03:05:10 --> URI Class Initialized
INFO - 2017-01-24 03:05:10 --> Router Class Initialized
INFO - 2017-01-24 03:05:10 --> Output Class Initialized
INFO - 2017-01-24 03:05:10 --> Security Class Initialized
DEBUG - 2017-01-24 03:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 03:05:10 --> Input Class Initialized
INFO - 2017-01-24 03:05:10 --> Language Class Initialized
INFO - 2017-01-24 03:05:10 --> Loader Class Initialized
INFO - 2017-01-24 03:05:10 --> Database Driver Class Initialized
INFO - 2017-01-24 03:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 03:05:10 --> Controller Class Initialized
INFO - 2017-01-24 03:05:10 --> Helper loaded: date_helper
DEBUG - 2017-01-24 03:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 03:05:10 --> Helper loaded: url_helper
INFO - 2017-01-24 03:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 03:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 03:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 03:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 03:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 03:05:10 --> Final output sent to browser
DEBUG - 2017-01-24 03:05:10 --> Total execution time: 0.0407
INFO - 2017-01-24 03:05:12 --> Config Class Initialized
INFO - 2017-01-24 03:05:12 --> Hooks Class Initialized
DEBUG - 2017-01-24 03:05:12 --> UTF-8 Support Enabled
INFO - 2017-01-24 03:05:12 --> Utf8 Class Initialized
INFO - 2017-01-24 03:05:12 --> URI Class Initialized
INFO - 2017-01-24 03:05:12 --> Router Class Initialized
INFO - 2017-01-24 03:05:12 --> Output Class Initialized
INFO - 2017-01-24 03:05:12 --> Security Class Initialized
DEBUG - 2017-01-24 03:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 03:05:12 --> Input Class Initialized
INFO - 2017-01-24 03:05:12 --> Language Class Initialized
INFO - 2017-01-24 03:05:12 --> Loader Class Initialized
INFO - 2017-01-24 03:05:12 --> Database Driver Class Initialized
INFO - 2017-01-24 03:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 03:05:12 --> Controller Class Initialized
INFO - 2017-01-24 03:05:12 --> Helper loaded: url_helper
DEBUG - 2017-01-24 03:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 03:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 03:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 03:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 03:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 03:05:12 --> Final output sent to browser
DEBUG - 2017-01-24 03:05:12 --> Total execution time: 0.0136
INFO - 2017-01-24 03:05:27 --> Config Class Initialized
INFO - 2017-01-24 03:05:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 03:05:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 03:05:27 --> Utf8 Class Initialized
INFO - 2017-01-24 03:05:27 --> URI Class Initialized
DEBUG - 2017-01-24 03:05:27 --> No URI present. Default controller set.
INFO - 2017-01-24 03:05:27 --> Router Class Initialized
INFO - 2017-01-24 03:05:27 --> Output Class Initialized
INFO - 2017-01-24 03:05:27 --> Security Class Initialized
DEBUG - 2017-01-24 03:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 03:05:27 --> Input Class Initialized
INFO - 2017-01-24 03:05:27 --> Language Class Initialized
INFO - 2017-01-24 03:05:27 --> Loader Class Initialized
INFO - 2017-01-24 03:05:27 --> Database Driver Class Initialized
INFO - 2017-01-24 03:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 03:05:27 --> Controller Class Initialized
INFO - 2017-01-24 03:05:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 03:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 03:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 03:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 03:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 03:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 03:05:27 --> Final output sent to browser
DEBUG - 2017-01-24 03:05:27 --> Total execution time: 0.0126
INFO - 2017-01-24 04:07:35 --> Config Class Initialized
INFO - 2017-01-24 04:07:35 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:35 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:35 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:35 --> URI Class Initialized
DEBUG - 2017-01-24 04:07:35 --> No URI present. Default controller set.
INFO - 2017-01-24 04:07:35 --> Router Class Initialized
INFO - 2017-01-24 04:07:35 --> Output Class Initialized
INFO - 2017-01-24 04:07:35 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:35 --> Input Class Initialized
INFO - 2017-01-24 04:07:35 --> Language Class Initialized
INFO - 2017-01-24 04:07:35 --> Loader Class Initialized
INFO - 2017-01-24 04:07:35 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:35 --> Controller Class Initialized
INFO - 2017-01-24 04:07:35 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:07:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:07:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:07:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:07:35 --> Final output sent to browser
DEBUG - 2017-01-24 04:07:35 --> Total execution time: 0.0139
INFO - 2017-01-24 04:07:38 --> Config Class Initialized
INFO - 2017-01-24 04:07:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:38 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:38 --> URI Class Initialized
DEBUG - 2017-01-24 04:07:38 --> No URI present. Default controller set.
INFO - 2017-01-24 04:07:38 --> Router Class Initialized
INFO - 2017-01-24 04:07:38 --> Output Class Initialized
INFO - 2017-01-24 04:07:38 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:38 --> Input Class Initialized
INFO - 2017-01-24 04:07:38 --> Language Class Initialized
INFO - 2017-01-24 04:07:38 --> Loader Class Initialized
INFO - 2017-01-24 04:07:38 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:38 --> Config Class Initialized
INFO - 2017-01-24 04:07:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:38 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:38 --> URI Class Initialized
DEBUG - 2017-01-24 04:07:38 --> No URI present. Default controller set.
INFO - 2017-01-24 04:07:38 --> Router Class Initialized
INFO - 2017-01-24 04:07:38 --> Output Class Initialized
INFO - 2017-01-24 04:07:38 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:38 --> Input Class Initialized
INFO - 2017-01-24 04:07:38 --> Language Class Initialized
INFO - 2017-01-24 04:07:38 --> Loader Class Initialized
INFO - 2017-01-24 04:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:38 --> Controller Class Initialized
INFO - 2017-01-24 04:07:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:07:38 --> Final output sent to browser
DEBUG - 2017-01-24 04:07:38 --> Total execution time: 0.0366
INFO - 2017-01-24 04:07:38 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:38 --> Controller Class Initialized
INFO - 2017-01-24 04:07:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:07:38 --> Final output sent to browser
DEBUG - 2017-01-24 04:07:38 --> Total execution time: 0.0743
INFO - 2017-01-24 04:07:39 --> Config Class Initialized
INFO - 2017-01-24 04:07:39 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:39 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:39 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:39 --> URI Class Initialized
INFO - 2017-01-24 04:07:39 --> Router Class Initialized
INFO - 2017-01-24 04:07:39 --> Output Class Initialized
INFO - 2017-01-24 04:07:39 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:39 --> Input Class Initialized
INFO - 2017-01-24 04:07:39 --> Language Class Initialized
INFO - 2017-01-24 04:07:39 --> Loader Class Initialized
INFO - 2017-01-24 04:07:39 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:39 --> Controller Class Initialized
INFO - 2017-01-24 04:07:39 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:07:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:07:39 --> Final output sent to browser
DEBUG - 2017-01-24 04:07:39 --> Total execution time: 0.0136
INFO - 2017-01-24 04:07:53 --> Config Class Initialized
INFO - 2017-01-24 04:07:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:53 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:53 --> URI Class Initialized
INFO - 2017-01-24 04:07:53 --> Router Class Initialized
INFO - 2017-01-24 04:07:53 --> Output Class Initialized
INFO - 2017-01-24 04:07:53 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:53 --> Input Class Initialized
INFO - 2017-01-24 04:07:53 --> Language Class Initialized
INFO - 2017-01-24 04:07:53 --> Loader Class Initialized
INFO - 2017-01-24 04:07:53 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:53 --> Controller Class Initialized
INFO - 2017-01-24 04:07:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:54 --> Config Class Initialized
INFO - 2017-01-24 04:07:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:54 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:54 --> URI Class Initialized
INFO - 2017-01-24 04:07:54 --> Router Class Initialized
INFO - 2017-01-24 04:07:54 --> Output Class Initialized
INFO - 2017-01-24 04:07:54 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:54 --> Input Class Initialized
INFO - 2017-01-24 04:07:54 --> Language Class Initialized
INFO - 2017-01-24 04:07:54 --> Loader Class Initialized
INFO - 2017-01-24 04:07:54 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:54 --> Controller Class Initialized
INFO - 2017-01-24 04:07:54 --> Helper loaded: date_helper
DEBUG - 2017-01-24 04:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:54 --> Helper loaded: url_helper
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:07:54 --> Final output sent to browser
DEBUG - 2017-01-24 04:07:54 --> Total execution time: 0.0136
INFO - 2017-01-24 04:07:54 --> Config Class Initialized
INFO - 2017-01-24 04:07:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:54 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:54 --> URI Class Initialized
INFO - 2017-01-24 04:07:54 --> Router Class Initialized
INFO - 2017-01-24 04:07:54 --> Output Class Initialized
INFO - 2017-01-24 04:07:54 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:54 --> Input Class Initialized
INFO - 2017-01-24 04:07:54 --> Language Class Initialized
INFO - 2017-01-24 04:07:54 --> Loader Class Initialized
INFO - 2017-01-24 04:07:54 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:54 --> Controller Class Initialized
INFO - 2017-01-24 04:07:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:07:54 --> Final output sent to browser
DEBUG - 2017-01-24 04:07:54 --> Total execution time: 0.0138
INFO - 2017-01-24 04:07:58 --> Config Class Initialized
INFO - 2017-01-24 04:07:58 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:07:58 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:07:58 --> Utf8 Class Initialized
INFO - 2017-01-24 04:07:58 --> URI Class Initialized
DEBUG - 2017-01-24 04:07:58 --> No URI present. Default controller set.
INFO - 2017-01-24 04:07:58 --> Router Class Initialized
INFO - 2017-01-24 04:07:58 --> Output Class Initialized
INFO - 2017-01-24 04:07:58 --> Security Class Initialized
DEBUG - 2017-01-24 04:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:07:58 --> Input Class Initialized
INFO - 2017-01-24 04:07:58 --> Language Class Initialized
INFO - 2017-01-24 04:07:58 --> Loader Class Initialized
INFO - 2017-01-24 04:07:58 --> Database Driver Class Initialized
INFO - 2017-01-24 04:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:07:58 --> Controller Class Initialized
INFO - 2017-01-24 04:07:58 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:07:58 --> Final output sent to browser
DEBUG - 2017-01-24 04:07:58 --> Total execution time: 0.0131
INFO - 2017-01-24 04:08:01 --> Config Class Initialized
INFO - 2017-01-24 04:08:01 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:08:01 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:08:01 --> Utf8 Class Initialized
INFO - 2017-01-24 04:08:01 --> URI Class Initialized
INFO - 2017-01-24 04:08:01 --> Router Class Initialized
INFO - 2017-01-24 04:08:01 --> Output Class Initialized
INFO - 2017-01-24 04:08:01 --> Security Class Initialized
DEBUG - 2017-01-24 04:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:08:01 --> Input Class Initialized
INFO - 2017-01-24 04:08:01 --> Language Class Initialized
INFO - 2017-01-24 04:08:01 --> Loader Class Initialized
INFO - 2017-01-24 04:08:01 --> Database Driver Class Initialized
INFO - 2017-01-24 04:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:08:01 --> Controller Class Initialized
INFO - 2017-01-24 04:08:01 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:08:01 --> Final output sent to browser
DEBUG - 2017-01-24 04:08:01 --> Total execution time: 0.0143
INFO - 2017-01-24 04:08:21 --> Config Class Initialized
INFO - 2017-01-24 04:08:21 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:08:21 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:08:21 --> Utf8 Class Initialized
INFO - 2017-01-24 04:08:21 --> URI Class Initialized
INFO - 2017-01-24 04:08:21 --> Router Class Initialized
INFO - 2017-01-24 04:08:21 --> Output Class Initialized
INFO - 2017-01-24 04:08:21 --> Security Class Initialized
DEBUG - 2017-01-24 04:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:08:21 --> Input Class Initialized
INFO - 2017-01-24 04:08:21 --> Language Class Initialized
INFO - 2017-01-24 04:08:21 --> Loader Class Initialized
INFO - 2017-01-24 04:08:21 --> Database Driver Class Initialized
INFO - 2017-01-24 04:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:08:21 --> Controller Class Initialized
INFO - 2017-01-24 04:08:21 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:08:22 --> Config Class Initialized
INFO - 2017-01-24 04:08:22 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:08:22 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:08:22 --> Utf8 Class Initialized
INFO - 2017-01-24 04:08:22 --> URI Class Initialized
INFO - 2017-01-24 04:08:22 --> Router Class Initialized
INFO - 2017-01-24 04:08:22 --> Output Class Initialized
INFO - 2017-01-24 04:08:22 --> Security Class Initialized
DEBUG - 2017-01-24 04:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:08:22 --> Input Class Initialized
INFO - 2017-01-24 04:08:22 --> Language Class Initialized
INFO - 2017-01-24 04:08:22 --> Loader Class Initialized
INFO - 2017-01-24 04:08:22 --> Database Driver Class Initialized
INFO - 2017-01-24 04:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:08:22 --> Controller Class Initialized
INFO - 2017-01-24 04:08:22 --> Helper loaded: date_helper
DEBUG - 2017-01-24 04:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:08:22 --> Helper loaded: url_helper
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:08:22 --> Final output sent to browser
DEBUG - 2017-01-24 04:08:22 --> Total execution time: 0.0147
INFO - 2017-01-24 04:08:22 --> Config Class Initialized
INFO - 2017-01-24 04:08:22 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:08:22 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:08:22 --> Utf8 Class Initialized
INFO - 2017-01-24 04:08:22 --> URI Class Initialized
INFO - 2017-01-24 04:08:22 --> Router Class Initialized
INFO - 2017-01-24 04:08:22 --> Output Class Initialized
INFO - 2017-01-24 04:08:22 --> Security Class Initialized
DEBUG - 2017-01-24 04:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:08:22 --> Input Class Initialized
INFO - 2017-01-24 04:08:22 --> Language Class Initialized
INFO - 2017-01-24 04:08:22 --> Loader Class Initialized
INFO - 2017-01-24 04:08:22 --> Database Driver Class Initialized
INFO - 2017-01-24 04:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:08:22 --> Controller Class Initialized
INFO - 2017-01-24 04:08:22 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:08:22 --> Final output sent to browser
DEBUG - 2017-01-24 04:08:22 --> Total execution time: 0.0129
INFO - 2017-01-24 04:08:26 --> Config Class Initialized
INFO - 2017-01-24 04:08:26 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:08:26 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:08:26 --> Utf8 Class Initialized
INFO - 2017-01-24 04:08:26 --> URI Class Initialized
DEBUG - 2017-01-24 04:08:26 --> No URI present. Default controller set.
INFO - 2017-01-24 04:08:26 --> Router Class Initialized
INFO - 2017-01-24 04:08:26 --> Output Class Initialized
INFO - 2017-01-24 04:08:26 --> Security Class Initialized
DEBUG - 2017-01-24 04:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:08:26 --> Input Class Initialized
INFO - 2017-01-24 04:08:26 --> Language Class Initialized
INFO - 2017-01-24 04:08:26 --> Loader Class Initialized
INFO - 2017-01-24 04:08:26 --> Database Driver Class Initialized
INFO - 2017-01-24 04:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:08:26 --> Controller Class Initialized
INFO - 2017-01-24 04:08:26 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:08:26 --> Final output sent to browser
DEBUG - 2017-01-24 04:08:26 --> Total execution time: 0.0137
INFO - 2017-01-24 04:08:27 --> Config Class Initialized
INFO - 2017-01-24 04:08:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:08:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:08:27 --> Utf8 Class Initialized
INFO - 2017-01-24 04:08:27 --> URI Class Initialized
INFO - 2017-01-24 04:08:27 --> Router Class Initialized
INFO - 2017-01-24 04:08:27 --> Output Class Initialized
INFO - 2017-01-24 04:08:27 --> Security Class Initialized
DEBUG - 2017-01-24 04:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:08:27 --> Input Class Initialized
INFO - 2017-01-24 04:08:27 --> Language Class Initialized
INFO - 2017-01-24 04:08:27 --> Loader Class Initialized
INFO - 2017-01-24 04:08:27 --> Database Driver Class Initialized
INFO - 2017-01-24 04:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:08:27 --> Controller Class Initialized
INFO - 2017-01-24 04:08:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:08:27 --> Final output sent to browser
DEBUG - 2017-01-24 04:08:27 --> Total execution time: 0.0139
INFO - 2017-01-24 04:09:05 --> Config Class Initialized
INFO - 2017-01-24 04:09:05 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:05 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:05 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:05 --> URI Class Initialized
INFO - 2017-01-24 04:09:05 --> Router Class Initialized
INFO - 2017-01-24 04:09:05 --> Output Class Initialized
INFO - 2017-01-24 04:09:05 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:05 --> Input Class Initialized
INFO - 2017-01-24 04:09:05 --> Language Class Initialized
INFO - 2017-01-24 04:09:05 --> Loader Class Initialized
INFO - 2017-01-24 04:09:05 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:05 --> Controller Class Initialized
INFO - 2017-01-24 04:09:05 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:05 --> Config Class Initialized
INFO - 2017-01-24 04:09:05 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:05 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:05 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:05 --> URI Class Initialized
INFO - 2017-01-24 04:09:05 --> Router Class Initialized
INFO - 2017-01-24 04:09:05 --> Output Class Initialized
INFO - 2017-01-24 04:09:05 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:05 --> Input Class Initialized
INFO - 2017-01-24 04:09:05 --> Language Class Initialized
INFO - 2017-01-24 04:09:05 --> Loader Class Initialized
INFO - 2017-01-24 04:09:05 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:05 --> Controller Class Initialized
INFO - 2017-01-24 04:09:05 --> Helper loaded: date_helper
DEBUG - 2017-01-24 04:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:05 --> Helper loaded: url_helper
INFO - 2017-01-24 04:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 04:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 04:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 04:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:05 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:05 --> Total execution time: 0.0151
INFO - 2017-01-24 04:09:06 --> Config Class Initialized
INFO - 2017-01-24 04:09:06 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:06 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:06 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:06 --> URI Class Initialized
INFO - 2017-01-24 04:09:06 --> Router Class Initialized
INFO - 2017-01-24 04:09:06 --> Output Class Initialized
INFO - 2017-01-24 04:09:06 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:06 --> Input Class Initialized
INFO - 2017-01-24 04:09:06 --> Language Class Initialized
INFO - 2017-01-24 04:09:06 --> Loader Class Initialized
INFO - 2017-01-24 04:09:06 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:06 --> Controller Class Initialized
INFO - 2017-01-24 04:09:06 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:06 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:06 --> Total execution time: 0.0131
INFO - 2017-01-24 04:09:10 --> Config Class Initialized
INFO - 2017-01-24 04:09:10 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:10 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:10 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:10 --> URI Class Initialized
DEBUG - 2017-01-24 04:09:10 --> No URI present. Default controller set.
INFO - 2017-01-24 04:09:10 --> Router Class Initialized
INFO - 2017-01-24 04:09:10 --> Output Class Initialized
INFO - 2017-01-24 04:09:10 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:10 --> Input Class Initialized
INFO - 2017-01-24 04:09:10 --> Language Class Initialized
INFO - 2017-01-24 04:09:10 --> Loader Class Initialized
INFO - 2017-01-24 04:09:10 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:10 --> Controller Class Initialized
INFO - 2017-01-24 04:09:10 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:10 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:10 --> Total execution time: 0.0159
INFO - 2017-01-24 04:09:11 --> Config Class Initialized
INFO - 2017-01-24 04:09:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:11 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:11 --> URI Class Initialized
INFO - 2017-01-24 04:09:11 --> Router Class Initialized
INFO - 2017-01-24 04:09:11 --> Output Class Initialized
INFO - 2017-01-24 04:09:11 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:11 --> Input Class Initialized
INFO - 2017-01-24 04:09:11 --> Language Class Initialized
INFO - 2017-01-24 04:09:11 --> Loader Class Initialized
INFO - 2017-01-24 04:09:11 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:11 --> Controller Class Initialized
INFO - 2017-01-24 04:09:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:11 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:11 --> Total execution time: 0.0135
INFO - 2017-01-24 04:09:29 --> Config Class Initialized
INFO - 2017-01-24 04:09:29 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:29 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:29 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:29 --> URI Class Initialized
INFO - 2017-01-24 04:09:29 --> Router Class Initialized
INFO - 2017-01-24 04:09:29 --> Output Class Initialized
INFO - 2017-01-24 04:09:29 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:29 --> Input Class Initialized
INFO - 2017-01-24 04:09:29 --> Language Class Initialized
INFO - 2017-01-24 04:09:29 --> Loader Class Initialized
INFO - 2017-01-24 04:09:29 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:29 --> Controller Class Initialized
INFO - 2017-01-24 04:09:29 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:29 --> Config Class Initialized
INFO - 2017-01-24 04:09:29 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:29 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:29 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:29 --> URI Class Initialized
INFO - 2017-01-24 04:09:29 --> Router Class Initialized
INFO - 2017-01-24 04:09:29 --> Output Class Initialized
INFO - 2017-01-24 04:09:29 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:29 --> Input Class Initialized
INFO - 2017-01-24 04:09:29 --> Language Class Initialized
INFO - 2017-01-24 04:09:29 --> Loader Class Initialized
INFO - 2017-01-24 04:09:29 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:29 --> Controller Class Initialized
INFO - 2017-01-24 04:09:29 --> Helper loaded: date_helper
DEBUG - 2017-01-24 04:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:29 --> Helper loaded: url_helper
INFO - 2017-01-24 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:29 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:29 --> Total execution time: 0.0145
INFO - 2017-01-24 04:09:30 --> Config Class Initialized
INFO - 2017-01-24 04:09:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:30 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:30 --> URI Class Initialized
INFO - 2017-01-24 04:09:30 --> Router Class Initialized
INFO - 2017-01-24 04:09:30 --> Output Class Initialized
INFO - 2017-01-24 04:09:30 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:30 --> Input Class Initialized
INFO - 2017-01-24 04:09:30 --> Language Class Initialized
INFO - 2017-01-24 04:09:30 --> Loader Class Initialized
INFO - 2017-01-24 04:09:30 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:30 --> Controller Class Initialized
INFO - 2017-01-24 04:09:30 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:30 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:30 --> Total execution time: 0.0136
INFO - 2017-01-24 04:09:32 --> Config Class Initialized
INFO - 2017-01-24 04:09:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:32 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:32 --> URI Class Initialized
DEBUG - 2017-01-24 04:09:32 --> No URI present. Default controller set.
INFO - 2017-01-24 04:09:32 --> Router Class Initialized
INFO - 2017-01-24 04:09:32 --> Output Class Initialized
INFO - 2017-01-24 04:09:32 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:32 --> Input Class Initialized
INFO - 2017-01-24 04:09:32 --> Language Class Initialized
INFO - 2017-01-24 04:09:32 --> Loader Class Initialized
INFO - 2017-01-24 04:09:32 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:32 --> Controller Class Initialized
INFO - 2017-01-24 04:09:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:09:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:32 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:32 --> Total execution time: 0.0133
INFO - 2017-01-24 04:09:34 --> Config Class Initialized
INFO - 2017-01-24 04:09:34 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:09:34 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:09:34 --> Utf8 Class Initialized
INFO - 2017-01-24 04:09:34 --> URI Class Initialized
INFO - 2017-01-24 04:09:34 --> Router Class Initialized
INFO - 2017-01-24 04:09:34 --> Output Class Initialized
INFO - 2017-01-24 04:09:34 --> Security Class Initialized
DEBUG - 2017-01-24 04:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:09:34 --> Input Class Initialized
INFO - 2017-01-24 04:09:34 --> Language Class Initialized
INFO - 2017-01-24 04:09:34 --> Loader Class Initialized
INFO - 2017-01-24 04:09:34 --> Database Driver Class Initialized
INFO - 2017-01-24 04:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:09:34 --> Controller Class Initialized
INFO - 2017-01-24 04:09:34 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:09:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:09:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:09:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:09:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:09:34 --> Final output sent to browser
DEBUG - 2017-01-24 04:09:34 --> Total execution time: 0.0131
INFO - 2017-01-24 04:10:58 --> Config Class Initialized
INFO - 2017-01-24 04:10:58 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:10:58 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:10:58 --> Utf8 Class Initialized
INFO - 2017-01-24 04:10:58 --> URI Class Initialized
INFO - 2017-01-24 04:10:58 --> Router Class Initialized
INFO - 2017-01-24 04:10:58 --> Output Class Initialized
INFO - 2017-01-24 04:10:58 --> Security Class Initialized
DEBUG - 2017-01-24 04:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:10:58 --> Input Class Initialized
INFO - 2017-01-24 04:10:58 --> Language Class Initialized
INFO - 2017-01-24 04:10:58 --> Loader Class Initialized
INFO - 2017-01-24 04:10:58 --> Database Driver Class Initialized
INFO - 2017-01-24 04:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:10:58 --> Controller Class Initialized
INFO - 2017-01-24 04:10:58 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:10:58 --> Config Class Initialized
INFO - 2017-01-24 04:10:58 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:10:58 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:10:58 --> Utf8 Class Initialized
INFO - 2017-01-24 04:10:58 --> URI Class Initialized
INFO - 2017-01-24 04:10:58 --> Router Class Initialized
INFO - 2017-01-24 04:10:58 --> Output Class Initialized
INFO - 2017-01-24 04:10:58 --> Security Class Initialized
DEBUG - 2017-01-24 04:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:10:58 --> Input Class Initialized
INFO - 2017-01-24 04:10:58 --> Language Class Initialized
INFO - 2017-01-24 04:10:58 --> Loader Class Initialized
INFO - 2017-01-24 04:10:58 --> Database Driver Class Initialized
INFO - 2017-01-24 04:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:10:58 --> Controller Class Initialized
INFO - 2017-01-24 04:10:58 --> Helper loaded: date_helper
DEBUG - 2017-01-24 04:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:10:58 --> Helper loaded: url_helper
INFO - 2017-01-24 04:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 04:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 04:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 04:10:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:10:58 --> Final output sent to browser
DEBUG - 2017-01-24 04:10:58 --> Total execution time: 0.0150
INFO - 2017-01-24 04:10:59 --> Config Class Initialized
INFO - 2017-01-24 04:10:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:10:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:10:59 --> Utf8 Class Initialized
INFO - 2017-01-24 04:10:59 --> URI Class Initialized
INFO - 2017-01-24 04:10:59 --> Router Class Initialized
INFO - 2017-01-24 04:10:59 --> Output Class Initialized
INFO - 2017-01-24 04:10:59 --> Security Class Initialized
DEBUG - 2017-01-24 04:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:10:59 --> Input Class Initialized
INFO - 2017-01-24 04:10:59 --> Language Class Initialized
INFO - 2017-01-24 04:10:59 --> Loader Class Initialized
INFO - 2017-01-24 04:10:59 --> Database Driver Class Initialized
INFO - 2017-01-24 04:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:10:59 --> Controller Class Initialized
INFO - 2017-01-24 04:10:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:10:59 --> Final output sent to browser
DEBUG - 2017-01-24 04:10:59 --> Total execution time: 0.0137
INFO - 2017-01-24 04:11:01 --> Config Class Initialized
INFO - 2017-01-24 04:11:01 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:11:01 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:11:01 --> Utf8 Class Initialized
INFO - 2017-01-24 04:11:01 --> URI Class Initialized
DEBUG - 2017-01-24 04:11:01 --> No URI present. Default controller set.
INFO - 2017-01-24 04:11:01 --> Router Class Initialized
INFO - 2017-01-24 04:11:01 --> Output Class Initialized
INFO - 2017-01-24 04:11:01 --> Security Class Initialized
DEBUG - 2017-01-24 04:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:11:01 --> Input Class Initialized
INFO - 2017-01-24 04:11:01 --> Language Class Initialized
INFO - 2017-01-24 04:11:01 --> Loader Class Initialized
INFO - 2017-01-24 04:11:01 --> Database Driver Class Initialized
INFO - 2017-01-24 04:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:11:01 --> Controller Class Initialized
INFO - 2017-01-24 04:11:01 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:11:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:11:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:11:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:11:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:11:01 --> Final output sent to browser
DEBUG - 2017-01-24 04:11:01 --> Total execution time: 0.0133
INFO - 2017-01-24 04:11:02 --> Config Class Initialized
INFO - 2017-01-24 04:11:02 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:11:02 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:11:02 --> Utf8 Class Initialized
INFO - 2017-01-24 04:11:02 --> URI Class Initialized
INFO - 2017-01-24 04:11:02 --> Router Class Initialized
INFO - 2017-01-24 04:11:02 --> Output Class Initialized
INFO - 2017-01-24 04:11:02 --> Security Class Initialized
DEBUG - 2017-01-24 04:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:11:02 --> Input Class Initialized
INFO - 2017-01-24 04:11:02 --> Language Class Initialized
INFO - 2017-01-24 04:11:02 --> Loader Class Initialized
INFO - 2017-01-24 04:11:02 --> Database Driver Class Initialized
INFO - 2017-01-24 04:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:11:02 --> Controller Class Initialized
INFO - 2017-01-24 04:11:02 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:11:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:11:02 --> Final output sent to browser
DEBUG - 2017-01-24 04:11:02 --> Total execution time: 0.0178
INFO - 2017-01-24 04:15:23 --> Config Class Initialized
INFO - 2017-01-24 04:15:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:15:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:15:23 --> Utf8 Class Initialized
INFO - 2017-01-24 04:15:23 --> URI Class Initialized
DEBUG - 2017-01-24 04:15:23 --> No URI present. Default controller set.
INFO - 2017-01-24 04:15:23 --> Router Class Initialized
INFO - 2017-01-24 04:15:23 --> Output Class Initialized
INFO - 2017-01-24 04:15:23 --> Security Class Initialized
DEBUG - 2017-01-24 04:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:15:23 --> Input Class Initialized
INFO - 2017-01-24 04:15:23 --> Language Class Initialized
INFO - 2017-01-24 04:15:23 --> Loader Class Initialized
INFO - 2017-01-24 04:15:23 --> Database Driver Class Initialized
INFO - 2017-01-24 04:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:15:23 --> Controller Class Initialized
INFO - 2017-01-24 04:15:23 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:15:23 --> Final output sent to browser
DEBUG - 2017-01-24 04:15:23 --> Total execution time: 0.0138
INFO - 2017-01-24 04:16:02 --> Config Class Initialized
INFO - 2017-01-24 04:16:02 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:16:02 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:16:02 --> Utf8 Class Initialized
INFO - 2017-01-24 04:16:02 --> URI Class Initialized
INFO - 2017-01-24 04:16:02 --> Router Class Initialized
INFO - 2017-01-24 04:16:02 --> Output Class Initialized
INFO - 2017-01-24 04:16:02 --> Security Class Initialized
DEBUG - 2017-01-24 04:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:16:02 --> Input Class Initialized
INFO - 2017-01-24 04:16:02 --> Language Class Initialized
INFO - 2017-01-24 04:16:02 --> Loader Class Initialized
INFO - 2017-01-24 04:16:02 --> Database Driver Class Initialized
INFO - 2017-01-24 04:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:16:02 --> Controller Class Initialized
INFO - 2017-01-24 04:16:02 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:16:02 --> Final output sent to browser
DEBUG - 2017-01-24 04:16:02 --> Total execution time: 0.0138
INFO - 2017-01-24 04:16:16 --> Config Class Initialized
INFO - 2017-01-24 04:16:16 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:16:16 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:16:16 --> Utf8 Class Initialized
INFO - 2017-01-24 04:16:16 --> URI Class Initialized
DEBUG - 2017-01-24 04:16:16 --> No URI present. Default controller set.
INFO - 2017-01-24 04:16:16 --> Router Class Initialized
INFO - 2017-01-24 04:16:16 --> Output Class Initialized
INFO - 2017-01-24 04:16:16 --> Security Class Initialized
DEBUG - 2017-01-24 04:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:16:16 --> Input Class Initialized
INFO - 2017-01-24 04:16:16 --> Language Class Initialized
INFO - 2017-01-24 04:16:16 --> Loader Class Initialized
INFO - 2017-01-24 04:16:16 --> Database Driver Class Initialized
INFO - 2017-01-24 04:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:16:16 --> Controller Class Initialized
INFO - 2017-01-24 04:16:16 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:16:16 --> Final output sent to browser
DEBUG - 2017-01-24 04:16:16 --> Total execution time: 0.0142
INFO - 2017-01-24 04:16:24 --> Config Class Initialized
INFO - 2017-01-24 04:16:24 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:16:24 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:16:24 --> Utf8 Class Initialized
INFO - 2017-01-24 04:16:24 --> URI Class Initialized
INFO - 2017-01-24 04:16:24 --> Router Class Initialized
INFO - 2017-01-24 04:16:24 --> Output Class Initialized
INFO - 2017-01-24 04:16:24 --> Security Class Initialized
DEBUG - 2017-01-24 04:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:16:24 --> Input Class Initialized
INFO - 2017-01-24 04:16:24 --> Language Class Initialized
INFO - 2017-01-24 04:16:24 --> Loader Class Initialized
INFO - 2017-01-24 04:16:24 --> Database Driver Class Initialized
INFO - 2017-01-24 04:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:16:24 --> Controller Class Initialized
INFO - 2017-01-24 04:16:24 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:16:24 --> Final output sent to browser
DEBUG - 2017-01-24 04:16:24 --> Total execution time: 0.0139
INFO - 2017-01-24 04:17:30 --> Config Class Initialized
INFO - 2017-01-24 04:17:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:17:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:17:30 --> Utf8 Class Initialized
INFO - 2017-01-24 04:17:30 --> URI Class Initialized
DEBUG - 2017-01-24 04:17:30 --> No URI present. Default controller set.
INFO - 2017-01-24 04:17:30 --> Router Class Initialized
INFO - 2017-01-24 04:17:30 --> Output Class Initialized
INFO - 2017-01-24 04:17:30 --> Security Class Initialized
DEBUG - 2017-01-24 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:17:30 --> Input Class Initialized
INFO - 2017-01-24 04:17:30 --> Language Class Initialized
INFO - 2017-01-24 04:17:30 --> Loader Class Initialized
INFO - 2017-01-24 04:17:30 --> Database Driver Class Initialized
INFO - 2017-01-24 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:17:30 --> Controller Class Initialized
INFO - 2017-01-24 04:17:30 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:17:30 --> Final output sent to browser
DEBUG - 2017-01-24 04:17:30 --> Total execution time: 0.0135
INFO - 2017-01-24 04:17:51 --> Config Class Initialized
INFO - 2017-01-24 04:17:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:17:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:17:51 --> Utf8 Class Initialized
INFO - 2017-01-24 04:17:51 --> URI Class Initialized
DEBUG - 2017-01-24 04:17:51 --> No URI present. Default controller set.
INFO - 2017-01-24 04:17:51 --> Router Class Initialized
INFO - 2017-01-24 04:17:51 --> Output Class Initialized
INFO - 2017-01-24 04:17:51 --> Security Class Initialized
DEBUG - 2017-01-24 04:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:17:51 --> Input Class Initialized
INFO - 2017-01-24 04:17:51 --> Language Class Initialized
INFO - 2017-01-24 04:17:51 --> Loader Class Initialized
INFO - 2017-01-24 04:17:51 --> Database Driver Class Initialized
INFO - 2017-01-24 04:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:17:51 --> Controller Class Initialized
INFO - 2017-01-24 04:17:51 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:17:51 --> Final output sent to browser
DEBUG - 2017-01-24 04:17:51 --> Total execution time: 0.0138
INFO - 2017-01-24 04:17:55 --> Config Class Initialized
INFO - 2017-01-24 04:17:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:17:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:17:55 --> Utf8 Class Initialized
INFO - 2017-01-24 04:17:55 --> URI Class Initialized
INFO - 2017-01-24 04:17:55 --> Router Class Initialized
INFO - 2017-01-24 04:17:55 --> Output Class Initialized
INFO - 2017-01-24 04:17:55 --> Security Class Initialized
DEBUG - 2017-01-24 04:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:17:55 --> Input Class Initialized
INFO - 2017-01-24 04:17:55 --> Language Class Initialized
INFO - 2017-01-24 04:17:55 --> Loader Class Initialized
INFO - 2017-01-24 04:17:55 --> Database Driver Class Initialized
INFO - 2017-01-24 04:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:17:55 --> Controller Class Initialized
INFO - 2017-01-24 04:17:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:17:55 --> Final output sent to browser
DEBUG - 2017-01-24 04:17:55 --> Total execution time: 0.0252
INFO - 2017-01-24 04:18:11 --> Config Class Initialized
INFO - 2017-01-24 04:18:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:18:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:18:11 --> Utf8 Class Initialized
INFO - 2017-01-24 04:18:11 --> URI Class Initialized
INFO - 2017-01-24 04:18:11 --> Router Class Initialized
INFO - 2017-01-24 04:18:11 --> Output Class Initialized
INFO - 2017-01-24 04:18:11 --> Security Class Initialized
DEBUG - 2017-01-24 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:18:11 --> Input Class Initialized
INFO - 2017-01-24 04:18:11 --> Language Class Initialized
INFO - 2017-01-24 04:18:11 --> Loader Class Initialized
INFO - 2017-01-24 04:18:11 --> Database Driver Class Initialized
INFO - 2017-01-24 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:18:11 --> Controller Class Initialized
INFO - 2017-01-24 04:18:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:18:11 --> Final output sent to browser
DEBUG - 2017-01-24 04:18:11 --> Total execution time: 0.0150
INFO - 2017-01-24 04:19:34 --> Config Class Initialized
INFO - 2017-01-24 04:19:34 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:19:34 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:19:34 --> Utf8 Class Initialized
INFO - 2017-01-24 04:19:34 --> URI Class Initialized
INFO - 2017-01-24 04:19:34 --> Router Class Initialized
INFO - 2017-01-24 04:19:34 --> Output Class Initialized
INFO - 2017-01-24 04:19:34 --> Security Class Initialized
DEBUG - 2017-01-24 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:19:34 --> Input Class Initialized
INFO - 2017-01-24 04:19:34 --> Language Class Initialized
INFO - 2017-01-24 04:19:34 --> Loader Class Initialized
INFO - 2017-01-24 04:19:34 --> Database Driver Class Initialized
INFO - 2017-01-24 04:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:19:34 --> Controller Class Initialized
INFO - 2017-01-24 04:19:34 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:19:35 --> Config Class Initialized
INFO - 2017-01-24 04:19:35 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:19:35 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:19:35 --> Utf8 Class Initialized
INFO - 2017-01-24 04:19:35 --> URI Class Initialized
INFO - 2017-01-24 04:19:35 --> Router Class Initialized
INFO - 2017-01-24 04:19:35 --> Output Class Initialized
INFO - 2017-01-24 04:19:35 --> Security Class Initialized
DEBUG - 2017-01-24 04:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:19:35 --> Input Class Initialized
INFO - 2017-01-24 04:19:35 --> Language Class Initialized
INFO - 2017-01-24 04:19:35 --> Loader Class Initialized
INFO - 2017-01-24 04:19:35 --> Database Driver Class Initialized
INFO - 2017-01-24 04:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:19:35 --> Controller Class Initialized
INFO - 2017-01-24 04:19:35 --> Helper loaded: date_helper
DEBUG - 2017-01-24 04:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:19:35 --> Helper loaded: url_helper
INFO - 2017-01-24 04:19:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:19:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 04:19:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 04:19:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 04:19:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:19:35 --> Final output sent to browser
DEBUG - 2017-01-24 04:19:35 --> Total execution time: 0.0148
INFO - 2017-01-24 04:19:39 --> Config Class Initialized
INFO - 2017-01-24 04:19:39 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:19:39 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:19:39 --> Utf8 Class Initialized
INFO - 2017-01-24 04:19:39 --> URI Class Initialized
INFO - 2017-01-24 04:19:39 --> Router Class Initialized
INFO - 2017-01-24 04:19:39 --> Output Class Initialized
INFO - 2017-01-24 04:19:39 --> Security Class Initialized
DEBUG - 2017-01-24 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:19:39 --> Input Class Initialized
INFO - 2017-01-24 04:19:39 --> Language Class Initialized
INFO - 2017-01-24 04:19:39 --> Loader Class Initialized
INFO - 2017-01-24 04:19:39 --> Database Driver Class Initialized
INFO - 2017-01-24 04:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:19:39 --> Controller Class Initialized
INFO - 2017-01-24 04:19:39 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:19:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:19:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:19:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:19:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:19:39 --> Final output sent to browser
DEBUG - 2017-01-24 04:19:39 --> Total execution time: 0.0133
INFO - 2017-01-24 04:20:29 --> Config Class Initialized
INFO - 2017-01-24 04:20:29 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:20:29 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:20:29 --> Utf8 Class Initialized
INFO - 2017-01-24 04:20:29 --> URI Class Initialized
INFO - 2017-01-24 04:20:29 --> Router Class Initialized
INFO - 2017-01-24 04:20:29 --> Output Class Initialized
INFO - 2017-01-24 04:20:29 --> Security Class Initialized
DEBUG - 2017-01-24 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:20:29 --> Input Class Initialized
INFO - 2017-01-24 04:20:29 --> Language Class Initialized
INFO - 2017-01-24 04:20:29 --> Loader Class Initialized
INFO - 2017-01-24 04:20:29 --> Database Driver Class Initialized
INFO - 2017-01-24 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:20:29 --> Controller Class Initialized
INFO - 2017-01-24 04:20:29 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:20:29 --> Final output sent to browser
DEBUG - 2017-01-24 04:20:29 --> Total execution time: 0.0141
INFO - 2017-01-24 04:20:35 --> Config Class Initialized
INFO - 2017-01-24 04:20:35 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:20:35 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:20:35 --> Utf8 Class Initialized
INFO - 2017-01-24 04:20:35 --> URI Class Initialized
INFO - 2017-01-24 04:20:35 --> Router Class Initialized
INFO - 2017-01-24 04:20:35 --> Output Class Initialized
INFO - 2017-01-24 04:20:35 --> Security Class Initialized
DEBUG - 2017-01-24 04:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:20:35 --> Input Class Initialized
INFO - 2017-01-24 04:20:35 --> Language Class Initialized
INFO - 2017-01-24 04:20:35 --> Loader Class Initialized
INFO - 2017-01-24 04:20:35 --> Database Driver Class Initialized
INFO - 2017-01-24 04:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:20:35 --> Controller Class Initialized
INFO - 2017-01-24 04:20:35 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:20:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:20:35 --> Final output sent to browser
DEBUG - 2017-01-24 04:20:35 --> Total execution time: 0.0164
INFO - 2017-01-24 04:20:36 --> Config Class Initialized
INFO - 2017-01-24 04:20:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:20:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:20:36 --> Utf8 Class Initialized
INFO - 2017-01-24 04:20:36 --> URI Class Initialized
DEBUG - 2017-01-24 04:20:36 --> No URI present. Default controller set.
INFO - 2017-01-24 04:20:36 --> Router Class Initialized
INFO - 2017-01-24 04:20:36 --> Output Class Initialized
INFO - 2017-01-24 04:20:36 --> Security Class Initialized
DEBUG - 2017-01-24 04:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:20:36 --> Input Class Initialized
INFO - 2017-01-24 04:20:36 --> Language Class Initialized
INFO - 2017-01-24 04:20:36 --> Loader Class Initialized
INFO - 2017-01-24 04:20:36 --> Database Driver Class Initialized
INFO - 2017-01-24 04:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:20:36 --> Controller Class Initialized
INFO - 2017-01-24 04:20:36 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:20:36 --> Final output sent to browser
DEBUG - 2017-01-24 04:20:36 --> Total execution time: 0.0139
INFO - 2017-01-24 04:20:37 --> Config Class Initialized
INFO - 2017-01-24 04:20:37 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:20:37 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:20:37 --> Utf8 Class Initialized
INFO - 2017-01-24 04:20:37 --> URI Class Initialized
INFO - 2017-01-24 04:20:37 --> Router Class Initialized
INFO - 2017-01-24 04:20:37 --> Output Class Initialized
INFO - 2017-01-24 04:20:37 --> Security Class Initialized
DEBUG - 2017-01-24 04:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:20:37 --> Input Class Initialized
INFO - 2017-01-24 04:20:37 --> Language Class Initialized
INFO - 2017-01-24 04:20:37 --> Loader Class Initialized
INFO - 2017-01-24 04:20:37 --> Database Driver Class Initialized
INFO - 2017-01-24 04:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:20:37 --> Controller Class Initialized
INFO - 2017-01-24 04:20:37 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:20:37 --> Final output sent to browser
DEBUG - 2017-01-24 04:20:37 --> Total execution time: 0.0136
INFO - 2017-01-24 04:20:53 --> Config Class Initialized
INFO - 2017-01-24 04:20:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:20:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:20:53 --> Utf8 Class Initialized
INFO - 2017-01-24 04:20:53 --> URI Class Initialized
INFO - 2017-01-24 04:20:53 --> Router Class Initialized
INFO - 2017-01-24 04:20:53 --> Output Class Initialized
INFO - 2017-01-24 04:20:53 --> Security Class Initialized
DEBUG - 2017-01-24 04:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:20:53 --> Input Class Initialized
INFO - 2017-01-24 04:20:53 --> Language Class Initialized
INFO - 2017-01-24 04:20:53 --> Loader Class Initialized
INFO - 2017-01-24 04:20:53 --> Database Driver Class Initialized
INFO - 2017-01-24 04:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:20:53 --> Controller Class Initialized
INFO - 2017-01-24 04:20:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:20:53 --> Final output sent to browser
DEBUG - 2017-01-24 04:20:53 --> Total execution time: 0.0141
INFO - 2017-01-24 04:20:54 --> Config Class Initialized
INFO - 2017-01-24 04:20:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:20:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:20:54 --> Utf8 Class Initialized
INFO - 2017-01-24 04:20:54 --> URI Class Initialized
INFO - 2017-01-24 04:20:54 --> Router Class Initialized
INFO - 2017-01-24 04:20:54 --> Output Class Initialized
INFO - 2017-01-24 04:20:54 --> Security Class Initialized
DEBUG - 2017-01-24 04:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:20:54 --> Input Class Initialized
INFO - 2017-01-24 04:20:54 --> Language Class Initialized
INFO - 2017-01-24 04:20:54 --> Loader Class Initialized
INFO - 2017-01-24 04:20:54 --> Database Driver Class Initialized
INFO - 2017-01-24 04:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:20:54 --> Controller Class Initialized
INFO - 2017-01-24 04:20:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:20:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:20:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:20:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:20:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:20:54 --> Final output sent to browser
DEBUG - 2017-01-24 04:20:54 --> Total execution time: 0.0130
INFO - 2017-01-24 04:22:03 --> Config Class Initialized
INFO - 2017-01-24 04:22:03 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:22:03 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:22:03 --> Utf8 Class Initialized
INFO - 2017-01-24 04:22:03 --> URI Class Initialized
INFO - 2017-01-24 04:22:03 --> Router Class Initialized
INFO - 2017-01-24 04:22:03 --> Output Class Initialized
INFO - 2017-01-24 04:22:03 --> Security Class Initialized
DEBUG - 2017-01-24 04:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:22:03 --> Input Class Initialized
INFO - 2017-01-24 04:22:03 --> Language Class Initialized
INFO - 2017-01-24 04:22:03 --> Loader Class Initialized
INFO - 2017-01-24 04:22:03 --> Database Driver Class Initialized
INFO - 2017-01-24 04:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:22:03 --> Controller Class Initialized
INFO - 2017-01-24 04:22:03 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:22:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:22:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:22:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:22:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:22:03 --> Final output sent to browser
DEBUG - 2017-01-24 04:22:03 --> Total execution time: 0.0158
INFO - 2017-01-24 04:22:06 --> Config Class Initialized
INFO - 2017-01-24 04:22:06 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:22:06 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:22:06 --> Utf8 Class Initialized
INFO - 2017-01-24 04:22:06 --> URI Class Initialized
INFO - 2017-01-24 04:22:06 --> Router Class Initialized
INFO - 2017-01-24 04:22:06 --> Output Class Initialized
INFO - 2017-01-24 04:22:06 --> Security Class Initialized
DEBUG - 2017-01-24 04:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:22:06 --> Input Class Initialized
INFO - 2017-01-24 04:22:06 --> Language Class Initialized
INFO - 2017-01-24 04:22:06 --> Loader Class Initialized
INFO - 2017-01-24 04:22:06 --> Database Driver Class Initialized
INFO - 2017-01-24 04:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:22:06 --> Controller Class Initialized
INFO - 2017-01-24 04:22:06 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:22:06 --> Final output sent to browser
DEBUG - 2017-01-24 04:22:06 --> Total execution time: 0.0639
INFO - 2017-01-24 04:22:34 --> Config Class Initialized
INFO - 2017-01-24 04:22:34 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:22:34 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:22:34 --> Utf8 Class Initialized
INFO - 2017-01-24 04:22:34 --> URI Class Initialized
INFO - 2017-01-24 04:22:34 --> Router Class Initialized
INFO - 2017-01-24 04:22:34 --> Output Class Initialized
INFO - 2017-01-24 04:22:34 --> Security Class Initialized
DEBUG - 2017-01-24 04:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:22:34 --> Input Class Initialized
INFO - 2017-01-24 04:22:34 --> Language Class Initialized
INFO - 2017-01-24 04:22:34 --> Loader Class Initialized
INFO - 2017-01-24 04:22:34 --> Database Driver Class Initialized
INFO - 2017-01-24 04:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:22:34 --> Controller Class Initialized
INFO - 2017-01-24 04:22:34 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:22:34 --> Final output sent to browser
DEBUG - 2017-01-24 04:22:34 --> Total execution time: 0.0148
INFO - 2017-01-24 04:22:36 --> Config Class Initialized
INFO - 2017-01-24 04:22:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:22:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:22:36 --> Utf8 Class Initialized
INFO - 2017-01-24 04:22:36 --> URI Class Initialized
INFO - 2017-01-24 04:22:36 --> Router Class Initialized
INFO - 2017-01-24 04:22:36 --> Output Class Initialized
INFO - 2017-01-24 04:22:36 --> Security Class Initialized
DEBUG - 2017-01-24 04:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:22:36 --> Input Class Initialized
INFO - 2017-01-24 04:22:36 --> Language Class Initialized
INFO - 2017-01-24 04:22:36 --> Loader Class Initialized
INFO - 2017-01-24 04:22:36 --> Database Driver Class Initialized
INFO - 2017-01-24 04:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:22:36 --> Controller Class Initialized
INFO - 2017-01-24 04:22:36 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:22:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:22:36 --> Final output sent to browser
DEBUG - 2017-01-24 04:22:36 --> Total execution time: 0.0137
INFO - 2017-01-24 04:22:38 --> Config Class Initialized
INFO - 2017-01-24 04:22:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:22:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:22:38 --> Utf8 Class Initialized
INFO - 2017-01-24 04:22:38 --> URI Class Initialized
INFO - 2017-01-24 04:22:38 --> Router Class Initialized
INFO - 2017-01-24 04:22:38 --> Output Class Initialized
INFO - 2017-01-24 04:22:38 --> Security Class Initialized
DEBUG - 2017-01-24 04:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:22:38 --> Input Class Initialized
INFO - 2017-01-24 04:22:38 --> Language Class Initialized
INFO - 2017-01-24 04:22:38 --> Loader Class Initialized
INFO - 2017-01-24 04:22:38 --> Database Driver Class Initialized
INFO - 2017-01-24 04:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:22:38 --> Controller Class Initialized
INFO - 2017-01-24 04:22:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:22:38 --> Final output sent to browser
DEBUG - 2017-01-24 04:22:38 --> Total execution time: 0.0135
INFO - 2017-01-24 04:22:39 --> Config Class Initialized
INFO - 2017-01-24 04:22:39 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:22:39 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:22:39 --> Utf8 Class Initialized
INFO - 2017-01-24 04:22:39 --> URI Class Initialized
INFO - 2017-01-24 04:22:39 --> Router Class Initialized
INFO - 2017-01-24 04:22:39 --> Output Class Initialized
INFO - 2017-01-24 04:22:39 --> Security Class Initialized
DEBUG - 2017-01-24 04:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:22:39 --> Input Class Initialized
INFO - 2017-01-24 04:22:39 --> Language Class Initialized
INFO - 2017-01-24 04:22:39 --> Loader Class Initialized
INFO - 2017-01-24 04:22:39 --> Database Driver Class Initialized
INFO - 2017-01-24 04:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:22:39 --> Controller Class Initialized
INFO - 2017-01-24 04:22:39 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:22:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:22:39 --> Final output sent to browser
DEBUG - 2017-01-24 04:22:39 --> Total execution time: 0.0152
INFO - 2017-01-24 04:24:28 --> Config Class Initialized
INFO - 2017-01-24 04:24:28 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:24:28 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:24:28 --> Utf8 Class Initialized
INFO - 2017-01-24 04:24:28 --> URI Class Initialized
INFO - 2017-01-24 04:24:28 --> Router Class Initialized
INFO - 2017-01-24 04:24:28 --> Output Class Initialized
INFO - 2017-01-24 04:24:28 --> Security Class Initialized
DEBUG - 2017-01-24 04:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:24:28 --> Input Class Initialized
INFO - 2017-01-24 04:24:28 --> Language Class Initialized
INFO - 2017-01-24 04:24:28 --> Loader Class Initialized
INFO - 2017-01-24 04:24:28 --> Database Driver Class Initialized
INFO - 2017-01-24 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:24:28 --> Controller Class Initialized
INFO - 2017-01-24 04:24:28 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:24:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 04:24:29 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 04:24:30 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'LiLi Coronado')
INFO - 2017-01-24 04:24:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 04:24:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 04:24:30 --> Config Class Initialized
INFO - 2017-01-24 04:24:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:24:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:24:30 --> Utf8 Class Initialized
INFO - 2017-01-24 04:24:30 --> URI Class Initialized
INFO - 2017-01-24 04:24:30 --> Router Class Initialized
INFO - 2017-01-24 04:24:30 --> Output Class Initialized
INFO - 2017-01-24 04:24:30 --> Security Class Initialized
DEBUG - 2017-01-24 04:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:24:30 --> Input Class Initialized
INFO - 2017-01-24 04:24:30 --> Language Class Initialized
INFO - 2017-01-24 04:24:30 --> Loader Class Initialized
INFO - 2017-01-24 04:24:30 --> Database Driver Class Initialized
INFO - 2017-01-24 04:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:24:30 --> Controller Class Initialized
INFO - 2017-01-24 04:24:30 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:24:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:24:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:24:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:24:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:24:30 --> Final output sent to browser
DEBUG - 2017-01-24 04:24:30 --> Total execution time: 0.0291
INFO - 2017-01-24 04:24:50 --> Config Class Initialized
INFO - 2017-01-24 04:24:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:24:50 --> Utf8 Class Initialized
INFO - 2017-01-24 04:24:50 --> URI Class Initialized
INFO - 2017-01-24 04:24:50 --> Router Class Initialized
INFO - 2017-01-24 04:24:50 --> Output Class Initialized
INFO - 2017-01-24 04:24:50 --> Security Class Initialized
DEBUG - 2017-01-24 04:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:24:50 --> Input Class Initialized
INFO - 2017-01-24 04:24:50 --> Language Class Initialized
INFO - 2017-01-24 04:24:50 --> Loader Class Initialized
INFO - 2017-01-24 04:24:50 --> Database Driver Class Initialized
INFO - 2017-01-24 04:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:24:50 --> Controller Class Initialized
INFO - 2017-01-24 04:24:50 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:24:50 --> Final output sent to browser
DEBUG - 2017-01-24 04:24:50 --> Total execution time: 0.0147
INFO - 2017-01-24 04:24:53 --> Config Class Initialized
INFO - 2017-01-24 04:24:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:24:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:24:53 --> Utf8 Class Initialized
INFO - 2017-01-24 04:24:53 --> URI Class Initialized
INFO - 2017-01-24 04:24:53 --> Router Class Initialized
INFO - 2017-01-24 04:24:53 --> Output Class Initialized
INFO - 2017-01-24 04:24:53 --> Security Class Initialized
DEBUG - 2017-01-24 04:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:24:53 --> Input Class Initialized
INFO - 2017-01-24 04:24:53 --> Language Class Initialized
INFO - 2017-01-24 04:24:53 --> Loader Class Initialized
INFO - 2017-01-24 04:24:53 --> Database Driver Class Initialized
INFO - 2017-01-24 04:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:24:53 --> Controller Class Initialized
INFO - 2017-01-24 04:24:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:24:53 --> Final output sent to browser
DEBUG - 2017-01-24 04:24:53 --> Total execution time: 0.0132
INFO - 2017-01-24 04:25:31 --> Config Class Initialized
INFO - 2017-01-24 04:25:31 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:25:31 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:25:31 --> Utf8 Class Initialized
INFO - 2017-01-24 04:25:31 --> URI Class Initialized
INFO - 2017-01-24 04:25:31 --> Router Class Initialized
INFO - 2017-01-24 04:25:31 --> Output Class Initialized
INFO - 2017-01-24 04:25:31 --> Security Class Initialized
DEBUG - 2017-01-24 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:25:31 --> Input Class Initialized
INFO - 2017-01-24 04:25:31 --> Language Class Initialized
INFO - 2017-01-24 04:25:31 --> Loader Class Initialized
INFO - 2017-01-24 04:25:31 --> Database Driver Class Initialized
INFO - 2017-01-24 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:25:31 --> Controller Class Initialized
INFO - 2017-01-24 04:25:31 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:25:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 04:25:32 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 04:25:32 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'LiLi Coronado')
INFO - 2017-01-24 04:25:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 04:25:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 04:25:33 --> Config Class Initialized
INFO - 2017-01-24 04:25:33 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:25:33 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:25:33 --> Utf8 Class Initialized
INFO - 2017-01-24 04:25:33 --> URI Class Initialized
INFO - 2017-01-24 04:25:33 --> Router Class Initialized
INFO - 2017-01-24 04:25:33 --> Output Class Initialized
INFO - 2017-01-24 04:25:33 --> Security Class Initialized
DEBUG - 2017-01-24 04:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:25:33 --> Input Class Initialized
INFO - 2017-01-24 04:25:33 --> Language Class Initialized
INFO - 2017-01-24 04:25:33 --> Loader Class Initialized
INFO - 2017-01-24 04:25:33 --> Database Driver Class Initialized
INFO - 2017-01-24 04:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:25:33 --> Controller Class Initialized
INFO - 2017-01-24 04:25:33 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:25:33 --> Final output sent to browser
DEBUG - 2017-01-24 04:25:33 --> Total execution time: 0.0140
INFO - 2017-01-24 04:25:45 --> Config Class Initialized
INFO - 2017-01-24 04:25:45 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:25:45 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:25:45 --> Utf8 Class Initialized
INFO - 2017-01-24 04:25:45 --> URI Class Initialized
INFO - 2017-01-24 04:25:45 --> Router Class Initialized
INFO - 2017-01-24 04:25:45 --> Output Class Initialized
INFO - 2017-01-24 04:25:45 --> Security Class Initialized
DEBUG - 2017-01-24 04:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:25:45 --> Input Class Initialized
INFO - 2017-01-24 04:25:45 --> Language Class Initialized
INFO - 2017-01-24 04:25:45 --> Loader Class Initialized
INFO - 2017-01-24 04:25:45 --> Database Driver Class Initialized
INFO - 2017-01-24 04:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:25:45 --> Controller Class Initialized
INFO - 2017-01-24 04:25:45 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:25:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:25:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:25:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:25:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:25:45 --> Final output sent to browser
DEBUG - 2017-01-24 04:25:45 --> Total execution time: 0.0136
INFO - 2017-01-24 04:25:48 --> Config Class Initialized
INFO - 2017-01-24 04:25:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:25:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:25:48 --> Utf8 Class Initialized
INFO - 2017-01-24 04:25:48 --> URI Class Initialized
INFO - 2017-01-24 04:25:48 --> Router Class Initialized
INFO - 2017-01-24 04:25:48 --> Output Class Initialized
INFO - 2017-01-24 04:25:48 --> Security Class Initialized
DEBUG - 2017-01-24 04:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:25:48 --> Input Class Initialized
INFO - 2017-01-24 04:25:48 --> Language Class Initialized
INFO - 2017-01-24 04:25:48 --> Loader Class Initialized
INFO - 2017-01-24 04:25:48 --> Database Driver Class Initialized
INFO - 2017-01-24 04:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:25:48 --> Controller Class Initialized
INFO - 2017-01-24 04:25:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:25:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:25:48 --> Final output sent to browser
DEBUG - 2017-01-24 04:25:48 --> Total execution time: 0.0135
INFO - 2017-01-24 04:27:40 --> Config Class Initialized
INFO - 2017-01-24 04:27:40 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:27:40 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:27:40 --> Utf8 Class Initialized
INFO - 2017-01-24 04:27:40 --> URI Class Initialized
DEBUG - 2017-01-24 04:27:40 --> No URI present. Default controller set.
INFO - 2017-01-24 04:27:40 --> Router Class Initialized
INFO - 2017-01-24 04:27:40 --> Output Class Initialized
INFO - 2017-01-24 04:27:40 --> Security Class Initialized
DEBUG - 2017-01-24 04:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:27:40 --> Input Class Initialized
INFO - 2017-01-24 04:27:40 --> Language Class Initialized
INFO - 2017-01-24 04:27:40 --> Loader Class Initialized
INFO - 2017-01-24 04:27:40 --> Database Driver Class Initialized
INFO - 2017-01-24 04:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:27:40 --> Controller Class Initialized
INFO - 2017-01-24 04:27:40 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:27:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:27:40 --> Final output sent to browser
DEBUG - 2017-01-24 04:27:40 --> Total execution time: 0.0136
INFO - 2017-01-24 04:27:45 --> Config Class Initialized
INFO - 2017-01-24 04:27:45 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:27:45 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:27:45 --> Utf8 Class Initialized
INFO - 2017-01-24 04:27:45 --> URI Class Initialized
INFO - 2017-01-24 04:27:45 --> Router Class Initialized
INFO - 2017-01-24 04:27:45 --> Output Class Initialized
INFO - 2017-01-24 04:27:45 --> Security Class Initialized
DEBUG - 2017-01-24 04:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:27:45 --> Input Class Initialized
INFO - 2017-01-24 04:27:45 --> Language Class Initialized
INFO - 2017-01-24 04:27:45 --> Loader Class Initialized
INFO - 2017-01-24 04:27:45 --> Database Driver Class Initialized
INFO - 2017-01-24 04:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:27:45 --> Controller Class Initialized
INFO - 2017-01-24 04:27:45 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:27:45 --> Final output sent to browser
DEBUG - 2017-01-24 04:27:45 --> Total execution time: 0.0134
INFO - 2017-01-24 04:27:50 --> Config Class Initialized
INFO - 2017-01-24 04:27:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:27:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:27:50 --> Utf8 Class Initialized
INFO - 2017-01-24 04:27:50 --> URI Class Initialized
INFO - 2017-01-24 04:27:50 --> Router Class Initialized
INFO - 2017-01-24 04:27:50 --> Output Class Initialized
INFO - 2017-01-24 04:27:50 --> Security Class Initialized
DEBUG - 2017-01-24 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:27:50 --> Input Class Initialized
INFO - 2017-01-24 04:27:50 --> Language Class Initialized
INFO - 2017-01-24 04:27:50 --> Loader Class Initialized
INFO - 2017-01-24 04:27:50 --> Database Driver Class Initialized
INFO - 2017-01-24 04:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:27:50 --> Controller Class Initialized
INFO - 2017-01-24 04:27:50 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:27:51 --> Config Class Initialized
INFO - 2017-01-24 04:27:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:27:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:27:51 --> Utf8 Class Initialized
INFO - 2017-01-24 04:27:51 --> URI Class Initialized
INFO - 2017-01-24 04:27:51 --> Router Class Initialized
INFO - 2017-01-24 04:27:51 --> Output Class Initialized
INFO - 2017-01-24 04:27:51 --> Security Class Initialized
DEBUG - 2017-01-24 04:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:27:51 --> Input Class Initialized
INFO - 2017-01-24 04:27:51 --> Language Class Initialized
INFO - 2017-01-24 04:27:51 --> Loader Class Initialized
INFO - 2017-01-24 04:27:51 --> Database Driver Class Initialized
INFO - 2017-01-24 04:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:27:51 --> Controller Class Initialized
INFO - 2017-01-24 04:27:51 --> Helper loaded: date_helper
DEBUG - 2017-01-24 04:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:27:51 --> Helper loaded: url_helper
INFO - 2017-01-24 04:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 04:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 04:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 04:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:27:51 --> Final output sent to browser
DEBUG - 2017-01-24 04:27:51 --> Total execution time: 0.0147
INFO - 2017-01-24 04:27:53 --> Config Class Initialized
INFO - 2017-01-24 04:27:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:27:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:27:53 --> Utf8 Class Initialized
INFO - 2017-01-24 04:27:53 --> URI Class Initialized
INFO - 2017-01-24 04:27:53 --> Router Class Initialized
INFO - 2017-01-24 04:27:53 --> Output Class Initialized
INFO - 2017-01-24 04:27:53 --> Security Class Initialized
DEBUG - 2017-01-24 04:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:27:53 --> Input Class Initialized
INFO - 2017-01-24 04:27:53 --> Language Class Initialized
INFO - 2017-01-24 04:27:53 --> Loader Class Initialized
INFO - 2017-01-24 04:27:53 --> Database Driver Class Initialized
INFO - 2017-01-24 04:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:27:53 --> Controller Class Initialized
INFO - 2017-01-24 04:27:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:27:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:27:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:27:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:27:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:27:53 --> Final output sent to browser
DEBUG - 2017-01-24 04:27:53 --> Total execution time: 0.0135
INFO - 2017-01-24 04:28:08 --> Config Class Initialized
INFO - 2017-01-24 04:28:08 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:28:08 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:28:08 --> Utf8 Class Initialized
INFO - 2017-01-24 04:28:08 --> URI Class Initialized
DEBUG - 2017-01-24 04:28:08 --> No URI present. Default controller set.
INFO - 2017-01-24 04:28:08 --> Router Class Initialized
INFO - 2017-01-24 04:28:08 --> Output Class Initialized
INFO - 2017-01-24 04:28:08 --> Security Class Initialized
DEBUG - 2017-01-24 04:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:28:08 --> Input Class Initialized
INFO - 2017-01-24 04:28:08 --> Language Class Initialized
INFO - 2017-01-24 04:28:08 --> Loader Class Initialized
INFO - 2017-01-24 04:28:08 --> Database Driver Class Initialized
INFO - 2017-01-24 04:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:28:08 --> Controller Class Initialized
INFO - 2017-01-24 04:28:08 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:28:08 --> Final output sent to browser
DEBUG - 2017-01-24 04:28:08 --> Total execution time: 0.0132
INFO - 2017-01-24 04:28:10 --> Config Class Initialized
INFO - 2017-01-24 04:28:10 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:28:10 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:28:10 --> Utf8 Class Initialized
INFO - 2017-01-24 04:28:10 --> URI Class Initialized
INFO - 2017-01-24 04:28:10 --> Router Class Initialized
INFO - 2017-01-24 04:28:10 --> Output Class Initialized
INFO - 2017-01-24 04:28:10 --> Security Class Initialized
DEBUG - 2017-01-24 04:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:28:10 --> Input Class Initialized
INFO - 2017-01-24 04:28:10 --> Language Class Initialized
INFO - 2017-01-24 04:28:10 --> Loader Class Initialized
INFO - 2017-01-24 04:28:10 --> Database Driver Class Initialized
INFO - 2017-01-24 04:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:28:10 --> Controller Class Initialized
INFO - 2017-01-24 04:28:10 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:28:10 --> Final output sent to browser
DEBUG - 2017-01-24 04:28:10 --> Total execution time: 0.0138
INFO - 2017-01-24 04:29:11 --> Config Class Initialized
INFO - 2017-01-24 04:29:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:29:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:29:11 --> Utf8 Class Initialized
INFO - 2017-01-24 04:29:11 --> URI Class Initialized
INFO - 2017-01-24 04:29:11 --> Router Class Initialized
INFO - 2017-01-24 04:29:11 --> Output Class Initialized
INFO - 2017-01-24 04:29:11 --> Security Class Initialized
DEBUG - 2017-01-24 04:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:29:11 --> Input Class Initialized
INFO - 2017-01-24 04:29:11 --> Language Class Initialized
INFO - 2017-01-24 04:29:11 --> Loader Class Initialized
INFO - 2017-01-24 04:29:11 --> Database Driver Class Initialized
INFO - 2017-01-24 04:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:29:11 --> Controller Class Initialized
INFO - 2017-01-24 04:29:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:29:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:29:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:29:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:29:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:29:11 --> Final output sent to browser
DEBUG - 2017-01-24 04:29:11 --> Total execution time: 0.0144
INFO - 2017-01-24 04:29:13 --> Config Class Initialized
INFO - 2017-01-24 04:29:13 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:29:13 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:29:13 --> Utf8 Class Initialized
INFO - 2017-01-24 04:29:13 --> URI Class Initialized
INFO - 2017-01-24 04:29:13 --> Router Class Initialized
INFO - 2017-01-24 04:29:13 --> Output Class Initialized
INFO - 2017-01-24 04:29:13 --> Security Class Initialized
DEBUG - 2017-01-24 04:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:29:13 --> Input Class Initialized
INFO - 2017-01-24 04:29:13 --> Language Class Initialized
INFO - 2017-01-24 04:29:13 --> Loader Class Initialized
INFO - 2017-01-24 04:29:13 --> Database Driver Class Initialized
INFO - 2017-01-24 04:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:29:13 --> Controller Class Initialized
INFO - 2017-01-24 04:29:13 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:29:13 --> Final output sent to browser
DEBUG - 2017-01-24 04:29:13 --> Total execution time: 0.0142
INFO - 2017-01-24 04:29:46 --> Config Class Initialized
INFO - 2017-01-24 04:29:46 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:29:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:29:46 --> Utf8 Class Initialized
INFO - 2017-01-24 04:29:46 --> URI Class Initialized
INFO - 2017-01-24 04:29:46 --> Router Class Initialized
INFO - 2017-01-24 04:29:46 --> Output Class Initialized
INFO - 2017-01-24 04:29:46 --> Security Class Initialized
DEBUG - 2017-01-24 04:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:29:46 --> Input Class Initialized
INFO - 2017-01-24 04:29:46 --> Language Class Initialized
INFO - 2017-01-24 04:29:46 --> Loader Class Initialized
INFO - 2017-01-24 04:29:46 --> Database Driver Class Initialized
INFO - 2017-01-24 04:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:29:46 --> Controller Class Initialized
INFO - 2017-01-24 04:29:46 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:29:46 --> Final output sent to browser
DEBUG - 2017-01-24 04:29:46 --> Total execution time: 0.0141
INFO - 2017-01-24 04:29:48 --> Config Class Initialized
INFO - 2017-01-24 04:29:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:29:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:29:48 --> Utf8 Class Initialized
INFO - 2017-01-24 04:29:48 --> URI Class Initialized
INFO - 2017-01-24 04:29:48 --> Router Class Initialized
INFO - 2017-01-24 04:29:48 --> Output Class Initialized
INFO - 2017-01-24 04:29:48 --> Security Class Initialized
DEBUG - 2017-01-24 04:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:29:48 --> Input Class Initialized
INFO - 2017-01-24 04:29:48 --> Language Class Initialized
INFO - 2017-01-24 04:29:48 --> Loader Class Initialized
INFO - 2017-01-24 04:29:48 --> Database Driver Class Initialized
INFO - 2017-01-24 04:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:29:48 --> Controller Class Initialized
INFO - 2017-01-24 04:29:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:29:48 --> Final output sent to browser
DEBUG - 2017-01-24 04:29:48 --> Total execution time: 0.0132
INFO - 2017-01-24 04:29:54 --> Config Class Initialized
INFO - 2017-01-24 04:29:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:29:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:29:54 --> Utf8 Class Initialized
INFO - 2017-01-24 04:29:54 --> URI Class Initialized
INFO - 2017-01-24 04:29:54 --> Router Class Initialized
INFO - 2017-01-24 04:29:54 --> Output Class Initialized
INFO - 2017-01-24 04:29:54 --> Security Class Initialized
DEBUG - 2017-01-24 04:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:29:54 --> Input Class Initialized
INFO - 2017-01-24 04:29:54 --> Language Class Initialized
INFO - 2017-01-24 04:29:54 --> Loader Class Initialized
INFO - 2017-01-24 04:29:54 --> Database Driver Class Initialized
INFO - 2017-01-24 04:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:29:54 --> Controller Class Initialized
INFO - 2017-01-24 04:29:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:29:54 --> Final output sent to browser
DEBUG - 2017-01-24 04:29:54 --> Total execution time: 0.0149
INFO - 2017-01-24 04:29:56 --> Config Class Initialized
INFO - 2017-01-24 04:29:56 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:29:56 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:29:56 --> Utf8 Class Initialized
INFO - 2017-01-24 04:29:56 --> URI Class Initialized
INFO - 2017-01-24 04:29:56 --> Router Class Initialized
INFO - 2017-01-24 04:29:56 --> Output Class Initialized
INFO - 2017-01-24 04:29:56 --> Security Class Initialized
DEBUG - 2017-01-24 04:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:29:56 --> Input Class Initialized
INFO - 2017-01-24 04:29:56 --> Language Class Initialized
INFO - 2017-01-24 04:29:56 --> Loader Class Initialized
INFO - 2017-01-24 04:29:56 --> Database Driver Class Initialized
INFO - 2017-01-24 04:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:29:56 --> Controller Class Initialized
INFO - 2017-01-24 04:29:56 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:29:56 --> Final output sent to browser
DEBUG - 2017-01-24 04:29:56 --> Total execution time: 0.0136
INFO - 2017-01-24 04:29:59 --> Config Class Initialized
INFO - 2017-01-24 04:29:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:29:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:29:59 --> Utf8 Class Initialized
INFO - 2017-01-24 04:29:59 --> URI Class Initialized
INFO - 2017-01-24 04:29:59 --> Router Class Initialized
INFO - 2017-01-24 04:29:59 --> Output Class Initialized
INFO - 2017-01-24 04:29:59 --> Security Class Initialized
DEBUG - 2017-01-24 04:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:29:59 --> Input Class Initialized
INFO - 2017-01-24 04:29:59 --> Language Class Initialized
INFO - 2017-01-24 04:29:59 --> Loader Class Initialized
INFO - 2017-01-24 04:29:59 --> Database Driver Class Initialized
INFO - 2017-01-24 04:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:29:59 --> Controller Class Initialized
INFO - 2017-01-24 04:29:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:29:59 --> Final output sent to browser
DEBUG - 2017-01-24 04:29:59 --> Total execution time: 0.0143
INFO - 2017-01-24 04:30:01 --> Config Class Initialized
INFO - 2017-01-24 04:30:01 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:30:01 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:30:01 --> Utf8 Class Initialized
INFO - 2017-01-24 04:30:01 --> URI Class Initialized
INFO - 2017-01-24 04:30:01 --> Router Class Initialized
INFO - 2017-01-24 04:30:01 --> Output Class Initialized
INFO - 2017-01-24 04:30:01 --> Security Class Initialized
DEBUG - 2017-01-24 04:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:30:01 --> Input Class Initialized
INFO - 2017-01-24 04:30:01 --> Language Class Initialized
INFO - 2017-01-24 04:30:01 --> Loader Class Initialized
INFO - 2017-01-24 04:30:01 --> Database Driver Class Initialized
INFO - 2017-01-24 04:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:30:01 --> Controller Class Initialized
INFO - 2017-01-24 04:30:01 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:30:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:30:01 --> Final output sent to browser
DEBUG - 2017-01-24 04:30:01 --> Total execution time: 0.0146
INFO - 2017-01-24 04:30:21 --> Config Class Initialized
INFO - 2017-01-24 04:30:21 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:30:21 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:30:21 --> Utf8 Class Initialized
INFO - 2017-01-24 04:30:21 --> URI Class Initialized
INFO - 2017-01-24 04:30:21 --> Router Class Initialized
INFO - 2017-01-24 04:30:21 --> Output Class Initialized
INFO - 2017-01-24 04:30:21 --> Security Class Initialized
DEBUG - 2017-01-24 04:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:30:21 --> Input Class Initialized
INFO - 2017-01-24 04:30:21 --> Language Class Initialized
INFO - 2017-01-24 04:30:21 --> Loader Class Initialized
INFO - 2017-01-24 04:30:21 --> Database Driver Class Initialized
INFO - 2017-01-24 04:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:30:21 --> Controller Class Initialized
INFO - 2017-01-24 04:30:21 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:30:21 --> Final output sent to browser
DEBUG - 2017-01-24 04:30:21 --> Total execution time: 0.0144
INFO - 2017-01-24 04:30:32 --> Config Class Initialized
INFO - 2017-01-24 04:30:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 04:30:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 04:30:32 --> Utf8 Class Initialized
INFO - 2017-01-24 04:30:32 --> URI Class Initialized
INFO - 2017-01-24 04:30:32 --> Router Class Initialized
INFO - 2017-01-24 04:30:32 --> Output Class Initialized
INFO - 2017-01-24 04:30:32 --> Security Class Initialized
DEBUG - 2017-01-24 04:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 04:30:32 --> Input Class Initialized
INFO - 2017-01-24 04:30:32 --> Language Class Initialized
INFO - 2017-01-24 04:30:32 --> Loader Class Initialized
INFO - 2017-01-24 04:30:32 --> Database Driver Class Initialized
INFO - 2017-01-24 04:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 04:30:32 --> Controller Class Initialized
INFO - 2017-01-24 04:30:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 04:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 04:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 04:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 04:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 04:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 04:30:32 --> Final output sent to browser
DEBUG - 2017-01-24 04:30:32 --> Total execution time: 0.0141
INFO - 2017-01-24 15:21:25 --> Config Class Initialized
INFO - 2017-01-24 15:21:25 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:21:25 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:21:25 --> Utf8 Class Initialized
INFO - 2017-01-24 15:21:25 --> URI Class Initialized
DEBUG - 2017-01-24 15:21:25 --> No URI present. Default controller set.
INFO - 2017-01-24 15:21:25 --> Router Class Initialized
INFO - 2017-01-24 15:21:25 --> Output Class Initialized
INFO - 2017-01-24 15:21:25 --> Security Class Initialized
DEBUG - 2017-01-24 15:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:21:25 --> Input Class Initialized
INFO - 2017-01-24 15:21:25 --> Language Class Initialized
INFO - 2017-01-24 15:21:25 --> Loader Class Initialized
INFO - 2017-01-24 15:21:25 --> Database Driver Class Initialized
INFO - 2017-01-24 15:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:21:25 --> Controller Class Initialized
INFO - 2017-01-24 15:21:25 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 15:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 15:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 15:21:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 15:21:25 --> Final output sent to browser
DEBUG - 2017-01-24 15:21:25 --> Total execution time: 0.0367
INFO - 2017-01-24 15:38:54 --> Config Class Initialized
INFO - 2017-01-24 15:38:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:38:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:38:54 --> Utf8 Class Initialized
INFO - 2017-01-24 15:38:54 --> URI Class Initialized
INFO - 2017-01-24 15:38:54 --> Router Class Initialized
INFO - 2017-01-24 15:38:54 --> Output Class Initialized
INFO - 2017-01-24 15:38:54 --> Security Class Initialized
DEBUG - 2017-01-24 15:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:38:54 --> Input Class Initialized
INFO - 2017-01-24 15:38:54 --> Language Class Initialized
INFO - 2017-01-24 15:38:54 --> Loader Class Initialized
INFO - 2017-01-24 15:38:54 --> Database Driver Class Initialized
INFO - 2017-01-24 15:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:38:54 --> Controller Class Initialized
INFO - 2017-01-24 15:38:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:38:54 --> Helper loaded: form_helper
INFO - 2017-01-24 15:38:54 --> Form Validation Class Initialized
INFO - 2017-01-24 15:38:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 15:38:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-24 15:38:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 15:38:54 --> Final output sent to browser
DEBUG - 2017-01-24 15:38:54 --> Total execution time: 0.0705
INFO - 2017-01-24 15:39:17 --> Config Class Initialized
INFO - 2017-01-24 15:39:17 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:17 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:17 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:17 --> URI Class Initialized
INFO - 2017-01-24 15:39:17 --> Router Class Initialized
INFO - 2017-01-24 15:39:17 --> Output Class Initialized
INFO - 2017-01-24 15:39:17 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:17 --> Input Class Initialized
INFO - 2017-01-24 15:39:17 --> Language Class Initialized
INFO - 2017-01-24 15:39:17 --> Loader Class Initialized
INFO - 2017-01-24 15:39:17 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:17 --> Controller Class Initialized
INFO - 2017-01-24 15:39:17 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:17 --> Helper loaded: form_helper
INFO - 2017-01-24 15:39:17 --> Form Validation Class Initialized
INFO - 2017-01-24 15:39:17 --> Config Class Initialized
INFO - 2017-01-24 15:39:17 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:17 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:17 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:17 --> URI Class Initialized
INFO - 2017-01-24 15:39:17 --> Router Class Initialized
INFO - 2017-01-24 15:39:17 --> Output Class Initialized
INFO - 2017-01-24 15:39:17 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:17 --> Input Class Initialized
INFO - 2017-01-24 15:39:17 --> Language Class Initialized
INFO - 2017-01-24 15:39:17 --> Loader Class Initialized
INFO - 2017-01-24 15:39:17 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-24 15:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:17 --> Controller Class Initialized
INFO - 2017-01-24 15:39:17 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 15:39:17 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:17 --> Total execution time: 0.0491
INFO - 2017-01-24 15:39:17 --> Config Class Initialized
INFO - 2017-01-24 15:39:17 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:17 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:17 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:17 --> URI Class Initialized
INFO - 2017-01-24 15:39:17 --> Router Class Initialized
INFO - 2017-01-24 15:39:17 --> Output Class Initialized
INFO - 2017-01-24 15:39:17 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:17 --> Input Class Initialized
INFO - 2017-01-24 15:39:17 --> Language Class Initialized
INFO - 2017-01-24 15:39:17 --> Loader Class Initialized
INFO - 2017-01-24 15:39:17 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:17 --> Controller Class Initialized
INFO - 2017-01-24 15:39:17 --> Helper loaded: date_helper
INFO - 2017-01-24 15:39:17 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:17 --> Helper loaded: form_helper
INFO - 2017-01-24 15:39:17 --> Form Validation Class Initialized
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-24 15:39:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 15:39:17 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:17 --> Total execution time: 0.1003
INFO - 2017-01-24 15:39:18 --> Config Class Initialized
INFO - 2017-01-24 15:39:18 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:18 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:18 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:18 --> URI Class Initialized
INFO - 2017-01-24 15:39:18 --> Router Class Initialized
INFO - 2017-01-24 15:39:18 --> Output Class Initialized
INFO - 2017-01-24 15:39:18 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:18 --> Input Class Initialized
INFO - 2017-01-24 15:39:18 --> Language Class Initialized
INFO - 2017-01-24 15:39:18 --> Loader Class Initialized
INFO - 2017-01-24 15:39:18 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:18 --> Controller Class Initialized
INFO - 2017-01-24 15:39:18 --> Helper loaded: date_helper
INFO - 2017-01-24 15:39:18 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:18 --> Helper loaded: form_helper
INFO - 2017-01-24 15:39:18 --> Form Validation Class Initialized
INFO - 2017-01-24 15:39:18 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:18 --> Total execution time: 0.0777
INFO - 2017-01-24 15:39:20 --> Config Class Initialized
INFO - 2017-01-24 15:39:20 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:20 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:20 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:20 --> URI Class Initialized
INFO - 2017-01-24 15:39:20 --> Router Class Initialized
INFO - 2017-01-24 15:39:20 --> Output Class Initialized
INFO - 2017-01-24 15:39:20 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:20 --> Input Class Initialized
INFO - 2017-01-24 15:39:20 --> Language Class Initialized
INFO - 2017-01-24 15:39:20 --> Loader Class Initialized
INFO - 2017-01-24 15:39:20 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:20 --> Controller Class Initialized
INFO - 2017-01-24 15:39:20 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 15:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 15:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 15:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 15:39:20 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:20 --> Total execution time: 0.0165
INFO - 2017-01-24 15:39:52 --> Config Class Initialized
INFO - 2017-01-24 15:39:52 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:52 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:52 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:52 --> URI Class Initialized
INFO - 2017-01-24 15:39:52 --> Router Class Initialized
INFO - 2017-01-24 15:39:52 --> Output Class Initialized
INFO - 2017-01-24 15:39:52 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:52 --> Input Class Initialized
INFO - 2017-01-24 15:39:52 --> Language Class Initialized
INFO - 2017-01-24 15:39:52 --> Loader Class Initialized
INFO - 2017-01-24 15:39:52 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:52 --> Controller Class Initialized
INFO - 2017-01-24 15:39:52 --> Helper loaded: date_helper
INFO - 2017-01-24 15:39:52 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:52 --> Helper loaded: form_helper
INFO - 2017-01-24 15:39:52 --> Form Validation Class Initialized
INFO - 2017-01-24 15:39:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 15:39:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 15:39:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 15:39:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 15:39:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 15:39:52 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:52 --> Total execution time: 0.1418
INFO - 2017-01-24 15:39:52 --> Config Class Initialized
INFO - 2017-01-24 15:39:52 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:52 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:52 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:52 --> URI Class Initialized
INFO - 2017-01-24 15:39:52 --> Router Class Initialized
INFO - 2017-01-24 15:39:52 --> Output Class Initialized
INFO - 2017-01-24 15:39:52 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:52 --> Input Class Initialized
INFO - 2017-01-24 15:39:52 --> Language Class Initialized
INFO - 2017-01-24 15:39:52 --> Loader Class Initialized
INFO - 2017-01-24 15:39:52 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:52 --> Controller Class Initialized
INFO - 2017-01-24 15:39:52 --> Helper loaded: date_helper
INFO - 2017-01-24 15:39:52 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:52 --> Helper loaded: form_helper
INFO - 2017-01-24 15:39:52 --> Form Validation Class Initialized
INFO - 2017-01-24 15:39:52 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:52 --> Total execution time: 0.0242
INFO - 2017-01-24 15:39:53 --> Config Class Initialized
INFO - 2017-01-24 15:39:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:53 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:53 --> URI Class Initialized
INFO - 2017-01-24 15:39:53 --> Router Class Initialized
INFO - 2017-01-24 15:39:53 --> Output Class Initialized
INFO - 2017-01-24 15:39:53 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:53 --> Input Class Initialized
INFO - 2017-01-24 15:39:53 --> Language Class Initialized
INFO - 2017-01-24 15:39:53 --> Loader Class Initialized
INFO - 2017-01-24 15:39:53 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:53 --> Controller Class Initialized
INFO - 2017-01-24 15:39:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 15:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 15:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 15:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 15:39:53 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:53 --> Total execution time: 0.0151
INFO - 2017-01-24 15:39:55 --> Config Class Initialized
INFO - 2017-01-24 15:39:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:39:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:55 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:55 --> URI Class Initialized
INFO - 2017-01-24 15:39:55 --> Router Class Initialized
INFO - 2017-01-24 15:39:55 --> Output Class Initialized
INFO - 2017-01-24 15:39:55 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:55 --> Input Class Initialized
INFO - 2017-01-24 15:39:55 --> Config Class Initialized
INFO - 2017-01-24 15:39:55 --> Hooks Class Initialized
INFO - 2017-01-24 15:39:55 --> Language Class Initialized
DEBUG - 2017-01-24 15:39:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:39:55 --> Utf8 Class Initialized
INFO - 2017-01-24 15:39:55 --> Loader Class Initialized
INFO - 2017-01-24 15:39:55 --> URI Class Initialized
INFO - 2017-01-24 15:39:55 --> Router Class Initialized
INFO - 2017-01-24 15:39:55 --> Output Class Initialized
INFO - 2017-01-24 15:39:55 --> Security Class Initialized
DEBUG - 2017-01-24 15:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:39:55 --> Input Class Initialized
INFO - 2017-01-24 15:39:55 --> Language Class Initialized
INFO - 2017-01-24 15:39:55 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:55 --> Loader Class Initialized
INFO - 2017-01-24 15:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:55 --> Controller Class Initialized
INFO - 2017-01-24 15:39:55 --> Helper loaded: date_helper
INFO - 2017-01-24 15:39:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:55 --> Database Driver Class Initialized
INFO - 2017-01-24 15:39:55 --> Helper loaded: form_helper
INFO - 2017-01-24 15:39:55 --> Form Validation Class Initialized
INFO - 2017-01-24 15:39:55 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:55 --> Total execution time: 0.0157
INFO - 2017-01-24 15:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:39:55 --> Controller Class Initialized
INFO - 2017-01-24 15:39:55 --> Helper loaded: date_helper
INFO - 2017-01-24 15:39:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:39:55 --> Helper loaded: form_helper
INFO - 2017-01-24 15:39:55 --> Form Validation Class Initialized
INFO - 2017-01-24 15:39:55 --> Final output sent to browser
DEBUG - 2017-01-24 15:39:55 --> Total execution time: 0.0910
INFO - 2017-01-24 15:40:11 --> Config Class Initialized
INFO - 2017-01-24 15:40:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:40:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:40:11 --> Utf8 Class Initialized
INFO - 2017-01-24 15:40:11 --> URI Class Initialized
INFO - 2017-01-24 15:40:11 --> Router Class Initialized
INFO - 2017-01-24 15:40:11 --> Output Class Initialized
INFO - 2017-01-24 15:40:11 --> Security Class Initialized
DEBUG - 2017-01-24 15:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:40:11 --> Input Class Initialized
INFO - 2017-01-24 15:40:11 --> Language Class Initialized
INFO - 2017-01-24 15:40:11 --> Loader Class Initialized
INFO - 2017-01-24 15:40:11 --> Database Driver Class Initialized
INFO - 2017-01-24 15:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:40:11 --> Controller Class Initialized
INFO - 2017-01-24 15:40:11 --> Helper loaded: date_helper
INFO - 2017-01-24 15:40:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:40:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:40:11 --> Helper loaded: form_helper
INFO - 2017-01-24 15:40:11 --> Form Validation Class Initialized
INFO - 2017-01-24 15:40:11 --> Final output sent to browser
DEBUG - 2017-01-24 15:40:11 --> Total execution time: 0.0182
INFO - 2017-01-24 15:57:15 --> Config Class Initialized
INFO - 2017-01-24 15:57:15 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:57:16 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:57:16 --> Utf8 Class Initialized
INFO - 2017-01-24 15:57:16 --> URI Class Initialized
INFO - 2017-01-24 15:57:16 --> Router Class Initialized
INFO - 2017-01-24 15:57:16 --> Output Class Initialized
INFO - 2017-01-24 15:57:16 --> Security Class Initialized
DEBUG - 2017-01-24 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:57:16 --> Input Class Initialized
INFO - 2017-01-24 15:57:16 --> Language Class Initialized
INFO - 2017-01-24 15:57:16 --> Loader Class Initialized
INFO - 2017-01-24 15:57:16 --> Database Driver Class Initialized
INFO - 2017-01-24 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:57:16 --> Controller Class Initialized
INFO - 2017-01-24 15:57:16 --> Helper loaded: date_helper
INFO - 2017-01-24 15:57:16 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:57:16 --> Helper loaded: form_helper
INFO - 2017-01-24 15:57:16 --> Form Validation Class Initialized
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 15:57:16 --> Final output sent to browser
DEBUG - 2017-01-24 15:57:16 --> Total execution time: 0.3296
INFO - 2017-01-24 15:57:16 --> Config Class Initialized
INFO - 2017-01-24 15:57:16 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:57:16 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:57:16 --> Utf8 Class Initialized
INFO - 2017-01-24 15:57:16 --> URI Class Initialized
INFO - 2017-01-24 15:57:16 --> Router Class Initialized
INFO - 2017-01-24 15:57:16 --> Output Class Initialized
INFO - 2017-01-24 15:57:16 --> Security Class Initialized
DEBUG - 2017-01-24 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:57:16 --> Input Class Initialized
INFO - 2017-01-24 15:57:16 --> Language Class Initialized
INFO - 2017-01-24 15:57:16 --> Loader Class Initialized
INFO - 2017-01-24 15:57:16 --> Database Driver Class Initialized
INFO - 2017-01-24 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:57:16 --> Controller Class Initialized
INFO - 2017-01-24 15:57:16 --> Helper loaded: date_helper
INFO - 2017-01-24 15:57:16 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:57:16 --> Helper loaded: form_helper
INFO - 2017-01-24 15:57:16 --> Form Validation Class Initialized
INFO - 2017-01-24 15:57:16 --> Config Class Initialized
INFO - 2017-01-24 15:57:16 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:57:16 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:57:16 --> Utf8 Class Initialized
INFO - 2017-01-24 15:57:16 --> URI Class Initialized
INFO - 2017-01-24 15:57:16 --> Router Class Initialized
INFO - 2017-01-24 15:57:16 --> Final output sent to browser
DEBUG - 2017-01-24 15:57:16 --> Total execution time: 0.0379
INFO - 2017-01-24 15:57:16 --> Output Class Initialized
INFO - 2017-01-24 15:57:16 --> Security Class Initialized
DEBUG - 2017-01-24 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:57:16 --> Input Class Initialized
INFO - 2017-01-24 15:57:16 --> Language Class Initialized
INFO - 2017-01-24 15:57:16 --> Loader Class Initialized
INFO - 2017-01-24 15:57:16 --> Database Driver Class Initialized
INFO - 2017-01-24 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:57:16 --> Controller Class Initialized
INFO - 2017-01-24 15:57:16 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 15:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 15:57:16 --> Final output sent to browser
DEBUG - 2017-01-24 15:57:16 --> Total execution time: 0.0824
INFO - 2017-01-24 15:57:18 --> Config Class Initialized
INFO - 2017-01-24 15:57:18 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:57:18 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:57:18 --> Utf8 Class Initialized
INFO - 2017-01-24 15:57:18 --> URI Class Initialized
INFO - 2017-01-24 15:57:18 --> Router Class Initialized
INFO - 2017-01-24 15:57:18 --> Output Class Initialized
INFO - 2017-01-24 15:57:18 --> Security Class Initialized
DEBUG - 2017-01-24 15:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:57:18 --> Input Class Initialized
INFO - 2017-01-24 15:57:18 --> Language Class Initialized
INFO - 2017-01-24 15:57:18 --> Loader Class Initialized
INFO - 2017-01-24 15:57:18 --> Config Class Initialized
INFO - 2017-01-24 15:57:18 --> Hooks Class Initialized
INFO - 2017-01-24 15:57:18 --> Database Driver Class Initialized
DEBUG - 2017-01-24 15:57:18 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:57:18 --> Utf8 Class Initialized
INFO - 2017-01-24 15:57:18 --> URI Class Initialized
INFO - 2017-01-24 15:57:18 --> Router Class Initialized
INFO - 2017-01-24 15:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:57:18 --> Controller Class Initialized
INFO - 2017-01-24 15:57:18 --> Output Class Initialized
INFO - 2017-01-24 15:57:18 --> Helper loaded: date_helper
INFO - 2017-01-24 15:57:18 --> Security Class Initialized
INFO - 2017-01-24 15:57:18 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:57:18 --> Input Class Initialized
DEBUG - 2017-01-24 15:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:57:18 --> Language Class Initialized
INFO - 2017-01-24 15:57:18 --> Loader Class Initialized
INFO - 2017-01-24 15:57:18 --> Helper loaded: form_helper
INFO - 2017-01-24 15:57:18 --> Form Validation Class Initialized
INFO - 2017-01-24 15:57:18 --> Database Driver Class Initialized
INFO - 2017-01-24 15:57:18 --> Final output sent to browser
DEBUG - 2017-01-24 15:57:18 --> Total execution time: 0.0213
INFO - 2017-01-24 15:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:57:18 --> Controller Class Initialized
INFO - 2017-01-24 15:57:19 --> Helper loaded: date_helper
INFO - 2017-01-24 15:57:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:57:19 --> Helper loaded: form_helper
INFO - 2017-01-24 15:57:19 --> Form Validation Class Initialized
INFO - 2017-01-24 15:57:19 --> Final output sent to browser
DEBUG - 2017-01-24 15:57:19 --> Total execution time: 0.0858
INFO - 2017-01-24 15:58:56 --> Config Class Initialized
INFO - 2017-01-24 15:58:56 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:58:56 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:58:56 --> Utf8 Class Initialized
INFO - 2017-01-24 15:58:56 --> URI Class Initialized
INFO - 2017-01-24 15:58:56 --> Router Class Initialized
INFO - 2017-01-24 15:58:56 --> Output Class Initialized
INFO - 2017-01-24 15:58:56 --> Security Class Initialized
DEBUG - 2017-01-24 15:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:58:56 --> Input Class Initialized
INFO - 2017-01-24 15:58:56 --> Language Class Initialized
INFO - 2017-01-24 15:58:56 --> Loader Class Initialized
INFO - 2017-01-24 15:58:56 --> Database Driver Class Initialized
INFO - 2017-01-24 15:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:58:56 --> Controller Class Initialized
INFO - 2017-01-24 15:58:56 --> Helper loaded: date_helper
INFO - 2017-01-24 15:58:56 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:58:56 --> Helper loaded: form_helper
INFO - 2017-01-24 15:58:56 --> Form Validation Class Initialized
INFO - 2017-01-24 15:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 15:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 15:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 15:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 15:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 15:58:56 --> Final output sent to browser
DEBUG - 2017-01-24 15:58:56 --> Total execution time: 0.0619
INFO - 2017-01-24 15:58:57 --> Config Class Initialized
INFO - 2017-01-24 15:58:57 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:58:57 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:58:57 --> Utf8 Class Initialized
INFO - 2017-01-24 15:58:57 --> URI Class Initialized
INFO - 2017-01-24 15:58:57 --> Router Class Initialized
INFO - 2017-01-24 15:58:57 --> Output Class Initialized
INFO - 2017-01-24 15:58:57 --> Security Class Initialized
DEBUG - 2017-01-24 15:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:58:57 --> Input Class Initialized
INFO - 2017-01-24 15:58:57 --> Language Class Initialized
INFO - 2017-01-24 15:58:57 --> Loader Class Initialized
INFO - 2017-01-24 15:58:57 --> Database Driver Class Initialized
INFO - 2017-01-24 15:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:58:57 --> Controller Class Initialized
INFO - 2017-01-24 15:58:57 --> Helper loaded: date_helper
INFO - 2017-01-24 15:58:57 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:58:57 --> Helper loaded: form_helper
INFO - 2017-01-24 15:58:57 --> Form Validation Class Initialized
INFO - 2017-01-24 15:58:57 --> Final output sent to browser
DEBUG - 2017-01-24 15:58:57 --> Total execution time: 0.0637
INFO - 2017-01-24 15:58:57 --> Config Class Initialized
INFO - 2017-01-24 15:58:57 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:58:57 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:58:57 --> Utf8 Class Initialized
INFO - 2017-01-24 15:58:57 --> URI Class Initialized
INFO - 2017-01-24 15:58:57 --> Router Class Initialized
INFO - 2017-01-24 15:58:57 --> Output Class Initialized
INFO - 2017-01-24 15:58:57 --> Security Class Initialized
DEBUG - 2017-01-24 15:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:58:57 --> Input Class Initialized
INFO - 2017-01-24 15:58:57 --> Language Class Initialized
INFO - 2017-01-24 15:58:57 --> Loader Class Initialized
INFO - 2017-01-24 15:58:57 --> Database Driver Class Initialized
INFO - 2017-01-24 15:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:58:57 --> Controller Class Initialized
INFO - 2017-01-24 15:58:57 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 15:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 15:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 15:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 15:58:57 --> Final output sent to browser
DEBUG - 2017-01-24 15:58:57 --> Total execution time: 0.0146
INFO - 2017-01-24 15:58:59 --> Config Class Initialized
INFO - 2017-01-24 15:58:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:58:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:58:59 --> Utf8 Class Initialized
INFO - 2017-01-24 15:58:59 --> URI Class Initialized
INFO - 2017-01-24 15:58:59 --> Router Class Initialized
INFO - 2017-01-24 15:58:59 --> Output Class Initialized
INFO - 2017-01-24 15:58:59 --> Security Class Initialized
INFO - 2017-01-24 15:58:59 --> Config Class Initialized
INFO - 2017-01-24 15:58:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 15:58:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 15:58:59 --> Utf8 Class Initialized
INFO - 2017-01-24 15:58:59 --> URI Class Initialized
INFO - 2017-01-24 15:58:59 --> Router Class Initialized
INFO - 2017-01-24 15:58:59 --> Output Class Initialized
DEBUG - 2017-01-24 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:58:59 --> Input Class Initialized
INFO - 2017-01-24 15:58:59 --> Language Class Initialized
INFO - 2017-01-24 15:58:59 --> Loader Class Initialized
INFO - 2017-01-24 15:58:59 --> Database Driver Class Initialized
INFO - 2017-01-24 15:58:59 --> Security Class Initialized
DEBUG - 2017-01-24 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 15:58:59 --> Input Class Initialized
INFO - 2017-01-24 15:58:59 --> Language Class Initialized
INFO - 2017-01-24 15:58:59 --> Loader Class Initialized
INFO - 2017-01-24 15:58:59 --> Database Driver Class Initialized
INFO - 2017-01-24 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:58:59 --> Controller Class Initialized
INFO - 2017-01-24 15:58:59 --> Helper loaded: date_helper
INFO - 2017-01-24 15:58:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:58:59 --> Helper loaded: form_helper
INFO - 2017-01-24 15:58:59 --> Form Validation Class Initialized
INFO - 2017-01-24 15:58:59 --> Final output sent to browser
DEBUG - 2017-01-24 15:58:59 --> Total execution time: 0.0353
INFO - 2017-01-24 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 15:58:59 --> Controller Class Initialized
INFO - 2017-01-24 15:58:59 --> Helper loaded: date_helper
INFO - 2017-01-24 15:58:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 15:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 15:58:59 --> Helper loaded: form_helper
INFO - 2017-01-24 15:58:59 --> Form Validation Class Initialized
INFO - 2017-01-24 15:58:59 --> Final output sent to browser
DEBUG - 2017-01-24 15:58:59 --> Total execution time: 0.0811
INFO - 2017-01-24 16:00:08 --> Config Class Initialized
INFO - 2017-01-24 16:00:08 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:00:08 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:00:08 --> Utf8 Class Initialized
INFO - 2017-01-24 16:00:08 --> URI Class Initialized
INFO - 2017-01-24 16:00:08 --> Router Class Initialized
INFO - 2017-01-24 16:00:08 --> Output Class Initialized
INFO - 2017-01-24 16:00:08 --> Security Class Initialized
DEBUG - 2017-01-24 16:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:00:08 --> Input Class Initialized
INFO - 2017-01-24 16:00:08 --> Language Class Initialized
INFO - 2017-01-24 16:00:08 --> Loader Class Initialized
INFO - 2017-01-24 16:00:08 --> Database Driver Class Initialized
INFO - 2017-01-24 16:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:00:08 --> Controller Class Initialized
INFO - 2017-01-24 16:00:08 --> Helper loaded: date_helper
INFO - 2017-01-24 16:00:08 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:00:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:00:08 --> Helper loaded: form_helper
INFO - 2017-01-24 16:00:08 --> Form Validation Class Initialized
INFO - 2017-01-24 16:00:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:00:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:00:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:00:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:00:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:00:08 --> Final output sent to browser
DEBUG - 2017-01-24 16:00:08 --> Total execution time: 0.0310
INFO - 2017-01-24 16:00:09 --> Config Class Initialized
INFO - 2017-01-24 16:00:09 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:00:09 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:00:09 --> Utf8 Class Initialized
INFO - 2017-01-24 16:00:09 --> URI Class Initialized
INFO - 2017-01-24 16:00:09 --> Router Class Initialized
INFO - 2017-01-24 16:00:09 --> Output Class Initialized
INFO - 2017-01-24 16:00:09 --> Security Class Initialized
DEBUG - 2017-01-24 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:00:09 --> Input Class Initialized
INFO - 2017-01-24 16:00:09 --> Language Class Initialized
INFO - 2017-01-24 16:00:09 --> Loader Class Initialized
INFO - 2017-01-24 16:00:09 --> Database Driver Class Initialized
INFO - 2017-01-24 16:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:00:09 --> Controller Class Initialized
INFO - 2017-01-24 16:00:09 --> Helper loaded: date_helper
INFO - 2017-01-24 16:00:09 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:00:09 --> Helper loaded: form_helper
INFO - 2017-01-24 16:00:09 --> Form Validation Class Initialized
INFO - 2017-01-24 16:00:09 --> Final output sent to browser
DEBUG - 2017-01-24 16:00:09 --> Total execution time: 0.0152
INFO - 2017-01-24 16:00:09 --> Config Class Initialized
INFO - 2017-01-24 16:00:09 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:00:09 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:00:09 --> Utf8 Class Initialized
INFO - 2017-01-24 16:00:09 --> URI Class Initialized
INFO - 2017-01-24 16:00:09 --> Router Class Initialized
INFO - 2017-01-24 16:00:09 --> Output Class Initialized
INFO - 2017-01-24 16:00:09 --> Security Class Initialized
DEBUG - 2017-01-24 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:00:09 --> Input Class Initialized
INFO - 2017-01-24 16:00:09 --> Language Class Initialized
INFO - 2017-01-24 16:00:09 --> Loader Class Initialized
INFO - 2017-01-24 16:00:09 --> Database Driver Class Initialized
INFO - 2017-01-24 16:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:00:09 --> Controller Class Initialized
INFO - 2017-01-24 16:00:09 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:00:09 --> Final output sent to browser
DEBUG - 2017-01-24 16:00:09 --> Total execution time: 0.0143
INFO - 2017-01-24 16:00:10 --> Config Class Initialized
INFO - 2017-01-24 16:00:10 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:00:10 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:00:10 --> Utf8 Class Initialized
INFO - 2017-01-24 16:00:10 --> URI Class Initialized
INFO - 2017-01-24 16:00:10 --> Router Class Initialized
INFO - 2017-01-24 16:00:10 --> Output Class Initialized
INFO - 2017-01-24 16:00:10 --> Security Class Initialized
DEBUG - 2017-01-24 16:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:00:10 --> Input Class Initialized
INFO - 2017-01-24 16:00:10 --> Language Class Initialized
ERROR - 2017-01-24 16:00:10 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:00:14 --> Config Class Initialized
INFO - 2017-01-24 16:00:14 --> Hooks Class Initialized
INFO - 2017-01-24 16:00:14 --> Config Class Initialized
INFO - 2017-01-24 16:00:14 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:00:14 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:00:14 --> Utf8 Class Initialized
DEBUG - 2017-01-24 16:00:14 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:00:14 --> Utf8 Class Initialized
INFO - 2017-01-24 16:00:14 --> URI Class Initialized
INFO - 2017-01-24 16:00:14 --> URI Class Initialized
INFO - 2017-01-24 16:00:14 --> Router Class Initialized
INFO - 2017-01-24 16:00:14 --> Router Class Initialized
INFO - 2017-01-24 16:00:14 --> Output Class Initialized
INFO - 2017-01-24 16:00:14 --> Output Class Initialized
INFO - 2017-01-24 16:00:14 --> Security Class Initialized
INFO - 2017-01-24 16:00:14 --> Security Class Initialized
DEBUG - 2017-01-24 16:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-24 16:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:00:14 --> Input Class Initialized
INFO - 2017-01-24 16:00:14 --> Input Class Initialized
INFO - 2017-01-24 16:00:14 --> Language Class Initialized
INFO - 2017-01-24 16:00:14 --> Language Class Initialized
INFO - 2017-01-24 16:00:14 --> Loader Class Initialized
INFO - 2017-01-24 16:00:14 --> Loader Class Initialized
INFO - 2017-01-24 16:00:14 --> Database Driver Class Initialized
INFO - 2017-01-24 16:00:14 --> Database Driver Class Initialized
INFO - 2017-01-24 16:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:00:14 --> Controller Class Initialized
INFO - 2017-01-24 16:00:14 --> Helper loaded: date_helper
INFO - 2017-01-24 16:00:14 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:00:14 --> Helper loaded: form_helper
INFO - 2017-01-24 16:00:14 --> Form Validation Class Initialized
INFO - 2017-01-24 16:00:14 --> Final output sent to browser
DEBUG - 2017-01-24 16:00:14 --> Total execution time: 0.0167
INFO - 2017-01-24 16:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:00:14 --> Controller Class Initialized
INFO - 2017-01-24 16:00:14 --> Helper loaded: date_helper
INFO - 2017-01-24 16:00:14 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:00:14 --> Helper loaded: form_helper
INFO - 2017-01-24 16:00:14 --> Form Validation Class Initialized
INFO - 2017-01-24 16:00:14 --> Final output sent to browser
DEBUG - 2017-01-24 16:00:14 --> Total execution time: 0.0252
INFO - 2017-01-24 16:01:46 --> Config Class Initialized
INFO - 2017-01-24 16:01:46 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:01:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:01:46 --> Utf8 Class Initialized
INFO - 2017-01-24 16:01:46 --> URI Class Initialized
INFO - 2017-01-24 16:01:46 --> Router Class Initialized
INFO - 2017-01-24 16:01:46 --> Output Class Initialized
INFO - 2017-01-24 16:01:46 --> Security Class Initialized
DEBUG - 2017-01-24 16:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:01:46 --> Input Class Initialized
INFO - 2017-01-24 16:01:46 --> Language Class Initialized
INFO - 2017-01-24 16:01:46 --> Loader Class Initialized
INFO - 2017-01-24 16:01:46 --> Database Driver Class Initialized
INFO - 2017-01-24 16:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:01:46 --> Controller Class Initialized
INFO - 2017-01-24 16:01:46 --> Helper loaded: date_helper
INFO - 2017-01-24 16:01:46 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:01:46 --> Helper loaded: form_helper
INFO - 2017-01-24 16:01:46 --> Form Validation Class Initialized
INFO - 2017-01-24 16:01:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:01:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:01:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:01:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:01:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:01:46 --> Final output sent to browser
DEBUG - 2017-01-24 16:01:46 --> Total execution time: 0.0563
INFO - 2017-01-24 16:01:46 --> Config Class Initialized
INFO - 2017-01-24 16:01:46 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:01:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:01:46 --> Utf8 Class Initialized
INFO - 2017-01-24 16:01:46 --> URI Class Initialized
INFO - 2017-01-24 16:01:46 --> Router Class Initialized
INFO - 2017-01-24 16:01:46 --> Output Class Initialized
INFO - 2017-01-24 16:01:46 --> Security Class Initialized
DEBUG - 2017-01-24 16:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:01:46 --> Input Class Initialized
INFO - 2017-01-24 16:01:46 --> Language Class Initialized
ERROR - 2017-01-24 16:01:46 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:01:47 --> Config Class Initialized
INFO - 2017-01-24 16:01:47 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:01:47 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:01:47 --> Utf8 Class Initialized
INFO - 2017-01-24 16:01:47 --> URI Class Initialized
INFO - 2017-01-24 16:01:47 --> Router Class Initialized
INFO - 2017-01-24 16:01:47 --> Output Class Initialized
INFO - 2017-01-24 16:01:47 --> Security Class Initialized
DEBUG - 2017-01-24 16:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:01:47 --> Input Class Initialized
INFO - 2017-01-24 16:01:47 --> Language Class Initialized
INFO - 2017-01-24 16:01:47 --> Loader Class Initialized
INFO - 2017-01-24 16:01:47 --> Database Driver Class Initialized
INFO - 2017-01-24 16:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:01:47 --> Controller Class Initialized
INFO - 2017-01-24 16:01:47 --> Helper loaded: date_helper
INFO - 2017-01-24 16:01:47 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:01:47 --> Helper loaded: form_helper
INFO - 2017-01-24 16:01:47 --> Form Validation Class Initialized
INFO - 2017-01-24 16:01:47 --> Final output sent to browser
DEBUG - 2017-01-24 16:01:47 --> Total execution time: 0.1016
INFO - 2017-01-24 16:01:47 --> Config Class Initialized
INFO - 2017-01-24 16:01:47 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:01:47 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:01:47 --> Utf8 Class Initialized
INFO - 2017-01-24 16:01:47 --> URI Class Initialized
INFO - 2017-01-24 16:01:47 --> Router Class Initialized
INFO - 2017-01-24 16:01:47 --> Output Class Initialized
INFO - 2017-01-24 16:01:47 --> Security Class Initialized
DEBUG - 2017-01-24 16:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:01:47 --> Input Class Initialized
INFO - 2017-01-24 16:01:47 --> Language Class Initialized
INFO - 2017-01-24 16:01:47 --> Loader Class Initialized
INFO - 2017-01-24 16:01:47 --> Database Driver Class Initialized
INFO - 2017-01-24 16:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:01:47 --> Controller Class Initialized
INFO - 2017-01-24 16:01:47 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:01:47 --> Final output sent to browser
DEBUG - 2017-01-24 16:01:47 --> Total execution time: 0.0736
INFO - 2017-01-24 16:01:48 --> Config Class Initialized
INFO - 2017-01-24 16:01:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:01:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:01:48 --> Utf8 Class Initialized
INFO - 2017-01-24 16:01:48 --> URI Class Initialized
INFO - 2017-01-24 16:01:48 --> Router Class Initialized
INFO - 2017-01-24 16:01:48 --> Config Class Initialized
INFO - 2017-01-24 16:01:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:01:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:01:48 --> Utf8 Class Initialized
INFO - 2017-01-24 16:01:48 --> Output Class Initialized
INFO - 2017-01-24 16:01:48 --> Security Class Initialized
DEBUG - 2017-01-24 16:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:01:48 --> Input Class Initialized
INFO - 2017-01-24 16:01:48 --> Language Class Initialized
INFO - 2017-01-24 16:01:48 --> Loader Class Initialized
INFO - 2017-01-24 16:01:48 --> Database Driver Class Initialized
INFO - 2017-01-24 16:01:48 --> URI Class Initialized
INFO - 2017-01-24 16:01:48 --> Router Class Initialized
INFO - 2017-01-24 16:01:48 --> Output Class Initialized
INFO - 2017-01-24 16:01:48 --> Security Class Initialized
DEBUG - 2017-01-24 16:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:01:48 --> Input Class Initialized
INFO - 2017-01-24 16:01:48 --> Language Class Initialized
INFO - 2017-01-24 16:01:48 --> Loader Class Initialized
INFO - 2017-01-24 16:01:48 --> Database Driver Class Initialized
INFO - 2017-01-24 16:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:01:48 --> Controller Class Initialized
INFO - 2017-01-24 16:01:48 --> Helper loaded: date_helper
INFO - 2017-01-24 16:01:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:01:48 --> Helper loaded: form_helper
INFO - 2017-01-24 16:01:48 --> Form Validation Class Initialized
INFO - 2017-01-24 16:01:48 --> Final output sent to browser
DEBUG - 2017-01-24 16:01:48 --> Total execution time: 0.0389
INFO - 2017-01-24 16:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:01:48 --> Controller Class Initialized
INFO - 2017-01-24 16:01:48 --> Helper loaded: date_helper
INFO - 2017-01-24 16:01:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:01:48 --> Helper loaded: form_helper
INFO - 2017-01-24 16:01:48 --> Form Validation Class Initialized
INFO - 2017-01-24 16:01:48 --> Final output sent to browser
DEBUG - 2017-01-24 16:01:48 --> Total execution time: 0.0901
INFO - 2017-01-24 16:02:32 --> Config Class Initialized
INFO - 2017-01-24 16:02:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:02:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:02:32 --> Utf8 Class Initialized
INFO - 2017-01-24 16:02:32 --> URI Class Initialized
INFO - 2017-01-24 16:02:32 --> Router Class Initialized
INFO - 2017-01-24 16:02:32 --> Output Class Initialized
INFO - 2017-01-24 16:02:32 --> Security Class Initialized
DEBUG - 2017-01-24 16:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:02:32 --> Input Class Initialized
INFO - 2017-01-24 16:02:32 --> Language Class Initialized
ERROR - 2017-01-24 16:02:32 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:02:45 --> Config Class Initialized
INFO - 2017-01-24 16:02:45 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:02:45 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:02:45 --> Utf8 Class Initialized
INFO - 2017-01-24 16:02:45 --> URI Class Initialized
INFO - 2017-01-24 16:02:45 --> Router Class Initialized
INFO - 2017-01-24 16:02:45 --> Output Class Initialized
INFO - 2017-01-24 16:02:45 --> Security Class Initialized
DEBUG - 2017-01-24 16:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:02:45 --> Input Class Initialized
INFO - 2017-01-24 16:02:45 --> Language Class Initialized
INFO - 2017-01-24 16:02:45 --> Loader Class Initialized
INFO - 2017-01-24 16:02:45 --> Database Driver Class Initialized
INFO - 2017-01-24 16:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:02:45 --> Controller Class Initialized
INFO - 2017-01-24 16:02:45 --> Helper loaded: date_helper
INFO - 2017-01-24 16:02:45 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:02:45 --> Helper loaded: form_helper
INFO - 2017-01-24 16:02:45 --> Form Validation Class Initialized
INFO - 2017-01-24 16:02:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:02:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:02:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:02:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:02:45 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:02:45 --> Final output sent to browser
DEBUG - 2017-01-24 16:02:45 --> Total execution time: 0.0559
INFO - 2017-01-24 16:02:46 --> Config Class Initialized
INFO - 2017-01-24 16:02:46 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:02:46 --> Utf8 Class Initialized
INFO - 2017-01-24 16:02:46 --> URI Class Initialized
INFO - 2017-01-24 16:02:46 --> Router Class Initialized
INFO - 2017-01-24 16:02:46 --> Output Class Initialized
INFO - 2017-01-24 16:02:46 --> Security Class Initialized
DEBUG - 2017-01-24 16:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:02:46 --> Input Class Initialized
INFO - 2017-01-24 16:02:46 --> Language Class Initialized
ERROR - 2017-01-24 16:02:46 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:02:46 --> Config Class Initialized
INFO - 2017-01-24 16:02:46 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:02:46 --> Utf8 Class Initialized
INFO - 2017-01-24 16:02:46 --> URI Class Initialized
INFO - 2017-01-24 16:02:46 --> Router Class Initialized
INFO - 2017-01-24 16:02:46 --> Output Class Initialized
INFO - 2017-01-24 16:02:46 --> Security Class Initialized
DEBUG - 2017-01-24 16:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:02:46 --> Input Class Initialized
INFO - 2017-01-24 16:02:46 --> Language Class Initialized
INFO - 2017-01-24 16:02:46 --> Loader Class Initialized
INFO - 2017-01-24 16:02:46 --> Database Driver Class Initialized
INFO - 2017-01-24 16:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:02:46 --> Controller Class Initialized
INFO - 2017-01-24 16:02:46 --> Helper loaded: date_helper
INFO - 2017-01-24 16:02:46 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:02:46 --> Helper loaded: form_helper
INFO - 2017-01-24 16:02:46 --> Form Validation Class Initialized
INFO - 2017-01-24 16:02:46 --> Config Class Initialized
INFO - 2017-01-24 16:02:46 --> Hooks Class Initialized
INFO - 2017-01-24 16:02:46 --> Final output sent to browser
DEBUG - 2017-01-24 16:02:46 --> Total execution time: 0.0687
DEBUG - 2017-01-24 16:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:02:46 --> Utf8 Class Initialized
INFO - 2017-01-24 16:02:46 --> URI Class Initialized
INFO - 2017-01-24 16:02:46 --> Router Class Initialized
INFO - 2017-01-24 16:02:46 --> Output Class Initialized
INFO - 2017-01-24 16:02:46 --> Security Class Initialized
DEBUG - 2017-01-24 16:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:02:46 --> Input Class Initialized
INFO - 2017-01-24 16:02:46 --> Language Class Initialized
INFO - 2017-01-24 16:02:46 --> Loader Class Initialized
INFO - 2017-01-24 16:02:46 --> Database Driver Class Initialized
INFO - 2017-01-24 16:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:02:46 --> Controller Class Initialized
INFO - 2017-01-24 16:02:46 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:02:46 --> Final output sent to browser
DEBUG - 2017-01-24 16:02:46 --> Total execution time: 0.0727
INFO - 2017-01-24 16:03:08 --> Config Class Initialized
INFO - 2017-01-24 16:03:08 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:08 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:08 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:08 --> URI Class Initialized
INFO - 2017-01-24 16:03:08 --> Router Class Initialized
INFO - 2017-01-24 16:03:08 --> Output Class Initialized
INFO - 2017-01-24 16:03:08 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:08 --> Input Class Initialized
INFO - 2017-01-24 16:03:08 --> Language Class Initialized
INFO - 2017-01-24 16:03:08 --> Loader Class Initialized
INFO - 2017-01-24 16:03:08 --> Database Driver Class Initialized
INFO - 2017-01-24 16:03:08 --> Config Class Initialized
INFO - 2017-01-24 16:03:08 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:08 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:08 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:08 --> URI Class Initialized
INFO - 2017-01-24 16:03:08 --> Router Class Initialized
INFO - 2017-01-24 16:03:08 --> Output Class Initialized
INFO - 2017-01-24 16:03:08 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:08 --> Input Class Initialized
INFO - 2017-01-24 16:03:08 --> Language Class Initialized
INFO - 2017-01-24 16:03:08 --> Loader Class Initialized
INFO - 2017-01-24 16:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:03:08 --> Controller Class Initialized
INFO - 2017-01-24 16:03:08 --> Helper loaded: date_helper
INFO - 2017-01-24 16:03:08 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:03:08 --> Helper loaded: form_helper
INFO - 2017-01-24 16:03:08 --> Form Validation Class Initialized
INFO - 2017-01-24 16:03:08 --> Database Driver Class Initialized
INFO - 2017-01-24 16:03:08 --> Final output sent to browser
DEBUG - 2017-01-24 16:03:08 --> Total execution time: 0.0861
INFO - 2017-01-24 16:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:03:08 --> Controller Class Initialized
INFO - 2017-01-24 16:03:08 --> Helper loaded: date_helper
INFO - 2017-01-24 16:03:08 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:03:08 --> Helper loaded: form_helper
INFO - 2017-01-24 16:03:08 --> Form Validation Class Initialized
INFO - 2017-01-24 16:03:08 --> Final output sent to browser
DEBUG - 2017-01-24 16:03:08 --> Total execution time: 0.0840
INFO - 2017-01-24 16:03:53 --> Config Class Initialized
INFO - 2017-01-24 16:03:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:53 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:53 --> URI Class Initialized
INFO - 2017-01-24 16:03:53 --> Router Class Initialized
INFO - 2017-01-24 16:03:53 --> Output Class Initialized
INFO - 2017-01-24 16:03:53 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:53 --> Input Class Initialized
INFO - 2017-01-24 16:03:53 --> Language Class Initialized
INFO - 2017-01-24 16:03:53 --> Loader Class Initialized
INFO - 2017-01-24 16:03:53 --> Database Driver Class Initialized
INFO - 2017-01-24 16:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:03:53 --> Controller Class Initialized
INFO - 2017-01-24 16:03:53 --> Helper loaded: date_helper
INFO - 2017-01-24 16:03:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:03:53 --> Helper loaded: form_helper
INFO - 2017-01-24 16:03:53 --> Form Validation Class Initialized
INFO - 2017-01-24 16:03:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:03:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:03:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:03:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:03:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:03:53 --> Final output sent to browser
DEBUG - 2017-01-24 16:03:53 --> Total execution time: 0.0349
INFO - 2017-01-24 16:03:53 --> Config Class Initialized
INFO - 2017-01-24 16:03:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:53 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:53 --> URI Class Initialized
INFO - 2017-01-24 16:03:53 --> Router Class Initialized
INFO - 2017-01-24 16:03:53 --> Output Class Initialized
INFO - 2017-01-24 16:03:53 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:53 --> Input Class Initialized
INFO - 2017-01-24 16:03:53 --> Language Class Initialized
ERROR - 2017-01-24 16:03:53 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:03:53 --> Config Class Initialized
INFO - 2017-01-24 16:03:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:53 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:53 --> URI Class Initialized
INFO - 2017-01-24 16:03:53 --> Router Class Initialized
INFO - 2017-01-24 16:03:53 --> Output Class Initialized
INFO - 2017-01-24 16:03:53 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:53 --> Input Class Initialized
INFO - 2017-01-24 16:03:53 --> Language Class Initialized
INFO - 2017-01-24 16:03:53 --> Loader Class Initialized
INFO - 2017-01-24 16:03:53 --> Database Driver Class Initialized
INFO - 2017-01-24 16:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:03:53 --> Controller Class Initialized
INFO - 2017-01-24 16:03:53 --> Helper loaded: date_helper
INFO - 2017-01-24 16:03:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:03:53 --> Helper loaded: form_helper
INFO - 2017-01-24 16:03:53 --> Form Validation Class Initialized
INFO - 2017-01-24 16:03:53 --> Final output sent to browser
DEBUG - 2017-01-24 16:03:53 --> Total execution time: 0.1084
INFO - 2017-01-24 16:03:54 --> Config Class Initialized
INFO - 2017-01-24 16:03:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:54 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:54 --> URI Class Initialized
INFO - 2017-01-24 16:03:54 --> Router Class Initialized
INFO - 2017-01-24 16:03:54 --> Output Class Initialized
INFO - 2017-01-24 16:03:54 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:54 --> Input Class Initialized
INFO - 2017-01-24 16:03:54 --> Language Class Initialized
INFO - 2017-01-24 16:03:54 --> Loader Class Initialized
INFO - 2017-01-24 16:03:54 --> Database Driver Class Initialized
INFO - 2017-01-24 16:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:03:54 --> Controller Class Initialized
INFO - 2017-01-24 16:03:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:03:54 --> Final output sent to browser
DEBUG - 2017-01-24 16:03:54 --> Total execution time: 0.0593
INFO - 2017-01-24 16:03:54 --> Config Class Initialized
INFO - 2017-01-24 16:03:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:54 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:54 --> URI Class Initialized
INFO - 2017-01-24 16:03:54 --> Config Class Initialized
INFO - 2017-01-24 16:03:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:03:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:03:54 --> Utf8 Class Initialized
INFO - 2017-01-24 16:03:54 --> URI Class Initialized
INFO - 2017-01-24 16:03:54 --> Router Class Initialized
INFO - 2017-01-24 16:03:54 --> Output Class Initialized
INFO - 2017-01-24 16:03:54 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:54 --> Input Class Initialized
INFO - 2017-01-24 16:03:54 --> Language Class Initialized
INFO - 2017-01-24 16:03:54 --> Loader Class Initialized
INFO - 2017-01-24 16:03:55 --> Database Driver Class Initialized
INFO - 2017-01-24 16:03:55 --> Router Class Initialized
INFO - 2017-01-24 16:03:55 --> Output Class Initialized
INFO - 2017-01-24 16:03:55 --> Security Class Initialized
DEBUG - 2017-01-24 16:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:03:55 --> Input Class Initialized
INFO - 2017-01-24 16:03:55 --> Language Class Initialized
INFO - 2017-01-24 16:03:55 --> Loader Class Initialized
INFO - 2017-01-24 16:03:55 --> Database Driver Class Initialized
INFO - 2017-01-24 16:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:03:55 --> Controller Class Initialized
INFO - 2017-01-24 16:03:55 --> Helper loaded: date_helper
INFO - 2017-01-24 16:03:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:03:55 --> Helper loaded: form_helper
INFO - 2017-01-24 16:03:55 --> Form Validation Class Initialized
INFO - 2017-01-24 16:03:55 --> Final output sent to browser
DEBUG - 2017-01-24 16:03:55 --> Total execution time: 0.0925
INFO - 2017-01-24 16:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:03:55 --> Controller Class Initialized
INFO - 2017-01-24 16:03:55 --> Helper loaded: date_helper
INFO - 2017-01-24 16:03:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:03:55 --> Helper loaded: form_helper
INFO - 2017-01-24 16:03:55 --> Form Validation Class Initialized
INFO - 2017-01-24 16:03:55 --> Final output sent to browser
DEBUG - 2017-01-24 16:03:55 --> Total execution time: 0.0938
INFO - 2017-01-24 16:07:32 --> Config Class Initialized
INFO - 2017-01-24 16:07:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:07:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:07:32 --> Utf8 Class Initialized
INFO - 2017-01-24 16:07:32 --> URI Class Initialized
INFO - 2017-01-24 16:07:32 --> Router Class Initialized
INFO - 2017-01-24 16:07:32 --> Output Class Initialized
INFO - 2017-01-24 16:07:32 --> Security Class Initialized
DEBUG - 2017-01-24 16:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:07:32 --> Input Class Initialized
INFO - 2017-01-24 16:07:32 --> Language Class Initialized
INFO - 2017-01-24 16:07:32 --> Loader Class Initialized
INFO - 2017-01-24 16:07:32 --> Database Driver Class Initialized
INFO - 2017-01-24 16:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:07:32 --> Controller Class Initialized
INFO - 2017-01-24 16:07:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:07:32 --> Helper loaded: form_helper
INFO - 2017-01-24 16:07:32 --> Form Validation Class Initialized
INFO - 2017-01-24 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-24 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:07:32 --> Final output sent to browser
DEBUG - 2017-01-24 16:07:32 --> Total execution time: 0.0717
INFO - 2017-01-24 16:07:32 --> Config Class Initialized
INFO - 2017-01-24 16:07:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:07:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:07:32 --> Utf8 Class Initialized
INFO - 2017-01-24 16:07:32 --> URI Class Initialized
INFO - 2017-01-24 16:07:32 --> Router Class Initialized
INFO - 2017-01-24 16:07:32 --> Output Class Initialized
INFO - 2017-01-24 16:07:32 --> Security Class Initialized
DEBUG - 2017-01-24 16:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:07:32 --> Input Class Initialized
INFO - 2017-01-24 16:07:32 --> Language Class Initialized
INFO - 2017-01-24 16:07:32 --> Loader Class Initialized
INFO - 2017-01-24 16:07:32 --> Database Driver Class Initialized
INFO - 2017-01-24 16:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:07:32 --> Controller Class Initialized
INFO - 2017-01-24 16:07:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:07:32 --> Final output sent to browser
DEBUG - 2017-01-24 16:07:32 --> Total execution time: 0.0209
INFO - 2017-01-24 16:08:52 --> Config Class Initialized
INFO - 2017-01-24 16:08:52 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:08:52 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:08:52 --> Utf8 Class Initialized
INFO - 2017-01-24 16:08:52 --> URI Class Initialized
INFO - 2017-01-24 16:08:52 --> Router Class Initialized
INFO - 2017-01-24 16:08:52 --> Output Class Initialized
INFO - 2017-01-24 16:08:52 --> Security Class Initialized
DEBUG - 2017-01-24 16:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:08:52 --> Input Class Initialized
INFO - 2017-01-24 16:08:52 --> Language Class Initialized
INFO - 2017-01-24 16:08:52 --> Loader Class Initialized
INFO - 2017-01-24 16:08:52 --> Database Driver Class Initialized
INFO - 2017-01-24 16:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:08:52 --> Controller Class Initialized
INFO - 2017-01-24 16:08:52 --> Helper loaded: date_helper
INFO - 2017-01-24 16:08:52 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:08:52 --> Helper loaded: form_helper
INFO - 2017-01-24 16:08:52 --> Form Validation Class Initialized
INFO - 2017-01-24 16:08:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:08:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:08:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:08:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:08:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:08:52 --> Final output sent to browser
DEBUG - 2017-01-24 16:08:52 --> Total execution time: 0.0172
INFO - 2017-01-24 16:08:53 --> Config Class Initialized
INFO - 2017-01-24 16:08:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:08:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:08:53 --> Utf8 Class Initialized
INFO - 2017-01-24 16:08:53 --> URI Class Initialized
INFO - 2017-01-24 16:08:53 --> Router Class Initialized
INFO - 2017-01-24 16:08:53 --> Output Class Initialized
INFO - 2017-01-24 16:08:53 --> Security Class Initialized
DEBUG - 2017-01-24 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:08:53 --> Input Class Initialized
INFO - 2017-01-24 16:08:53 --> Language Class Initialized
ERROR - 2017-01-24 16:08:53 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:08:53 --> Config Class Initialized
INFO - 2017-01-24 16:08:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:08:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:08:53 --> Utf8 Class Initialized
INFO - 2017-01-24 16:08:53 --> URI Class Initialized
INFO - 2017-01-24 16:08:53 --> Router Class Initialized
INFO - 2017-01-24 16:08:53 --> Output Class Initialized
INFO - 2017-01-24 16:08:53 --> Security Class Initialized
DEBUG - 2017-01-24 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:08:53 --> Input Class Initialized
INFO - 2017-01-24 16:08:53 --> Language Class Initialized
INFO - 2017-01-24 16:08:53 --> Loader Class Initialized
INFO - 2017-01-24 16:08:53 --> Database Driver Class Initialized
INFO - 2017-01-24 16:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:08:53 --> Controller Class Initialized
INFO - 2017-01-24 16:08:53 --> Helper loaded: date_helper
INFO - 2017-01-24 16:08:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:08:53 --> Helper loaded: form_helper
INFO - 2017-01-24 16:08:53 --> Form Validation Class Initialized
INFO - 2017-01-24 16:08:53 --> Final output sent to browser
DEBUG - 2017-01-24 16:08:53 --> Total execution time: 0.0181
INFO - 2017-01-24 16:08:53 --> Config Class Initialized
INFO - 2017-01-24 16:08:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:08:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:08:53 --> Utf8 Class Initialized
INFO - 2017-01-24 16:08:53 --> URI Class Initialized
INFO - 2017-01-24 16:08:53 --> Router Class Initialized
INFO - 2017-01-24 16:08:53 --> Output Class Initialized
INFO - 2017-01-24 16:08:53 --> Security Class Initialized
DEBUG - 2017-01-24 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:08:53 --> Input Class Initialized
INFO - 2017-01-24 16:08:53 --> Language Class Initialized
INFO - 2017-01-24 16:08:53 --> Loader Class Initialized
INFO - 2017-01-24 16:08:53 --> Database Driver Class Initialized
INFO - 2017-01-24 16:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:08:53 --> Controller Class Initialized
INFO - 2017-01-24 16:08:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:08:53 --> Final output sent to browser
DEBUG - 2017-01-24 16:08:53 --> Total execution time: 0.0153
INFO - 2017-01-24 16:08:55 --> Config Class Initialized
INFO - 2017-01-24 16:08:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:08:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:08:55 --> Utf8 Class Initialized
INFO - 2017-01-24 16:08:55 --> URI Class Initialized
INFO - 2017-01-24 16:08:55 --> Config Class Initialized
INFO - 2017-01-24 16:08:55 --> Hooks Class Initialized
INFO - 2017-01-24 16:08:55 --> Router Class Initialized
INFO - 2017-01-24 16:08:55 --> Output Class Initialized
INFO - 2017-01-24 16:08:55 --> Security Class Initialized
DEBUG - 2017-01-24 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:08:55 --> Input Class Initialized
INFO - 2017-01-24 16:08:55 --> Language Class Initialized
INFO - 2017-01-24 16:08:55 --> Loader Class Initialized
INFO - 2017-01-24 16:08:55 --> Database Driver Class Initialized
DEBUG - 2017-01-24 16:08:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:08:55 --> Utf8 Class Initialized
INFO - 2017-01-24 16:08:55 --> URI Class Initialized
INFO - 2017-01-24 16:08:55 --> Router Class Initialized
INFO - 2017-01-24 16:08:55 --> Output Class Initialized
INFO - 2017-01-24 16:08:55 --> Security Class Initialized
DEBUG - 2017-01-24 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:08:55 --> Input Class Initialized
INFO - 2017-01-24 16:08:55 --> Language Class Initialized
INFO - 2017-01-24 16:08:55 --> Loader Class Initialized
INFO - 2017-01-24 16:08:55 --> Database Driver Class Initialized
INFO - 2017-01-24 16:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:08:55 --> Controller Class Initialized
INFO - 2017-01-24 16:08:55 --> Helper loaded: date_helper
INFO - 2017-01-24 16:08:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:08:55 --> Helper loaded: form_helper
INFO - 2017-01-24 16:08:55 --> Form Validation Class Initialized
INFO - 2017-01-24 16:08:55 --> Final output sent to browser
DEBUG - 2017-01-24 16:08:55 --> Total execution time: 0.0286
INFO - 2017-01-24 16:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:08:55 --> Controller Class Initialized
INFO - 2017-01-24 16:08:55 --> Helper loaded: date_helper
INFO - 2017-01-24 16:08:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:08:55 --> Helper loaded: form_helper
INFO - 2017-01-24 16:08:55 --> Form Validation Class Initialized
INFO - 2017-01-24 16:08:55 --> Final output sent to browser
DEBUG - 2017-01-24 16:08:55 --> Total execution time: 0.0955
INFO - 2017-01-24 16:14:15 --> Config Class Initialized
INFO - 2017-01-24 16:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:14:15 --> Utf8 Class Initialized
INFO - 2017-01-24 16:14:15 --> URI Class Initialized
INFO - 2017-01-24 16:14:15 --> Router Class Initialized
INFO - 2017-01-24 16:14:15 --> Output Class Initialized
INFO - 2017-01-24 16:14:15 --> Security Class Initialized
DEBUG - 2017-01-24 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:14:15 --> Input Class Initialized
INFO - 2017-01-24 16:14:15 --> Language Class Initialized
INFO - 2017-01-24 16:14:15 --> Loader Class Initialized
INFO - 2017-01-24 16:14:15 --> Database Driver Class Initialized
INFO - 2017-01-24 16:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:14:15 --> Controller Class Initialized
INFO - 2017-01-24 16:14:15 --> Helper loaded: date_helper
INFO - 2017-01-24 16:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:14:15 --> Helper loaded: form_helper
INFO - 2017-01-24 16:14:15 --> Form Validation Class Initialized
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:14:15 --> Final output sent to browser
DEBUG - 2017-01-24 16:14:15 --> Total execution time: 0.0455
INFO - 2017-01-24 16:14:15 --> Config Class Initialized
INFO - 2017-01-24 16:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:14:15 --> Utf8 Class Initialized
INFO - 2017-01-24 16:14:15 --> URI Class Initialized
INFO - 2017-01-24 16:14:15 --> Router Class Initialized
INFO - 2017-01-24 16:14:15 --> Output Class Initialized
INFO - 2017-01-24 16:14:15 --> Security Class Initialized
DEBUG - 2017-01-24 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:14:15 --> Input Class Initialized
INFO - 2017-01-24 16:14:15 --> Language Class Initialized
ERROR - 2017-01-24 16:14:15 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:14:15 --> Config Class Initialized
INFO - 2017-01-24 16:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:14:15 --> Utf8 Class Initialized
INFO - 2017-01-24 16:14:15 --> URI Class Initialized
INFO - 2017-01-24 16:14:15 --> Router Class Initialized
INFO - 2017-01-24 16:14:15 --> Output Class Initialized
INFO - 2017-01-24 16:14:15 --> Security Class Initialized
DEBUG - 2017-01-24 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:14:15 --> Input Class Initialized
INFO - 2017-01-24 16:14:15 --> Language Class Initialized
INFO - 2017-01-24 16:14:15 --> Loader Class Initialized
INFO - 2017-01-24 16:14:15 --> Database Driver Class Initialized
INFO - 2017-01-24 16:14:15 --> Config Class Initialized
INFO - 2017-01-24 16:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:14:15 --> Utf8 Class Initialized
INFO - 2017-01-24 16:14:15 --> URI Class Initialized
INFO - 2017-01-24 16:14:15 --> Router Class Initialized
INFO - 2017-01-24 16:14:15 --> Output Class Initialized
INFO - 2017-01-24 16:14:15 --> Security Class Initialized
DEBUG - 2017-01-24 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:14:15 --> Input Class Initialized
INFO - 2017-01-24 16:14:15 --> Language Class Initialized
INFO - 2017-01-24 16:14:15 --> Loader Class Initialized
INFO - 2017-01-24 16:14:15 --> Database Driver Class Initialized
INFO - 2017-01-24 16:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:14:15 --> Controller Class Initialized
INFO - 2017-01-24 16:14:15 --> Helper loaded: date_helper
INFO - 2017-01-24 16:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:14:15 --> Helper loaded: form_helper
INFO - 2017-01-24 16:14:15 --> Form Validation Class Initialized
INFO - 2017-01-24 16:14:15 --> Final output sent to browser
DEBUG - 2017-01-24 16:14:15 --> Total execution time: 0.0306
INFO - 2017-01-24 16:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:14:15 --> Controller Class Initialized
INFO - 2017-01-24 16:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:14:15 --> Final output sent to browser
DEBUG - 2017-01-24 16:14:15 --> Total execution time: 0.0250
INFO - 2017-01-24 16:14:17 --> Config Class Initialized
INFO - 2017-01-24 16:14:17 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:14:17 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:14:17 --> Utf8 Class Initialized
INFO - 2017-01-24 16:14:17 --> URI Class Initialized
INFO - 2017-01-24 16:14:17 --> Config Class Initialized
INFO - 2017-01-24 16:14:17 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:14:17 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:14:17 --> Utf8 Class Initialized
INFO - 2017-01-24 16:14:17 --> URI Class Initialized
INFO - 2017-01-24 16:14:17 --> Router Class Initialized
INFO - 2017-01-24 16:14:17 --> Output Class Initialized
INFO - 2017-01-24 16:14:17 --> Security Class Initialized
DEBUG - 2017-01-24 16:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:14:17 --> Input Class Initialized
INFO - 2017-01-24 16:14:17 --> Language Class Initialized
INFO - 2017-01-24 16:14:17 --> Router Class Initialized
INFO - 2017-01-24 16:14:17 --> Output Class Initialized
INFO - 2017-01-24 16:14:17 --> Security Class Initialized
DEBUG - 2017-01-24 16:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:14:17 --> Input Class Initialized
INFO - 2017-01-24 16:14:17 --> Language Class Initialized
INFO - 2017-01-24 16:14:17 --> Loader Class Initialized
INFO - 2017-01-24 16:14:17 --> Database Driver Class Initialized
INFO - 2017-01-24 16:14:17 --> Loader Class Initialized
INFO - 2017-01-24 16:14:17 --> Database Driver Class Initialized
INFO - 2017-01-24 16:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:14:17 --> Controller Class Initialized
INFO - 2017-01-24 16:14:17 --> Helper loaded: date_helper
INFO - 2017-01-24 16:14:17 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:14:17 --> Helper loaded: form_helper
INFO - 2017-01-24 16:14:17 --> Form Validation Class Initialized
INFO - 2017-01-24 16:14:17 --> Final output sent to browser
DEBUG - 2017-01-24 16:14:17 --> Total execution time: 0.0938
INFO - 2017-01-24 16:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:14:17 --> Controller Class Initialized
INFO - 2017-01-24 16:14:17 --> Helper loaded: date_helper
INFO - 2017-01-24 16:14:17 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:14:17 --> Helper loaded: form_helper
INFO - 2017-01-24 16:14:17 --> Form Validation Class Initialized
INFO - 2017-01-24 16:14:17 --> Final output sent to browser
DEBUG - 2017-01-24 16:14:17 --> Total execution time: 0.1010
INFO - 2017-01-24 16:15:50 --> Config Class Initialized
INFO - 2017-01-24 16:15:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:15:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:15:50 --> Utf8 Class Initialized
INFO - 2017-01-24 16:15:50 --> URI Class Initialized
INFO - 2017-01-24 16:15:50 --> Router Class Initialized
INFO - 2017-01-24 16:15:50 --> Output Class Initialized
INFO - 2017-01-24 16:15:50 --> Security Class Initialized
DEBUG - 2017-01-24 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:15:50 --> Input Class Initialized
INFO - 2017-01-24 16:15:50 --> Language Class Initialized
INFO - 2017-01-24 16:15:50 --> Loader Class Initialized
INFO - 2017-01-24 16:15:50 --> Database Driver Class Initialized
INFO - 2017-01-24 16:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:15:50 --> Controller Class Initialized
INFO - 2017-01-24 16:15:50 --> Helper loaded: date_helper
INFO - 2017-01-24 16:15:50 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:15:50 --> Helper loaded: form_helper
INFO - 2017-01-24 16:15:50 --> Form Validation Class Initialized
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:15:50 --> Final output sent to browser
DEBUG - 2017-01-24 16:15:50 --> Total execution time: 0.0279
INFO - 2017-01-24 16:15:50 --> Config Class Initialized
INFO - 2017-01-24 16:15:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:15:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:15:50 --> Utf8 Class Initialized
INFO - 2017-01-24 16:15:50 --> URI Class Initialized
INFO - 2017-01-24 16:15:50 --> Router Class Initialized
INFO - 2017-01-24 16:15:50 --> Output Class Initialized
INFO - 2017-01-24 16:15:50 --> Security Class Initialized
DEBUG - 2017-01-24 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:15:50 --> Input Class Initialized
INFO - 2017-01-24 16:15:50 --> Language Class Initialized
ERROR - 2017-01-24 16:15:50 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:15:50 --> Config Class Initialized
INFO - 2017-01-24 16:15:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:15:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:15:50 --> Utf8 Class Initialized
INFO - 2017-01-24 16:15:50 --> URI Class Initialized
INFO - 2017-01-24 16:15:50 --> Router Class Initialized
INFO - 2017-01-24 16:15:50 --> Output Class Initialized
INFO - 2017-01-24 16:15:50 --> Security Class Initialized
DEBUG - 2017-01-24 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:15:50 --> Input Class Initialized
INFO - 2017-01-24 16:15:50 --> Language Class Initialized
INFO - 2017-01-24 16:15:50 --> Loader Class Initialized
INFO - 2017-01-24 16:15:50 --> Database Driver Class Initialized
INFO - 2017-01-24 16:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:15:50 --> Controller Class Initialized
INFO - 2017-01-24 16:15:50 --> Helper loaded: date_helper
INFO - 2017-01-24 16:15:50 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:15:50 --> Helper loaded: form_helper
INFO - 2017-01-24 16:15:50 --> Form Validation Class Initialized
INFO - 2017-01-24 16:15:50 --> Final output sent to browser
DEBUG - 2017-01-24 16:15:50 --> Total execution time: 0.0933
INFO - 2017-01-24 16:15:50 --> Config Class Initialized
INFO - 2017-01-24 16:15:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:15:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:15:50 --> Utf8 Class Initialized
INFO - 2017-01-24 16:15:50 --> URI Class Initialized
INFO - 2017-01-24 16:15:50 --> Router Class Initialized
INFO - 2017-01-24 16:15:50 --> Output Class Initialized
INFO - 2017-01-24 16:15:50 --> Security Class Initialized
DEBUG - 2017-01-24 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:15:50 --> Input Class Initialized
INFO - 2017-01-24 16:15:50 --> Language Class Initialized
INFO - 2017-01-24 16:15:50 --> Loader Class Initialized
INFO - 2017-01-24 16:15:50 --> Database Driver Class Initialized
INFO - 2017-01-24 16:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:15:50 --> Controller Class Initialized
INFO - 2017-01-24 16:15:50 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:15:50 --> Final output sent to browser
DEBUG - 2017-01-24 16:15:50 --> Total execution time: 0.0213
INFO - 2017-01-24 16:15:54 --> Config Class Initialized
INFO - 2017-01-24 16:15:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:15:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:15:54 --> Utf8 Class Initialized
INFO - 2017-01-24 16:15:54 --> URI Class Initialized
INFO - 2017-01-24 16:15:54 --> Router Class Initialized
INFO - 2017-01-24 16:15:54 --> Output Class Initialized
INFO - 2017-01-24 16:15:54 --> Security Class Initialized
DEBUG - 2017-01-24 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:15:54 --> Input Class Initialized
INFO - 2017-01-24 16:15:54 --> Language Class Initialized
INFO - 2017-01-24 16:15:54 --> Loader Class Initialized
INFO - 2017-01-24 16:15:54 --> Database Driver Class Initialized
INFO - 2017-01-24 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:15:54 --> Controller Class Initialized
INFO - 2017-01-24 16:15:54 --> Helper loaded: date_helper
INFO - 2017-01-24 16:15:54 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:15:54 --> Helper loaded: form_helper
INFO - 2017-01-24 16:15:54 --> Form Validation Class Initialized
INFO - 2017-01-24 16:15:54 --> Final output sent to browser
DEBUG - 2017-01-24 16:15:54 --> Total execution time: 0.0206
INFO - 2017-01-24 16:15:55 --> Config Class Initialized
INFO - 2017-01-24 16:15:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:15:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:15:55 --> Utf8 Class Initialized
INFO - 2017-01-24 16:15:55 --> URI Class Initialized
INFO - 2017-01-24 16:15:55 --> Router Class Initialized
INFO - 2017-01-24 16:15:55 --> Output Class Initialized
INFO - 2017-01-24 16:15:55 --> Security Class Initialized
DEBUG - 2017-01-24 16:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:15:55 --> Input Class Initialized
INFO - 2017-01-24 16:15:55 --> Language Class Initialized
INFO - 2017-01-24 16:15:55 --> Loader Class Initialized
INFO - 2017-01-24 16:15:55 --> Database Driver Class Initialized
INFO - 2017-01-24 16:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:15:55 --> Controller Class Initialized
INFO - 2017-01-24 16:15:55 --> Helper loaded: date_helper
INFO - 2017-01-24 16:15:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:15:55 --> Helper loaded: form_helper
INFO - 2017-01-24 16:15:55 --> Form Validation Class Initialized
INFO - 2017-01-24 16:15:55 --> Final output sent to browser
DEBUG - 2017-01-24 16:15:55 --> Total execution time: 0.0150
INFO - 2017-01-24 16:17:48 --> Config Class Initialized
INFO - 2017-01-24 16:17:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:17:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:17:48 --> Utf8 Class Initialized
INFO - 2017-01-24 16:17:48 --> URI Class Initialized
INFO - 2017-01-24 16:17:48 --> Router Class Initialized
INFO - 2017-01-24 16:17:48 --> Output Class Initialized
INFO - 2017-01-24 16:17:48 --> Security Class Initialized
DEBUG - 2017-01-24 16:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:17:48 --> Input Class Initialized
INFO - 2017-01-24 16:17:48 --> Language Class Initialized
INFO - 2017-01-24 16:17:48 --> Loader Class Initialized
INFO - 2017-01-24 16:17:48 --> Database Driver Class Initialized
INFO - 2017-01-24 16:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:17:48 --> Controller Class Initialized
INFO - 2017-01-24 16:17:48 --> Helper loaded: date_helper
INFO - 2017-01-24 16:17:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:17:48 --> Helper loaded: form_helper
INFO - 2017-01-24 16:17:48 --> Form Validation Class Initialized
INFO - 2017-01-24 16:17:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:17:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:17:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:17:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:17:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:17:48 --> Final output sent to browser
DEBUG - 2017-01-24 16:17:48 --> Total execution time: 0.0281
INFO - 2017-01-24 16:17:48 --> Config Class Initialized
INFO - 2017-01-24 16:17:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:17:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:17:48 --> Utf8 Class Initialized
INFO - 2017-01-24 16:17:48 --> URI Class Initialized
INFO - 2017-01-24 16:17:48 --> Router Class Initialized
INFO - 2017-01-24 16:17:48 --> Output Class Initialized
INFO - 2017-01-24 16:17:48 --> Security Class Initialized
DEBUG - 2017-01-24 16:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:17:48 --> Input Class Initialized
INFO - 2017-01-24 16:17:48 --> Language Class Initialized
ERROR - 2017-01-24 16:17:48 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:17:48 --> Config Class Initialized
INFO - 2017-01-24 16:17:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:17:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:17:48 --> Utf8 Class Initialized
INFO - 2017-01-24 16:17:48 --> URI Class Initialized
INFO - 2017-01-24 16:17:48 --> Router Class Initialized
INFO - 2017-01-24 16:17:48 --> Output Class Initialized
INFO - 2017-01-24 16:17:48 --> Security Class Initialized
DEBUG - 2017-01-24 16:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:17:48 --> Input Class Initialized
INFO - 2017-01-24 16:17:48 --> Language Class Initialized
INFO - 2017-01-24 16:17:48 --> Loader Class Initialized
INFO - 2017-01-24 16:17:48 --> Database Driver Class Initialized
INFO - 2017-01-24 16:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:17:48 --> Controller Class Initialized
INFO - 2017-01-24 16:17:48 --> Helper loaded: date_helper
INFO - 2017-01-24 16:17:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:17:48 --> Helper loaded: form_helper
INFO - 2017-01-24 16:17:48 --> Form Validation Class Initialized
INFO - 2017-01-24 16:17:48 --> Final output sent to browser
DEBUG - 2017-01-24 16:17:48 --> Total execution time: 0.0345
INFO - 2017-01-24 16:17:49 --> Config Class Initialized
INFO - 2017-01-24 16:17:49 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:17:49 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:17:49 --> Utf8 Class Initialized
INFO - 2017-01-24 16:17:49 --> URI Class Initialized
INFO - 2017-01-24 16:17:49 --> Router Class Initialized
INFO - 2017-01-24 16:17:49 --> Output Class Initialized
INFO - 2017-01-24 16:17:49 --> Security Class Initialized
DEBUG - 2017-01-24 16:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:17:49 --> Input Class Initialized
INFO - 2017-01-24 16:17:49 --> Language Class Initialized
INFO - 2017-01-24 16:17:49 --> Loader Class Initialized
INFO - 2017-01-24 16:17:49 --> Database Driver Class Initialized
INFO - 2017-01-24 16:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:17:49 --> Controller Class Initialized
INFO - 2017-01-24 16:17:49 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:17:49 --> Final output sent to browser
DEBUG - 2017-01-24 16:17:49 --> Total execution time: 0.0717
INFO - 2017-01-24 16:17:51 --> Config Class Initialized
INFO - 2017-01-24 16:17:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:17:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:17:51 --> Utf8 Class Initialized
INFO - 2017-01-24 16:17:51 --> URI Class Initialized
INFO - 2017-01-24 16:17:51 --> Router Class Initialized
INFO - 2017-01-24 16:17:51 --> Output Class Initialized
INFO - 2017-01-24 16:17:51 --> Security Class Initialized
DEBUG - 2017-01-24 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:17:51 --> Input Class Initialized
INFO - 2017-01-24 16:17:51 --> Language Class Initialized
INFO - 2017-01-24 16:17:51 --> Loader Class Initialized
INFO - 2017-01-24 16:17:51 --> Database Driver Class Initialized
INFO - 2017-01-24 16:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:17:51 --> Controller Class Initialized
INFO - 2017-01-24 16:17:51 --> Helper loaded: date_helper
INFO - 2017-01-24 16:17:51 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:17:51 --> Helper loaded: form_helper
INFO - 2017-01-24 16:17:51 --> Form Validation Class Initialized
INFO - 2017-01-24 16:17:51 --> Final output sent to browser
DEBUG - 2017-01-24 16:17:51 --> Total execution time: 0.0160
INFO - 2017-01-24 16:17:51 --> Config Class Initialized
INFO - 2017-01-24 16:17:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:17:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:17:51 --> Utf8 Class Initialized
INFO - 2017-01-24 16:17:51 --> URI Class Initialized
INFO - 2017-01-24 16:17:51 --> Router Class Initialized
INFO - 2017-01-24 16:17:51 --> Output Class Initialized
INFO - 2017-01-24 16:17:51 --> Security Class Initialized
DEBUG - 2017-01-24 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:17:51 --> Input Class Initialized
INFO - 2017-01-24 16:17:51 --> Language Class Initialized
INFO - 2017-01-24 16:17:51 --> Loader Class Initialized
INFO - 2017-01-24 16:17:51 --> Database Driver Class Initialized
INFO - 2017-01-24 16:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:17:51 --> Controller Class Initialized
INFO - 2017-01-24 16:17:51 --> Helper loaded: date_helper
INFO - 2017-01-24 16:17:51 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:17:51 --> Helper loaded: form_helper
INFO - 2017-01-24 16:17:51 --> Form Validation Class Initialized
INFO - 2017-01-24 16:17:51 --> Final output sent to browser
DEBUG - 2017-01-24 16:17:51 --> Total execution time: 0.0150
INFO - 2017-01-24 16:19:02 --> Config Class Initialized
INFO - 2017-01-24 16:19:02 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:19:02 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:19:02 --> Utf8 Class Initialized
INFO - 2017-01-24 16:19:02 --> URI Class Initialized
INFO - 2017-01-24 16:19:02 --> Router Class Initialized
INFO - 2017-01-24 16:19:02 --> Output Class Initialized
INFO - 2017-01-24 16:19:02 --> Security Class Initialized
DEBUG - 2017-01-24 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:19:02 --> Input Class Initialized
INFO - 2017-01-24 16:19:02 --> Language Class Initialized
INFO - 2017-01-24 16:19:02 --> Loader Class Initialized
INFO - 2017-01-24 16:19:02 --> Database Driver Class Initialized
INFO - 2017-01-24 16:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:19:02 --> Controller Class Initialized
INFO - 2017-01-24 16:19:02 --> Helper loaded: date_helper
INFO - 2017-01-24 16:19:02 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:19:02 --> Helper loaded: form_helper
INFO - 2017-01-24 16:19:02 --> Form Validation Class Initialized
INFO - 2017-01-24 16:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:19:02 --> Final output sent to browser
DEBUG - 2017-01-24 16:19:02 --> Total execution time: 0.0393
INFO - 2017-01-24 16:19:02 --> Config Class Initialized
INFO - 2017-01-24 16:19:02 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:19:02 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:19:02 --> Utf8 Class Initialized
INFO - 2017-01-24 16:19:02 --> URI Class Initialized
INFO - 2017-01-24 16:19:02 --> Router Class Initialized
INFO - 2017-01-24 16:19:02 --> Output Class Initialized
INFO - 2017-01-24 16:19:02 --> Security Class Initialized
DEBUG - 2017-01-24 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:19:02 --> Input Class Initialized
INFO - 2017-01-24 16:19:02 --> Language Class Initialized
ERROR - 2017-01-24 16:19:02 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:19:02 --> Config Class Initialized
INFO - 2017-01-24 16:19:02 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:19:02 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:19:02 --> Utf8 Class Initialized
INFO - 2017-01-24 16:19:02 --> URI Class Initialized
INFO - 2017-01-24 16:19:02 --> Router Class Initialized
INFO - 2017-01-24 16:19:02 --> Output Class Initialized
INFO - 2017-01-24 16:19:02 --> Security Class Initialized
DEBUG - 2017-01-24 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:19:02 --> Input Class Initialized
INFO - 2017-01-24 16:19:02 --> Language Class Initialized
INFO - 2017-01-24 16:19:02 --> Loader Class Initialized
INFO - 2017-01-24 16:19:02 --> Database Driver Class Initialized
INFO - 2017-01-24 16:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:19:02 --> Controller Class Initialized
INFO - 2017-01-24 16:19:02 --> Helper loaded: date_helper
INFO - 2017-01-24 16:19:02 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:19:02 --> Helper loaded: form_helper
INFO - 2017-01-24 16:19:02 --> Form Validation Class Initialized
INFO - 2017-01-24 16:19:02 --> Config Class Initialized
INFO - 2017-01-24 16:19:02 --> Hooks Class Initialized
INFO - 2017-01-24 16:19:02 --> Final output sent to browser
DEBUG - 2017-01-24 16:19:02 --> Total execution time: 0.0354
DEBUG - 2017-01-24 16:19:03 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:19:03 --> Utf8 Class Initialized
INFO - 2017-01-24 16:19:03 --> URI Class Initialized
INFO - 2017-01-24 16:19:03 --> Router Class Initialized
INFO - 2017-01-24 16:19:03 --> Output Class Initialized
INFO - 2017-01-24 16:19:03 --> Security Class Initialized
DEBUG - 2017-01-24 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:19:03 --> Input Class Initialized
INFO - 2017-01-24 16:19:03 --> Language Class Initialized
INFO - 2017-01-24 16:19:03 --> Loader Class Initialized
INFO - 2017-01-24 16:19:03 --> Database Driver Class Initialized
INFO - 2017-01-24 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:19:03 --> Controller Class Initialized
INFO - 2017-01-24 16:19:03 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:19:03 --> Final output sent to browser
DEBUG - 2017-01-24 16:19:03 --> Total execution time: 0.0954
INFO - 2017-01-24 16:19:04 --> Config Class Initialized
INFO - 2017-01-24 16:19:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:19:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:19:04 --> Utf8 Class Initialized
INFO - 2017-01-24 16:19:04 --> URI Class Initialized
INFO - 2017-01-24 16:19:04 --> Router Class Initialized
INFO - 2017-01-24 16:19:04 --> Output Class Initialized
INFO - 2017-01-24 16:19:04 --> Security Class Initialized
DEBUG - 2017-01-24 16:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:19:04 --> Input Class Initialized
INFO - 2017-01-24 16:19:04 --> Language Class Initialized
INFO - 2017-01-24 16:19:04 --> Loader Class Initialized
INFO - 2017-01-24 16:19:04 --> Config Class Initialized
INFO - 2017-01-24 16:19:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:19:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:19:04 --> Utf8 Class Initialized
INFO - 2017-01-24 16:19:04 --> URI Class Initialized
INFO - 2017-01-24 16:19:04 --> Router Class Initialized
INFO - 2017-01-24 16:19:04 --> Output Class Initialized
INFO - 2017-01-24 16:19:04 --> Security Class Initialized
DEBUG - 2017-01-24 16:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:19:04 --> Input Class Initialized
INFO - 2017-01-24 16:19:04 --> Language Class Initialized
INFO - 2017-01-24 16:19:04 --> Loader Class Initialized
INFO - 2017-01-24 16:19:04 --> Database Driver Class Initialized
INFO - 2017-01-24 16:19:04 --> Database Driver Class Initialized
INFO - 2017-01-24 16:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:19:04 --> Controller Class Initialized
INFO - 2017-01-24 16:19:04 --> Helper loaded: date_helper
INFO - 2017-01-24 16:19:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:19:04 --> Helper loaded: form_helper
INFO - 2017-01-24 16:19:04 --> Form Validation Class Initialized
INFO - 2017-01-24 16:19:04 --> Final output sent to browser
DEBUG - 2017-01-24 16:19:04 --> Total execution time: 0.0667
INFO - 2017-01-24 16:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:19:04 --> Controller Class Initialized
INFO - 2017-01-24 16:19:04 --> Helper loaded: date_helper
INFO - 2017-01-24 16:19:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:19:04 --> Helper loaded: form_helper
INFO - 2017-01-24 16:19:04 --> Form Validation Class Initialized
INFO - 2017-01-24 16:19:04 --> Final output sent to browser
DEBUG - 2017-01-24 16:19:04 --> Total execution time: 0.0846
INFO - 2017-01-24 16:22:43 --> Config Class Initialized
INFO - 2017-01-24 16:22:43 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:22:43 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:22:43 --> Utf8 Class Initialized
INFO - 2017-01-24 16:22:43 --> URI Class Initialized
DEBUG - 2017-01-24 16:22:43 --> No URI present. Default controller set.
INFO - 2017-01-24 16:22:43 --> Router Class Initialized
INFO - 2017-01-24 16:22:43 --> Output Class Initialized
INFO - 2017-01-24 16:22:43 --> Security Class Initialized
DEBUG - 2017-01-24 16:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:22:43 --> Input Class Initialized
INFO - 2017-01-24 16:22:43 --> Language Class Initialized
INFO - 2017-01-24 16:22:43 --> Loader Class Initialized
INFO - 2017-01-24 16:22:43 --> Database Driver Class Initialized
INFO - 2017-01-24 16:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:22:43 --> Controller Class Initialized
INFO - 2017-01-24 16:22:43 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:22:43 --> Final output sent to browser
DEBUG - 2017-01-24 16:22:43 --> Total execution time: 0.0133
INFO - 2017-01-24 16:24:58 --> Config Class Initialized
INFO - 2017-01-24 16:24:58 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:24:58 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:24:58 --> Utf8 Class Initialized
INFO - 2017-01-24 16:24:58 --> URI Class Initialized
INFO - 2017-01-24 16:24:58 --> Router Class Initialized
INFO - 2017-01-24 16:24:58 --> Output Class Initialized
INFO - 2017-01-24 16:24:58 --> Security Class Initialized
DEBUG - 2017-01-24 16:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:24:58 --> Input Class Initialized
INFO - 2017-01-24 16:24:58 --> Language Class Initialized
INFO - 2017-01-24 16:24:58 --> Loader Class Initialized
INFO - 2017-01-24 16:24:58 --> Database Driver Class Initialized
INFO - 2017-01-24 16:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:24:58 --> Controller Class Initialized
INFO - 2017-01-24 16:24:58 --> Helper loaded: date_helper
INFO - 2017-01-24 16:24:58 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:24:58 --> Helper loaded: form_helper
INFO - 2017-01-24 16:24:58 --> Form Validation Class Initialized
INFO - 2017-01-24 16:24:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:24:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:24:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:24:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:24:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:24:58 --> Final output sent to browser
DEBUG - 2017-01-24 16:24:58 --> Total execution time: 0.0313
INFO - 2017-01-24 16:24:59 --> Config Class Initialized
INFO - 2017-01-24 16:24:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:24:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:24:59 --> Utf8 Class Initialized
INFO - 2017-01-24 16:24:59 --> URI Class Initialized
INFO - 2017-01-24 16:24:59 --> Router Class Initialized
INFO - 2017-01-24 16:24:59 --> Output Class Initialized
INFO - 2017-01-24 16:24:59 --> Security Class Initialized
DEBUG - 2017-01-24 16:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:24:59 --> Input Class Initialized
INFO - 2017-01-24 16:24:59 --> Language Class Initialized
INFO - 2017-01-24 16:24:59 --> Loader Class Initialized
INFO - 2017-01-24 16:24:59 --> Database Driver Class Initialized
INFO - 2017-01-24 16:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:24:59 --> Controller Class Initialized
INFO - 2017-01-24 16:24:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:24:59 --> Final output sent to browser
DEBUG - 2017-01-24 16:24:59 --> Total execution time: 0.0143
INFO - 2017-01-24 16:24:59 --> Config Class Initialized
INFO - 2017-01-24 16:24:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:24:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:24:59 --> Utf8 Class Initialized
INFO - 2017-01-24 16:24:59 --> URI Class Initialized
INFO - 2017-01-24 16:24:59 --> Router Class Initialized
INFO - 2017-01-24 16:24:59 --> Output Class Initialized
INFO - 2017-01-24 16:24:59 --> Security Class Initialized
DEBUG - 2017-01-24 16:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:24:59 --> Input Class Initialized
INFO - 2017-01-24 16:24:59 --> Language Class Initialized
INFO - 2017-01-24 16:24:59 --> Loader Class Initialized
INFO - 2017-01-24 16:24:59 --> Database Driver Class Initialized
INFO - 2017-01-24 16:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:24:59 --> Controller Class Initialized
INFO - 2017-01-24 16:24:59 --> Helper loaded: date_helper
INFO - 2017-01-24 16:24:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:24:59 --> Helper loaded: form_helper
INFO - 2017-01-24 16:24:59 --> Form Validation Class Initialized
INFO - 2017-01-24 16:24:59 --> Final output sent to browser
DEBUG - 2017-01-24 16:24:59 --> Total execution time: 0.0153
INFO - 2017-01-24 16:25:02 --> Config Class Initialized
INFO - 2017-01-24 16:25:02 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:25:02 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:25:02 --> Utf8 Class Initialized
INFO - 2017-01-24 16:25:02 --> URI Class Initialized
INFO - 2017-01-24 16:25:02 --> Router Class Initialized
INFO - 2017-01-24 16:25:02 --> Output Class Initialized
INFO - 2017-01-24 16:25:02 --> Security Class Initialized
DEBUG - 2017-01-24 16:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:25:02 --> Input Class Initialized
INFO - 2017-01-24 16:25:02 --> Language Class Initialized
INFO - 2017-01-24 16:25:02 --> Loader Class Initialized
INFO - 2017-01-24 16:25:02 --> Database Driver Class Initialized
INFO - 2017-01-24 16:25:02 --> Config Class Initialized
INFO - 2017-01-24 16:25:02 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:25:02 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:25:02 --> Utf8 Class Initialized
INFO - 2017-01-24 16:25:02 --> URI Class Initialized
INFO - 2017-01-24 16:25:02 --> Router Class Initialized
INFO - 2017-01-24 16:25:02 --> Output Class Initialized
INFO - 2017-01-24 16:25:02 --> Security Class Initialized
DEBUG - 2017-01-24 16:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:25:02 --> Input Class Initialized
INFO - 2017-01-24 16:25:02 --> Language Class Initialized
INFO - 2017-01-24 16:25:02 --> Loader Class Initialized
INFO - 2017-01-24 16:25:02 --> Database Driver Class Initialized
INFO - 2017-01-24 16:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:25:02 --> Controller Class Initialized
INFO - 2017-01-24 16:25:02 --> Helper loaded: date_helper
INFO - 2017-01-24 16:25:02 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:25:02 --> Helper loaded: form_helper
INFO - 2017-01-24 16:25:02 --> Form Validation Class Initialized
INFO - 2017-01-24 16:25:02 --> Final output sent to browser
DEBUG - 2017-01-24 16:25:02 --> Total execution time: 0.0960
INFO - 2017-01-24 16:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:25:02 --> Controller Class Initialized
INFO - 2017-01-24 16:25:02 --> Helper loaded: date_helper
INFO - 2017-01-24 16:25:02 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:25:02 --> Helper loaded: form_helper
INFO - 2017-01-24 16:25:02 --> Form Validation Class Initialized
INFO - 2017-01-24 16:25:02 --> Final output sent to browser
DEBUG - 2017-01-24 16:25:02 --> Total execution time: 0.0776
INFO - 2017-01-24 16:26:29 --> Config Class Initialized
INFO - 2017-01-24 16:26:29 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:26:29 --> Utf8 Class Initialized
INFO - 2017-01-24 16:26:29 --> URI Class Initialized
DEBUG - 2017-01-24 16:26:29 --> No URI present. Default controller set.
INFO - 2017-01-24 16:26:29 --> Router Class Initialized
INFO - 2017-01-24 16:26:29 --> Output Class Initialized
INFO - 2017-01-24 16:26:29 --> Security Class Initialized
DEBUG - 2017-01-24 16:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:26:29 --> Input Class Initialized
INFO - 2017-01-24 16:26:29 --> Language Class Initialized
INFO - 2017-01-24 16:26:29 --> Loader Class Initialized
INFO - 2017-01-24 16:26:29 --> Database Driver Class Initialized
INFO - 2017-01-24 16:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:26:29 --> Controller Class Initialized
INFO - 2017-01-24 16:26:29 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:26:29 --> Final output sent to browser
DEBUG - 2017-01-24 16:26:29 --> Total execution time: 0.0139
INFO - 2017-01-24 16:56:31 --> Config Class Initialized
INFO - 2017-01-24 16:56:31 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:56:31 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:56:31 --> Utf8 Class Initialized
INFO - 2017-01-24 16:56:31 --> URI Class Initialized
INFO - 2017-01-24 16:56:31 --> Router Class Initialized
INFO - 2017-01-24 16:56:31 --> Output Class Initialized
INFO - 2017-01-24 16:56:31 --> Security Class Initialized
DEBUG - 2017-01-24 16:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:56:31 --> Input Class Initialized
INFO - 2017-01-24 16:56:31 --> Language Class Initialized
INFO - 2017-01-24 16:56:31 --> Loader Class Initialized
INFO - 2017-01-24 16:56:31 --> Database Driver Class Initialized
INFO - 2017-01-24 16:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:56:31 --> Controller Class Initialized
INFO - 2017-01-24 16:56:31 --> Helper loaded: date_helper
INFO - 2017-01-24 16:56:31 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:56:31 --> Helper loaded: form_helper
INFO - 2017-01-24 16:56:31 --> Form Validation Class Initialized
INFO - 2017-01-24 16:56:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:56:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:56:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:56:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:56:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:56:31 --> Final output sent to browser
DEBUG - 2017-01-24 16:56:31 --> Total execution time: 0.0253
INFO - 2017-01-24 16:56:32 --> Config Class Initialized
INFO - 2017-01-24 16:56:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:56:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:56:32 --> Utf8 Class Initialized
INFO - 2017-01-24 16:56:32 --> URI Class Initialized
INFO - 2017-01-24 16:56:32 --> Router Class Initialized
INFO - 2017-01-24 16:56:32 --> Output Class Initialized
INFO - 2017-01-24 16:56:32 --> Security Class Initialized
DEBUG - 2017-01-24 16:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:56:32 --> Input Class Initialized
INFO - 2017-01-24 16:56:32 --> Language Class Initialized
INFO - 2017-01-24 16:56:32 --> Loader Class Initialized
INFO - 2017-01-24 16:56:32 --> Database Driver Class Initialized
INFO - 2017-01-24 16:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:56:32 --> Controller Class Initialized
INFO - 2017-01-24 16:56:32 --> Helper loaded: date_helper
INFO - 2017-01-24 16:56:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:56:32 --> Helper loaded: form_helper
INFO - 2017-01-24 16:56:32 --> Form Validation Class Initialized
INFO - 2017-01-24 16:56:32 --> Final output sent to browser
DEBUG - 2017-01-24 16:56:32 --> Total execution time: 0.0503
INFO - 2017-01-24 16:56:32 --> Config Class Initialized
INFO - 2017-01-24 16:56:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:56:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:56:32 --> Utf8 Class Initialized
INFO - 2017-01-24 16:56:32 --> URI Class Initialized
INFO - 2017-01-24 16:56:32 --> Router Class Initialized
INFO - 2017-01-24 16:56:32 --> Output Class Initialized
INFO - 2017-01-24 16:56:32 --> Security Class Initialized
DEBUG - 2017-01-24 16:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:56:32 --> Input Class Initialized
INFO - 2017-01-24 16:56:32 --> Language Class Initialized
INFO - 2017-01-24 16:56:32 --> Loader Class Initialized
INFO - 2017-01-24 16:56:32 --> Database Driver Class Initialized
INFO - 2017-01-24 16:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:56:32 --> Controller Class Initialized
INFO - 2017-01-24 16:56:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:56:32 --> Final output sent to browser
DEBUG - 2017-01-24 16:56:32 --> Total execution time: 0.0604
INFO - 2017-01-24 16:56:34 --> Config Class Initialized
INFO - 2017-01-24 16:56:34 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:56:34 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:56:34 --> Utf8 Class Initialized
INFO - 2017-01-24 16:56:34 --> URI Class Initialized
INFO - 2017-01-24 16:56:34 --> Router Class Initialized
INFO - 2017-01-24 16:56:34 --> Output Class Initialized
INFO - 2017-01-24 16:56:34 --> Security Class Initialized
DEBUG - 2017-01-24 16:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:56:34 --> Input Class Initialized
INFO - 2017-01-24 16:56:34 --> Language Class Initialized
ERROR - 2017-01-24 16:56:34 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 16:56:36 --> Config Class Initialized
INFO - 2017-01-24 16:56:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:56:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:56:36 --> Utf8 Class Initialized
INFO - 2017-01-24 16:56:36 --> URI Class Initialized
INFO - 2017-01-24 16:56:36 --> Router Class Initialized
INFO - 2017-01-24 16:56:36 --> Config Class Initialized
INFO - 2017-01-24 16:56:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:56:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:56:36 --> Utf8 Class Initialized
INFO - 2017-01-24 16:56:36 --> URI Class Initialized
INFO - 2017-01-24 16:56:36 --> Router Class Initialized
INFO - 2017-01-24 16:56:36 --> Output Class Initialized
INFO - 2017-01-24 16:56:36 --> Security Class Initialized
DEBUG - 2017-01-24 16:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:56:36 --> Input Class Initialized
INFO - 2017-01-24 16:56:36 --> Language Class Initialized
INFO - 2017-01-24 16:56:36 --> Loader Class Initialized
INFO - 2017-01-24 16:56:36 --> Output Class Initialized
INFO - 2017-01-24 16:56:36 --> Security Class Initialized
DEBUG - 2017-01-24 16:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:56:36 --> Input Class Initialized
INFO - 2017-01-24 16:56:36 --> Language Class Initialized
INFO - 2017-01-24 16:56:36 --> Loader Class Initialized
INFO - 2017-01-24 16:56:36 --> Database Driver Class Initialized
INFO - 2017-01-24 16:56:36 --> Database Driver Class Initialized
INFO - 2017-01-24 16:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:56:36 --> Controller Class Initialized
INFO - 2017-01-24 16:56:36 --> Helper loaded: date_helper
INFO - 2017-01-24 16:56:36 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:56:36 --> Helper loaded: form_helper
INFO - 2017-01-24 16:56:36 --> Form Validation Class Initialized
INFO - 2017-01-24 16:56:36 --> Final output sent to browser
DEBUG - 2017-01-24 16:56:36 --> Total execution time: 0.0868
INFO - 2017-01-24 16:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:56:36 --> Controller Class Initialized
INFO - 2017-01-24 16:56:36 --> Helper loaded: date_helper
INFO - 2017-01-24 16:56:36 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:56:36 --> Helper loaded: form_helper
INFO - 2017-01-24 16:56:36 --> Form Validation Class Initialized
INFO - 2017-01-24 16:56:36 --> Final output sent to browser
DEBUG - 2017-01-24 16:56:36 --> Total execution time: 0.1087
INFO - 2017-01-24 16:59:19 --> Config Class Initialized
INFO - 2017-01-24 16:59:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:59:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:59:19 --> Utf8 Class Initialized
INFO - 2017-01-24 16:59:19 --> URI Class Initialized
INFO - 2017-01-24 16:59:19 --> Router Class Initialized
INFO - 2017-01-24 16:59:19 --> Output Class Initialized
INFO - 2017-01-24 16:59:19 --> Security Class Initialized
DEBUG - 2017-01-24 16:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:59:19 --> Input Class Initialized
INFO - 2017-01-24 16:59:19 --> Language Class Initialized
INFO - 2017-01-24 16:59:19 --> Loader Class Initialized
INFO - 2017-01-24 16:59:19 --> Database Driver Class Initialized
INFO - 2017-01-24 16:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:59:19 --> Controller Class Initialized
INFO - 2017-01-24 16:59:19 --> Helper loaded: date_helper
INFO - 2017-01-24 16:59:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:59:19 --> Helper loaded: form_helper
INFO - 2017-01-24 16:59:19 --> Form Validation Class Initialized
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 16:59:19 --> Final output sent to browser
DEBUG - 2017-01-24 16:59:19 --> Total execution time: 0.0616
INFO - 2017-01-24 16:59:19 --> Config Class Initialized
INFO - 2017-01-24 16:59:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:59:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:59:19 --> Utf8 Class Initialized
INFO - 2017-01-24 16:59:19 --> URI Class Initialized
INFO - 2017-01-24 16:59:19 --> Router Class Initialized
INFO - 2017-01-24 16:59:19 --> Output Class Initialized
INFO - 2017-01-24 16:59:19 --> Security Class Initialized
DEBUG - 2017-01-24 16:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:59:19 --> Input Class Initialized
INFO - 2017-01-24 16:59:19 --> Language Class Initialized
INFO - 2017-01-24 16:59:19 --> Loader Class Initialized
INFO - 2017-01-24 16:59:19 --> Database Driver Class Initialized
INFO - 2017-01-24 16:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:59:19 --> Controller Class Initialized
INFO - 2017-01-24 16:59:19 --> Helper loaded: date_helper
INFO - 2017-01-24 16:59:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:59:19 --> Helper loaded: form_helper
INFO - 2017-01-24 16:59:19 --> Form Validation Class Initialized
INFO - 2017-01-24 16:59:19 --> Final output sent to browser
DEBUG - 2017-01-24 16:59:19 --> Total execution time: 0.0150
INFO - 2017-01-24 16:59:19 --> Config Class Initialized
INFO - 2017-01-24 16:59:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:59:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:59:19 --> Utf8 Class Initialized
INFO - 2017-01-24 16:59:19 --> URI Class Initialized
INFO - 2017-01-24 16:59:19 --> Router Class Initialized
INFO - 2017-01-24 16:59:19 --> Output Class Initialized
INFO - 2017-01-24 16:59:19 --> Security Class Initialized
DEBUG - 2017-01-24 16:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:59:19 --> Input Class Initialized
INFO - 2017-01-24 16:59:19 --> Language Class Initialized
INFO - 2017-01-24 16:59:19 --> Loader Class Initialized
INFO - 2017-01-24 16:59:19 --> Database Driver Class Initialized
INFO - 2017-01-24 16:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:59:19 --> Controller Class Initialized
INFO - 2017-01-24 16:59:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 16:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 16:59:19 --> Final output sent to browser
DEBUG - 2017-01-24 16:59:19 --> Total execution time: 0.0457
INFO - 2017-01-24 16:59:21 --> Config Class Initialized
INFO - 2017-01-24 16:59:21 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:59:21 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:59:21 --> Utf8 Class Initialized
INFO - 2017-01-24 16:59:21 --> URI Class Initialized
INFO - 2017-01-24 16:59:21 --> Config Class Initialized
INFO - 2017-01-24 16:59:21 --> Hooks Class Initialized
DEBUG - 2017-01-24 16:59:21 --> UTF-8 Support Enabled
INFO - 2017-01-24 16:59:21 --> Utf8 Class Initialized
INFO - 2017-01-24 16:59:21 --> URI Class Initialized
INFO - 2017-01-24 16:59:21 --> Router Class Initialized
INFO - 2017-01-24 16:59:21 --> Output Class Initialized
INFO - 2017-01-24 16:59:21 --> Security Class Initialized
DEBUG - 2017-01-24 16:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:59:21 --> Input Class Initialized
INFO - 2017-01-24 16:59:21 --> Language Class Initialized
INFO - 2017-01-24 16:59:21 --> Loader Class Initialized
INFO - 2017-01-24 16:59:21 --> Database Driver Class Initialized
INFO - 2017-01-24 16:59:21 --> Router Class Initialized
INFO - 2017-01-24 16:59:21 --> Output Class Initialized
INFO - 2017-01-24 16:59:21 --> Security Class Initialized
DEBUG - 2017-01-24 16:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 16:59:21 --> Input Class Initialized
INFO - 2017-01-24 16:59:21 --> Language Class Initialized
INFO - 2017-01-24 16:59:21 --> Loader Class Initialized
INFO - 2017-01-24 16:59:22 --> Database Driver Class Initialized
INFO - 2017-01-24 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:59:22 --> Controller Class Initialized
INFO - 2017-01-24 16:59:22 --> Helper loaded: date_helper
INFO - 2017-01-24 16:59:22 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:59:22 --> Helper loaded: form_helper
INFO - 2017-01-24 16:59:22 --> Form Validation Class Initialized
INFO - 2017-01-24 16:59:22 --> Final output sent to browser
DEBUG - 2017-01-24 16:59:22 --> Total execution time: 0.0885
INFO - 2017-01-24 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 16:59:22 --> Controller Class Initialized
INFO - 2017-01-24 16:59:22 --> Helper loaded: date_helper
INFO - 2017-01-24 16:59:22 --> Helper loaded: url_helper
DEBUG - 2017-01-24 16:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 16:59:22 --> Helper loaded: form_helper
INFO - 2017-01-24 16:59:22 --> Form Validation Class Initialized
INFO - 2017-01-24 16:59:22 --> Final output sent to browser
DEBUG - 2017-01-24 16:59:22 --> Total execution time: 0.0849
INFO - 2017-01-24 17:03:42 --> Config Class Initialized
INFO - 2017-01-24 17:03:42 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:03:42 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:03:42 --> Utf8 Class Initialized
INFO - 2017-01-24 17:03:42 --> URI Class Initialized
INFO - 2017-01-24 17:03:42 --> Router Class Initialized
INFO - 2017-01-24 17:03:42 --> Output Class Initialized
INFO - 2017-01-24 17:03:42 --> Security Class Initialized
DEBUG - 2017-01-24 17:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:03:42 --> Input Class Initialized
INFO - 2017-01-24 17:03:42 --> Language Class Initialized
INFO - 2017-01-24 17:03:42 --> Loader Class Initialized
INFO - 2017-01-24 17:03:42 --> Database Driver Class Initialized
INFO - 2017-01-24 17:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:03:42 --> Controller Class Initialized
INFO - 2017-01-24 17:03:42 --> Helper loaded: date_helper
INFO - 2017-01-24 17:03:42 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:03:42 --> Helper loaded: form_helper
INFO - 2017-01-24 17:03:42 --> Form Validation Class Initialized
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 17:03:42 --> Final output sent to browser
DEBUG - 2017-01-24 17:03:42 --> Total execution time: 0.0234
INFO - 2017-01-24 17:03:42 --> Config Class Initialized
INFO - 2017-01-24 17:03:42 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:03:42 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:03:42 --> Utf8 Class Initialized
INFO - 2017-01-24 17:03:42 --> URI Class Initialized
INFO - 2017-01-24 17:03:42 --> Router Class Initialized
INFO - 2017-01-24 17:03:42 --> Output Class Initialized
INFO - 2017-01-24 17:03:42 --> Security Class Initialized
DEBUG - 2017-01-24 17:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:03:42 --> Input Class Initialized
INFO - 2017-01-24 17:03:42 --> Language Class Initialized
INFO - 2017-01-24 17:03:42 --> Loader Class Initialized
INFO - 2017-01-24 17:03:42 --> Database Driver Class Initialized
INFO - 2017-01-24 17:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:03:42 --> Controller Class Initialized
INFO - 2017-01-24 17:03:42 --> Helper loaded: date_helper
INFO - 2017-01-24 17:03:42 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:03:42 --> Helper loaded: form_helper
INFO - 2017-01-24 17:03:42 --> Form Validation Class Initialized
INFO - 2017-01-24 17:03:42 --> Final output sent to browser
DEBUG - 2017-01-24 17:03:42 --> Total execution time: 0.0158
INFO - 2017-01-24 17:03:42 --> Config Class Initialized
INFO - 2017-01-24 17:03:42 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:03:42 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:03:42 --> Utf8 Class Initialized
INFO - 2017-01-24 17:03:42 --> URI Class Initialized
INFO - 2017-01-24 17:03:42 --> Router Class Initialized
INFO - 2017-01-24 17:03:42 --> Output Class Initialized
INFO - 2017-01-24 17:03:42 --> Security Class Initialized
DEBUG - 2017-01-24 17:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:03:42 --> Input Class Initialized
INFO - 2017-01-24 17:03:42 --> Language Class Initialized
INFO - 2017-01-24 17:03:42 --> Loader Class Initialized
INFO - 2017-01-24 17:03:42 --> Database Driver Class Initialized
INFO - 2017-01-24 17:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:03:42 --> Controller Class Initialized
INFO - 2017-01-24 17:03:42 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:03:42 --> Final output sent to browser
DEBUG - 2017-01-24 17:03:42 --> Total execution time: 0.0142
INFO - 2017-01-24 17:03:46 --> Config Class Initialized
INFO - 2017-01-24 17:03:46 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:03:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:03:46 --> Utf8 Class Initialized
INFO - 2017-01-24 17:03:46 --> URI Class Initialized
INFO - 2017-01-24 17:03:46 --> Router Class Initialized
INFO - 2017-01-24 17:03:46 --> Output Class Initialized
INFO - 2017-01-24 17:03:46 --> Security Class Initialized
DEBUG - 2017-01-24 17:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:03:46 --> Input Class Initialized
INFO - 2017-01-24 17:03:46 --> Language Class Initialized
INFO - 2017-01-24 17:03:46 --> Loader Class Initialized
INFO - 2017-01-24 17:03:46 --> Database Driver Class Initialized
INFO - 2017-01-24 17:03:46 --> Config Class Initialized
INFO - 2017-01-24 17:03:46 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:03:46 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:03:46 --> Utf8 Class Initialized
INFO - 2017-01-24 17:03:46 --> URI Class Initialized
INFO - 2017-01-24 17:03:46 --> Router Class Initialized
INFO - 2017-01-24 17:03:46 --> Output Class Initialized
INFO - 2017-01-24 17:03:46 --> Security Class Initialized
DEBUG - 2017-01-24 17:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:03:46 --> Input Class Initialized
INFO - 2017-01-24 17:03:46 --> Language Class Initialized
INFO - 2017-01-24 17:03:46 --> Loader Class Initialized
INFO - 2017-01-24 17:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:03:46 --> Controller Class Initialized
INFO - 2017-01-24 17:03:46 --> Helper loaded: date_helper
INFO - 2017-01-24 17:03:46 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:03:46 --> Helper loaded: form_helper
INFO - 2017-01-24 17:03:46 --> Form Validation Class Initialized
INFO - 2017-01-24 17:03:46 --> Final output sent to browser
DEBUG - 2017-01-24 17:03:46 --> Total execution time: 0.0573
INFO - 2017-01-24 17:03:46 --> Database Driver Class Initialized
INFO - 2017-01-24 17:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:03:46 --> Controller Class Initialized
INFO - 2017-01-24 17:03:46 --> Helper loaded: date_helper
INFO - 2017-01-24 17:03:46 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:03:46 --> Helper loaded: form_helper
INFO - 2017-01-24 17:03:46 --> Form Validation Class Initialized
INFO - 2017-01-24 17:03:46 --> Final output sent to browser
DEBUG - 2017-01-24 17:03:46 --> Total execution time: 0.0758
INFO - 2017-01-24 17:42:23 --> Config Class Initialized
INFO - 2017-01-24 17:42:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:42:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:42:23 --> Utf8 Class Initialized
INFO - 2017-01-24 17:42:23 --> URI Class Initialized
DEBUG - 2017-01-24 17:42:23 --> No URI present. Default controller set.
INFO - 2017-01-24 17:42:23 --> Router Class Initialized
INFO - 2017-01-24 17:42:23 --> Output Class Initialized
INFO - 2017-01-24 17:42:23 --> Security Class Initialized
DEBUG - 2017-01-24 17:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:42:23 --> Input Class Initialized
INFO - 2017-01-24 17:42:23 --> Language Class Initialized
INFO - 2017-01-24 17:42:23 --> Loader Class Initialized
INFO - 2017-01-24 17:42:23 --> Database Driver Class Initialized
INFO - 2017-01-24 17:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:42:23 --> Controller Class Initialized
INFO - 2017-01-24 17:42:23 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:42:24 --> Final output sent to browser
DEBUG - 2017-01-24 17:42:24 --> Total execution time: 0.0135
INFO - 2017-01-24 17:42:28 --> Config Class Initialized
INFO - 2017-01-24 17:42:28 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:42:28 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:42:28 --> Utf8 Class Initialized
INFO - 2017-01-24 17:42:28 --> URI Class Initialized
INFO - 2017-01-24 17:42:28 --> Router Class Initialized
INFO - 2017-01-24 17:42:28 --> Output Class Initialized
INFO - 2017-01-24 17:42:28 --> Security Class Initialized
DEBUG - 2017-01-24 17:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:42:28 --> Input Class Initialized
INFO - 2017-01-24 17:42:28 --> Language Class Initialized
INFO - 2017-01-24 17:42:28 --> Loader Class Initialized
INFO - 2017-01-24 17:42:28 --> Database Driver Class Initialized
INFO - 2017-01-24 17:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:42:28 --> Controller Class Initialized
INFO - 2017-01-24 17:42:28 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:42:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:42:29 --> Final output sent to browser
DEBUG - 2017-01-24 17:42:29 --> Total execution time: 0.0154
INFO - 2017-01-24 17:42:51 --> Config Class Initialized
INFO - 2017-01-24 17:42:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:42:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:42:51 --> Utf8 Class Initialized
INFO - 2017-01-24 17:42:51 --> URI Class Initialized
INFO - 2017-01-24 17:42:51 --> Router Class Initialized
INFO - 2017-01-24 17:42:51 --> Output Class Initialized
INFO - 2017-01-24 17:42:51 --> Security Class Initialized
DEBUG - 2017-01-24 17:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:42:51 --> Input Class Initialized
INFO - 2017-01-24 17:42:51 --> Language Class Initialized
INFO - 2017-01-24 17:42:51 --> Loader Class Initialized
INFO - 2017-01-24 17:42:51 --> Database Driver Class Initialized
INFO - 2017-01-24 17:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:42:51 --> Controller Class Initialized
INFO - 2017-01-24 17:42:51 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:42:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:42:51 --> Final output sent to browser
DEBUG - 2017-01-24 17:42:51 --> Total execution time: 0.0296
INFO - 2017-01-24 17:42:52 --> Config Class Initialized
INFO - 2017-01-24 17:42:52 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:42:52 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:42:52 --> Utf8 Class Initialized
INFO - 2017-01-24 17:42:52 --> URI Class Initialized
INFO - 2017-01-24 17:42:52 --> Router Class Initialized
INFO - 2017-01-24 17:42:52 --> Output Class Initialized
INFO - 2017-01-24 17:42:52 --> Security Class Initialized
DEBUG - 2017-01-24 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:42:52 --> Input Class Initialized
INFO - 2017-01-24 17:42:52 --> Language Class Initialized
INFO - 2017-01-24 17:42:52 --> Loader Class Initialized
INFO - 2017-01-24 17:42:52 --> Database Driver Class Initialized
INFO - 2017-01-24 17:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:42:52 --> Controller Class Initialized
INFO - 2017-01-24 17:42:52 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:42:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:42:52 --> Final output sent to browser
DEBUG - 2017-01-24 17:42:52 --> Total execution time: 0.0157
INFO - 2017-01-24 17:43:18 --> Config Class Initialized
INFO - 2017-01-24 17:43:18 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:43:18 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:43:18 --> Utf8 Class Initialized
INFO - 2017-01-24 17:43:18 --> URI Class Initialized
INFO - 2017-01-24 17:43:18 --> Router Class Initialized
INFO - 2017-01-24 17:43:18 --> Output Class Initialized
INFO - 2017-01-24 17:43:18 --> Security Class Initialized
DEBUG - 2017-01-24 17:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:43:18 --> Input Class Initialized
INFO - 2017-01-24 17:43:18 --> Language Class Initialized
INFO - 2017-01-24 17:43:18 --> Loader Class Initialized
INFO - 2017-01-24 17:43:18 --> Database Driver Class Initialized
INFO - 2017-01-24 17:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:43:18 --> Controller Class Initialized
INFO - 2017-01-24 17:43:18 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:43:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 17:43:20 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 17:43:20 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'LiLi Coronado')
INFO - 2017-01-24 17:43:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 17:43:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 17:43:20 --> Config Class Initialized
INFO - 2017-01-24 17:43:20 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:43:20 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:43:20 --> Utf8 Class Initialized
INFO - 2017-01-24 17:43:20 --> URI Class Initialized
INFO - 2017-01-24 17:43:20 --> Router Class Initialized
INFO - 2017-01-24 17:43:20 --> Output Class Initialized
INFO - 2017-01-24 17:43:20 --> Security Class Initialized
DEBUG - 2017-01-24 17:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:43:20 --> Input Class Initialized
INFO - 2017-01-24 17:43:20 --> Language Class Initialized
INFO - 2017-01-24 17:43:20 --> Loader Class Initialized
INFO - 2017-01-24 17:43:20 --> Database Driver Class Initialized
INFO - 2017-01-24 17:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:43:20 --> Controller Class Initialized
INFO - 2017-01-24 17:43:20 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:43:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:43:20 --> Final output sent to browser
DEBUG - 2017-01-24 17:43:20 --> Total execution time: 0.0167
INFO - 2017-01-24 17:43:32 --> Config Class Initialized
INFO - 2017-01-24 17:43:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:43:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:43:32 --> Utf8 Class Initialized
INFO - 2017-01-24 17:43:32 --> URI Class Initialized
INFO - 2017-01-24 17:43:32 --> Router Class Initialized
INFO - 2017-01-24 17:43:32 --> Output Class Initialized
INFO - 2017-01-24 17:43:32 --> Security Class Initialized
DEBUG - 2017-01-24 17:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:43:32 --> Input Class Initialized
INFO - 2017-01-24 17:43:32 --> Language Class Initialized
INFO - 2017-01-24 17:43:32 --> Loader Class Initialized
INFO - 2017-01-24 17:43:32 --> Database Driver Class Initialized
INFO - 2017-01-24 17:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:43:32 --> Controller Class Initialized
INFO - 2017-01-24 17:43:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:43:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 17:43:33 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 17:43:33 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'LiLi Coronado')
INFO - 2017-01-24 17:43:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 17:43:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 17:43:33 --> Config Class Initialized
INFO - 2017-01-24 17:43:33 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:43:33 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:43:33 --> Utf8 Class Initialized
INFO - 2017-01-24 17:43:33 --> URI Class Initialized
INFO - 2017-01-24 17:43:33 --> Router Class Initialized
INFO - 2017-01-24 17:43:33 --> Output Class Initialized
INFO - 2017-01-24 17:43:33 --> Security Class Initialized
DEBUG - 2017-01-24 17:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:43:33 --> Input Class Initialized
INFO - 2017-01-24 17:43:33 --> Language Class Initialized
INFO - 2017-01-24 17:43:33 --> Loader Class Initialized
INFO - 2017-01-24 17:43:33 --> Database Driver Class Initialized
INFO - 2017-01-24 17:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:43:33 --> Controller Class Initialized
INFO - 2017-01-24 17:43:33 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:43:33 --> Final output sent to browser
DEBUG - 2017-01-24 17:43:33 --> Total execution time: 0.0142
INFO - 2017-01-24 17:44:08 --> Config Class Initialized
INFO - 2017-01-24 17:44:08 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:44:08 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:44:08 --> Utf8 Class Initialized
INFO - 2017-01-24 17:44:08 --> URI Class Initialized
INFO - 2017-01-24 17:44:08 --> Router Class Initialized
INFO - 2017-01-24 17:44:08 --> Output Class Initialized
INFO - 2017-01-24 17:44:08 --> Security Class Initialized
DEBUG - 2017-01-24 17:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:44:08 --> Input Class Initialized
INFO - 2017-01-24 17:44:08 --> Language Class Initialized
INFO - 2017-01-24 17:44:08 --> Loader Class Initialized
INFO - 2017-01-24 17:44:08 --> Database Driver Class Initialized
INFO - 2017-01-24 17:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:44:08 --> Controller Class Initialized
INFO - 2017-01-24 17:44:08 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:44:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 17:44:10 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 17:44:10 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'LiLi Coronado')
INFO - 2017-01-24 17:44:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 17:44:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 17:44:10 --> Config Class Initialized
INFO - 2017-01-24 17:44:10 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:44:10 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:44:10 --> Utf8 Class Initialized
INFO - 2017-01-24 17:44:10 --> URI Class Initialized
INFO - 2017-01-24 17:44:10 --> Router Class Initialized
INFO - 2017-01-24 17:44:10 --> Output Class Initialized
INFO - 2017-01-24 17:44:10 --> Security Class Initialized
DEBUG - 2017-01-24 17:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:44:10 --> Input Class Initialized
INFO - 2017-01-24 17:44:10 --> Language Class Initialized
INFO - 2017-01-24 17:44:10 --> Loader Class Initialized
INFO - 2017-01-24 17:44:10 --> Database Driver Class Initialized
INFO - 2017-01-24 17:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:44:10 --> Controller Class Initialized
INFO - 2017-01-24 17:44:10 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:44:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:44:11 --> Final output sent to browser
DEBUG - 2017-01-24 17:44:11 --> Total execution time: 0.0318
INFO - 2017-01-24 17:44:13 --> Config Class Initialized
INFO - 2017-01-24 17:44:13 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:44:13 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:44:13 --> Utf8 Class Initialized
INFO - 2017-01-24 17:44:13 --> URI Class Initialized
DEBUG - 2017-01-24 17:44:13 --> No URI present. Default controller set.
INFO - 2017-01-24 17:44:13 --> Router Class Initialized
INFO - 2017-01-24 17:44:13 --> Output Class Initialized
INFO - 2017-01-24 17:44:13 --> Security Class Initialized
DEBUG - 2017-01-24 17:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:44:13 --> Input Class Initialized
INFO - 2017-01-24 17:44:13 --> Language Class Initialized
INFO - 2017-01-24 17:44:13 --> Loader Class Initialized
INFO - 2017-01-24 17:44:13 --> Database Driver Class Initialized
INFO - 2017-01-24 17:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:44:13 --> Controller Class Initialized
INFO - 2017-01-24 17:44:13 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:44:13 --> Final output sent to browser
DEBUG - 2017-01-24 17:44:13 --> Total execution time: 0.0149
INFO - 2017-01-24 17:44:14 --> Config Class Initialized
INFO - 2017-01-24 17:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:44:14 --> Utf8 Class Initialized
INFO - 2017-01-24 17:44:14 --> URI Class Initialized
INFO - 2017-01-24 17:44:14 --> Router Class Initialized
INFO - 2017-01-24 17:44:14 --> Output Class Initialized
INFO - 2017-01-24 17:44:14 --> Security Class Initialized
DEBUG - 2017-01-24 17:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:44:14 --> Input Class Initialized
INFO - 2017-01-24 17:44:14 --> Language Class Initialized
INFO - 2017-01-24 17:44:14 --> Loader Class Initialized
INFO - 2017-01-24 17:44:14 --> Database Driver Class Initialized
INFO - 2017-01-24 17:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:44:14 --> Controller Class Initialized
INFO - 2017-01-24 17:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:44:14 --> Final output sent to browser
DEBUG - 2017-01-24 17:44:14 --> Total execution time: 0.0152
INFO - 2017-01-24 17:45:11 --> Config Class Initialized
INFO - 2017-01-24 17:45:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:11 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:11 --> URI Class Initialized
INFO - 2017-01-24 17:45:11 --> Router Class Initialized
INFO - 2017-01-24 17:45:11 --> Output Class Initialized
INFO - 2017-01-24 17:45:11 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:11 --> Input Class Initialized
INFO - 2017-01-24 17:45:11 --> Language Class Initialized
INFO - 2017-01-24 17:45:11 --> Loader Class Initialized
INFO - 2017-01-24 17:45:11 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:11 --> Controller Class Initialized
INFO - 2017-01-24 17:45:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:11 --> Config Class Initialized
INFO - 2017-01-24 17:45:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:11 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:11 --> URI Class Initialized
INFO - 2017-01-24 17:45:11 --> Router Class Initialized
INFO - 2017-01-24 17:45:11 --> Output Class Initialized
INFO - 2017-01-24 17:45:11 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:11 --> Input Class Initialized
INFO - 2017-01-24 17:45:11 --> Language Class Initialized
INFO - 2017-01-24 17:45:11 --> Loader Class Initialized
INFO - 2017-01-24 17:45:11 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:11 --> Controller Class Initialized
INFO - 2017-01-24 17:45:11 --> Helper loaded: date_helper
DEBUG - 2017-01-24 17:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:11 --> Helper loaded: url_helper
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:11 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:11 --> Total execution time: 0.0527
INFO - 2017-01-24 17:45:11 --> Config Class Initialized
INFO - 2017-01-24 17:45:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:11 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:11 --> URI Class Initialized
INFO - 2017-01-24 17:45:11 --> Router Class Initialized
INFO - 2017-01-24 17:45:11 --> Output Class Initialized
INFO - 2017-01-24 17:45:11 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:11 --> Input Class Initialized
INFO - 2017-01-24 17:45:11 --> Language Class Initialized
INFO - 2017-01-24 17:45:11 --> Loader Class Initialized
INFO - 2017-01-24 17:45:11 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:11 --> Controller Class Initialized
INFO - 2017-01-24 17:45:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:11 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:11 --> Total execution time: 0.0133
INFO - 2017-01-24 17:45:19 --> Config Class Initialized
INFO - 2017-01-24 17:45:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:19 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:19 --> URI Class Initialized
DEBUG - 2017-01-24 17:45:19 --> No URI present. Default controller set.
INFO - 2017-01-24 17:45:19 --> Router Class Initialized
INFO - 2017-01-24 17:45:19 --> Output Class Initialized
INFO - 2017-01-24 17:45:19 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:19 --> Input Class Initialized
INFO - 2017-01-24 17:45:19 --> Language Class Initialized
INFO - 2017-01-24 17:45:19 --> Loader Class Initialized
INFO - 2017-01-24 17:45:19 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:19 --> Controller Class Initialized
INFO - 2017-01-24 17:45:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:19 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:19 --> Total execution time: 0.0330
INFO - 2017-01-24 17:45:19 --> Config Class Initialized
INFO - 2017-01-24 17:45:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:19 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:19 --> URI Class Initialized
INFO - 2017-01-24 17:45:19 --> Router Class Initialized
INFO - 2017-01-24 17:45:19 --> Output Class Initialized
INFO - 2017-01-24 17:45:19 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:19 --> Input Class Initialized
INFO - 2017-01-24 17:45:19 --> Language Class Initialized
INFO - 2017-01-24 17:45:19 --> Loader Class Initialized
INFO - 2017-01-24 17:45:19 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:19 --> Controller Class Initialized
INFO - 2017-01-24 17:45:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:19 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:19 --> Total execution time: 0.0147
INFO - 2017-01-24 17:45:30 --> Config Class Initialized
INFO - 2017-01-24 17:45:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:30 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:30 --> URI Class Initialized
INFO - 2017-01-24 17:45:30 --> Router Class Initialized
INFO - 2017-01-24 17:45:30 --> Output Class Initialized
INFO - 2017-01-24 17:45:30 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:30 --> Input Class Initialized
INFO - 2017-01-24 17:45:30 --> Language Class Initialized
INFO - 2017-01-24 17:45:30 --> Loader Class Initialized
INFO - 2017-01-24 17:45:30 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:30 --> Controller Class Initialized
INFO - 2017-01-24 17:45:30 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:30 --> Config Class Initialized
INFO - 2017-01-24 17:45:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:30 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:30 --> URI Class Initialized
INFO - 2017-01-24 17:45:30 --> Router Class Initialized
INFO - 2017-01-24 17:45:30 --> Output Class Initialized
INFO - 2017-01-24 17:45:30 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:30 --> Input Class Initialized
INFO - 2017-01-24 17:45:30 --> Language Class Initialized
INFO - 2017-01-24 17:45:30 --> Loader Class Initialized
INFO - 2017-01-24 17:45:30 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:30 --> Controller Class Initialized
INFO - 2017-01-24 17:45:30 --> Helper loaded: date_helper
DEBUG - 2017-01-24 17:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:30 --> Helper loaded: url_helper
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:30 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:30 --> Total execution time: 0.0222
INFO - 2017-01-24 17:45:30 --> Config Class Initialized
INFO - 2017-01-24 17:45:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:30 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:30 --> URI Class Initialized
INFO - 2017-01-24 17:45:30 --> Router Class Initialized
INFO - 2017-01-24 17:45:30 --> Output Class Initialized
INFO - 2017-01-24 17:45:30 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:30 --> Input Class Initialized
INFO - 2017-01-24 17:45:30 --> Language Class Initialized
INFO - 2017-01-24 17:45:30 --> Loader Class Initialized
INFO - 2017-01-24 17:45:30 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:30 --> Controller Class Initialized
INFO - 2017-01-24 17:45:30 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:30 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:30 --> Total execution time: 0.0141
INFO - 2017-01-24 17:45:33 --> Config Class Initialized
INFO - 2017-01-24 17:45:33 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:33 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:33 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:33 --> URI Class Initialized
DEBUG - 2017-01-24 17:45:33 --> No URI present. Default controller set.
INFO - 2017-01-24 17:45:33 --> Router Class Initialized
INFO - 2017-01-24 17:45:33 --> Output Class Initialized
INFO - 2017-01-24 17:45:33 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:33 --> Input Class Initialized
INFO - 2017-01-24 17:45:33 --> Language Class Initialized
INFO - 2017-01-24 17:45:33 --> Loader Class Initialized
INFO - 2017-01-24 17:45:33 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:33 --> Controller Class Initialized
INFO - 2017-01-24 17:45:33 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:45:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:45:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:33 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:33 --> Total execution time: 0.0153
INFO - 2017-01-24 17:45:34 --> Config Class Initialized
INFO - 2017-01-24 17:45:34 --> Hooks Class Initialized
DEBUG - 2017-01-24 17:45:34 --> UTF-8 Support Enabled
INFO - 2017-01-24 17:45:34 --> Utf8 Class Initialized
INFO - 2017-01-24 17:45:34 --> URI Class Initialized
INFO - 2017-01-24 17:45:34 --> Router Class Initialized
INFO - 2017-01-24 17:45:34 --> Output Class Initialized
INFO - 2017-01-24 17:45:34 --> Security Class Initialized
DEBUG - 2017-01-24 17:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 17:45:34 --> Input Class Initialized
INFO - 2017-01-24 17:45:34 --> Language Class Initialized
INFO - 2017-01-24 17:45:34 --> Loader Class Initialized
INFO - 2017-01-24 17:45:34 --> Database Driver Class Initialized
INFO - 2017-01-24 17:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 17:45:34 --> Controller Class Initialized
INFO - 2017-01-24 17:45:34 --> Helper loaded: url_helper
DEBUG - 2017-01-24 17:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 17:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 17:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 17:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 17:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 17:45:34 --> Final output sent to browser
DEBUG - 2017-01-24 17:45:34 --> Total execution time: 0.0140
INFO - 2017-01-24 19:14:15 --> Config Class Initialized
INFO - 2017-01-24 19:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:14:15 --> Utf8 Class Initialized
INFO - 2017-01-24 19:14:15 --> URI Class Initialized
DEBUG - 2017-01-24 19:14:15 --> No URI present. Default controller set.
INFO - 2017-01-24 19:14:15 --> Router Class Initialized
INFO - 2017-01-24 19:14:15 --> Output Class Initialized
INFO - 2017-01-24 19:14:15 --> Security Class Initialized
DEBUG - 2017-01-24 19:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:14:15 --> Input Class Initialized
INFO - 2017-01-24 19:14:15 --> Language Class Initialized
INFO - 2017-01-24 19:14:15 --> Loader Class Initialized
INFO - 2017-01-24 19:14:15 --> Database Driver Class Initialized
INFO - 2017-01-24 19:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:14:15 --> Controller Class Initialized
INFO - 2017-01-24 19:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:14:15 --> Final output sent to browser
DEBUG - 2017-01-24 19:14:15 --> Total execution time: 0.0902
INFO - 2017-01-24 19:14:19 --> Config Class Initialized
INFO - 2017-01-24 19:14:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:14:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:14:19 --> Utf8 Class Initialized
INFO - 2017-01-24 19:14:19 --> URI Class Initialized
INFO - 2017-01-24 19:14:19 --> Router Class Initialized
INFO - 2017-01-24 19:14:19 --> Output Class Initialized
INFO - 2017-01-24 19:14:19 --> Security Class Initialized
DEBUG - 2017-01-24 19:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:14:19 --> Input Class Initialized
INFO - 2017-01-24 19:14:19 --> Language Class Initialized
INFO - 2017-01-24 19:14:19 --> Loader Class Initialized
INFO - 2017-01-24 19:14:19 --> Database Driver Class Initialized
INFO - 2017-01-24 19:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:14:19 --> Controller Class Initialized
INFO - 2017-01-24 19:14:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:14:19 --> Final output sent to browser
DEBUG - 2017-01-24 19:14:19 --> Total execution time: 0.0530
INFO - 2017-01-24 19:14:23 --> Config Class Initialized
INFO - 2017-01-24 19:14:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:14:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:14:23 --> Utf8 Class Initialized
INFO - 2017-01-24 19:14:23 --> URI Class Initialized
INFO - 2017-01-24 19:14:23 --> Router Class Initialized
INFO - 2017-01-24 19:14:23 --> Output Class Initialized
INFO - 2017-01-24 19:14:23 --> Security Class Initialized
DEBUG - 2017-01-24 19:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:14:23 --> Input Class Initialized
INFO - 2017-01-24 19:14:23 --> Language Class Initialized
INFO - 2017-01-24 19:14:23 --> Loader Class Initialized
INFO - 2017-01-24 19:14:23 --> Database Driver Class Initialized
INFO - 2017-01-24 19:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:14:23 --> Controller Class Initialized
INFO - 2017-01-24 19:14:23 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:14:25 --> Config Class Initialized
INFO - 2017-01-24 19:14:25 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:14:25 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:14:25 --> Utf8 Class Initialized
INFO - 2017-01-24 19:14:25 --> URI Class Initialized
INFO - 2017-01-24 19:14:25 --> Router Class Initialized
INFO - 2017-01-24 19:14:25 --> Output Class Initialized
INFO - 2017-01-24 19:14:25 --> Security Class Initialized
DEBUG - 2017-01-24 19:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:14:25 --> Input Class Initialized
INFO - 2017-01-24 19:14:25 --> Language Class Initialized
INFO - 2017-01-24 19:14:25 --> Loader Class Initialized
INFO - 2017-01-24 19:14:25 --> Database Driver Class Initialized
INFO - 2017-01-24 19:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:14:25 --> Controller Class Initialized
INFO - 2017-01-24 19:14:25 --> Helper loaded: date_helper
DEBUG - 2017-01-24 19:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:14:25 --> Helper loaded: url_helper
INFO - 2017-01-24 19:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 19:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 19:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 19:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:14:25 --> Final output sent to browser
DEBUG - 2017-01-24 19:14:25 --> Total execution time: 0.0398
INFO - 2017-01-24 19:14:26 --> Config Class Initialized
INFO - 2017-01-24 19:14:26 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:14:26 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:14:26 --> Utf8 Class Initialized
INFO - 2017-01-24 19:14:26 --> URI Class Initialized
INFO - 2017-01-24 19:14:26 --> Router Class Initialized
INFO - 2017-01-24 19:14:26 --> Output Class Initialized
INFO - 2017-01-24 19:14:26 --> Security Class Initialized
DEBUG - 2017-01-24 19:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:14:26 --> Input Class Initialized
INFO - 2017-01-24 19:14:26 --> Language Class Initialized
INFO - 2017-01-24 19:14:26 --> Loader Class Initialized
INFO - 2017-01-24 19:14:26 --> Database Driver Class Initialized
INFO - 2017-01-24 19:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:14:26 --> Controller Class Initialized
INFO - 2017-01-24 19:14:26 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:14:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:14:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:14:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:14:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:14:26 --> Final output sent to browser
DEBUG - 2017-01-24 19:14:26 --> Total execution time: 0.0145
INFO - 2017-01-24 19:22:40 --> Config Class Initialized
INFO - 2017-01-24 19:22:40 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:22:40 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:22:40 --> Utf8 Class Initialized
INFO - 2017-01-24 19:22:40 --> URI Class Initialized
DEBUG - 2017-01-24 19:22:40 --> No URI present. Default controller set.
INFO - 2017-01-24 19:22:40 --> Router Class Initialized
INFO - 2017-01-24 19:22:40 --> Output Class Initialized
INFO - 2017-01-24 19:22:40 --> Security Class Initialized
DEBUG - 2017-01-24 19:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:22:40 --> Input Class Initialized
INFO - 2017-01-24 19:22:40 --> Language Class Initialized
INFO - 2017-01-24 19:22:40 --> Loader Class Initialized
INFO - 2017-01-24 19:22:40 --> Database Driver Class Initialized
INFO - 2017-01-24 19:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:22:40 --> Controller Class Initialized
INFO - 2017-01-24 19:22:40 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:22:40 --> Final output sent to browser
DEBUG - 2017-01-24 19:22:40 --> Total execution time: 0.0308
INFO - 2017-01-24 19:22:49 --> Config Class Initialized
INFO - 2017-01-24 19:22:49 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:22:49 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:22:49 --> Utf8 Class Initialized
INFO - 2017-01-24 19:22:49 --> URI Class Initialized
INFO - 2017-01-24 19:22:49 --> Router Class Initialized
INFO - 2017-01-24 19:22:49 --> Output Class Initialized
INFO - 2017-01-24 19:22:49 --> Security Class Initialized
DEBUG - 2017-01-24 19:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:22:49 --> Input Class Initialized
INFO - 2017-01-24 19:22:49 --> Language Class Initialized
INFO - 2017-01-24 19:22:49 --> Loader Class Initialized
INFO - 2017-01-24 19:22:49 --> Database Driver Class Initialized
INFO - 2017-01-24 19:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:22:49 --> Controller Class Initialized
INFO - 2017-01-24 19:22:49 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:22:49 --> Final output sent to browser
DEBUG - 2017-01-24 19:22:49 --> Total execution time: 0.0145
INFO - 2017-01-24 19:23:17 --> Config Class Initialized
INFO - 2017-01-24 19:23:17 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:23:17 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:23:17 --> Utf8 Class Initialized
INFO - 2017-01-24 19:23:17 --> URI Class Initialized
DEBUG - 2017-01-24 19:23:17 --> No URI present. Default controller set.
INFO - 2017-01-24 19:23:17 --> Router Class Initialized
INFO - 2017-01-24 19:23:17 --> Output Class Initialized
INFO - 2017-01-24 19:23:17 --> Security Class Initialized
DEBUG - 2017-01-24 19:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:23:17 --> Input Class Initialized
INFO - 2017-01-24 19:23:17 --> Language Class Initialized
INFO - 2017-01-24 19:23:17 --> Loader Class Initialized
INFO - 2017-01-24 19:23:17 --> Database Driver Class Initialized
INFO - 2017-01-24 19:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:23:17 --> Controller Class Initialized
INFO - 2017-01-24 19:23:17 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:23:17 --> Final output sent to browser
DEBUG - 2017-01-24 19:23:17 --> Total execution time: 0.0151
INFO - 2017-01-24 19:23:27 --> Config Class Initialized
INFO - 2017-01-24 19:23:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:23:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:23:27 --> Utf8 Class Initialized
INFO - 2017-01-24 19:23:27 --> URI Class Initialized
INFO - 2017-01-24 19:23:27 --> Router Class Initialized
INFO - 2017-01-24 19:23:27 --> Output Class Initialized
INFO - 2017-01-24 19:23:27 --> Security Class Initialized
DEBUG - 2017-01-24 19:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:23:27 --> Input Class Initialized
INFO - 2017-01-24 19:23:27 --> Language Class Initialized
INFO - 2017-01-24 19:23:27 --> Loader Class Initialized
INFO - 2017-01-24 19:23:27 --> Database Driver Class Initialized
INFO - 2017-01-24 19:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:23:27 --> Controller Class Initialized
INFO - 2017-01-24 19:23:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:23:27 --> Final output sent to browser
DEBUG - 2017-01-24 19:23:27 --> Total execution time: 0.0309
INFO - 2017-01-24 19:24:17 --> Config Class Initialized
INFO - 2017-01-24 19:24:17 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:24:17 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:24:17 --> Utf8 Class Initialized
INFO - 2017-01-24 19:24:17 --> URI Class Initialized
INFO - 2017-01-24 19:24:17 --> Router Class Initialized
INFO - 2017-01-24 19:24:17 --> Output Class Initialized
INFO - 2017-01-24 19:24:17 --> Security Class Initialized
DEBUG - 2017-01-24 19:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:24:17 --> Input Class Initialized
INFO - 2017-01-24 19:24:17 --> Language Class Initialized
INFO - 2017-01-24 19:24:17 --> Loader Class Initialized
INFO - 2017-01-24 19:24:17 --> Database Driver Class Initialized
INFO - 2017-01-24 19:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:24:17 --> Controller Class Initialized
INFO - 2017-01-24 19:24:17 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:24:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 19:24:18 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 19:24:18 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Susana Casas')
INFO - 2017-01-24 19:24:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 19:24:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 19:24:19 --> Config Class Initialized
INFO - 2017-01-24 19:24:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:24:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:24:19 --> Utf8 Class Initialized
INFO - 2017-01-24 19:24:19 --> URI Class Initialized
INFO - 2017-01-24 19:24:19 --> Router Class Initialized
INFO - 2017-01-24 19:24:19 --> Output Class Initialized
INFO - 2017-01-24 19:24:19 --> Security Class Initialized
DEBUG - 2017-01-24 19:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:24:19 --> Input Class Initialized
INFO - 2017-01-24 19:24:19 --> Language Class Initialized
INFO - 2017-01-24 19:24:19 --> Loader Class Initialized
INFO - 2017-01-24 19:24:19 --> Database Driver Class Initialized
INFO - 2017-01-24 19:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:24:19 --> Controller Class Initialized
INFO - 2017-01-24 19:24:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:24:19 --> Final output sent to browser
DEBUG - 2017-01-24 19:24:19 --> Total execution time: 0.0143
INFO - 2017-01-24 19:24:47 --> Config Class Initialized
INFO - 2017-01-24 19:24:47 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:24:47 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:24:47 --> Utf8 Class Initialized
INFO - 2017-01-24 19:24:47 --> URI Class Initialized
DEBUG - 2017-01-24 19:24:47 --> No URI present. Default controller set.
INFO - 2017-01-24 19:24:47 --> Router Class Initialized
INFO - 2017-01-24 19:24:47 --> Output Class Initialized
INFO - 2017-01-24 19:24:47 --> Security Class Initialized
DEBUG - 2017-01-24 19:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:24:47 --> Input Class Initialized
INFO - 2017-01-24 19:24:47 --> Language Class Initialized
INFO - 2017-01-24 19:24:47 --> Loader Class Initialized
INFO - 2017-01-24 19:24:47 --> Database Driver Class Initialized
INFO - 2017-01-24 19:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:24:47 --> Controller Class Initialized
INFO - 2017-01-24 19:24:47 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:24:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:24:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:24:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:24:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:24:47 --> Final output sent to browser
DEBUG - 2017-01-24 19:24:47 --> Total execution time: 0.0146
INFO - 2017-01-24 19:24:50 --> Config Class Initialized
INFO - 2017-01-24 19:24:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:24:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:24:50 --> Utf8 Class Initialized
INFO - 2017-01-24 19:24:50 --> URI Class Initialized
DEBUG - 2017-01-24 19:24:50 --> No URI present. Default controller set.
INFO - 2017-01-24 19:24:50 --> Router Class Initialized
INFO - 2017-01-24 19:24:50 --> Output Class Initialized
INFO - 2017-01-24 19:24:50 --> Security Class Initialized
DEBUG - 2017-01-24 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:24:50 --> Input Class Initialized
INFO - 2017-01-24 19:24:50 --> Language Class Initialized
INFO - 2017-01-24 19:24:50 --> Loader Class Initialized
INFO - 2017-01-24 19:24:50 --> Database Driver Class Initialized
INFO - 2017-01-24 19:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:24:50 --> Controller Class Initialized
INFO - 2017-01-24 19:24:50 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:24:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:24:51 --> Final output sent to browser
DEBUG - 2017-01-24 19:24:51 --> Total execution time: 0.0559
INFO - 2017-01-24 19:24:54 --> Config Class Initialized
INFO - 2017-01-24 19:24:54 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:24:54 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:24:54 --> Utf8 Class Initialized
INFO - 2017-01-24 19:24:54 --> URI Class Initialized
INFO - 2017-01-24 19:24:54 --> Router Class Initialized
INFO - 2017-01-24 19:24:54 --> Output Class Initialized
INFO - 2017-01-24 19:24:54 --> Security Class Initialized
DEBUG - 2017-01-24 19:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:24:54 --> Input Class Initialized
INFO - 2017-01-24 19:24:54 --> Language Class Initialized
INFO - 2017-01-24 19:24:54 --> Loader Class Initialized
INFO - 2017-01-24 19:24:55 --> Database Driver Class Initialized
INFO - 2017-01-24 19:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:24:55 --> Controller Class Initialized
INFO - 2017-01-24 19:24:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:24:55 --> Final output sent to browser
DEBUG - 2017-01-24 19:24:55 --> Total execution time: 0.0148
INFO - 2017-01-24 19:24:55 --> Config Class Initialized
INFO - 2017-01-24 19:24:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:24:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:24:55 --> Utf8 Class Initialized
INFO - 2017-01-24 19:24:55 --> URI Class Initialized
INFO - 2017-01-24 19:24:55 --> Router Class Initialized
INFO - 2017-01-24 19:24:55 --> Output Class Initialized
INFO - 2017-01-24 19:24:55 --> Security Class Initialized
DEBUG - 2017-01-24 19:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:24:55 --> Input Class Initialized
INFO - 2017-01-24 19:24:55 --> Language Class Initialized
INFO - 2017-01-24 19:24:55 --> Loader Class Initialized
INFO - 2017-01-24 19:24:55 --> Database Driver Class Initialized
INFO - 2017-01-24 19:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:24:55 --> Controller Class Initialized
INFO - 2017-01-24 19:24:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:24:55 --> Final output sent to browser
DEBUG - 2017-01-24 19:24:55 --> Total execution time: 0.0139
INFO - 2017-01-24 19:25:25 --> Config Class Initialized
INFO - 2017-01-24 19:25:25 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:25 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:25 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:25 --> URI Class Initialized
INFO - 2017-01-24 19:25:25 --> Router Class Initialized
INFO - 2017-01-24 19:25:25 --> Output Class Initialized
INFO - 2017-01-24 19:25:25 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:25 --> Input Class Initialized
INFO - 2017-01-24 19:25:25 --> Language Class Initialized
INFO - 2017-01-24 19:25:25 --> Loader Class Initialized
INFO - 2017-01-24 19:25:25 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:25 --> Controller Class Initialized
INFO - 2017-01-24 19:25:25 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:27 --> Config Class Initialized
INFO - 2017-01-24 19:25:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:27 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:27 --> URI Class Initialized
INFO - 2017-01-24 19:25:27 --> Router Class Initialized
INFO - 2017-01-24 19:25:27 --> Output Class Initialized
INFO - 2017-01-24 19:25:27 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:27 --> Input Class Initialized
INFO - 2017-01-24 19:25:27 --> Language Class Initialized
INFO - 2017-01-24 19:25:27 --> Loader Class Initialized
INFO - 2017-01-24 19:25:27 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:27 --> Controller Class Initialized
INFO - 2017-01-24 19:25:27 --> Helper loaded: date_helper
DEBUG - 2017-01-24 19:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:27 --> Helper loaded: url_helper
INFO - 2017-01-24 19:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 19:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 19:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 19:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:27 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:27 --> Total execution time: 0.1172
INFO - 2017-01-24 19:25:28 --> Config Class Initialized
INFO - 2017-01-24 19:25:28 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:28 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:28 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:28 --> URI Class Initialized
INFO - 2017-01-24 19:25:28 --> Router Class Initialized
INFO - 2017-01-24 19:25:28 --> Output Class Initialized
INFO - 2017-01-24 19:25:28 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:28 --> Input Class Initialized
INFO - 2017-01-24 19:25:28 --> Language Class Initialized
INFO - 2017-01-24 19:25:28 --> Loader Class Initialized
INFO - 2017-01-24 19:25:28 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:28 --> Controller Class Initialized
INFO - 2017-01-24 19:25:28 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:28 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:28 --> Total execution time: 0.0151
INFO - 2017-01-24 19:25:32 --> Config Class Initialized
INFO - 2017-01-24 19:25:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:32 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:32 --> URI Class Initialized
DEBUG - 2017-01-24 19:25:32 --> No URI present. Default controller set.
INFO - 2017-01-24 19:25:32 --> Router Class Initialized
INFO - 2017-01-24 19:25:32 --> Output Class Initialized
INFO - 2017-01-24 19:25:32 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:32 --> Input Class Initialized
INFO - 2017-01-24 19:25:32 --> Language Class Initialized
INFO - 2017-01-24 19:25:32 --> Loader Class Initialized
INFO - 2017-01-24 19:25:32 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:32 --> Controller Class Initialized
INFO - 2017-01-24 19:25:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:25:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:25:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:32 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:32 --> Total execution time: 0.0152
INFO - 2017-01-24 19:25:34 --> Config Class Initialized
INFO - 2017-01-24 19:25:34 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:34 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:34 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:34 --> URI Class Initialized
INFO - 2017-01-24 19:25:34 --> Router Class Initialized
INFO - 2017-01-24 19:25:34 --> Output Class Initialized
INFO - 2017-01-24 19:25:34 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:34 --> Input Class Initialized
INFO - 2017-01-24 19:25:34 --> Language Class Initialized
INFO - 2017-01-24 19:25:34 --> Loader Class Initialized
INFO - 2017-01-24 19:25:34 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:34 --> Controller Class Initialized
INFO - 2017-01-24 19:25:34 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:34 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:34 --> Total execution time: 0.0141
INFO - 2017-01-24 19:25:37 --> Config Class Initialized
INFO - 2017-01-24 19:25:37 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:37 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:37 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:37 --> URI Class Initialized
INFO - 2017-01-24 19:25:37 --> Router Class Initialized
INFO - 2017-01-24 19:25:37 --> Output Class Initialized
INFO - 2017-01-24 19:25:37 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:37 --> Input Class Initialized
INFO - 2017-01-24 19:25:37 --> Language Class Initialized
INFO - 2017-01-24 19:25:37 --> Loader Class Initialized
INFO - 2017-01-24 19:25:37 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:37 --> Controller Class Initialized
INFO - 2017-01-24 19:25:37 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:39 --> Config Class Initialized
INFO - 2017-01-24 19:25:39 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:39 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:39 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:39 --> URI Class Initialized
INFO - 2017-01-24 19:25:39 --> Router Class Initialized
INFO - 2017-01-24 19:25:39 --> Output Class Initialized
INFO - 2017-01-24 19:25:39 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:39 --> Input Class Initialized
INFO - 2017-01-24 19:25:39 --> Language Class Initialized
INFO - 2017-01-24 19:25:39 --> Loader Class Initialized
INFO - 2017-01-24 19:25:39 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:39 --> Controller Class Initialized
INFO - 2017-01-24 19:25:39 --> Helper loaded: date_helper
DEBUG - 2017-01-24 19:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:39 --> Helper loaded: url_helper
INFO - 2017-01-24 19:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 19:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 19:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 19:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:39 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:39 --> Total execution time: 0.0147
INFO - 2017-01-24 19:25:40 --> Config Class Initialized
INFO - 2017-01-24 19:25:40 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:40 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:40 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:40 --> URI Class Initialized
INFO - 2017-01-24 19:25:40 --> Router Class Initialized
INFO - 2017-01-24 19:25:40 --> Output Class Initialized
INFO - 2017-01-24 19:25:40 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:40 --> Input Class Initialized
INFO - 2017-01-24 19:25:40 --> Language Class Initialized
INFO - 2017-01-24 19:25:40 --> Loader Class Initialized
INFO - 2017-01-24 19:25:40 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:40 --> Controller Class Initialized
INFO - 2017-01-24 19:25:40 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:40 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:40 --> Total execution time: 0.0136
INFO - 2017-01-24 19:25:45 --> Config Class Initialized
INFO - 2017-01-24 19:25:45 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:45 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:45 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:45 --> URI Class Initialized
INFO - 2017-01-24 19:25:45 --> Router Class Initialized
INFO - 2017-01-24 19:25:45 --> Output Class Initialized
INFO - 2017-01-24 19:25:45 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:45 --> Input Class Initialized
INFO - 2017-01-24 19:25:45 --> Language Class Initialized
INFO - 2017-01-24 19:25:45 --> Loader Class Initialized
INFO - 2017-01-24 19:25:45 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:45 --> Controller Class Initialized
INFO - 2017-01-24 19:25:45 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:47 --> Config Class Initialized
INFO - 2017-01-24 19:25:47 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:47 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:47 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:47 --> URI Class Initialized
INFO - 2017-01-24 19:25:47 --> Router Class Initialized
INFO - 2017-01-24 19:25:47 --> Output Class Initialized
INFO - 2017-01-24 19:25:47 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:47 --> Input Class Initialized
INFO - 2017-01-24 19:25:47 --> Language Class Initialized
INFO - 2017-01-24 19:25:47 --> Loader Class Initialized
INFO - 2017-01-24 19:25:47 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:47 --> Controller Class Initialized
INFO - 2017-01-24 19:25:47 --> Helper loaded: date_helper
DEBUG - 2017-01-24 19:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:47 --> Helper loaded: url_helper
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:47 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:47 --> Total execution time: 0.0225
INFO - 2017-01-24 19:25:47 --> Config Class Initialized
INFO - 2017-01-24 19:25:47 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:47 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:47 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:47 --> URI Class Initialized
INFO - 2017-01-24 19:25:47 --> Router Class Initialized
INFO - 2017-01-24 19:25:47 --> Output Class Initialized
INFO - 2017-01-24 19:25:47 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:47 --> Input Class Initialized
INFO - 2017-01-24 19:25:47 --> Language Class Initialized
INFO - 2017-01-24 19:25:47 --> Loader Class Initialized
INFO - 2017-01-24 19:25:47 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:47 --> Controller Class Initialized
INFO - 2017-01-24 19:25:47 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:47 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:47 --> Total execution time: 0.0147
INFO - 2017-01-24 19:25:58 --> Config Class Initialized
INFO - 2017-01-24 19:25:58 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:25:58 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:25:58 --> Utf8 Class Initialized
INFO - 2017-01-24 19:25:58 --> URI Class Initialized
DEBUG - 2017-01-24 19:25:58 --> No URI present. Default controller set.
INFO - 2017-01-24 19:25:58 --> Router Class Initialized
INFO - 2017-01-24 19:25:58 --> Output Class Initialized
INFO - 2017-01-24 19:25:58 --> Security Class Initialized
DEBUG - 2017-01-24 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:25:58 --> Input Class Initialized
INFO - 2017-01-24 19:25:58 --> Language Class Initialized
INFO - 2017-01-24 19:25:58 --> Loader Class Initialized
INFO - 2017-01-24 19:25:58 --> Database Driver Class Initialized
INFO - 2017-01-24 19:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:25:58 --> Controller Class Initialized
INFO - 2017-01-24 19:25:58 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:25:58 --> Final output sent to browser
DEBUG - 2017-01-24 19:25:58 --> Total execution time: 0.0143
INFO - 2017-01-24 19:26:03 --> Config Class Initialized
INFO - 2017-01-24 19:26:03 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:26:03 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:26:03 --> Utf8 Class Initialized
INFO - 2017-01-24 19:26:03 --> URI Class Initialized
INFO - 2017-01-24 19:26:03 --> Router Class Initialized
INFO - 2017-01-24 19:26:03 --> Output Class Initialized
INFO - 2017-01-24 19:26:03 --> Security Class Initialized
DEBUG - 2017-01-24 19:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:26:03 --> Input Class Initialized
INFO - 2017-01-24 19:26:03 --> Language Class Initialized
INFO - 2017-01-24 19:26:03 --> Loader Class Initialized
INFO - 2017-01-24 19:26:03 --> Database Driver Class Initialized
INFO - 2017-01-24 19:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:26:03 --> Controller Class Initialized
INFO - 2017-01-24 19:26:03 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:26:03 --> Final output sent to browser
DEBUG - 2017-01-24 19:26:03 --> Total execution time: 0.0469
INFO - 2017-01-24 19:26:27 --> Config Class Initialized
INFO - 2017-01-24 19:26:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:26:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:26:27 --> Utf8 Class Initialized
INFO - 2017-01-24 19:26:27 --> URI Class Initialized
INFO - 2017-01-24 19:26:27 --> Router Class Initialized
INFO - 2017-01-24 19:26:27 --> Output Class Initialized
INFO - 2017-01-24 19:26:27 --> Security Class Initialized
DEBUG - 2017-01-24 19:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:26:27 --> Input Class Initialized
INFO - 2017-01-24 19:26:27 --> Language Class Initialized
INFO - 2017-01-24 19:26:27 --> Loader Class Initialized
INFO - 2017-01-24 19:26:27 --> Database Driver Class Initialized
INFO - 2017-01-24 19:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:26:27 --> Controller Class Initialized
INFO - 2017-01-24 19:26:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:26:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-24 19:26:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-24 19:26:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-24 19:26:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-24 19:26:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:26:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:26:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:26:27 --> Final output sent to browser
DEBUG - 2017-01-24 19:26:27 --> Total execution time: 0.0274
INFO - 2017-01-24 19:26:29 --> Config Class Initialized
INFO - 2017-01-24 19:26:29 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:26:29 --> Utf8 Class Initialized
INFO - 2017-01-24 19:26:29 --> URI Class Initialized
INFO - 2017-01-24 19:26:29 --> Router Class Initialized
INFO - 2017-01-24 19:26:29 --> Output Class Initialized
INFO - 2017-01-24 19:26:29 --> Security Class Initialized
DEBUG - 2017-01-24 19:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:26:29 --> Input Class Initialized
INFO - 2017-01-24 19:26:29 --> Language Class Initialized
INFO - 2017-01-24 19:26:29 --> Loader Class Initialized
INFO - 2017-01-24 19:26:29 --> Database Driver Class Initialized
INFO - 2017-01-24 19:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:26:29 --> Controller Class Initialized
INFO - 2017-01-24 19:26:29 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:26:29 --> Final output sent to browser
DEBUG - 2017-01-24 19:26:29 --> Total execution time: 0.0242
INFO - 2017-01-24 19:26:48 --> Config Class Initialized
INFO - 2017-01-24 19:26:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:26:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:26:48 --> Utf8 Class Initialized
INFO - 2017-01-24 19:26:48 --> URI Class Initialized
DEBUG - 2017-01-24 19:26:48 --> No URI present. Default controller set.
INFO - 2017-01-24 19:26:48 --> Router Class Initialized
INFO - 2017-01-24 19:26:48 --> Output Class Initialized
INFO - 2017-01-24 19:26:48 --> Security Class Initialized
DEBUG - 2017-01-24 19:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:26:48 --> Input Class Initialized
INFO - 2017-01-24 19:26:48 --> Language Class Initialized
INFO - 2017-01-24 19:26:48 --> Loader Class Initialized
INFO - 2017-01-24 19:26:48 --> Database Driver Class Initialized
INFO - 2017-01-24 19:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:26:48 --> Controller Class Initialized
INFO - 2017-01-24 19:26:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:26:48 --> Final output sent to browser
DEBUG - 2017-01-24 19:26:48 --> Total execution time: 0.0240
INFO - 2017-01-24 19:26:50 --> Config Class Initialized
INFO - 2017-01-24 19:26:50 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:26:50 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:26:50 --> Utf8 Class Initialized
INFO - 2017-01-24 19:26:50 --> URI Class Initialized
INFO - 2017-01-24 19:26:50 --> Router Class Initialized
INFO - 2017-01-24 19:26:50 --> Output Class Initialized
INFO - 2017-01-24 19:26:50 --> Security Class Initialized
DEBUG - 2017-01-24 19:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:26:50 --> Input Class Initialized
INFO - 2017-01-24 19:26:50 --> Language Class Initialized
INFO - 2017-01-24 19:26:50 --> Loader Class Initialized
INFO - 2017-01-24 19:26:50 --> Database Driver Class Initialized
INFO - 2017-01-24 19:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:26:50 --> Controller Class Initialized
INFO - 2017-01-24 19:26:50 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:26:50 --> Final output sent to browser
DEBUG - 2017-01-24 19:26:50 --> Total execution time: 0.0229
INFO - 2017-01-24 19:28:27 --> Config Class Initialized
INFO - 2017-01-24 19:28:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:28:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:28:27 --> Utf8 Class Initialized
INFO - 2017-01-24 19:28:27 --> URI Class Initialized
INFO - 2017-01-24 19:28:27 --> Router Class Initialized
INFO - 2017-01-24 19:28:27 --> Output Class Initialized
INFO - 2017-01-24 19:28:27 --> Security Class Initialized
DEBUG - 2017-01-24 19:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:28:27 --> Input Class Initialized
INFO - 2017-01-24 19:28:27 --> Language Class Initialized
INFO - 2017-01-24 19:28:27 --> Loader Class Initialized
INFO - 2017-01-24 19:28:27 --> Database Driver Class Initialized
INFO - 2017-01-24 19:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:28:27 --> Controller Class Initialized
INFO - 2017-01-24 19:28:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:28:27 --> Final output sent to browser
DEBUG - 2017-01-24 19:28:27 --> Total execution time: 0.0346
INFO - 2017-01-24 19:28:38 --> Config Class Initialized
INFO - 2017-01-24 19:28:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:28:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:28:38 --> Utf8 Class Initialized
INFO - 2017-01-24 19:28:38 --> URI Class Initialized
INFO - 2017-01-24 19:28:38 --> Router Class Initialized
INFO - 2017-01-24 19:28:38 --> Output Class Initialized
INFO - 2017-01-24 19:28:38 --> Security Class Initialized
DEBUG - 2017-01-24 19:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:28:38 --> Input Class Initialized
INFO - 2017-01-24 19:28:38 --> Language Class Initialized
INFO - 2017-01-24 19:28:38 --> Loader Class Initialized
INFO - 2017-01-24 19:28:38 --> Database Driver Class Initialized
INFO - 2017-01-24 19:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:28:38 --> Controller Class Initialized
INFO - 2017-01-24 19:28:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:28:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 19:28:39 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 19:28:39 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Zuleima Esparza Martínez')
INFO - 2017-01-24 19:28:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 19:28:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 19:28:40 --> Config Class Initialized
INFO - 2017-01-24 19:28:40 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:28:40 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:28:40 --> Utf8 Class Initialized
INFO - 2017-01-24 19:28:40 --> URI Class Initialized
INFO - 2017-01-24 19:28:40 --> Router Class Initialized
INFO - 2017-01-24 19:28:40 --> Output Class Initialized
INFO - 2017-01-24 19:28:40 --> Security Class Initialized
DEBUG - 2017-01-24 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:28:40 --> Input Class Initialized
INFO - 2017-01-24 19:28:40 --> Language Class Initialized
INFO - 2017-01-24 19:28:40 --> Loader Class Initialized
INFO - 2017-01-24 19:28:40 --> Database Driver Class Initialized
INFO - 2017-01-24 19:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:28:40 --> Controller Class Initialized
INFO - 2017-01-24 19:28:40 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:28:40 --> Final output sent to browser
DEBUG - 2017-01-24 19:28:40 --> Total execution time: 0.0480
INFO - 2017-01-24 19:36:19 --> Config Class Initialized
INFO - 2017-01-24 19:36:20 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:36:20 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:36:20 --> Utf8 Class Initialized
INFO - 2017-01-24 19:36:20 --> URI Class Initialized
DEBUG - 2017-01-24 19:36:20 --> No URI present. Default controller set.
INFO - 2017-01-24 19:36:20 --> Router Class Initialized
INFO - 2017-01-24 19:36:20 --> Output Class Initialized
INFO - 2017-01-24 19:36:20 --> Security Class Initialized
DEBUG - 2017-01-24 19:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:36:20 --> Input Class Initialized
INFO - 2017-01-24 19:36:20 --> Language Class Initialized
INFO - 2017-01-24 19:36:20 --> Loader Class Initialized
INFO - 2017-01-24 19:36:20 --> Database Driver Class Initialized
INFO - 2017-01-24 19:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:36:20 --> Controller Class Initialized
INFO - 2017-01-24 19:36:20 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:36:20 --> Final output sent to browser
DEBUG - 2017-01-24 19:36:20 --> Total execution time: 0.1411
INFO - 2017-01-24 19:36:24 --> Config Class Initialized
INFO - 2017-01-24 19:36:24 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:36:24 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:36:24 --> Utf8 Class Initialized
INFO - 2017-01-24 19:36:24 --> URI Class Initialized
INFO - 2017-01-24 19:36:24 --> Router Class Initialized
INFO - 2017-01-24 19:36:24 --> Output Class Initialized
INFO - 2017-01-24 19:36:24 --> Security Class Initialized
DEBUG - 2017-01-24 19:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:36:24 --> Input Class Initialized
INFO - 2017-01-24 19:36:24 --> Language Class Initialized
INFO - 2017-01-24 19:36:24 --> Loader Class Initialized
INFO - 2017-01-24 19:36:24 --> Database Driver Class Initialized
INFO - 2017-01-24 19:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:36:24 --> Controller Class Initialized
INFO - 2017-01-24 19:36:24 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:36:24 --> Final output sent to browser
DEBUG - 2017-01-24 19:36:24 --> Total execution time: 0.0172
INFO - 2017-01-24 19:38:28 --> Config Class Initialized
INFO - 2017-01-24 19:38:28 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:38:28 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:38:28 --> Utf8 Class Initialized
INFO - 2017-01-24 19:38:28 --> URI Class Initialized
INFO - 2017-01-24 19:38:28 --> Router Class Initialized
INFO - 2017-01-24 19:38:28 --> Output Class Initialized
INFO - 2017-01-24 19:38:28 --> Security Class Initialized
DEBUG - 2017-01-24 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:38:28 --> Input Class Initialized
INFO - 2017-01-24 19:38:28 --> Language Class Initialized
INFO - 2017-01-24 19:38:28 --> Loader Class Initialized
INFO - 2017-01-24 19:38:28 --> Database Driver Class Initialized
INFO - 2017-01-24 19:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:38:28 --> Controller Class Initialized
INFO - 2017-01-24 19:38:28 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:38:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 19:38:30 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 19:38:30 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-01-24 19:38:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 19:38:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 19:38:30 --> Config Class Initialized
INFO - 2017-01-24 19:38:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:38:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:38:30 --> Utf8 Class Initialized
INFO - 2017-01-24 19:38:30 --> URI Class Initialized
INFO - 2017-01-24 19:38:30 --> Router Class Initialized
INFO - 2017-01-24 19:38:30 --> Output Class Initialized
INFO - 2017-01-24 19:38:30 --> Security Class Initialized
DEBUG - 2017-01-24 19:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:38:30 --> Input Class Initialized
INFO - 2017-01-24 19:38:30 --> Language Class Initialized
INFO - 2017-01-24 19:38:30 --> Loader Class Initialized
INFO - 2017-01-24 19:38:30 --> Database Driver Class Initialized
INFO - 2017-01-24 19:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:38:30 --> Controller Class Initialized
INFO - 2017-01-24 19:38:30 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:38:30 --> Final output sent to browser
DEBUG - 2017-01-24 19:38:30 --> Total execution time: 0.0142
INFO - 2017-01-24 19:38:38 --> Config Class Initialized
INFO - 2017-01-24 19:38:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:38:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:38:38 --> Utf8 Class Initialized
INFO - 2017-01-24 19:38:38 --> URI Class Initialized
DEBUG - 2017-01-24 19:38:38 --> No URI present. Default controller set.
INFO - 2017-01-24 19:38:38 --> Router Class Initialized
INFO - 2017-01-24 19:38:38 --> Output Class Initialized
INFO - 2017-01-24 19:38:38 --> Security Class Initialized
DEBUG - 2017-01-24 19:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:38:38 --> Input Class Initialized
INFO - 2017-01-24 19:38:38 --> Language Class Initialized
INFO - 2017-01-24 19:38:38 --> Loader Class Initialized
INFO - 2017-01-24 19:38:38 --> Database Driver Class Initialized
INFO - 2017-01-24 19:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:38:38 --> Controller Class Initialized
INFO - 2017-01-24 19:38:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:38:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:38:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:38:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:38:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:38:38 --> Final output sent to browser
DEBUG - 2017-01-24 19:38:38 --> Total execution time: 0.0142
INFO - 2017-01-24 19:38:39 --> Config Class Initialized
INFO - 2017-01-24 19:38:39 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:38:39 --> Utf8 Class Initialized
INFO - 2017-01-24 19:38:39 --> URI Class Initialized
INFO - 2017-01-24 19:38:39 --> Router Class Initialized
INFO - 2017-01-24 19:38:39 --> Output Class Initialized
INFO - 2017-01-24 19:38:39 --> Security Class Initialized
DEBUG - 2017-01-24 19:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:38:39 --> Input Class Initialized
INFO - 2017-01-24 19:38:39 --> Language Class Initialized
INFO - 2017-01-24 19:38:39 --> Loader Class Initialized
INFO - 2017-01-24 19:38:39 --> Database Driver Class Initialized
INFO - 2017-01-24 19:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:38:39 --> Controller Class Initialized
INFO - 2017-01-24 19:38:39 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:38:39 --> Final output sent to browser
DEBUG - 2017-01-24 19:38:39 --> Total execution time: 0.0397
INFO - 2017-01-24 19:38:47 --> Config Class Initialized
INFO - 2017-01-24 19:38:47 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:38:47 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:38:47 --> Utf8 Class Initialized
INFO - 2017-01-24 19:38:47 --> URI Class Initialized
INFO - 2017-01-24 19:38:47 --> Router Class Initialized
INFO - 2017-01-24 19:38:47 --> Output Class Initialized
INFO - 2017-01-24 19:38:47 --> Security Class Initialized
DEBUG - 2017-01-24 19:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:38:47 --> Input Class Initialized
INFO - 2017-01-24 19:38:47 --> Language Class Initialized
INFO - 2017-01-24 19:38:47 --> Loader Class Initialized
INFO - 2017-01-24 19:38:47 --> Database Driver Class Initialized
INFO - 2017-01-24 19:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:38:47 --> Controller Class Initialized
INFO - 2017-01-24 19:38:47 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:38:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-24 19:38:48 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-24 19:38:48 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-01-24 19:38:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-24 19:38:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-24 19:38:48 --> Config Class Initialized
INFO - 2017-01-24 19:38:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:38:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:38:48 --> Utf8 Class Initialized
INFO - 2017-01-24 19:38:48 --> URI Class Initialized
INFO - 2017-01-24 19:38:48 --> Router Class Initialized
INFO - 2017-01-24 19:38:48 --> Output Class Initialized
INFO - 2017-01-24 19:38:48 --> Security Class Initialized
DEBUG - 2017-01-24 19:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:38:48 --> Input Class Initialized
INFO - 2017-01-24 19:38:48 --> Language Class Initialized
INFO - 2017-01-24 19:38:48 --> Loader Class Initialized
INFO - 2017-01-24 19:38:48 --> Database Driver Class Initialized
INFO - 2017-01-24 19:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:38:48 --> Controller Class Initialized
INFO - 2017-01-24 19:38:48 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:38:48 --> Final output sent to browser
DEBUG - 2017-01-24 19:38:48 --> Total execution time: 0.0138
INFO - 2017-01-24 19:38:59 --> Config Class Initialized
INFO - 2017-01-24 19:38:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:38:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:38:59 --> Utf8 Class Initialized
INFO - 2017-01-24 19:38:59 --> URI Class Initialized
DEBUG - 2017-01-24 19:38:59 --> No URI present. Default controller set.
INFO - 2017-01-24 19:38:59 --> Router Class Initialized
INFO - 2017-01-24 19:38:59 --> Output Class Initialized
INFO - 2017-01-24 19:38:59 --> Security Class Initialized
DEBUG - 2017-01-24 19:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:38:59 --> Input Class Initialized
INFO - 2017-01-24 19:38:59 --> Language Class Initialized
INFO - 2017-01-24 19:38:59 --> Loader Class Initialized
INFO - 2017-01-24 19:38:59 --> Database Driver Class Initialized
INFO - 2017-01-24 19:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:38:59 --> Controller Class Initialized
INFO - 2017-01-24 19:38:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:38:59 --> Final output sent to browser
DEBUG - 2017-01-24 19:38:59 --> Total execution time: 0.0174
INFO - 2017-01-24 19:39:00 --> Config Class Initialized
INFO - 2017-01-24 19:39:00 --> Hooks Class Initialized
DEBUG - 2017-01-24 19:39:00 --> UTF-8 Support Enabled
INFO - 2017-01-24 19:39:00 --> Utf8 Class Initialized
INFO - 2017-01-24 19:39:00 --> URI Class Initialized
INFO - 2017-01-24 19:39:00 --> Router Class Initialized
INFO - 2017-01-24 19:39:00 --> Output Class Initialized
INFO - 2017-01-24 19:39:00 --> Security Class Initialized
DEBUG - 2017-01-24 19:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 19:39:00 --> Input Class Initialized
INFO - 2017-01-24 19:39:00 --> Language Class Initialized
INFO - 2017-01-24 19:39:00 --> Loader Class Initialized
INFO - 2017-01-24 19:39:00 --> Database Driver Class Initialized
INFO - 2017-01-24 19:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 19:39:00 --> Controller Class Initialized
INFO - 2017-01-24 19:39:00 --> Helper loaded: url_helper
DEBUG - 2017-01-24 19:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 19:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 19:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 19:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 19:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 19:39:00 --> Final output sent to browser
DEBUG - 2017-01-24 19:39:00 --> Total execution time: 0.0234
INFO - 2017-01-24 20:20:13 --> Config Class Initialized
INFO - 2017-01-24 20:20:13 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:20:13 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:20:13 --> Utf8 Class Initialized
INFO - 2017-01-24 20:20:13 --> URI Class Initialized
DEBUG - 2017-01-24 20:20:13 --> No URI present. Default controller set.
INFO - 2017-01-24 20:20:13 --> Router Class Initialized
INFO - 2017-01-24 20:20:13 --> Output Class Initialized
INFO - 2017-01-24 20:20:13 --> Security Class Initialized
DEBUG - 2017-01-24 20:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:20:13 --> Input Class Initialized
INFO - 2017-01-24 20:20:13 --> Language Class Initialized
INFO - 2017-01-24 20:20:13 --> Loader Class Initialized
INFO - 2017-01-24 20:20:13 --> Database Driver Class Initialized
INFO - 2017-01-24 20:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:20:13 --> Controller Class Initialized
INFO - 2017-01-24 20:20:13 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:20:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:20:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 20:20:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 20:20:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:20:13 --> Final output sent to browser
DEBUG - 2017-01-24 20:20:13 --> Total execution time: 0.0198
INFO - 2017-01-24 20:20:25 --> Config Class Initialized
INFO - 2017-01-24 20:20:25 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:20:25 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:20:25 --> Utf8 Class Initialized
INFO - 2017-01-24 20:20:25 --> URI Class Initialized
INFO - 2017-01-24 20:20:25 --> Router Class Initialized
INFO - 2017-01-24 20:20:25 --> Output Class Initialized
INFO - 2017-01-24 20:20:25 --> Security Class Initialized
DEBUG - 2017-01-24 20:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:20:25 --> Input Class Initialized
INFO - 2017-01-24 20:20:25 --> Language Class Initialized
INFO - 2017-01-24 20:20:25 --> Loader Class Initialized
INFO - 2017-01-24 20:20:25 --> Database Driver Class Initialized
INFO - 2017-01-24 20:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:20:25 --> Controller Class Initialized
INFO - 2017-01-24 20:20:25 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 20:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 20:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:20:25 --> Final output sent to browser
DEBUG - 2017-01-24 20:20:25 --> Total execution time: 0.0141
INFO - 2017-01-24 20:21:55 --> Config Class Initialized
INFO - 2017-01-24 20:21:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:21:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:21:55 --> Utf8 Class Initialized
INFO - 2017-01-24 20:21:55 --> URI Class Initialized
INFO - 2017-01-24 20:21:55 --> Router Class Initialized
INFO - 2017-01-24 20:21:55 --> Output Class Initialized
INFO - 2017-01-24 20:21:55 --> Security Class Initialized
DEBUG - 2017-01-24 20:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:21:55 --> Input Class Initialized
INFO - 2017-01-24 20:21:55 --> Language Class Initialized
INFO - 2017-01-24 20:21:55 --> Loader Class Initialized
INFO - 2017-01-24 20:21:55 --> Database Driver Class Initialized
INFO - 2017-01-24 20:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:21:55 --> Controller Class Initialized
INFO - 2017-01-24 20:21:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:21:57 --> Config Class Initialized
INFO - 2017-01-24 20:21:57 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:21:57 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:21:57 --> Utf8 Class Initialized
INFO - 2017-01-24 20:21:57 --> URI Class Initialized
INFO - 2017-01-24 20:21:57 --> Router Class Initialized
INFO - 2017-01-24 20:21:57 --> Output Class Initialized
INFO - 2017-01-24 20:21:57 --> Security Class Initialized
DEBUG - 2017-01-24 20:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:21:57 --> Input Class Initialized
INFO - 2017-01-24 20:21:57 --> Language Class Initialized
INFO - 2017-01-24 20:21:57 --> Loader Class Initialized
INFO - 2017-01-24 20:21:57 --> Database Driver Class Initialized
INFO - 2017-01-24 20:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:21:57 --> Controller Class Initialized
INFO - 2017-01-24 20:21:57 --> Helper loaded: date_helper
DEBUG - 2017-01-24 20:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:21:57 --> Helper loaded: url_helper
INFO - 2017-01-24 20:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 20:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 20:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 20:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:21:57 --> Final output sent to browser
DEBUG - 2017-01-24 20:21:57 --> Total execution time: 0.0240
INFO - 2017-01-24 20:21:59 --> Config Class Initialized
INFO - 2017-01-24 20:21:59 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:21:59 --> Utf8 Class Initialized
INFO - 2017-01-24 20:21:59 --> URI Class Initialized
INFO - 2017-01-24 20:21:59 --> Router Class Initialized
INFO - 2017-01-24 20:21:59 --> Output Class Initialized
INFO - 2017-01-24 20:21:59 --> Security Class Initialized
DEBUG - 2017-01-24 20:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:21:59 --> Input Class Initialized
INFO - 2017-01-24 20:21:59 --> Language Class Initialized
INFO - 2017-01-24 20:21:59 --> Loader Class Initialized
INFO - 2017-01-24 20:21:59 --> Database Driver Class Initialized
INFO - 2017-01-24 20:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:21:59 --> Controller Class Initialized
INFO - 2017-01-24 20:21:59 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 20:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 20:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:21:59 --> Final output sent to browser
DEBUG - 2017-01-24 20:21:59 --> Total execution time: 0.0140
INFO - 2017-01-24 20:22:12 --> Config Class Initialized
INFO - 2017-01-24 20:22:12 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:22:12 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:22:12 --> Utf8 Class Initialized
INFO - 2017-01-24 20:22:12 --> URI Class Initialized
DEBUG - 2017-01-24 20:22:12 --> No URI present. Default controller set.
INFO - 2017-01-24 20:22:12 --> Router Class Initialized
INFO - 2017-01-24 20:22:12 --> Output Class Initialized
INFO - 2017-01-24 20:22:12 --> Security Class Initialized
DEBUG - 2017-01-24 20:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:22:12 --> Input Class Initialized
INFO - 2017-01-24 20:22:12 --> Language Class Initialized
INFO - 2017-01-24 20:22:12 --> Loader Class Initialized
INFO - 2017-01-24 20:22:12 --> Database Driver Class Initialized
INFO - 2017-01-24 20:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:22:12 --> Controller Class Initialized
INFO - 2017-01-24 20:22:12 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 20:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 20:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:22:12 --> Final output sent to browser
DEBUG - 2017-01-24 20:22:12 --> Total execution time: 0.0139
INFO - 2017-01-24 20:22:15 --> Config Class Initialized
INFO - 2017-01-24 20:22:15 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:22:15 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:22:15 --> Utf8 Class Initialized
INFO - 2017-01-24 20:22:15 --> URI Class Initialized
INFO - 2017-01-24 20:22:15 --> Router Class Initialized
INFO - 2017-01-24 20:22:15 --> Output Class Initialized
INFO - 2017-01-24 20:22:15 --> Security Class Initialized
DEBUG - 2017-01-24 20:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:22:15 --> Input Class Initialized
INFO - 2017-01-24 20:22:15 --> Language Class Initialized
INFO - 2017-01-24 20:22:15 --> Loader Class Initialized
INFO - 2017-01-24 20:22:15 --> Database Driver Class Initialized
INFO - 2017-01-24 20:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:22:15 --> Controller Class Initialized
INFO - 2017-01-24 20:22:15 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 20:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 20:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:22:15 --> Final output sent to browser
DEBUG - 2017-01-24 20:22:15 --> Total execution time: 0.0146
INFO - 2017-01-24 20:22:48 --> Config Class Initialized
INFO - 2017-01-24 20:22:48 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:22:48 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:22:48 --> Utf8 Class Initialized
INFO - 2017-01-24 20:22:48 --> URI Class Initialized
INFO - 2017-01-24 20:22:48 --> Router Class Initialized
INFO - 2017-01-24 20:22:48 --> Output Class Initialized
INFO - 2017-01-24 20:22:48 --> Security Class Initialized
DEBUG - 2017-01-24 20:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:22:48 --> Input Class Initialized
INFO - 2017-01-24 20:22:48 --> Language Class Initialized
INFO - 2017-01-24 20:22:48 --> Loader Class Initialized
INFO - 2017-01-24 20:22:48 --> Database Driver Class Initialized
INFO - 2017-01-24 20:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:22:48 --> Controller Class Initialized
INFO - 2017-01-24 20:22:48 --> Helper loaded: date_helper
DEBUG - 2017-01-24 20:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:22:48 --> Helper loaded: url_helper
INFO - 2017-01-24 20:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 20:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 20:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 20:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:22:48 --> Final output sent to browser
DEBUG - 2017-01-24 20:22:48 --> Total execution time: 0.0308
INFO - 2017-01-24 20:22:49 --> Config Class Initialized
INFO - 2017-01-24 20:22:49 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:22:49 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:22:49 --> Utf8 Class Initialized
INFO - 2017-01-24 20:22:49 --> URI Class Initialized
INFO - 2017-01-24 20:22:49 --> Router Class Initialized
INFO - 2017-01-24 20:22:49 --> Output Class Initialized
INFO - 2017-01-24 20:22:49 --> Security Class Initialized
DEBUG - 2017-01-24 20:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:22:49 --> Input Class Initialized
INFO - 2017-01-24 20:22:49 --> Language Class Initialized
INFO - 2017-01-24 20:22:49 --> Loader Class Initialized
INFO - 2017-01-24 20:22:49 --> Database Driver Class Initialized
INFO - 2017-01-24 20:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:22:49 --> Controller Class Initialized
INFO - 2017-01-24 20:22:49 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 20:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 20:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:22:49 --> Final output sent to browser
DEBUG - 2017-01-24 20:22:49 --> Total execution time: 0.0674
INFO - 2017-01-24 20:23:04 --> Config Class Initialized
INFO - 2017-01-24 20:23:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:23:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:23:04 --> Utf8 Class Initialized
INFO - 2017-01-24 20:23:04 --> URI Class Initialized
INFO - 2017-01-24 20:23:04 --> Router Class Initialized
INFO - 2017-01-24 20:23:04 --> Output Class Initialized
INFO - 2017-01-24 20:23:04 --> Security Class Initialized
DEBUG - 2017-01-24 20:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:23:04 --> Input Class Initialized
INFO - 2017-01-24 20:23:04 --> Language Class Initialized
INFO - 2017-01-24 20:23:04 --> Loader Class Initialized
INFO - 2017-01-24 20:23:04 --> Database Driver Class Initialized
INFO - 2017-01-24 20:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:23:04 --> Controller Class Initialized
INFO - 2017-01-24 20:23:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:23:05 --> Config Class Initialized
INFO - 2017-01-24 20:23:05 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:23:05 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:23:05 --> Utf8 Class Initialized
INFO - 2017-01-24 20:23:05 --> URI Class Initialized
INFO - 2017-01-24 20:23:05 --> Router Class Initialized
INFO - 2017-01-24 20:23:05 --> Output Class Initialized
INFO - 2017-01-24 20:23:05 --> Security Class Initialized
DEBUG - 2017-01-24 20:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:23:05 --> Input Class Initialized
INFO - 2017-01-24 20:23:05 --> Language Class Initialized
INFO - 2017-01-24 20:23:05 --> Loader Class Initialized
INFO - 2017-01-24 20:23:05 --> Database Driver Class Initialized
INFO - 2017-01-24 20:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:23:05 --> Controller Class Initialized
INFO - 2017-01-24 20:23:05 --> Helper loaded: date_helper
DEBUG - 2017-01-24 20:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:23:05 --> Helper loaded: url_helper
INFO - 2017-01-24 20:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-24 20:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-24 20:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-24 20:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:23:05 --> Final output sent to browser
DEBUG - 2017-01-24 20:23:05 --> Total execution time: 0.0617
INFO - 2017-01-24 20:23:07 --> Config Class Initialized
INFO - 2017-01-24 20:23:07 --> Hooks Class Initialized
DEBUG - 2017-01-24 20:23:07 --> UTF-8 Support Enabled
INFO - 2017-01-24 20:23:07 --> Utf8 Class Initialized
INFO - 2017-01-24 20:23:07 --> URI Class Initialized
INFO - 2017-01-24 20:23:07 --> Router Class Initialized
INFO - 2017-01-24 20:23:07 --> Output Class Initialized
INFO - 2017-01-24 20:23:07 --> Security Class Initialized
DEBUG - 2017-01-24 20:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 20:23:07 --> Input Class Initialized
INFO - 2017-01-24 20:23:07 --> Language Class Initialized
INFO - 2017-01-24 20:23:07 --> Loader Class Initialized
INFO - 2017-01-24 20:23:07 --> Database Driver Class Initialized
INFO - 2017-01-24 20:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 20:23:07 --> Controller Class Initialized
INFO - 2017-01-24 20:23:07 --> Helper loaded: url_helper
DEBUG - 2017-01-24 20:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 20:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 20:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 20:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 20:23:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 20:23:07 --> Final output sent to browser
DEBUG - 2017-01-24 20:23:07 --> Total execution time: 0.0219
INFO - 2017-01-24 21:04:19 --> Config Class Initialized
INFO - 2017-01-24 21:04:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:04:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:04:19 --> Utf8 Class Initialized
INFO - 2017-01-24 21:04:19 --> URI Class Initialized
DEBUG - 2017-01-24 21:04:19 --> No URI present. Default controller set.
INFO - 2017-01-24 21:04:19 --> Router Class Initialized
INFO - 2017-01-24 21:04:19 --> Output Class Initialized
INFO - 2017-01-24 21:04:19 --> Security Class Initialized
DEBUG - 2017-01-24 21:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:04:19 --> Input Class Initialized
INFO - 2017-01-24 21:04:19 --> Language Class Initialized
INFO - 2017-01-24 21:04:19 --> Loader Class Initialized
INFO - 2017-01-24 21:04:19 --> Database Driver Class Initialized
INFO - 2017-01-24 21:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:04:19 --> Controller Class Initialized
INFO - 2017-01-24 21:04:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:04:19 --> Final output sent to browser
DEBUG - 2017-01-24 21:04:19 --> Total execution time: 0.0150
INFO - 2017-01-24 21:04:27 --> Config Class Initialized
INFO - 2017-01-24 21:04:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:04:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:04:27 --> Utf8 Class Initialized
INFO - 2017-01-24 21:04:27 --> URI Class Initialized
INFO - 2017-01-24 21:04:27 --> Router Class Initialized
INFO - 2017-01-24 21:04:27 --> Output Class Initialized
INFO - 2017-01-24 21:04:27 --> Security Class Initialized
DEBUG - 2017-01-24 21:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:04:27 --> Input Class Initialized
INFO - 2017-01-24 21:04:27 --> Language Class Initialized
INFO - 2017-01-24 21:04:27 --> Loader Class Initialized
INFO - 2017-01-24 21:04:27 --> Database Driver Class Initialized
INFO - 2017-01-24 21:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:04:27 --> Controller Class Initialized
INFO - 2017-01-24 21:04:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:04:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:04:27 --> Final output sent to browser
DEBUG - 2017-01-24 21:04:27 --> Total execution time: 0.0146
INFO - 2017-01-24 21:43:49 --> Config Class Initialized
INFO - 2017-01-24 21:43:49 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:43:49 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:43:49 --> Utf8 Class Initialized
INFO - 2017-01-24 21:43:49 --> URI Class Initialized
DEBUG - 2017-01-24 21:43:49 --> No URI present. Default controller set.
INFO - 2017-01-24 21:43:49 --> Router Class Initialized
INFO - 2017-01-24 21:43:49 --> Output Class Initialized
INFO - 2017-01-24 21:43:49 --> Security Class Initialized
DEBUG - 2017-01-24 21:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:43:49 --> Input Class Initialized
INFO - 2017-01-24 21:43:49 --> Language Class Initialized
INFO - 2017-01-24 21:43:49 --> Loader Class Initialized
INFO - 2017-01-24 21:43:49 --> Database Driver Class Initialized
INFO - 2017-01-24 21:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:43:49 --> Controller Class Initialized
INFO - 2017-01-24 21:43:49 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:43:49 --> Final output sent to browser
DEBUG - 2017-01-24 21:43:49 --> Total execution time: 0.0209
INFO - 2017-01-24 21:43:55 --> Config Class Initialized
INFO - 2017-01-24 21:43:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:43:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:43:55 --> Utf8 Class Initialized
INFO - 2017-01-24 21:43:55 --> URI Class Initialized
INFO - 2017-01-24 21:43:55 --> Router Class Initialized
INFO - 2017-01-24 21:43:55 --> Output Class Initialized
INFO - 2017-01-24 21:43:55 --> Security Class Initialized
DEBUG - 2017-01-24 21:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:43:55 --> Input Class Initialized
INFO - 2017-01-24 21:43:55 --> Language Class Initialized
INFO - 2017-01-24 21:43:55 --> Loader Class Initialized
INFO - 2017-01-24 21:43:55 --> Database Driver Class Initialized
INFO - 2017-01-24 21:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:43:55 --> Controller Class Initialized
INFO - 2017-01-24 21:43:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:43:55 --> Final output sent to browser
DEBUG - 2017-01-24 21:43:55 --> Total execution time: 0.0138
INFO - 2017-01-24 21:43:58 --> Config Class Initialized
INFO - 2017-01-24 21:43:58 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:43:58 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:43:58 --> Utf8 Class Initialized
INFO - 2017-01-24 21:43:58 --> URI Class Initialized
INFO - 2017-01-24 21:43:58 --> Router Class Initialized
INFO - 2017-01-24 21:43:58 --> Output Class Initialized
INFO - 2017-01-24 21:43:58 --> Security Class Initialized
DEBUG - 2017-01-24 21:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:43:58 --> Input Class Initialized
INFO - 2017-01-24 21:43:58 --> Language Class Initialized
INFO - 2017-01-24 21:43:58 --> Loader Class Initialized
INFO - 2017-01-24 21:43:58 --> Database Driver Class Initialized
INFO - 2017-01-24 21:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:43:58 --> Controller Class Initialized
INFO - 2017-01-24 21:43:58 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:43:58 --> Helper loaded: form_helper
INFO - 2017-01-24 21:43:58 --> Form Validation Class Initialized
INFO - 2017-01-24 21:43:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:43:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-24 21:43:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:43:58 --> Final output sent to browser
DEBUG - 2017-01-24 21:43:58 --> Total execution time: 0.2763
INFO - 2017-01-24 21:43:58 --> Config Class Initialized
INFO - 2017-01-24 21:43:58 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:43:58 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:43:58 --> Utf8 Class Initialized
INFO - 2017-01-24 21:43:58 --> URI Class Initialized
INFO - 2017-01-24 21:43:58 --> Router Class Initialized
INFO - 2017-01-24 21:43:58 --> Output Class Initialized
INFO - 2017-01-24 21:43:58 --> Security Class Initialized
DEBUG - 2017-01-24 21:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:43:58 --> Input Class Initialized
INFO - 2017-01-24 21:43:58 --> Language Class Initialized
INFO - 2017-01-24 21:43:58 --> Loader Class Initialized
INFO - 2017-01-24 21:43:58 --> Database Driver Class Initialized
INFO - 2017-01-24 21:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:43:58 --> Controller Class Initialized
INFO - 2017-01-24 21:43:58 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:43:58 --> Final output sent to browser
DEBUG - 2017-01-24 21:43:58 --> Total execution time: 0.0142
INFO - 2017-01-24 21:44:06 --> Config Class Initialized
INFO - 2017-01-24 21:44:06 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:06 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:06 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:06 --> URI Class Initialized
INFO - 2017-01-24 21:44:06 --> Router Class Initialized
INFO - 2017-01-24 21:44:06 --> Output Class Initialized
INFO - 2017-01-24 21:44:06 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:06 --> Input Class Initialized
INFO - 2017-01-24 21:44:06 --> Language Class Initialized
INFO - 2017-01-24 21:44:06 --> Loader Class Initialized
INFO - 2017-01-24 21:44:06 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:06 --> Controller Class Initialized
INFO - 2017-01-24 21:44:06 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:06 --> Helper loaded: form_helper
INFO - 2017-01-24 21:44:06 --> Form Validation Class Initialized
INFO - 2017-01-24 21:44:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-24 21:44:07 --> Config Class Initialized
INFO - 2017-01-24 21:44:07 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:07 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:07 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:07 --> URI Class Initialized
INFO - 2017-01-24 21:44:07 --> Router Class Initialized
INFO - 2017-01-24 21:44:07 --> Output Class Initialized
INFO - 2017-01-24 21:44:07 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:07 --> Input Class Initialized
INFO - 2017-01-24 21:44:07 --> Language Class Initialized
INFO - 2017-01-24 21:44:07 --> Loader Class Initialized
INFO - 2017-01-24 21:44:07 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:07 --> Controller Class Initialized
INFO - 2017-01-24 21:44:07 --> Helper loaded: date_helper
INFO - 2017-01-24 21:44:07 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:07 --> Helper loaded: form_helper
INFO - 2017-01-24 21:44:07 --> Form Validation Class Initialized
INFO - 2017-01-24 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-24 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-24 21:44:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:44:07 --> Final output sent to browser
DEBUG - 2017-01-24 21:44:07 --> Total execution time: 0.1218
INFO - 2017-01-24 21:44:07 --> Config Class Initialized
INFO - 2017-01-24 21:44:07 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:07 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:07 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:07 --> URI Class Initialized
INFO - 2017-01-24 21:44:07 --> Router Class Initialized
INFO - 2017-01-24 21:44:07 --> Output Class Initialized
INFO - 2017-01-24 21:44:07 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:07 --> Input Class Initialized
INFO - 2017-01-24 21:44:07 --> Language Class Initialized
INFO - 2017-01-24 21:44:07 --> Loader Class Initialized
INFO - 2017-01-24 21:44:07 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:07 --> Controller Class Initialized
INFO - 2017-01-24 21:44:07 --> Helper loaded: date_helper
INFO - 2017-01-24 21:44:07 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:07 --> Helper loaded: form_helper
INFO - 2017-01-24 21:44:07 --> Form Validation Class Initialized
INFO - 2017-01-24 21:44:07 --> Final output sent to browser
DEBUG - 2017-01-24 21:44:07 --> Total execution time: 0.0660
INFO - 2017-01-24 21:44:10 --> Config Class Initialized
INFO - 2017-01-24 21:44:10 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:10 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:10 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:10 --> URI Class Initialized
INFO - 2017-01-24 21:44:10 --> Router Class Initialized
INFO - 2017-01-24 21:44:10 --> Output Class Initialized
INFO - 2017-01-24 21:44:10 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:10 --> Input Class Initialized
INFO - 2017-01-24 21:44:10 --> Language Class Initialized
INFO - 2017-01-24 21:44:10 --> Loader Class Initialized
INFO - 2017-01-24 21:44:10 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:10 --> Controller Class Initialized
INFO - 2017-01-24 21:44:10 --> Helper loaded: date_helper
INFO - 2017-01-24 21:44:10 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:10 --> Helper loaded: form_helper
INFO - 2017-01-24 21:44:10 --> Form Validation Class Initialized
INFO - 2017-01-24 21:44:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:44:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:44:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:44:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:44:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:44:10 --> Final output sent to browser
DEBUG - 2017-01-24 21:44:10 --> Total execution time: 0.0484
INFO - 2017-01-24 21:44:11 --> Config Class Initialized
INFO - 2017-01-24 21:44:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:11 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:11 --> URI Class Initialized
INFO - 2017-01-24 21:44:11 --> Router Class Initialized
INFO - 2017-01-24 21:44:11 --> Output Class Initialized
INFO - 2017-01-24 21:44:11 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:11 --> Input Class Initialized
INFO - 2017-01-24 21:44:11 --> Language Class Initialized
INFO - 2017-01-24 21:44:11 --> Loader Class Initialized
INFO - 2017-01-24 21:44:11 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:11 --> Controller Class Initialized
INFO - 2017-01-24 21:44:11 --> Helper loaded: date_helper
INFO - 2017-01-24 21:44:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:11 --> Helper loaded: form_helper
INFO - 2017-01-24 21:44:11 --> Form Validation Class Initialized
INFO - 2017-01-24 21:44:11 --> Final output sent to browser
DEBUG - 2017-01-24 21:44:11 --> Total execution time: 0.0392
INFO - 2017-01-24 21:44:11 --> Config Class Initialized
INFO - 2017-01-24 21:44:11 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:11 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:11 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:11 --> URI Class Initialized
INFO - 2017-01-24 21:44:11 --> Router Class Initialized
INFO - 2017-01-24 21:44:11 --> Output Class Initialized
INFO - 2017-01-24 21:44:11 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:11 --> Input Class Initialized
INFO - 2017-01-24 21:44:11 --> Language Class Initialized
INFO - 2017-01-24 21:44:11 --> Loader Class Initialized
INFO - 2017-01-24 21:44:11 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:11 --> Controller Class Initialized
INFO - 2017-01-24 21:44:11 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:44:11 --> Final output sent to browser
DEBUG - 2017-01-24 21:44:11 --> Total execution time: 0.0744
INFO - 2017-01-24 21:44:14 --> Config Class Initialized
INFO - 2017-01-24 21:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:14 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:14 --> URI Class Initialized
INFO - 2017-01-24 21:44:14 --> Router Class Initialized
INFO - 2017-01-24 21:44:14 --> Output Class Initialized
INFO - 2017-01-24 21:44:14 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:14 --> Input Class Initialized
INFO - 2017-01-24 21:44:14 --> Language Class Initialized
INFO - 2017-01-24 21:44:14 --> Loader Class Initialized
INFO - 2017-01-24 21:44:14 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:14 --> Controller Class Initialized
INFO - 2017-01-24 21:44:14 --> Helper loaded: date_helper
INFO - 2017-01-24 21:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:14 --> Helper loaded: form_helper
INFO - 2017-01-24 21:44:14 --> Form Validation Class Initialized
INFO - 2017-01-24 21:44:14 --> Final output sent to browser
DEBUG - 2017-01-24 21:44:14 --> Total execution time: 0.0159
INFO - 2017-01-24 21:44:14 --> Config Class Initialized
INFO - 2017-01-24 21:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:44:14 --> Utf8 Class Initialized
INFO - 2017-01-24 21:44:14 --> URI Class Initialized
INFO - 2017-01-24 21:44:14 --> Router Class Initialized
INFO - 2017-01-24 21:44:14 --> Output Class Initialized
INFO - 2017-01-24 21:44:14 --> Security Class Initialized
DEBUG - 2017-01-24 21:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:44:14 --> Input Class Initialized
INFO - 2017-01-24 21:44:14 --> Language Class Initialized
INFO - 2017-01-24 21:44:14 --> Loader Class Initialized
INFO - 2017-01-24 21:44:14 --> Database Driver Class Initialized
INFO - 2017-01-24 21:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:44:14 --> Controller Class Initialized
INFO - 2017-01-24 21:44:14 --> Helper loaded: date_helper
INFO - 2017-01-24 21:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:44:14 --> Helper loaded: form_helper
INFO - 2017-01-24 21:44:14 --> Form Validation Class Initialized
INFO - 2017-01-24 21:44:14 --> Final output sent to browser
DEBUG - 2017-01-24 21:44:14 --> Total execution time: 0.0957
INFO - 2017-01-24 21:46:03 --> Config Class Initialized
INFO - 2017-01-24 21:46:03 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:03 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:03 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:03 --> URI Class Initialized
INFO - 2017-01-24 21:46:03 --> Router Class Initialized
INFO - 2017-01-24 21:46:03 --> Output Class Initialized
INFO - 2017-01-24 21:46:03 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:03 --> Input Class Initialized
INFO - 2017-01-24 21:46:03 --> Language Class Initialized
INFO - 2017-01-24 21:46:03 --> Loader Class Initialized
INFO - 2017-01-24 21:46:03 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:03 --> Controller Class Initialized
INFO - 2017-01-24 21:46:03 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:03 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:03 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:03 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:46:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:46:03 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:03 --> Total execution time: 0.0224
INFO - 2017-01-24 21:46:04 --> Config Class Initialized
INFO - 2017-01-24 21:46:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:04 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:04 --> URI Class Initialized
INFO - 2017-01-24 21:46:04 --> Router Class Initialized
INFO - 2017-01-24 21:46:04 --> Output Class Initialized
INFO - 2017-01-24 21:46:04 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:04 --> Input Class Initialized
INFO - 2017-01-24 21:46:04 --> Language Class Initialized
INFO - 2017-01-24 21:46:04 --> Loader Class Initialized
INFO - 2017-01-24 21:46:04 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:04 --> Controller Class Initialized
INFO - 2017-01-24 21:46:04 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:04 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:04 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:04 --> Config Class Initialized
INFO - 2017-01-24 21:46:04 --> Hooks Class Initialized
INFO - 2017-01-24 21:46:04 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:04 --> Total execution time: 0.0577
DEBUG - 2017-01-24 21:46:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:04 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:04 --> URI Class Initialized
INFO - 2017-01-24 21:46:04 --> Router Class Initialized
INFO - 2017-01-24 21:46:04 --> Output Class Initialized
INFO - 2017-01-24 21:46:04 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:04 --> Input Class Initialized
INFO - 2017-01-24 21:46:04 --> Language Class Initialized
INFO - 2017-01-24 21:46:04 --> Loader Class Initialized
INFO - 2017-01-24 21:46:04 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:04 --> Controller Class Initialized
INFO - 2017-01-24 21:46:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:46:04 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:04 --> Total execution time: 0.0213
INFO - 2017-01-24 21:46:06 --> Config Class Initialized
INFO - 2017-01-24 21:46:06 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:06 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:06 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:06 --> URI Class Initialized
INFO - 2017-01-24 21:46:06 --> Router Class Initialized
INFO - 2017-01-24 21:46:06 --> Output Class Initialized
INFO - 2017-01-24 21:46:06 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:06 --> Input Class Initialized
INFO - 2017-01-24 21:46:06 --> Language Class Initialized
INFO - 2017-01-24 21:46:06 --> Loader Class Initialized
INFO - 2017-01-24 21:46:06 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:06 --> Controller Class Initialized
INFO - 2017-01-24 21:46:06 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:06 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:06 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:06 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:06 --> Config Class Initialized
INFO - 2017-01-24 21:46:06 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:06 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:06 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:06 --> URI Class Initialized
INFO - 2017-01-24 21:46:06 --> Router Class Initialized
INFO - 2017-01-24 21:46:06 --> Output Class Initialized
INFO - 2017-01-24 21:46:06 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:06 --> Input Class Initialized
INFO - 2017-01-24 21:46:06 --> Language Class Initialized
INFO - 2017-01-24 21:46:06 --> Loader Class Initialized
INFO - 2017-01-24 21:46:06 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:06 --> Total execution time: 0.0896
INFO - 2017-01-24 21:46:06 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:06 --> Controller Class Initialized
INFO - 2017-01-24 21:46:06 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:06 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:06 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:06 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:07 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:07 --> Total execution time: 0.0223
INFO - 2017-01-24 21:46:12 --> Config Class Initialized
INFO - 2017-01-24 21:46:12 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:12 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:12 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:12 --> URI Class Initialized
INFO - 2017-01-24 21:46:12 --> Router Class Initialized
INFO - 2017-01-24 21:46:12 --> Output Class Initialized
INFO - 2017-01-24 21:46:12 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:12 --> Input Class Initialized
INFO - 2017-01-24 21:46:12 --> Language Class Initialized
ERROR - 2017-01-24 21:46:12 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:46:38 --> Config Class Initialized
INFO - 2017-01-24 21:46:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:38 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:38 --> URI Class Initialized
INFO - 2017-01-24 21:46:38 --> Router Class Initialized
INFO - 2017-01-24 21:46:38 --> Output Class Initialized
INFO - 2017-01-24 21:46:38 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:38 --> Input Class Initialized
INFO - 2017-01-24 21:46:38 --> Language Class Initialized
INFO - 2017-01-24 21:46:38 --> Loader Class Initialized
INFO - 2017-01-24 21:46:38 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:38 --> Controller Class Initialized
INFO - 2017-01-24 21:46:38 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:38 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:38 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:46:38 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:38 --> Total execution time: 0.0584
INFO - 2017-01-24 21:46:38 --> Config Class Initialized
INFO - 2017-01-24 21:46:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:38 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:38 --> URI Class Initialized
INFO - 2017-01-24 21:46:38 --> Router Class Initialized
INFO - 2017-01-24 21:46:38 --> Output Class Initialized
INFO - 2017-01-24 21:46:38 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:38 --> Input Class Initialized
INFO - 2017-01-24 21:46:38 --> Language Class Initialized
INFO - 2017-01-24 21:46:38 --> Loader Class Initialized
INFO - 2017-01-24 21:46:38 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:38 --> Config Class Initialized
INFO - 2017-01-24 21:46:38 --> Hooks Class Initialized
INFO - 2017-01-24 21:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:38 --> Controller Class Initialized
DEBUG - 2017-01-24 21:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:38 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:38 --> URI Class Initialized
INFO - 2017-01-24 21:46:38 --> Router Class Initialized
INFO - 2017-01-24 21:46:38 --> Output Class Initialized
INFO - 2017-01-24 21:46:38 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:38 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:38 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:38 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:38 --> Input Class Initialized
INFO - 2017-01-24 21:46:38 --> Language Class Initialized
INFO - 2017-01-24 21:46:38 --> Loader Class Initialized
INFO - 2017-01-24 21:46:38 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:38 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:38 --> Total execution time: 0.0975
INFO - 2017-01-24 21:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:38 --> Controller Class Initialized
INFO - 2017-01-24 21:46:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:46:38 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:38 --> Total execution time: 0.1010
INFO - 2017-01-24 21:46:40 --> Config Class Initialized
INFO - 2017-01-24 21:46:40 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:40 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:40 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:40 --> URI Class Initialized
INFO - 2017-01-24 21:46:40 --> Router Class Initialized
INFO - 2017-01-24 21:46:40 --> Output Class Initialized
INFO - 2017-01-24 21:46:40 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:40 --> Input Class Initialized
INFO - 2017-01-24 21:46:40 --> Language Class Initialized
INFO - 2017-01-24 21:46:40 --> Loader Class Initialized
INFO - 2017-01-24 21:46:40 --> Config Class Initialized
INFO - 2017-01-24 21:46:40 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:46:40 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:46:40 --> Utf8 Class Initialized
INFO - 2017-01-24 21:46:40 --> URI Class Initialized
INFO - 2017-01-24 21:46:40 --> Router Class Initialized
INFO - 2017-01-24 21:46:40 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:40 --> Output Class Initialized
INFO - 2017-01-24 21:46:40 --> Security Class Initialized
DEBUG - 2017-01-24 21:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:46:40 --> Input Class Initialized
INFO - 2017-01-24 21:46:40 --> Language Class Initialized
INFO - 2017-01-24 21:46:40 --> Loader Class Initialized
INFO - 2017-01-24 21:46:40 --> Database Driver Class Initialized
INFO - 2017-01-24 21:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:40 --> Controller Class Initialized
INFO - 2017-01-24 21:46:40 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:40 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:40 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:40 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:40 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:40 --> Total execution time: 0.0344
INFO - 2017-01-24 21:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:46:40 --> Controller Class Initialized
INFO - 2017-01-24 21:46:40 --> Helper loaded: date_helper
INFO - 2017-01-24 21:46:40 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:46:40 --> Helper loaded: form_helper
INFO - 2017-01-24 21:46:40 --> Form Validation Class Initialized
INFO - 2017-01-24 21:46:40 --> Final output sent to browser
DEBUG - 2017-01-24 21:46:40 --> Total execution time: 0.0265
INFO - 2017-01-24 21:47:26 --> Config Class Initialized
INFO - 2017-01-24 21:47:26 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:47:26 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:47:26 --> Utf8 Class Initialized
INFO - 2017-01-24 21:47:26 --> URI Class Initialized
INFO - 2017-01-24 21:47:26 --> Router Class Initialized
INFO - 2017-01-24 21:47:26 --> Output Class Initialized
INFO - 2017-01-24 21:47:26 --> Security Class Initialized
DEBUG - 2017-01-24 21:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:47:26 --> Input Class Initialized
INFO - 2017-01-24 21:47:26 --> Language Class Initialized
INFO - 2017-01-24 21:47:26 --> Loader Class Initialized
INFO - 2017-01-24 21:47:26 --> Database Driver Class Initialized
INFO - 2017-01-24 21:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:47:26 --> Controller Class Initialized
INFO - 2017-01-24 21:47:26 --> Helper loaded: date_helper
INFO - 2017-01-24 21:47:26 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:47:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:47:26 --> Helper loaded: form_helper
INFO - 2017-01-24 21:47:26 --> Form Validation Class Initialized
INFO - 2017-01-24 21:47:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:47:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:47:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:47:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:47:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:47:26 --> Final output sent to browser
DEBUG - 2017-01-24 21:47:26 --> Total execution time: 0.0292
INFO - 2017-01-24 21:47:27 --> Config Class Initialized
INFO - 2017-01-24 21:47:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:47:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:47:27 --> Utf8 Class Initialized
INFO - 2017-01-24 21:47:27 --> URI Class Initialized
INFO - 2017-01-24 21:47:27 --> Router Class Initialized
INFO - 2017-01-24 21:47:27 --> Output Class Initialized
INFO - 2017-01-24 21:47:27 --> Security Class Initialized
DEBUG - 2017-01-24 21:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:47:27 --> Input Class Initialized
INFO - 2017-01-24 21:47:27 --> Language Class Initialized
INFO - 2017-01-24 21:47:27 --> Loader Class Initialized
INFO - 2017-01-24 21:47:27 --> Database Driver Class Initialized
INFO - 2017-01-24 21:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:47:27 --> Controller Class Initialized
INFO - 2017-01-24 21:47:27 --> Helper loaded: date_helper
INFO - 2017-01-24 21:47:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:47:27 --> Helper loaded: form_helper
INFO - 2017-01-24 21:47:27 --> Form Validation Class Initialized
INFO - 2017-01-24 21:47:27 --> Final output sent to browser
DEBUG - 2017-01-24 21:47:27 --> Total execution time: 0.0824
INFO - 2017-01-24 21:47:27 --> Config Class Initialized
INFO - 2017-01-24 21:47:27 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:47:27 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:47:27 --> Utf8 Class Initialized
INFO - 2017-01-24 21:47:27 --> URI Class Initialized
INFO - 2017-01-24 21:47:27 --> Router Class Initialized
INFO - 2017-01-24 21:47:27 --> Output Class Initialized
INFO - 2017-01-24 21:47:27 --> Security Class Initialized
DEBUG - 2017-01-24 21:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:47:27 --> Input Class Initialized
INFO - 2017-01-24 21:47:27 --> Language Class Initialized
INFO - 2017-01-24 21:47:27 --> Loader Class Initialized
INFO - 2017-01-24 21:47:27 --> Database Driver Class Initialized
INFO - 2017-01-24 21:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:47:27 --> Controller Class Initialized
INFO - 2017-01-24 21:47:27 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:47:27 --> Final output sent to browser
DEBUG - 2017-01-24 21:47:27 --> Total execution time: 0.0202
INFO - 2017-01-24 21:47:29 --> Config Class Initialized
INFO - 2017-01-24 21:47:29 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:47:29 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:47:29 --> Utf8 Class Initialized
INFO - 2017-01-24 21:47:29 --> URI Class Initialized
INFO - 2017-01-24 21:47:29 --> Router Class Initialized
INFO - 2017-01-24 21:47:29 --> Output Class Initialized
INFO - 2017-01-24 21:47:29 --> Security Class Initialized
DEBUG - 2017-01-24 21:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:47:29 --> Input Class Initialized
INFO - 2017-01-24 21:47:29 --> Language Class Initialized
INFO - 2017-01-24 21:47:29 --> Loader Class Initialized
INFO - 2017-01-24 21:47:29 --> Config Class Initialized
INFO - 2017-01-24 21:47:29 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:47:29 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:47:29 --> Utf8 Class Initialized
INFO - 2017-01-24 21:47:29 --> URI Class Initialized
INFO - 2017-01-24 21:47:29 --> Router Class Initialized
INFO - 2017-01-24 21:47:29 --> Database Driver Class Initialized
INFO - 2017-01-24 21:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:47:29 --> Controller Class Initialized
INFO - 2017-01-24 21:47:29 --> Helper loaded: date_helper
INFO - 2017-01-24 21:47:29 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:47:29 --> Helper loaded: form_helper
INFO - 2017-01-24 21:47:29 --> Form Validation Class Initialized
INFO - 2017-01-24 21:47:29 --> Final output sent to browser
DEBUG - 2017-01-24 21:47:29 --> Total execution time: 0.0363
INFO - 2017-01-24 21:47:29 --> Output Class Initialized
INFO - 2017-01-24 21:47:29 --> Security Class Initialized
DEBUG - 2017-01-24 21:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:47:29 --> Input Class Initialized
INFO - 2017-01-24 21:47:29 --> Language Class Initialized
INFO - 2017-01-24 21:47:29 --> Loader Class Initialized
INFO - 2017-01-24 21:47:29 --> Database Driver Class Initialized
INFO - 2017-01-24 21:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:47:29 --> Controller Class Initialized
INFO - 2017-01-24 21:47:29 --> Helper loaded: date_helper
INFO - 2017-01-24 21:47:29 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:47:29 --> Helper loaded: form_helper
INFO - 2017-01-24 21:47:29 --> Form Validation Class Initialized
INFO - 2017-01-24 21:47:29 --> Final output sent to browser
DEBUG - 2017-01-24 21:47:29 --> Total execution time: 0.0794
INFO - 2017-01-24 21:50:55 --> Config Class Initialized
INFO - 2017-01-24 21:50:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:50:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:50:55 --> Utf8 Class Initialized
INFO - 2017-01-24 21:50:55 --> URI Class Initialized
INFO - 2017-01-24 21:50:55 --> Router Class Initialized
INFO - 2017-01-24 21:50:55 --> Output Class Initialized
INFO - 2017-01-24 21:50:55 --> Security Class Initialized
DEBUG - 2017-01-24 21:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:50:55 --> Input Class Initialized
INFO - 2017-01-24 21:50:55 --> Language Class Initialized
INFO - 2017-01-24 21:50:55 --> Loader Class Initialized
INFO - 2017-01-24 21:50:55 --> Database Driver Class Initialized
INFO - 2017-01-24 21:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:50:55 --> Controller Class Initialized
INFO - 2017-01-24 21:50:55 --> Helper loaded: date_helper
INFO - 2017-01-24 21:50:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:50:55 --> Helper loaded: form_helper
INFO - 2017-01-24 21:50:55 --> Form Validation Class Initialized
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:50:55 --> Final output sent to browser
DEBUG - 2017-01-24 21:50:55 --> Total execution time: 0.0227
INFO - 2017-01-24 21:50:55 --> Config Class Initialized
INFO - 2017-01-24 21:50:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:50:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:50:55 --> Utf8 Class Initialized
INFO - 2017-01-24 21:50:55 --> URI Class Initialized
INFO - 2017-01-24 21:50:55 --> Router Class Initialized
INFO - 2017-01-24 21:50:55 --> Output Class Initialized
INFO - 2017-01-24 21:50:55 --> Security Class Initialized
DEBUG - 2017-01-24 21:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:50:55 --> Input Class Initialized
INFO - 2017-01-24 21:50:55 --> Language Class Initialized
INFO - 2017-01-24 21:50:55 --> Loader Class Initialized
INFO - 2017-01-24 21:50:55 --> Database Driver Class Initialized
INFO - 2017-01-24 21:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:50:55 --> Controller Class Initialized
INFO - 2017-01-24 21:50:55 --> Helper loaded: date_helper
INFO - 2017-01-24 21:50:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:50:55 --> Helper loaded: form_helper
INFO - 2017-01-24 21:50:55 --> Form Validation Class Initialized
INFO - 2017-01-24 21:50:55 --> Final output sent to browser
DEBUG - 2017-01-24 21:50:55 --> Total execution time: 0.0392
INFO - 2017-01-24 21:50:55 --> Config Class Initialized
INFO - 2017-01-24 21:50:55 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:50:55 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:50:55 --> Utf8 Class Initialized
INFO - 2017-01-24 21:50:55 --> URI Class Initialized
INFO - 2017-01-24 21:50:55 --> Router Class Initialized
INFO - 2017-01-24 21:50:55 --> Output Class Initialized
INFO - 2017-01-24 21:50:55 --> Security Class Initialized
DEBUG - 2017-01-24 21:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:50:55 --> Input Class Initialized
INFO - 2017-01-24 21:50:55 --> Language Class Initialized
INFO - 2017-01-24 21:50:55 --> Loader Class Initialized
INFO - 2017-01-24 21:50:55 --> Database Driver Class Initialized
INFO - 2017-01-24 21:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:50:55 --> Controller Class Initialized
INFO - 2017-01-24 21:50:55 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:50:55 --> Final output sent to browser
DEBUG - 2017-01-24 21:50:55 --> Total execution time: 0.0690
INFO - 2017-01-24 21:50:56 --> Config Class Initialized
INFO - 2017-01-24 21:50:56 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:50:56 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:50:56 --> Utf8 Class Initialized
INFO - 2017-01-24 21:50:56 --> URI Class Initialized
INFO - 2017-01-24 21:50:56 --> Router Class Initialized
INFO - 2017-01-24 21:50:56 --> Output Class Initialized
INFO - 2017-01-24 21:50:56 --> Security Class Initialized
DEBUG - 2017-01-24 21:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:50:56 --> Input Class Initialized
INFO - 2017-01-24 21:50:56 --> Language Class Initialized
INFO - 2017-01-24 21:50:56 --> Loader Class Initialized
INFO - 2017-01-24 21:50:56 --> Database Driver Class Initialized
INFO - 2017-01-24 21:50:56 --> Config Class Initialized
INFO - 2017-01-24 21:50:56 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:50:56 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:50:56 --> Utf8 Class Initialized
INFO - 2017-01-24 21:50:56 --> URI Class Initialized
INFO - 2017-01-24 21:50:56 --> Router Class Initialized
INFO - 2017-01-24 21:50:56 --> Output Class Initialized
INFO - 2017-01-24 21:50:56 --> Security Class Initialized
DEBUG - 2017-01-24 21:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:50:56 --> Input Class Initialized
INFO - 2017-01-24 21:50:56 --> Language Class Initialized
INFO - 2017-01-24 21:50:56 --> Loader Class Initialized
INFO - 2017-01-24 21:50:56 --> Database Driver Class Initialized
INFO - 2017-01-24 21:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:50:56 --> Controller Class Initialized
INFO - 2017-01-24 21:50:56 --> Helper loaded: date_helper
INFO - 2017-01-24 21:50:56 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:50:56 --> Helper loaded: form_helper
INFO - 2017-01-24 21:50:56 --> Form Validation Class Initialized
INFO - 2017-01-24 21:50:56 --> Final output sent to browser
DEBUG - 2017-01-24 21:50:56 --> Total execution time: 0.1001
INFO - 2017-01-24 21:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:50:56 --> Controller Class Initialized
INFO - 2017-01-24 21:50:56 --> Helper loaded: date_helper
INFO - 2017-01-24 21:50:56 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:50:56 --> Helper loaded: form_helper
INFO - 2017-01-24 21:50:56 --> Form Validation Class Initialized
INFO - 2017-01-24 21:50:56 --> Final output sent to browser
DEBUG - 2017-01-24 21:50:56 --> Total execution time: 0.0340
INFO - 2017-01-24 21:51:33 --> Config Class Initialized
INFO - 2017-01-24 21:51:33 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:51:33 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:51:33 --> Utf8 Class Initialized
INFO - 2017-01-24 21:51:33 --> URI Class Initialized
INFO - 2017-01-24 21:51:33 --> Router Class Initialized
INFO - 2017-01-24 21:51:33 --> Output Class Initialized
INFO - 2017-01-24 21:51:33 --> Security Class Initialized
DEBUG - 2017-01-24 21:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:51:33 --> Input Class Initialized
INFO - 2017-01-24 21:51:33 --> Language Class Initialized
INFO - 2017-01-24 21:51:33 --> Loader Class Initialized
INFO - 2017-01-24 21:51:33 --> Database Driver Class Initialized
INFO - 2017-01-24 21:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:51:33 --> Controller Class Initialized
INFO - 2017-01-24 21:51:33 --> Helper loaded: date_helper
INFO - 2017-01-24 21:51:33 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:51:33 --> Helper loaded: form_helper
INFO - 2017-01-24 21:51:33 --> Form Validation Class Initialized
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:51:33 --> Final output sent to browser
DEBUG - 2017-01-24 21:51:33 --> Total execution time: 0.0246
INFO - 2017-01-24 21:51:33 --> Config Class Initialized
INFO - 2017-01-24 21:51:33 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:51:33 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:51:33 --> Utf8 Class Initialized
INFO - 2017-01-24 21:51:33 --> URI Class Initialized
INFO - 2017-01-24 21:51:33 --> Router Class Initialized
INFO - 2017-01-24 21:51:33 --> Output Class Initialized
INFO - 2017-01-24 21:51:33 --> Security Class Initialized
DEBUG - 2017-01-24 21:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:51:33 --> Input Class Initialized
INFO - 2017-01-24 21:51:33 --> Language Class Initialized
INFO - 2017-01-24 21:51:33 --> Loader Class Initialized
INFO - 2017-01-24 21:51:33 --> Database Driver Class Initialized
INFO - 2017-01-24 21:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:51:33 --> Controller Class Initialized
INFO - 2017-01-24 21:51:33 --> Helper loaded: date_helper
INFO - 2017-01-24 21:51:33 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:51:33 --> Helper loaded: form_helper
INFO - 2017-01-24 21:51:33 --> Form Validation Class Initialized
INFO - 2017-01-24 21:51:33 --> Final output sent to browser
DEBUG - 2017-01-24 21:51:33 --> Total execution time: 0.0441
INFO - 2017-01-24 21:51:33 --> Config Class Initialized
INFO - 2017-01-24 21:51:33 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:51:33 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:51:33 --> Utf8 Class Initialized
INFO - 2017-01-24 21:51:33 --> URI Class Initialized
INFO - 2017-01-24 21:51:33 --> Router Class Initialized
INFO - 2017-01-24 21:51:33 --> Output Class Initialized
INFO - 2017-01-24 21:51:33 --> Security Class Initialized
DEBUG - 2017-01-24 21:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:51:33 --> Input Class Initialized
INFO - 2017-01-24 21:51:33 --> Language Class Initialized
INFO - 2017-01-24 21:51:33 --> Loader Class Initialized
INFO - 2017-01-24 21:51:33 --> Database Driver Class Initialized
INFO - 2017-01-24 21:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:51:33 --> Controller Class Initialized
INFO - 2017-01-24 21:51:33 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:51:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:51:33 --> Final output sent to browser
DEBUG - 2017-01-24 21:51:33 --> Total execution time: 0.0146
INFO - 2017-01-24 21:51:35 --> Config Class Initialized
INFO - 2017-01-24 21:51:35 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:51:35 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:51:35 --> Utf8 Class Initialized
INFO - 2017-01-24 21:51:35 --> URI Class Initialized
INFO - 2017-01-24 21:51:35 --> Router Class Initialized
INFO - 2017-01-24 21:51:35 --> Output Class Initialized
INFO - 2017-01-24 21:51:35 --> Security Class Initialized
DEBUG - 2017-01-24 21:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:51:35 --> Input Class Initialized
INFO - 2017-01-24 21:51:35 --> Language Class Initialized
INFO - 2017-01-24 21:51:35 --> Loader Class Initialized
INFO - 2017-01-24 21:51:35 --> Config Class Initialized
INFO - 2017-01-24 21:51:35 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:51:35 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:51:35 --> Utf8 Class Initialized
INFO - 2017-01-24 21:51:35 --> URI Class Initialized
INFO - 2017-01-24 21:51:35 --> Router Class Initialized
INFO - 2017-01-24 21:51:35 --> Output Class Initialized
INFO - 2017-01-24 21:51:35 --> Security Class Initialized
DEBUG - 2017-01-24 21:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:51:35 --> Input Class Initialized
INFO - 2017-01-24 21:51:35 --> Language Class Initialized
INFO - 2017-01-24 21:51:35 --> Loader Class Initialized
INFO - 2017-01-24 21:51:35 --> Database Driver Class Initialized
INFO - 2017-01-24 21:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:51:35 --> Controller Class Initialized
INFO - 2017-01-24 21:51:35 --> Helper loaded: date_helper
INFO - 2017-01-24 21:51:35 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:51:35 --> Helper loaded: form_helper
INFO - 2017-01-24 21:51:35 --> Form Validation Class Initialized
INFO - 2017-01-24 21:51:35 --> Final output sent to browser
DEBUG - 2017-01-24 21:51:35 --> Total execution time: 0.0808
INFO - 2017-01-24 21:51:35 --> Database Driver Class Initialized
INFO - 2017-01-24 21:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:51:35 --> Controller Class Initialized
INFO - 2017-01-24 21:51:35 --> Helper loaded: date_helper
INFO - 2017-01-24 21:51:35 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:51:35 --> Helper loaded: form_helper
INFO - 2017-01-24 21:51:35 --> Form Validation Class Initialized
INFO - 2017-01-24 21:51:35 --> Final output sent to browser
DEBUG - 2017-01-24 21:51:35 --> Total execution time: 0.0802
INFO - 2017-01-24 21:52:51 --> Config Class Initialized
INFO - 2017-01-24 21:52:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:52:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:52:51 --> Utf8 Class Initialized
INFO - 2017-01-24 21:52:51 --> URI Class Initialized
INFO - 2017-01-24 21:52:51 --> Router Class Initialized
INFO - 2017-01-24 21:52:51 --> Output Class Initialized
INFO - 2017-01-24 21:52:51 --> Security Class Initialized
DEBUG - 2017-01-24 21:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:52:51 --> Input Class Initialized
INFO - 2017-01-24 21:52:51 --> Language Class Initialized
INFO - 2017-01-24 21:52:51 --> Loader Class Initialized
INFO - 2017-01-24 21:52:51 --> Database Driver Class Initialized
INFO - 2017-01-24 21:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:52:51 --> Controller Class Initialized
INFO - 2017-01-24 21:52:51 --> Helper loaded: date_helper
INFO - 2017-01-24 21:52:51 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:52:51 --> Helper loaded: form_helper
INFO - 2017-01-24 21:52:51 --> Form Validation Class Initialized
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:52:51 --> Final output sent to browser
DEBUG - 2017-01-24 21:52:51 --> Total execution time: 0.0152
INFO - 2017-01-24 21:52:51 --> Config Class Initialized
INFO - 2017-01-24 21:52:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:52:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:52:51 --> Utf8 Class Initialized
INFO - 2017-01-24 21:52:51 --> URI Class Initialized
INFO - 2017-01-24 21:52:51 --> Router Class Initialized
INFO - 2017-01-24 21:52:51 --> Output Class Initialized
INFO - 2017-01-24 21:52:51 --> Security Class Initialized
DEBUG - 2017-01-24 21:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:52:51 --> Input Class Initialized
INFO - 2017-01-24 21:52:51 --> Language Class Initialized
INFO - 2017-01-24 21:52:51 --> Loader Class Initialized
INFO - 2017-01-24 21:52:51 --> Database Driver Class Initialized
INFO - 2017-01-24 21:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:52:51 --> Controller Class Initialized
INFO - 2017-01-24 21:52:51 --> Helper loaded: date_helper
INFO - 2017-01-24 21:52:51 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:52:51 --> Helper loaded: form_helper
INFO - 2017-01-24 21:52:51 --> Form Validation Class Initialized
INFO - 2017-01-24 21:52:51 --> Final output sent to browser
DEBUG - 2017-01-24 21:52:51 --> Total execution time: 0.0937
INFO - 2017-01-24 21:52:51 --> Config Class Initialized
INFO - 2017-01-24 21:52:51 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:52:51 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:52:51 --> Utf8 Class Initialized
INFO - 2017-01-24 21:52:51 --> URI Class Initialized
INFO - 2017-01-24 21:52:51 --> Router Class Initialized
INFO - 2017-01-24 21:52:51 --> Output Class Initialized
INFO - 2017-01-24 21:52:51 --> Security Class Initialized
DEBUG - 2017-01-24 21:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:52:51 --> Input Class Initialized
INFO - 2017-01-24 21:52:51 --> Language Class Initialized
INFO - 2017-01-24 21:52:51 --> Loader Class Initialized
INFO - 2017-01-24 21:52:51 --> Database Driver Class Initialized
INFO - 2017-01-24 21:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:52:51 --> Controller Class Initialized
INFO - 2017-01-24 21:52:51 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:52:51 --> Final output sent to browser
DEBUG - 2017-01-24 21:52:51 --> Total execution time: 0.0138
INFO - 2017-01-24 21:52:53 --> Config Class Initialized
INFO - 2017-01-24 21:52:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:52:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:52:53 --> Utf8 Class Initialized
INFO - 2017-01-24 21:52:53 --> URI Class Initialized
INFO - 2017-01-24 21:52:53 --> Router Class Initialized
INFO - 2017-01-24 21:52:53 --> Output Class Initialized
INFO - 2017-01-24 21:52:53 --> Security Class Initialized
DEBUG - 2017-01-24 21:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:52:53 --> Input Class Initialized
INFO - 2017-01-24 21:52:53 --> Language Class Initialized
INFO - 2017-01-24 21:52:53 --> Loader Class Initialized
INFO - 2017-01-24 21:52:53 --> Database Driver Class Initialized
INFO - 2017-01-24 21:52:53 --> Config Class Initialized
INFO - 2017-01-24 21:52:53 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:52:53 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:52:53 --> Utf8 Class Initialized
INFO - 2017-01-24 21:52:53 --> URI Class Initialized
INFO - 2017-01-24 21:52:53 --> Router Class Initialized
INFO - 2017-01-24 21:52:53 --> Output Class Initialized
INFO - 2017-01-24 21:52:53 --> Security Class Initialized
DEBUG - 2017-01-24 21:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:52:53 --> Input Class Initialized
INFO - 2017-01-24 21:52:53 --> Language Class Initialized
INFO - 2017-01-24 21:52:53 --> Loader Class Initialized
INFO - 2017-01-24 21:52:53 --> Database Driver Class Initialized
INFO - 2017-01-24 21:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:52:53 --> Controller Class Initialized
INFO - 2017-01-24 21:52:53 --> Helper loaded: date_helper
INFO - 2017-01-24 21:52:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:52:53 --> Helper loaded: form_helper
INFO - 2017-01-24 21:52:53 --> Form Validation Class Initialized
INFO - 2017-01-24 21:52:53 --> Final output sent to browser
DEBUG - 2017-01-24 21:52:53 --> Total execution time: 0.1105
INFO - 2017-01-24 21:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:52:53 --> Controller Class Initialized
INFO - 2017-01-24 21:52:53 --> Helper loaded: date_helper
INFO - 2017-01-24 21:52:53 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:52:53 --> Helper loaded: form_helper
INFO - 2017-01-24 21:52:53 --> Form Validation Class Initialized
INFO - 2017-01-24 21:52:53 --> Final output sent to browser
DEBUG - 2017-01-24 21:52:53 --> Total execution time: 0.0334
INFO - 2017-01-24 21:53:01 --> Config Class Initialized
INFO - 2017-01-24 21:53:01 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:53:01 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:53:01 --> Utf8 Class Initialized
INFO - 2017-01-24 21:53:01 --> URI Class Initialized
INFO - 2017-01-24 21:53:01 --> Router Class Initialized
INFO - 2017-01-24 21:53:01 --> Output Class Initialized
INFO - 2017-01-24 21:53:01 --> Security Class Initialized
DEBUG - 2017-01-24 21:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:53:01 --> Input Class Initialized
INFO - 2017-01-24 21:53:01 --> Language Class Initialized
ERROR - 2017-01-24 21:53:01 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:54:13 --> Config Class Initialized
INFO - 2017-01-24 21:54:13 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:13 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:13 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:13 --> URI Class Initialized
INFO - 2017-01-24 21:54:13 --> Router Class Initialized
INFO - 2017-01-24 21:54:13 --> Output Class Initialized
INFO - 2017-01-24 21:54:13 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:13 --> Input Class Initialized
INFO - 2017-01-24 21:54:13 --> Language Class Initialized
INFO - 2017-01-24 21:54:13 --> Loader Class Initialized
INFO - 2017-01-24 21:54:13 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:13 --> Controller Class Initialized
INFO - 2017-01-24 21:54:13 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:13 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:13 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:13 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:54:13 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:13 --> Total execution time: 0.0153
INFO - 2017-01-24 21:54:13 --> Config Class Initialized
INFO - 2017-01-24 21:54:13 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:13 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:13 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:13 --> URI Class Initialized
INFO - 2017-01-24 21:54:13 --> Router Class Initialized
INFO - 2017-01-24 21:54:13 --> Output Class Initialized
INFO - 2017-01-24 21:54:13 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:13 --> Input Class Initialized
INFO - 2017-01-24 21:54:13 --> Language Class Initialized
ERROR - 2017-01-24 21:54:13 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:54:13 --> Config Class Initialized
INFO - 2017-01-24 21:54:13 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:13 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:13 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:13 --> URI Class Initialized
INFO - 2017-01-24 21:54:13 --> Router Class Initialized
INFO - 2017-01-24 21:54:13 --> Output Class Initialized
INFO - 2017-01-24 21:54:13 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:13 --> Input Class Initialized
INFO - 2017-01-24 21:54:13 --> Language Class Initialized
INFO - 2017-01-24 21:54:13 --> Loader Class Initialized
INFO - 2017-01-24 21:54:13 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:13 --> Controller Class Initialized
INFO - 2017-01-24 21:54:13 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:13 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:13 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:13 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:13 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:13 --> Total execution time: 0.1057
INFO - 2017-01-24 21:54:13 --> Config Class Initialized
INFO - 2017-01-24 21:54:13 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:13 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:13 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:13 --> URI Class Initialized
INFO - 2017-01-24 21:54:13 --> Router Class Initialized
INFO - 2017-01-24 21:54:13 --> Output Class Initialized
INFO - 2017-01-24 21:54:13 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:13 --> Input Class Initialized
INFO - 2017-01-24 21:54:13 --> Language Class Initialized
INFO - 2017-01-24 21:54:13 --> Loader Class Initialized
INFO - 2017-01-24 21:54:13 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:13 --> Controller Class Initialized
INFO - 2017-01-24 21:54:13 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:54:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:54:13 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:13 --> Total execution time: 0.0151
INFO - 2017-01-24 21:54:16 --> Config Class Initialized
INFO - 2017-01-24 21:54:16 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:16 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:16 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:16 --> URI Class Initialized
INFO - 2017-01-24 21:54:16 --> Router Class Initialized
INFO - 2017-01-24 21:54:16 --> Output Class Initialized
INFO - 2017-01-24 21:54:16 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:16 --> Input Class Initialized
INFO - 2017-01-24 21:54:16 --> Language Class Initialized
INFO - 2017-01-24 21:54:16 --> Loader Class Initialized
INFO - 2017-01-24 21:54:16 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:16 --> Controller Class Initialized
INFO - 2017-01-24 21:54:16 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:16 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:16 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:16 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:16 --> Config Class Initialized
INFO - 2017-01-24 21:54:16 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:16 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:16 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:16 --> URI Class Initialized
INFO - 2017-01-24 21:54:16 --> Router Class Initialized
INFO - 2017-01-24 21:54:16 --> Output Class Initialized
INFO - 2017-01-24 21:54:16 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:16 --> Input Class Initialized
INFO - 2017-01-24 21:54:16 --> Language Class Initialized
INFO - 2017-01-24 21:54:16 --> Loader Class Initialized
INFO - 2017-01-24 21:54:16 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:16 --> Total execution time: 0.0627
INFO - 2017-01-24 21:54:16 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:16 --> Controller Class Initialized
INFO - 2017-01-24 21:54:16 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:16 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:16 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:16 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:16 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:16 --> Total execution time: 0.0868
INFO - 2017-01-24 21:54:36 --> Config Class Initialized
INFO - 2017-01-24 21:54:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:36 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:36 --> URI Class Initialized
INFO - 2017-01-24 21:54:36 --> Router Class Initialized
INFO - 2017-01-24 21:54:36 --> Output Class Initialized
INFO - 2017-01-24 21:54:36 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:36 --> Input Class Initialized
INFO - 2017-01-24 21:54:36 --> Language Class Initialized
INFO - 2017-01-24 21:54:36 --> Loader Class Initialized
INFO - 2017-01-24 21:54:36 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:36 --> Controller Class Initialized
INFO - 2017-01-24 21:54:36 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:36 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:36 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:36 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:54:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:54:36 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:36 --> Total execution time: 0.0159
INFO - 2017-01-24 21:54:36 --> Config Class Initialized
INFO - 2017-01-24 21:54:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:36 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:36 --> URI Class Initialized
INFO - 2017-01-24 21:54:36 --> Router Class Initialized
INFO - 2017-01-24 21:54:36 --> Output Class Initialized
INFO - 2017-01-24 21:54:36 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:36 --> Input Class Initialized
INFO - 2017-01-24 21:54:36 --> Language Class Initialized
ERROR - 2017-01-24 21:54:36 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:54:36 --> Config Class Initialized
INFO - 2017-01-24 21:54:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:36 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:36 --> URI Class Initialized
INFO - 2017-01-24 21:54:36 --> Router Class Initialized
INFO - 2017-01-24 21:54:36 --> Output Class Initialized
INFO - 2017-01-24 21:54:36 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:36 --> Input Class Initialized
INFO - 2017-01-24 21:54:36 --> Language Class Initialized
INFO - 2017-01-24 21:54:36 --> Loader Class Initialized
INFO - 2017-01-24 21:54:36 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:36 --> Controller Class Initialized
INFO - 2017-01-24 21:54:36 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:36 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:36 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:36 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:36 --> Config Class Initialized
INFO - 2017-01-24 21:54:36 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:36 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:36 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:36 --> URI Class Initialized
INFO - 2017-01-24 21:54:36 --> Router Class Initialized
INFO - 2017-01-24 21:54:36 --> Output Class Initialized
INFO - 2017-01-24 21:54:36 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:36 --> Input Class Initialized
INFO - 2017-01-24 21:54:36 --> Language Class Initialized
INFO - 2017-01-24 21:54:36 --> Loader Class Initialized
INFO - 2017-01-24 21:54:37 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:37 --> Total execution time: 0.0872
INFO - 2017-01-24 21:54:37 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:37 --> Controller Class Initialized
INFO - 2017-01-24 21:54:37 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:54:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:54:37 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:37 --> Total execution time: 0.0728
INFO - 2017-01-24 21:54:38 --> Config Class Initialized
INFO - 2017-01-24 21:54:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:38 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:38 --> URI Class Initialized
INFO - 2017-01-24 21:54:38 --> Router Class Initialized
INFO - 2017-01-24 21:54:38 --> Output Class Initialized
INFO - 2017-01-24 21:54:38 --> Security Class Initialized
DEBUG - 2017-01-24 21:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:38 --> Input Class Initialized
INFO - 2017-01-24 21:54:38 --> Language Class Initialized
INFO - 2017-01-24 21:54:38 --> Loader Class Initialized
INFO - 2017-01-24 21:54:38 --> Config Class Initialized
INFO - 2017-01-24 21:54:38 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:54:38 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:54:38 --> Utf8 Class Initialized
INFO - 2017-01-24 21:54:38 --> URI Class Initialized
INFO - 2017-01-24 21:54:38 --> Router Class Initialized
INFO - 2017-01-24 21:54:38 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:38 --> Output Class Initialized
INFO - 2017-01-24 21:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:38 --> Controller Class Initialized
INFO - 2017-01-24 21:54:38 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:38 --> Security Class Initialized
INFO - 2017-01-24 21:54:38 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:38 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:38 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:38 --> Total execution time: 0.0821
DEBUG - 2017-01-24 21:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:54:38 --> Input Class Initialized
INFO - 2017-01-24 21:54:38 --> Language Class Initialized
INFO - 2017-01-24 21:54:38 --> Loader Class Initialized
INFO - 2017-01-24 21:54:38 --> Database Driver Class Initialized
INFO - 2017-01-24 21:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:54:38 --> Controller Class Initialized
INFO - 2017-01-24 21:54:38 --> Helper loaded: date_helper
INFO - 2017-01-24 21:54:38 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:54:38 --> Helper loaded: form_helper
INFO - 2017-01-24 21:54:38 --> Form Validation Class Initialized
INFO - 2017-01-24 21:54:38 --> Final output sent to browser
DEBUG - 2017-01-24 21:54:38 --> Total execution time: 0.0818
INFO - 2017-01-24 21:56:23 --> Config Class Initialized
INFO - 2017-01-24 21:56:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:56:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:56:23 --> Utf8 Class Initialized
INFO - 2017-01-24 21:56:23 --> URI Class Initialized
INFO - 2017-01-24 21:56:23 --> Router Class Initialized
INFO - 2017-01-24 21:56:23 --> Output Class Initialized
INFO - 2017-01-24 21:56:23 --> Security Class Initialized
DEBUG - 2017-01-24 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:56:23 --> Input Class Initialized
INFO - 2017-01-24 21:56:23 --> Language Class Initialized
INFO - 2017-01-24 21:56:23 --> Loader Class Initialized
INFO - 2017-01-24 21:56:23 --> Database Driver Class Initialized
INFO - 2017-01-24 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:56:23 --> Controller Class Initialized
INFO - 2017-01-24 21:56:23 --> Helper loaded: date_helper
INFO - 2017-01-24 21:56:23 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:56:23 --> Helper loaded: form_helper
INFO - 2017-01-24 21:56:23 --> Form Validation Class Initialized
INFO - 2017-01-24 21:56:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:56:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:56:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:56:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:56:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:56:23 --> Final output sent to browser
DEBUG - 2017-01-24 21:56:23 --> Total execution time: 0.0441
INFO - 2017-01-24 21:56:23 --> Config Class Initialized
INFO - 2017-01-24 21:56:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:56:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:56:23 --> Utf8 Class Initialized
INFO - 2017-01-24 21:56:23 --> URI Class Initialized
INFO - 2017-01-24 21:56:23 --> Router Class Initialized
INFO - 2017-01-24 21:56:23 --> Output Class Initialized
INFO - 2017-01-24 21:56:23 --> Security Class Initialized
DEBUG - 2017-01-24 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:56:23 --> Input Class Initialized
INFO - 2017-01-24 21:56:23 --> Language Class Initialized
ERROR - 2017-01-24 21:56:23 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:56:23 --> Config Class Initialized
INFO - 2017-01-24 21:56:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:56:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:56:23 --> Utf8 Class Initialized
INFO - 2017-01-24 21:56:23 --> URI Class Initialized
INFO - 2017-01-24 21:56:23 --> Router Class Initialized
INFO - 2017-01-24 21:56:23 --> Output Class Initialized
INFO - 2017-01-24 21:56:23 --> Security Class Initialized
DEBUG - 2017-01-24 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:56:23 --> Input Class Initialized
INFO - 2017-01-24 21:56:23 --> Language Class Initialized
INFO - 2017-01-24 21:56:23 --> Loader Class Initialized
INFO - 2017-01-24 21:56:23 --> Database Driver Class Initialized
INFO - 2017-01-24 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:56:23 --> Controller Class Initialized
INFO - 2017-01-24 21:56:23 --> Helper loaded: date_helper
INFO - 2017-01-24 21:56:23 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:56:23 --> Helper loaded: form_helper
INFO - 2017-01-24 21:56:23 --> Form Validation Class Initialized
INFO - 2017-01-24 21:56:23 --> Final output sent to browser
DEBUG - 2017-01-24 21:56:23 --> Total execution time: 0.0161
INFO - 2017-01-24 21:56:23 --> Config Class Initialized
INFO - 2017-01-24 21:56:23 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:56:23 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:56:23 --> Utf8 Class Initialized
INFO - 2017-01-24 21:56:23 --> URI Class Initialized
INFO - 2017-01-24 21:56:23 --> Router Class Initialized
INFO - 2017-01-24 21:56:23 --> Output Class Initialized
INFO - 2017-01-24 21:56:23 --> Security Class Initialized
DEBUG - 2017-01-24 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:56:23 --> Input Class Initialized
INFO - 2017-01-24 21:56:23 --> Language Class Initialized
INFO - 2017-01-24 21:56:23 --> Loader Class Initialized
INFO - 2017-01-24 21:56:23 --> Database Driver Class Initialized
INFO - 2017-01-24 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:56:23 --> Controller Class Initialized
INFO - 2017-01-24 21:56:24 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:56:24 --> Final output sent to browser
DEBUG - 2017-01-24 21:56:24 --> Total execution time: 0.0904
INFO - 2017-01-24 21:56:25 --> Config Class Initialized
INFO - 2017-01-24 21:56:25 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:56:25 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:56:25 --> Utf8 Class Initialized
INFO - 2017-01-24 21:56:25 --> URI Class Initialized
INFO - 2017-01-24 21:56:25 --> Router Class Initialized
INFO - 2017-01-24 21:56:25 --> Output Class Initialized
INFO - 2017-01-24 21:56:25 --> Security Class Initialized
DEBUG - 2017-01-24 21:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:56:25 --> Input Class Initialized
INFO - 2017-01-24 21:56:25 --> Language Class Initialized
INFO - 2017-01-24 21:56:25 --> Loader Class Initialized
INFO - 2017-01-24 21:56:25 --> Database Driver Class Initialized
INFO - 2017-01-24 21:56:25 --> Config Class Initialized
INFO - 2017-01-24 21:56:25 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:56:25 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:56:25 --> Utf8 Class Initialized
INFO - 2017-01-24 21:56:25 --> URI Class Initialized
INFO - 2017-01-24 21:56:25 --> Router Class Initialized
INFO - 2017-01-24 21:56:25 --> Output Class Initialized
INFO - 2017-01-24 21:56:25 --> Security Class Initialized
DEBUG - 2017-01-24 21:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:56:25 --> Input Class Initialized
INFO - 2017-01-24 21:56:25 --> Language Class Initialized
INFO - 2017-01-24 21:56:25 --> Loader Class Initialized
INFO - 2017-01-24 21:56:25 --> Database Driver Class Initialized
INFO - 2017-01-24 21:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:56:25 --> Controller Class Initialized
INFO - 2017-01-24 21:56:25 --> Helper loaded: date_helper
INFO - 2017-01-24 21:56:25 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:56:25 --> Helper loaded: form_helper
INFO - 2017-01-24 21:56:25 --> Form Validation Class Initialized
INFO - 2017-01-24 21:56:25 --> Final output sent to browser
DEBUG - 2017-01-24 21:56:25 --> Total execution time: 0.0395
INFO - 2017-01-24 21:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:56:25 --> Controller Class Initialized
INFO - 2017-01-24 21:56:25 --> Helper loaded: date_helper
INFO - 2017-01-24 21:56:25 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:56:25 --> Helper loaded: form_helper
INFO - 2017-01-24 21:56:25 --> Form Validation Class Initialized
INFO - 2017-01-24 21:56:25 --> Final output sent to browser
DEBUG - 2017-01-24 21:56:25 --> Total execution time: 0.0773
INFO - 2017-01-24 21:57:19 --> Config Class Initialized
INFO - 2017-01-24 21:57:19 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:57:19 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:57:19 --> Utf8 Class Initialized
INFO - 2017-01-24 21:57:19 --> URI Class Initialized
INFO - 2017-01-24 21:57:19 --> Router Class Initialized
INFO - 2017-01-24 21:57:19 --> Output Class Initialized
INFO - 2017-01-24 21:57:19 --> Security Class Initialized
DEBUG - 2017-01-24 21:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:57:19 --> Input Class Initialized
INFO - 2017-01-24 21:57:19 --> Language Class Initialized
INFO - 2017-01-24 21:57:19 --> Loader Class Initialized
INFO - 2017-01-24 21:57:19 --> Database Driver Class Initialized
INFO - 2017-01-24 21:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:57:19 --> Controller Class Initialized
INFO - 2017-01-24 21:57:19 --> Helper loaded: date_helper
INFO - 2017-01-24 21:57:19 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:57:19 --> Helper loaded: form_helper
INFO - 2017-01-24 21:57:19 --> Form Validation Class Initialized
INFO - 2017-01-24 21:57:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:57:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:57:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:57:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:57:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:57:19 --> Final output sent to browser
DEBUG - 2017-01-24 21:57:19 --> Total execution time: 0.0453
INFO - 2017-01-24 21:57:20 --> Config Class Initialized
INFO - 2017-01-24 21:57:20 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:57:20 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:57:20 --> Utf8 Class Initialized
INFO - 2017-01-24 21:57:20 --> URI Class Initialized
INFO - 2017-01-24 21:57:20 --> Router Class Initialized
INFO - 2017-01-24 21:57:20 --> Output Class Initialized
INFO - 2017-01-24 21:57:20 --> Security Class Initialized
DEBUG - 2017-01-24 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:57:20 --> Input Class Initialized
INFO - 2017-01-24 21:57:20 --> Language Class Initialized
ERROR - 2017-01-24 21:57:20 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:57:20 --> Config Class Initialized
INFO - 2017-01-24 21:57:20 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:57:20 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:57:20 --> Utf8 Class Initialized
INFO - 2017-01-24 21:57:20 --> URI Class Initialized
INFO - 2017-01-24 21:57:20 --> Router Class Initialized
INFO - 2017-01-24 21:57:20 --> Output Class Initialized
INFO - 2017-01-24 21:57:20 --> Security Class Initialized
DEBUG - 2017-01-24 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:57:20 --> Input Class Initialized
INFO - 2017-01-24 21:57:20 --> Language Class Initialized
INFO - 2017-01-24 21:57:20 --> Loader Class Initialized
INFO - 2017-01-24 21:57:20 --> Database Driver Class Initialized
INFO - 2017-01-24 21:57:20 --> Config Class Initialized
INFO - 2017-01-24 21:57:20 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:57:20 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:57:20 --> Utf8 Class Initialized
INFO - 2017-01-24 21:57:20 --> URI Class Initialized
INFO - 2017-01-24 21:57:20 --> Router Class Initialized
INFO - 2017-01-24 21:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:57:20 --> Controller Class Initialized
INFO - 2017-01-24 21:57:20 --> Helper loaded: date_helper
INFO - 2017-01-24 21:57:20 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:57:20 --> Helper loaded: form_helper
INFO - 2017-01-24 21:57:20 --> Form Validation Class Initialized
INFO - 2017-01-24 21:57:20 --> Final output sent to browser
DEBUG - 2017-01-24 21:57:20 --> Total execution time: 0.0430
INFO - 2017-01-24 21:57:20 --> Output Class Initialized
INFO - 2017-01-24 21:57:20 --> Security Class Initialized
DEBUG - 2017-01-24 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:57:20 --> Input Class Initialized
INFO - 2017-01-24 21:57:20 --> Language Class Initialized
INFO - 2017-01-24 21:57:20 --> Loader Class Initialized
INFO - 2017-01-24 21:57:20 --> Database Driver Class Initialized
INFO - 2017-01-24 21:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:57:20 --> Controller Class Initialized
INFO - 2017-01-24 21:57:20 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:57:20 --> Final output sent to browser
DEBUG - 2017-01-24 21:57:20 --> Total execution time: 0.0765
INFO - 2017-01-24 21:57:22 --> Config Class Initialized
INFO - 2017-01-24 21:57:22 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:57:22 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:57:22 --> Utf8 Class Initialized
INFO - 2017-01-24 21:57:22 --> URI Class Initialized
INFO - 2017-01-24 21:57:22 --> Router Class Initialized
INFO - 2017-01-24 21:57:22 --> Output Class Initialized
INFO - 2017-01-24 21:57:22 --> Security Class Initialized
DEBUG - 2017-01-24 21:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:57:22 --> Input Class Initialized
INFO - 2017-01-24 21:57:22 --> Language Class Initialized
INFO - 2017-01-24 21:57:22 --> Loader Class Initialized
INFO - 2017-01-24 21:57:22 --> Database Driver Class Initialized
INFO - 2017-01-24 21:57:22 --> Config Class Initialized
INFO - 2017-01-24 21:57:22 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:57:22 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:57:22 --> Utf8 Class Initialized
INFO - 2017-01-24 21:57:22 --> URI Class Initialized
INFO - 2017-01-24 21:57:22 --> Router Class Initialized
INFO - 2017-01-24 21:57:22 --> Output Class Initialized
INFO - 2017-01-24 21:57:22 --> Security Class Initialized
DEBUG - 2017-01-24 21:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:57:22 --> Input Class Initialized
INFO - 2017-01-24 21:57:22 --> Language Class Initialized
INFO - 2017-01-24 21:57:22 --> Loader Class Initialized
INFO - 2017-01-24 21:57:22 --> Database Driver Class Initialized
INFO - 2017-01-24 21:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:57:22 --> Controller Class Initialized
INFO - 2017-01-24 21:57:22 --> Helper loaded: date_helper
INFO - 2017-01-24 21:57:22 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:57:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:57:22 --> Helper loaded: form_helper
INFO - 2017-01-24 21:57:22 --> Form Validation Class Initialized
INFO - 2017-01-24 21:57:22 --> Final output sent to browser
DEBUG - 2017-01-24 21:57:22 --> Total execution time: 0.0826
INFO - 2017-01-24 21:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:57:22 --> Controller Class Initialized
INFO - 2017-01-24 21:57:22 --> Helper loaded: date_helper
INFO - 2017-01-24 21:57:22 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:57:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:57:22 --> Helper loaded: form_helper
INFO - 2017-01-24 21:57:22 --> Form Validation Class Initialized
INFO - 2017-01-24 21:57:22 --> Final output sent to browser
DEBUG - 2017-01-24 21:57:22 --> Total execution time: 0.0845
INFO - 2017-01-24 21:58:04 --> Config Class Initialized
INFO - 2017-01-24 21:58:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:58:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:58:04 --> Utf8 Class Initialized
INFO - 2017-01-24 21:58:04 --> URI Class Initialized
INFO - 2017-01-24 21:58:04 --> Router Class Initialized
INFO - 2017-01-24 21:58:04 --> Output Class Initialized
INFO - 2017-01-24 21:58:04 --> Security Class Initialized
DEBUG - 2017-01-24 21:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:58:04 --> Input Class Initialized
INFO - 2017-01-24 21:58:04 --> Language Class Initialized
INFO - 2017-01-24 21:58:04 --> Loader Class Initialized
INFO - 2017-01-24 21:58:04 --> Database Driver Class Initialized
INFO - 2017-01-24 21:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:58:04 --> Controller Class Initialized
INFO - 2017-01-24 21:58:04 --> Helper loaded: date_helper
INFO - 2017-01-24 21:58:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:58:04 --> Helper loaded: form_helper
INFO - 2017-01-24 21:58:04 --> Form Validation Class Initialized
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:58:04 --> Final output sent to browser
DEBUG - 2017-01-24 21:58:04 --> Total execution time: 0.0372
INFO - 2017-01-24 21:58:04 --> Config Class Initialized
INFO - 2017-01-24 21:58:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:58:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:58:04 --> Utf8 Class Initialized
INFO - 2017-01-24 21:58:04 --> URI Class Initialized
INFO - 2017-01-24 21:58:04 --> Router Class Initialized
INFO - 2017-01-24 21:58:04 --> Output Class Initialized
INFO - 2017-01-24 21:58:04 --> Security Class Initialized
DEBUG - 2017-01-24 21:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:58:04 --> Input Class Initialized
INFO - 2017-01-24 21:58:04 --> Language Class Initialized
ERROR - 2017-01-24 21:58:04 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:58:04 --> Config Class Initialized
INFO - 2017-01-24 21:58:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:58:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:58:04 --> Utf8 Class Initialized
INFO - 2017-01-24 21:58:04 --> URI Class Initialized
INFO - 2017-01-24 21:58:04 --> Router Class Initialized
INFO - 2017-01-24 21:58:04 --> Output Class Initialized
INFO - 2017-01-24 21:58:04 --> Security Class Initialized
DEBUG - 2017-01-24 21:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:58:04 --> Input Class Initialized
INFO - 2017-01-24 21:58:04 --> Language Class Initialized
INFO - 2017-01-24 21:58:04 --> Loader Class Initialized
INFO - 2017-01-24 21:58:04 --> Database Driver Class Initialized
INFO - 2017-01-24 21:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:58:04 --> Controller Class Initialized
INFO - 2017-01-24 21:58:04 --> Helper loaded: date_helper
INFO - 2017-01-24 21:58:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:58:04 --> Helper loaded: form_helper
INFO - 2017-01-24 21:58:04 --> Form Validation Class Initialized
INFO - 2017-01-24 21:58:04 --> Final output sent to browser
DEBUG - 2017-01-24 21:58:04 --> Total execution time: 0.0491
INFO - 2017-01-24 21:58:04 --> Config Class Initialized
INFO - 2017-01-24 21:58:04 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:58:04 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:58:04 --> Utf8 Class Initialized
INFO - 2017-01-24 21:58:04 --> URI Class Initialized
INFO - 2017-01-24 21:58:04 --> Router Class Initialized
INFO - 2017-01-24 21:58:04 --> Output Class Initialized
INFO - 2017-01-24 21:58:04 --> Security Class Initialized
DEBUG - 2017-01-24 21:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:58:04 --> Input Class Initialized
INFO - 2017-01-24 21:58:04 --> Language Class Initialized
INFO - 2017-01-24 21:58:04 --> Loader Class Initialized
INFO - 2017-01-24 21:58:04 --> Database Driver Class Initialized
INFO - 2017-01-24 21:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:58:04 --> Controller Class Initialized
INFO - 2017-01-24 21:58:04 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:58:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:58:04 --> Final output sent to browser
DEBUG - 2017-01-24 21:58:04 --> Total execution time: 0.0779
INFO - 2017-01-24 21:58:06 --> Config Class Initialized
INFO - 2017-01-24 21:58:06 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:58:06 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:58:06 --> Utf8 Class Initialized
INFO - 2017-01-24 21:58:06 --> URI Class Initialized
INFO - 2017-01-24 21:58:06 --> Router Class Initialized
INFO - 2017-01-24 21:58:06 --> Output Class Initialized
INFO - 2017-01-24 21:58:06 --> Security Class Initialized
DEBUG - 2017-01-24 21:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:58:06 --> Input Class Initialized
INFO - 2017-01-24 21:58:06 --> Language Class Initialized
INFO - 2017-01-24 21:58:06 --> Loader Class Initialized
INFO - 2017-01-24 21:58:06 --> Database Driver Class Initialized
INFO - 2017-01-24 21:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:58:06 --> Controller Class Initialized
INFO - 2017-01-24 21:58:06 --> Helper loaded: date_helper
INFO - 2017-01-24 21:58:06 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:58:06 --> Helper loaded: form_helper
INFO - 2017-01-24 21:58:06 --> Form Validation Class Initialized
INFO - 2017-01-24 21:58:06 --> Config Class Initialized
INFO - 2017-01-24 21:58:06 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:58:06 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:58:06 --> Utf8 Class Initialized
INFO - 2017-01-24 21:58:06 --> URI Class Initialized
INFO - 2017-01-24 21:58:06 --> Router Class Initialized
INFO - 2017-01-24 21:58:06 --> Output Class Initialized
INFO - 2017-01-24 21:58:06 --> Security Class Initialized
INFO - 2017-01-24 21:58:06 --> Final output sent to browser
DEBUG - 2017-01-24 21:58:06 --> Total execution time: 0.0162
DEBUG - 2017-01-24 21:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:58:06 --> Input Class Initialized
INFO - 2017-01-24 21:58:06 --> Language Class Initialized
INFO - 2017-01-24 21:58:06 --> Loader Class Initialized
INFO - 2017-01-24 21:58:06 --> Database Driver Class Initialized
INFO - 2017-01-24 21:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:58:06 --> Controller Class Initialized
INFO - 2017-01-24 21:58:06 --> Helper loaded: date_helper
INFO - 2017-01-24 21:58:06 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:58:06 --> Helper loaded: form_helper
INFO - 2017-01-24 21:58:06 --> Form Validation Class Initialized
INFO - 2017-01-24 21:58:06 --> Final output sent to browser
DEBUG - 2017-01-24 21:58:06 --> Total execution time: 0.0227
INFO - 2017-01-24 21:59:30 --> Config Class Initialized
INFO - 2017-01-24 21:59:30 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:59:30 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:59:30 --> Utf8 Class Initialized
INFO - 2017-01-24 21:59:30 --> URI Class Initialized
INFO - 2017-01-24 21:59:30 --> Router Class Initialized
INFO - 2017-01-24 21:59:30 --> Output Class Initialized
INFO - 2017-01-24 21:59:30 --> Security Class Initialized
DEBUG - 2017-01-24 21:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:59:30 --> Input Class Initialized
INFO - 2017-01-24 21:59:30 --> Language Class Initialized
INFO - 2017-01-24 21:59:30 --> Loader Class Initialized
INFO - 2017-01-24 21:59:30 --> Database Driver Class Initialized
INFO - 2017-01-24 21:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:59:30 --> Controller Class Initialized
INFO - 2017-01-24 21:59:30 --> Helper loaded: date_helper
INFO - 2017-01-24 21:59:30 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:59:30 --> Helper loaded: form_helper
INFO - 2017-01-24 21:59:30 --> Form Validation Class Initialized
INFO - 2017-01-24 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-24 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-24 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-24 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-24 21:59:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-24 21:59:30 --> Final output sent to browser
DEBUG - 2017-01-24 21:59:30 --> Total execution time: 0.0183
INFO - 2017-01-24 21:59:31 --> Config Class Initialized
INFO - 2017-01-24 21:59:31 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:59:31 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:59:31 --> Utf8 Class Initialized
INFO - 2017-01-24 21:59:31 --> URI Class Initialized
INFO - 2017-01-24 21:59:31 --> Router Class Initialized
INFO - 2017-01-24 21:59:31 --> Output Class Initialized
INFO - 2017-01-24 21:59:31 --> Security Class Initialized
DEBUG - 2017-01-24 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:59:31 --> Input Class Initialized
INFO - 2017-01-24 21:59:31 --> Language Class Initialized
ERROR - 2017-01-24 21:59:31 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-24 21:59:31 --> Config Class Initialized
INFO - 2017-01-24 21:59:31 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:59:31 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:59:31 --> Utf8 Class Initialized
INFO - 2017-01-24 21:59:31 --> URI Class Initialized
INFO - 2017-01-24 21:59:31 --> Router Class Initialized
INFO - 2017-01-24 21:59:31 --> Output Class Initialized
INFO - 2017-01-24 21:59:31 --> Security Class Initialized
DEBUG - 2017-01-24 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:59:31 --> Input Class Initialized
INFO - 2017-01-24 21:59:31 --> Language Class Initialized
INFO - 2017-01-24 21:59:31 --> Loader Class Initialized
INFO - 2017-01-24 21:59:31 --> Database Driver Class Initialized
INFO - 2017-01-24 21:59:31 --> Config Class Initialized
INFO - 2017-01-24 21:59:31 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:59:31 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:59:31 --> Utf8 Class Initialized
INFO - 2017-01-24 21:59:31 --> URI Class Initialized
INFO - 2017-01-24 21:59:31 --> Router Class Initialized
INFO - 2017-01-24 21:59:31 --> Output Class Initialized
INFO - 2017-01-24 21:59:31 --> Security Class Initialized
DEBUG - 2017-01-24 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:59:31 --> Input Class Initialized
INFO - 2017-01-24 21:59:31 --> Language Class Initialized
INFO - 2017-01-24 21:59:31 --> Loader Class Initialized
INFO - 2017-01-24 21:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:59:31 --> Controller Class Initialized
INFO - 2017-01-24 21:59:31 --> Helper loaded: date_helper
INFO - 2017-01-24 21:59:31 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:59:31 --> Helper loaded: form_helper
INFO - 2017-01-24 21:59:31 --> Form Validation Class Initialized
INFO - 2017-01-24 21:59:31 --> Final output sent to browser
DEBUG - 2017-01-24 21:59:31 --> Total execution time: 0.0631
INFO - 2017-01-24 21:59:31 --> Database Driver Class Initialized
INFO - 2017-01-24 21:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:59:31 --> Controller Class Initialized
INFO - 2017-01-24 21:59:31 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 21:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 21:59:31 --> Final output sent to browser
DEBUG - 2017-01-24 21:59:31 --> Total execution time: 0.0810
INFO - 2017-01-24 21:59:32 --> Config Class Initialized
INFO - 2017-01-24 21:59:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:59:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:59:32 --> Utf8 Class Initialized
INFO - 2017-01-24 21:59:32 --> URI Class Initialized
INFO - 2017-01-24 21:59:32 --> Router Class Initialized
INFO - 2017-01-24 21:59:32 --> Output Class Initialized
INFO - 2017-01-24 21:59:32 --> Security Class Initialized
DEBUG - 2017-01-24 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:59:32 --> Input Class Initialized
INFO - 2017-01-24 21:59:32 --> Language Class Initialized
INFO - 2017-01-24 21:59:32 --> Loader Class Initialized
INFO - 2017-01-24 21:59:32 --> Database Driver Class Initialized
INFO - 2017-01-24 21:59:32 --> Config Class Initialized
INFO - 2017-01-24 21:59:32 --> Hooks Class Initialized
DEBUG - 2017-01-24 21:59:32 --> UTF-8 Support Enabled
INFO - 2017-01-24 21:59:32 --> Utf8 Class Initialized
INFO - 2017-01-24 21:59:32 --> URI Class Initialized
INFO - 2017-01-24 21:59:32 --> Router Class Initialized
INFO - 2017-01-24 21:59:32 --> Output Class Initialized
INFO - 2017-01-24 21:59:32 --> Security Class Initialized
DEBUG - 2017-01-24 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 21:59:32 --> Input Class Initialized
INFO - 2017-01-24 21:59:32 --> Language Class Initialized
INFO - 2017-01-24 21:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:59:32 --> Controller Class Initialized
INFO - 2017-01-24 21:59:32 --> Helper loaded: date_helper
INFO - 2017-01-24 21:59:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:59:32 --> Helper loaded: form_helper
INFO - 2017-01-24 21:59:32 --> Form Validation Class Initialized
INFO - 2017-01-24 21:59:32 --> Loader Class Initialized
INFO - 2017-01-24 21:59:32 --> Database Driver Class Initialized
INFO - 2017-01-24 21:59:32 --> Final output sent to browser
DEBUG - 2017-01-24 21:59:32 --> Total execution time: 0.0969
INFO - 2017-01-24 21:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 21:59:32 --> Controller Class Initialized
INFO - 2017-01-24 21:59:32 --> Helper loaded: date_helper
INFO - 2017-01-24 21:59:32 --> Helper loaded: url_helper
DEBUG - 2017-01-24 21:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 21:59:32 --> Helper loaded: form_helper
INFO - 2017-01-24 21:59:32 --> Form Validation Class Initialized
INFO - 2017-01-24 21:59:32 --> Final output sent to browser
DEBUG - 2017-01-24 21:59:32 --> Total execution time: 0.0780
INFO - 2017-01-24 22:22:00 --> Config Class Initialized
INFO - 2017-01-24 22:22:00 --> Hooks Class Initialized
DEBUG - 2017-01-24 22:22:00 --> UTF-8 Support Enabled
INFO - 2017-01-24 22:22:00 --> Utf8 Class Initialized
INFO - 2017-01-24 22:22:00 --> URI Class Initialized
DEBUG - 2017-01-24 22:22:00 --> No URI present. Default controller set.
INFO - 2017-01-24 22:22:00 --> Router Class Initialized
INFO - 2017-01-24 22:22:00 --> Output Class Initialized
INFO - 2017-01-24 22:22:00 --> Security Class Initialized
DEBUG - 2017-01-24 22:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 22:22:00 --> Input Class Initialized
INFO - 2017-01-24 22:22:00 --> Language Class Initialized
INFO - 2017-01-24 22:22:00 --> Loader Class Initialized
INFO - 2017-01-24 22:22:00 --> Database Driver Class Initialized
INFO - 2017-01-24 22:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 22:22:00 --> Controller Class Initialized
INFO - 2017-01-24 22:22:00 --> Helper loaded: url_helper
DEBUG - 2017-01-24 22:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 22:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 22:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 22:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 22:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 22:22:00 --> Final output sent to browser
DEBUG - 2017-01-24 22:22:00 --> Total execution time: 0.0191
INFO - 2017-01-24 22:22:05 --> Config Class Initialized
INFO - 2017-01-24 22:22:05 --> Hooks Class Initialized
DEBUG - 2017-01-24 22:22:05 --> UTF-8 Support Enabled
INFO - 2017-01-24 22:22:05 --> Utf8 Class Initialized
INFO - 2017-01-24 22:22:05 --> URI Class Initialized
INFO - 2017-01-24 22:22:05 --> Router Class Initialized
INFO - 2017-01-24 22:22:05 --> Output Class Initialized
INFO - 2017-01-24 22:22:05 --> Security Class Initialized
DEBUG - 2017-01-24 22:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 22:22:05 --> Input Class Initialized
INFO - 2017-01-24 22:22:05 --> Language Class Initialized
INFO - 2017-01-24 22:22:05 --> Loader Class Initialized
INFO - 2017-01-24 22:22:05 --> Database Driver Class Initialized
INFO - 2017-01-24 22:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 22:22:05 --> Controller Class Initialized
INFO - 2017-01-24 22:22:05 --> Helper loaded: url_helper
DEBUG - 2017-01-24 22:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 22:22:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 22:22:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 22:22:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 22:22:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 22:22:05 --> Final output sent to browser
DEBUG - 2017-01-24 22:22:05 --> Total execution time: 0.0155
INFO - 2017-01-24 23:12:24 --> Config Class Initialized
INFO - 2017-01-24 23:12:24 --> Hooks Class Initialized
DEBUG - 2017-01-24 23:12:24 --> UTF-8 Support Enabled
INFO - 2017-01-24 23:12:24 --> Utf8 Class Initialized
INFO - 2017-01-24 23:12:24 --> URI Class Initialized
INFO - 2017-01-24 23:12:24 --> Router Class Initialized
INFO - 2017-01-24 23:12:24 --> Output Class Initialized
INFO - 2017-01-24 23:12:24 --> Security Class Initialized
DEBUG - 2017-01-24 23:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 23:12:24 --> Input Class Initialized
INFO - 2017-01-24 23:12:24 --> Language Class Initialized
INFO - 2017-01-24 23:12:24 --> Loader Class Initialized
INFO - 2017-01-24 23:12:24 --> Database Driver Class Initialized
INFO - 2017-01-24 23:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 23:12:24 --> Controller Class Initialized
INFO - 2017-01-24 23:12:24 --> Helper loaded: url_helper
DEBUG - 2017-01-24 23:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 23:12:24 --> Final output sent to browser
DEBUG - 2017-01-24 23:12:24 --> Total execution time: 0.0188
INFO - 2017-01-24 23:12:25 --> Config Class Initialized
INFO - 2017-01-24 23:12:25 --> Hooks Class Initialized
DEBUG - 2017-01-24 23:12:25 --> UTF-8 Support Enabled
INFO - 2017-01-24 23:12:25 --> Utf8 Class Initialized
INFO - 2017-01-24 23:12:25 --> URI Class Initialized
DEBUG - 2017-01-24 23:12:25 --> No URI present. Default controller set.
INFO - 2017-01-24 23:12:25 --> Router Class Initialized
INFO - 2017-01-24 23:12:25 --> Output Class Initialized
INFO - 2017-01-24 23:12:25 --> Security Class Initialized
DEBUG - 2017-01-24 23:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 23:12:25 --> Input Class Initialized
INFO - 2017-01-24 23:12:25 --> Language Class Initialized
INFO - 2017-01-24 23:12:25 --> Loader Class Initialized
INFO - 2017-01-24 23:12:25 --> Database Driver Class Initialized
INFO - 2017-01-24 23:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 23:12:25 --> Controller Class Initialized
INFO - 2017-01-24 23:12:25 --> Helper loaded: url_helper
DEBUG - 2017-01-24 23:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 23:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 23:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 23:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 23:12:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 23:12:25 --> Final output sent to browser
DEBUG - 2017-01-24 23:12:25 --> Total execution time: 0.0159
INFO - 2017-01-24 23:19:22 --> Config Class Initialized
INFO - 2017-01-24 23:19:22 --> Hooks Class Initialized
DEBUG - 2017-01-24 23:19:22 --> UTF-8 Support Enabled
INFO - 2017-01-24 23:19:22 --> Utf8 Class Initialized
INFO - 2017-01-24 23:19:22 --> URI Class Initialized
DEBUG - 2017-01-24 23:19:22 --> No URI present. Default controller set.
INFO - 2017-01-24 23:19:22 --> Router Class Initialized
INFO - 2017-01-24 23:19:22 --> Output Class Initialized
INFO - 2017-01-24 23:19:22 --> Security Class Initialized
DEBUG - 2017-01-24 23:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-24 23:19:22 --> Input Class Initialized
INFO - 2017-01-24 23:19:22 --> Language Class Initialized
INFO - 2017-01-24 23:19:22 --> Loader Class Initialized
INFO - 2017-01-24 23:19:22 --> Database Driver Class Initialized
INFO - 2017-01-24 23:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-24 23:19:22 --> Controller Class Initialized
INFO - 2017-01-24 23:19:22 --> Helper loaded: url_helper
DEBUG - 2017-01-24 23:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-24 23:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-24 23:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-24 23:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-24 23:19:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-24 23:19:22 --> Final output sent to browser
DEBUG - 2017-01-24 23:19:22 --> Total execution time: 0.0155

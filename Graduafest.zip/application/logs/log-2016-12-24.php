<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-24 04:47:53 --> Config Class Initialized
INFO - 2016-12-24 04:47:53 --> Hooks Class Initialized
DEBUG - 2016-12-24 04:47:53 --> UTF-8 Support Enabled
INFO - 2016-12-24 04:47:53 --> Utf8 Class Initialized
INFO - 2016-12-24 04:47:53 --> URI Class Initialized
DEBUG - 2016-12-24 04:47:53 --> No URI present. Default controller set.
INFO - 2016-12-24 04:47:53 --> Router Class Initialized
INFO - 2016-12-24 04:47:53 --> Output Class Initialized
INFO - 2016-12-24 04:47:53 --> Security Class Initialized
DEBUG - 2016-12-24 04:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 04:47:53 --> Input Class Initialized
INFO - 2016-12-24 04:47:53 --> Language Class Initialized
INFO - 2016-12-24 04:47:53 --> Loader Class Initialized
INFO - 2016-12-24 04:47:54 --> Database Driver Class Initialized
INFO - 2016-12-24 04:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 04:47:54 --> Controller Class Initialized
INFO - 2016-12-24 04:47:54 --> Helper loaded: url_helper
DEBUG - 2016-12-24 04:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 04:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 04:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 04:47:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 04:47:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 04:47:55 --> Final output sent to browser
DEBUG - 2016-12-24 04:47:55 --> Total execution time: 1.7127
INFO - 2016-12-24 08:22:11 --> Config Class Initialized
INFO - 2016-12-24 08:22:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 08:22:12 --> UTF-8 Support Enabled
INFO - 2016-12-24 08:22:12 --> Utf8 Class Initialized
INFO - 2016-12-24 08:22:12 --> URI Class Initialized
DEBUG - 2016-12-24 08:22:12 --> No URI present. Default controller set.
INFO - 2016-12-24 08:22:12 --> Router Class Initialized
INFO - 2016-12-24 08:22:12 --> Output Class Initialized
INFO - 2016-12-24 08:22:12 --> Security Class Initialized
DEBUG - 2016-12-24 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 08:22:12 --> Input Class Initialized
INFO - 2016-12-24 08:22:12 --> Language Class Initialized
INFO - 2016-12-24 08:22:12 --> Loader Class Initialized
INFO - 2016-12-24 08:22:12 --> Database Driver Class Initialized
INFO - 2016-12-24 08:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 08:22:12 --> Controller Class Initialized
INFO - 2016-12-24 08:22:12 --> Helper loaded: url_helper
DEBUG - 2016-12-24 08:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 08:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 08:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 08:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 08:22:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 08:22:12 --> Final output sent to browser
DEBUG - 2016-12-24 08:22:12 --> Total execution time: 0.2974
INFO - 2016-12-24 10:12:36 --> Config Class Initialized
INFO - 2016-12-24 10:12:36 --> Hooks Class Initialized
DEBUG - 2016-12-24 10:12:36 --> UTF-8 Support Enabled
INFO - 2016-12-24 10:12:36 --> Utf8 Class Initialized
INFO - 2016-12-24 10:12:36 --> URI Class Initialized
DEBUG - 2016-12-24 10:12:36 --> No URI present. Default controller set.
INFO - 2016-12-24 10:12:36 --> Router Class Initialized
INFO - 2016-12-24 10:12:36 --> Output Class Initialized
INFO - 2016-12-24 10:12:37 --> Security Class Initialized
DEBUG - 2016-12-24 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 10:12:37 --> Input Class Initialized
INFO - 2016-12-24 10:12:37 --> Language Class Initialized
INFO - 2016-12-24 10:12:37 --> Loader Class Initialized
INFO - 2016-12-24 10:12:37 --> Database Driver Class Initialized
INFO - 2016-12-24 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 10:12:38 --> Controller Class Initialized
INFO - 2016-12-24 10:12:38 --> Helper loaded: url_helper
DEBUG - 2016-12-24 10:12:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 10:12:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 10:12:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 10:12:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 10:12:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 10:12:38 --> Final output sent to browser
DEBUG - 2016-12-24 10:12:38 --> Total execution time: 1.8744
INFO - 2016-12-24 10:13:50 --> Config Class Initialized
INFO - 2016-12-24 10:13:50 --> Hooks Class Initialized
DEBUG - 2016-12-24 10:13:50 --> UTF-8 Support Enabled
INFO - 2016-12-24 10:13:50 --> Utf8 Class Initialized
INFO - 2016-12-24 10:13:50 --> URI Class Initialized
DEBUG - 2016-12-24 10:13:50 --> No URI present. Default controller set.
INFO - 2016-12-24 10:13:50 --> Router Class Initialized
INFO - 2016-12-24 10:13:50 --> Output Class Initialized
INFO - 2016-12-24 10:13:50 --> Security Class Initialized
DEBUG - 2016-12-24 10:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 10:13:51 --> Input Class Initialized
INFO - 2016-12-24 10:13:51 --> Language Class Initialized
INFO - 2016-12-24 10:13:51 --> Loader Class Initialized
INFO - 2016-12-24 10:13:51 --> Database Driver Class Initialized
INFO - 2016-12-24 10:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 10:13:51 --> Controller Class Initialized
INFO - 2016-12-24 10:13:51 --> Helper loaded: url_helper
DEBUG - 2016-12-24 10:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 10:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 10:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 10:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 10:13:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 10:13:52 --> Final output sent to browser
DEBUG - 2016-12-24 10:13:52 --> Total execution time: 1.6121
INFO - 2016-12-24 10:15:59 --> Config Class Initialized
INFO - 2016-12-24 10:16:00 --> Hooks Class Initialized
DEBUG - 2016-12-24 10:16:00 --> UTF-8 Support Enabled
INFO - 2016-12-24 10:16:00 --> Utf8 Class Initialized
INFO - 2016-12-24 10:16:00 --> URI Class Initialized
DEBUG - 2016-12-24 10:16:00 --> No URI present. Default controller set.
INFO - 2016-12-24 10:16:00 --> Router Class Initialized
INFO - 2016-12-24 10:16:00 --> Output Class Initialized
INFO - 2016-12-24 10:16:00 --> Security Class Initialized
DEBUG - 2016-12-24 10:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 10:16:00 --> Input Class Initialized
INFO - 2016-12-24 10:16:00 --> Language Class Initialized
INFO - 2016-12-24 10:16:00 --> Loader Class Initialized
INFO - 2016-12-24 10:16:00 --> Database Driver Class Initialized
INFO - 2016-12-24 10:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 10:16:01 --> Controller Class Initialized
INFO - 2016-12-24 10:16:01 --> Helper loaded: url_helper
DEBUG - 2016-12-24 10:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 10:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 10:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 10:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 10:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 10:16:01 --> Final output sent to browser
DEBUG - 2016-12-24 10:16:01 --> Total execution time: 1.5627
INFO - 2016-12-24 17:37:49 --> Config Class Initialized
INFO - 2016-12-24 17:37:49 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:37:49 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:37:49 --> Utf8 Class Initialized
INFO - 2016-12-24 17:37:49 --> URI Class Initialized
DEBUG - 2016-12-24 17:37:49 --> No URI present. Default controller set.
INFO - 2016-12-24 17:37:49 --> Router Class Initialized
INFO - 2016-12-24 17:37:49 --> Output Class Initialized
INFO - 2016-12-24 17:37:49 --> Security Class Initialized
DEBUG - 2016-12-24 17:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:37:50 --> Input Class Initialized
INFO - 2016-12-24 17:37:50 --> Language Class Initialized
INFO - 2016-12-24 17:37:50 --> Loader Class Initialized
INFO - 2016-12-24 17:37:50 --> Database Driver Class Initialized
INFO - 2016-12-24 17:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:37:50 --> Controller Class Initialized
INFO - 2016-12-24 17:37:50 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 17:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 17:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 17:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 17:37:51 --> Final output sent to browser
DEBUG - 2016-12-24 17:37:51 --> Total execution time: 1.7758
INFO - 2016-12-24 17:38:23 --> Config Class Initialized
INFO - 2016-12-24 17:38:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:38:23 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:38:23 --> Utf8 Class Initialized
INFO - 2016-12-24 17:38:23 --> URI Class Initialized
INFO - 2016-12-24 17:38:23 --> Router Class Initialized
INFO - 2016-12-24 17:38:23 --> Output Class Initialized
INFO - 2016-12-24 17:38:24 --> Security Class Initialized
DEBUG - 2016-12-24 17:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:38:24 --> Input Class Initialized
INFO - 2016-12-24 17:38:24 --> Language Class Initialized
INFO - 2016-12-24 17:38:24 --> Loader Class Initialized
INFO - 2016-12-24 17:38:24 --> Database Driver Class Initialized
INFO - 2016-12-24 17:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:38:24 --> Controller Class Initialized
INFO - 2016-12-24 17:38:24 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:38:27 --> Config Class Initialized
INFO - 2016-12-24 17:38:27 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:38:27 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:38:27 --> Utf8 Class Initialized
INFO - 2016-12-24 17:38:27 --> URI Class Initialized
INFO - 2016-12-24 17:38:27 --> Router Class Initialized
INFO - 2016-12-24 17:38:27 --> Output Class Initialized
INFO - 2016-12-24 17:38:27 --> Security Class Initialized
DEBUG - 2016-12-24 17:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:38:27 --> Input Class Initialized
INFO - 2016-12-24 17:38:27 --> Language Class Initialized
INFO - 2016-12-24 17:38:27 --> Loader Class Initialized
INFO - 2016-12-24 17:38:27 --> Database Driver Class Initialized
INFO - 2016-12-24 17:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:38:27 --> Controller Class Initialized
INFO - 2016-12-24 17:38:28 --> Helper loaded: date_helper
DEBUG - 2016-12-24 17:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:38:28 --> Helper loaded: url_helper
INFO - 2016-12-24 17:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 17:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-24 17:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-24 17:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-24 17:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 17:38:28 --> Final output sent to browser
DEBUG - 2016-12-24 17:38:28 --> Total execution time: 0.4415
INFO - 2016-12-24 17:38:40 --> Config Class Initialized
INFO - 2016-12-24 17:38:40 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:38:40 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:38:40 --> Utf8 Class Initialized
INFO - 2016-12-24 17:38:40 --> URI Class Initialized
INFO - 2016-12-24 17:38:40 --> Router Class Initialized
INFO - 2016-12-24 17:38:40 --> Output Class Initialized
INFO - 2016-12-24 17:38:40 --> Security Class Initialized
DEBUG - 2016-12-24 17:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:38:40 --> Input Class Initialized
INFO - 2016-12-24 17:38:40 --> Language Class Initialized
INFO - 2016-12-24 17:38:40 --> Loader Class Initialized
INFO - 2016-12-24 17:38:41 --> Database Driver Class Initialized
INFO - 2016-12-24 17:38:41 --> Config Class Initialized
INFO - 2016-12-24 17:38:41 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:38:41 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:38:41 --> Utf8 Class Initialized
INFO - 2016-12-24 17:38:41 --> URI Class Initialized
INFO - 2016-12-24 17:38:41 --> Router Class Initialized
INFO - 2016-12-24 17:38:41 --> Output Class Initialized
INFO - 2016-12-24 17:38:41 --> Security Class Initialized
DEBUG - 2016-12-24 17:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:38:41 --> Input Class Initialized
INFO - 2016-12-24 17:38:41 --> Language Class Initialized
INFO - 2016-12-24 17:38:41 --> Loader Class Initialized
INFO - 2016-12-24 17:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:38:41 --> Controller Class Initialized
INFO - 2016-12-24 17:38:41 --> Database Driver Class Initialized
INFO - 2016-12-24 17:38:41 --> Helper loaded: date_helper
DEBUG - 2016-12-24 17:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:38:41 --> Helper loaded: url_helper
INFO - 2016-12-24 17:38:42 --> Helper loaded: download_helper
INFO - 2016-12-24 17:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 17:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-24 17:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-24 17:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-24 17:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 17:38:42 --> Final output sent to browser
DEBUG - 2016-12-24 17:38:42 --> Total execution time: 2.3496
INFO - 2016-12-24 17:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:38:42 --> Controller Class Initialized
INFO - 2016-12-24 17:38:42 --> Helper loaded: date_helper
DEBUG - 2016-12-24 17:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:38:43 --> Helper loaded: url_helper
INFO - 2016-12-24 17:38:43 --> Helper loaded: download_helper
INFO - 2016-12-24 17:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 17:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-24 17:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-24 17:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-24 17:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 17:38:43 --> Final output sent to browser
DEBUG - 2016-12-24 17:38:43 --> Total execution time: 1.9822
INFO - 2016-12-24 17:39:05 --> Config Class Initialized
INFO - 2016-12-24 17:39:05 --> Config Class Initialized
INFO - 2016-12-24 17:39:05 --> Hooks Class Initialized
INFO - 2016-12-24 17:39:05 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:05 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:05 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:05 --> URI Class Initialized
INFO - 2016-12-24 17:39:05 --> Router Class Initialized
DEBUG - 2016-12-24 17:39:05 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:05 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:05 --> URI Class Initialized
INFO - 2016-12-24 17:39:05 --> Router Class Initialized
INFO - 2016-12-24 17:39:05 --> Output Class Initialized
INFO - 2016-12-24 17:39:05 --> Output Class Initialized
INFO - 2016-12-24 17:39:05 --> Security Class Initialized
INFO - 2016-12-24 17:39:05 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-12-24 17:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:05 --> Input Class Initialized
INFO - 2016-12-24 17:39:05 --> Input Class Initialized
INFO - 2016-12-24 17:39:05 --> Language Class Initialized
INFO - 2016-12-24 17:39:05 --> Language Class Initialized
INFO - 2016-12-24 17:39:05 --> Loader Class Initialized
INFO - 2016-12-24 17:39:05 --> Loader Class Initialized
INFO - 2016-12-24 17:39:05 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:05 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:06 --> Controller Class Initialized
INFO - 2016-12-24 17:39:06 --> Helper loaded: date_helper
INFO - 2016-12-24 17:39:06 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:07 --> Helper loaded: form_helper
INFO - 2016-12-24 17:39:07 --> Form Validation Class Initialized
INFO - 2016-12-24 17:39:07 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:07 --> Total execution time: 2.3938
INFO - 2016-12-24 17:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:07 --> Controller Class Initialized
INFO - 2016-12-24 17:39:07 --> Helper loaded: date_helper
INFO - 2016-12-24 17:39:07 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:07 --> Helper loaded: form_helper
INFO - 2016-12-24 17:39:07 --> Form Validation Class Initialized
INFO - 2016-12-24 17:39:07 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:07 --> Total execution time: 2.7147
INFO - 2016-12-24 17:39:08 --> Config Class Initialized
INFO - 2016-12-24 17:39:08 --> Hooks Class Initialized
INFO - 2016-12-24 17:39:08 --> Config Class Initialized
INFO - 2016-12-24 17:39:08 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:08 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:08 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:08 --> URI Class Initialized
INFO - 2016-12-24 17:39:08 --> Router Class Initialized
DEBUG - 2016-12-24 17:39:08 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:08 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:08 --> URI Class Initialized
INFO - 2016-12-24 17:39:08 --> Router Class Initialized
INFO - 2016-12-24 17:39:08 --> Output Class Initialized
INFO - 2016-12-24 17:39:08 --> Output Class Initialized
INFO - 2016-12-24 17:39:08 --> Security Class Initialized
INFO - 2016-12-24 17:39:08 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:08 --> Input Class Initialized
DEBUG - 2016-12-24 17:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:08 --> Input Class Initialized
INFO - 2016-12-24 17:39:08 --> Language Class Initialized
INFO - 2016-12-24 17:39:08 --> Language Class Initialized
INFO - 2016-12-24 17:39:08 --> Loader Class Initialized
INFO - 2016-12-24 17:39:08 --> Loader Class Initialized
INFO - 2016-12-24 17:39:09 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:09 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:09 --> Controller Class Initialized
INFO - 2016-12-24 17:39:09 --> Helper loaded: date_helper
INFO - 2016-12-24 17:39:09 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:09 --> Helper loaded: form_helper
INFO - 2016-12-24 17:39:09 --> Form Validation Class Initialized
INFO - 2016-12-24 17:39:09 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:09 --> Total execution time: 0.8126
INFO - 2016-12-24 17:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:09 --> Controller Class Initialized
INFO - 2016-12-24 17:39:09 --> Helper loaded: date_helper
INFO - 2016-12-24 17:39:09 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:09 --> Helper loaded: form_helper
INFO - 2016-12-24 17:39:09 --> Form Validation Class Initialized
INFO - 2016-12-24 17:39:09 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:09 --> Total execution time: 0.8184
INFO - 2016-12-24 17:39:09 --> Config Class Initialized
INFO - 2016-12-24 17:39:09 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:09 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:09 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:09 --> URI Class Initialized
INFO - 2016-12-24 17:39:09 --> Router Class Initialized
INFO - 2016-12-24 17:39:09 --> Output Class Initialized
INFO - 2016-12-24 17:39:09 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:09 --> Input Class Initialized
INFO - 2016-12-24 17:39:09 --> Language Class Initialized
INFO - 2016-12-24 17:39:09 --> Loader Class Initialized
INFO - 2016-12-24 17:39:09 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:09 --> Controller Class Initialized
INFO - 2016-12-24 17:39:09 --> Helper loaded: date_helper
INFO - 2016-12-24 17:39:09 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:09 --> Helper loaded: form_helper
INFO - 2016-12-24 17:39:09 --> Form Validation Class Initialized
INFO - 2016-12-24 17:39:09 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:09 --> Total execution time: 0.0147
INFO - 2016-12-24 17:39:21 --> Config Class Initialized
INFO - 2016-12-24 17:39:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:21 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:21 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:21 --> URI Class Initialized
INFO - 2016-12-24 17:39:21 --> Router Class Initialized
INFO - 2016-12-24 17:39:21 --> Output Class Initialized
INFO - 2016-12-24 17:39:21 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:21 --> Input Class Initialized
INFO - 2016-12-24 17:39:21 --> Language Class Initialized
INFO - 2016-12-24 17:39:21 --> Loader Class Initialized
INFO - 2016-12-24 17:39:21 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:21 --> Controller Class Initialized
INFO - 2016-12-24 17:39:21 --> Helper loaded: date_helper
INFO - 2016-12-24 17:39:22 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:22 --> Helper loaded: form_helper
INFO - 2016-12-24 17:39:22 --> Form Validation Class Initialized
INFO - 2016-12-24 17:39:22 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:22 --> Total execution time: 1.0411
INFO - 2016-12-24 17:39:24 --> Config Class Initialized
INFO - 2016-12-24 17:39:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:24 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:24 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:24 --> URI Class Initialized
INFO - 2016-12-24 17:39:24 --> Router Class Initialized
INFO - 2016-12-24 17:39:24 --> Output Class Initialized
INFO - 2016-12-24 17:39:24 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:24 --> Input Class Initialized
INFO - 2016-12-24 17:39:24 --> Language Class Initialized
INFO - 2016-12-24 17:39:24 --> Loader Class Initialized
INFO - 2016-12-24 17:39:24 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:24 --> Controller Class Initialized
INFO - 2016-12-24 17:39:24 --> Helper loaded: date_helper
INFO - 2016-12-24 17:39:24 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:24 --> Helper loaded: form_helper
INFO - 2016-12-24 17:39:24 --> Form Validation Class Initialized
INFO - 2016-12-24 17:39:24 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:24 --> Total execution time: 0.0146
INFO - 2016-12-24 17:39:46 --> Config Class Initialized
INFO - 2016-12-24 17:39:46 --> Config Class Initialized
INFO - 2016-12-24 17:39:46 --> Hooks Class Initialized
INFO - 2016-12-24 17:39:46 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:39:46 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:46 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:46 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:46 --> URI Class Initialized
INFO - 2016-12-24 17:39:46 --> URI Class Initialized
INFO - 2016-12-24 17:39:46 --> Router Class Initialized
INFO - 2016-12-24 17:39:46 --> Router Class Initialized
INFO - 2016-12-24 17:39:46 --> Output Class Initialized
INFO - 2016-12-24 17:39:46 --> Output Class Initialized
INFO - 2016-12-24 17:39:46 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:46 --> Input Class Initialized
INFO - 2016-12-24 17:39:46 --> Security Class Initialized
INFO - 2016-12-24 17:39:46 --> Language Class Initialized
DEBUG - 2016-12-24 17:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:47 --> Input Class Initialized
INFO - 2016-12-24 17:39:47 --> Language Class Initialized
INFO - 2016-12-24 17:39:47 --> Loader Class Initialized
INFO - 2016-12-24 17:39:47 --> Loader Class Initialized
INFO - 2016-12-24 17:39:47 --> Config Class Initialized
INFO - 2016-12-24 17:39:47 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:47 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:47 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:47 --> URI Class Initialized
INFO - 2016-12-24 17:39:47 --> Router Class Initialized
INFO - 2016-12-24 17:39:47 --> Output Class Initialized
INFO - 2016-12-24 17:39:47 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:47 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:47 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:47 --> Input Class Initialized
INFO - 2016-12-24 17:39:47 --> Language Class Initialized
INFO - 2016-12-24 17:39:47 --> Loader Class Initialized
INFO - 2016-12-24 17:39:47 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:47 --> Controller Class Initialized
INFO - 2016-12-24 17:39:47 --> Helper loaded: date_helper
DEBUG - 2016-12-24 17:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:47 --> Helper loaded: url_helper
INFO - 2016-12-24 17:39:47 --> Helper loaded: download_helper
INFO - 2016-12-24 17:39:47 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:47 --> Total execution time: 1.0597
INFO - 2016-12-24 17:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:47 --> Controller Class Initialized
INFO - 2016-12-24 17:39:47 --> Upload Class Initialized
INFO - 2016-12-24 17:39:48 --> Helper loaded: date_helper
DEBUG - 2016-12-24 17:39:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:48 --> Helper loaded: url_helper
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 17:39:48 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:48 --> Total execution time: 2.1747
INFO - 2016-12-24 17:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:48 --> Controller Class Initialized
INFO - 2016-12-24 17:39:48 --> Upload Class Initialized
INFO - 2016-12-24 17:39:48 --> Helper loaded: date_helper
DEBUG - 2016-12-24 17:39:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:48 --> Helper loaded: url_helper
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-24 17:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 17:39:48 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:48 --> Total execution time: 1.6150
INFO - 2016-12-24 17:39:52 --> Config Class Initialized
INFO - 2016-12-24 17:39:52 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:39:52 --> UTF-8 Support Enabled
INFO - 2016-12-24 17:39:52 --> Utf8 Class Initialized
INFO - 2016-12-24 17:39:52 --> URI Class Initialized
INFO - 2016-12-24 17:39:52 --> Router Class Initialized
INFO - 2016-12-24 17:39:52 --> Output Class Initialized
INFO - 2016-12-24 17:39:52 --> Security Class Initialized
DEBUG - 2016-12-24 17:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 17:39:52 --> Input Class Initialized
INFO - 2016-12-24 17:39:52 --> Language Class Initialized
INFO - 2016-12-24 17:39:52 --> Loader Class Initialized
INFO - 2016-12-24 17:39:53 --> Database Driver Class Initialized
INFO - 2016-12-24 17:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 17:39:53 --> Controller Class Initialized
INFO - 2016-12-24 17:39:53 --> Upload Class Initialized
INFO - 2016-12-24 17:39:53 --> Helper loaded: date_helper
DEBUG - 2016-12-24 17:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 17:39:53 --> Helper loaded: url_helper
INFO - 2016-12-24 17:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 17:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-24 17:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-24 17:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-24 17:39:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-24 17:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 17:39:54 --> Final output sent to browser
DEBUG - 2016-12-24 17:39:54 --> Total execution time: 1.2356
INFO - 2016-12-24 18:33:03 --> Config Class Initialized
INFO - 2016-12-24 18:33:03 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:33:03 --> UTF-8 Support Enabled
INFO - 2016-12-24 18:33:03 --> Utf8 Class Initialized
INFO - 2016-12-24 18:33:03 --> URI Class Initialized
INFO - 2016-12-24 18:33:03 --> Router Class Initialized
INFO - 2016-12-24 18:33:03 --> Output Class Initialized
INFO - 2016-12-24 18:33:03 --> Security Class Initialized
DEBUG - 2016-12-24 18:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 18:33:03 --> Input Class Initialized
INFO - 2016-12-24 18:33:03 --> Language Class Initialized
INFO - 2016-12-24 18:33:03 --> Loader Class Initialized
INFO - 2016-12-24 18:33:04 --> Database Driver Class Initialized
INFO - 2016-12-24 18:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 18:33:04 --> Controller Class Initialized
INFO - 2016-12-24 18:33:04 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 18:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 18:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 18:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 18:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 18:33:04 --> Final output sent to browser
DEBUG - 2016-12-24 18:33:04 --> Total execution time: 1.9618
INFO - 2016-12-24 18:33:05 --> Config Class Initialized
INFO - 2016-12-24 18:33:05 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:33:05 --> UTF-8 Support Enabled
INFO - 2016-12-24 18:33:05 --> Utf8 Class Initialized
INFO - 2016-12-24 18:33:05 --> URI Class Initialized
DEBUG - 2016-12-24 18:33:05 --> No URI present. Default controller set.
INFO - 2016-12-24 18:33:05 --> Router Class Initialized
INFO - 2016-12-24 18:33:05 --> Output Class Initialized
INFO - 2016-12-24 18:33:05 --> Security Class Initialized
DEBUG - 2016-12-24 18:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 18:33:05 --> Input Class Initialized
INFO - 2016-12-24 18:33:05 --> Language Class Initialized
INFO - 2016-12-24 18:33:05 --> Loader Class Initialized
INFO - 2016-12-24 18:33:06 --> Database Driver Class Initialized
INFO - 2016-12-24 18:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 18:33:06 --> Controller Class Initialized
INFO - 2016-12-24 18:33:06 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 18:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 18:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 18:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 18:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 18:33:06 --> Final output sent to browser
DEBUG - 2016-12-24 18:33:06 --> Total execution time: 1.1081
INFO - 2016-12-24 22:45:03 --> Config Class Initialized
INFO - 2016-12-24 22:45:03 --> Hooks Class Initialized
DEBUG - 2016-12-24 22:45:03 --> UTF-8 Support Enabled
INFO - 2016-12-24 22:45:03 --> Utf8 Class Initialized
INFO - 2016-12-24 22:45:03 --> URI Class Initialized
DEBUG - 2016-12-24 22:45:03 --> No URI present. Default controller set.
INFO - 2016-12-24 22:45:03 --> Router Class Initialized
INFO - 2016-12-24 22:45:03 --> Output Class Initialized
INFO - 2016-12-24 22:45:03 --> Security Class Initialized
DEBUG - 2016-12-24 22:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 22:45:03 --> Input Class Initialized
INFO - 2016-12-24 22:45:03 --> Language Class Initialized
INFO - 2016-12-24 22:45:03 --> Loader Class Initialized
INFO - 2016-12-24 22:45:04 --> Database Driver Class Initialized
INFO - 2016-12-24 22:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 22:45:04 --> Controller Class Initialized
INFO - 2016-12-24 22:45:04 --> Helper loaded: url_helper
DEBUG - 2016-12-24 22:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 22:45:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 22:45:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 22:45:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 22:45:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 22:45:04 --> Final output sent to browser
DEBUG - 2016-12-24 22:45:04 --> Total execution time: 1.6627
INFO - 2016-12-24 22:45:10 --> Config Class Initialized
INFO - 2016-12-24 22:45:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 22:45:10 --> UTF-8 Support Enabled
INFO - 2016-12-24 22:45:10 --> Utf8 Class Initialized
INFO - 2016-12-24 22:45:10 --> URI Class Initialized
INFO - 2016-12-24 22:45:10 --> Router Class Initialized
INFO - 2016-12-24 22:45:10 --> Output Class Initialized
INFO - 2016-12-24 22:45:10 --> Security Class Initialized
DEBUG - 2016-12-24 22:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-24 22:45:10 --> Input Class Initialized
INFO - 2016-12-24 22:45:10 --> Language Class Initialized
INFO - 2016-12-24 22:45:10 --> Loader Class Initialized
INFO - 2016-12-24 22:45:10 --> Database Driver Class Initialized
INFO - 2016-12-24 22:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-24 22:45:10 --> Controller Class Initialized
INFO - 2016-12-24 22:45:10 --> Helper loaded: url_helper
DEBUG - 2016-12-24 22:45:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-24 22:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-24 22:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-24 22:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-24 22:45:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-24 22:45:10 --> Final output sent to browser
DEBUG - 2016-12-24 22:45:10 --> Total execution time: 0.0146

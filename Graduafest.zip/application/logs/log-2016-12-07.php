<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-07 01:08:57 --> Config Class Initialized
INFO - 2016-12-07 01:08:57 --> Hooks Class Initialized
DEBUG - 2016-12-07 01:08:57 --> UTF-8 Support Enabled
INFO - 2016-12-07 01:08:57 --> Utf8 Class Initialized
INFO - 2016-12-07 01:08:57 --> URI Class Initialized
DEBUG - 2016-12-07 01:08:57 --> No URI present. Default controller set.
INFO - 2016-12-07 01:08:57 --> Router Class Initialized
INFO - 2016-12-07 01:08:57 --> Output Class Initialized
INFO - 2016-12-07 01:08:57 --> Security Class Initialized
DEBUG - 2016-12-07 01:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-07 01:08:57 --> Input Class Initialized
INFO - 2016-12-07 01:08:57 --> Language Class Initialized
INFO - 2016-12-07 01:08:57 --> Loader Class Initialized
INFO - 2016-12-07 01:08:57 --> Database Driver Class Initialized
INFO - 2016-12-07 01:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-07 01:08:58 --> Controller Class Initialized
INFO - 2016-12-07 01:08:58 --> Helper loaded: url_helper
DEBUG - 2016-12-07 01:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-07 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-07 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-07 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-07 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-07 01:08:58 --> Final output sent to browser
DEBUG - 2016-12-07 01:08:58 --> Total execution time: 1.0675
INFO - 2016-12-07 15:31:13 --> Config Class Initialized
INFO - 2016-12-07 15:31:13 --> Hooks Class Initialized
DEBUG - 2016-12-07 15:31:13 --> UTF-8 Support Enabled
INFO - 2016-12-07 15:31:13 --> Utf8 Class Initialized
INFO - 2016-12-07 15:31:13 --> URI Class Initialized
DEBUG - 2016-12-07 15:31:13 --> No URI present. Default controller set.
INFO - 2016-12-07 15:31:13 --> Router Class Initialized
INFO - 2016-12-07 15:31:13 --> Output Class Initialized
INFO - 2016-12-07 15:31:13 --> Security Class Initialized
DEBUG - 2016-12-07 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-07 15:31:13 --> Input Class Initialized
INFO - 2016-12-07 15:31:13 --> Language Class Initialized
INFO - 2016-12-07 15:31:13 --> Loader Class Initialized
INFO - 2016-12-07 15:31:13 --> Database Driver Class Initialized
INFO - 2016-12-07 15:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-07 15:31:13 --> Controller Class Initialized
INFO - 2016-12-07 15:31:13 --> Helper loaded: url_helper
DEBUG - 2016-12-07 15:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-07 15:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-07 15:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-07 15:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-07 15:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-07 15:31:13 --> Final output sent to browser
DEBUG - 2016-12-07 15:31:13 --> Total execution time: 0.0172
INFO - 2016-12-07 15:31:50 --> Config Class Initialized
INFO - 2016-12-07 15:31:50 --> Hooks Class Initialized
DEBUG - 2016-12-07 15:31:50 --> UTF-8 Support Enabled
INFO - 2016-12-07 15:31:50 --> Utf8 Class Initialized
INFO - 2016-12-07 15:31:50 --> URI Class Initialized
DEBUG - 2016-12-07 15:31:50 --> No URI present. Default controller set.
INFO - 2016-12-07 15:31:50 --> Router Class Initialized
INFO - 2016-12-07 15:31:50 --> Output Class Initialized
INFO - 2016-12-07 15:31:50 --> Security Class Initialized
DEBUG - 2016-12-07 15:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-07 15:31:50 --> Input Class Initialized
INFO - 2016-12-07 15:31:50 --> Language Class Initialized
INFO - 2016-12-07 15:31:50 --> Loader Class Initialized
INFO - 2016-12-07 15:31:50 --> Database Driver Class Initialized
INFO - 2016-12-07 15:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-07 15:31:50 --> Controller Class Initialized
INFO - 2016-12-07 15:31:50 --> Helper loaded: url_helper
DEBUG - 2016-12-07 15:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-07 15:31:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-07 15:31:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-07 15:31:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-07 15:31:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-07 15:31:50 --> Final output sent to browser
DEBUG - 2016-12-07 15:31:50 --> Total execution time: 0.0162
INFO - 2016-12-07 19:18:44 --> Config Class Initialized
INFO - 2016-12-07 19:18:44 --> Hooks Class Initialized
DEBUG - 2016-12-07 19:18:44 --> UTF-8 Support Enabled
INFO - 2016-12-07 19:18:44 --> Utf8 Class Initialized
INFO - 2016-12-07 19:18:44 --> URI Class Initialized
INFO - 2016-12-07 19:18:44 --> Router Class Initialized
INFO - 2016-12-07 19:18:44 --> Output Class Initialized
INFO - 2016-12-07 19:18:44 --> Security Class Initialized
DEBUG - 2016-12-07 19:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-07 19:18:44 --> Input Class Initialized
INFO - 2016-12-07 19:18:44 --> Language Class Initialized
INFO - 2016-12-07 19:18:44 --> Loader Class Initialized
INFO - 2016-12-07 19:18:44 --> Database Driver Class Initialized
INFO - 2016-12-07 19:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-07 19:18:44 --> Controller Class Initialized
INFO - 2016-12-07 19:18:44 --> Helper loaded: url_helper
DEBUG - 2016-12-07 19:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-07 19:18:44 --> Final output sent to browser
DEBUG - 2016-12-07 19:18:44 --> Total execution time: 0.0233
INFO - 2016-12-07 19:18:44 --> Config Class Initialized
INFO - 2016-12-07 19:18:44 --> Hooks Class Initialized
DEBUG - 2016-12-07 19:18:44 --> UTF-8 Support Enabled
INFO - 2016-12-07 19:18:44 --> Utf8 Class Initialized
INFO - 2016-12-07 19:18:44 --> URI Class Initialized
DEBUG - 2016-12-07 19:18:44 --> No URI present. Default controller set.
INFO - 2016-12-07 19:18:44 --> Router Class Initialized
INFO - 2016-12-07 19:18:44 --> Output Class Initialized
INFO - 2016-12-07 19:18:44 --> Security Class Initialized
DEBUG - 2016-12-07 19:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-07 19:18:44 --> Input Class Initialized
INFO - 2016-12-07 19:18:44 --> Language Class Initialized
INFO - 2016-12-07 19:18:44 --> Loader Class Initialized
INFO - 2016-12-07 19:18:44 --> Database Driver Class Initialized
INFO - 2016-12-07 19:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-07 19:18:44 --> Controller Class Initialized
INFO - 2016-12-07 19:18:44 --> Helper loaded: url_helper
DEBUG - 2016-12-07 19:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-07 19:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-07 19:18:44 --> Final output sent to browser
DEBUG - 2016-12-07 19:18:44 --> Total execution time: 0.0249

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-27 00:12:04 --> Config Class Initialized
INFO - 2016-12-27 00:12:04 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:12:04 --> UTF-8 Support Enabled
INFO - 2016-12-27 00:12:04 --> Utf8 Class Initialized
INFO - 2016-12-27 00:12:04 --> URI Class Initialized
INFO - 2016-12-27 00:12:04 --> Router Class Initialized
INFO - 2016-12-27 00:12:04 --> Output Class Initialized
INFO - 2016-12-27 00:12:04 --> Security Class Initialized
DEBUG - 2016-12-27 00:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 00:12:04 --> Input Class Initialized
INFO - 2016-12-27 00:12:04 --> Language Class Initialized
INFO - 2016-12-27 00:12:04 --> Loader Class Initialized
INFO - 2016-12-27 00:12:05 --> Database Driver Class Initialized
INFO - 2016-12-27 00:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 00:12:05 --> Controller Class Initialized
INFO - 2016-12-27 00:12:05 --> Helper loaded: date_helper
DEBUG - 2016-12-27 00:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 00:12:05 --> Helper loaded: url_helper
INFO - 2016-12-27 00:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 00:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2016-12-27 00:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-27 00:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-27 00:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 00:12:06 --> Final output sent to browser
DEBUG - 2016-12-27 00:12:06 --> Total execution time: 1.8792
INFO - 2016-12-27 01:17:39 --> Config Class Initialized
INFO - 2016-12-27 01:17:40 --> Hooks Class Initialized
DEBUG - 2016-12-27 01:17:40 --> UTF-8 Support Enabled
INFO - 2016-12-27 01:17:40 --> Utf8 Class Initialized
INFO - 2016-12-27 01:17:40 --> URI Class Initialized
DEBUG - 2016-12-27 01:17:40 --> No URI present. Default controller set.
INFO - 2016-12-27 01:17:40 --> Router Class Initialized
INFO - 2016-12-27 01:17:40 --> Output Class Initialized
INFO - 2016-12-27 01:17:40 --> Security Class Initialized
DEBUG - 2016-12-27 01:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 01:17:40 --> Input Class Initialized
INFO - 2016-12-27 01:17:40 --> Language Class Initialized
INFO - 2016-12-27 01:17:40 --> Loader Class Initialized
INFO - 2016-12-27 01:17:41 --> Database Driver Class Initialized
INFO - 2016-12-27 01:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 01:17:41 --> Controller Class Initialized
INFO - 2016-12-27 01:17:41 --> Helper loaded: url_helper
DEBUG - 2016-12-27 01:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 01:17:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 01:17:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 01:17:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 01:17:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 01:17:41 --> Final output sent to browser
DEBUG - 2016-12-27 01:17:41 --> Total execution time: 1.5974
INFO - 2016-12-27 02:36:48 --> Config Class Initialized
INFO - 2016-12-27 02:36:49 --> Hooks Class Initialized
DEBUG - 2016-12-27 02:36:49 --> UTF-8 Support Enabled
INFO - 2016-12-27 02:36:49 --> Utf8 Class Initialized
INFO - 2016-12-27 02:36:49 --> URI Class Initialized
DEBUG - 2016-12-27 02:36:49 --> No URI present. Default controller set.
INFO - 2016-12-27 02:36:49 --> Router Class Initialized
INFO - 2016-12-27 02:36:49 --> Output Class Initialized
INFO - 2016-12-27 02:36:49 --> Security Class Initialized
DEBUG - 2016-12-27 02:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 02:36:49 --> Input Class Initialized
INFO - 2016-12-27 02:36:49 --> Language Class Initialized
INFO - 2016-12-27 02:36:49 --> Loader Class Initialized
INFO - 2016-12-27 02:36:49 --> Database Driver Class Initialized
INFO - 2016-12-27 02:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 02:36:50 --> Controller Class Initialized
INFO - 2016-12-27 02:36:50 --> Helper loaded: url_helper
DEBUG - 2016-12-27 02:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 02:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 02:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 02:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 02:36:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 02:36:50 --> Final output sent to browser
DEBUG - 2016-12-27 02:36:50 --> Total execution time: 1.5773
INFO - 2016-12-27 03:18:34 --> Config Class Initialized
INFO - 2016-12-27 03:18:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 03:18:35 --> UTF-8 Support Enabled
INFO - 2016-12-27 03:18:35 --> Utf8 Class Initialized
INFO - 2016-12-27 03:18:35 --> URI Class Initialized
DEBUG - 2016-12-27 03:18:35 --> No URI present. Default controller set.
INFO - 2016-12-27 03:18:35 --> Router Class Initialized
INFO - 2016-12-27 03:18:35 --> Output Class Initialized
INFO - 2016-12-27 03:18:35 --> Security Class Initialized
DEBUG - 2016-12-27 03:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 03:18:35 --> Input Class Initialized
INFO - 2016-12-27 03:18:35 --> Language Class Initialized
INFO - 2016-12-27 03:18:35 --> Loader Class Initialized
INFO - 2016-12-27 03:18:35 --> Database Driver Class Initialized
INFO - 2016-12-27 03:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 03:18:35 --> Controller Class Initialized
INFO - 2016-12-27 03:18:35 --> Helper loaded: url_helper
DEBUG - 2016-12-27 03:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 03:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 03:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 03:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 03:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 03:18:36 --> Final output sent to browser
DEBUG - 2016-12-27 03:18:36 --> Total execution time: 1.1876
INFO - 2016-12-27 03:18:36 --> Config Class Initialized
INFO - 2016-12-27 03:18:36 --> Hooks Class Initialized
DEBUG - 2016-12-27 03:18:36 --> UTF-8 Support Enabled
INFO - 2016-12-27 03:18:36 --> Utf8 Class Initialized
INFO - 2016-12-27 03:18:36 --> URI Class Initialized
INFO - 2016-12-27 03:18:36 --> Router Class Initialized
INFO - 2016-12-27 03:18:36 --> Output Class Initialized
INFO - 2016-12-27 03:18:36 --> Security Class Initialized
DEBUG - 2016-12-27 03:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 03:18:36 --> Input Class Initialized
INFO - 2016-12-27 03:18:36 --> Language Class Initialized
INFO - 2016-12-27 03:18:36 --> Loader Class Initialized
INFO - 2016-12-27 03:18:36 --> Database Driver Class Initialized
INFO - 2016-12-27 03:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 03:18:36 --> Controller Class Initialized
INFO - 2016-12-27 03:18:36 --> Helper loaded: url_helper
DEBUG - 2016-12-27 03:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 03:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 03:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 03:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 03:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 03:18:36 --> Final output sent to browser
DEBUG - 2016-12-27 03:18:36 --> Total execution time: 0.0135
INFO - 2016-12-27 03:20:36 --> Config Class Initialized
INFO - 2016-12-27 03:20:36 --> Hooks Class Initialized
DEBUG - 2016-12-27 03:20:36 --> UTF-8 Support Enabled
INFO - 2016-12-27 03:20:36 --> Utf8 Class Initialized
INFO - 2016-12-27 03:20:36 --> URI Class Initialized
DEBUG - 2016-12-27 03:20:36 --> No URI present. Default controller set.
INFO - 2016-12-27 03:20:36 --> Router Class Initialized
INFO - 2016-12-27 03:20:36 --> Output Class Initialized
INFO - 2016-12-27 03:20:36 --> Security Class Initialized
DEBUG - 2016-12-27 03:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 03:20:36 --> Input Class Initialized
INFO - 2016-12-27 03:20:36 --> Language Class Initialized
INFO - 2016-12-27 03:20:36 --> Loader Class Initialized
INFO - 2016-12-27 03:20:36 --> Database Driver Class Initialized
INFO - 2016-12-27 03:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 03:20:36 --> Controller Class Initialized
INFO - 2016-12-27 03:20:36 --> Helper loaded: url_helper
DEBUG - 2016-12-27 03:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 03:20:36 --> Final output sent to browser
DEBUG - 2016-12-27 03:20:36 --> Total execution time: 0.0135
INFO - 2016-12-27 03:20:36 --> Config Class Initialized
INFO - 2016-12-27 03:20:36 --> Hooks Class Initialized
DEBUG - 2016-12-27 03:20:36 --> UTF-8 Support Enabled
INFO - 2016-12-27 03:20:36 --> Utf8 Class Initialized
INFO - 2016-12-27 03:20:36 --> URI Class Initialized
INFO - 2016-12-27 03:20:36 --> Router Class Initialized
INFO - 2016-12-27 03:20:36 --> Output Class Initialized
INFO - 2016-12-27 03:20:36 --> Security Class Initialized
DEBUG - 2016-12-27 03:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 03:20:36 --> Input Class Initialized
INFO - 2016-12-27 03:20:36 --> Language Class Initialized
INFO - 2016-12-27 03:20:36 --> Loader Class Initialized
INFO - 2016-12-27 03:20:36 --> Database Driver Class Initialized
INFO - 2016-12-27 03:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 03:20:36 --> Controller Class Initialized
INFO - 2016-12-27 03:20:36 --> Helper loaded: url_helper
DEBUG - 2016-12-27 03:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 03:20:36 --> Final output sent to browser
DEBUG - 2016-12-27 03:20:36 --> Total execution time: 0.0383
INFO - 2016-12-27 03:52:59 --> Config Class Initialized
INFO - 2016-12-27 03:52:59 --> Hooks Class Initialized
DEBUG - 2016-12-27 03:52:59 --> UTF-8 Support Enabled
INFO - 2016-12-27 03:52:59 --> Utf8 Class Initialized
INFO - 2016-12-27 03:52:59 --> URI Class Initialized
DEBUG - 2016-12-27 03:52:59 --> No URI present. Default controller set.
INFO - 2016-12-27 03:52:59 --> Router Class Initialized
INFO - 2016-12-27 03:52:59 --> Output Class Initialized
INFO - 2016-12-27 03:52:59 --> Security Class Initialized
DEBUG - 2016-12-27 03:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 03:52:59 --> Input Class Initialized
INFO - 2016-12-27 03:52:59 --> Language Class Initialized
INFO - 2016-12-27 03:52:59 --> Loader Class Initialized
INFO - 2016-12-27 03:52:59 --> Database Driver Class Initialized
INFO - 2016-12-27 03:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 03:52:59 --> Controller Class Initialized
INFO - 2016-12-27 03:52:59 --> Helper loaded: url_helper
DEBUG - 2016-12-27 03:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 03:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 03:52:59 --> Final output sent to browser
DEBUG - 2016-12-27 03:52:59 --> Total execution time: 0.0131
INFO - 2016-12-27 17:04:28 --> Config Class Initialized
INFO - 2016-12-27 17:04:28 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:28 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:28 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:28 --> URI Class Initialized
DEBUG - 2016-12-27 17:04:29 --> No URI present. Default controller set.
INFO - 2016-12-27 17:04:29 --> Router Class Initialized
INFO - 2016-12-27 17:04:29 --> Output Class Initialized
INFO - 2016-12-27 17:04:29 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:29 --> Input Class Initialized
INFO - 2016-12-27 17:04:29 --> Language Class Initialized
INFO - 2016-12-27 17:04:29 --> Loader Class Initialized
INFO - 2016-12-27 17:04:29 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:29 --> Controller Class Initialized
INFO - 2016-12-27 17:04:29 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:30 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:30 --> Total execution time: 1.6627
INFO - 2016-12-27 17:04:31 --> Config Class Initialized
INFO - 2016-12-27 17:04:31 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:31 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:31 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:31 --> URI Class Initialized
INFO - 2016-12-27 17:04:31 --> Router Class Initialized
INFO - 2016-12-27 17:04:31 --> Output Class Initialized
INFO - 2016-12-27 17:04:31 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:31 --> Input Class Initialized
INFO - 2016-12-27 17:04:31 --> Language Class Initialized
INFO - 2016-12-27 17:04:31 --> Loader Class Initialized
INFO - 2016-12-27 17:04:31 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:31 --> Controller Class Initialized
INFO - 2016-12-27 17:04:31 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:31 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:31 --> Total execution time: 0.0144
INFO - 2016-12-27 17:04:32 --> Config Class Initialized
INFO - 2016-12-27 17:04:32 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:32 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:32 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:32 --> URI Class Initialized
INFO - 2016-12-27 17:04:32 --> Router Class Initialized
INFO - 2016-12-27 17:04:32 --> Output Class Initialized
INFO - 2016-12-27 17:04:32 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:32 --> Input Class Initialized
INFO - 2016-12-27 17:04:32 --> Language Class Initialized
INFO - 2016-12-27 17:04:32 --> Loader Class Initialized
INFO - 2016-12-27 17:04:32 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:32 --> Controller Class Initialized
INFO - 2016-12-27 17:04:32 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:32 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:32 --> Total execution time: 0.0142
INFO - 2016-12-27 17:04:32 --> Config Class Initialized
INFO - 2016-12-27 17:04:32 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:32 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:32 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:32 --> URI Class Initialized
INFO - 2016-12-27 17:04:32 --> Router Class Initialized
INFO - 2016-12-27 17:04:32 --> Output Class Initialized
INFO - 2016-12-27 17:04:32 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:32 --> Input Class Initialized
INFO - 2016-12-27 17:04:32 --> Language Class Initialized
INFO - 2016-12-27 17:04:32 --> Loader Class Initialized
INFO - 2016-12-27 17:04:32 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:32 --> Controller Class Initialized
INFO - 2016-12-27 17:04:32 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:32 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:32 --> Total execution time: 0.0148
INFO - 2016-12-27 17:04:32 --> Config Class Initialized
INFO - 2016-12-27 17:04:32 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:32 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:32 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:32 --> URI Class Initialized
INFO - 2016-12-27 17:04:32 --> Router Class Initialized
INFO - 2016-12-27 17:04:32 --> Output Class Initialized
INFO - 2016-12-27 17:04:32 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:32 --> Input Class Initialized
INFO - 2016-12-27 17:04:32 --> Language Class Initialized
INFO - 2016-12-27 17:04:32 --> Loader Class Initialized
INFO - 2016-12-27 17:04:32 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:32 --> Controller Class Initialized
INFO - 2016-12-27 17:04:32 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:32 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:32 --> Total execution time: 0.0135
INFO - 2016-12-27 17:04:33 --> Config Class Initialized
INFO - 2016-12-27 17:04:33 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:33 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:33 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:33 --> URI Class Initialized
INFO - 2016-12-27 17:04:33 --> Router Class Initialized
INFO - 2016-12-27 17:04:33 --> Output Class Initialized
INFO - 2016-12-27 17:04:33 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:33 --> Input Class Initialized
INFO - 2016-12-27 17:04:33 --> Language Class Initialized
INFO - 2016-12-27 17:04:33 --> Loader Class Initialized
INFO - 2016-12-27 17:04:33 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:33 --> Controller Class Initialized
INFO - 2016-12-27 17:04:33 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:33 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:33 --> Total execution time: 0.0137
INFO - 2016-12-27 17:04:33 --> Config Class Initialized
INFO - 2016-12-27 17:04:33 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:33 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:33 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:33 --> URI Class Initialized
INFO - 2016-12-27 17:04:33 --> Router Class Initialized
INFO - 2016-12-27 17:04:33 --> Output Class Initialized
INFO - 2016-12-27 17:04:33 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:33 --> Input Class Initialized
INFO - 2016-12-27 17:04:33 --> Language Class Initialized
INFO - 2016-12-27 17:04:33 --> Loader Class Initialized
INFO - 2016-12-27 17:04:33 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:33 --> Controller Class Initialized
INFO - 2016-12-27 17:04:33 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:33 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:33 --> Total execution time: 0.0135
INFO - 2016-12-27 17:04:33 --> Config Class Initialized
INFO - 2016-12-27 17:04:33 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:33 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:33 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:33 --> URI Class Initialized
DEBUG - 2016-12-27 17:04:33 --> No URI present. Default controller set.
INFO - 2016-12-27 17:04:33 --> Router Class Initialized
INFO - 2016-12-27 17:04:33 --> Output Class Initialized
INFO - 2016-12-27 17:04:33 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:33 --> Input Class Initialized
INFO - 2016-12-27 17:04:33 --> Language Class Initialized
INFO - 2016-12-27 17:04:33 --> Loader Class Initialized
INFO - 2016-12-27 17:04:33 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:33 --> Controller Class Initialized
INFO - 2016-12-27 17:04:33 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:33 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:33 --> Total execution time: 0.0161
INFO - 2016-12-27 17:04:34 --> Config Class Initialized
INFO - 2016-12-27 17:04:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:34 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:34 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:34 --> URI Class Initialized
INFO - 2016-12-27 17:04:34 --> Router Class Initialized
INFO - 2016-12-27 17:04:34 --> Output Class Initialized
INFO - 2016-12-27 17:04:34 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:34 --> Input Class Initialized
INFO - 2016-12-27 17:04:34 --> Language Class Initialized
INFO - 2016-12-27 17:04:34 --> Loader Class Initialized
INFO - 2016-12-27 17:04:34 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:34 --> Controller Class Initialized
INFO - 2016-12-27 17:04:34 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:34 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:34 --> Total execution time: 0.0137
INFO - 2016-12-27 17:04:34 --> Config Class Initialized
INFO - 2016-12-27 17:04:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:34 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:34 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:34 --> URI Class Initialized
INFO - 2016-12-27 17:04:34 --> Router Class Initialized
INFO - 2016-12-27 17:04:34 --> Output Class Initialized
INFO - 2016-12-27 17:04:34 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:34 --> Input Class Initialized
INFO - 2016-12-27 17:04:34 --> Language Class Initialized
INFO - 2016-12-27 17:04:34 --> Loader Class Initialized
INFO - 2016-12-27 17:04:34 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:34 --> Controller Class Initialized
INFO - 2016-12-27 17:04:34 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:34 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:34 --> Total execution time: 0.0150
INFO - 2016-12-27 17:04:34 --> Config Class Initialized
INFO - 2016-12-27 17:04:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:34 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:34 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:34 --> URI Class Initialized
INFO - 2016-12-27 17:04:34 --> Router Class Initialized
INFO - 2016-12-27 17:04:34 --> Output Class Initialized
INFO - 2016-12-27 17:04:34 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:34 --> Input Class Initialized
INFO - 2016-12-27 17:04:34 --> Language Class Initialized
INFO - 2016-12-27 17:04:34 --> Loader Class Initialized
INFO - 2016-12-27 17:04:34 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:34 --> Controller Class Initialized
INFO - 2016-12-27 17:04:34 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:34 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:34 --> Total execution time: 0.0145
INFO - 2016-12-27 17:04:35 --> Config Class Initialized
INFO - 2016-12-27 17:04:35 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:35 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:35 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:35 --> URI Class Initialized
INFO - 2016-12-27 17:04:35 --> Router Class Initialized
INFO - 2016-12-27 17:04:35 --> Output Class Initialized
INFO - 2016-12-27 17:04:35 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:35 --> Input Class Initialized
INFO - 2016-12-27 17:04:35 --> Language Class Initialized
INFO - 2016-12-27 17:04:35 --> Loader Class Initialized
INFO - 2016-12-27 17:04:35 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:35 --> Controller Class Initialized
INFO - 2016-12-27 17:04:35 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:35 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:35 --> Total execution time: 0.0159
INFO - 2016-12-27 17:04:35 --> Config Class Initialized
INFO - 2016-12-27 17:04:35 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:35 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:35 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:35 --> URI Class Initialized
INFO - 2016-12-27 17:04:35 --> Router Class Initialized
INFO - 2016-12-27 17:04:35 --> Output Class Initialized
INFO - 2016-12-27 17:04:35 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:35 --> Input Class Initialized
INFO - 2016-12-27 17:04:35 --> Language Class Initialized
INFO - 2016-12-27 17:04:35 --> Loader Class Initialized
INFO - 2016-12-27 17:04:35 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:35 --> Controller Class Initialized
INFO - 2016-12-27 17:04:35 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:35 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:35 --> Total execution time: 0.0138
INFO - 2016-12-27 17:04:35 --> Config Class Initialized
INFO - 2016-12-27 17:04:35 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:04:35 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:04:35 --> Utf8 Class Initialized
INFO - 2016-12-27 17:04:35 --> URI Class Initialized
INFO - 2016-12-27 17:04:35 --> Router Class Initialized
INFO - 2016-12-27 17:04:35 --> Output Class Initialized
INFO - 2016-12-27 17:04:35 --> Security Class Initialized
DEBUG - 2016-12-27 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:04:35 --> Input Class Initialized
INFO - 2016-12-27 17:04:35 --> Language Class Initialized
INFO - 2016-12-27 17:04:35 --> Loader Class Initialized
INFO - 2016-12-27 17:04:35 --> Database Driver Class Initialized
INFO - 2016-12-27 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:04:35 --> Controller Class Initialized
INFO - 2016-12-27 17:04:35 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:04:35 --> Final output sent to browser
DEBUG - 2016-12-27 17:04:35 --> Total execution time: 0.0695
INFO - 2016-12-27 17:18:08 --> Config Class Initialized
INFO - 2016-12-27 17:18:08 --> Hooks Class Initialized
DEBUG - 2016-12-27 17:18:08 --> UTF-8 Support Enabled
INFO - 2016-12-27 17:18:08 --> Utf8 Class Initialized
INFO - 2016-12-27 17:18:08 --> URI Class Initialized
DEBUG - 2016-12-27 17:18:08 --> No URI present. Default controller set.
INFO - 2016-12-27 17:18:08 --> Router Class Initialized
INFO - 2016-12-27 17:18:08 --> Output Class Initialized
INFO - 2016-12-27 17:18:08 --> Security Class Initialized
DEBUG - 2016-12-27 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 17:18:08 --> Input Class Initialized
INFO - 2016-12-27 17:18:08 --> Language Class Initialized
INFO - 2016-12-27 17:18:08 --> Loader Class Initialized
INFO - 2016-12-27 17:18:09 --> Database Driver Class Initialized
INFO - 2016-12-27 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 17:18:09 --> Controller Class Initialized
INFO - 2016-12-27 17:18:09 --> Helper loaded: url_helper
DEBUG - 2016-12-27 17:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 17:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 17:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 17:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 17:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 17:18:10 --> Final output sent to browser
DEBUG - 2016-12-27 17:18:10 --> Total execution time: 1.7957
INFO - 2016-12-27 18:53:10 --> Config Class Initialized
INFO - 2016-12-27 18:53:10 --> Hooks Class Initialized
DEBUG - 2016-12-27 18:53:10 --> UTF-8 Support Enabled
INFO - 2016-12-27 18:53:10 --> Utf8 Class Initialized
INFO - 2016-12-27 18:53:10 --> URI Class Initialized
DEBUG - 2016-12-27 18:53:10 --> No URI present. Default controller set.
INFO - 2016-12-27 18:53:10 --> Router Class Initialized
INFO - 2016-12-27 18:53:10 --> Output Class Initialized
INFO - 2016-12-27 18:53:10 --> Security Class Initialized
DEBUG - 2016-12-27 18:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 18:53:10 --> Input Class Initialized
INFO - 2016-12-27 18:53:10 --> Language Class Initialized
INFO - 2016-12-27 18:53:10 --> Loader Class Initialized
INFO - 2016-12-27 18:53:10 --> Database Driver Class Initialized
INFO - 2016-12-27 18:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 18:53:11 --> Controller Class Initialized
INFO - 2016-12-27 18:53:11 --> Helper loaded: url_helper
DEBUG - 2016-12-27 18:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 18:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 18:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 18:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 18:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 18:53:11 --> Final output sent to browser
DEBUG - 2016-12-27 18:53:11 --> Total execution time: 1.4509
INFO - 2016-12-27 18:58:23 --> Config Class Initialized
INFO - 2016-12-27 18:58:23 --> Hooks Class Initialized
DEBUG - 2016-12-27 18:58:23 --> UTF-8 Support Enabled
INFO - 2016-12-27 18:58:23 --> Utf8 Class Initialized
INFO - 2016-12-27 18:58:23 --> URI Class Initialized
DEBUG - 2016-12-27 18:58:23 --> No URI present. Default controller set.
INFO - 2016-12-27 18:58:23 --> Router Class Initialized
INFO - 2016-12-27 18:58:23 --> Output Class Initialized
INFO - 2016-12-27 18:58:23 --> Security Class Initialized
DEBUG - 2016-12-27 18:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 18:58:23 --> Input Class Initialized
INFO - 2016-12-27 18:58:23 --> Language Class Initialized
INFO - 2016-12-27 18:58:23 --> Loader Class Initialized
INFO - 2016-12-27 18:58:23 --> Database Driver Class Initialized
INFO - 2016-12-27 18:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 18:58:23 --> Controller Class Initialized
INFO - 2016-12-27 18:58:23 --> Helper loaded: url_helper
DEBUG - 2016-12-27 18:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 18:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 18:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 18:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 18:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 18:58:23 --> Final output sent to browser
DEBUG - 2016-12-27 18:58:23 --> Total execution time: 0.0138
INFO - 2016-12-27 20:26:27 --> Config Class Initialized
INFO - 2016-12-27 20:26:27 --> Hooks Class Initialized
DEBUG - 2016-12-27 20:26:28 --> UTF-8 Support Enabled
INFO - 2016-12-27 20:26:28 --> Utf8 Class Initialized
INFO - 2016-12-27 20:26:28 --> URI Class Initialized
DEBUG - 2016-12-27 20:26:28 --> No URI present. Default controller set.
INFO - 2016-12-27 20:26:28 --> Router Class Initialized
INFO - 2016-12-27 20:26:28 --> Output Class Initialized
INFO - 2016-12-27 20:26:28 --> Security Class Initialized
DEBUG - 2016-12-27 20:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 20:26:28 --> Input Class Initialized
INFO - 2016-12-27 20:26:28 --> Language Class Initialized
INFO - 2016-12-27 20:26:28 --> Loader Class Initialized
INFO - 2016-12-27 20:26:28 --> Database Driver Class Initialized
INFO - 2016-12-27 20:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 20:26:29 --> Controller Class Initialized
INFO - 2016-12-27 20:26:29 --> Helper loaded: url_helper
DEBUG - 2016-12-27 20:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 20:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 20:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 20:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 20:26:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 20:26:29 --> Final output sent to browser
DEBUG - 2016-12-27 20:26:29 --> Total execution time: 1.3677
INFO - 2016-12-27 21:53:56 --> Config Class Initialized
INFO - 2016-12-27 21:53:56 --> Hooks Class Initialized
DEBUG - 2016-12-27 21:53:56 --> UTF-8 Support Enabled
INFO - 2016-12-27 21:53:57 --> Utf8 Class Initialized
INFO - 2016-12-27 21:53:57 --> URI Class Initialized
DEBUG - 2016-12-27 21:53:57 --> No URI present. Default controller set.
INFO - 2016-12-27 21:53:57 --> Router Class Initialized
INFO - 2016-12-27 21:53:57 --> Output Class Initialized
INFO - 2016-12-27 21:53:57 --> Security Class Initialized
DEBUG - 2016-12-27 21:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 21:53:57 --> Input Class Initialized
INFO - 2016-12-27 21:53:57 --> Language Class Initialized
INFO - 2016-12-27 21:53:57 --> Loader Class Initialized
INFO - 2016-12-27 21:53:57 --> Database Driver Class Initialized
INFO - 2016-12-27 21:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 21:53:57 --> Controller Class Initialized
INFO - 2016-12-27 21:53:57 --> Helper loaded: url_helper
DEBUG - 2016-12-27 21:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 21:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 21:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 21:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 21:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 21:53:58 --> Final output sent to browser
DEBUG - 2016-12-27 21:53:58 --> Total execution time: 1.4399
INFO - 2016-12-27 21:55:25 --> Config Class Initialized
INFO - 2016-12-27 21:55:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 21:55:25 --> UTF-8 Support Enabled
INFO - 2016-12-27 21:55:25 --> Utf8 Class Initialized
INFO - 2016-12-27 21:55:25 --> URI Class Initialized
DEBUG - 2016-12-27 21:55:25 --> No URI present. Default controller set.
INFO - 2016-12-27 21:55:25 --> Router Class Initialized
INFO - 2016-12-27 21:55:25 --> Output Class Initialized
INFO - 2016-12-27 21:55:25 --> Security Class Initialized
DEBUG - 2016-12-27 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-27 21:55:25 --> Input Class Initialized
INFO - 2016-12-27 21:55:25 --> Language Class Initialized
INFO - 2016-12-27 21:55:25 --> Loader Class Initialized
INFO - 2016-12-27 21:55:25 --> Database Driver Class Initialized
INFO - 2016-12-27 21:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-27 21:55:25 --> Controller Class Initialized
INFO - 2016-12-27 21:55:25 --> Helper loaded: url_helper
DEBUG - 2016-12-27 21:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-27 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-27 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-27 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-27 21:55:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-27 21:55:25 --> Final output sent to browser
DEBUG - 2016-12-27 21:55:25 --> Total execution time: 0.7424

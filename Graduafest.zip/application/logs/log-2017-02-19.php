<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-19 02:08:42 --> Config Class Initialized
INFO - 2017-02-19 02:08:42 --> Hooks Class Initialized
DEBUG - 2017-02-19 02:08:42 --> UTF-8 Support Enabled
INFO - 2017-02-19 02:08:42 --> Utf8 Class Initialized
INFO - 2017-02-19 02:08:42 --> URI Class Initialized
DEBUG - 2017-02-19 02:08:42 --> No URI present. Default controller set.
INFO - 2017-02-19 02:08:42 --> Router Class Initialized
INFO - 2017-02-19 02:08:42 --> Output Class Initialized
INFO - 2017-02-19 02:08:42 --> Security Class Initialized
DEBUG - 2017-02-19 02:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 02:08:42 --> Input Class Initialized
INFO - 2017-02-19 02:08:42 --> Language Class Initialized
INFO - 2017-02-19 02:08:42 --> Loader Class Initialized
INFO - 2017-02-19 02:08:42 --> Database Driver Class Initialized
INFO - 2017-02-19 02:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 02:08:42 --> Controller Class Initialized
INFO - 2017-02-19 02:08:42 --> Helper loaded: url_helper
DEBUG - 2017-02-19 02:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 02:08:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 02:08:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 02:08:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 02:08:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 02:08:42 --> Final output sent to browser
DEBUG - 2017-02-19 02:08:42 --> Total execution time: 0.0215
INFO - 2017-02-19 02:08:50 --> Config Class Initialized
INFO - 2017-02-19 02:08:50 --> Hooks Class Initialized
DEBUG - 2017-02-19 02:08:50 --> UTF-8 Support Enabled
INFO - 2017-02-19 02:08:50 --> Utf8 Class Initialized
INFO - 2017-02-19 02:08:50 --> URI Class Initialized
INFO - 2017-02-19 02:08:50 --> Router Class Initialized
INFO - 2017-02-19 02:08:50 --> Output Class Initialized
INFO - 2017-02-19 02:08:50 --> Security Class Initialized
DEBUG - 2017-02-19 02:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 02:08:50 --> Input Class Initialized
INFO - 2017-02-19 02:08:50 --> Language Class Initialized
INFO - 2017-02-19 02:08:50 --> Loader Class Initialized
INFO - 2017-02-19 02:08:50 --> Database Driver Class Initialized
INFO - 2017-02-19 02:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 02:08:50 --> Controller Class Initialized
INFO - 2017-02-19 02:08:50 --> Helper loaded: url_helper
DEBUG - 2017-02-19 02:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 02:08:53 --> Config Class Initialized
INFO - 2017-02-19 02:08:53 --> Hooks Class Initialized
DEBUG - 2017-02-19 02:08:53 --> UTF-8 Support Enabled
INFO - 2017-02-19 02:08:53 --> Utf8 Class Initialized
INFO - 2017-02-19 02:08:53 --> URI Class Initialized
INFO - 2017-02-19 02:08:53 --> Router Class Initialized
INFO - 2017-02-19 02:08:53 --> Output Class Initialized
INFO - 2017-02-19 02:08:53 --> Security Class Initialized
DEBUG - 2017-02-19 02:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 02:08:53 --> Input Class Initialized
INFO - 2017-02-19 02:08:53 --> Language Class Initialized
INFO - 2017-02-19 02:08:53 --> Loader Class Initialized
INFO - 2017-02-19 02:08:53 --> Database Driver Class Initialized
INFO - 2017-02-19 02:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 02:08:53 --> Controller Class Initialized
INFO - 2017-02-19 02:08:53 --> Helper loaded: date_helper
DEBUG - 2017-02-19 02:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 02:08:53 --> Helper loaded: url_helper
INFO - 2017-02-19 02:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 02:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-19 02:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-19 02:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-19 02:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 02:08:53 --> Final output sent to browser
DEBUG - 2017-02-19 02:08:53 --> Total execution time: 0.1374
INFO - 2017-02-19 02:09:24 --> Config Class Initialized
INFO - 2017-02-19 02:09:24 --> Hooks Class Initialized
DEBUG - 2017-02-19 02:09:24 --> UTF-8 Support Enabled
INFO - 2017-02-19 02:09:24 --> Utf8 Class Initialized
INFO - 2017-02-19 02:09:24 --> URI Class Initialized
INFO - 2017-02-19 02:09:24 --> Router Class Initialized
INFO - 2017-02-19 02:09:24 --> Output Class Initialized
INFO - 2017-02-19 02:09:24 --> Security Class Initialized
DEBUG - 2017-02-19 02:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 02:09:24 --> Input Class Initialized
INFO - 2017-02-19 02:09:24 --> Language Class Initialized
INFO - 2017-02-19 02:09:24 --> Loader Class Initialized
INFO - 2017-02-19 02:09:24 --> Database Driver Class Initialized
INFO - 2017-02-19 02:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 02:09:24 --> Controller Class Initialized
INFO - 2017-02-19 02:09:24 --> Upload Class Initialized
INFO - 2017-02-19 02:09:24 --> Helper loaded: date_helper
DEBUG - 2017-02-19 02:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 02:09:24 --> Helper loaded: url_helper
INFO - 2017-02-19 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-19 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-02-19 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-02-19 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-19 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 02:09:24 --> Final output sent to browser
DEBUG - 2017-02-19 02:09:24 --> Total execution time: 0.2584
INFO - 2017-02-19 02:09:35 --> Config Class Initialized
INFO - 2017-02-19 02:09:35 --> Hooks Class Initialized
DEBUG - 2017-02-19 02:09:35 --> UTF-8 Support Enabled
INFO - 2017-02-19 02:09:35 --> Utf8 Class Initialized
INFO - 2017-02-19 02:09:35 --> URI Class Initialized
INFO - 2017-02-19 02:09:35 --> Router Class Initialized
INFO - 2017-02-19 02:09:35 --> Output Class Initialized
INFO - 2017-02-19 02:09:35 --> Security Class Initialized
DEBUG - 2017-02-19 02:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 02:09:35 --> Input Class Initialized
INFO - 2017-02-19 02:09:35 --> Language Class Initialized
INFO - 2017-02-19 02:09:35 --> Loader Class Initialized
INFO - 2017-02-19 02:09:35 --> Database Driver Class Initialized
INFO - 2017-02-19 02:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 02:09:35 --> Controller Class Initialized
INFO - 2017-02-19 02:09:35 --> Helper loaded: date_helper
DEBUG - 2017-02-19 02:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 02:09:35 --> Helper loaded: url_helper
INFO - 2017-02-19 02:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 02:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-19 02:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-19 02:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-19 02:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 02:09:35 --> Final output sent to browser
DEBUG - 2017-02-19 02:09:35 --> Total execution time: 0.0238
INFO - 2017-02-19 03:16:58 --> Config Class Initialized
INFO - 2017-02-19 03:16:58 --> Hooks Class Initialized
DEBUG - 2017-02-19 03:16:58 --> UTF-8 Support Enabled
INFO - 2017-02-19 03:16:58 --> Utf8 Class Initialized
INFO - 2017-02-19 03:16:58 --> URI Class Initialized
INFO - 2017-02-19 03:16:58 --> Router Class Initialized
INFO - 2017-02-19 03:16:58 --> Output Class Initialized
INFO - 2017-02-19 03:16:58 --> Security Class Initialized
DEBUG - 2017-02-19 03:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 03:16:58 --> Input Class Initialized
INFO - 2017-02-19 03:16:58 --> Language Class Initialized
INFO - 2017-02-19 03:16:58 --> Loader Class Initialized
INFO - 2017-02-19 03:16:58 --> Database Driver Class Initialized
INFO - 2017-02-19 03:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 03:16:58 --> Controller Class Initialized
INFO - 2017-02-19 03:16:58 --> Helper loaded: url_helper
DEBUG - 2017-02-19 03:16:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 03:16:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 03:16:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 03:16:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 03:16:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 03:16:58 --> Final output sent to browser
DEBUG - 2017-02-19 03:16:58 --> Total execution time: 0.0134
INFO - 2017-02-19 03:17:00 --> Config Class Initialized
INFO - 2017-02-19 03:17:00 --> Hooks Class Initialized
DEBUG - 2017-02-19 03:17:00 --> UTF-8 Support Enabled
INFO - 2017-02-19 03:17:00 --> Utf8 Class Initialized
INFO - 2017-02-19 03:17:00 --> URI Class Initialized
DEBUG - 2017-02-19 03:17:00 --> No URI present. Default controller set.
INFO - 2017-02-19 03:17:00 --> Router Class Initialized
INFO - 2017-02-19 03:17:00 --> Output Class Initialized
INFO - 2017-02-19 03:17:00 --> Security Class Initialized
DEBUG - 2017-02-19 03:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 03:17:00 --> Input Class Initialized
INFO - 2017-02-19 03:17:00 --> Language Class Initialized
INFO - 2017-02-19 03:17:00 --> Loader Class Initialized
INFO - 2017-02-19 03:17:00 --> Database Driver Class Initialized
INFO - 2017-02-19 03:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 03:17:00 --> Controller Class Initialized
INFO - 2017-02-19 03:17:00 --> Helper loaded: url_helper
DEBUG - 2017-02-19 03:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 03:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 03:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 03:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 03:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 03:17:00 --> Final output sent to browser
DEBUG - 2017-02-19 03:17:00 --> Total execution time: 0.0135
INFO - 2017-02-19 03:20:52 --> Config Class Initialized
INFO - 2017-02-19 03:20:52 --> Hooks Class Initialized
DEBUG - 2017-02-19 03:20:52 --> UTF-8 Support Enabled
INFO - 2017-02-19 03:20:52 --> Utf8 Class Initialized
INFO - 2017-02-19 03:20:52 --> URI Class Initialized
INFO - 2017-02-19 03:20:52 --> Router Class Initialized
INFO - 2017-02-19 03:20:52 --> Output Class Initialized
INFO - 2017-02-19 03:20:52 --> Security Class Initialized
DEBUG - 2017-02-19 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 03:20:52 --> Input Class Initialized
INFO - 2017-02-19 03:20:52 --> Language Class Initialized
INFO - 2017-02-19 03:20:52 --> Loader Class Initialized
INFO - 2017-02-19 03:20:52 --> Database Driver Class Initialized
INFO - 2017-02-19 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 03:20:52 --> Controller Class Initialized
INFO - 2017-02-19 03:20:52 --> Helper loaded: url_helper
DEBUG - 2017-02-19 03:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 03:20:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 03:20:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 03:20:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 03:20:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 03:20:52 --> Final output sent to browser
DEBUG - 2017-02-19 03:20:52 --> Total execution time: 0.0137
INFO - 2017-02-19 05:03:46 --> Config Class Initialized
INFO - 2017-02-19 05:03:46 --> Hooks Class Initialized
DEBUG - 2017-02-19 05:03:46 --> UTF-8 Support Enabled
INFO - 2017-02-19 05:03:46 --> Utf8 Class Initialized
INFO - 2017-02-19 05:03:46 --> URI Class Initialized
INFO - 2017-02-19 05:03:46 --> Router Class Initialized
INFO - 2017-02-19 05:03:46 --> Output Class Initialized
INFO - 2017-02-19 05:03:46 --> Security Class Initialized
DEBUG - 2017-02-19 05:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 05:03:46 --> Input Class Initialized
INFO - 2017-02-19 05:03:46 --> Language Class Initialized
INFO - 2017-02-19 05:03:46 --> Loader Class Initialized
INFO - 2017-02-19 05:03:46 --> Database Driver Class Initialized
INFO - 2017-02-19 05:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 05:03:46 --> Controller Class Initialized
INFO - 2017-02-19 05:03:46 --> Helper loaded: url_helper
DEBUG - 2017-02-19 05:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 05:03:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 05:03:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 05:03:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 05:03:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 05:03:46 --> Final output sent to browser
DEBUG - 2017-02-19 05:03:46 --> Total execution time: 0.2729
INFO - 2017-02-19 05:23:44 --> Config Class Initialized
INFO - 2017-02-19 05:23:44 --> Hooks Class Initialized
DEBUG - 2017-02-19 05:23:44 --> UTF-8 Support Enabled
INFO - 2017-02-19 05:23:44 --> Utf8 Class Initialized
INFO - 2017-02-19 05:23:44 --> URI Class Initialized
DEBUG - 2017-02-19 05:23:44 --> No URI present. Default controller set.
INFO - 2017-02-19 05:23:44 --> Router Class Initialized
INFO - 2017-02-19 05:23:44 --> Output Class Initialized
INFO - 2017-02-19 05:23:44 --> Security Class Initialized
DEBUG - 2017-02-19 05:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 05:23:44 --> Input Class Initialized
INFO - 2017-02-19 05:23:44 --> Language Class Initialized
INFO - 2017-02-19 05:23:44 --> Loader Class Initialized
INFO - 2017-02-19 05:23:44 --> Database Driver Class Initialized
INFO - 2017-02-19 05:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 05:23:44 --> Controller Class Initialized
INFO - 2017-02-19 05:23:44 --> Helper loaded: url_helper
DEBUG - 2017-02-19 05:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 05:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 05:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 05:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 05:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 05:23:44 --> Final output sent to browser
DEBUG - 2017-02-19 05:23:44 --> Total execution time: 0.0181
INFO - 2017-02-19 07:13:21 --> Config Class Initialized
INFO - 2017-02-19 07:13:21 --> Hooks Class Initialized
DEBUG - 2017-02-19 07:13:21 --> UTF-8 Support Enabled
INFO - 2017-02-19 07:13:21 --> Utf8 Class Initialized
INFO - 2017-02-19 07:13:21 --> URI Class Initialized
INFO - 2017-02-19 07:13:21 --> Router Class Initialized
INFO - 2017-02-19 07:13:21 --> Output Class Initialized
INFO - 2017-02-19 07:13:21 --> Security Class Initialized
DEBUG - 2017-02-19 07:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 07:13:21 --> Input Class Initialized
INFO - 2017-02-19 07:13:21 --> Language Class Initialized
INFO - 2017-02-19 07:13:21 --> Loader Class Initialized
INFO - 2017-02-19 07:13:21 --> Database Driver Class Initialized
INFO - 2017-02-19 07:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 07:13:21 --> Controller Class Initialized
INFO - 2017-02-19 07:13:21 --> Helper loaded: url_helper
DEBUG - 2017-02-19 07:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 07:13:21 --> Final output sent to browser
DEBUG - 2017-02-19 07:13:21 --> Total execution time: 0.0137
INFO - 2017-02-19 07:13:21 --> Config Class Initialized
INFO - 2017-02-19 07:13:21 --> Hooks Class Initialized
DEBUG - 2017-02-19 07:13:21 --> UTF-8 Support Enabled
INFO - 2017-02-19 07:13:21 --> Utf8 Class Initialized
INFO - 2017-02-19 07:13:21 --> URI Class Initialized
DEBUG - 2017-02-19 07:13:21 --> No URI present. Default controller set.
INFO - 2017-02-19 07:13:21 --> Router Class Initialized
INFO - 2017-02-19 07:13:21 --> Output Class Initialized
INFO - 2017-02-19 07:13:21 --> Security Class Initialized
DEBUG - 2017-02-19 07:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 07:13:21 --> Input Class Initialized
INFO - 2017-02-19 07:13:21 --> Language Class Initialized
INFO - 2017-02-19 07:13:21 --> Loader Class Initialized
INFO - 2017-02-19 07:13:21 --> Database Driver Class Initialized
INFO - 2017-02-19 07:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 07:13:21 --> Controller Class Initialized
INFO - 2017-02-19 07:13:21 --> Helper loaded: url_helper
DEBUG - 2017-02-19 07:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 07:13:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 07:13:21 --> Final output sent to browser
DEBUG - 2017-02-19 07:13:21 --> Total execution time: 0.0133
INFO - 2017-02-19 07:16:11 --> Config Class Initialized
INFO - 2017-02-19 07:16:11 --> Hooks Class Initialized
DEBUG - 2017-02-19 07:16:11 --> UTF-8 Support Enabled
INFO - 2017-02-19 07:16:11 --> Utf8 Class Initialized
INFO - 2017-02-19 07:16:11 --> URI Class Initialized
INFO - 2017-02-19 07:16:11 --> Router Class Initialized
INFO - 2017-02-19 07:16:11 --> Output Class Initialized
INFO - 2017-02-19 07:16:11 --> Security Class Initialized
DEBUG - 2017-02-19 07:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 07:16:11 --> Input Class Initialized
INFO - 2017-02-19 07:16:11 --> Language Class Initialized
INFO - 2017-02-19 07:16:11 --> Loader Class Initialized
INFO - 2017-02-19 07:16:11 --> Database Driver Class Initialized
INFO - 2017-02-19 07:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 07:16:11 --> Controller Class Initialized
INFO - 2017-02-19 07:16:11 --> Helper loaded: url_helper
DEBUG - 2017-02-19 07:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 07:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 07:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 07:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 07:16:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 07:16:11 --> Final output sent to browser
DEBUG - 2017-02-19 07:16:11 --> Total execution time: 0.0136
INFO - 2017-02-19 07:25:08 --> Config Class Initialized
INFO - 2017-02-19 07:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-19 07:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-19 07:25:08 --> Utf8 Class Initialized
INFO - 2017-02-19 07:25:08 --> URI Class Initialized
DEBUG - 2017-02-19 07:25:08 --> No URI present. Default controller set.
INFO - 2017-02-19 07:25:08 --> Router Class Initialized
INFO - 2017-02-19 07:25:08 --> Output Class Initialized
INFO - 2017-02-19 07:25:08 --> Security Class Initialized
DEBUG - 2017-02-19 07:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 07:25:08 --> Input Class Initialized
INFO - 2017-02-19 07:25:08 --> Language Class Initialized
INFO - 2017-02-19 07:25:08 --> Loader Class Initialized
INFO - 2017-02-19 07:25:08 --> Database Driver Class Initialized
INFO - 2017-02-19 07:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 07:25:08 --> Controller Class Initialized
INFO - 2017-02-19 07:25:08 --> Helper loaded: url_helper
DEBUG - 2017-02-19 07:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 07:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 07:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 07:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 07:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 07:25:08 --> Final output sent to browser
DEBUG - 2017-02-19 07:25:08 --> Total execution time: 0.4454
INFO - 2017-02-19 08:27:09 --> Config Class Initialized
INFO - 2017-02-19 08:27:09 --> Hooks Class Initialized
DEBUG - 2017-02-19 08:27:09 --> UTF-8 Support Enabled
INFO - 2017-02-19 08:27:09 --> Utf8 Class Initialized
INFO - 2017-02-19 08:27:09 --> URI Class Initialized
DEBUG - 2017-02-19 08:27:09 --> No URI present. Default controller set.
INFO - 2017-02-19 08:27:09 --> Router Class Initialized
INFO - 2017-02-19 08:27:09 --> Output Class Initialized
INFO - 2017-02-19 08:27:09 --> Security Class Initialized
DEBUG - 2017-02-19 08:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 08:27:09 --> Input Class Initialized
INFO - 2017-02-19 08:27:09 --> Language Class Initialized
INFO - 2017-02-19 08:27:09 --> Loader Class Initialized
INFO - 2017-02-19 08:27:09 --> Database Driver Class Initialized
INFO - 2017-02-19 08:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 08:27:09 --> Controller Class Initialized
INFO - 2017-02-19 08:27:09 --> Helper loaded: url_helper
DEBUG - 2017-02-19 08:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 08:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 08:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 08:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 08:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 08:27:09 --> Final output sent to browser
DEBUG - 2017-02-19 08:27:09 --> Total execution time: 0.0135
INFO - 2017-02-19 08:27:26 --> Config Class Initialized
INFO - 2017-02-19 08:27:26 --> Hooks Class Initialized
DEBUG - 2017-02-19 08:27:26 --> UTF-8 Support Enabled
INFO - 2017-02-19 08:27:26 --> Utf8 Class Initialized
INFO - 2017-02-19 08:27:26 --> URI Class Initialized
INFO - 2017-02-19 08:27:26 --> Router Class Initialized
INFO - 2017-02-19 08:27:26 --> Output Class Initialized
INFO - 2017-02-19 08:27:26 --> Security Class Initialized
DEBUG - 2017-02-19 08:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 08:27:26 --> Input Class Initialized
INFO - 2017-02-19 08:27:26 --> Language Class Initialized
INFO - 2017-02-19 08:27:26 --> Loader Class Initialized
INFO - 2017-02-19 08:27:26 --> Database Driver Class Initialized
INFO - 2017-02-19 08:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 08:27:26 --> Controller Class Initialized
INFO - 2017-02-19 08:27:26 --> Helper loaded: url_helper
DEBUG - 2017-02-19 08:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 08:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 08:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 08:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 08:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 08:27:26 --> Final output sent to browser
DEBUG - 2017-02-19 08:27:26 --> Total execution time: 0.0153
INFO - 2017-02-19 08:38:48 --> Config Class Initialized
INFO - 2017-02-19 08:38:48 --> Hooks Class Initialized
DEBUG - 2017-02-19 08:38:48 --> UTF-8 Support Enabled
INFO - 2017-02-19 08:38:48 --> Utf8 Class Initialized
INFO - 2017-02-19 08:38:48 --> URI Class Initialized
INFO - 2017-02-19 08:38:48 --> Router Class Initialized
INFO - 2017-02-19 08:38:48 --> Output Class Initialized
INFO - 2017-02-19 08:38:48 --> Security Class Initialized
DEBUG - 2017-02-19 08:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 08:38:48 --> Input Class Initialized
INFO - 2017-02-19 08:38:48 --> Language Class Initialized
INFO - 2017-02-19 08:38:48 --> Loader Class Initialized
INFO - 2017-02-19 08:38:48 --> Database Driver Class Initialized
INFO - 2017-02-19 08:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 08:38:48 --> Controller Class Initialized
INFO - 2017-02-19 08:38:48 --> Helper loaded: url_helper
DEBUG - 2017-02-19 08:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 08:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 08:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 08:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 08:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 08:38:48 --> Final output sent to browser
DEBUG - 2017-02-19 08:38:48 --> Total execution time: 0.0138
INFO - 2017-02-19 08:54:33 --> Config Class Initialized
INFO - 2017-02-19 08:54:33 --> Hooks Class Initialized
DEBUG - 2017-02-19 08:54:33 --> UTF-8 Support Enabled
INFO - 2017-02-19 08:54:33 --> Utf8 Class Initialized
INFO - 2017-02-19 08:54:33 --> URI Class Initialized
INFO - 2017-02-19 08:54:33 --> Router Class Initialized
INFO - 2017-02-19 08:54:33 --> Output Class Initialized
INFO - 2017-02-19 08:54:33 --> Security Class Initialized
DEBUG - 2017-02-19 08:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 08:54:33 --> Input Class Initialized
INFO - 2017-02-19 08:54:33 --> Language Class Initialized
INFO - 2017-02-19 08:54:33 --> Loader Class Initialized
INFO - 2017-02-19 08:54:33 --> Database Driver Class Initialized
INFO - 2017-02-19 08:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 08:54:33 --> Controller Class Initialized
INFO - 2017-02-19 08:54:33 --> Helper loaded: url_helper
DEBUG - 2017-02-19 08:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 08:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 08:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 08:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 08:54:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 08:54:33 --> Final output sent to browser
DEBUG - 2017-02-19 08:54:33 --> Total execution time: 0.0137
INFO - 2017-02-19 15:18:13 --> Config Class Initialized
INFO - 2017-02-19 15:18:13 --> Hooks Class Initialized
DEBUG - 2017-02-19 15:18:13 --> UTF-8 Support Enabled
INFO - 2017-02-19 15:18:13 --> Utf8 Class Initialized
INFO - 2017-02-19 15:18:13 --> URI Class Initialized
DEBUG - 2017-02-19 15:18:13 --> No URI present. Default controller set.
INFO - 2017-02-19 15:18:13 --> Router Class Initialized
INFO - 2017-02-19 15:18:13 --> Output Class Initialized
INFO - 2017-02-19 15:18:13 --> Security Class Initialized
DEBUG - 2017-02-19 15:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 15:18:13 --> Input Class Initialized
INFO - 2017-02-19 15:18:13 --> Language Class Initialized
INFO - 2017-02-19 15:18:13 --> Loader Class Initialized
INFO - 2017-02-19 15:18:13 --> Database Driver Class Initialized
INFO - 2017-02-19 15:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 15:18:14 --> Controller Class Initialized
INFO - 2017-02-19 15:18:14 --> Helper loaded: url_helper
DEBUG - 2017-02-19 15:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 15:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 15:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 15:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 15:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 15:18:14 --> Final output sent to browser
DEBUG - 2017-02-19 15:18:14 --> Total execution time: 0.2344
INFO - 2017-02-19 18:04:31 --> Config Class Initialized
INFO - 2017-02-19 18:04:31 --> Hooks Class Initialized
DEBUG - 2017-02-19 18:04:31 --> UTF-8 Support Enabled
INFO - 2017-02-19 18:04:31 --> Utf8 Class Initialized
INFO - 2017-02-19 18:04:31 --> URI Class Initialized
INFO - 2017-02-19 18:04:31 --> Router Class Initialized
INFO - 2017-02-19 18:04:31 --> Output Class Initialized
INFO - 2017-02-19 18:04:31 --> Security Class Initialized
DEBUG - 2017-02-19 18:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 18:04:31 --> Input Class Initialized
INFO - 2017-02-19 18:04:31 --> Language Class Initialized
INFO - 2017-02-19 18:04:31 --> Loader Class Initialized
INFO - 2017-02-19 18:04:31 --> Database Driver Class Initialized
INFO - 2017-02-19 18:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 18:04:31 --> Controller Class Initialized
INFO - 2017-02-19 18:04:31 --> Helper loaded: url_helper
DEBUG - 2017-02-19 18:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 18:04:31 --> Final output sent to browser
DEBUG - 2017-02-19 18:04:31 --> Total execution time: 0.3040
INFO - 2017-02-19 18:04:31 --> Config Class Initialized
INFO - 2017-02-19 18:04:31 --> Hooks Class Initialized
DEBUG - 2017-02-19 18:04:31 --> UTF-8 Support Enabled
INFO - 2017-02-19 18:04:31 --> Utf8 Class Initialized
INFO - 2017-02-19 18:04:31 --> URI Class Initialized
DEBUG - 2017-02-19 18:04:31 --> No URI present. Default controller set.
INFO - 2017-02-19 18:04:31 --> Router Class Initialized
INFO - 2017-02-19 18:04:31 --> Output Class Initialized
INFO - 2017-02-19 18:04:31 --> Security Class Initialized
DEBUG - 2017-02-19 18:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 18:04:31 --> Input Class Initialized
INFO - 2017-02-19 18:04:31 --> Language Class Initialized
INFO - 2017-02-19 18:04:31 --> Loader Class Initialized
INFO - 2017-02-19 18:04:31 --> Database Driver Class Initialized
INFO - 2017-02-19 18:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 18:04:31 --> Controller Class Initialized
INFO - 2017-02-19 18:04:31 --> Helper loaded: url_helper
DEBUG - 2017-02-19 18:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 18:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 18:04:31 --> Final output sent to browser
DEBUG - 2017-02-19 18:04:31 --> Total execution time: 0.0135
INFO - 2017-02-19 18:04:50 --> Config Class Initialized
INFO - 2017-02-19 18:04:50 --> Hooks Class Initialized
DEBUG - 2017-02-19 18:04:50 --> UTF-8 Support Enabled
INFO - 2017-02-19 18:04:50 --> Utf8 Class Initialized
INFO - 2017-02-19 18:04:50 --> URI Class Initialized
INFO - 2017-02-19 18:04:50 --> Router Class Initialized
INFO - 2017-02-19 18:04:50 --> Output Class Initialized
INFO - 2017-02-19 18:04:50 --> Security Class Initialized
DEBUG - 2017-02-19 18:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 18:04:50 --> Input Class Initialized
INFO - 2017-02-19 18:04:50 --> Language Class Initialized
INFO - 2017-02-19 18:04:50 --> Loader Class Initialized
INFO - 2017-02-19 18:04:50 --> Database Driver Class Initialized
INFO - 2017-02-19 18:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 18:04:50 --> Controller Class Initialized
INFO - 2017-02-19 18:04:50 --> Helper loaded: url_helper
DEBUG - 2017-02-19 18:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 18:04:50 --> Final output sent to browser
DEBUG - 2017-02-19 18:04:50 --> Total execution time: 0.0422
INFO - 2017-02-19 18:04:50 --> Config Class Initialized
INFO - 2017-02-19 18:04:50 --> Hooks Class Initialized
DEBUG - 2017-02-19 18:04:50 --> UTF-8 Support Enabled
INFO - 2017-02-19 18:04:50 --> Utf8 Class Initialized
INFO - 2017-02-19 18:04:50 --> URI Class Initialized
DEBUG - 2017-02-19 18:04:50 --> No URI present. Default controller set.
INFO - 2017-02-19 18:04:50 --> Router Class Initialized
INFO - 2017-02-19 18:04:50 --> Output Class Initialized
INFO - 2017-02-19 18:04:50 --> Security Class Initialized
DEBUG - 2017-02-19 18:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 18:04:50 --> Input Class Initialized
INFO - 2017-02-19 18:04:50 --> Language Class Initialized
INFO - 2017-02-19 18:04:50 --> Loader Class Initialized
INFO - 2017-02-19 18:04:50 --> Database Driver Class Initialized
INFO - 2017-02-19 18:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 18:04:50 --> Controller Class Initialized
INFO - 2017-02-19 18:04:50 --> Helper loaded: url_helper
DEBUG - 2017-02-19 18:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 18:04:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 18:04:50 --> Final output sent to browser
DEBUG - 2017-02-19 18:04:50 --> Total execution time: 0.0129
INFO - 2017-02-19 20:43:43 --> Config Class Initialized
INFO - 2017-02-19 20:43:43 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:43:43 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:43:43 --> Utf8 Class Initialized
INFO - 2017-02-19 20:43:43 --> URI Class Initialized
DEBUG - 2017-02-19 20:43:43 --> No URI present. Default controller set.
INFO - 2017-02-19 20:43:43 --> Router Class Initialized
INFO - 2017-02-19 20:43:43 --> Output Class Initialized
INFO - 2017-02-19 20:43:43 --> Security Class Initialized
DEBUG - 2017-02-19 20:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:43:43 --> Input Class Initialized
INFO - 2017-02-19 20:43:43 --> Language Class Initialized
INFO - 2017-02-19 20:43:43 --> Loader Class Initialized
INFO - 2017-02-19 20:43:43 --> Database Driver Class Initialized
INFO - 2017-02-19 20:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:43:43 --> Controller Class Initialized
INFO - 2017-02-19 20:43:43 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:43:43 --> Final output sent to browser
DEBUG - 2017-02-19 20:43:43 --> Total execution time: 0.0139
INFO - 2017-02-19 20:43:50 --> Config Class Initialized
INFO - 2017-02-19 20:43:50 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:43:50 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:43:50 --> Utf8 Class Initialized
INFO - 2017-02-19 20:43:50 --> URI Class Initialized
INFO - 2017-02-19 20:43:50 --> Router Class Initialized
INFO - 2017-02-19 20:43:50 --> Output Class Initialized
INFO - 2017-02-19 20:43:50 --> Security Class Initialized
DEBUG - 2017-02-19 20:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:43:50 --> Input Class Initialized
INFO - 2017-02-19 20:43:50 --> Language Class Initialized
INFO - 2017-02-19 20:43:50 --> Loader Class Initialized
INFO - 2017-02-19 20:43:50 --> Database Driver Class Initialized
INFO - 2017-02-19 20:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:43:50 --> Controller Class Initialized
INFO - 2017-02-19 20:43:50 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:43:50 --> Final output sent to browser
DEBUG - 2017-02-19 20:43:50 --> Total execution time: 0.0141
INFO - 2017-02-19 20:45:12 --> Config Class Initialized
INFO - 2017-02-19 20:45:12 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:12 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:12 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:12 --> URI Class Initialized
INFO - 2017-02-19 20:45:12 --> Router Class Initialized
INFO - 2017-02-19 20:45:12 --> Output Class Initialized
INFO - 2017-02-19 20:45:12 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:12 --> Input Class Initialized
INFO - 2017-02-19 20:45:12 --> Language Class Initialized
INFO - 2017-02-19 20:45:12 --> Loader Class Initialized
INFO - 2017-02-19 20:45:12 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:12 --> Controller Class Initialized
INFO - 2017-02-19 20:45:12 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:12 --> Config Class Initialized
INFO - 2017-02-19 20:45:12 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:12 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:12 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:12 --> URI Class Initialized
INFO - 2017-02-19 20:45:12 --> Router Class Initialized
INFO - 2017-02-19 20:45:12 --> Output Class Initialized
INFO - 2017-02-19 20:45:12 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:12 --> Input Class Initialized
INFO - 2017-02-19 20:45:12 --> Language Class Initialized
INFO - 2017-02-19 20:45:12 --> Loader Class Initialized
INFO - 2017-02-19 20:45:12 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:12 --> Controller Class Initialized
INFO - 2017-02-19 20:45:12 --> Helper loaded: date_helper
DEBUG - 2017-02-19 20:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:12 --> Helper loaded: url_helper
INFO - 2017-02-19 20:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-19 20:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-19 20:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-19 20:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:12 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:12 --> Total execution time: 0.0772
INFO - 2017-02-19 20:45:13 --> Config Class Initialized
INFO - 2017-02-19 20:45:13 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:13 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:13 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:13 --> URI Class Initialized
DEBUG - 2017-02-19 20:45:13 --> No URI present. Default controller set.
INFO - 2017-02-19 20:45:13 --> Router Class Initialized
INFO - 2017-02-19 20:45:13 --> Output Class Initialized
INFO - 2017-02-19 20:45:13 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:13 --> Input Class Initialized
INFO - 2017-02-19 20:45:13 --> Language Class Initialized
INFO - 2017-02-19 20:45:13 --> Loader Class Initialized
INFO - 2017-02-19 20:45:13 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:13 --> Controller Class Initialized
INFO - 2017-02-19 20:45:13 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:13 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:13 --> Total execution time: 0.0133
INFO - 2017-02-19 20:45:14 --> Config Class Initialized
INFO - 2017-02-19 20:45:14 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:14 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:14 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:14 --> URI Class Initialized
INFO - 2017-02-19 20:45:14 --> Router Class Initialized
INFO - 2017-02-19 20:45:14 --> Output Class Initialized
INFO - 2017-02-19 20:45:14 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:14 --> Input Class Initialized
INFO - 2017-02-19 20:45:14 --> Language Class Initialized
INFO - 2017-02-19 20:45:14 --> Loader Class Initialized
INFO - 2017-02-19 20:45:14 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:14 --> Controller Class Initialized
INFO - 2017-02-19 20:45:14 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:14 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:14 --> Total execution time: 0.0137
INFO - 2017-02-19 20:45:19 --> Config Class Initialized
INFO - 2017-02-19 20:45:19 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:19 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:19 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:19 --> URI Class Initialized
INFO - 2017-02-19 20:45:19 --> Router Class Initialized
INFO - 2017-02-19 20:45:19 --> Output Class Initialized
INFO - 2017-02-19 20:45:19 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:19 --> Input Class Initialized
INFO - 2017-02-19 20:45:19 --> Language Class Initialized
INFO - 2017-02-19 20:45:19 --> Loader Class Initialized
INFO - 2017-02-19 20:45:19 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:19 --> Controller Class Initialized
INFO - 2017-02-19 20:45:19 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:19 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:19 --> Total execution time: 0.0139
INFO - 2017-02-19 20:45:22 --> Config Class Initialized
INFO - 2017-02-19 20:45:22 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:22 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:22 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:22 --> URI Class Initialized
DEBUG - 2017-02-19 20:45:22 --> No URI present. Default controller set.
INFO - 2017-02-19 20:45:22 --> Router Class Initialized
INFO - 2017-02-19 20:45:22 --> Output Class Initialized
INFO - 2017-02-19 20:45:22 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:22 --> Input Class Initialized
INFO - 2017-02-19 20:45:22 --> Language Class Initialized
INFO - 2017-02-19 20:45:22 --> Loader Class Initialized
INFO - 2017-02-19 20:45:22 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:22 --> Controller Class Initialized
INFO - 2017-02-19 20:45:22 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:22 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:22 --> Total execution time: 0.0135
INFO - 2017-02-19 20:45:25 --> Config Class Initialized
INFO - 2017-02-19 20:45:25 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:25 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:25 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:25 --> URI Class Initialized
INFO - 2017-02-19 20:45:25 --> Router Class Initialized
INFO - 2017-02-19 20:45:25 --> Output Class Initialized
INFO - 2017-02-19 20:45:25 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:25 --> Input Class Initialized
INFO - 2017-02-19 20:45:25 --> Language Class Initialized
INFO - 2017-02-19 20:45:25 --> Loader Class Initialized
INFO - 2017-02-19 20:45:25 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:25 --> Controller Class Initialized
INFO - 2017-02-19 20:45:25 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:25 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:25 --> Total execution time: 0.0134
INFO - 2017-02-19 20:45:34 --> Config Class Initialized
INFO - 2017-02-19 20:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:34 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:34 --> URI Class Initialized
INFO - 2017-02-19 20:45:34 --> Router Class Initialized
INFO - 2017-02-19 20:45:34 --> Output Class Initialized
INFO - 2017-02-19 20:45:34 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:34 --> Input Class Initialized
INFO - 2017-02-19 20:45:34 --> Language Class Initialized
INFO - 2017-02-19 20:45:34 --> Loader Class Initialized
INFO - 2017-02-19 20:45:34 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:34 --> Controller Class Initialized
INFO - 2017-02-19 20:45:34 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-19 20:45:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-19 20:45:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-19 20:45:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-19 20:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:34 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:34 --> Total execution time: 0.0558
INFO - 2017-02-19 20:45:38 --> Config Class Initialized
INFO - 2017-02-19 20:45:38 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:38 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:38 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:38 --> URI Class Initialized
INFO - 2017-02-19 20:45:38 --> Router Class Initialized
INFO - 2017-02-19 20:45:38 --> Output Class Initialized
INFO - 2017-02-19 20:45:38 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:38 --> Input Class Initialized
INFO - 2017-02-19 20:45:38 --> Language Class Initialized
INFO - 2017-02-19 20:45:38 --> Loader Class Initialized
INFO - 2017-02-19 20:45:38 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:38 --> Controller Class Initialized
INFO - 2017-02-19 20:45:38 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:38 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:38 --> Total execution time: 0.0135
INFO - 2017-02-19 20:45:44 --> Config Class Initialized
INFO - 2017-02-19 20:45:44 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:44 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:44 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:44 --> URI Class Initialized
INFO - 2017-02-19 20:45:44 --> Router Class Initialized
INFO - 2017-02-19 20:45:44 --> Output Class Initialized
INFO - 2017-02-19 20:45:44 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:44 --> Input Class Initialized
INFO - 2017-02-19 20:45:44 --> Language Class Initialized
INFO - 2017-02-19 20:45:44 --> Loader Class Initialized
INFO - 2017-02-19 20:45:44 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:44 --> Controller Class Initialized
INFO - 2017-02-19 20:45:44 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:45 --> Config Class Initialized
INFO - 2017-02-19 20:45:45 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:45 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:45 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:45 --> URI Class Initialized
INFO - 2017-02-19 20:45:45 --> Router Class Initialized
INFO - 2017-02-19 20:45:45 --> Output Class Initialized
INFO - 2017-02-19 20:45:45 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:45 --> Input Class Initialized
INFO - 2017-02-19 20:45:45 --> Language Class Initialized
INFO - 2017-02-19 20:45:45 --> Loader Class Initialized
INFO - 2017-02-19 20:45:45 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:45 --> Controller Class Initialized
INFO - 2017-02-19 20:45:45 --> Helper loaded: date_helper
DEBUG - 2017-02-19 20:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:45 --> Helper loaded: url_helper
INFO - 2017-02-19 20:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-19 20:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-19 20:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-19 20:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:45 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:45 --> Total execution time: 0.0134
INFO - 2017-02-19 20:45:46 --> Config Class Initialized
INFO - 2017-02-19 20:45:46 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:46 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:46 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:46 --> URI Class Initialized
INFO - 2017-02-19 20:45:46 --> Router Class Initialized
INFO - 2017-02-19 20:45:46 --> Output Class Initialized
INFO - 2017-02-19 20:45:46 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:46 --> Input Class Initialized
INFO - 2017-02-19 20:45:46 --> Language Class Initialized
INFO - 2017-02-19 20:45:46 --> Loader Class Initialized
INFO - 2017-02-19 20:45:46 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:46 --> Controller Class Initialized
INFO - 2017-02-19 20:45:46 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:46 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:46 --> Total execution time: 0.0143
INFO - 2017-02-19 20:45:51 --> Config Class Initialized
INFO - 2017-02-19 20:45:51 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:51 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:51 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:51 --> URI Class Initialized
INFO - 2017-02-19 20:45:51 --> Router Class Initialized
INFO - 2017-02-19 20:45:51 --> Output Class Initialized
INFO - 2017-02-19 20:45:51 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:51 --> Input Class Initialized
INFO - 2017-02-19 20:45:51 --> Language Class Initialized
INFO - 2017-02-19 20:45:51 --> Loader Class Initialized
INFO - 2017-02-19 20:45:51 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:51 --> Controller Class Initialized
INFO - 2017-02-19 20:45:51 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:51 --> Config Class Initialized
INFO - 2017-02-19 20:45:51 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:51 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:51 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:51 --> URI Class Initialized
INFO - 2017-02-19 20:45:51 --> Router Class Initialized
INFO - 2017-02-19 20:45:51 --> Output Class Initialized
INFO - 2017-02-19 20:45:51 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:51 --> Input Class Initialized
INFO - 2017-02-19 20:45:51 --> Language Class Initialized
INFO - 2017-02-19 20:45:51 --> Loader Class Initialized
INFO - 2017-02-19 20:45:51 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:51 --> Controller Class Initialized
INFO - 2017-02-19 20:45:51 --> Helper loaded: date_helper
DEBUG - 2017-02-19 20:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:51 --> Helper loaded: url_helper
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:51 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:51 --> Total execution time: 0.0142
INFO - 2017-02-19 20:45:51 --> Config Class Initialized
INFO - 2017-02-19 20:45:51 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:45:51 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:45:51 --> Utf8 Class Initialized
INFO - 2017-02-19 20:45:51 --> URI Class Initialized
DEBUG - 2017-02-19 20:45:51 --> No URI present. Default controller set.
INFO - 2017-02-19 20:45:51 --> Router Class Initialized
INFO - 2017-02-19 20:45:51 --> Output Class Initialized
INFO - 2017-02-19 20:45:51 --> Security Class Initialized
DEBUG - 2017-02-19 20:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:45:51 --> Input Class Initialized
INFO - 2017-02-19 20:45:51 --> Language Class Initialized
INFO - 2017-02-19 20:45:51 --> Loader Class Initialized
INFO - 2017-02-19 20:45:51 --> Database Driver Class Initialized
INFO - 2017-02-19 20:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:45:51 --> Controller Class Initialized
INFO - 2017-02-19 20:45:51 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 20:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 20:45:51 --> Final output sent to browser
DEBUG - 2017-02-19 20:45:51 --> Total execution time: 0.0138
INFO - 2017-02-19 20:47:03 --> Config Class Initialized
INFO - 2017-02-19 20:47:03 --> Hooks Class Initialized
DEBUG - 2017-02-19 20:47:03 --> UTF-8 Support Enabled
INFO - 2017-02-19 20:47:03 --> Utf8 Class Initialized
INFO - 2017-02-19 20:47:03 --> URI Class Initialized
INFO - 2017-02-19 20:47:03 --> Router Class Initialized
INFO - 2017-02-19 20:47:03 --> Output Class Initialized
INFO - 2017-02-19 20:47:03 --> Security Class Initialized
DEBUG - 2017-02-19 20:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 20:47:03 --> Input Class Initialized
INFO - 2017-02-19 20:47:03 --> Language Class Initialized
INFO - 2017-02-19 20:47:03 --> Loader Class Initialized
INFO - 2017-02-19 20:47:03 --> Database Driver Class Initialized
INFO - 2017-02-19 20:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 20:47:03 --> Controller Class Initialized
INFO - 2017-02-19 20:47:03 --> Helper loaded: url_helper
DEBUG - 2017-02-19 20:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 20:47:03 --> Final output sent to browser
DEBUG - 2017-02-19 20:47:03 --> Total execution time: 0.0141
INFO - 2017-02-19 21:03:17 --> Config Class Initialized
INFO - 2017-02-19 21:03:17 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:03:17 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:03:17 --> Utf8 Class Initialized
INFO - 2017-02-19 21:03:17 --> URI Class Initialized
DEBUG - 2017-02-19 21:03:17 --> No URI present. Default controller set.
INFO - 2017-02-19 21:03:17 --> Router Class Initialized
INFO - 2017-02-19 21:03:17 --> Output Class Initialized
INFO - 2017-02-19 21:03:17 --> Security Class Initialized
DEBUG - 2017-02-19 21:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:03:17 --> Input Class Initialized
INFO - 2017-02-19 21:03:17 --> Language Class Initialized
INFO - 2017-02-19 21:03:17 --> Loader Class Initialized
INFO - 2017-02-19 21:03:17 --> Database Driver Class Initialized
INFO - 2017-02-19 21:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:03:17 --> Controller Class Initialized
INFO - 2017-02-19 21:03:17 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:03:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:03:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:03:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:03:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:03:17 --> Final output sent to browser
DEBUG - 2017-02-19 21:03:17 --> Total execution time: 0.0130
INFO - 2017-02-19 21:03:28 --> Config Class Initialized
INFO - 2017-02-19 21:03:28 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:03:28 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:03:28 --> Utf8 Class Initialized
INFO - 2017-02-19 21:03:28 --> URI Class Initialized
INFO - 2017-02-19 21:03:28 --> Router Class Initialized
INFO - 2017-02-19 21:03:28 --> Output Class Initialized
INFO - 2017-02-19 21:03:28 --> Security Class Initialized
DEBUG - 2017-02-19 21:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:03:28 --> Input Class Initialized
INFO - 2017-02-19 21:03:28 --> Language Class Initialized
INFO - 2017-02-19 21:03:28 --> Loader Class Initialized
INFO - 2017-02-19 21:03:28 --> Database Driver Class Initialized
INFO - 2017-02-19 21:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:03:28 --> Controller Class Initialized
INFO - 2017-02-19 21:03:28 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:03:28 --> Final output sent to browser
DEBUG - 2017-02-19 21:03:28 --> Total execution time: 0.0135
INFO - 2017-02-19 21:03:56 --> Config Class Initialized
INFO - 2017-02-19 21:03:56 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:03:56 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:03:56 --> Utf8 Class Initialized
INFO - 2017-02-19 21:03:56 --> URI Class Initialized
INFO - 2017-02-19 21:03:56 --> Router Class Initialized
INFO - 2017-02-19 21:03:56 --> Output Class Initialized
INFO - 2017-02-19 21:03:56 --> Security Class Initialized
DEBUG - 2017-02-19 21:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:03:56 --> Input Class Initialized
INFO - 2017-02-19 21:03:56 --> Language Class Initialized
INFO - 2017-02-19 21:03:56 --> Loader Class Initialized
INFO - 2017-02-19 21:03:56 --> Database Driver Class Initialized
INFO - 2017-02-19 21:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:03:56 --> Controller Class Initialized
INFO - 2017-02-19 21:03:56 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:03:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:03:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:03:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:03:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:03:56 --> Final output sent to browser
DEBUG - 2017-02-19 21:03:56 --> Total execution time: 0.0139
INFO - 2017-02-19 21:05:45 --> Config Class Initialized
INFO - 2017-02-19 21:05:45 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:05:45 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:05:45 --> Utf8 Class Initialized
INFO - 2017-02-19 21:05:45 --> URI Class Initialized
INFO - 2017-02-19 21:05:45 --> Router Class Initialized
INFO - 2017-02-19 21:05:45 --> Output Class Initialized
INFO - 2017-02-19 21:05:45 --> Security Class Initialized
DEBUG - 2017-02-19 21:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:05:45 --> Input Class Initialized
INFO - 2017-02-19 21:05:45 --> Language Class Initialized
INFO - 2017-02-19 21:05:45 --> Loader Class Initialized
INFO - 2017-02-19 21:05:45 --> Database Driver Class Initialized
INFO - 2017-02-19 21:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:05:45 --> Controller Class Initialized
INFO - 2017-02-19 21:05:45 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:05:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:05:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:05:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:05:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:05:45 --> Final output sent to browser
DEBUG - 2017-02-19 21:05:45 --> Total execution time: 0.0154
INFO - 2017-02-19 21:05:47 --> Config Class Initialized
INFO - 2017-02-19 21:05:47 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:05:47 --> Utf8 Class Initialized
INFO - 2017-02-19 21:05:47 --> URI Class Initialized
INFO - 2017-02-19 21:05:47 --> Router Class Initialized
INFO - 2017-02-19 21:05:47 --> Output Class Initialized
INFO - 2017-02-19 21:05:47 --> Security Class Initialized
DEBUG - 2017-02-19 21:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:05:47 --> Input Class Initialized
INFO - 2017-02-19 21:05:47 --> Language Class Initialized
INFO - 2017-02-19 21:05:47 --> Loader Class Initialized
INFO - 2017-02-19 21:05:47 --> Database Driver Class Initialized
INFO - 2017-02-19 21:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:05:47 --> Controller Class Initialized
INFO - 2017-02-19 21:05:47 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:05:47 --> Final output sent to browser
DEBUG - 2017-02-19 21:05:47 --> Total execution time: 0.0134
INFO - 2017-02-19 21:06:44 --> Config Class Initialized
INFO - 2017-02-19 21:06:44 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:06:44 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:06:44 --> Utf8 Class Initialized
INFO - 2017-02-19 21:06:44 --> URI Class Initialized
INFO - 2017-02-19 21:06:44 --> Router Class Initialized
INFO - 2017-02-19 21:06:44 --> Output Class Initialized
INFO - 2017-02-19 21:06:44 --> Security Class Initialized
DEBUG - 2017-02-19 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:06:44 --> Input Class Initialized
INFO - 2017-02-19 21:06:44 --> Language Class Initialized
INFO - 2017-02-19 21:06:44 --> Loader Class Initialized
INFO - 2017-02-19 21:06:44 --> Database Driver Class Initialized
INFO - 2017-02-19 21:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:06:44 --> Controller Class Initialized
INFO - 2017-02-19 21:06:44 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:06:44 --> Config Class Initialized
INFO - 2017-02-19 21:06:44 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:06:44 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:06:44 --> Utf8 Class Initialized
INFO - 2017-02-19 21:06:44 --> URI Class Initialized
INFO - 2017-02-19 21:06:44 --> Router Class Initialized
INFO - 2017-02-19 21:06:44 --> Output Class Initialized
INFO - 2017-02-19 21:06:44 --> Security Class Initialized
DEBUG - 2017-02-19 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:06:44 --> Input Class Initialized
INFO - 2017-02-19 21:06:44 --> Language Class Initialized
INFO - 2017-02-19 21:06:44 --> Loader Class Initialized
INFO - 2017-02-19 21:06:44 --> Database Driver Class Initialized
INFO - 2017-02-19 21:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:06:45 --> Controller Class Initialized
INFO - 2017-02-19 21:06:45 --> Helper loaded: date_helper
DEBUG - 2017-02-19 21:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:06:45 --> Helper loaded: url_helper
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:06:45 --> Final output sent to browser
DEBUG - 2017-02-19 21:06:45 --> Total execution time: 0.0145
INFO - 2017-02-19 21:06:45 --> Config Class Initialized
INFO - 2017-02-19 21:06:45 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:06:45 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:06:45 --> Utf8 Class Initialized
INFO - 2017-02-19 21:06:45 --> URI Class Initialized
INFO - 2017-02-19 21:06:45 --> Router Class Initialized
INFO - 2017-02-19 21:06:45 --> Output Class Initialized
INFO - 2017-02-19 21:06:45 --> Security Class Initialized
DEBUG - 2017-02-19 21:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:06:45 --> Input Class Initialized
INFO - 2017-02-19 21:06:45 --> Language Class Initialized
INFO - 2017-02-19 21:06:45 --> Loader Class Initialized
INFO - 2017-02-19 21:06:45 --> Database Driver Class Initialized
INFO - 2017-02-19 21:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:06:45 --> Controller Class Initialized
INFO - 2017-02-19 21:06:45 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:06:45 --> Final output sent to browser
DEBUG - 2017-02-19 21:06:45 --> Total execution time: 0.0136
INFO - 2017-02-19 21:07:09 --> Config Class Initialized
INFO - 2017-02-19 21:07:09 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:07:09 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:07:09 --> Utf8 Class Initialized
INFO - 2017-02-19 21:07:09 --> URI Class Initialized
DEBUG - 2017-02-19 21:07:09 --> No URI present. Default controller set.
INFO - 2017-02-19 21:07:09 --> Router Class Initialized
INFO - 2017-02-19 21:07:09 --> Output Class Initialized
INFO - 2017-02-19 21:07:09 --> Security Class Initialized
DEBUG - 2017-02-19 21:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:07:09 --> Input Class Initialized
INFO - 2017-02-19 21:07:09 --> Language Class Initialized
INFO - 2017-02-19 21:07:09 --> Loader Class Initialized
INFO - 2017-02-19 21:07:09 --> Database Driver Class Initialized
INFO - 2017-02-19 21:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:07:09 --> Controller Class Initialized
INFO - 2017-02-19 21:07:09 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:07:09 --> Final output sent to browser
DEBUG - 2017-02-19 21:07:09 --> Total execution time: 0.0132
INFO - 2017-02-19 21:07:10 --> Config Class Initialized
INFO - 2017-02-19 21:07:10 --> Hooks Class Initialized
DEBUG - 2017-02-19 21:07:10 --> UTF-8 Support Enabled
INFO - 2017-02-19 21:07:10 --> Utf8 Class Initialized
INFO - 2017-02-19 21:07:10 --> URI Class Initialized
INFO - 2017-02-19 21:07:10 --> Router Class Initialized
INFO - 2017-02-19 21:07:10 --> Output Class Initialized
INFO - 2017-02-19 21:07:10 --> Security Class Initialized
DEBUG - 2017-02-19 21:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 21:07:10 --> Input Class Initialized
INFO - 2017-02-19 21:07:10 --> Language Class Initialized
INFO - 2017-02-19 21:07:10 --> Loader Class Initialized
INFO - 2017-02-19 21:07:10 --> Database Driver Class Initialized
INFO - 2017-02-19 21:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 21:07:10 --> Controller Class Initialized
INFO - 2017-02-19 21:07:10 --> Helper loaded: url_helper
DEBUG - 2017-02-19 21:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 21:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 21:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 21:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 21:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 21:07:10 --> Final output sent to browser
DEBUG - 2017-02-19 21:07:10 --> Total execution time: 0.0137
INFO - 2017-02-19 23:37:31 --> Config Class Initialized
INFO - 2017-02-19 23:37:31 --> Hooks Class Initialized
DEBUG - 2017-02-19 23:37:31 --> UTF-8 Support Enabled
INFO - 2017-02-19 23:37:31 --> Utf8 Class Initialized
INFO - 2017-02-19 23:37:31 --> URI Class Initialized
INFO - 2017-02-19 23:37:31 --> Router Class Initialized
INFO - 2017-02-19 23:37:31 --> Output Class Initialized
INFO - 2017-02-19 23:37:31 --> Security Class Initialized
DEBUG - 2017-02-19 23:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 23:37:31 --> Input Class Initialized
INFO - 2017-02-19 23:37:31 --> Language Class Initialized
INFO - 2017-02-19 23:37:31 --> Loader Class Initialized
INFO - 2017-02-19 23:37:31 --> Database Driver Class Initialized
INFO - 2017-02-19 23:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 23:37:31 --> Controller Class Initialized
INFO - 2017-02-19 23:37:31 --> Helper loaded: url_helper
DEBUG - 2017-02-19 23:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 23:37:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 23:37:31 --> Final output sent to browser
DEBUG - 2017-02-19 23:37:31 --> Total execution time: 0.0144
INFO - 2017-02-19 23:37:35 --> Config Class Initialized
INFO - 2017-02-19 23:37:35 --> Hooks Class Initialized
DEBUG - 2017-02-19 23:37:35 --> UTF-8 Support Enabled
INFO - 2017-02-19 23:37:35 --> Utf8 Class Initialized
INFO - 2017-02-19 23:37:35 --> URI Class Initialized
INFO - 2017-02-19 23:37:35 --> Router Class Initialized
INFO - 2017-02-19 23:37:35 --> Output Class Initialized
INFO - 2017-02-19 23:37:35 --> Security Class Initialized
DEBUG - 2017-02-19 23:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 23:37:35 --> Input Class Initialized
INFO - 2017-02-19 23:37:35 --> Language Class Initialized
INFO - 2017-02-19 23:37:35 --> Loader Class Initialized
INFO - 2017-02-19 23:37:35 --> Database Driver Class Initialized
INFO - 2017-02-19 23:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 23:37:35 --> Controller Class Initialized
INFO - 2017-02-19 23:37:35 --> Helper loaded: url_helper
DEBUG - 2017-02-19 23:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 23:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 23:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 23:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 23:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 23:37:35 --> Final output sent to browser
DEBUG - 2017-02-19 23:37:35 --> Total execution time: 0.0139
INFO - 2017-02-19 23:44:39 --> Config Class Initialized
INFO - 2017-02-19 23:44:39 --> Hooks Class Initialized
DEBUG - 2017-02-19 23:44:39 --> UTF-8 Support Enabled
INFO - 2017-02-19 23:44:39 --> Utf8 Class Initialized
INFO - 2017-02-19 23:44:39 --> URI Class Initialized
INFO - 2017-02-19 23:44:39 --> Router Class Initialized
INFO - 2017-02-19 23:44:39 --> Output Class Initialized
INFO - 2017-02-19 23:44:39 --> Security Class Initialized
DEBUG - 2017-02-19 23:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 23:44:39 --> Input Class Initialized
INFO - 2017-02-19 23:44:39 --> Language Class Initialized
INFO - 2017-02-19 23:44:39 --> Loader Class Initialized
INFO - 2017-02-19 23:44:39 --> Database Driver Class Initialized
INFO - 2017-02-19 23:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 23:44:39 --> Controller Class Initialized
INFO - 2017-02-19 23:44:39 --> Helper loaded: url_helper
DEBUG - 2017-02-19 23:44:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 23:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 23:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 23:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 23:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 23:44:39 --> Final output sent to browser
DEBUG - 2017-02-19 23:44:39 --> Total execution time: 0.0142
INFO - 2017-02-19 23:44:40 --> Config Class Initialized
INFO - 2017-02-19 23:44:40 --> Hooks Class Initialized
DEBUG - 2017-02-19 23:44:40 --> UTF-8 Support Enabled
INFO - 2017-02-19 23:44:40 --> Utf8 Class Initialized
INFO - 2017-02-19 23:44:40 --> URI Class Initialized
INFO - 2017-02-19 23:44:40 --> Router Class Initialized
INFO - 2017-02-19 23:44:40 --> Output Class Initialized
INFO - 2017-02-19 23:44:40 --> Security Class Initialized
DEBUG - 2017-02-19 23:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 23:44:40 --> Input Class Initialized
INFO - 2017-02-19 23:44:40 --> Language Class Initialized
INFO - 2017-02-19 23:44:40 --> Loader Class Initialized
INFO - 2017-02-19 23:44:40 --> Database Driver Class Initialized
INFO - 2017-02-19 23:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 23:44:40 --> Controller Class Initialized
INFO - 2017-02-19 23:44:40 --> Helper loaded: url_helper
DEBUG - 2017-02-19 23:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-19 23:44:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-19 23:44:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-19 23:44:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-19 23:44:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-19 23:44:40 --> Final output sent to browser
DEBUG - 2017-02-19 23:44:40 --> Total execution time: 0.0139

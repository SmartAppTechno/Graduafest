<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-04 00:05:15 --> Config Class Initialized
INFO - 2017-02-04 00:05:15 --> Hooks Class Initialized
DEBUG - 2017-02-04 00:05:15 --> UTF-8 Support Enabled
INFO - 2017-02-04 00:05:15 --> Utf8 Class Initialized
INFO - 2017-02-04 00:05:15 --> URI Class Initialized
DEBUG - 2017-02-04 00:05:15 --> No URI present. Default controller set.
INFO - 2017-02-04 00:05:15 --> Router Class Initialized
INFO - 2017-02-04 00:05:15 --> Output Class Initialized
INFO - 2017-02-04 00:05:15 --> Security Class Initialized
DEBUG - 2017-02-04 00:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 00:05:15 --> Input Class Initialized
INFO - 2017-02-04 00:05:15 --> Language Class Initialized
INFO - 2017-02-04 00:05:15 --> Loader Class Initialized
INFO - 2017-02-04 00:05:16 --> Database Driver Class Initialized
INFO - 2017-02-04 00:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 00:05:16 --> Controller Class Initialized
INFO - 2017-02-04 00:05:16 --> Helper loaded: url_helper
DEBUG - 2017-02-04 00:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 00:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 00:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 00:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 00:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 00:05:16 --> Final output sent to browser
DEBUG - 2017-02-04 00:05:16 --> Total execution time: 1.8424
INFO - 2017-02-04 00:05:23 --> Config Class Initialized
INFO - 2017-02-04 00:05:23 --> Hooks Class Initialized
DEBUG - 2017-02-04 00:05:23 --> UTF-8 Support Enabled
INFO - 2017-02-04 00:05:23 --> Utf8 Class Initialized
INFO - 2017-02-04 00:05:23 --> URI Class Initialized
INFO - 2017-02-04 00:05:23 --> Router Class Initialized
INFO - 2017-02-04 00:05:23 --> Output Class Initialized
INFO - 2017-02-04 00:05:23 --> Security Class Initialized
DEBUG - 2017-02-04 00:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 00:05:23 --> Input Class Initialized
INFO - 2017-02-04 00:05:23 --> Language Class Initialized
INFO - 2017-02-04 00:05:23 --> Loader Class Initialized
INFO - 2017-02-04 00:05:23 --> Database Driver Class Initialized
INFO - 2017-02-04 00:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 00:05:23 --> Controller Class Initialized
INFO - 2017-02-04 00:05:23 --> Helper loaded: url_helper
DEBUG - 2017-02-04 00:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 00:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 00:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 00:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 00:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 00:05:23 --> Final output sent to browser
DEBUG - 2017-02-04 00:05:23 --> Total execution time: 0.0136
INFO - 2017-02-04 00:05:41 --> Config Class Initialized
INFO - 2017-02-04 00:05:41 --> Hooks Class Initialized
DEBUG - 2017-02-04 00:05:41 --> UTF-8 Support Enabled
INFO - 2017-02-04 00:05:41 --> Utf8 Class Initialized
INFO - 2017-02-04 00:05:41 --> URI Class Initialized
INFO - 2017-02-04 00:05:41 --> Router Class Initialized
INFO - 2017-02-04 00:05:41 --> Output Class Initialized
INFO - 2017-02-04 00:05:41 --> Security Class Initialized
DEBUG - 2017-02-04 00:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 00:05:41 --> Input Class Initialized
INFO - 2017-02-04 00:05:41 --> Language Class Initialized
INFO - 2017-02-04 00:05:41 --> Loader Class Initialized
INFO - 2017-02-04 00:05:41 --> Database Driver Class Initialized
INFO - 2017-02-04 00:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 00:05:41 --> Controller Class Initialized
INFO - 2017-02-04 00:05:41 --> Helper loaded: url_helper
DEBUG - 2017-02-04 00:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 00:05:42 --> Config Class Initialized
INFO - 2017-02-04 00:05:42 --> Hooks Class Initialized
DEBUG - 2017-02-04 00:05:42 --> UTF-8 Support Enabled
INFO - 2017-02-04 00:05:42 --> Utf8 Class Initialized
INFO - 2017-02-04 00:05:42 --> URI Class Initialized
INFO - 2017-02-04 00:05:42 --> Router Class Initialized
INFO - 2017-02-04 00:05:42 --> Output Class Initialized
INFO - 2017-02-04 00:05:42 --> Security Class Initialized
DEBUG - 2017-02-04 00:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 00:05:42 --> Input Class Initialized
INFO - 2017-02-04 00:05:42 --> Language Class Initialized
INFO - 2017-02-04 00:05:42 --> Loader Class Initialized
INFO - 2017-02-04 00:05:42 --> Database Driver Class Initialized
INFO - 2017-02-04 00:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 00:05:42 --> Controller Class Initialized
INFO - 2017-02-04 00:05:42 --> Helper loaded: date_helper
DEBUG - 2017-02-04 00:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 00:05:42 --> Helper loaded: url_helper
INFO - 2017-02-04 00:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 00:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-04 00:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-04 00:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-04 00:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 00:05:43 --> Final output sent to browser
DEBUG - 2017-02-04 00:05:43 --> Total execution time: 0.1066
INFO - 2017-02-04 00:05:44 --> Config Class Initialized
INFO - 2017-02-04 00:05:44 --> Hooks Class Initialized
DEBUG - 2017-02-04 00:05:44 --> UTF-8 Support Enabled
INFO - 2017-02-04 00:05:44 --> Utf8 Class Initialized
INFO - 2017-02-04 00:05:44 --> URI Class Initialized
INFO - 2017-02-04 00:05:44 --> Router Class Initialized
INFO - 2017-02-04 00:05:44 --> Output Class Initialized
INFO - 2017-02-04 00:05:44 --> Security Class Initialized
DEBUG - 2017-02-04 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 00:05:44 --> Input Class Initialized
INFO - 2017-02-04 00:05:44 --> Language Class Initialized
INFO - 2017-02-04 00:05:44 --> Loader Class Initialized
INFO - 2017-02-04 00:05:44 --> Database Driver Class Initialized
INFO - 2017-02-04 00:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 00:05:44 --> Controller Class Initialized
INFO - 2017-02-04 00:05:44 --> Helper loaded: url_helper
DEBUG - 2017-02-04 00:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 00:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 00:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 00:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 00:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 00:05:44 --> Final output sent to browser
DEBUG - 2017-02-04 00:05:44 --> Total execution time: 0.0138
INFO - 2017-02-04 00:05:50 --> Config Class Initialized
INFO - 2017-02-04 00:05:50 --> Hooks Class Initialized
DEBUG - 2017-02-04 00:05:50 --> UTF-8 Support Enabled
INFO - 2017-02-04 00:05:50 --> Utf8 Class Initialized
INFO - 2017-02-04 00:05:50 --> URI Class Initialized
DEBUG - 2017-02-04 00:05:50 --> No URI present. Default controller set.
INFO - 2017-02-04 00:05:50 --> Router Class Initialized
INFO - 2017-02-04 00:05:50 --> Output Class Initialized
INFO - 2017-02-04 00:05:50 --> Security Class Initialized
DEBUG - 2017-02-04 00:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 00:05:50 --> Input Class Initialized
INFO - 2017-02-04 00:05:50 --> Language Class Initialized
INFO - 2017-02-04 00:05:50 --> Loader Class Initialized
INFO - 2017-02-04 00:05:50 --> Database Driver Class Initialized
INFO - 2017-02-04 00:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 00:05:50 --> Controller Class Initialized
INFO - 2017-02-04 00:05:50 --> Helper loaded: url_helper
DEBUG - 2017-02-04 00:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 00:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 00:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 00:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 00:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 00:05:50 --> Final output sent to browser
DEBUG - 2017-02-04 00:05:50 --> Total execution time: 0.0130
INFO - 2017-02-04 00:05:53 --> Config Class Initialized
INFO - 2017-02-04 00:05:53 --> Hooks Class Initialized
DEBUG - 2017-02-04 00:05:53 --> UTF-8 Support Enabled
INFO - 2017-02-04 00:05:53 --> Utf8 Class Initialized
INFO - 2017-02-04 00:05:53 --> URI Class Initialized
INFO - 2017-02-04 00:05:53 --> Router Class Initialized
INFO - 2017-02-04 00:05:53 --> Output Class Initialized
INFO - 2017-02-04 00:05:53 --> Security Class Initialized
DEBUG - 2017-02-04 00:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 00:05:53 --> Input Class Initialized
INFO - 2017-02-04 00:05:53 --> Language Class Initialized
INFO - 2017-02-04 00:05:53 --> Loader Class Initialized
INFO - 2017-02-04 00:05:53 --> Database Driver Class Initialized
INFO - 2017-02-04 00:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 00:05:53 --> Controller Class Initialized
INFO - 2017-02-04 00:05:53 --> Helper loaded: url_helper
DEBUG - 2017-02-04 00:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 00:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 00:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 00:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 00:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 00:05:53 --> Final output sent to browser
DEBUG - 2017-02-04 00:05:53 --> Total execution time: 0.0133
INFO - 2017-02-04 01:21:01 --> Config Class Initialized
INFO - 2017-02-04 01:21:01 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:21:01 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:21:01 --> Utf8 Class Initialized
INFO - 2017-02-04 01:21:01 --> URI Class Initialized
DEBUG - 2017-02-04 01:21:01 --> No URI present. Default controller set.
INFO - 2017-02-04 01:21:01 --> Router Class Initialized
INFO - 2017-02-04 01:21:01 --> Output Class Initialized
INFO - 2017-02-04 01:21:01 --> Security Class Initialized
DEBUG - 2017-02-04 01:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:21:01 --> Input Class Initialized
INFO - 2017-02-04 01:21:01 --> Language Class Initialized
INFO - 2017-02-04 01:21:01 --> Loader Class Initialized
INFO - 2017-02-04 01:21:01 --> Database Driver Class Initialized
INFO - 2017-02-04 01:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:21:01 --> Controller Class Initialized
INFO - 2017-02-04 01:21:01 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:21:01 --> Final output sent to browser
DEBUG - 2017-02-04 01:21:01 --> Total execution time: 0.0408
INFO - 2017-02-04 01:21:01 --> Config Class Initialized
INFO - 2017-02-04 01:21:01 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:21:01 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:21:01 --> Utf8 Class Initialized
INFO - 2017-02-04 01:21:01 --> URI Class Initialized
DEBUG - 2017-02-04 01:21:01 --> No URI present. Default controller set.
INFO - 2017-02-04 01:21:01 --> Router Class Initialized
INFO - 2017-02-04 01:21:01 --> Output Class Initialized
INFO - 2017-02-04 01:21:01 --> Security Class Initialized
DEBUG - 2017-02-04 01:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:21:01 --> Input Class Initialized
INFO - 2017-02-04 01:21:01 --> Language Class Initialized
INFO - 2017-02-04 01:21:01 --> Loader Class Initialized
INFO - 2017-02-04 01:21:01 --> Database Driver Class Initialized
INFO - 2017-02-04 01:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:21:01 --> Controller Class Initialized
INFO - 2017-02-04 01:21:01 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:21:01 --> Final output sent to browser
DEBUG - 2017-02-04 01:21:01 --> Total execution time: 0.0139
INFO - 2017-02-04 01:21:11 --> Config Class Initialized
INFO - 2017-02-04 01:21:11 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:21:11 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:21:11 --> Utf8 Class Initialized
INFO - 2017-02-04 01:21:11 --> URI Class Initialized
INFO - 2017-02-04 01:21:11 --> Router Class Initialized
INFO - 2017-02-04 01:21:11 --> Output Class Initialized
INFO - 2017-02-04 01:21:11 --> Security Class Initialized
DEBUG - 2017-02-04 01:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:21:11 --> Input Class Initialized
INFO - 2017-02-04 01:21:11 --> Language Class Initialized
INFO - 2017-02-04 01:21:11 --> Loader Class Initialized
INFO - 2017-02-04 01:21:11 --> Database Driver Class Initialized
INFO - 2017-02-04 01:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:21:11 --> Controller Class Initialized
INFO - 2017-02-04 01:21:11 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:21:11 --> Final output sent to browser
DEBUG - 2017-02-04 01:21:11 --> Total execution time: 0.0134
INFO - 2017-02-04 01:21:11 --> Config Class Initialized
INFO - 2017-02-04 01:21:11 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:21:11 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:21:11 --> Utf8 Class Initialized
INFO - 2017-02-04 01:21:11 --> URI Class Initialized
INFO - 2017-02-04 01:21:11 --> Router Class Initialized
INFO - 2017-02-04 01:21:11 --> Output Class Initialized
INFO - 2017-02-04 01:21:11 --> Security Class Initialized
DEBUG - 2017-02-04 01:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:21:11 --> Input Class Initialized
INFO - 2017-02-04 01:21:11 --> Language Class Initialized
INFO - 2017-02-04 01:21:11 --> Loader Class Initialized
INFO - 2017-02-04 01:21:11 --> Database Driver Class Initialized
INFO - 2017-02-04 01:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:21:11 --> Controller Class Initialized
INFO - 2017-02-04 01:21:11 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:21:11 --> Final output sent to browser
DEBUG - 2017-02-04 01:21:11 --> Total execution time: 0.0137
INFO - 2017-02-04 01:22:59 --> Config Class Initialized
INFO - 2017-02-04 01:22:59 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:22:59 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:22:59 --> Utf8 Class Initialized
INFO - 2017-02-04 01:22:59 --> URI Class Initialized
DEBUG - 2017-02-04 01:22:59 --> No URI present. Default controller set.
INFO - 2017-02-04 01:22:59 --> Router Class Initialized
INFO - 2017-02-04 01:22:59 --> Output Class Initialized
INFO - 2017-02-04 01:22:59 --> Security Class Initialized
DEBUG - 2017-02-04 01:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:22:59 --> Input Class Initialized
INFO - 2017-02-04 01:22:59 --> Language Class Initialized
INFO - 2017-02-04 01:22:59 --> Loader Class Initialized
INFO - 2017-02-04 01:22:59 --> Database Driver Class Initialized
INFO - 2017-02-04 01:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:22:59 --> Controller Class Initialized
INFO - 2017-02-04 01:22:59 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:22:59 --> Final output sent to browser
DEBUG - 2017-02-04 01:22:59 --> Total execution time: 0.0134
INFO - 2017-02-04 01:23:04 --> Config Class Initialized
INFO - 2017-02-04 01:23:04 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:23:04 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:23:04 --> Utf8 Class Initialized
INFO - 2017-02-04 01:23:04 --> URI Class Initialized
INFO - 2017-02-04 01:23:04 --> Router Class Initialized
INFO - 2017-02-04 01:23:04 --> Output Class Initialized
INFO - 2017-02-04 01:23:04 --> Security Class Initialized
DEBUG - 2017-02-04 01:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:23:04 --> Input Class Initialized
INFO - 2017-02-04 01:23:04 --> Language Class Initialized
INFO - 2017-02-04 01:23:04 --> Loader Class Initialized
INFO - 2017-02-04 01:23:04 --> Database Driver Class Initialized
INFO - 2017-02-04 01:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:23:04 --> Controller Class Initialized
INFO - 2017-02-04 01:23:04 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:23:04 --> Final output sent to browser
DEBUG - 2017-02-04 01:23:04 --> Total execution time: 0.0142
INFO - 2017-02-04 01:23:29 --> Config Class Initialized
INFO - 2017-02-04 01:23:29 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:23:29 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:23:29 --> Utf8 Class Initialized
INFO - 2017-02-04 01:23:29 --> URI Class Initialized
DEBUG - 2017-02-04 01:23:29 --> No URI present. Default controller set.
INFO - 2017-02-04 01:23:29 --> Router Class Initialized
INFO - 2017-02-04 01:23:29 --> Output Class Initialized
INFO - 2017-02-04 01:23:29 --> Security Class Initialized
DEBUG - 2017-02-04 01:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:23:29 --> Input Class Initialized
INFO - 2017-02-04 01:23:29 --> Language Class Initialized
INFO - 2017-02-04 01:23:29 --> Loader Class Initialized
INFO - 2017-02-04 01:23:29 --> Database Driver Class Initialized
INFO - 2017-02-04 01:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:23:29 --> Controller Class Initialized
INFO - 2017-02-04 01:23:29 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:23:29 --> Final output sent to browser
DEBUG - 2017-02-04 01:23:29 --> Total execution time: 0.0131
INFO - 2017-02-04 01:23:34 --> Config Class Initialized
INFO - 2017-02-04 01:23:34 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:23:34 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:23:34 --> Utf8 Class Initialized
INFO - 2017-02-04 01:23:34 --> URI Class Initialized
INFO - 2017-02-04 01:23:34 --> Router Class Initialized
INFO - 2017-02-04 01:23:34 --> Output Class Initialized
INFO - 2017-02-04 01:23:34 --> Security Class Initialized
DEBUG - 2017-02-04 01:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:23:34 --> Input Class Initialized
INFO - 2017-02-04 01:23:34 --> Language Class Initialized
INFO - 2017-02-04 01:23:34 --> Loader Class Initialized
INFO - 2017-02-04 01:23:34 --> Database Driver Class Initialized
INFO - 2017-02-04 01:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:23:34 --> Controller Class Initialized
INFO - 2017-02-04 01:23:34 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:23:34 --> Final output sent to browser
DEBUG - 2017-02-04 01:23:34 --> Total execution time: 0.0142
INFO - 2017-02-04 01:23:55 --> Config Class Initialized
INFO - 2017-02-04 01:23:55 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:23:55 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:23:55 --> Utf8 Class Initialized
INFO - 2017-02-04 01:23:55 --> URI Class Initialized
INFO - 2017-02-04 01:23:55 --> Router Class Initialized
INFO - 2017-02-04 01:23:55 --> Output Class Initialized
INFO - 2017-02-04 01:23:55 --> Security Class Initialized
DEBUG - 2017-02-04 01:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:23:55 --> Input Class Initialized
INFO - 2017-02-04 01:23:55 --> Language Class Initialized
INFO - 2017-02-04 01:23:55 --> Loader Class Initialized
INFO - 2017-02-04 01:23:55 --> Database Driver Class Initialized
INFO - 2017-02-04 01:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:23:55 --> Controller Class Initialized
INFO - 2017-02-04 01:23:55 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:23:57 --> Config Class Initialized
INFO - 2017-02-04 01:23:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:23:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:23:57 --> Utf8 Class Initialized
INFO - 2017-02-04 01:23:57 --> URI Class Initialized
INFO - 2017-02-04 01:23:57 --> Router Class Initialized
INFO - 2017-02-04 01:23:57 --> Output Class Initialized
INFO - 2017-02-04 01:23:57 --> Security Class Initialized
DEBUG - 2017-02-04 01:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:23:57 --> Input Class Initialized
INFO - 2017-02-04 01:23:57 --> Language Class Initialized
INFO - 2017-02-04 01:23:57 --> Loader Class Initialized
INFO - 2017-02-04 01:23:57 --> Database Driver Class Initialized
INFO - 2017-02-04 01:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:23:57 --> Controller Class Initialized
INFO - 2017-02-04 01:23:57 --> Helper loaded: date_helper
DEBUG - 2017-02-04 01:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:23:57 --> Helper loaded: url_helper
INFO - 2017-02-04 01:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-04 01:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-04 01:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-04 01:23:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:23:57 --> Final output sent to browser
DEBUG - 2017-02-04 01:23:57 --> Total execution time: 0.2494
INFO - 2017-02-04 01:23:59 --> Config Class Initialized
INFO - 2017-02-04 01:23:59 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:23:59 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:23:59 --> Utf8 Class Initialized
INFO - 2017-02-04 01:23:59 --> URI Class Initialized
INFO - 2017-02-04 01:23:59 --> Router Class Initialized
INFO - 2017-02-04 01:23:59 --> Output Class Initialized
INFO - 2017-02-04 01:23:59 --> Security Class Initialized
DEBUG - 2017-02-04 01:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:23:59 --> Input Class Initialized
INFO - 2017-02-04 01:23:59 --> Language Class Initialized
INFO - 2017-02-04 01:23:59 --> Loader Class Initialized
INFO - 2017-02-04 01:23:59 --> Database Driver Class Initialized
INFO - 2017-02-04 01:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:23:59 --> Controller Class Initialized
INFO - 2017-02-04 01:23:59 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:23:59 --> Final output sent to browser
DEBUG - 2017-02-04 01:23:59 --> Total execution time: 0.0134
INFO - 2017-02-04 01:24:43 --> Config Class Initialized
INFO - 2017-02-04 01:24:43 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:24:43 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:24:43 --> Utf8 Class Initialized
INFO - 2017-02-04 01:24:43 --> URI Class Initialized
DEBUG - 2017-02-04 01:24:43 --> No URI present. Default controller set.
INFO - 2017-02-04 01:24:43 --> Router Class Initialized
INFO - 2017-02-04 01:24:43 --> Output Class Initialized
INFO - 2017-02-04 01:24:43 --> Security Class Initialized
DEBUG - 2017-02-04 01:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:24:43 --> Input Class Initialized
INFO - 2017-02-04 01:24:43 --> Language Class Initialized
INFO - 2017-02-04 01:24:43 --> Loader Class Initialized
INFO - 2017-02-04 01:24:43 --> Database Driver Class Initialized
INFO - 2017-02-04 01:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:24:43 --> Controller Class Initialized
INFO - 2017-02-04 01:24:43 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:24:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:24:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:24:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:24:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:24:43 --> Final output sent to browser
DEBUG - 2017-02-04 01:24:43 --> Total execution time: 0.0149
INFO - 2017-02-04 01:24:46 --> Config Class Initialized
INFO - 2017-02-04 01:24:46 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:24:46 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:24:46 --> Utf8 Class Initialized
INFO - 2017-02-04 01:24:46 --> URI Class Initialized
INFO - 2017-02-04 01:24:46 --> Router Class Initialized
INFO - 2017-02-04 01:24:46 --> Output Class Initialized
INFO - 2017-02-04 01:24:46 --> Security Class Initialized
DEBUG - 2017-02-04 01:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:24:46 --> Input Class Initialized
INFO - 2017-02-04 01:24:46 --> Language Class Initialized
INFO - 2017-02-04 01:24:46 --> Loader Class Initialized
INFO - 2017-02-04 01:24:46 --> Database Driver Class Initialized
INFO - 2017-02-04 01:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:24:46 --> Controller Class Initialized
INFO - 2017-02-04 01:24:46 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:24:46 --> Final output sent to browser
DEBUG - 2017-02-04 01:24:46 --> Total execution time: 0.0157
INFO - 2017-02-04 01:25:43 --> Config Class Initialized
INFO - 2017-02-04 01:25:43 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:25:43 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:25:43 --> Utf8 Class Initialized
INFO - 2017-02-04 01:25:43 --> URI Class Initialized
INFO - 2017-02-04 01:25:43 --> Router Class Initialized
INFO - 2017-02-04 01:25:43 --> Output Class Initialized
INFO - 2017-02-04 01:25:43 --> Security Class Initialized
DEBUG - 2017-02-04 01:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:25:43 --> Input Class Initialized
INFO - 2017-02-04 01:25:43 --> Language Class Initialized
INFO - 2017-02-04 01:25:43 --> Loader Class Initialized
INFO - 2017-02-04 01:25:43 --> Database Driver Class Initialized
INFO - 2017-02-04 01:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:25:43 --> Controller Class Initialized
INFO - 2017-02-04 01:25:43 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:25:44 --> Config Class Initialized
INFO - 2017-02-04 01:25:44 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:25:44 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:25:44 --> Utf8 Class Initialized
INFO - 2017-02-04 01:25:44 --> URI Class Initialized
INFO - 2017-02-04 01:25:44 --> Router Class Initialized
INFO - 2017-02-04 01:25:44 --> Output Class Initialized
INFO - 2017-02-04 01:25:44 --> Security Class Initialized
DEBUG - 2017-02-04 01:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:25:44 --> Input Class Initialized
INFO - 2017-02-04 01:25:44 --> Language Class Initialized
INFO - 2017-02-04 01:25:44 --> Loader Class Initialized
INFO - 2017-02-04 01:25:44 --> Database Driver Class Initialized
INFO - 2017-02-04 01:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:25:44 --> Controller Class Initialized
INFO - 2017-02-04 01:25:44 --> Helper loaded: date_helper
DEBUG - 2017-02-04 01:25:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:25:44 --> Helper loaded: url_helper
INFO - 2017-02-04 01:25:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:25:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-04 01:25:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-04 01:25:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-04 01:25:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:25:44 --> Final output sent to browser
DEBUG - 2017-02-04 01:25:44 --> Total execution time: 0.0139
INFO - 2017-02-04 01:25:46 --> Config Class Initialized
INFO - 2017-02-04 01:25:46 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:25:46 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:25:46 --> Utf8 Class Initialized
INFO - 2017-02-04 01:25:46 --> URI Class Initialized
INFO - 2017-02-04 01:25:46 --> Router Class Initialized
INFO - 2017-02-04 01:25:46 --> Output Class Initialized
INFO - 2017-02-04 01:25:46 --> Security Class Initialized
DEBUG - 2017-02-04 01:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:25:46 --> Input Class Initialized
INFO - 2017-02-04 01:25:46 --> Language Class Initialized
INFO - 2017-02-04 01:25:46 --> Loader Class Initialized
INFO - 2017-02-04 01:25:46 --> Database Driver Class Initialized
INFO - 2017-02-04 01:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:25:46 --> Controller Class Initialized
INFO - 2017-02-04 01:25:46 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:25:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:25:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:25:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:25:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:25:46 --> Final output sent to browser
DEBUG - 2017-02-04 01:25:46 --> Total execution time: 0.0134
INFO - 2017-02-04 01:36:03 --> Config Class Initialized
INFO - 2017-02-04 01:36:03 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:36:03 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:36:03 --> Utf8 Class Initialized
INFO - 2017-02-04 01:36:03 --> URI Class Initialized
DEBUG - 2017-02-04 01:36:03 --> No URI present. Default controller set.
INFO - 2017-02-04 01:36:03 --> Router Class Initialized
INFO - 2017-02-04 01:36:03 --> Output Class Initialized
INFO - 2017-02-04 01:36:03 --> Security Class Initialized
DEBUG - 2017-02-04 01:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:36:03 --> Input Class Initialized
INFO - 2017-02-04 01:36:03 --> Language Class Initialized
INFO - 2017-02-04 01:36:03 --> Loader Class Initialized
INFO - 2017-02-04 01:36:03 --> Database Driver Class Initialized
INFO - 2017-02-04 01:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:36:03 --> Controller Class Initialized
INFO - 2017-02-04 01:36:03 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:36:03 --> Final output sent to browser
DEBUG - 2017-02-04 01:36:03 --> Total execution time: 0.0136
INFO - 2017-02-04 01:36:27 --> Config Class Initialized
INFO - 2017-02-04 01:36:27 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:36:27 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:36:27 --> Utf8 Class Initialized
INFO - 2017-02-04 01:36:27 --> URI Class Initialized
INFO - 2017-02-04 01:36:27 --> Router Class Initialized
INFO - 2017-02-04 01:36:27 --> Output Class Initialized
INFO - 2017-02-04 01:36:27 --> Security Class Initialized
DEBUG - 2017-02-04 01:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:36:27 --> Input Class Initialized
INFO - 2017-02-04 01:36:27 --> Language Class Initialized
INFO - 2017-02-04 01:36:27 --> Loader Class Initialized
INFO - 2017-02-04 01:36:27 --> Database Driver Class Initialized
INFO - 2017-02-04 01:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:36:27 --> Controller Class Initialized
INFO - 2017-02-04 01:36:27 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:36:28 --> Config Class Initialized
INFO - 2017-02-04 01:36:28 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:36:28 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:36:28 --> Utf8 Class Initialized
INFO - 2017-02-04 01:36:28 --> URI Class Initialized
INFO - 2017-02-04 01:36:28 --> Router Class Initialized
INFO - 2017-02-04 01:36:28 --> Output Class Initialized
INFO - 2017-02-04 01:36:28 --> Security Class Initialized
DEBUG - 2017-02-04 01:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:36:28 --> Input Class Initialized
INFO - 2017-02-04 01:36:28 --> Language Class Initialized
INFO - 2017-02-04 01:36:28 --> Loader Class Initialized
INFO - 2017-02-04 01:36:28 --> Database Driver Class Initialized
INFO - 2017-02-04 01:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:36:28 --> Controller Class Initialized
INFO - 2017-02-04 01:36:28 --> Helper loaded: date_helper
DEBUG - 2017-02-04 01:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:36:28 --> Helper loaded: url_helper
INFO - 2017-02-04 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-04 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-04 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-04 01:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:36:28 --> Final output sent to browser
DEBUG - 2017-02-04 01:36:28 --> Total execution time: 0.0136
INFO - 2017-02-04 01:59:57 --> Config Class Initialized
INFO - 2017-02-04 01:59:57 --> Hooks Class Initialized
DEBUG - 2017-02-04 01:59:57 --> UTF-8 Support Enabled
INFO - 2017-02-04 01:59:57 --> Utf8 Class Initialized
INFO - 2017-02-04 01:59:57 --> URI Class Initialized
DEBUG - 2017-02-04 01:59:57 --> No URI present. Default controller set.
INFO - 2017-02-04 01:59:57 --> Router Class Initialized
INFO - 2017-02-04 01:59:57 --> Output Class Initialized
INFO - 2017-02-04 01:59:57 --> Security Class Initialized
DEBUG - 2017-02-04 01:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 01:59:57 --> Input Class Initialized
INFO - 2017-02-04 01:59:57 --> Language Class Initialized
INFO - 2017-02-04 01:59:57 --> Loader Class Initialized
INFO - 2017-02-04 01:59:57 --> Database Driver Class Initialized
INFO - 2017-02-04 01:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 01:59:57 --> Controller Class Initialized
INFO - 2017-02-04 01:59:57 --> Helper loaded: url_helper
DEBUG - 2017-02-04 01:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 01:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 01:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 01:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 01:59:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 01:59:57 --> Final output sent to browser
DEBUG - 2017-02-04 01:59:57 --> Total execution time: 0.0135
INFO - 2017-02-04 02:08:44 --> Config Class Initialized
INFO - 2017-02-04 02:08:44 --> Hooks Class Initialized
DEBUG - 2017-02-04 02:08:44 --> UTF-8 Support Enabled
INFO - 2017-02-04 02:08:44 --> Utf8 Class Initialized
INFO - 2017-02-04 02:08:44 --> URI Class Initialized
DEBUG - 2017-02-04 02:08:44 --> No URI present. Default controller set.
INFO - 2017-02-04 02:08:44 --> Router Class Initialized
INFO - 2017-02-04 02:08:44 --> Output Class Initialized
INFO - 2017-02-04 02:08:44 --> Security Class Initialized
DEBUG - 2017-02-04 02:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 02:08:44 --> Input Class Initialized
INFO - 2017-02-04 02:08:44 --> Language Class Initialized
INFO - 2017-02-04 02:08:44 --> Loader Class Initialized
INFO - 2017-02-04 02:08:44 --> Database Driver Class Initialized
INFO - 2017-02-04 02:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 02:08:44 --> Controller Class Initialized
INFO - 2017-02-04 02:08:44 --> Helper loaded: url_helper
DEBUG - 2017-02-04 02:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 02:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 02:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 02:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 02:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 02:08:44 --> Final output sent to browser
DEBUG - 2017-02-04 02:08:44 --> Total execution time: 0.0141
INFO - 2017-02-04 02:21:12 --> Config Class Initialized
INFO - 2017-02-04 02:21:12 --> Hooks Class Initialized
DEBUG - 2017-02-04 02:21:12 --> UTF-8 Support Enabled
INFO - 2017-02-04 02:21:12 --> Utf8 Class Initialized
INFO - 2017-02-04 02:21:12 --> URI Class Initialized
DEBUG - 2017-02-04 02:21:12 --> No URI present. Default controller set.
INFO - 2017-02-04 02:21:12 --> Router Class Initialized
INFO - 2017-02-04 02:21:12 --> Output Class Initialized
INFO - 2017-02-04 02:21:12 --> Security Class Initialized
DEBUG - 2017-02-04 02:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 02:21:12 --> Input Class Initialized
INFO - 2017-02-04 02:21:12 --> Language Class Initialized
INFO - 2017-02-04 02:21:12 --> Loader Class Initialized
INFO - 2017-02-04 02:21:12 --> Database Driver Class Initialized
INFO - 2017-02-04 02:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 02:21:12 --> Controller Class Initialized
INFO - 2017-02-04 02:21:12 --> Helper loaded: url_helper
DEBUG - 2017-02-04 02:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 02:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 02:21:12 --> Final output sent to browser
DEBUG - 2017-02-04 02:21:12 --> Total execution time: 0.0134
INFO - 2017-02-04 03:08:06 --> Config Class Initialized
INFO - 2017-02-04 03:08:06 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:08:06 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:08:06 --> Utf8 Class Initialized
INFO - 2017-02-04 03:08:06 --> URI Class Initialized
DEBUG - 2017-02-04 03:08:06 --> No URI present. Default controller set.
INFO - 2017-02-04 03:08:06 --> Router Class Initialized
INFO - 2017-02-04 03:08:06 --> Output Class Initialized
INFO - 2017-02-04 03:08:06 --> Security Class Initialized
DEBUG - 2017-02-04 03:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:08:06 --> Input Class Initialized
INFO - 2017-02-04 03:08:06 --> Language Class Initialized
INFO - 2017-02-04 03:08:06 --> Loader Class Initialized
INFO - 2017-02-04 03:08:06 --> Database Driver Class Initialized
INFO - 2017-02-04 03:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:08:06 --> Controller Class Initialized
INFO - 2017-02-04 03:08:06 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:08:06 --> Final output sent to browser
DEBUG - 2017-02-04 03:08:06 --> Total execution time: 0.0781
INFO - 2017-02-04 03:08:16 --> Config Class Initialized
INFO - 2017-02-04 03:08:16 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:08:16 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:08:16 --> Utf8 Class Initialized
INFO - 2017-02-04 03:08:16 --> URI Class Initialized
INFO - 2017-02-04 03:08:16 --> Router Class Initialized
INFO - 2017-02-04 03:08:16 --> Output Class Initialized
INFO - 2017-02-04 03:08:16 --> Security Class Initialized
DEBUG - 2017-02-04 03:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:08:16 --> Input Class Initialized
INFO - 2017-02-04 03:08:16 --> Language Class Initialized
INFO - 2017-02-04 03:08:16 --> Loader Class Initialized
INFO - 2017-02-04 03:08:16 --> Database Driver Class Initialized
INFO - 2017-02-04 03:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:08:16 --> Controller Class Initialized
INFO - 2017-02-04 03:08:16 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:08:18 --> Config Class Initialized
INFO - 2017-02-04 03:08:18 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:08:18 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:08:18 --> Utf8 Class Initialized
INFO - 2017-02-04 03:08:18 --> URI Class Initialized
INFO - 2017-02-04 03:08:18 --> Router Class Initialized
INFO - 2017-02-04 03:08:18 --> Output Class Initialized
INFO - 2017-02-04 03:08:18 --> Security Class Initialized
DEBUG - 2017-02-04 03:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:08:18 --> Input Class Initialized
INFO - 2017-02-04 03:08:18 --> Language Class Initialized
INFO - 2017-02-04 03:08:18 --> Loader Class Initialized
INFO - 2017-02-04 03:08:18 --> Database Driver Class Initialized
INFO - 2017-02-04 03:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:08:18 --> Controller Class Initialized
INFO - 2017-02-04 03:08:18 --> Helper loaded: date_helper
DEBUG - 2017-02-04 03:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:08:18 --> Helper loaded: url_helper
INFO - 2017-02-04 03:08:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:08:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-04 03:08:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-04 03:08:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-04 03:08:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:08:18 --> Final output sent to browser
DEBUG - 2017-02-04 03:08:18 --> Total execution time: 0.1337
INFO - 2017-02-04 03:08:27 --> Config Class Initialized
INFO - 2017-02-04 03:08:27 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:08:27 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:08:27 --> Utf8 Class Initialized
INFO - 2017-02-04 03:08:27 --> URI Class Initialized
INFO - 2017-02-04 03:08:27 --> Router Class Initialized
INFO - 2017-02-04 03:08:27 --> Output Class Initialized
INFO - 2017-02-04 03:08:27 --> Security Class Initialized
DEBUG - 2017-02-04 03:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:08:27 --> Input Class Initialized
INFO - 2017-02-04 03:08:27 --> Language Class Initialized
INFO - 2017-02-04 03:08:27 --> Loader Class Initialized
INFO - 2017-02-04 03:08:27 --> Database Driver Class Initialized
INFO - 2017-02-04 03:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:08:27 --> Controller Class Initialized
INFO - 2017-02-04 03:08:27 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:08:27 --> Final output sent to browser
DEBUG - 2017-02-04 03:08:27 --> Total execution time: 0.0141
INFO - 2017-02-04 03:12:31 --> Config Class Initialized
INFO - 2017-02-04 03:12:31 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:12:31 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:12:31 --> Utf8 Class Initialized
INFO - 2017-02-04 03:12:31 --> URI Class Initialized
INFO - 2017-02-04 03:12:31 --> Router Class Initialized
INFO - 2017-02-04 03:12:31 --> Output Class Initialized
INFO - 2017-02-04 03:12:31 --> Security Class Initialized
DEBUG - 2017-02-04 03:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:12:31 --> Input Class Initialized
INFO - 2017-02-04 03:12:31 --> Language Class Initialized
INFO - 2017-02-04 03:12:31 --> Loader Class Initialized
INFO - 2017-02-04 03:12:31 --> Database Driver Class Initialized
INFO - 2017-02-04 03:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:12:31 --> Controller Class Initialized
INFO - 2017-02-04 03:12:31 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:12:32 --> Config Class Initialized
INFO - 2017-02-04 03:12:32 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:12:32 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:12:32 --> Utf8 Class Initialized
INFO - 2017-02-04 03:12:32 --> URI Class Initialized
INFO - 2017-02-04 03:12:32 --> Router Class Initialized
INFO - 2017-02-04 03:12:32 --> Output Class Initialized
INFO - 2017-02-04 03:12:32 --> Security Class Initialized
DEBUG - 2017-02-04 03:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:12:32 --> Input Class Initialized
INFO - 2017-02-04 03:12:32 --> Language Class Initialized
INFO - 2017-02-04 03:12:32 --> Loader Class Initialized
INFO - 2017-02-04 03:12:32 --> Database Driver Class Initialized
INFO - 2017-02-04 03:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:12:32 --> Controller Class Initialized
INFO - 2017-02-04 03:12:32 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:12:32 --> Final output sent to browser
DEBUG - 2017-02-04 03:12:32 --> Total execution time: 0.0145
INFO - 2017-02-04 03:12:32 --> Config Class Initialized
INFO - 2017-02-04 03:12:32 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:12:32 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:12:32 --> Utf8 Class Initialized
INFO - 2017-02-04 03:12:32 --> URI Class Initialized
DEBUG - 2017-02-04 03:12:32 --> No URI present. Default controller set.
INFO - 2017-02-04 03:12:32 --> Router Class Initialized
INFO - 2017-02-04 03:12:32 --> Output Class Initialized
INFO - 2017-02-04 03:12:32 --> Security Class Initialized
DEBUG - 2017-02-04 03:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:12:32 --> Input Class Initialized
INFO - 2017-02-04 03:12:32 --> Language Class Initialized
INFO - 2017-02-04 03:12:32 --> Loader Class Initialized
INFO - 2017-02-04 03:12:32 --> Database Driver Class Initialized
INFO - 2017-02-04 03:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:12:32 --> Controller Class Initialized
INFO - 2017-02-04 03:12:32 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:12:32 --> Final output sent to browser
DEBUG - 2017-02-04 03:12:32 --> Total execution time: 0.0139
INFO - 2017-02-04 03:16:08 --> Config Class Initialized
INFO - 2017-02-04 03:16:08 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:16:08 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:16:08 --> Utf8 Class Initialized
INFO - 2017-02-04 03:16:08 --> URI Class Initialized
INFO - 2017-02-04 03:16:08 --> Router Class Initialized
INFO - 2017-02-04 03:16:08 --> Output Class Initialized
INFO - 2017-02-04 03:16:08 --> Security Class Initialized
DEBUG - 2017-02-04 03:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:16:08 --> Input Class Initialized
INFO - 2017-02-04 03:16:08 --> Language Class Initialized
INFO - 2017-02-04 03:16:08 --> Loader Class Initialized
INFO - 2017-02-04 03:16:08 --> Database Driver Class Initialized
INFO - 2017-02-04 03:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:16:08 --> Controller Class Initialized
INFO - 2017-02-04 03:16:08 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:16:08 --> Final output sent to browser
DEBUG - 2017-02-04 03:16:08 --> Total execution time: 0.0132
INFO - 2017-02-04 03:16:08 --> Config Class Initialized
INFO - 2017-02-04 03:16:08 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:16:08 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:16:08 --> Utf8 Class Initialized
INFO - 2017-02-04 03:16:08 --> URI Class Initialized
DEBUG - 2017-02-04 03:16:08 --> No URI present. Default controller set.
INFO - 2017-02-04 03:16:08 --> Router Class Initialized
INFO - 2017-02-04 03:16:08 --> Output Class Initialized
INFO - 2017-02-04 03:16:08 --> Security Class Initialized
DEBUG - 2017-02-04 03:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:16:08 --> Input Class Initialized
INFO - 2017-02-04 03:16:08 --> Language Class Initialized
INFO - 2017-02-04 03:16:08 --> Loader Class Initialized
INFO - 2017-02-04 03:16:08 --> Database Driver Class Initialized
INFO - 2017-02-04 03:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:16:08 --> Controller Class Initialized
INFO - 2017-02-04 03:16:08 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:16:08 --> Final output sent to browser
DEBUG - 2017-02-04 03:16:08 --> Total execution time: 0.0135
INFO - 2017-02-04 03:48:52 --> Config Class Initialized
INFO - 2017-02-04 03:48:52 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:48:52 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:48:52 --> Utf8 Class Initialized
INFO - 2017-02-04 03:48:52 --> URI Class Initialized
DEBUG - 2017-02-04 03:48:52 --> No URI present. Default controller set.
INFO - 2017-02-04 03:48:52 --> Router Class Initialized
INFO - 2017-02-04 03:48:52 --> Output Class Initialized
INFO - 2017-02-04 03:48:52 --> Security Class Initialized
DEBUG - 2017-02-04 03:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:48:52 --> Input Class Initialized
INFO - 2017-02-04 03:48:52 --> Language Class Initialized
INFO - 2017-02-04 03:48:52 --> Loader Class Initialized
INFO - 2017-02-04 03:48:52 --> Database Driver Class Initialized
INFO - 2017-02-04 03:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:48:52 --> Controller Class Initialized
INFO - 2017-02-04 03:48:52 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:48:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:48:52 --> Final output sent to browser
DEBUG - 2017-02-04 03:48:52 --> Total execution time: 0.0145
INFO - 2017-02-04 03:48:59 --> Config Class Initialized
INFO - 2017-02-04 03:48:59 --> Hooks Class Initialized
DEBUG - 2017-02-04 03:48:59 --> UTF-8 Support Enabled
INFO - 2017-02-04 03:48:59 --> Utf8 Class Initialized
INFO - 2017-02-04 03:48:59 --> URI Class Initialized
INFO - 2017-02-04 03:48:59 --> Router Class Initialized
INFO - 2017-02-04 03:48:59 --> Output Class Initialized
INFO - 2017-02-04 03:48:59 --> Security Class Initialized
DEBUG - 2017-02-04 03:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 03:48:59 --> Input Class Initialized
INFO - 2017-02-04 03:48:59 --> Language Class Initialized
INFO - 2017-02-04 03:48:59 --> Loader Class Initialized
INFO - 2017-02-04 03:48:59 --> Database Driver Class Initialized
INFO - 2017-02-04 03:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 03:48:59 --> Controller Class Initialized
INFO - 2017-02-04 03:48:59 --> Helper loaded: url_helper
DEBUG - 2017-02-04 03:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 03:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 03:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 03:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 03:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 03:48:59 --> Final output sent to browser
DEBUG - 2017-02-04 03:48:59 --> Total execution time: 0.0139
INFO - 2017-02-04 05:12:36 --> Config Class Initialized
INFO - 2017-02-04 05:12:36 --> Hooks Class Initialized
DEBUG - 2017-02-04 05:12:36 --> UTF-8 Support Enabled
INFO - 2017-02-04 05:12:36 --> Utf8 Class Initialized
INFO - 2017-02-04 05:12:36 --> URI Class Initialized
INFO - 2017-02-04 05:12:36 --> Router Class Initialized
INFO - 2017-02-04 05:12:36 --> Output Class Initialized
INFO - 2017-02-04 05:12:36 --> Security Class Initialized
DEBUG - 2017-02-04 05:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 05:12:36 --> Input Class Initialized
INFO - 2017-02-04 05:12:36 --> Language Class Initialized
INFO - 2017-02-04 05:12:36 --> Loader Class Initialized
INFO - 2017-02-04 05:12:36 --> Database Driver Class Initialized
INFO - 2017-02-04 05:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 05:12:37 --> Controller Class Initialized
INFO - 2017-02-04 05:12:37 --> Helper loaded: date_helper
DEBUG - 2017-02-04 05:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 05:12:37 --> Helper loaded: url_helper
INFO - 2017-02-04 05:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 05:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-04 05:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-04 05:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-04 05:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 05:12:37 --> Final output sent to browser
DEBUG - 2017-02-04 05:12:37 --> Total execution time: 1.6375
INFO - 2017-02-04 05:12:42 --> Config Class Initialized
INFO - 2017-02-04 05:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-04 05:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-04 05:12:42 --> Utf8 Class Initialized
INFO - 2017-02-04 05:12:42 --> URI Class Initialized
INFO - 2017-02-04 05:12:42 --> Router Class Initialized
INFO - 2017-02-04 05:12:42 --> Output Class Initialized
INFO - 2017-02-04 05:12:42 --> Security Class Initialized
DEBUG - 2017-02-04 05:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 05:12:42 --> Input Class Initialized
INFO - 2017-02-04 05:12:42 --> Language Class Initialized
INFO - 2017-02-04 05:12:42 --> Loader Class Initialized
INFO - 2017-02-04 05:12:42 --> Database Driver Class Initialized
INFO - 2017-02-04 05:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 05:12:42 --> Controller Class Initialized
INFO - 2017-02-04 05:12:42 --> Helper loaded: url_helper
DEBUG - 2017-02-04 05:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 05:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 05:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 05:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 05:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 05:12:43 --> Final output sent to browser
DEBUG - 2017-02-04 05:12:43 --> Total execution time: 0.2508
INFO - 2017-02-04 05:12:46 --> Config Class Initialized
INFO - 2017-02-04 05:12:46 --> Hooks Class Initialized
DEBUG - 2017-02-04 05:12:46 --> UTF-8 Support Enabled
INFO - 2017-02-04 05:12:46 --> Utf8 Class Initialized
INFO - 2017-02-04 05:12:46 --> URI Class Initialized
DEBUG - 2017-02-04 05:12:46 --> No URI present. Default controller set.
INFO - 2017-02-04 05:12:46 --> Router Class Initialized
INFO - 2017-02-04 05:12:46 --> Output Class Initialized
INFO - 2017-02-04 05:12:46 --> Security Class Initialized
DEBUG - 2017-02-04 05:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 05:12:46 --> Input Class Initialized
INFO - 2017-02-04 05:12:46 --> Language Class Initialized
INFO - 2017-02-04 05:12:46 --> Loader Class Initialized
INFO - 2017-02-04 05:12:46 --> Database Driver Class Initialized
INFO - 2017-02-04 05:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 05:12:46 --> Controller Class Initialized
INFO - 2017-02-04 05:12:46 --> Helper loaded: url_helper
DEBUG - 2017-02-04 05:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 05:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 05:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 05:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 05:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 05:12:46 --> Final output sent to browser
DEBUG - 2017-02-04 05:12:46 --> Total execution time: 0.0143
INFO - 2017-02-04 05:12:50 --> Config Class Initialized
INFO - 2017-02-04 05:12:50 --> Hooks Class Initialized
DEBUG - 2017-02-04 05:12:50 --> UTF-8 Support Enabled
INFO - 2017-02-04 05:12:50 --> Utf8 Class Initialized
INFO - 2017-02-04 05:12:50 --> URI Class Initialized
INFO - 2017-02-04 05:12:50 --> Router Class Initialized
INFO - 2017-02-04 05:12:50 --> Output Class Initialized
INFO - 2017-02-04 05:12:50 --> Security Class Initialized
DEBUG - 2017-02-04 05:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 05:12:50 --> Input Class Initialized
INFO - 2017-02-04 05:12:50 --> Language Class Initialized
INFO - 2017-02-04 05:12:50 --> Loader Class Initialized
INFO - 2017-02-04 05:12:50 --> Database Driver Class Initialized
INFO - 2017-02-04 05:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 05:12:50 --> Controller Class Initialized
INFO - 2017-02-04 05:12:50 --> Helper loaded: url_helper
DEBUG - 2017-02-04 05:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 05:12:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 05:12:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 05:12:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 05:12:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 05:12:50 --> Final output sent to browser
DEBUG - 2017-02-04 05:12:50 --> Total execution time: 0.0613
INFO - 2017-02-04 19:19:24 --> Config Class Initialized
INFO - 2017-02-04 19:19:24 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:19:25 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:19:25 --> Utf8 Class Initialized
INFO - 2017-02-04 19:19:25 --> URI Class Initialized
DEBUG - 2017-02-04 19:19:25 --> No URI present. Default controller set.
INFO - 2017-02-04 19:19:25 --> Router Class Initialized
INFO - 2017-02-04 19:19:25 --> Output Class Initialized
INFO - 2017-02-04 19:19:25 --> Security Class Initialized
DEBUG - 2017-02-04 19:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:19:25 --> Input Class Initialized
INFO - 2017-02-04 19:19:25 --> Language Class Initialized
INFO - 2017-02-04 19:19:25 --> Loader Class Initialized
INFO - 2017-02-04 19:19:25 --> Database Driver Class Initialized
INFO - 2017-02-04 19:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:19:25 --> Controller Class Initialized
INFO - 2017-02-04 19:19:25 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:19:26 --> Final output sent to browser
DEBUG - 2017-02-04 19:19:26 --> Total execution time: 1.4872
INFO - 2017-02-04 19:19:32 --> Config Class Initialized
INFO - 2017-02-04 19:19:32 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:19:32 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:19:32 --> Utf8 Class Initialized
INFO - 2017-02-04 19:19:32 --> URI Class Initialized
INFO - 2017-02-04 19:19:32 --> Router Class Initialized
INFO - 2017-02-04 19:19:32 --> Output Class Initialized
INFO - 2017-02-04 19:19:32 --> Security Class Initialized
DEBUG - 2017-02-04 19:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:19:32 --> Input Class Initialized
INFO - 2017-02-04 19:19:32 --> Language Class Initialized
INFO - 2017-02-04 19:19:32 --> Loader Class Initialized
INFO - 2017-02-04 19:19:33 --> Database Driver Class Initialized
INFO - 2017-02-04 19:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:19:33 --> Controller Class Initialized
INFO - 2017-02-04 19:19:33 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:19:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:19:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:19:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:19:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:19:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:19:33 --> Final output sent to browser
DEBUG - 2017-02-04 19:19:33 --> Total execution time: 1.2098
INFO - 2017-02-04 19:19:40 --> Config Class Initialized
INFO - 2017-02-04 19:19:40 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:19:40 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:19:40 --> Utf8 Class Initialized
INFO - 2017-02-04 19:19:40 --> URI Class Initialized
INFO - 2017-02-04 19:19:40 --> Router Class Initialized
INFO - 2017-02-04 19:19:40 --> Output Class Initialized
INFO - 2017-02-04 19:19:40 --> Security Class Initialized
DEBUG - 2017-02-04 19:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:19:40 --> Input Class Initialized
INFO - 2017-02-04 19:19:40 --> Language Class Initialized
INFO - 2017-02-04 19:19:40 --> Loader Class Initialized
INFO - 2017-02-04 19:19:40 --> Database Driver Class Initialized
INFO - 2017-02-04 19:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:19:40 --> Controller Class Initialized
INFO - 2017-02-04 19:19:40 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:19:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-04 19:19:43 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-04 19:19:43 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-04 19:19:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-04 19:19:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-04 19:19:44 --> Config Class Initialized
INFO - 2017-02-04 19:19:44 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:19:44 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:19:44 --> Utf8 Class Initialized
INFO - 2017-02-04 19:19:44 --> URI Class Initialized
INFO - 2017-02-04 19:19:44 --> Router Class Initialized
INFO - 2017-02-04 19:19:44 --> Output Class Initialized
INFO - 2017-02-04 19:19:44 --> Security Class Initialized
DEBUG - 2017-02-04 19:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:19:44 --> Input Class Initialized
INFO - 2017-02-04 19:19:44 --> Language Class Initialized
INFO - 2017-02-04 19:19:44 --> Loader Class Initialized
INFO - 2017-02-04 19:19:44 --> Database Driver Class Initialized
INFO - 2017-02-04 19:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:19:44 --> Controller Class Initialized
INFO - 2017-02-04 19:19:44 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:19:44 --> Final output sent to browser
DEBUG - 2017-02-04 19:19:44 --> Total execution time: 0.1533
INFO - 2017-02-04 19:20:24 --> Config Class Initialized
INFO - 2017-02-04 19:20:24 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:20:24 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:20:24 --> Utf8 Class Initialized
INFO - 2017-02-04 19:20:24 --> URI Class Initialized
DEBUG - 2017-02-04 19:20:24 --> No URI present. Default controller set.
INFO - 2017-02-04 19:20:24 --> Router Class Initialized
INFO - 2017-02-04 19:20:24 --> Output Class Initialized
INFO - 2017-02-04 19:20:24 --> Security Class Initialized
DEBUG - 2017-02-04 19:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:20:24 --> Input Class Initialized
INFO - 2017-02-04 19:20:24 --> Language Class Initialized
INFO - 2017-02-04 19:20:24 --> Loader Class Initialized
INFO - 2017-02-04 19:20:24 --> Database Driver Class Initialized
INFO - 2017-02-04 19:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:20:24 --> Controller Class Initialized
INFO - 2017-02-04 19:20:24 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:20:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:20:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:20:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:20:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:20:24 --> Final output sent to browser
DEBUG - 2017-02-04 19:20:24 --> Total execution time: 0.0135
INFO - 2017-02-04 19:20:26 --> Config Class Initialized
INFO - 2017-02-04 19:20:26 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:20:26 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:20:26 --> Utf8 Class Initialized
INFO - 2017-02-04 19:20:26 --> URI Class Initialized
INFO - 2017-02-04 19:20:26 --> Router Class Initialized
INFO - 2017-02-04 19:20:26 --> Output Class Initialized
INFO - 2017-02-04 19:20:26 --> Security Class Initialized
DEBUG - 2017-02-04 19:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:20:26 --> Input Class Initialized
INFO - 2017-02-04 19:20:26 --> Language Class Initialized
INFO - 2017-02-04 19:20:26 --> Loader Class Initialized
INFO - 2017-02-04 19:20:26 --> Database Driver Class Initialized
INFO - 2017-02-04 19:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:20:26 --> Controller Class Initialized
INFO - 2017-02-04 19:20:26 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:20:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:20:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:20:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:20:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:20:26 --> Final output sent to browser
DEBUG - 2017-02-04 19:20:26 --> Total execution time: 0.0732
INFO - 2017-02-04 19:21:16 --> Config Class Initialized
INFO - 2017-02-04 19:21:16 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:21:16 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:21:16 --> Utf8 Class Initialized
INFO - 2017-02-04 19:21:16 --> URI Class Initialized
DEBUG - 2017-02-04 19:21:16 --> No URI present. Default controller set.
INFO - 2017-02-04 19:21:16 --> Router Class Initialized
INFO - 2017-02-04 19:21:16 --> Output Class Initialized
INFO - 2017-02-04 19:21:16 --> Security Class Initialized
DEBUG - 2017-02-04 19:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:21:16 --> Input Class Initialized
INFO - 2017-02-04 19:21:16 --> Language Class Initialized
INFO - 2017-02-04 19:21:16 --> Loader Class Initialized
INFO - 2017-02-04 19:21:16 --> Database Driver Class Initialized
INFO - 2017-02-04 19:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:21:16 --> Controller Class Initialized
INFO - 2017-02-04 19:21:16 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:21:16 --> Final output sent to browser
DEBUG - 2017-02-04 19:21:16 --> Total execution time: 0.0136
INFO - 2017-02-04 19:21:17 --> Config Class Initialized
INFO - 2017-02-04 19:21:17 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:21:17 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:21:17 --> Utf8 Class Initialized
INFO - 2017-02-04 19:21:17 --> URI Class Initialized
INFO - 2017-02-04 19:21:17 --> Router Class Initialized
INFO - 2017-02-04 19:21:17 --> Output Class Initialized
INFO - 2017-02-04 19:21:17 --> Security Class Initialized
DEBUG - 2017-02-04 19:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:21:17 --> Input Class Initialized
INFO - 2017-02-04 19:21:17 --> Language Class Initialized
INFO - 2017-02-04 19:21:17 --> Loader Class Initialized
INFO - 2017-02-04 19:21:17 --> Database Driver Class Initialized
INFO - 2017-02-04 19:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:21:17 --> Controller Class Initialized
INFO - 2017-02-04 19:21:17 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:21:17 --> Final output sent to browser
DEBUG - 2017-02-04 19:21:17 --> Total execution time: 0.0133
INFO - 2017-02-04 19:21:39 --> Config Class Initialized
INFO - 2017-02-04 19:21:39 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:21:39 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:21:39 --> Utf8 Class Initialized
INFO - 2017-02-04 19:21:39 --> URI Class Initialized
INFO - 2017-02-04 19:21:39 --> Router Class Initialized
INFO - 2017-02-04 19:21:39 --> Output Class Initialized
INFO - 2017-02-04 19:21:39 --> Security Class Initialized
DEBUG - 2017-02-04 19:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:21:39 --> Input Class Initialized
INFO - 2017-02-04 19:21:39 --> Language Class Initialized
INFO - 2017-02-04 19:21:39 --> Loader Class Initialized
INFO - 2017-02-04 19:21:39 --> Database Driver Class Initialized
INFO - 2017-02-04 19:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:21:39 --> Controller Class Initialized
INFO - 2017-02-04 19:21:39 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:21:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-04 19:21:40 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-04 19:21:40 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ale Serrano')
INFO - 2017-02-04 19:21:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-04 19:21:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-04 19:21:41 --> Config Class Initialized
INFO - 2017-02-04 19:21:41 --> Hooks Class Initialized
DEBUG - 2017-02-04 19:21:41 --> UTF-8 Support Enabled
INFO - 2017-02-04 19:21:41 --> Utf8 Class Initialized
INFO - 2017-02-04 19:21:41 --> URI Class Initialized
INFO - 2017-02-04 19:21:41 --> Router Class Initialized
INFO - 2017-02-04 19:21:41 --> Output Class Initialized
INFO - 2017-02-04 19:21:41 --> Security Class Initialized
DEBUG - 2017-02-04 19:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-04 19:21:41 --> Input Class Initialized
INFO - 2017-02-04 19:21:41 --> Language Class Initialized
INFO - 2017-02-04 19:21:41 --> Loader Class Initialized
INFO - 2017-02-04 19:21:41 --> Database Driver Class Initialized
INFO - 2017-02-04 19:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-04 19:21:41 --> Controller Class Initialized
INFO - 2017-02-04 19:21:41 --> Helper loaded: url_helper
DEBUG - 2017-02-04 19:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-04 19:21:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-04 19:21:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-04 19:21:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-04 19:21:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-04 19:21:41 --> Final output sent to browser
DEBUG - 2017-02-04 19:21:41 --> Total execution time: 0.1094

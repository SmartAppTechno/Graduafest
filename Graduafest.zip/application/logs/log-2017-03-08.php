<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-08 02:22:50 --> Config Class Initialized
INFO - 2017-03-08 02:22:51 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:22:51 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:22:51 --> Utf8 Class Initialized
INFO - 2017-03-08 02:22:51 --> URI Class Initialized
DEBUG - 2017-03-08 02:22:51 --> No URI present. Default controller set.
INFO - 2017-03-08 02:22:51 --> Router Class Initialized
INFO - 2017-03-08 02:22:51 --> Output Class Initialized
INFO - 2017-03-08 02:22:51 --> Security Class Initialized
DEBUG - 2017-03-08 02:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:22:51 --> Input Class Initialized
INFO - 2017-03-08 02:22:51 --> Language Class Initialized
INFO - 2017-03-08 02:22:51 --> Loader Class Initialized
INFO - 2017-03-08 02:22:51 --> Database Driver Class Initialized
INFO - 2017-03-08 02:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:22:51 --> Controller Class Initialized
INFO - 2017-03-08 02:22:51 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:22:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 02:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 02:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:22:52 --> Final output sent to browser
DEBUG - 2017-03-08 02:22:52 --> Total execution time: 1.7542
INFO - 2017-03-08 02:23:04 --> Config Class Initialized
INFO - 2017-03-08 02:23:04 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:23:04 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:23:04 --> Utf8 Class Initialized
INFO - 2017-03-08 02:23:04 --> URI Class Initialized
INFO - 2017-03-08 02:23:04 --> Router Class Initialized
INFO - 2017-03-08 02:23:04 --> Output Class Initialized
INFO - 2017-03-08 02:23:05 --> Security Class Initialized
DEBUG - 2017-03-08 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:23:05 --> Input Class Initialized
INFO - 2017-03-08 02:23:05 --> Language Class Initialized
INFO - 2017-03-08 02:23:05 --> Loader Class Initialized
INFO - 2017-03-08 02:23:05 --> Database Driver Class Initialized
INFO - 2017-03-08 02:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:23:05 --> Controller Class Initialized
INFO - 2017-03-08 02:23:05 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 02:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 02:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:23:05 --> Final output sent to browser
DEBUG - 2017-03-08 02:23:05 --> Total execution time: 1.2157
INFO - 2017-03-08 02:24:27 --> Config Class Initialized
INFO - 2017-03-08 02:24:27 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:24:27 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:24:27 --> Utf8 Class Initialized
INFO - 2017-03-08 02:24:27 --> URI Class Initialized
INFO - 2017-03-08 02:24:27 --> Router Class Initialized
INFO - 2017-03-08 02:24:27 --> Output Class Initialized
INFO - 2017-03-08 02:24:27 --> Security Class Initialized
DEBUG - 2017-03-08 02:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:24:27 --> Input Class Initialized
INFO - 2017-03-08 02:24:27 --> Language Class Initialized
INFO - 2017-03-08 02:24:27 --> Loader Class Initialized
INFO - 2017-03-08 02:24:27 --> Database Driver Class Initialized
INFO - 2017-03-08 02:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:24:28 --> Controller Class Initialized
INFO - 2017-03-08 02:24:28 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:24:32 --> Config Class Initialized
INFO - 2017-03-08 02:24:32 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:24:32 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:24:32 --> Utf8 Class Initialized
INFO - 2017-03-08 02:24:32 --> URI Class Initialized
INFO - 2017-03-08 02:24:32 --> Router Class Initialized
INFO - 2017-03-08 02:24:32 --> Output Class Initialized
INFO - 2017-03-08 02:24:32 --> Security Class Initialized
DEBUG - 2017-03-08 02:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:24:32 --> Input Class Initialized
INFO - 2017-03-08 02:24:32 --> Language Class Initialized
INFO - 2017-03-08 02:24:32 --> Loader Class Initialized
INFO - 2017-03-08 02:24:32 --> Database Driver Class Initialized
INFO - 2017-03-08 02:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:24:32 --> Controller Class Initialized
INFO - 2017-03-08 02:24:32 --> Helper loaded: date_helper
DEBUG - 2017-03-08 02:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:24:32 --> Helper loaded: url_helper
INFO - 2017-03-08 02:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 02:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 02:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 02:24:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:24:32 --> Final output sent to browser
DEBUG - 2017-03-08 02:24:33 --> Total execution time: 0.1381
INFO - 2017-03-08 02:24:34 --> Config Class Initialized
INFO - 2017-03-08 02:24:34 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:24:34 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:24:34 --> Utf8 Class Initialized
INFO - 2017-03-08 02:24:34 --> URI Class Initialized
INFO - 2017-03-08 02:24:34 --> Router Class Initialized
INFO - 2017-03-08 02:24:34 --> Output Class Initialized
INFO - 2017-03-08 02:24:34 --> Security Class Initialized
DEBUG - 2017-03-08 02:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:24:34 --> Input Class Initialized
INFO - 2017-03-08 02:24:34 --> Language Class Initialized
INFO - 2017-03-08 02:24:34 --> Loader Class Initialized
INFO - 2017-03-08 02:24:34 --> Database Driver Class Initialized
INFO - 2017-03-08 02:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:24:34 --> Controller Class Initialized
INFO - 2017-03-08 02:24:34 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:24:34 --> Final output sent to browser
DEBUG - 2017-03-08 02:24:34 --> Total execution time: 0.0338
INFO - 2017-03-08 02:25:20 --> Config Class Initialized
INFO - 2017-03-08 02:25:20 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:25:21 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:25:21 --> Utf8 Class Initialized
INFO - 2017-03-08 02:25:21 --> URI Class Initialized
INFO - 2017-03-08 02:25:21 --> Router Class Initialized
INFO - 2017-03-08 02:25:21 --> Output Class Initialized
INFO - 2017-03-08 02:25:21 --> Security Class Initialized
DEBUG - 2017-03-08 02:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:25:21 --> Input Class Initialized
INFO - 2017-03-08 02:25:21 --> Language Class Initialized
INFO - 2017-03-08 02:25:21 --> Loader Class Initialized
INFO - 2017-03-08 02:25:21 --> Database Driver Class Initialized
INFO - 2017-03-08 02:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:25:21 --> Controller Class Initialized
INFO - 2017-03-08 02:25:21 --> Helper loaded: date_helper
DEBUG - 2017-03-08 02:25:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:25:21 --> Helper loaded: url_helper
INFO - 2017-03-08 02:25:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 02:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 02:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 02:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:25:22 --> Final output sent to browser
DEBUG - 2017-03-08 02:25:22 --> Total execution time: 1.3315
INFO - 2017-03-08 02:25:23 --> Config Class Initialized
INFO - 2017-03-08 02:25:23 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:25:23 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:25:23 --> Utf8 Class Initialized
INFO - 2017-03-08 02:25:23 --> URI Class Initialized
INFO - 2017-03-08 02:25:23 --> Router Class Initialized
INFO - 2017-03-08 02:25:23 --> Output Class Initialized
INFO - 2017-03-08 02:25:23 --> Security Class Initialized
DEBUG - 2017-03-08 02:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:25:23 --> Input Class Initialized
INFO - 2017-03-08 02:25:23 --> Language Class Initialized
INFO - 2017-03-08 02:25:23 --> Loader Class Initialized
INFO - 2017-03-08 02:25:23 --> Database Driver Class Initialized
INFO - 2017-03-08 02:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:25:23 --> Controller Class Initialized
INFO - 2017-03-08 02:25:23 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 02:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 02:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:25:23 --> Final output sent to browser
DEBUG - 2017-03-08 02:25:23 --> Total execution time: 0.2426
INFO - 2017-03-08 02:25:25 --> Config Class Initialized
INFO - 2017-03-08 02:25:25 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:25:25 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:25:25 --> Utf8 Class Initialized
INFO - 2017-03-08 02:25:25 --> URI Class Initialized
INFO - 2017-03-08 02:25:25 --> Router Class Initialized
INFO - 2017-03-08 02:25:25 --> Output Class Initialized
INFO - 2017-03-08 02:25:25 --> Security Class Initialized
DEBUG - 2017-03-08 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:25:25 --> Input Class Initialized
INFO - 2017-03-08 02:25:25 --> Language Class Initialized
INFO - 2017-03-08 02:25:25 --> Loader Class Initialized
INFO - 2017-03-08 02:25:25 --> Database Driver Class Initialized
INFO - 2017-03-08 02:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:25:25 --> Controller Class Initialized
INFO - 2017-03-08 02:25:25 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:25:26 --> Config Class Initialized
INFO - 2017-03-08 02:25:26 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:25:26 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:25:26 --> Utf8 Class Initialized
INFO - 2017-03-08 02:25:26 --> URI Class Initialized
INFO - 2017-03-08 02:25:26 --> Router Class Initialized
INFO - 2017-03-08 02:25:26 --> Output Class Initialized
INFO - 2017-03-08 02:25:26 --> Security Class Initialized
DEBUG - 2017-03-08 02:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:25:26 --> Input Class Initialized
INFO - 2017-03-08 02:25:26 --> Language Class Initialized
INFO - 2017-03-08 02:25:26 --> Loader Class Initialized
INFO - 2017-03-08 02:25:26 --> Database Driver Class Initialized
INFO - 2017-03-08 02:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:25:26 --> Controller Class Initialized
INFO - 2017-03-08 02:25:26 --> Helper loaded: date_helper
DEBUG - 2017-03-08 02:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:25:26 --> Helper loaded: url_helper
INFO - 2017-03-08 02:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 02:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 02:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 02:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:25:26 --> Final output sent to browser
DEBUG - 2017-03-08 02:25:26 --> Total execution time: 0.0133
INFO - 2017-03-08 02:25:27 --> Config Class Initialized
INFO - 2017-03-08 02:25:27 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:25:27 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:25:27 --> Utf8 Class Initialized
INFO - 2017-03-08 02:25:27 --> URI Class Initialized
INFO - 2017-03-08 02:25:27 --> Router Class Initialized
INFO - 2017-03-08 02:25:27 --> Output Class Initialized
INFO - 2017-03-08 02:25:27 --> Security Class Initialized
DEBUG - 2017-03-08 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:25:27 --> Input Class Initialized
INFO - 2017-03-08 02:25:27 --> Language Class Initialized
INFO - 2017-03-08 02:25:27 --> Loader Class Initialized
INFO - 2017-03-08 02:25:27 --> Database Driver Class Initialized
INFO - 2017-03-08 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:25:27 --> Controller Class Initialized
INFO - 2017-03-08 02:25:27 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 02:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 02:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:25:27 --> Final output sent to browser
DEBUG - 2017-03-08 02:25:27 --> Total execution time: 0.0130
INFO - 2017-03-08 02:37:19 --> Config Class Initialized
INFO - 2017-03-08 02:37:19 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:37:19 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:37:19 --> Utf8 Class Initialized
INFO - 2017-03-08 02:37:19 --> URI Class Initialized
INFO - 2017-03-08 02:37:19 --> Router Class Initialized
INFO - 2017-03-08 02:37:19 --> Output Class Initialized
INFO - 2017-03-08 02:37:19 --> Security Class Initialized
DEBUG - 2017-03-08 02:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:37:19 --> Input Class Initialized
INFO - 2017-03-08 02:37:19 --> Language Class Initialized
INFO - 2017-03-08 02:37:19 --> Loader Class Initialized
INFO - 2017-03-08 02:37:20 --> Database Driver Class Initialized
INFO - 2017-03-08 02:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:37:20 --> Controller Class Initialized
INFO - 2017-03-08 02:37:20 --> Helper loaded: date_helper
DEBUG - 2017-03-08 02:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:37:20 --> Helper loaded: url_helper
INFO - 2017-03-08 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 02:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:37:20 --> Final output sent to browser
DEBUG - 2017-03-08 02:37:20 --> Total execution time: 1.3505
INFO - 2017-03-08 02:37:22 --> Config Class Initialized
INFO - 2017-03-08 02:37:22 --> Hooks Class Initialized
DEBUG - 2017-03-08 02:37:22 --> UTF-8 Support Enabled
INFO - 2017-03-08 02:37:22 --> Utf8 Class Initialized
INFO - 2017-03-08 02:37:22 --> URI Class Initialized
INFO - 2017-03-08 02:37:22 --> Router Class Initialized
INFO - 2017-03-08 02:37:22 --> Output Class Initialized
INFO - 2017-03-08 02:37:22 --> Security Class Initialized
DEBUG - 2017-03-08 02:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 02:37:22 --> Input Class Initialized
INFO - 2017-03-08 02:37:22 --> Language Class Initialized
INFO - 2017-03-08 02:37:22 --> Loader Class Initialized
INFO - 2017-03-08 02:37:22 --> Database Driver Class Initialized
INFO - 2017-03-08 02:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 02:37:22 --> Controller Class Initialized
INFO - 2017-03-08 02:37:22 --> Helper loaded: url_helper
DEBUG - 2017-03-08 02:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 02:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 02:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 02:37:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 02:37:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 02:37:23 --> Final output sent to browser
DEBUG - 2017-03-08 02:37:23 --> Total execution time: 0.2469
INFO - 2017-03-08 04:32:37 --> Config Class Initialized
INFO - 2017-03-08 04:32:37 --> Hooks Class Initialized
DEBUG - 2017-03-08 04:32:37 --> UTF-8 Support Enabled
INFO - 2017-03-08 04:32:37 --> Utf8 Class Initialized
INFO - 2017-03-08 04:32:37 --> URI Class Initialized
DEBUG - 2017-03-08 04:32:37 --> No URI present. Default controller set.
INFO - 2017-03-08 04:32:37 --> Router Class Initialized
INFO - 2017-03-08 04:32:37 --> Output Class Initialized
INFO - 2017-03-08 04:32:37 --> Security Class Initialized
DEBUG - 2017-03-08 04:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 04:32:37 --> Input Class Initialized
INFO - 2017-03-08 04:32:37 --> Language Class Initialized
INFO - 2017-03-08 04:32:37 --> Loader Class Initialized
INFO - 2017-03-08 04:32:38 --> Database Driver Class Initialized
INFO - 2017-03-08 04:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 04:32:38 --> Controller Class Initialized
INFO - 2017-03-08 04:32:38 --> Helper loaded: url_helper
DEBUG - 2017-03-08 04:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 04:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 04:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 04:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 04:32:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 04:32:38 --> Final output sent to browser
DEBUG - 2017-03-08 04:32:38 --> Total execution time: 1.2187
INFO - 2017-03-08 04:33:59 --> Config Class Initialized
INFO - 2017-03-08 04:33:59 --> Hooks Class Initialized
DEBUG - 2017-03-08 04:33:59 --> UTF-8 Support Enabled
INFO - 2017-03-08 04:33:59 --> Utf8 Class Initialized
INFO - 2017-03-08 04:33:59 --> URI Class Initialized
INFO - 2017-03-08 04:34:00 --> Router Class Initialized
INFO - 2017-03-08 04:34:00 --> Output Class Initialized
INFO - 2017-03-08 04:34:00 --> Security Class Initialized
DEBUG - 2017-03-08 04:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 04:34:00 --> Input Class Initialized
INFO - 2017-03-08 04:34:00 --> Language Class Initialized
INFO - 2017-03-08 04:34:00 --> Loader Class Initialized
INFO - 2017-03-08 04:34:00 --> Database Driver Class Initialized
INFO - 2017-03-08 04:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 04:34:00 --> Controller Class Initialized
INFO - 2017-03-08 04:34:00 --> Helper loaded: url_helper
DEBUG - 2017-03-08 04:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 04:34:02 --> Config Class Initialized
INFO - 2017-03-08 04:34:02 --> Hooks Class Initialized
DEBUG - 2017-03-08 04:34:02 --> UTF-8 Support Enabled
INFO - 2017-03-08 04:34:02 --> Utf8 Class Initialized
INFO - 2017-03-08 04:34:02 --> URI Class Initialized
INFO - 2017-03-08 04:34:02 --> Router Class Initialized
INFO - 2017-03-08 04:34:02 --> Output Class Initialized
INFO - 2017-03-08 04:34:02 --> Security Class Initialized
DEBUG - 2017-03-08 04:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 04:34:02 --> Input Class Initialized
INFO - 2017-03-08 04:34:02 --> Language Class Initialized
INFO - 2017-03-08 04:34:02 --> Loader Class Initialized
INFO - 2017-03-08 04:34:02 --> Database Driver Class Initialized
INFO - 2017-03-08 04:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 04:34:02 --> Controller Class Initialized
INFO - 2017-03-08 04:34:02 --> Helper loaded: date_helper
DEBUG - 2017-03-08 04:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 04:34:02 --> Helper loaded: url_helper
INFO - 2017-03-08 04:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 04:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 04:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 04:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 04:34:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 04:34:02 --> Final output sent to browser
DEBUG - 2017-03-08 04:34:02 --> Total execution time: 0.1285
INFO - 2017-03-08 04:34:57 --> Config Class Initialized
INFO - 2017-03-08 04:34:57 --> Hooks Class Initialized
DEBUG - 2017-03-08 04:34:57 --> UTF-8 Support Enabled
INFO - 2017-03-08 04:34:57 --> Utf8 Class Initialized
INFO - 2017-03-08 04:34:57 --> URI Class Initialized
DEBUG - 2017-03-08 04:34:57 --> No URI present. Default controller set.
INFO - 2017-03-08 04:34:57 --> Router Class Initialized
INFO - 2017-03-08 04:34:57 --> Output Class Initialized
INFO - 2017-03-08 04:34:57 --> Security Class Initialized
DEBUG - 2017-03-08 04:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 04:34:57 --> Input Class Initialized
INFO - 2017-03-08 04:34:57 --> Language Class Initialized
INFO - 2017-03-08 04:34:58 --> Loader Class Initialized
INFO - 2017-03-08 04:34:58 --> Database Driver Class Initialized
INFO - 2017-03-08 04:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 04:34:58 --> Controller Class Initialized
INFO - 2017-03-08 04:34:58 --> Helper loaded: url_helper
DEBUG - 2017-03-08 04:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 04:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 04:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 04:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 04:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 04:34:58 --> Final output sent to browser
DEBUG - 2017-03-08 04:34:58 --> Total execution time: 1.5646
INFO - 2017-03-08 04:39:12 --> Config Class Initialized
INFO - 2017-03-08 04:39:12 --> Hooks Class Initialized
DEBUG - 2017-03-08 04:39:12 --> UTF-8 Support Enabled
INFO - 2017-03-08 04:39:12 --> Utf8 Class Initialized
INFO - 2017-03-08 04:39:12 --> URI Class Initialized
INFO - 2017-03-08 04:39:12 --> Router Class Initialized
INFO - 2017-03-08 04:39:12 --> Output Class Initialized
INFO - 2017-03-08 04:39:12 --> Security Class Initialized
DEBUG - 2017-03-08 04:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 04:39:12 --> Input Class Initialized
INFO - 2017-03-08 04:39:12 --> Language Class Initialized
INFO - 2017-03-08 04:39:12 --> Loader Class Initialized
INFO - 2017-03-08 04:39:12 --> Database Driver Class Initialized
INFO - 2017-03-08 04:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 04:39:13 --> Controller Class Initialized
INFO - 2017-03-08 04:39:13 --> Helper loaded: date_helper
DEBUG - 2017-03-08 04:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 04:39:13 --> Helper loaded: url_helper
INFO - 2017-03-08 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 04:39:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 04:39:13 --> Final output sent to browser
DEBUG - 2017-03-08 04:39:13 --> Total execution time: 1.1169
INFO - 2017-03-08 04:39:16 --> Config Class Initialized
INFO - 2017-03-08 04:39:16 --> Hooks Class Initialized
DEBUG - 2017-03-08 04:39:16 --> UTF-8 Support Enabled
INFO - 2017-03-08 04:39:16 --> Utf8 Class Initialized
INFO - 2017-03-08 04:39:16 --> URI Class Initialized
INFO - 2017-03-08 04:39:16 --> Router Class Initialized
INFO - 2017-03-08 04:39:16 --> Output Class Initialized
INFO - 2017-03-08 04:39:16 --> Security Class Initialized
DEBUG - 2017-03-08 04:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 04:39:16 --> Input Class Initialized
INFO - 2017-03-08 04:39:16 --> Language Class Initialized
INFO - 2017-03-08 04:39:16 --> Loader Class Initialized
INFO - 2017-03-08 04:39:16 --> Database Driver Class Initialized
INFO - 2017-03-08 04:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 04:39:16 --> Controller Class Initialized
INFO - 2017-03-08 04:39:16 --> Helper loaded: url_helper
DEBUG - 2017-03-08 04:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 04:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 04:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 04:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 04:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 04:39:17 --> Final output sent to browser
DEBUG - 2017-03-08 04:39:17 --> Total execution time: 1.5016
INFO - 2017-03-08 05:08:20 --> Config Class Initialized
INFO - 2017-03-08 05:08:20 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:08:20 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:08:20 --> Utf8 Class Initialized
INFO - 2017-03-08 05:08:20 --> URI Class Initialized
DEBUG - 2017-03-08 05:08:20 --> No URI present. Default controller set.
INFO - 2017-03-08 05:08:20 --> Router Class Initialized
INFO - 2017-03-08 05:08:20 --> Output Class Initialized
INFO - 2017-03-08 05:08:20 --> Security Class Initialized
DEBUG - 2017-03-08 05:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:08:20 --> Input Class Initialized
INFO - 2017-03-08 05:08:20 --> Language Class Initialized
INFO - 2017-03-08 05:08:20 --> Loader Class Initialized
INFO - 2017-03-08 05:08:20 --> Database Driver Class Initialized
INFO - 2017-03-08 05:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:08:20 --> Controller Class Initialized
INFO - 2017-03-08 05:08:20 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:08:21 --> Final output sent to browser
DEBUG - 2017-03-08 05:08:21 --> Total execution time: 1.2148
INFO - 2017-03-08 05:08:21 --> Config Class Initialized
INFO - 2017-03-08 05:08:21 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:08:21 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:08:21 --> Utf8 Class Initialized
INFO - 2017-03-08 05:08:21 --> URI Class Initialized
DEBUG - 2017-03-08 05:08:21 --> No URI present. Default controller set.
INFO - 2017-03-08 05:08:21 --> Router Class Initialized
INFO - 2017-03-08 05:08:21 --> Output Class Initialized
INFO - 2017-03-08 05:08:21 --> Security Class Initialized
DEBUG - 2017-03-08 05:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:08:21 --> Input Class Initialized
INFO - 2017-03-08 05:08:21 --> Language Class Initialized
INFO - 2017-03-08 05:08:21 --> Loader Class Initialized
INFO - 2017-03-08 05:08:21 --> Database Driver Class Initialized
INFO - 2017-03-08 05:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:08:21 --> Controller Class Initialized
INFO - 2017-03-08 05:08:21 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:08:21 --> Final output sent to browser
DEBUG - 2017-03-08 05:08:21 --> Total execution time: 0.0133
INFO - 2017-03-08 05:08:25 --> Config Class Initialized
INFO - 2017-03-08 05:08:25 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:08:25 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:08:25 --> Utf8 Class Initialized
INFO - 2017-03-08 05:08:25 --> URI Class Initialized
INFO - 2017-03-08 05:08:25 --> Router Class Initialized
INFO - 2017-03-08 05:08:25 --> Output Class Initialized
INFO - 2017-03-08 05:08:25 --> Security Class Initialized
DEBUG - 2017-03-08 05:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:08:25 --> Input Class Initialized
INFO - 2017-03-08 05:08:25 --> Language Class Initialized
INFO - 2017-03-08 05:08:25 --> Loader Class Initialized
INFO - 2017-03-08 05:08:26 --> Database Driver Class Initialized
INFO - 2017-03-08 05:08:26 --> Config Class Initialized
INFO - 2017-03-08 05:08:26 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:08:26 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:08:26 --> Utf8 Class Initialized
INFO - 2017-03-08 05:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:08:26 --> URI Class Initialized
INFO - 2017-03-08 05:08:26 --> Controller Class Initialized
INFO - 2017-03-08 05:08:26 --> Router Class Initialized
INFO - 2017-03-08 05:08:26 --> Helper loaded: url_helper
INFO - 2017-03-08 05:08:26 --> Output Class Initialized
INFO - 2017-03-08 05:08:26 --> Security Class Initialized
DEBUG - 2017-03-08 05:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-08 05:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:08:26 --> Input Class Initialized
INFO - 2017-03-08 05:08:26 --> Language Class Initialized
INFO - 2017-03-08 05:08:26 --> Loader Class Initialized
INFO - 2017-03-08 05:08:26 --> Database Driver Class Initialized
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:08:26 --> Final output sent to browser
DEBUG - 2017-03-08 05:08:26 --> Total execution time: 1.0027
INFO - 2017-03-08 05:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:08:26 --> Controller Class Initialized
INFO - 2017-03-08 05:08:26 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:08:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:08:26 --> Final output sent to browser
DEBUG - 2017-03-08 05:08:26 --> Total execution time: 0.6986
INFO - 2017-03-08 05:08:53 --> Config Class Initialized
INFO - 2017-03-08 05:08:53 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:08:53 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:08:53 --> Utf8 Class Initialized
INFO - 2017-03-08 05:08:53 --> URI Class Initialized
INFO - 2017-03-08 05:08:53 --> Router Class Initialized
INFO - 2017-03-08 05:08:53 --> Output Class Initialized
INFO - 2017-03-08 05:08:53 --> Security Class Initialized
DEBUG - 2017-03-08 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:08:53 --> Input Class Initialized
INFO - 2017-03-08 05:08:53 --> Language Class Initialized
INFO - 2017-03-08 05:08:53 --> Loader Class Initialized
INFO - 2017-03-08 05:08:53 --> Database Driver Class Initialized
INFO - 2017-03-08 05:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:08:53 --> Controller Class Initialized
INFO - 2017-03-08 05:08:53 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:08:56 --> Config Class Initialized
INFO - 2017-03-08 05:08:56 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:08:56 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:08:56 --> Utf8 Class Initialized
INFO - 2017-03-08 05:08:56 --> URI Class Initialized
INFO - 2017-03-08 05:08:56 --> Router Class Initialized
INFO - 2017-03-08 05:08:56 --> Output Class Initialized
INFO - 2017-03-08 05:08:56 --> Security Class Initialized
DEBUG - 2017-03-08 05:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:08:56 --> Input Class Initialized
INFO - 2017-03-08 05:08:56 --> Language Class Initialized
INFO - 2017-03-08 05:08:57 --> Loader Class Initialized
INFO - 2017-03-08 05:08:57 --> Database Driver Class Initialized
INFO - 2017-03-08 05:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:08:57 --> Controller Class Initialized
INFO - 2017-03-08 05:08:57 --> Helper loaded: date_helper
DEBUG - 2017-03-08 05:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:08:57 --> Helper loaded: url_helper
INFO - 2017-03-08 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 05:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:08:57 --> Final output sent to browser
DEBUG - 2017-03-08 05:08:57 --> Total execution time: 1.0605
INFO - 2017-03-08 05:08:58 --> Config Class Initialized
INFO - 2017-03-08 05:08:58 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:08:58 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:08:58 --> Utf8 Class Initialized
INFO - 2017-03-08 05:08:58 --> URI Class Initialized
INFO - 2017-03-08 05:08:58 --> Router Class Initialized
INFO - 2017-03-08 05:08:58 --> Output Class Initialized
INFO - 2017-03-08 05:08:58 --> Security Class Initialized
DEBUG - 2017-03-08 05:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:08:58 --> Input Class Initialized
INFO - 2017-03-08 05:08:58 --> Language Class Initialized
INFO - 2017-03-08 05:08:58 --> Loader Class Initialized
INFO - 2017-03-08 05:08:58 --> Database Driver Class Initialized
INFO - 2017-03-08 05:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:08:58 --> Controller Class Initialized
INFO - 2017-03-08 05:08:58 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:08:58 --> Final output sent to browser
DEBUG - 2017-03-08 05:08:58 --> Total execution time: 0.2660
INFO - 2017-03-08 05:09:08 --> Config Class Initialized
INFO - 2017-03-08 05:09:08 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:09:08 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:09:08 --> Utf8 Class Initialized
INFO - 2017-03-08 05:09:08 --> URI Class Initialized
DEBUG - 2017-03-08 05:09:08 --> No URI present. Default controller set.
INFO - 2017-03-08 05:09:08 --> Router Class Initialized
INFO - 2017-03-08 05:09:08 --> Output Class Initialized
INFO - 2017-03-08 05:09:08 --> Security Class Initialized
DEBUG - 2017-03-08 05:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:09:09 --> Input Class Initialized
INFO - 2017-03-08 05:09:09 --> Language Class Initialized
INFO - 2017-03-08 05:09:09 --> Loader Class Initialized
INFO - 2017-03-08 05:09:09 --> Database Driver Class Initialized
INFO - 2017-03-08 05:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:09:09 --> Controller Class Initialized
INFO - 2017-03-08 05:09:09 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:09:09 --> Final output sent to browser
DEBUG - 2017-03-08 05:09:09 --> Total execution time: 1.2274
INFO - 2017-03-08 05:09:11 --> Config Class Initialized
INFO - 2017-03-08 05:09:11 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:09:11 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:09:11 --> Utf8 Class Initialized
INFO - 2017-03-08 05:09:11 --> URI Class Initialized
INFO - 2017-03-08 05:09:11 --> Router Class Initialized
INFO - 2017-03-08 05:09:12 --> Output Class Initialized
INFO - 2017-03-08 05:09:12 --> Security Class Initialized
DEBUG - 2017-03-08 05:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:09:12 --> Input Class Initialized
INFO - 2017-03-08 05:09:12 --> Language Class Initialized
INFO - 2017-03-08 05:09:12 --> Loader Class Initialized
INFO - 2017-03-08 05:09:12 --> Database Driver Class Initialized
INFO - 2017-03-08 05:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:09:12 --> Controller Class Initialized
INFO - 2017-03-08 05:09:12 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:09:12 --> Final output sent to browser
DEBUG - 2017-03-08 05:09:12 --> Total execution time: 0.6372
INFO - 2017-03-08 05:38:31 --> Config Class Initialized
INFO - 2017-03-08 05:38:31 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:38:31 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:38:31 --> Utf8 Class Initialized
INFO - 2017-03-08 05:38:31 --> URI Class Initialized
INFO - 2017-03-08 05:38:31 --> Router Class Initialized
INFO - 2017-03-08 05:38:31 --> Output Class Initialized
INFO - 2017-03-08 05:38:31 --> Security Class Initialized
DEBUG - 2017-03-08 05:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:38:31 --> Input Class Initialized
INFO - 2017-03-08 05:38:31 --> Language Class Initialized
INFO - 2017-03-08 05:38:31 --> Loader Class Initialized
INFO - 2017-03-08 05:38:31 --> Database Driver Class Initialized
INFO - 2017-03-08 05:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:38:32 --> Controller Class Initialized
INFO - 2017-03-08 05:38:32 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:38:32 --> Final output sent to browser
DEBUG - 2017-03-08 05:38:32 --> Total execution time: 1.4823
INFO - 2017-03-08 05:38:32 --> Config Class Initialized
INFO - 2017-03-08 05:38:32 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:38:32 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:38:32 --> Utf8 Class Initialized
INFO - 2017-03-08 05:38:32 --> URI Class Initialized
DEBUG - 2017-03-08 05:38:32 --> No URI present. Default controller set.
INFO - 2017-03-08 05:38:32 --> Router Class Initialized
INFO - 2017-03-08 05:38:32 --> Output Class Initialized
INFO - 2017-03-08 05:38:32 --> Security Class Initialized
DEBUG - 2017-03-08 05:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:38:32 --> Input Class Initialized
INFO - 2017-03-08 05:38:32 --> Language Class Initialized
INFO - 2017-03-08 05:38:32 --> Loader Class Initialized
INFO - 2017-03-08 05:38:32 --> Database Driver Class Initialized
INFO - 2017-03-08 05:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:38:32 --> Controller Class Initialized
INFO - 2017-03-08 05:38:32 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:38:32 --> Final output sent to browser
DEBUG - 2017-03-08 05:38:32 --> Total execution time: 0.0145
INFO - 2017-03-08 05:38:34 --> Config Class Initialized
INFO - 2017-03-08 05:38:34 --> Hooks Class Initialized
DEBUG - 2017-03-08 05:38:34 --> UTF-8 Support Enabled
INFO - 2017-03-08 05:38:34 --> Utf8 Class Initialized
INFO - 2017-03-08 05:38:34 --> URI Class Initialized
INFO - 2017-03-08 05:38:34 --> Router Class Initialized
INFO - 2017-03-08 05:38:34 --> Output Class Initialized
INFO - 2017-03-08 05:38:34 --> Security Class Initialized
DEBUG - 2017-03-08 05:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 05:38:34 --> Input Class Initialized
INFO - 2017-03-08 05:38:34 --> Language Class Initialized
INFO - 2017-03-08 05:38:34 --> Loader Class Initialized
INFO - 2017-03-08 05:38:34 --> Database Driver Class Initialized
INFO - 2017-03-08 05:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 05:38:34 --> Controller Class Initialized
INFO - 2017-03-08 05:38:34 --> Helper loaded: url_helper
DEBUG - 2017-03-08 05:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 05:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 05:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 05:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 05:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 05:38:34 --> Final output sent to browser
DEBUG - 2017-03-08 05:38:34 --> Total execution time: 0.0130
INFO - 2017-03-08 11:11:18 --> Config Class Initialized
INFO - 2017-03-08 11:11:18 --> Hooks Class Initialized
DEBUG - 2017-03-08 11:11:18 --> UTF-8 Support Enabled
INFO - 2017-03-08 11:11:18 --> Utf8 Class Initialized
INFO - 2017-03-08 11:11:18 --> URI Class Initialized
INFO - 2017-03-08 11:11:18 --> Router Class Initialized
INFO - 2017-03-08 11:11:18 --> Output Class Initialized
INFO - 2017-03-08 11:11:18 --> Security Class Initialized
DEBUG - 2017-03-08 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 11:11:18 --> Input Class Initialized
INFO - 2017-03-08 11:11:18 --> Language Class Initialized
INFO - 2017-03-08 11:11:18 --> Loader Class Initialized
INFO - 2017-03-08 11:11:18 --> Database Driver Class Initialized
INFO - 2017-03-08 11:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 11:11:19 --> Controller Class Initialized
INFO - 2017-03-08 11:11:19 --> Helper loaded: url_helper
DEBUG - 2017-03-08 11:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 11:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 11:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 11:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 11:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 11:11:19 --> Final output sent to browser
DEBUG - 2017-03-08 11:11:19 --> Total execution time: 1.9263
INFO - 2017-03-08 11:11:46 --> Config Class Initialized
INFO - 2017-03-08 11:11:46 --> Hooks Class Initialized
DEBUG - 2017-03-08 11:11:46 --> UTF-8 Support Enabled
INFO - 2017-03-08 11:11:46 --> Utf8 Class Initialized
INFO - 2017-03-08 11:11:46 --> URI Class Initialized
DEBUG - 2017-03-08 11:11:46 --> No URI present. Default controller set.
INFO - 2017-03-08 11:11:46 --> Router Class Initialized
INFO - 2017-03-08 11:11:46 --> Output Class Initialized
INFO - 2017-03-08 11:11:46 --> Security Class Initialized
DEBUG - 2017-03-08 11:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 11:11:46 --> Input Class Initialized
INFO - 2017-03-08 11:11:46 --> Language Class Initialized
INFO - 2017-03-08 11:11:46 --> Loader Class Initialized
INFO - 2017-03-08 11:11:47 --> Database Driver Class Initialized
INFO - 2017-03-08 11:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 11:11:47 --> Controller Class Initialized
INFO - 2017-03-08 11:11:47 --> Helper loaded: url_helper
DEBUG - 2017-03-08 11:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 11:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 11:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 11:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 11:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 11:11:48 --> Final output sent to browser
DEBUG - 2017-03-08 11:11:48 --> Total execution time: 1.8843
INFO - 2017-03-08 12:24:22 --> Config Class Initialized
INFO - 2017-03-08 12:24:22 --> Hooks Class Initialized
DEBUG - 2017-03-08 12:24:22 --> UTF-8 Support Enabled
INFO - 2017-03-08 12:24:22 --> Utf8 Class Initialized
INFO - 2017-03-08 12:24:22 --> URI Class Initialized
INFO - 2017-03-08 12:24:22 --> Router Class Initialized
INFO - 2017-03-08 12:24:22 --> Output Class Initialized
INFO - 2017-03-08 12:24:22 --> Security Class Initialized
DEBUG - 2017-03-08 12:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 12:24:22 --> Input Class Initialized
INFO - 2017-03-08 12:24:22 --> Language Class Initialized
INFO - 2017-03-08 12:24:22 --> Loader Class Initialized
INFO - 2017-03-08 12:24:23 --> Database Driver Class Initialized
INFO - 2017-03-08 12:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 12:24:23 --> Controller Class Initialized
INFO - 2017-03-08 12:24:23 --> Helper loaded: url_helper
DEBUG - 2017-03-08 12:24:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 12:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 12:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 12:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 12:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 12:24:24 --> Final output sent to browser
DEBUG - 2017-03-08 12:24:24 --> Total execution time: 1.6226
INFO - 2017-03-08 12:24:34 --> Config Class Initialized
INFO - 2017-03-08 12:24:34 --> Hooks Class Initialized
DEBUG - 2017-03-08 12:24:34 --> UTF-8 Support Enabled
INFO - 2017-03-08 12:24:34 --> Utf8 Class Initialized
INFO - 2017-03-08 12:24:34 --> URI Class Initialized
DEBUG - 2017-03-08 12:24:34 --> No URI present. Default controller set.
INFO - 2017-03-08 12:24:34 --> Router Class Initialized
INFO - 2017-03-08 12:24:34 --> Output Class Initialized
INFO - 2017-03-08 12:24:34 --> Security Class Initialized
DEBUG - 2017-03-08 12:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 12:24:34 --> Input Class Initialized
INFO - 2017-03-08 12:24:34 --> Language Class Initialized
INFO - 2017-03-08 12:24:34 --> Loader Class Initialized
INFO - 2017-03-08 12:24:34 --> Database Driver Class Initialized
INFO - 2017-03-08 12:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 12:24:34 --> Controller Class Initialized
INFO - 2017-03-08 12:24:34 --> Helper loaded: url_helper
DEBUG - 2017-03-08 12:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 12:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 12:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 12:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 12:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 12:24:34 --> Final output sent to browser
DEBUG - 2017-03-08 12:24:34 --> Total execution time: 0.6435
INFO - 2017-03-08 15:17:59 --> Config Class Initialized
INFO - 2017-03-08 15:17:59 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:18:00 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:18:00 --> Utf8 Class Initialized
INFO - 2017-03-08 15:18:00 --> URI Class Initialized
DEBUG - 2017-03-08 15:18:00 --> No URI present. Default controller set.
INFO - 2017-03-08 15:18:00 --> Router Class Initialized
INFO - 2017-03-08 15:18:00 --> Output Class Initialized
INFO - 2017-03-08 15:18:00 --> Security Class Initialized
DEBUG - 2017-03-08 15:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:18:00 --> Input Class Initialized
INFO - 2017-03-08 15:18:00 --> Language Class Initialized
INFO - 2017-03-08 15:18:00 --> Loader Class Initialized
INFO - 2017-03-08 15:18:00 --> Database Driver Class Initialized
INFO - 2017-03-08 15:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:18:01 --> Controller Class Initialized
INFO - 2017-03-08 15:18:01 --> Helper loaded: url_helper
DEBUG - 2017-03-08 15:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 15:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 15:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 15:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 15:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 15:18:01 --> Final output sent to browser
DEBUG - 2017-03-08 15:18:01 --> Total execution time: 2.0994
INFO - 2017-03-08 15:18:24 --> Config Class Initialized
INFO - 2017-03-08 15:18:24 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:18:24 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:18:24 --> Utf8 Class Initialized
INFO - 2017-03-08 15:18:24 --> URI Class Initialized
INFO - 2017-03-08 15:18:24 --> Router Class Initialized
INFO - 2017-03-08 15:18:24 --> Output Class Initialized
INFO - 2017-03-08 15:18:24 --> Security Class Initialized
DEBUG - 2017-03-08 15:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:18:24 --> Input Class Initialized
INFO - 2017-03-08 15:18:24 --> Language Class Initialized
INFO - 2017-03-08 15:18:24 --> Loader Class Initialized
INFO - 2017-03-08 15:18:25 --> Database Driver Class Initialized
INFO - 2017-03-08 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:18:25 --> Controller Class Initialized
INFO - 2017-03-08 15:18:25 --> Helper loaded: url_helper
DEBUG - 2017-03-08 15:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 15:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 15:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 15:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 15:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 15:18:26 --> Final output sent to browser
DEBUG - 2017-03-08 15:18:26 --> Total execution time: 1.9995
INFO - 2017-03-08 15:30:10 --> Config Class Initialized
INFO - 2017-03-08 15:30:10 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:30:11 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:30:11 --> Utf8 Class Initialized
INFO - 2017-03-08 15:30:11 --> URI Class Initialized
DEBUG - 2017-03-08 15:30:11 --> No URI present. Default controller set.
INFO - 2017-03-08 15:30:11 --> Router Class Initialized
INFO - 2017-03-08 15:30:11 --> Output Class Initialized
INFO - 2017-03-08 15:30:11 --> Security Class Initialized
DEBUG - 2017-03-08 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:30:11 --> Input Class Initialized
INFO - 2017-03-08 15:30:11 --> Language Class Initialized
INFO - 2017-03-08 15:30:11 --> Loader Class Initialized
INFO - 2017-03-08 15:30:11 --> Database Driver Class Initialized
INFO - 2017-03-08 15:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:30:12 --> Controller Class Initialized
INFO - 2017-03-08 15:30:12 --> Helper loaded: url_helper
DEBUG - 2017-03-08 15:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 15:30:12 --> Final output sent to browser
DEBUG - 2017-03-08 15:30:12 --> Total execution time: 1.7690
INFO - 2017-03-08 15:30:16 --> Config Class Initialized
INFO - 2017-03-08 15:30:16 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:30:16 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:30:16 --> Utf8 Class Initialized
INFO - 2017-03-08 15:30:16 --> URI Class Initialized
INFO - 2017-03-08 15:30:16 --> Router Class Initialized
INFO - 2017-03-08 15:30:16 --> Output Class Initialized
INFO - 2017-03-08 15:30:16 --> Security Class Initialized
DEBUG - 2017-03-08 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:30:16 --> Input Class Initialized
INFO - 2017-03-08 15:30:16 --> Language Class Initialized
INFO - 2017-03-08 15:30:16 --> Loader Class Initialized
INFO - 2017-03-08 15:30:16 --> Database Driver Class Initialized
INFO - 2017-03-08 15:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:30:16 --> Controller Class Initialized
INFO - 2017-03-08 15:30:16 --> Helper loaded: url_helper
DEBUG - 2017-03-08 15:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 15:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 15:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 15:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 15:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 15:30:16 --> Final output sent to browser
DEBUG - 2017-03-08 15:30:16 --> Total execution time: 0.0142
INFO - 2017-03-08 15:42:44 --> Config Class Initialized
INFO - 2017-03-08 15:42:44 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:42:45 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:42:45 --> Utf8 Class Initialized
INFO - 2017-03-08 15:42:45 --> URI Class Initialized
INFO - 2017-03-08 15:42:45 --> Router Class Initialized
INFO - 2017-03-08 15:42:45 --> Output Class Initialized
INFO - 2017-03-08 15:42:45 --> Security Class Initialized
DEBUG - 2017-03-08 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:42:45 --> Input Class Initialized
INFO - 2017-03-08 15:42:45 --> Language Class Initialized
INFO - 2017-03-08 15:42:45 --> Loader Class Initialized
INFO - 2017-03-08 15:42:45 --> Database Driver Class Initialized
INFO - 2017-03-08 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:42:46 --> Controller Class Initialized
INFO - 2017-03-08 15:42:46 --> Helper loaded: url_helper
DEBUG - 2017-03-08 15:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 15:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-08 15:42:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-08 15:42:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-08 15:42:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-08 15:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 15:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 15:42:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 15:42:47 --> Final output sent to browser
DEBUG - 2017-03-08 15:42:47 --> Total execution time: 2.0604
INFO - 2017-03-08 16:15:41 --> Config Class Initialized
INFO - 2017-03-08 16:15:41 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:15:41 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:15:41 --> Utf8 Class Initialized
INFO - 2017-03-08 16:15:41 --> URI Class Initialized
DEBUG - 2017-03-08 16:15:41 --> No URI present. Default controller set.
INFO - 2017-03-08 16:15:41 --> Router Class Initialized
INFO - 2017-03-08 16:15:41 --> Output Class Initialized
INFO - 2017-03-08 16:15:41 --> Security Class Initialized
DEBUG - 2017-03-08 16:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:15:41 --> Input Class Initialized
INFO - 2017-03-08 16:15:41 --> Language Class Initialized
INFO - 2017-03-08 16:15:42 --> Loader Class Initialized
INFO - 2017-03-08 16:15:42 --> Database Driver Class Initialized
INFO - 2017-03-08 16:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:15:43 --> Controller Class Initialized
INFO - 2017-03-08 16:15:43 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 16:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 16:15:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 16:15:43 --> Final output sent to browser
DEBUG - 2017-03-08 16:15:43 --> Total execution time: 3.1040
INFO - 2017-03-08 16:15:52 --> Config Class Initialized
INFO - 2017-03-08 16:15:52 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:15:52 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:15:52 --> Utf8 Class Initialized
INFO - 2017-03-08 16:15:52 --> URI Class Initialized
INFO - 2017-03-08 16:15:52 --> Router Class Initialized
INFO - 2017-03-08 16:15:52 --> Output Class Initialized
INFO - 2017-03-08 16:15:52 --> Security Class Initialized
DEBUG - 2017-03-08 16:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:15:52 --> Input Class Initialized
INFO - 2017-03-08 16:15:52 --> Language Class Initialized
INFO - 2017-03-08 16:15:52 --> Loader Class Initialized
INFO - 2017-03-08 16:15:52 --> Database Driver Class Initialized
INFO - 2017-03-08 16:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:15:53 --> Controller Class Initialized
INFO - 2017-03-08 16:15:53 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 16:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 16:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 16:15:53 --> Final output sent to browser
DEBUG - 2017-03-08 16:15:53 --> Total execution time: 1.2006
INFO - 2017-03-08 16:25:07 --> Config Class Initialized
INFO - 2017-03-08 16:25:07 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:25:07 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:25:07 --> Utf8 Class Initialized
INFO - 2017-03-08 16:25:07 --> URI Class Initialized
DEBUG - 2017-03-08 16:25:08 --> No URI present. Default controller set.
INFO - 2017-03-08 16:25:08 --> Router Class Initialized
INFO - 2017-03-08 16:25:08 --> Output Class Initialized
INFO - 2017-03-08 16:25:08 --> Security Class Initialized
DEBUG - 2017-03-08 16:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:25:08 --> Input Class Initialized
INFO - 2017-03-08 16:25:08 --> Language Class Initialized
INFO - 2017-03-08 16:25:08 --> Loader Class Initialized
INFO - 2017-03-08 16:25:08 --> Database Driver Class Initialized
INFO - 2017-03-08 16:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:25:09 --> Controller Class Initialized
INFO - 2017-03-08 16:25:09 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 16:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 16:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 16:25:09 --> Final output sent to browser
DEBUG - 2017-03-08 16:25:09 --> Total execution time: 2.1156
INFO - 2017-03-08 16:25:22 --> Config Class Initialized
INFO - 2017-03-08 16:25:22 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:25:22 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:25:22 --> Utf8 Class Initialized
INFO - 2017-03-08 16:25:22 --> URI Class Initialized
INFO - 2017-03-08 16:25:22 --> Router Class Initialized
INFO - 2017-03-08 16:25:23 --> Output Class Initialized
INFO - 2017-03-08 16:25:23 --> Security Class Initialized
DEBUG - 2017-03-08 16:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:25:23 --> Input Class Initialized
INFO - 2017-03-08 16:25:23 --> Language Class Initialized
INFO - 2017-03-08 16:25:23 --> Loader Class Initialized
INFO - 2017-03-08 16:25:23 --> Database Driver Class Initialized
INFO - 2017-03-08 16:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:25:23 --> Controller Class Initialized
INFO - 2017-03-08 16:25:23 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:25:39 --> Config Class Initialized
INFO - 2017-03-08 16:25:40 --> Config Class Initialized
INFO - 2017-03-08 16:25:40 --> Hooks Class Initialized
INFO - 2017-03-08 16:25:40 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:25:40 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:25:40 --> Utf8 Class Initialized
DEBUG - 2017-03-08 16:25:40 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:25:40 --> URI Class Initialized
INFO - 2017-03-08 16:25:40 --> Utf8 Class Initialized
INFO - 2017-03-08 16:25:40 --> URI Class Initialized
INFO - 2017-03-08 16:25:40 --> Router Class Initialized
INFO - 2017-03-08 16:25:40 --> Router Class Initialized
INFO - 2017-03-08 16:25:40 --> Output Class Initialized
INFO - 2017-03-08 16:25:40 --> Output Class Initialized
INFO - 2017-03-08 16:25:40 --> Security Class Initialized
INFO - 2017-03-08 16:25:40 --> Security Class Initialized
DEBUG - 2017-03-08 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:25:40 --> Input Class Initialized
INFO - 2017-03-08 16:25:40 --> Language Class Initialized
DEBUG - 2017-03-08 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:25:40 --> Input Class Initialized
INFO - 2017-03-08 16:25:40 --> Language Class Initialized
INFO - 2017-03-08 16:25:40 --> Loader Class Initialized
INFO - 2017-03-08 16:25:40 --> Loader Class Initialized
INFO - 2017-03-08 16:25:41 --> Database Driver Class Initialized
INFO - 2017-03-08 16:25:41 --> Database Driver Class Initialized
INFO - 2017-03-08 16:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:25:41 --> Controller Class Initialized
INFO - 2017-03-08 16:25:41 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 16:25:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 16:25:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 16:25:42 --> Final output sent to browser
DEBUG - 2017-03-08 16:25:42 --> Total execution time: 2.2931
INFO - 2017-03-08 16:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:25:42 --> Controller Class Initialized
INFO - 2017-03-08 16:25:42 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:25:46 --> Config Class Initialized
INFO - 2017-03-08 16:25:46 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:25:46 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:25:46 --> Utf8 Class Initialized
INFO - 2017-03-08 16:25:46 --> URI Class Initialized
INFO - 2017-03-08 16:25:46 --> Router Class Initialized
INFO - 2017-03-08 16:25:47 --> Output Class Initialized
INFO - 2017-03-08 16:25:47 --> Security Class Initialized
DEBUG - 2017-03-08 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:25:47 --> Input Class Initialized
INFO - 2017-03-08 16:25:47 --> Language Class Initialized
INFO - 2017-03-08 16:25:47 --> Loader Class Initialized
INFO - 2017-03-08 16:25:47 --> Database Driver Class Initialized
INFO - 2017-03-08 16:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:25:47 --> Controller Class Initialized
INFO - 2017-03-08 16:25:47 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 16:25:48 --> Final output sent to browser
DEBUG - 2017-03-08 16:25:48 --> Total execution time: 1.7153
INFO - 2017-03-08 16:25:48 --> Config Class Initialized
INFO - 2017-03-08 16:25:48 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:25:48 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:25:48 --> Utf8 Class Initialized
INFO - 2017-03-08 16:25:48 --> URI Class Initialized
INFO - 2017-03-08 16:25:48 --> Router Class Initialized
INFO - 2017-03-08 16:25:48 --> Output Class Initialized
INFO - 2017-03-08 16:25:48 --> Security Class Initialized
DEBUG - 2017-03-08 16:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:25:48 --> Input Class Initialized
INFO - 2017-03-08 16:25:48 --> Language Class Initialized
INFO - 2017-03-08 16:25:48 --> Loader Class Initialized
INFO - 2017-03-08 16:25:48 --> Database Driver Class Initialized
INFO - 2017-03-08 16:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:25:48 --> Controller Class Initialized
INFO - 2017-03-08 16:25:48 --> Helper loaded: date_helper
DEBUG - 2017-03-08 16:25:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:25:48 --> Helper loaded: url_helper
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 16:25:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 16:25:48 --> Final output sent to browser
DEBUG - 2017-03-08 16:25:48 --> Total execution time: 0.1422
INFO - 2017-03-08 16:25:49 --> Config Class Initialized
INFO - 2017-03-08 16:25:49 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:25:49 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:25:49 --> Utf8 Class Initialized
INFO - 2017-03-08 16:25:49 --> URI Class Initialized
INFO - 2017-03-08 16:25:49 --> Router Class Initialized
INFO - 2017-03-08 16:25:49 --> Output Class Initialized
INFO - 2017-03-08 16:25:49 --> Security Class Initialized
DEBUG - 2017-03-08 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:25:49 --> Input Class Initialized
INFO - 2017-03-08 16:25:49 --> Language Class Initialized
INFO - 2017-03-08 16:25:49 --> Loader Class Initialized
INFO - 2017-03-08 16:25:49 --> Database Driver Class Initialized
INFO - 2017-03-08 16:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:25:49 --> Controller Class Initialized
INFO - 2017-03-08 16:25:49 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:25:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:25:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:25:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 16:25:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 16:25:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 16:25:49 --> Final output sent to browser
DEBUG - 2017-03-08 16:25:49 --> Total execution time: 0.0134
INFO - 2017-03-08 16:26:01 --> Config Class Initialized
INFO - 2017-03-08 16:26:01 --> Hooks Class Initialized
DEBUG - 2017-03-08 16:26:01 --> UTF-8 Support Enabled
INFO - 2017-03-08 16:26:01 --> Utf8 Class Initialized
INFO - 2017-03-08 16:26:01 --> URI Class Initialized
DEBUG - 2017-03-08 16:26:02 --> No URI present. Default controller set.
INFO - 2017-03-08 16:26:02 --> Router Class Initialized
INFO - 2017-03-08 16:26:02 --> Output Class Initialized
INFO - 2017-03-08 16:26:02 --> Security Class Initialized
DEBUG - 2017-03-08 16:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 16:26:02 --> Input Class Initialized
INFO - 2017-03-08 16:26:02 --> Language Class Initialized
INFO - 2017-03-08 16:26:02 --> Loader Class Initialized
INFO - 2017-03-08 16:26:02 --> Database Driver Class Initialized
INFO - 2017-03-08 16:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 16:26:03 --> Controller Class Initialized
INFO - 2017-03-08 16:26:03 --> Helper loaded: url_helper
DEBUG - 2017-03-08 16:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 16:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 16:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 16:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 16:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 19:59:29 --> Config Class Initialized
INFO - 2017-03-08 19:59:29 --> Hooks Class Initialized
DEBUG - 2017-03-08 19:59:29 --> UTF-8 Support Enabled
INFO - 2017-03-08 19:59:29 --> Utf8 Class Initialized
INFO - 2017-03-08 19:59:29 --> URI Class Initialized
DEBUG - 2017-03-08 19:59:29 --> No URI present. Default controller set.
INFO - 2017-03-08 19:59:29 --> Router Class Initialized
INFO - 2017-03-08 19:59:30 --> Output Class Initialized
INFO - 2017-03-08 19:59:30 --> Security Class Initialized
DEBUG - 2017-03-08 19:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 19:59:30 --> Input Class Initialized
INFO - 2017-03-08 19:59:30 --> Language Class Initialized
INFO - 2017-03-08 19:59:30 --> Loader Class Initialized
INFO - 2017-03-08 19:59:30 --> Database Driver Class Initialized
INFO - 2017-03-08 19:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 19:59:30 --> Controller Class Initialized
INFO - 2017-03-08 19:59:30 --> Helper loaded: url_helper
DEBUG - 2017-03-08 19:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 19:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 19:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 19:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 19:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 19:59:31 --> Final output sent to browser
DEBUG - 2017-03-08 19:59:31 --> Total execution time: 1.4843
INFO - 2017-03-08 21:27:35 --> Config Class Initialized
INFO - 2017-03-08 21:27:35 --> Hooks Class Initialized
DEBUG - 2017-03-08 21:27:35 --> UTF-8 Support Enabled
INFO - 2017-03-08 21:27:35 --> Utf8 Class Initialized
INFO - 2017-03-08 21:27:35 --> URI Class Initialized
DEBUG - 2017-03-08 21:27:35 --> No URI present. Default controller set.
INFO - 2017-03-08 21:27:35 --> Router Class Initialized
INFO - 2017-03-08 21:27:35 --> Output Class Initialized
INFO - 2017-03-08 21:27:35 --> Security Class Initialized
DEBUG - 2017-03-08 21:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 21:27:35 --> Input Class Initialized
INFO - 2017-03-08 21:27:35 --> Language Class Initialized
INFO - 2017-03-08 21:27:35 --> Loader Class Initialized
INFO - 2017-03-08 21:27:36 --> Database Driver Class Initialized
INFO - 2017-03-08 21:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 21:27:36 --> Controller Class Initialized
INFO - 2017-03-08 21:27:36 --> Helper loaded: url_helper
DEBUG - 2017-03-08 21:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 21:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 21:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 21:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 21:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 21:27:36 --> Final output sent to browser
DEBUG - 2017-03-08 21:27:36 --> Total execution time: 1.7412
INFO - 2017-03-08 21:36:20 --> Config Class Initialized
INFO - 2017-03-08 21:36:20 --> Hooks Class Initialized
DEBUG - 2017-03-08 21:36:21 --> UTF-8 Support Enabled
INFO - 2017-03-08 21:36:21 --> Utf8 Class Initialized
INFO - 2017-03-08 21:36:21 --> URI Class Initialized
DEBUG - 2017-03-08 21:36:21 --> No URI present. Default controller set.
INFO - 2017-03-08 21:36:21 --> Router Class Initialized
INFO - 2017-03-08 21:36:21 --> Output Class Initialized
INFO - 2017-03-08 21:36:21 --> Security Class Initialized
DEBUG - 2017-03-08 21:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 21:36:21 --> Input Class Initialized
INFO - 2017-03-08 21:36:21 --> Language Class Initialized
INFO - 2017-03-08 21:36:21 --> Loader Class Initialized
INFO - 2017-03-08 21:36:21 --> Database Driver Class Initialized
INFO - 2017-03-08 21:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 21:36:22 --> Controller Class Initialized
INFO - 2017-03-08 21:36:22 --> Helper loaded: url_helper
DEBUG - 2017-03-08 21:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 21:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 21:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 21:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 21:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 21:36:22 --> Final output sent to browser
DEBUG - 2017-03-08 21:36:22 --> Total execution time: 1.4629
INFO - 2017-03-08 21:36:39 --> Config Class Initialized
INFO - 2017-03-08 21:36:39 --> Hooks Class Initialized
DEBUG - 2017-03-08 21:36:39 --> UTF-8 Support Enabled
INFO - 2017-03-08 21:36:39 --> Utf8 Class Initialized
INFO - 2017-03-08 21:36:39 --> URI Class Initialized
INFO - 2017-03-08 21:36:39 --> Router Class Initialized
INFO - 2017-03-08 21:36:39 --> Output Class Initialized
INFO - 2017-03-08 21:36:39 --> Security Class Initialized
DEBUG - 2017-03-08 21:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 21:36:39 --> Input Class Initialized
INFO - 2017-03-08 21:36:39 --> Language Class Initialized
INFO - 2017-03-08 21:36:39 --> Loader Class Initialized
INFO - 2017-03-08 21:36:39 --> Database Driver Class Initialized
INFO - 2017-03-08 21:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 21:36:39 --> Controller Class Initialized
INFO - 2017-03-08 21:36:39 --> Helper loaded: url_helper
DEBUG - 2017-03-08 21:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 21:36:41 --> Config Class Initialized
INFO - 2017-03-08 21:36:41 --> Hooks Class Initialized
DEBUG - 2017-03-08 21:36:41 --> UTF-8 Support Enabled
INFO - 2017-03-08 21:36:41 --> Utf8 Class Initialized
INFO - 2017-03-08 21:36:41 --> URI Class Initialized
INFO - 2017-03-08 21:36:41 --> Router Class Initialized
INFO - 2017-03-08 21:36:41 --> Output Class Initialized
INFO - 2017-03-08 21:36:41 --> Security Class Initialized
DEBUG - 2017-03-08 21:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 21:36:41 --> Input Class Initialized
INFO - 2017-03-08 21:36:41 --> Language Class Initialized
INFO - 2017-03-08 21:36:42 --> Loader Class Initialized
INFO - 2017-03-08 21:36:42 --> Database Driver Class Initialized
INFO - 2017-03-08 21:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 21:36:42 --> Controller Class Initialized
INFO - 2017-03-08 21:36:42 --> Helper loaded: date_helper
DEBUG - 2017-03-08 21:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 21:36:42 --> Helper loaded: url_helper
INFO - 2017-03-08 21:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 21:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 21:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 21:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 21:36:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 21:36:42 --> Final output sent to browser
DEBUG - 2017-03-08 21:36:42 --> Total execution time: 0.1846
INFO - 2017-03-08 21:36:45 --> Config Class Initialized
INFO - 2017-03-08 21:36:45 --> Hooks Class Initialized
DEBUG - 2017-03-08 21:36:45 --> UTF-8 Support Enabled
INFO - 2017-03-08 21:36:45 --> Utf8 Class Initialized
INFO - 2017-03-08 21:36:45 --> URI Class Initialized
INFO - 2017-03-08 21:36:45 --> Router Class Initialized
INFO - 2017-03-08 21:36:45 --> Output Class Initialized
INFO - 2017-03-08 21:36:45 --> Security Class Initialized
DEBUG - 2017-03-08 21:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 21:36:45 --> Input Class Initialized
INFO - 2017-03-08 21:36:45 --> Language Class Initialized
INFO - 2017-03-08 21:36:45 --> Loader Class Initialized
INFO - 2017-03-08 21:36:45 --> Database Driver Class Initialized
INFO - 2017-03-08 21:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 21:36:45 --> Controller Class Initialized
INFO - 2017-03-08 21:36:45 --> Helper loaded: url_helper
DEBUG - 2017-03-08 21:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 21:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 21:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 21:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 21:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 21:36:45 --> Final output sent to browser
DEBUG - 2017-03-08 21:36:45 --> Total execution time: 0.1294
INFO - 2017-03-08 21:36:52 --> Config Class Initialized
INFO - 2017-03-08 21:36:52 --> Hooks Class Initialized
DEBUG - 2017-03-08 21:36:52 --> UTF-8 Support Enabled
INFO - 2017-03-08 21:36:52 --> Utf8 Class Initialized
INFO - 2017-03-08 21:36:52 --> URI Class Initialized
INFO - 2017-03-08 21:36:52 --> Router Class Initialized
INFO - 2017-03-08 21:36:52 --> Output Class Initialized
INFO - 2017-03-08 21:36:52 --> Security Class Initialized
DEBUG - 2017-03-08 21:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 21:36:52 --> Input Class Initialized
INFO - 2017-03-08 21:36:52 --> Language Class Initialized
INFO - 2017-03-08 21:36:52 --> Loader Class Initialized
INFO - 2017-03-08 21:36:52 --> Database Driver Class Initialized
INFO - 2017-03-08 21:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 21:36:52 --> Controller Class Initialized
INFO - 2017-03-08 21:36:52 --> Helper loaded: date_helper
DEBUG - 2017-03-08 21:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 21:36:52 --> Helper loaded: url_helper
INFO - 2017-03-08 21:36:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 21:36:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-08 21:36:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-08 21:36:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-08 21:36:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 21:36:52 --> Final output sent to browser
DEBUG - 2017-03-08 21:36:52 --> Total execution time: 0.0174
INFO - 2017-03-08 21:36:53 --> Config Class Initialized
INFO - 2017-03-08 21:36:53 --> Hooks Class Initialized
DEBUG - 2017-03-08 21:36:53 --> UTF-8 Support Enabled
INFO - 2017-03-08 21:36:53 --> Utf8 Class Initialized
INFO - 2017-03-08 21:36:53 --> URI Class Initialized
INFO - 2017-03-08 21:36:53 --> Router Class Initialized
INFO - 2017-03-08 21:36:53 --> Output Class Initialized
INFO - 2017-03-08 21:36:53 --> Security Class Initialized
DEBUG - 2017-03-08 21:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 21:36:53 --> Input Class Initialized
INFO - 2017-03-08 21:36:53 --> Language Class Initialized
INFO - 2017-03-08 21:36:53 --> Loader Class Initialized
INFO - 2017-03-08 21:36:53 --> Database Driver Class Initialized
INFO - 2017-03-08 21:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 21:36:53 --> Controller Class Initialized
INFO - 2017-03-08 21:36:53 --> Helper loaded: url_helper
DEBUG - 2017-03-08 21:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 21:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 21:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 21:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 21:36:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 21:36:53 --> Final output sent to browser
DEBUG - 2017-03-08 21:36:53 --> Total execution time: 0.0143
INFO - 2017-03-08 23:11:21 --> Config Class Initialized
INFO - 2017-03-08 23:11:21 --> Hooks Class Initialized
DEBUG - 2017-03-08 23:11:21 --> UTF-8 Support Enabled
INFO - 2017-03-08 23:11:21 --> Utf8 Class Initialized
INFO - 2017-03-08 23:11:21 --> URI Class Initialized
DEBUG - 2017-03-08 23:11:21 --> No URI present. Default controller set.
INFO - 2017-03-08 23:11:21 --> Router Class Initialized
INFO - 2017-03-08 23:11:21 --> Output Class Initialized
INFO - 2017-03-08 23:11:21 --> Security Class Initialized
DEBUG - 2017-03-08 23:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 23:11:21 --> Input Class Initialized
INFO - 2017-03-08 23:11:21 --> Language Class Initialized
INFO - 2017-03-08 23:11:21 --> Loader Class Initialized
INFO - 2017-03-08 23:11:21 --> Database Driver Class Initialized
INFO - 2017-03-08 23:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 23:11:22 --> Controller Class Initialized
INFO - 2017-03-08 23:11:22 --> Helper loaded: url_helper
DEBUG - 2017-03-08 23:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 23:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 23:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 23:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 23:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 23:11:22 --> Final output sent to browser
DEBUG - 2017-03-08 23:11:22 --> Total execution time: 1.5554
INFO - 2017-03-08 23:11:53 --> Config Class Initialized
INFO - 2017-03-08 23:11:53 --> Hooks Class Initialized
DEBUG - 2017-03-08 23:11:53 --> UTF-8 Support Enabled
INFO - 2017-03-08 23:11:53 --> Utf8 Class Initialized
INFO - 2017-03-08 23:11:53 --> URI Class Initialized
INFO - 2017-03-08 23:11:54 --> Router Class Initialized
INFO - 2017-03-08 23:11:54 --> Output Class Initialized
INFO - 2017-03-08 23:11:54 --> Security Class Initialized
DEBUG - 2017-03-08 23:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 23:11:54 --> Input Class Initialized
INFO - 2017-03-08 23:11:54 --> Language Class Initialized
INFO - 2017-03-08 23:11:54 --> Loader Class Initialized
INFO - 2017-03-08 23:11:54 --> Database Driver Class Initialized
INFO - 2017-03-08 23:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 23:11:54 --> Controller Class Initialized
INFO - 2017-03-08 23:11:54 --> Helper loaded: url_helper
DEBUG - 2017-03-08 23:11:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-08 23:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-08 23:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-08 23:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-08 23:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-08 23:11:55 --> Final output sent to browser
DEBUG - 2017-03-08 23:11:55 --> Total execution time: 1.3548

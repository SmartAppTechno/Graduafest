<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-04 15:59:27 --> Config Class Initialized
INFO - 2016-12-04 15:59:27 --> Hooks Class Initialized
DEBUG - 2016-12-04 15:59:27 --> UTF-8 Support Enabled
INFO - 2016-12-04 15:59:27 --> Utf8 Class Initialized
INFO - 2016-12-04 15:59:27 --> URI Class Initialized
INFO - 2016-12-04 15:59:27 --> Router Class Initialized
INFO - 2016-12-04 15:59:27 --> Output Class Initialized
INFO - 2016-12-04 15:59:27 --> Security Class Initialized
DEBUG - 2016-12-04 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-04 15:59:27 --> Input Class Initialized
INFO - 2016-12-04 15:59:27 --> Language Class Initialized
INFO - 2016-12-04 15:59:28 --> Loader Class Initialized
INFO - 2016-12-04 15:59:28 --> Database Driver Class Initialized
INFO - 2016-12-04 15:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-04 15:59:28 --> Controller Class Initialized
INFO - 2016-12-04 15:59:28 --> Helper loaded: url_helper
DEBUG - 2016-12-04 15:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-04 15:59:28 --> Final output sent to browser
DEBUG - 2016-12-04 15:59:28 --> Total execution time: 1.1317
INFO - 2016-12-04 15:59:28 --> Config Class Initialized
INFO - 2016-12-04 15:59:28 --> Hooks Class Initialized
DEBUG - 2016-12-04 15:59:28 --> UTF-8 Support Enabled
INFO - 2016-12-04 15:59:28 --> Utf8 Class Initialized
INFO - 2016-12-04 15:59:28 --> URI Class Initialized
DEBUG - 2016-12-04 15:59:28 --> No URI present. Default controller set.
INFO - 2016-12-04 15:59:28 --> Router Class Initialized
INFO - 2016-12-04 15:59:28 --> Output Class Initialized
INFO - 2016-12-04 15:59:28 --> Security Class Initialized
DEBUG - 2016-12-04 15:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-04 15:59:28 --> Input Class Initialized
INFO - 2016-12-04 15:59:28 --> Language Class Initialized
INFO - 2016-12-04 15:59:28 --> Loader Class Initialized
INFO - 2016-12-04 15:59:28 --> Database Driver Class Initialized
INFO - 2016-12-04 15:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-04 15:59:28 --> Controller Class Initialized
INFO - 2016-12-04 15:59:28 --> Helper loaded: url_helper
DEBUG - 2016-12-04 15:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-04 15:59:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-04 15:59:28 --> Final output sent to browser
DEBUG - 2016-12-04 15:59:28 --> Total execution time: 0.0137

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-22 01:10:08 --> Config Class Initialized
INFO - 2016-12-22 01:10:08 --> Hooks Class Initialized
DEBUG - 2016-12-22 01:10:08 --> UTF-8 Support Enabled
INFO - 2016-12-22 01:10:08 --> Utf8 Class Initialized
INFO - 2016-12-22 01:10:08 --> URI Class Initialized
DEBUG - 2016-12-22 01:10:08 --> No URI present. Default controller set.
INFO - 2016-12-22 01:10:08 --> Router Class Initialized
INFO - 2016-12-22 01:10:08 --> Output Class Initialized
INFO - 2016-12-22 01:10:08 --> Security Class Initialized
DEBUG - 2016-12-22 01:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 01:10:08 --> Input Class Initialized
INFO - 2016-12-22 01:10:08 --> Language Class Initialized
INFO - 2016-12-22 01:10:08 --> Loader Class Initialized
INFO - 2016-12-22 01:10:09 --> Database Driver Class Initialized
INFO - 2016-12-22 01:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 01:10:09 --> Controller Class Initialized
INFO - 2016-12-22 01:10:09 --> Helper loaded: url_helper
DEBUG - 2016-12-22 01:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 01:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 01:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 01:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 01:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 01:10:10 --> Final output sent to browser
DEBUG - 2016-12-22 01:10:10 --> Total execution time: 2.3863
INFO - 2016-12-22 13:55:09 --> Config Class Initialized
INFO - 2016-12-22 13:55:09 --> Hooks Class Initialized
DEBUG - 2016-12-22 13:55:09 --> UTF-8 Support Enabled
INFO - 2016-12-22 13:55:09 --> Utf8 Class Initialized
INFO - 2016-12-22 13:55:09 --> URI Class Initialized
DEBUG - 2016-12-22 13:55:09 --> No URI present. Default controller set.
INFO - 2016-12-22 13:55:09 --> Router Class Initialized
INFO - 2016-12-22 13:55:09 --> Output Class Initialized
INFO - 2016-12-22 13:55:09 --> Security Class Initialized
DEBUG - 2016-12-22 13:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 13:55:09 --> Input Class Initialized
INFO - 2016-12-22 13:55:09 --> Language Class Initialized
INFO - 2016-12-22 13:55:09 --> Loader Class Initialized
INFO - 2016-12-22 13:55:09 --> Database Driver Class Initialized
INFO - 2016-12-22 13:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 13:55:09 --> Controller Class Initialized
INFO - 2016-12-22 13:55:09 --> Helper loaded: url_helper
DEBUG - 2016-12-22 13:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 13:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 13:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 13:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 13:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 13:55:10 --> Final output sent to browser
DEBUG - 2016-12-22 13:55:10 --> Total execution time: 1.5627
INFO - 2016-12-22 16:58:39 --> Config Class Initialized
INFO - 2016-12-22 16:58:39 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:39 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:39 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:39 --> URI Class Initialized
DEBUG - 2016-12-22 16:58:39 --> No URI present. Default controller set.
INFO - 2016-12-22 16:58:39 --> Router Class Initialized
INFO - 2016-12-22 16:58:39 --> Output Class Initialized
INFO - 2016-12-22 16:58:39 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:39 --> Input Class Initialized
INFO - 2016-12-22 16:58:39 --> Language Class Initialized
INFO - 2016-12-22 16:58:39 --> Loader Class Initialized
INFO - 2016-12-22 16:58:39 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:40 --> Controller Class Initialized
INFO - 2016-12-22 16:58:40 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:40 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:40 --> Total execution time: 0.2764
INFO - 2016-12-22 16:58:40 --> Config Class Initialized
INFO - 2016-12-22 16:58:40 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:40 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:40 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:40 --> URI Class Initialized
INFO - 2016-12-22 16:58:40 --> Router Class Initialized
INFO - 2016-12-22 16:58:40 --> Output Class Initialized
INFO - 2016-12-22 16:58:40 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:40 --> Input Class Initialized
INFO - 2016-12-22 16:58:40 --> Language Class Initialized
INFO - 2016-12-22 16:58:40 --> Loader Class Initialized
INFO - 2016-12-22 16:58:40 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:40 --> Controller Class Initialized
INFO - 2016-12-22 16:58:40 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:40 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:40 --> Total execution time: 0.0683
INFO - 2016-12-22 16:58:40 --> Config Class Initialized
INFO - 2016-12-22 16:58:40 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:40 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:40 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:40 --> URI Class Initialized
INFO - 2016-12-22 16:58:40 --> Router Class Initialized
INFO - 2016-12-22 16:58:40 --> Output Class Initialized
INFO - 2016-12-22 16:58:40 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:40 --> Input Class Initialized
INFO - 2016-12-22 16:58:40 --> Language Class Initialized
INFO - 2016-12-22 16:58:40 --> Loader Class Initialized
INFO - 2016-12-22 16:58:40 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:40 --> Controller Class Initialized
INFO - 2016-12-22 16:58:40 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:40 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:40 --> Total execution time: 0.0141
INFO - 2016-12-22 16:58:41 --> Config Class Initialized
INFO - 2016-12-22 16:58:41 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:41 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:41 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:41 --> URI Class Initialized
INFO - 2016-12-22 16:58:41 --> Router Class Initialized
INFO - 2016-12-22 16:58:41 --> Output Class Initialized
INFO - 2016-12-22 16:58:41 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:41 --> Input Class Initialized
INFO - 2016-12-22 16:58:41 --> Language Class Initialized
INFO - 2016-12-22 16:58:41 --> Loader Class Initialized
INFO - 2016-12-22 16:58:41 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:41 --> Controller Class Initialized
INFO - 2016-12-22 16:58:41 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:41 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:41 --> Total execution time: 0.0141
INFO - 2016-12-22 16:58:41 --> Config Class Initialized
INFO - 2016-12-22 16:58:41 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:41 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:41 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:41 --> URI Class Initialized
INFO - 2016-12-22 16:58:41 --> Router Class Initialized
INFO - 2016-12-22 16:58:41 --> Output Class Initialized
INFO - 2016-12-22 16:58:41 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:41 --> Input Class Initialized
INFO - 2016-12-22 16:58:41 --> Language Class Initialized
INFO - 2016-12-22 16:58:41 --> Loader Class Initialized
INFO - 2016-12-22 16:58:41 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:41 --> Controller Class Initialized
INFO - 2016-12-22 16:58:41 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:41 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:41 --> Total execution time: 0.0665
INFO - 2016-12-22 16:58:41 --> Config Class Initialized
INFO - 2016-12-22 16:58:41 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:41 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:41 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:41 --> URI Class Initialized
INFO - 2016-12-22 16:58:41 --> Router Class Initialized
INFO - 2016-12-22 16:58:41 --> Output Class Initialized
INFO - 2016-12-22 16:58:41 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:41 --> Input Class Initialized
INFO - 2016-12-22 16:58:41 --> Language Class Initialized
INFO - 2016-12-22 16:58:41 --> Loader Class Initialized
INFO - 2016-12-22 16:58:41 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:41 --> Controller Class Initialized
INFO - 2016-12-22 16:58:41 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:41 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:41 --> Total execution time: 0.0141
INFO - 2016-12-22 16:58:41 --> Config Class Initialized
INFO - 2016-12-22 16:58:41 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:41 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:41 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:41 --> URI Class Initialized
INFO - 2016-12-22 16:58:41 --> Router Class Initialized
INFO - 2016-12-22 16:58:41 --> Output Class Initialized
INFO - 2016-12-22 16:58:41 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:41 --> Input Class Initialized
INFO - 2016-12-22 16:58:41 --> Language Class Initialized
INFO - 2016-12-22 16:58:41 --> Loader Class Initialized
INFO - 2016-12-22 16:58:41 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:41 --> Controller Class Initialized
INFO - 2016-12-22 16:58:41 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:42 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:42 --> Total execution time: 0.3052
INFO - 2016-12-22 16:58:42 --> Config Class Initialized
INFO - 2016-12-22 16:58:42 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:42 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:42 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:42 --> URI Class Initialized
DEBUG - 2016-12-22 16:58:42 --> No URI present. Default controller set.
INFO - 2016-12-22 16:58:42 --> Router Class Initialized
INFO - 2016-12-22 16:58:42 --> Output Class Initialized
INFO - 2016-12-22 16:58:42 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:42 --> Input Class Initialized
INFO - 2016-12-22 16:58:42 --> Language Class Initialized
INFO - 2016-12-22 16:58:42 --> Loader Class Initialized
INFO - 2016-12-22 16:58:42 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:42 --> Controller Class Initialized
INFO - 2016-12-22 16:58:42 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:42 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:42 --> Total execution time: 0.0141
INFO - 2016-12-22 16:58:42 --> Config Class Initialized
INFO - 2016-12-22 16:58:42 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:42 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:42 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:42 --> URI Class Initialized
INFO - 2016-12-22 16:58:42 --> Router Class Initialized
INFO - 2016-12-22 16:58:42 --> Output Class Initialized
INFO - 2016-12-22 16:58:42 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:42 --> Input Class Initialized
INFO - 2016-12-22 16:58:42 --> Language Class Initialized
INFO - 2016-12-22 16:58:42 --> Loader Class Initialized
INFO - 2016-12-22 16:58:42 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:42 --> Controller Class Initialized
INFO - 2016-12-22 16:58:42 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:42 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:42 --> Total execution time: 0.0169
INFO - 2016-12-22 16:58:43 --> Config Class Initialized
INFO - 2016-12-22 16:58:43 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:43 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:43 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:43 --> URI Class Initialized
INFO - 2016-12-22 16:58:43 --> Router Class Initialized
INFO - 2016-12-22 16:58:43 --> Output Class Initialized
INFO - 2016-12-22 16:58:43 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:43 --> Input Class Initialized
INFO - 2016-12-22 16:58:43 --> Language Class Initialized
INFO - 2016-12-22 16:58:43 --> Loader Class Initialized
INFO - 2016-12-22 16:58:43 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:43 --> Controller Class Initialized
INFO - 2016-12-22 16:58:43 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:43 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:43 --> Total execution time: 0.0699
INFO - 2016-12-22 16:58:43 --> Config Class Initialized
INFO - 2016-12-22 16:58:43 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:43 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:43 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:43 --> URI Class Initialized
INFO - 2016-12-22 16:58:43 --> Router Class Initialized
INFO - 2016-12-22 16:58:43 --> Output Class Initialized
INFO - 2016-12-22 16:58:43 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:43 --> Input Class Initialized
INFO - 2016-12-22 16:58:43 --> Language Class Initialized
INFO - 2016-12-22 16:58:43 --> Loader Class Initialized
INFO - 2016-12-22 16:58:43 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:43 --> Controller Class Initialized
INFO - 2016-12-22 16:58:43 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:43 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:43 --> Total execution time: 0.0155
INFO - 2016-12-22 16:58:43 --> Config Class Initialized
INFO - 2016-12-22 16:58:43 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:43 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:43 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:43 --> URI Class Initialized
INFO - 2016-12-22 16:58:43 --> Router Class Initialized
INFO - 2016-12-22 16:58:43 --> Output Class Initialized
INFO - 2016-12-22 16:58:43 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:43 --> Input Class Initialized
INFO - 2016-12-22 16:58:43 --> Language Class Initialized
INFO - 2016-12-22 16:58:43 --> Loader Class Initialized
INFO - 2016-12-22 16:58:43 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:43 --> Controller Class Initialized
INFO - 2016-12-22 16:58:43 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:43 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:43 --> Total execution time: 0.0714
INFO - 2016-12-22 16:58:44 --> Config Class Initialized
INFO - 2016-12-22 16:58:44 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:44 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:44 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:44 --> URI Class Initialized
INFO - 2016-12-22 16:58:44 --> Router Class Initialized
INFO - 2016-12-22 16:58:44 --> Output Class Initialized
INFO - 2016-12-22 16:58:44 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:44 --> Input Class Initialized
INFO - 2016-12-22 16:58:44 --> Language Class Initialized
INFO - 2016-12-22 16:58:44 --> Loader Class Initialized
INFO - 2016-12-22 16:58:44 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:44 --> Controller Class Initialized
INFO - 2016-12-22 16:58:44 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:44 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:44 --> Total execution time: 0.0143
INFO - 2016-12-22 16:58:44 --> Config Class Initialized
INFO - 2016-12-22 16:58:44 --> Hooks Class Initialized
DEBUG - 2016-12-22 16:58:44 --> UTF-8 Support Enabled
INFO - 2016-12-22 16:58:44 --> Utf8 Class Initialized
INFO - 2016-12-22 16:58:44 --> URI Class Initialized
INFO - 2016-12-22 16:58:44 --> Router Class Initialized
INFO - 2016-12-22 16:58:44 --> Output Class Initialized
INFO - 2016-12-22 16:58:44 --> Security Class Initialized
DEBUG - 2016-12-22 16:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 16:58:44 --> Input Class Initialized
INFO - 2016-12-22 16:58:44 --> Language Class Initialized
INFO - 2016-12-22 16:58:44 --> Loader Class Initialized
INFO - 2016-12-22 16:58:44 --> Database Driver Class Initialized
INFO - 2016-12-22 16:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 16:58:44 --> Controller Class Initialized
INFO - 2016-12-22 16:58:44 --> Helper loaded: url_helper
DEBUG - 2016-12-22 16:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 16:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 16:58:44 --> Final output sent to browser
DEBUG - 2016-12-22 16:58:44 --> Total execution time: 0.0145
INFO - 2016-12-22 17:13:42 --> Config Class Initialized
INFO - 2016-12-22 17:13:42 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:42 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:42 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:42 --> URI Class Initialized
DEBUG - 2016-12-22 17:13:42 --> No URI present. Default controller set.
INFO - 2016-12-22 17:13:42 --> Router Class Initialized
INFO - 2016-12-22 17:13:42 --> Output Class Initialized
INFO - 2016-12-22 17:13:42 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:42 --> Input Class Initialized
INFO - 2016-12-22 17:13:42 --> Language Class Initialized
INFO - 2016-12-22 17:13:42 --> Loader Class Initialized
INFO - 2016-12-22 17:13:42 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:42 --> Controller Class Initialized
INFO - 2016-12-22 17:13:42 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:42 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:42 --> Total execution time: 0.0168
INFO - 2016-12-22 17:13:43 --> Config Class Initialized
INFO - 2016-12-22 17:13:43 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:43 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:43 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:43 --> URI Class Initialized
INFO - 2016-12-22 17:13:43 --> Router Class Initialized
INFO - 2016-12-22 17:13:43 --> Output Class Initialized
INFO - 2016-12-22 17:13:43 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:43 --> Input Class Initialized
INFO - 2016-12-22 17:13:43 --> Language Class Initialized
INFO - 2016-12-22 17:13:43 --> Loader Class Initialized
INFO - 2016-12-22 17:13:43 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:43 --> Controller Class Initialized
INFO - 2016-12-22 17:13:43 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:43 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:43 --> Total execution time: 0.0145
INFO - 2016-12-22 17:13:43 --> Config Class Initialized
INFO - 2016-12-22 17:13:43 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:43 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:43 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:43 --> URI Class Initialized
INFO - 2016-12-22 17:13:43 --> Router Class Initialized
INFO - 2016-12-22 17:13:43 --> Output Class Initialized
INFO - 2016-12-22 17:13:43 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:43 --> Input Class Initialized
INFO - 2016-12-22 17:13:43 --> Language Class Initialized
INFO - 2016-12-22 17:13:43 --> Loader Class Initialized
INFO - 2016-12-22 17:13:43 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:43 --> Controller Class Initialized
INFO - 2016-12-22 17:13:43 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:43 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:43 --> Total execution time: 0.0367
INFO - 2016-12-22 17:13:43 --> Config Class Initialized
INFO - 2016-12-22 17:13:43 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:43 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:43 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:43 --> URI Class Initialized
INFO - 2016-12-22 17:13:43 --> Router Class Initialized
INFO - 2016-12-22 17:13:43 --> Output Class Initialized
INFO - 2016-12-22 17:13:43 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:43 --> Input Class Initialized
INFO - 2016-12-22 17:13:43 --> Language Class Initialized
INFO - 2016-12-22 17:13:43 --> Loader Class Initialized
INFO - 2016-12-22 17:13:43 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:43 --> Controller Class Initialized
INFO - 2016-12-22 17:13:43 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:43 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:43 --> Total execution time: 0.0144
INFO - 2016-12-22 17:13:44 --> Config Class Initialized
INFO - 2016-12-22 17:13:44 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:44 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:44 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:44 --> URI Class Initialized
INFO - 2016-12-22 17:13:44 --> Router Class Initialized
INFO - 2016-12-22 17:13:44 --> Output Class Initialized
INFO - 2016-12-22 17:13:44 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:44 --> Input Class Initialized
INFO - 2016-12-22 17:13:44 --> Language Class Initialized
INFO - 2016-12-22 17:13:44 --> Loader Class Initialized
INFO - 2016-12-22 17:13:44 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:44 --> Controller Class Initialized
INFO - 2016-12-22 17:13:44 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:44 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:44 --> Total execution time: 0.0151
INFO - 2016-12-22 17:13:44 --> Config Class Initialized
INFO - 2016-12-22 17:13:44 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:44 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:44 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:44 --> URI Class Initialized
INFO - 2016-12-22 17:13:44 --> Router Class Initialized
INFO - 2016-12-22 17:13:44 --> Output Class Initialized
INFO - 2016-12-22 17:13:44 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:44 --> Input Class Initialized
INFO - 2016-12-22 17:13:44 --> Language Class Initialized
INFO - 2016-12-22 17:13:44 --> Loader Class Initialized
INFO - 2016-12-22 17:13:44 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:44 --> Controller Class Initialized
INFO - 2016-12-22 17:13:44 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:44 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:44 --> Total execution time: 0.0175
INFO - 2016-12-22 17:13:44 --> Config Class Initialized
INFO - 2016-12-22 17:13:44 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:44 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:44 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:44 --> URI Class Initialized
INFO - 2016-12-22 17:13:44 --> Router Class Initialized
INFO - 2016-12-22 17:13:44 --> Output Class Initialized
INFO - 2016-12-22 17:13:44 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:44 --> Input Class Initialized
INFO - 2016-12-22 17:13:44 --> Language Class Initialized
INFO - 2016-12-22 17:13:44 --> Loader Class Initialized
INFO - 2016-12-22 17:13:44 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:44 --> Controller Class Initialized
INFO - 2016-12-22 17:13:44 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:44 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:44 --> Total execution time: 0.0148
INFO - 2016-12-22 17:13:44 --> Config Class Initialized
INFO - 2016-12-22 17:13:44 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:44 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:44 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:44 --> URI Class Initialized
DEBUG - 2016-12-22 17:13:44 --> No URI present. Default controller set.
INFO - 2016-12-22 17:13:44 --> Router Class Initialized
INFO - 2016-12-22 17:13:44 --> Output Class Initialized
INFO - 2016-12-22 17:13:44 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:44 --> Input Class Initialized
INFO - 2016-12-22 17:13:44 --> Language Class Initialized
INFO - 2016-12-22 17:13:44 --> Loader Class Initialized
INFO - 2016-12-22 17:13:44 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:44 --> Controller Class Initialized
INFO - 2016-12-22 17:13:44 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:44 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:44 --> Total execution time: 0.0336
INFO - 2016-12-22 17:13:45 --> Config Class Initialized
INFO - 2016-12-22 17:13:45 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:45 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:45 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:45 --> URI Class Initialized
INFO - 2016-12-22 17:13:45 --> Router Class Initialized
INFO - 2016-12-22 17:13:45 --> Output Class Initialized
INFO - 2016-12-22 17:13:45 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:45 --> Input Class Initialized
INFO - 2016-12-22 17:13:45 --> Language Class Initialized
INFO - 2016-12-22 17:13:45 --> Loader Class Initialized
INFO - 2016-12-22 17:13:45 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:45 --> Controller Class Initialized
INFO - 2016-12-22 17:13:45 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:45 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:45 --> Total execution time: 0.0551
INFO - 2016-12-22 17:13:45 --> Config Class Initialized
INFO - 2016-12-22 17:13:45 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:45 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:45 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:45 --> URI Class Initialized
INFO - 2016-12-22 17:13:45 --> Router Class Initialized
INFO - 2016-12-22 17:13:45 --> Output Class Initialized
INFO - 2016-12-22 17:13:45 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:45 --> Input Class Initialized
INFO - 2016-12-22 17:13:45 --> Language Class Initialized
INFO - 2016-12-22 17:13:45 --> Loader Class Initialized
INFO - 2016-12-22 17:13:45 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:45 --> Controller Class Initialized
INFO - 2016-12-22 17:13:45 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:45 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:45 --> Total execution time: 0.0133
INFO - 2016-12-22 17:13:45 --> Config Class Initialized
INFO - 2016-12-22 17:13:45 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:45 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:45 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:45 --> URI Class Initialized
INFO - 2016-12-22 17:13:45 --> Router Class Initialized
INFO - 2016-12-22 17:13:45 --> Output Class Initialized
INFO - 2016-12-22 17:13:45 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:45 --> Input Class Initialized
INFO - 2016-12-22 17:13:45 --> Language Class Initialized
INFO - 2016-12-22 17:13:45 --> Loader Class Initialized
INFO - 2016-12-22 17:13:45 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:45 --> Controller Class Initialized
INFO - 2016-12-22 17:13:45 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:45 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:45 --> Total execution time: 0.0137
INFO - 2016-12-22 17:13:45 --> Config Class Initialized
INFO - 2016-12-22 17:13:45 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:45 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:45 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:45 --> URI Class Initialized
INFO - 2016-12-22 17:13:45 --> Router Class Initialized
INFO - 2016-12-22 17:13:45 --> Output Class Initialized
INFO - 2016-12-22 17:13:45 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:45 --> Input Class Initialized
INFO - 2016-12-22 17:13:45 --> Language Class Initialized
INFO - 2016-12-22 17:13:45 --> Loader Class Initialized
INFO - 2016-12-22 17:13:45 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:45 --> Controller Class Initialized
INFO - 2016-12-22 17:13:45 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:45 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:45 --> Total execution time: 0.0211
INFO - 2016-12-22 17:13:46 --> Config Class Initialized
INFO - 2016-12-22 17:13:46 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:46 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:46 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:46 --> URI Class Initialized
INFO - 2016-12-22 17:13:46 --> Router Class Initialized
INFO - 2016-12-22 17:13:46 --> Output Class Initialized
INFO - 2016-12-22 17:13:46 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:46 --> Input Class Initialized
INFO - 2016-12-22 17:13:46 --> Language Class Initialized
INFO - 2016-12-22 17:13:46 --> Loader Class Initialized
INFO - 2016-12-22 17:13:46 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:46 --> Controller Class Initialized
INFO - 2016-12-22 17:13:46 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:46 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:46 --> Total execution time: 0.0139
INFO - 2016-12-22 17:13:46 --> Config Class Initialized
INFO - 2016-12-22 17:13:46 --> Hooks Class Initialized
DEBUG - 2016-12-22 17:13:46 --> UTF-8 Support Enabled
INFO - 2016-12-22 17:13:46 --> Utf8 Class Initialized
INFO - 2016-12-22 17:13:46 --> URI Class Initialized
INFO - 2016-12-22 17:13:46 --> Router Class Initialized
INFO - 2016-12-22 17:13:46 --> Output Class Initialized
INFO - 2016-12-22 17:13:46 --> Security Class Initialized
DEBUG - 2016-12-22 17:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-22 17:13:46 --> Input Class Initialized
INFO - 2016-12-22 17:13:46 --> Language Class Initialized
INFO - 2016-12-22 17:13:46 --> Loader Class Initialized
INFO - 2016-12-22 17:13:46 --> Database Driver Class Initialized
INFO - 2016-12-22 17:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-22 17:13:46 --> Controller Class Initialized
INFO - 2016-12-22 17:13:46 --> Helper loaded: url_helper
DEBUG - 2016-12-22 17:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-22 17:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-22 17:13:46 --> Final output sent to browser
DEBUG - 2016-12-22 17:13:46 --> Total execution time: 0.0144

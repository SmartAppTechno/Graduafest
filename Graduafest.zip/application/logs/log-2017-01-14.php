<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-14 00:01:43 --> Config Class Initialized
INFO - 2017-01-14 00:01:43 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:01:43 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:01:43 --> Utf8 Class Initialized
INFO - 2017-01-14 00:01:43 --> URI Class Initialized
INFO - 2017-01-14 00:01:43 --> Router Class Initialized
INFO - 2017-01-14 00:01:43 --> Output Class Initialized
INFO - 2017-01-14 00:01:43 --> Security Class Initialized
DEBUG - 2017-01-14 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:01:43 --> Input Class Initialized
INFO - 2017-01-14 00:01:43 --> Language Class Initialized
INFO - 2017-01-14 00:01:43 --> Loader Class Initialized
INFO - 2017-01-14 00:01:43 --> Database Driver Class Initialized
INFO - 2017-01-14 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:01:43 --> Controller Class Initialized
INFO - 2017-01-14 00:01:43 --> Helper loaded: date_helper
INFO - 2017-01-14 00:01:43 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:01:43 --> Helper loaded: form_helper
INFO - 2017-01-14 00:01:43 --> Form Validation Class Initialized
INFO - 2017-01-14 00:01:43 --> Final output sent to browser
DEBUG - 2017-01-14 00:01:43 --> Total execution time: 0.0138
INFO - 2017-01-14 00:01:43 --> Config Class Initialized
INFO - 2017-01-14 00:01:43 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:01:43 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:01:43 --> Utf8 Class Initialized
INFO - 2017-01-14 00:01:43 --> URI Class Initialized
INFO - 2017-01-14 00:01:43 --> Router Class Initialized
INFO - 2017-01-14 00:01:43 --> Output Class Initialized
INFO - 2017-01-14 00:01:43 --> Security Class Initialized
DEBUG - 2017-01-14 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:01:43 --> Input Class Initialized
INFO - 2017-01-14 00:01:43 --> Language Class Initialized
INFO - 2017-01-14 00:01:43 --> Loader Class Initialized
INFO - 2017-01-14 00:01:43 --> Database Driver Class Initialized
INFO - 2017-01-14 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:01:43 --> Controller Class Initialized
INFO - 2017-01-14 00:01:43 --> Helper loaded: date_helper
INFO - 2017-01-14 00:01:43 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:01:43 --> Helper loaded: form_helper
INFO - 2017-01-14 00:01:43 --> Form Validation Class Initialized
INFO - 2017-01-14 00:01:43 --> Final output sent to browser
DEBUG - 2017-01-14 00:01:43 --> Total execution time: 0.0150
INFO - 2017-01-14 00:03:33 --> Config Class Initialized
INFO - 2017-01-14 00:03:33 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:03:33 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:03:33 --> Utf8 Class Initialized
INFO - 2017-01-14 00:03:33 --> URI Class Initialized
INFO - 2017-01-14 00:03:33 --> Router Class Initialized
INFO - 2017-01-14 00:03:33 --> Output Class Initialized
INFO - 2017-01-14 00:03:33 --> Security Class Initialized
DEBUG - 2017-01-14 00:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:03:33 --> Input Class Initialized
INFO - 2017-01-14 00:03:33 --> Language Class Initialized
INFO - 2017-01-14 00:03:33 --> Loader Class Initialized
INFO - 2017-01-14 00:03:33 --> Database Driver Class Initialized
INFO - 2017-01-14 00:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:03:33 --> Controller Class Initialized
INFO - 2017-01-14 00:03:33 --> Helper loaded: date_helper
DEBUG - 2017-01-14 00:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:03:33 --> Helper loaded: url_helper
INFO - 2017-01-14 00:03:33 --> Helper loaded: download_helper
INFO - 2017-01-14 00:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 00:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-14 00:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-14 00:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-14 00:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 00:03:33 --> Final output sent to browser
DEBUG - 2017-01-14 00:03:33 --> Total execution time: 0.0180
INFO - 2017-01-14 00:04:40 --> Config Class Initialized
INFO - 2017-01-14 00:04:40 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:40 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:40 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:40 --> URI Class Initialized
INFO - 2017-01-14 00:04:40 --> Router Class Initialized
INFO - 2017-01-14 00:04:40 --> Output Class Initialized
INFO - 2017-01-14 00:04:40 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:40 --> Input Class Initialized
INFO - 2017-01-14 00:04:40 --> Language Class Initialized
INFO - 2017-01-14 00:04:40 --> Loader Class Initialized
INFO - 2017-01-14 00:04:40 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:40 --> Controller Class Initialized
INFO - 2017-01-14 00:04:40 --> Upload Class Initialized
INFO - 2017-01-14 00:04:40 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:40 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:40 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:40 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-14 00:04:40 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:40 --> Total execution time: 0.0162
INFO - 2017-01-14 00:04:40 --> Config Class Initialized
INFO - 2017-01-14 00:04:40 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:40 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:40 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:40 --> URI Class Initialized
INFO - 2017-01-14 00:04:40 --> Router Class Initialized
INFO - 2017-01-14 00:04:40 --> Output Class Initialized
INFO - 2017-01-14 00:04:40 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:40 --> Input Class Initialized
INFO - 2017-01-14 00:04:40 --> Language Class Initialized
INFO - 2017-01-14 00:04:40 --> Loader Class Initialized
INFO - 2017-01-14 00:04:40 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:40 --> Controller Class Initialized
INFO - 2017-01-14 00:04:40 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 00:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 00:04:40 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:40 --> Total execution time: 0.0135
INFO - 2017-01-14 00:04:41 --> Config Class Initialized
INFO - 2017-01-14 00:04:41 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:41 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:41 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:41 --> URI Class Initialized
INFO - 2017-01-14 00:04:41 --> Router Class Initialized
INFO - 2017-01-14 00:04:41 --> Output Class Initialized
INFO - 2017-01-14 00:04:41 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:41 --> Input Class Initialized
INFO - 2017-01-14 00:04:41 --> Language Class Initialized
INFO - 2017-01-14 00:04:41 --> Loader Class Initialized
INFO - 2017-01-14 00:04:41 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:41 --> Controller Class Initialized
INFO - 2017-01-14 00:04:41 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:41 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:41 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:41 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-14 00:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-14 00:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-14 00:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-14 00:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-14 00:04:41 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:41 --> Total execution time: 0.0148
INFO - 2017-01-14 00:04:42 --> Config Class Initialized
INFO - 2017-01-14 00:04:42 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:42 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:42 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:42 --> URI Class Initialized
INFO - 2017-01-14 00:04:42 --> Router Class Initialized
INFO - 2017-01-14 00:04:42 --> Output Class Initialized
INFO - 2017-01-14 00:04:42 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:42 --> Input Class Initialized
INFO - 2017-01-14 00:04:42 --> Language Class Initialized
INFO - 2017-01-14 00:04:42 --> Loader Class Initialized
INFO - 2017-01-14 00:04:42 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:42 --> Controller Class Initialized
INFO - 2017-01-14 00:04:42 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:42 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:42 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:42 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:42 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:42 --> Total execution time: 0.0142
INFO - 2017-01-14 00:04:42 --> Config Class Initialized
INFO - 2017-01-14 00:04:42 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:42 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:42 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:42 --> URI Class Initialized
INFO - 2017-01-14 00:04:42 --> Router Class Initialized
INFO - 2017-01-14 00:04:42 --> Output Class Initialized
INFO - 2017-01-14 00:04:42 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:42 --> Input Class Initialized
INFO - 2017-01-14 00:04:42 --> Language Class Initialized
INFO - 2017-01-14 00:04:42 --> Loader Class Initialized
INFO - 2017-01-14 00:04:42 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:42 --> Controller Class Initialized
INFO - 2017-01-14 00:04:42 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 00:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 00:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 00:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 00:04:42 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:42 --> Total execution time: 0.0143
INFO - 2017-01-14 00:04:44 --> Config Class Initialized
INFO - 2017-01-14 00:04:44 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:44 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:44 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:44 --> URI Class Initialized
INFO - 2017-01-14 00:04:44 --> Router Class Initialized
INFO - 2017-01-14 00:04:44 --> Output Class Initialized
INFO - 2017-01-14 00:04:44 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:44 --> Input Class Initialized
INFO - 2017-01-14 00:04:44 --> Language Class Initialized
INFO - 2017-01-14 00:04:44 --> Loader Class Initialized
INFO - 2017-01-14 00:04:44 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:44 --> Controller Class Initialized
INFO - 2017-01-14 00:04:44 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:44 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:44 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:44 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:44 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:44 --> Total execution time: 0.0680
INFO - 2017-01-14 00:04:51 --> Config Class Initialized
INFO - 2017-01-14 00:04:51 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:51 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:51 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:51 --> URI Class Initialized
INFO - 2017-01-14 00:04:51 --> Router Class Initialized
INFO - 2017-01-14 00:04:51 --> Output Class Initialized
INFO - 2017-01-14 00:04:51 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:51 --> Input Class Initialized
INFO - 2017-01-14 00:04:51 --> Language Class Initialized
INFO - 2017-01-14 00:04:51 --> Loader Class Initialized
INFO - 2017-01-14 00:04:51 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:51 --> Controller Class Initialized
INFO - 2017-01-14 00:04:51 --> Upload Class Initialized
INFO - 2017-01-14 00:04:51 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:51 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:51 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:51 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-14 00:04:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-14 00:04:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-14 00:04:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-14 00:04:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-14 00:04:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-14 00:04:51 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:51 --> Total execution time: 0.0160
INFO - 2017-01-14 00:04:52 --> Config Class Initialized
INFO - 2017-01-14 00:04:52 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:52 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:52 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:52 --> URI Class Initialized
INFO - 2017-01-14 00:04:52 --> Router Class Initialized
INFO - 2017-01-14 00:04:52 --> Output Class Initialized
INFO - 2017-01-14 00:04:52 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:52 --> Input Class Initialized
INFO - 2017-01-14 00:04:52 --> Language Class Initialized
INFO - 2017-01-14 00:04:52 --> Loader Class Initialized
INFO - 2017-01-14 00:04:52 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:52 --> Controller Class Initialized
INFO - 2017-01-14 00:04:52 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 00:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 00:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 00:04:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 00:04:52 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:52 --> Total execution time: 0.0139
INFO - 2017-01-14 00:04:53 --> Config Class Initialized
INFO - 2017-01-14 00:04:53 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:53 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:53 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:53 --> URI Class Initialized
INFO - 2017-01-14 00:04:53 --> Router Class Initialized
INFO - 2017-01-14 00:04:53 --> Output Class Initialized
INFO - 2017-01-14 00:04:53 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:53 --> Input Class Initialized
INFO - 2017-01-14 00:04:53 --> Language Class Initialized
INFO - 2017-01-14 00:04:53 --> Loader Class Initialized
INFO - 2017-01-14 00:04:53 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:53 --> Controller Class Initialized
INFO - 2017-01-14 00:04:53 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:53 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:53 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:53 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-14 00:04:53 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:53 --> Total execution time: 0.0149
INFO - 2017-01-14 00:04:53 --> Config Class Initialized
INFO - 2017-01-14 00:04:53 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:53 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:53 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:53 --> URI Class Initialized
INFO - 2017-01-14 00:04:53 --> Router Class Initialized
INFO - 2017-01-14 00:04:53 --> Output Class Initialized
INFO - 2017-01-14 00:04:53 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:53 --> Input Class Initialized
INFO - 2017-01-14 00:04:53 --> Language Class Initialized
INFO - 2017-01-14 00:04:53 --> Loader Class Initialized
INFO - 2017-01-14 00:04:53 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:53 --> Controller Class Initialized
INFO - 2017-01-14 00:04:53 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:53 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:53 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:53 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:53 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:53 --> Total execution time: 0.0144
INFO - 2017-01-14 00:04:53 --> Config Class Initialized
INFO - 2017-01-14 00:04:53 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:53 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:53 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:53 --> URI Class Initialized
INFO - 2017-01-14 00:04:53 --> Router Class Initialized
INFO - 2017-01-14 00:04:53 --> Output Class Initialized
INFO - 2017-01-14 00:04:53 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:53 --> Input Class Initialized
INFO - 2017-01-14 00:04:53 --> Language Class Initialized
INFO - 2017-01-14 00:04:53 --> Loader Class Initialized
INFO - 2017-01-14 00:04:53 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:53 --> Controller Class Initialized
INFO - 2017-01-14 00:04:53 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 00:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 00:04:53 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:53 --> Total execution time: 0.0366
INFO - 2017-01-14 00:04:55 --> Config Class Initialized
INFO - 2017-01-14 00:04:55 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:55 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:55 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:55 --> URI Class Initialized
INFO - 2017-01-14 00:04:55 --> Router Class Initialized
INFO - 2017-01-14 00:04:55 --> Output Class Initialized
INFO - 2017-01-14 00:04:55 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:55 --> Input Class Initialized
INFO - 2017-01-14 00:04:55 --> Language Class Initialized
INFO - 2017-01-14 00:04:55 --> Loader Class Initialized
INFO - 2017-01-14 00:04:55 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:55 --> Controller Class Initialized
INFO - 2017-01-14 00:04:55 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:55 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:55 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:55 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:55 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:55 --> Total execution time: 0.0652
INFO - 2017-01-14 00:04:57 --> Config Class Initialized
INFO - 2017-01-14 00:04:57 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:04:57 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:04:57 --> Utf8 Class Initialized
INFO - 2017-01-14 00:04:57 --> URI Class Initialized
INFO - 2017-01-14 00:04:57 --> Router Class Initialized
INFO - 2017-01-14 00:04:57 --> Output Class Initialized
INFO - 2017-01-14 00:04:57 --> Security Class Initialized
DEBUG - 2017-01-14 00:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:04:57 --> Input Class Initialized
INFO - 2017-01-14 00:04:57 --> Language Class Initialized
INFO - 2017-01-14 00:04:57 --> Loader Class Initialized
INFO - 2017-01-14 00:04:57 --> Database Driver Class Initialized
INFO - 2017-01-14 00:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:04:57 --> Controller Class Initialized
INFO - 2017-01-14 00:04:57 --> Helper loaded: date_helper
INFO - 2017-01-14 00:04:57 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:04:57 --> Helper loaded: form_helper
INFO - 2017-01-14 00:04:57 --> Form Validation Class Initialized
INFO - 2017-01-14 00:04:57 --> Final output sent to browser
DEBUG - 2017-01-14 00:04:57 --> Total execution time: 0.0149
INFO - 2017-01-14 00:05:01 --> Config Class Initialized
INFO - 2017-01-14 00:05:01 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:01 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:01 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:01 --> URI Class Initialized
INFO - 2017-01-14 00:05:01 --> Router Class Initialized
INFO - 2017-01-14 00:05:01 --> Output Class Initialized
INFO - 2017-01-14 00:05:01 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:01 --> Input Class Initialized
INFO - 2017-01-14 00:05:01 --> Language Class Initialized
INFO - 2017-01-14 00:05:01 --> Loader Class Initialized
INFO - 2017-01-14 00:05:01 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:01 --> Controller Class Initialized
INFO - 2017-01-14 00:05:01 --> Helper loaded: date_helper
INFO - 2017-01-14 00:05:01 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:01 --> Helper loaded: form_helper
INFO - 2017-01-14 00:05:01 --> Form Validation Class Initialized
INFO - 2017-01-14 00:05:01 --> Final output sent to browser
DEBUG - 2017-01-14 00:05:01 --> Total execution time: 0.0258
INFO - 2017-01-14 00:05:03 --> Config Class Initialized
INFO - 2017-01-14 00:05:03 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:03 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:03 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:03 --> URI Class Initialized
INFO - 2017-01-14 00:05:03 --> Router Class Initialized
INFO - 2017-01-14 00:05:03 --> Output Class Initialized
INFO - 2017-01-14 00:05:03 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:03 --> Input Class Initialized
INFO - 2017-01-14 00:05:03 --> Language Class Initialized
INFO - 2017-01-14 00:05:03 --> Loader Class Initialized
INFO - 2017-01-14 00:05:03 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:03 --> Controller Class Initialized
INFO - 2017-01-14 00:05:03 --> Helper loaded: date_helper
INFO - 2017-01-14 00:05:03 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:03 --> Helper loaded: form_helper
INFO - 2017-01-14 00:05:03 --> Form Validation Class Initialized
INFO - 2017-01-14 00:05:03 --> Final output sent to browser
DEBUG - 2017-01-14 00:05:03 --> Total execution time: 0.0144
INFO - 2017-01-14 00:05:08 --> Config Class Initialized
INFO - 2017-01-14 00:05:08 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:08 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:08 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:08 --> URI Class Initialized
INFO - 2017-01-14 00:05:08 --> Router Class Initialized
INFO - 2017-01-14 00:05:08 --> Output Class Initialized
INFO - 2017-01-14 00:05:08 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:08 --> Input Class Initialized
INFO - 2017-01-14 00:05:08 --> Language Class Initialized
INFO - 2017-01-14 00:05:08 --> Loader Class Initialized
INFO - 2017-01-14 00:05:08 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:08 --> Controller Class Initialized
INFO - 2017-01-14 00:05:08 --> Helper loaded: date_helper
INFO - 2017-01-14 00:05:08 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:08 --> Helper loaded: form_helper
INFO - 2017-01-14 00:05:08 --> Form Validation Class Initialized
INFO - 2017-01-14 00:05:08 --> Final output sent to browser
DEBUG - 2017-01-14 00:05:08 --> Total execution time: 0.0146
INFO - 2017-01-14 00:05:08 --> Config Class Initialized
INFO - 2017-01-14 00:05:08 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:08 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:08 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:08 --> URI Class Initialized
INFO - 2017-01-14 00:05:08 --> Router Class Initialized
INFO - 2017-01-14 00:05:08 --> Output Class Initialized
INFO - 2017-01-14 00:05:08 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:08 --> Input Class Initialized
INFO - 2017-01-14 00:05:08 --> Language Class Initialized
INFO - 2017-01-14 00:05:08 --> Loader Class Initialized
INFO - 2017-01-14 00:05:08 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:08 --> Controller Class Initialized
INFO - 2017-01-14 00:05:08 --> Helper loaded: date_helper
INFO - 2017-01-14 00:05:08 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:08 --> Helper loaded: form_helper
INFO - 2017-01-14 00:05:08 --> Form Validation Class Initialized
INFO - 2017-01-14 00:05:08 --> Final output sent to browser
DEBUG - 2017-01-14 00:05:08 --> Total execution time: 0.0147
INFO - 2017-01-14 00:05:11 --> Config Class Initialized
INFO - 2017-01-14 00:05:11 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:11 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:11 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:11 --> URI Class Initialized
INFO - 2017-01-14 00:05:11 --> Router Class Initialized
INFO - 2017-01-14 00:05:11 --> Output Class Initialized
INFO - 2017-01-14 00:05:11 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:11 --> Input Class Initialized
INFO - 2017-01-14 00:05:11 --> Language Class Initialized
INFO - 2017-01-14 00:05:11 --> Loader Class Initialized
INFO - 2017-01-14 00:05:11 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:11 --> Controller Class Initialized
INFO - 2017-01-14 00:05:11 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:11 --> Config Class Initialized
INFO - 2017-01-14 00:05:11 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:11 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:11 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:11 --> URI Class Initialized
INFO - 2017-01-14 00:05:11 --> Router Class Initialized
INFO - 2017-01-14 00:05:11 --> Output Class Initialized
INFO - 2017-01-14 00:05:11 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:11 --> Input Class Initialized
INFO - 2017-01-14 00:05:11 --> Language Class Initialized
INFO - 2017-01-14 00:05:11 --> Loader Class Initialized
INFO - 2017-01-14 00:05:11 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:11 --> Controller Class Initialized
INFO - 2017-01-14 00:05:11 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:11 --> Helper loaded: form_helper
INFO - 2017-01-14 00:05:11 --> Form Validation Class Initialized
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-14 00:05:11 --> Final output sent to browser
DEBUG - 2017-01-14 00:05:11 --> Total execution time: 0.0138
INFO - 2017-01-14 00:05:11 --> Config Class Initialized
INFO - 2017-01-14 00:05:11 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:11 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:11 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:11 --> URI Class Initialized
INFO - 2017-01-14 00:05:11 --> Router Class Initialized
INFO - 2017-01-14 00:05:11 --> Output Class Initialized
INFO - 2017-01-14 00:05:11 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:11 --> Input Class Initialized
INFO - 2017-01-14 00:05:11 --> Language Class Initialized
INFO - 2017-01-14 00:05:11 --> Loader Class Initialized
INFO - 2017-01-14 00:05:11 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:11 --> Controller Class Initialized
INFO - 2017-01-14 00:05:11 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 00:05:11 --> Final output sent to browser
DEBUG - 2017-01-14 00:05:11 --> Total execution time: 0.0133
INFO - 2017-01-14 00:05:11 --> Config Class Initialized
INFO - 2017-01-14 00:05:11 --> Hooks Class Initialized
DEBUG - 2017-01-14 00:05:11 --> UTF-8 Support Enabled
INFO - 2017-01-14 00:05:11 --> Utf8 Class Initialized
INFO - 2017-01-14 00:05:11 --> URI Class Initialized
INFO - 2017-01-14 00:05:11 --> Router Class Initialized
INFO - 2017-01-14 00:05:11 --> Output Class Initialized
INFO - 2017-01-14 00:05:11 --> Security Class Initialized
DEBUG - 2017-01-14 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 00:05:11 --> Input Class Initialized
INFO - 2017-01-14 00:05:11 --> Language Class Initialized
INFO - 2017-01-14 00:05:11 --> Loader Class Initialized
INFO - 2017-01-14 00:05:11 --> Database Driver Class Initialized
INFO - 2017-01-14 00:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 00:05:11 --> Controller Class Initialized
INFO - 2017-01-14 00:05:11 --> Helper loaded: url_helper
DEBUG - 2017-01-14 00:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 00:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 00:05:11 --> Final output sent to browser
DEBUG - 2017-01-14 00:05:11 --> Total execution time: 0.0147
INFO - 2017-01-14 01:16:30 --> Config Class Initialized
INFO - 2017-01-14 01:16:30 --> Hooks Class Initialized
DEBUG - 2017-01-14 01:16:30 --> UTF-8 Support Enabled
INFO - 2017-01-14 01:16:30 --> Utf8 Class Initialized
INFO - 2017-01-14 01:16:30 --> URI Class Initialized
INFO - 2017-01-14 01:16:30 --> Router Class Initialized
INFO - 2017-01-14 01:16:30 --> Output Class Initialized
INFO - 2017-01-14 01:16:30 --> Security Class Initialized
DEBUG - 2017-01-14 01:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 01:16:30 --> Input Class Initialized
INFO - 2017-01-14 01:16:30 --> Language Class Initialized
ERROR - 2017-01-14 01:16:30 --> 404 Page Not Found: Imagenes_portada/Galeria1.jpg
INFO - 2017-01-14 06:06:32 --> Config Class Initialized
INFO - 2017-01-14 06:06:32 --> Hooks Class Initialized
DEBUG - 2017-01-14 06:06:32 --> UTF-8 Support Enabled
INFO - 2017-01-14 06:06:32 --> Utf8 Class Initialized
INFO - 2017-01-14 06:06:32 --> URI Class Initialized
INFO - 2017-01-14 06:06:32 --> Router Class Initialized
INFO - 2017-01-14 06:06:32 --> Output Class Initialized
INFO - 2017-01-14 06:06:32 --> Security Class Initialized
DEBUG - 2017-01-14 06:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 06:06:32 --> Input Class Initialized
INFO - 2017-01-14 06:06:32 --> Language Class Initialized
INFO - 2017-01-14 06:06:32 --> Loader Class Initialized
INFO - 2017-01-14 06:06:32 --> Database Driver Class Initialized
INFO - 2017-01-14 06:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 06:06:32 --> Controller Class Initialized
INFO - 2017-01-14 06:06:32 --> Helper loaded: url_helper
DEBUG - 2017-01-14 06:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 06:06:32 --> Final output sent to browser
DEBUG - 2017-01-14 06:06:32 --> Total execution time: 0.0137
INFO - 2017-01-14 06:06:32 --> Config Class Initialized
INFO - 2017-01-14 06:06:32 --> Hooks Class Initialized
DEBUG - 2017-01-14 06:06:32 --> UTF-8 Support Enabled
INFO - 2017-01-14 06:06:32 --> Utf8 Class Initialized
INFO - 2017-01-14 06:06:32 --> URI Class Initialized
DEBUG - 2017-01-14 06:06:32 --> No URI present. Default controller set.
INFO - 2017-01-14 06:06:32 --> Router Class Initialized
INFO - 2017-01-14 06:06:32 --> Output Class Initialized
INFO - 2017-01-14 06:06:32 --> Security Class Initialized
DEBUG - 2017-01-14 06:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 06:06:32 --> Input Class Initialized
INFO - 2017-01-14 06:06:32 --> Language Class Initialized
INFO - 2017-01-14 06:06:32 --> Loader Class Initialized
INFO - 2017-01-14 06:06:32 --> Database Driver Class Initialized
INFO - 2017-01-14 06:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 06:06:32 --> Controller Class Initialized
INFO - 2017-01-14 06:06:32 --> Helper loaded: url_helper
DEBUG - 2017-01-14 06:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 06:06:32 --> Final output sent to browser
DEBUG - 2017-01-14 06:06:32 --> Total execution time: 0.0130
INFO - 2017-01-14 13:42:25 --> Config Class Initialized
INFO - 2017-01-14 13:42:25 --> Hooks Class Initialized
DEBUG - 2017-01-14 13:42:25 --> UTF-8 Support Enabled
INFO - 2017-01-14 13:42:25 --> Utf8 Class Initialized
INFO - 2017-01-14 13:42:25 --> URI Class Initialized
INFO - 2017-01-14 13:42:25 --> Router Class Initialized
INFO - 2017-01-14 13:42:25 --> Output Class Initialized
INFO - 2017-01-14 13:42:25 --> Security Class Initialized
DEBUG - 2017-01-14 13:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 13:42:25 --> Input Class Initialized
INFO - 2017-01-14 13:42:25 --> Language Class Initialized
INFO - 2017-01-14 13:42:25 --> Loader Class Initialized
INFO - 2017-01-14 13:42:25 --> Database Driver Class Initialized
INFO - 2017-01-14 13:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 13:42:25 --> Controller Class Initialized
INFO - 2017-01-14 13:42:25 --> Helper loaded: url_helper
DEBUG - 2017-01-14 13:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 13:42:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 13:42:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 13:42:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 13:42:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 13:42:25 --> Final output sent to browser
DEBUG - 2017-01-14 13:42:25 --> Total execution time: 0.0291
INFO - 2017-01-14 16:53:23 --> Config Class Initialized
INFO - 2017-01-14 16:53:23 --> Hooks Class Initialized
DEBUG - 2017-01-14 16:53:23 --> UTF-8 Support Enabled
INFO - 2017-01-14 16:53:23 --> Utf8 Class Initialized
INFO - 2017-01-14 16:53:23 --> URI Class Initialized
INFO - 2017-01-14 16:53:23 --> Router Class Initialized
INFO - 2017-01-14 16:53:23 --> Output Class Initialized
INFO - 2017-01-14 16:53:23 --> Security Class Initialized
DEBUG - 2017-01-14 16:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 16:53:23 --> Input Class Initialized
INFO - 2017-01-14 16:53:23 --> Language Class Initialized
INFO - 2017-01-14 16:53:23 --> Loader Class Initialized
INFO - 2017-01-14 16:53:23 --> Database Driver Class Initialized
INFO - 2017-01-14 16:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 16:53:23 --> Controller Class Initialized
INFO - 2017-01-14 16:53:23 --> Helper loaded: url_helper
DEBUG - 2017-01-14 16:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 16:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 16:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 16:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 16:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 16:53:23 --> Final output sent to browser
DEBUG - 2017-01-14 16:53:23 --> Total execution time: 0.0136
INFO - 2017-01-14 16:53:23 --> Config Class Initialized
INFO - 2017-01-14 16:53:23 --> Hooks Class Initialized
DEBUG - 2017-01-14 16:53:23 --> UTF-8 Support Enabled
INFO - 2017-01-14 16:53:23 --> Utf8 Class Initialized
INFO - 2017-01-14 16:53:23 --> URI Class Initialized
INFO - 2017-01-14 16:53:23 --> Router Class Initialized
INFO - 2017-01-14 16:53:23 --> Output Class Initialized
INFO - 2017-01-14 16:53:23 --> Security Class Initialized
DEBUG - 2017-01-14 16:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 16:53:23 --> Input Class Initialized
INFO - 2017-01-14 16:53:23 --> Language Class Initialized
ERROR - 2017-01-14 16:53:23 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2017-01-14 18:21:27 --> Config Class Initialized
INFO - 2017-01-14 18:21:27 --> Hooks Class Initialized
DEBUG - 2017-01-14 18:21:27 --> UTF-8 Support Enabled
INFO - 2017-01-14 18:21:27 --> Utf8 Class Initialized
INFO - 2017-01-14 18:21:27 --> URI Class Initialized
DEBUG - 2017-01-14 18:21:27 --> No URI present. Default controller set.
INFO - 2017-01-14 18:21:27 --> Router Class Initialized
INFO - 2017-01-14 18:21:27 --> Output Class Initialized
INFO - 2017-01-14 18:21:27 --> Security Class Initialized
DEBUG - 2017-01-14 18:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 18:21:27 --> Input Class Initialized
INFO - 2017-01-14 18:21:27 --> Language Class Initialized
INFO - 2017-01-14 18:21:27 --> Loader Class Initialized
INFO - 2017-01-14 18:21:27 --> Database Driver Class Initialized
INFO - 2017-01-14 18:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 18:21:27 --> Controller Class Initialized
INFO - 2017-01-14 18:21:27 --> Helper loaded: url_helper
DEBUG - 2017-01-14 18:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 18:21:27 --> Final output sent to browser
DEBUG - 2017-01-14 18:21:27 --> Total execution time: 0.0138
INFO - 2017-01-14 20:32:35 --> Config Class Initialized
INFO - 2017-01-14 20:32:35 --> Hooks Class Initialized
DEBUG - 2017-01-14 20:32:35 --> UTF-8 Support Enabled
INFO - 2017-01-14 20:32:35 --> Utf8 Class Initialized
INFO - 2017-01-14 20:32:35 --> URI Class Initialized
DEBUG - 2017-01-14 20:32:35 --> No URI present. Default controller set.
INFO - 2017-01-14 20:32:35 --> Router Class Initialized
INFO - 2017-01-14 20:32:35 --> Output Class Initialized
INFO - 2017-01-14 20:32:35 --> Security Class Initialized
DEBUG - 2017-01-14 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 20:32:35 --> Input Class Initialized
INFO - 2017-01-14 20:32:35 --> Language Class Initialized
INFO - 2017-01-14 20:32:35 --> Loader Class Initialized
INFO - 2017-01-14 20:32:35 --> Database Driver Class Initialized
INFO - 2017-01-14 20:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 20:32:35 --> Controller Class Initialized
INFO - 2017-01-14 20:32:35 --> Helper loaded: url_helper
DEBUG - 2017-01-14 20:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 20:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 20:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 20:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 20:32:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 20:32:35 --> Final output sent to browser
DEBUG - 2017-01-14 20:32:35 --> Total execution time: 0.1637
INFO - 2017-01-14 21:23:34 --> Config Class Initialized
INFO - 2017-01-14 21:23:34 --> Hooks Class Initialized
DEBUG - 2017-01-14 21:23:34 --> UTF-8 Support Enabled
INFO - 2017-01-14 21:23:34 --> Utf8 Class Initialized
INFO - 2017-01-14 21:23:34 --> URI Class Initialized
DEBUG - 2017-01-14 21:23:34 --> No URI present. Default controller set.
INFO - 2017-01-14 21:23:34 --> Router Class Initialized
INFO - 2017-01-14 21:23:34 --> Output Class Initialized
INFO - 2017-01-14 21:23:34 --> Security Class Initialized
DEBUG - 2017-01-14 21:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-14 21:23:34 --> Input Class Initialized
INFO - 2017-01-14 21:23:34 --> Language Class Initialized
INFO - 2017-01-14 21:23:34 --> Loader Class Initialized
INFO - 2017-01-14 21:23:34 --> Database Driver Class Initialized
INFO - 2017-01-14 21:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-14 21:23:34 --> Controller Class Initialized
INFO - 2017-01-14 21:23:34 --> Helper loaded: url_helper
DEBUG - 2017-01-14 21:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-14 21:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-14 21:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-14 21:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-14 21:23:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-14 21:23:34 --> Final output sent to browser
DEBUG - 2017-01-14 21:23:34 --> Total execution time: 0.0565

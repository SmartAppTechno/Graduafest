<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-11 03:26:08 --> Config Class Initialized
INFO - 2017-02-11 03:26:08 --> Hooks Class Initialized
DEBUG - 2017-02-11 03:26:08 --> UTF-8 Support Enabled
INFO - 2017-02-11 03:26:08 --> Utf8 Class Initialized
INFO - 2017-02-11 03:26:08 --> URI Class Initialized
DEBUG - 2017-02-11 03:26:08 --> No URI present. Default controller set.
INFO - 2017-02-11 03:26:08 --> Router Class Initialized
INFO - 2017-02-11 03:26:08 --> Output Class Initialized
INFO - 2017-02-11 03:26:08 --> Security Class Initialized
DEBUG - 2017-02-11 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 03:26:08 --> Input Class Initialized
INFO - 2017-02-11 03:26:08 --> Language Class Initialized
INFO - 2017-02-11 03:26:08 --> Loader Class Initialized
INFO - 2017-02-11 03:26:08 --> Database Driver Class Initialized
INFO - 2017-02-11 03:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 03:26:08 --> Controller Class Initialized
INFO - 2017-02-11 03:26:08 --> Helper loaded: url_helper
DEBUG - 2017-02-11 03:26:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 03:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 03:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 03:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 03:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 03:26:08 --> Final output sent to browser
DEBUG - 2017-02-11 03:26:08 --> Total execution time: 0.0237
INFO - 2017-02-11 03:26:11 --> Config Class Initialized
INFO - 2017-02-11 03:26:11 --> Hooks Class Initialized
DEBUG - 2017-02-11 03:26:11 --> UTF-8 Support Enabled
INFO - 2017-02-11 03:26:11 --> Utf8 Class Initialized
INFO - 2017-02-11 03:26:11 --> URI Class Initialized
INFO - 2017-02-11 03:26:11 --> Router Class Initialized
INFO - 2017-02-11 03:26:11 --> Output Class Initialized
INFO - 2017-02-11 03:26:11 --> Security Class Initialized
DEBUG - 2017-02-11 03:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 03:26:11 --> Input Class Initialized
INFO - 2017-02-11 03:26:11 --> Language Class Initialized
INFO - 2017-02-11 03:26:11 --> Loader Class Initialized
INFO - 2017-02-11 03:26:11 --> Database Driver Class Initialized
INFO - 2017-02-11 03:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 03:26:11 --> Controller Class Initialized
INFO - 2017-02-11 03:26:11 --> Helper loaded: url_helper
DEBUG - 2017-02-11 03:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 03:26:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 03:26:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 03:26:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 03:26:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 03:26:11 --> Final output sent to browser
DEBUG - 2017-02-11 03:26:11 --> Total execution time: 0.0132
INFO - 2017-02-11 03:48:13 --> Config Class Initialized
INFO - 2017-02-11 03:48:13 --> Hooks Class Initialized
DEBUG - 2017-02-11 03:48:13 --> UTF-8 Support Enabled
INFO - 2017-02-11 03:48:13 --> Utf8 Class Initialized
INFO - 2017-02-11 03:48:13 --> URI Class Initialized
INFO - 2017-02-11 03:48:13 --> Router Class Initialized
INFO - 2017-02-11 03:48:13 --> Output Class Initialized
INFO - 2017-02-11 03:48:13 --> Security Class Initialized
DEBUG - 2017-02-11 03:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 03:48:13 --> Input Class Initialized
INFO - 2017-02-11 03:48:13 --> Language Class Initialized
INFO - 2017-02-11 03:48:13 --> Loader Class Initialized
INFO - 2017-02-11 03:48:13 --> Database Driver Class Initialized
INFO - 2017-02-11 03:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 03:48:13 --> Controller Class Initialized
INFO - 2017-02-11 03:48:13 --> Helper loaded: url_helper
DEBUG - 2017-02-11 03:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 03:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 03:48:13 --> Final output sent to browser
DEBUG - 2017-02-11 03:48:13 --> Total execution time: 0.0236
INFO - 2017-02-11 03:48:22 --> Config Class Initialized
INFO - 2017-02-11 03:48:22 --> Hooks Class Initialized
DEBUG - 2017-02-11 03:48:22 --> UTF-8 Support Enabled
INFO - 2017-02-11 03:48:22 --> Utf8 Class Initialized
INFO - 2017-02-11 03:48:22 --> URI Class Initialized
INFO - 2017-02-11 03:48:22 --> Router Class Initialized
INFO - 2017-02-11 03:48:22 --> Output Class Initialized
INFO - 2017-02-11 03:48:22 --> Security Class Initialized
DEBUG - 2017-02-11 03:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 03:48:22 --> Input Class Initialized
INFO - 2017-02-11 03:48:22 --> Language Class Initialized
INFO - 2017-02-11 03:48:22 --> Loader Class Initialized
INFO - 2017-02-11 03:48:22 --> Database Driver Class Initialized
INFO - 2017-02-11 03:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 03:48:22 --> Controller Class Initialized
INFO - 2017-02-11 03:48:22 --> Helper loaded: url_helper
DEBUG - 2017-02-11 03:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 03:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 03:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 03:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 03:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 03:48:22 --> Final output sent to browser
DEBUG - 2017-02-11 03:48:22 --> Total execution time: 0.0138
INFO - 2017-02-11 05:55:09 --> Config Class Initialized
INFO - 2017-02-11 05:55:09 --> Hooks Class Initialized
DEBUG - 2017-02-11 05:55:09 --> UTF-8 Support Enabled
INFO - 2017-02-11 05:55:09 --> Utf8 Class Initialized
INFO - 2017-02-11 05:55:09 --> URI Class Initialized
INFO - 2017-02-11 05:55:09 --> Router Class Initialized
INFO - 2017-02-11 05:55:09 --> Output Class Initialized
INFO - 2017-02-11 05:55:09 --> Security Class Initialized
DEBUG - 2017-02-11 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 05:55:09 --> Input Class Initialized
INFO - 2017-02-11 05:55:09 --> Language Class Initialized
INFO - 2017-02-11 05:55:09 --> Loader Class Initialized
INFO - 2017-02-11 05:55:09 --> Database Driver Class Initialized
INFO - 2017-02-11 05:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 05:55:09 --> Controller Class Initialized
INFO - 2017-02-11 05:55:09 --> Helper loaded: url_helper
DEBUG - 2017-02-11 05:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 05:55:09 --> Final output sent to browser
DEBUG - 2017-02-11 05:55:09 --> Total execution time: 0.0134
INFO - 2017-02-11 05:55:09 --> Config Class Initialized
INFO - 2017-02-11 05:55:09 --> Hooks Class Initialized
DEBUG - 2017-02-11 05:55:09 --> UTF-8 Support Enabled
INFO - 2017-02-11 05:55:09 --> Utf8 Class Initialized
INFO - 2017-02-11 05:55:09 --> URI Class Initialized
DEBUG - 2017-02-11 05:55:09 --> No URI present. Default controller set.
INFO - 2017-02-11 05:55:09 --> Router Class Initialized
INFO - 2017-02-11 05:55:09 --> Output Class Initialized
INFO - 2017-02-11 05:55:09 --> Security Class Initialized
DEBUG - 2017-02-11 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 05:55:09 --> Input Class Initialized
INFO - 2017-02-11 05:55:09 --> Language Class Initialized
INFO - 2017-02-11 05:55:09 --> Loader Class Initialized
INFO - 2017-02-11 05:55:09 --> Database Driver Class Initialized
INFO - 2017-02-11 05:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 05:55:09 --> Controller Class Initialized
INFO - 2017-02-11 05:55:09 --> Helper loaded: url_helper
DEBUG - 2017-02-11 05:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 05:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 05:55:09 --> Final output sent to browser
DEBUG - 2017-02-11 05:55:09 --> Total execution time: 0.0135
INFO - 2017-02-11 06:09:50 --> Config Class Initialized
INFO - 2017-02-11 06:09:50 --> Hooks Class Initialized
DEBUG - 2017-02-11 06:09:50 --> UTF-8 Support Enabled
INFO - 2017-02-11 06:09:50 --> Utf8 Class Initialized
INFO - 2017-02-11 06:09:50 --> URI Class Initialized
INFO - 2017-02-11 06:09:50 --> Router Class Initialized
INFO - 2017-02-11 06:09:50 --> Output Class Initialized
INFO - 2017-02-11 06:09:50 --> Security Class Initialized
DEBUG - 2017-02-11 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 06:09:50 --> Input Class Initialized
INFO - 2017-02-11 06:09:50 --> Language Class Initialized
INFO - 2017-02-11 06:09:50 --> Loader Class Initialized
INFO - 2017-02-11 06:09:50 --> Database Driver Class Initialized
INFO - 2017-02-11 06:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 06:09:50 --> Controller Class Initialized
INFO - 2017-02-11 06:09:50 --> Helper loaded: url_helper
DEBUG - 2017-02-11 06:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 06:09:50 --> Final output sent to browser
DEBUG - 2017-02-11 06:09:50 --> Total execution time: 0.0138
INFO - 2017-02-11 06:09:50 --> Config Class Initialized
INFO - 2017-02-11 06:09:50 --> Hooks Class Initialized
DEBUG - 2017-02-11 06:09:50 --> UTF-8 Support Enabled
INFO - 2017-02-11 06:09:50 --> Utf8 Class Initialized
INFO - 2017-02-11 06:09:50 --> URI Class Initialized
DEBUG - 2017-02-11 06:09:50 --> No URI present. Default controller set.
INFO - 2017-02-11 06:09:50 --> Router Class Initialized
INFO - 2017-02-11 06:09:50 --> Output Class Initialized
INFO - 2017-02-11 06:09:50 --> Security Class Initialized
DEBUG - 2017-02-11 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 06:09:50 --> Input Class Initialized
INFO - 2017-02-11 06:09:50 --> Language Class Initialized
INFO - 2017-02-11 06:09:50 --> Loader Class Initialized
INFO - 2017-02-11 06:09:50 --> Database Driver Class Initialized
INFO - 2017-02-11 06:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 06:09:50 --> Controller Class Initialized
INFO - 2017-02-11 06:09:50 --> Helper loaded: url_helper
DEBUG - 2017-02-11 06:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 06:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 06:09:50 --> Final output sent to browser
DEBUG - 2017-02-11 06:09:50 --> Total execution time: 0.0135
INFO - 2017-02-11 09:20:30 --> Config Class Initialized
INFO - 2017-02-11 09:20:30 --> Hooks Class Initialized
DEBUG - 2017-02-11 09:20:30 --> UTF-8 Support Enabled
INFO - 2017-02-11 09:20:30 --> Utf8 Class Initialized
INFO - 2017-02-11 09:20:30 --> URI Class Initialized
INFO - 2017-02-11 09:20:30 --> Router Class Initialized
INFO - 2017-02-11 09:20:30 --> Output Class Initialized
INFO - 2017-02-11 09:20:30 --> Security Class Initialized
DEBUG - 2017-02-11 09:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 09:20:30 --> Input Class Initialized
INFO - 2017-02-11 09:20:30 --> Language Class Initialized
INFO - 2017-02-11 09:20:30 --> Loader Class Initialized
INFO - 2017-02-11 09:20:30 --> Database Driver Class Initialized
INFO - 2017-02-11 09:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 09:20:30 --> Controller Class Initialized
INFO - 2017-02-11 09:20:30 --> Helper loaded: url_helper
DEBUG - 2017-02-11 09:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 09:20:30 --> Final output sent to browser
DEBUG - 2017-02-11 09:20:30 --> Total execution time: 0.0139
INFO - 2017-02-11 09:20:30 --> Config Class Initialized
INFO - 2017-02-11 09:20:30 --> Hooks Class Initialized
DEBUG - 2017-02-11 09:20:30 --> UTF-8 Support Enabled
INFO - 2017-02-11 09:20:30 --> Utf8 Class Initialized
INFO - 2017-02-11 09:20:30 --> URI Class Initialized
DEBUG - 2017-02-11 09:20:30 --> No URI present. Default controller set.
INFO - 2017-02-11 09:20:30 --> Router Class Initialized
INFO - 2017-02-11 09:20:30 --> Output Class Initialized
INFO - 2017-02-11 09:20:30 --> Security Class Initialized
DEBUG - 2017-02-11 09:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 09:20:30 --> Input Class Initialized
INFO - 2017-02-11 09:20:30 --> Language Class Initialized
INFO - 2017-02-11 09:20:30 --> Loader Class Initialized
INFO - 2017-02-11 09:20:30 --> Database Driver Class Initialized
INFO - 2017-02-11 09:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 09:20:30 --> Controller Class Initialized
INFO - 2017-02-11 09:20:30 --> Helper loaded: url_helper
DEBUG - 2017-02-11 09:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 09:20:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 09:20:30 --> Final output sent to browser
DEBUG - 2017-02-11 09:20:30 --> Total execution time: 0.0134
INFO - 2017-02-11 09:52:41 --> Config Class Initialized
INFO - 2017-02-11 09:52:41 --> Hooks Class Initialized
DEBUG - 2017-02-11 09:52:41 --> UTF-8 Support Enabled
INFO - 2017-02-11 09:52:41 --> Utf8 Class Initialized
INFO - 2017-02-11 09:52:41 --> URI Class Initialized
INFO - 2017-02-11 09:52:41 --> Router Class Initialized
INFO - 2017-02-11 09:52:41 --> Output Class Initialized
INFO - 2017-02-11 09:52:41 --> Security Class Initialized
DEBUG - 2017-02-11 09:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 09:52:41 --> Input Class Initialized
INFO - 2017-02-11 09:52:41 --> Language Class Initialized
INFO - 2017-02-11 09:52:41 --> Loader Class Initialized
INFO - 2017-02-11 09:52:41 --> Database Driver Class Initialized
INFO - 2017-02-11 09:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 09:52:41 --> Controller Class Initialized
INFO - 2017-02-11 09:52:41 --> Helper loaded: url_helper
DEBUG - 2017-02-11 09:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 09:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 09:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 09:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 09:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 09:52:41 --> Final output sent to browser
DEBUG - 2017-02-11 09:52:41 --> Total execution time: 0.0298
INFO - 2017-02-11 10:04:55 --> Config Class Initialized
INFO - 2017-02-11 10:04:55 --> Hooks Class Initialized
DEBUG - 2017-02-11 10:04:55 --> UTF-8 Support Enabled
INFO - 2017-02-11 10:04:55 --> Utf8 Class Initialized
INFO - 2017-02-11 10:04:55 --> URI Class Initialized
INFO - 2017-02-11 10:04:55 --> Router Class Initialized
INFO - 2017-02-11 10:04:55 --> Output Class Initialized
INFO - 2017-02-11 10:04:55 --> Security Class Initialized
DEBUG - 2017-02-11 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 10:04:55 --> Input Class Initialized
INFO - 2017-02-11 10:04:55 --> Language Class Initialized
INFO - 2017-02-11 10:04:55 --> Loader Class Initialized
INFO - 2017-02-11 10:04:55 --> Database Driver Class Initialized
INFO - 2017-02-11 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 10:04:55 --> Controller Class Initialized
INFO - 2017-02-11 10:04:55 --> Helper loaded: url_helper
DEBUG - 2017-02-11 10:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 10:04:55 --> Final output sent to browser
DEBUG - 2017-02-11 10:04:55 --> Total execution time: 0.0335
INFO - 2017-02-11 10:04:55 --> Config Class Initialized
INFO - 2017-02-11 10:04:55 --> Hooks Class Initialized
DEBUG - 2017-02-11 10:04:55 --> UTF-8 Support Enabled
INFO - 2017-02-11 10:04:55 --> Utf8 Class Initialized
INFO - 2017-02-11 10:04:55 --> URI Class Initialized
DEBUG - 2017-02-11 10:04:55 --> No URI present. Default controller set.
INFO - 2017-02-11 10:04:55 --> Router Class Initialized
INFO - 2017-02-11 10:04:55 --> Output Class Initialized
INFO - 2017-02-11 10:04:55 --> Security Class Initialized
DEBUG - 2017-02-11 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 10:04:55 --> Input Class Initialized
INFO - 2017-02-11 10:04:55 --> Language Class Initialized
INFO - 2017-02-11 10:04:55 --> Loader Class Initialized
INFO - 2017-02-11 10:04:55 --> Database Driver Class Initialized
INFO - 2017-02-11 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 10:04:55 --> Controller Class Initialized
INFO - 2017-02-11 10:04:55 --> Helper loaded: url_helper
DEBUG - 2017-02-11 10:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 10:04:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 10:04:55 --> Final output sent to browser
DEBUG - 2017-02-11 10:04:55 --> Total execution time: 0.0258
INFO - 2017-02-11 11:01:57 --> Config Class Initialized
INFO - 2017-02-11 11:01:57 --> Hooks Class Initialized
DEBUG - 2017-02-11 11:01:57 --> UTF-8 Support Enabled
INFO - 2017-02-11 11:01:57 --> Utf8 Class Initialized
INFO - 2017-02-11 11:01:57 --> URI Class Initialized
DEBUG - 2017-02-11 11:01:57 --> No URI present. Default controller set.
INFO - 2017-02-11 11:01:57 --> Router Class Initialized
INFO - 2017-02-11 11:01:57 --> Output Class Initialized
INFO - 2017-02-11 11:01:57 --> Security Class Initialized
DEBUG - 2017-02-11 11:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 11:01:57 --> Input Class Initialized
INFO - 2017-02-11 11:01:57 --> Language Class Initialized
INFO - 2017-02-11 11:01:57 --> Loader Class Initialized
INFO - 2017-02-11 11:01:57 --> Database Driver Class Initialized
INFO - 2017-02-11 11:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 11:01:57 --> Controller Class Initialized
INFO - 2017-02-11 11:01:57 --> Helper loaded: url_helper
DEBUG - 2017-02-11 11:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 11:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 11:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 11:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 11:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 11:01:57 --> Final output sent to browser
DEBUG - 2017-02-11 11:01:57 --> Total execution time: 0.0130
INFO - 2017-02-11 12:18:50 --> Config Class Initialized
INFO - 2017-02-11 12:18:50 --> Hooks Class Initialized
DEBUG - 2017-02-11 12:18:50 --> UTF-8 Support Enabled
INFO - 2017-02-11 12:18:50 --> Utf8 Class Initialized
INFO - 2017-02-11 12:18:50 --> URI Class Initialized
INFO - 2017-02-11 12:18:50 --> Router Class Initialized
INFO - 2017-02-11 12:18:50 --> Output Class Initialized
INFO - 2017-02-11 12:18:50 --> Security Class Initialized
DEBUG - 2017-02-11 12:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 12:18:50 --> Input Class Initialized
INFO - 2017-02-11 12:18:50 --> Language Class Initialized
INFO - 2017-02-11 12:18:50 --> Loader Class Initialized
INFO - 2017-02-11 12:18:50 --> Database Driver Class Initialized
INFO - 2017-02-11 12:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 12:18:50 --> Controller Class Initialized
INFO - 2017-02-11 12:18:50 --> Helper loaded: url_helper
DEBUG - 2017-02-11 12:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 12:18:50 --> Final output sent to browser
DEBUG - 2017-02-11 12:18:50 --> Total execution time: 0.0143
INFO - 2017-02-11 12:18:50 --> Config Class Initialized
INFO - 2017-02-11 12:18:50 --> Hooks Class Initialized
DEBUG - 2017-02-11 12:18:50 --> UTF-8 Support Enabled
INFO - 2017-02-11 12:18:50 --> Utf8 Class Initialized
INFO - 2017-02-11 12:18:50 --> URI Class Initialized
DEBUG - 2017-02-11 12:18:50 --> No URI present. Default controller set.
INFO - 2017-02-11 12:18:50 --> Router Class Initialized
INFO - 2017-02-11 12:18:50 --> Output Class Initialized
INFO - 2017-02-11 12:18:50 --> Security Class Initialized
DEBUG - 2017-02-11 12:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 12:18:50 --> Input Class Initialized
INFO - 2017-02-11 12:18:50 --> Language Class Initialized
INFO - 2017-02-11 12:18:50 --> Loader Class Initialized
INFO - 2017-02-11 12:18:50 --> Database Driver Class Initialized
INFO - 2017-02-11 12:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 12:18:50 --> Controller Class Initialized
INFO - 2017-02-11 12:18:50 --> Helper loaded: url_helper
DEBUG - 2017-02-11 12:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 12:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 12:18:50 --> Final output sent to browser
DEBUG - 2017-02-11 12:18:50 --> Total execution time: 0.0136
INFO - 2017-02-11 12:46:44 --> Config Class Initialized
INFO - 2017-02-11 12:46:44 --> Hooks Class Initialized
DEBUG - 2017-02-11 12:46:44 --> UTF-8 Support Enabled
INFO - 2017-02-11 12:46:44 --> Utf8 Class Initialized
INFO - 2017-02-11 12:46:44 --> URI Class Initialized
DEBUG - 2017-02-11 12:46:44 --> No URI present. Default controller set.
INFO - 2017-02-11 12:46:44 --> Router Class Initialized
INFO - 2017-02-11 12:46:44 --> Output Class Initialized
INFO - 2017-02-11 12:46:44 --> Security Class Initialized
DEBUG - 2017-02-11 12:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 12:46:44 --> Input Class Initialized
INFO - 2017-02-11 12:46:44 --> Language Class Initialized
INFO - 2017-02-11 12:46:44 --> Loader Class Initialized
INFO - 2017-02-11 12:46:44 --> Database Driver Class Initialized
INFO - 2017-02-11 12:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 12:46:44 --> Controller Class Initialized
INFO - 2017-02-11 12:46:44 --> Helper loaded: url_helper
DEBUG - 2017-02-11 12:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 12:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 12:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 12:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 12:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 12:46:44 --> Final output sent to browser
DEBUG - 2017-02-11 12:46:44 --> Total execution time: 0.0135
INFO - 2017-02-11 15:12:49 --> Config Class Initialized
INFO - 2017-02-11 15:12:49 --> Hooks Class Initialized
DEBUG - 2017-02-11 15:12:49 --> UTF-8 Support Enabled
INFO - 2017-02-11 15:12:49 --> Utf8 Class Initialized
INFO - 2017-02-11 15:12:49 --> URI Class Initialized
INFO - 2017-02-11 15:12:49 --> Router Class Initialized
INFO - 2017-02-11 15:12:49 --> Output Class Initialized
INFO - 2017-02-11 15:12:49 --> Security Class Initialized
DEBUG - 2017-02-11 15:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 15:12:49 --> Input Class Initialized
INFO - 2017-02-11 15:12:49 --> Language Class Initialized
INFO - 2017-02-11 15:12:49 --> Loader Class Initialized
INFO - 2017-02-11 15:12:49 --> Database Driver Class Initialized
INFO - 2017-02-11 15:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 15:12:49 --> Controller Class Initialized
INFO - 2017-02-11 15:12:49 --> Helper loaded: url_helper
DEBUG - 2017-02-11 15:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 15:12:49 --> Final output sent to browser
DEBUG - 2017-02-11 15:12:49 --> Total execution time: 0.0136
INFO - 2017-02-11 15:12:49 --> Config Class Initialized
INFO - 2017-02-11 15:12:49 --> Hooks Class Initialized
DEBUG - 2017-02-11 15:12:49 --> UTF-8 Support Enabled
INFO - 2017-02-11 15:12:49 --> Utf8 Class Initialized
INFO - 2017-02-11 15:12:49 --> URI Class Initialized
DEBUG - 2017-02-11 15:12:49 --> No URI present. Default controller set.
INFO - 2017-02-11 15:12:49 --> Router Class Initialized
INFO - 2017-02-11 15:12:49 --> Output Class Initialized
INFO - 2017-02-11 15:12:49 --> Security Class Initialized
DEBUG - 2017-02-11 15:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 15:12:49 --> Input Class Initialized
INFO - 2017-02-11 15:12:49 --> Language Class Initialized
INFO - 2017-02-11 15:12:49 --> Loader Class Initialized
INFO - 2017-02-11 15:12:49 --> Database Driver Class Initialized
INFO - 2017-02-11 15:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 15:12:49 --> Controller Class Initialized
INFO - 2017-02-11 15:12:49 --> Helper loaded: url_helper
DEBUG - 2017-02-11 15:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 15:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 15:12:49 --> Final output sent to browser
DEBUG - 2017-02-11 15:12:49 --> Total execution time: 0.0138
INFO - 2017-02-11 15:23:25 --> Config Class Initialized
INFO - 2017-02-11 15:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-11 15:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-11 15:23:25 --> Utf8 Class Initialized
INFO - 2017-02-11 15:23:25 --> URI Class Initialized
INFO - 2017-02-11 15:23:25 --> Router Class Initialized
INFO - 2017-02-11 15:23:25 --> Output Class Initialized
INFO - 2017-02-11 15:23:25 --> Security Class Initialized
DEBUG - 2017-02-11 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 15:23:25 --> Input Class Initialized
INFO - 2017-02-11 15:23:25 --> Language Class Initialized
INFO - 2017-02-11 15:23:25 --> Loader Class Initialized
INFO - 2017-02-11 15:23:25 --> Database Driver Class Initialized
INFO - 2017-02-11 15:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 15:23:25 --> Controller Class Initialized
INFO - 2017-02-11 15:23:25 --> Helper loaded: url_helper
DEBUG - 2017-02-11 15:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 15:23:25 --> Final output sent to browser
DEBUG - 2017-02-11 15:23:25 --> Total execution time: 0.0133
INFO - 2017-02-11 15:23:25 --> Config Class Initialized
INFO - 2017-02-11 15:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-11 15:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-11 15:23:25 --> Utf8 Class Initialized
INFO - 2017-02-11 15:23:25 --> URI Class Initialized
DEBUG - 2017-02-11 15:23:25 --> No URI present. Default controller set.
INFO - 2017-02-11 15:23:25 --> Router Class Initialized
INFO - 2017-02-11 15:23:25 --> Output Class Initialized
INFO - 2017-02-11 15:23:25 --> Security Class Initialized
DEBUG - 2017-02-11 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 15:23:25 --> Input Class Initialized
INFO - 2017-02-11 15:23:25 --> Language Class Initialized
INFO - 2017-02-11 15:23:25 --> Loader Class Initialized
INFO - 2017-02-11 15:23:25 --> Database Driver Class Initialized
INFO - 2017-02-11 15:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 15:23:25 --> Controller Class Initialized
INFO - 2017-02-11 15:23:25 --> Helper loaded: url_helper
DEBUG - 2017-02-11 15:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 15:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 15:23:25 --> Final output sent to browser
DEBUG - 2017-02-11 15:23:25 --> Total execution time: 0.0133
INFO - 2017-02-11 16:36:26 --> Config Class Initialized
INFO - 2017-02-11 16:36:26 --> Hooks Class Initialized
DEBUG - 2017-02-11 16:36:26 --> UTF-8 Support Enabled
INFO - 2017-02-11 16:36:26 --> Utf8 Class Initialized
INFO - 2017-02-11 16:36:26 --> URI Class Initialized
DEBUG - 2017-02-11 16:36:26 --> No URI present. Default controller set.
INFO - 2017-02-11 16:36:26 --> Router Class Initialized
INFO - 2017-02-11 16:36:26 --> Output Class Initialized
INFO - 2017-02-11 16:36:26 --> Security Class Initialized
DEBUG - 2017-02-11 16:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 16:36:26 --> Input Class Initialized
INFO - 2017-02-11 16:36:26 --> Language Class Initialized
INFO - 2017-02-11 16:36:26 --> Loader Class Initialized
INFO - 2017-02-11 16:36:26 --> Database Driver Class Initialized
INFO - 2017-02-11 16:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 16:36:26 --> Controller Class Initialized
INFO - 2017-02-11 16:36:26 --> Helper loaded: url_helper
DEBUG - 2017-02-11 16:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 16:36:26 --> Final output sent to browser
DEBUG - 2017-02-11 16:36:26 --> Total execution time: 0.0136
INFO - 2017-02-11 16:36:26 --> Config Class Initialized
INFO - 2017-02-11 16:36:26 --> Hooks Class Initialized
DEBUG - 2017-02-11 16:36:26 --> UTF-8 Support Enabled
INFO - 2017-02-11 16:36:26 --> Utf8 Class Initialized
INFO - 2017-02-11 16:36:26 --> URI Class Initialized
INFO - 2017-02-11 16:36:26 --> Router Class Initialized
INFO - 2017-02-11 16:36:26 --> Output Class Initialized
INFO - 2017-02-11 16:36:26 --> Security Class Initialized
DEBUG - 2017-02-11 16:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 16:36:26 --> Input Class Initialized
INFO - 2017-02-11 16:36:26 --> Language Class Initialized
INFO - 2017-02-11 16:36:26 --> Loader Class Initialized
INFO - 2017-02-11 16:36:26 --> Database Driver Class Initialized
INFO - 2017-02-11 16:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 16:36:26 --> Controller Class Initialized
INFO - 2017-02-11 16:36:26 --> Helper loaded: url_helper
DEBUG - 2017-02-11 16:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 16:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 16:36:26 --> Final output sent to browser
DEBUG - 2017-02-11 16:36:26 --> Total execution time: 0.0167
INFO - 2017-02-11 16:37:08 --> Config Class Initialized
INFO - 2017-02-11 16:37:08 --> Hooks Class Initialized
DEBUG - 2017-02-11 16:37:08 --> UTF-8 Support Enabled
INFO - 2017-02-11 16:37:08 --> Utf8 Class Initialized
INFO - 2017-02-11 16:37:08 --> URI Class Initialized
DEBUG - 2017-02-11 16:37:08 --> No URI present. Default controller set.
INFO - 2017-02-11 16:37:08 --> Router Class Initialized
INFO - 2017-02-11 16:37:08 --> Output Class Initialized
INFO - 2017-02-11 16:37:08 --> Security Class Initialized
DEBUG - 2017-02-11 16:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 16:37:08 --> Input Class Initialized
INFO - 2017-02-11 16:37:08 --> Language Class Initialized
INFO - 2017-02-11 16:37:08 --> Loader Class Initialized
INFO - 2017-02-11 16:37:08 --> Database Driver Class Initialized
INFO - 2017-02-11 16:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 16:37:08 --> Controller Class Initialized
INFO - 2017-02-11 16:37:08 --> Helper loaded: url_helper
DEBUG - 2017-02-11 16:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 16:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 16:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 16:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 16:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 16:37:08 --> Final output sent to browser
DEBUG - 2017-02-11 16:37:08 --> Total execution time: 0.0134
INFO - 2017-02-11 17:06:47 --> Config Class Initialized
INFO - 2017-02-11 17:06:47 --> Hooks Class Initialized
DEBUG - 2017-02-11 17:06:47 --> UTF-8 Support Enabled
INFO - 2017-02-11 17:06:47 --> Utf8 Class Initialized
INFO - 2017-02-11 17:06:47 --> URI Class Initialized
INFO - 2017-02-11 17:06:47 --> Router Class Initialized
INFO - 2017-02-11 17:06:47 --> Output Class Initialized
INFO - 2017-02-11 17:06:47 --> Security Class Initialized
DEBUG - 2017-02-11 17:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 17:06:47 --> Input Class Initialized
INFO - 2017-02-11 17:06:47 --> Language Class Initialized
INFO - 2017-02-11 17:06:47 --> Loader Class Initialized
INFO - 2017-02-11 17:06:47 --> Database Driver Class Initialized
INFO - 2017-02-11 17:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 17:06:47 --> Controller Class Initialized
INFO - 2017-02-11 17:06:47 --> Helper loaded: url_helper
DEBUG - 2017-02-11 17:06:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 17:06:47 --> Final output sent to browser
DEBUG - 2017-02-11 17:06:47 --> Total execution time: 0.0135
INFO - 2017-02-11 17:06:47 --> Config Class Initialized
INFO - 2017-02-11 17:06:47 --> Hooks Class Initialized
DEBUG - 2017-02-11 17:06:47 --> UTF-8 Support Enabled
INFO - 2017-02-11 17:06:47 --> Utf8 Class Initialized
INFO - 2017-02-11 17:06:47 --> URI Class Initialized
DEBUG - 2017-02-11 17:06:47 --> No URI present. Default controller set.
INFO - 2017-02-11 17:06:47 --> Router Class Initialized
INFO - 2017-02-11 17:06:47 --> Output Class Initialized
INFO - 2017-02-11 17:06:47 --> Security Class Initialized
DEBUG - 2017-02-11 17:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 17:06:47 --> Input Class Initialized
INFO - 2017-02-11 17:06:47 --> Language Class Initialized
INFO - 2017-02-11 17:06:47 --> Loader Class Initialized
INFO - 2017-02-11 17:06:47 --> Database Driver Class Initialized
INFO - 2017-02-11 17:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 17:06:47 --> Controller Class Initialized
INFO - 2017-02-11 17:06:47 --> Helper loaded: url_helper
DEBUG - 2017-02-11 17:06:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 17:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 17:06:47 --> Final output sent to browser
DEBUG - 2017-02-11 17:06:47 --> Total execution time: 0.0339
INFO - 2017-02-11 18:45:06 --> Config Class Initialized
INFO - 2017-02-11 18:45:06 --> Hooks Class Initialized
DEBUG - 2017-02-11 18:45:06 --> UTF-8 Support Enabled
INFO - 2017-02-11 18:45:06 --> Utf8 Class Initialized
INFO - 2017-02-11 18:45:06 --> URI Class Initialized
INFO - 2017-02-11 18:45:06 --> Router Class Initialized
INFO - 2017-02-11 18:45:06 --> Output Class Initialized
INFO - 2017-02-11 18:45:06 --> Security Class Initialized
DEBUG - 2017-02-11 18:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 18:45:06 --> Input Class Initialized
INFO - 2017-02-11 18:45:06 --> Language Class Initialized
INFO - 2017-02-11 18:45:06 --> Loader Class Initialized
INFO - 2017-02-11 18:45:06 --> Database Driver Class Initialized
INFO - 2017-02-11 18:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 18:45:06 --> Controller Class Initialized
INFO - 2017-02-11 18:45:06 --> Helper loaded: url_helper
DEBUG - 2017-02-11 18:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 18:45:06 --> Final output sent to browser
DEBUG - 2017-02-11 18:45:06 --> Total execution time: 0.0139
INFO - 2017-02-11 18:45:06 --> Config Class Initialized
INFO - 2017-02-11 18:45:06 --> Hooks Class Initialized
DEBUG - 2017-02-11 18:45:06 --> UTF-8 Support Enabled
INFO - 2017-02-11 18:45:06 --> Utf8 Class Initialized
INFO - 2017-02-11 18:45:06 --> URI Class Initialized
DEBUG - 2017-02-11 18:45:06 --> No URI present. Default controller set.
INFO - 2017-02-11 18:45:06 --> Router Class Initialized
INFO - 2017-02-11 18:45:06 --> Output Class Initialized
INFO - 2017-02-11 18:45:06 --> Security Class Initialized
DEBUG - 2017-02-11 18:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 18:45:06 --> Input Class Initialized
INFO - 2017-02-11 18:45:06 --> Language Class Initialized
INFO - 2017-02-11 18:45:06 --> Loader Class Initialized
INFO - 2017-02-11 18:45:06 --> Database Driver Class Initialized
INFO - 2017-02-11 18:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 18:45:06 --> Controller Class Initialized
INFO - 2017-02-11 18:45:06 --> Helper loaded: url_helper
DEBUG - 2017-02-11 18:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 18:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 18:45:06 --> Final output sent to browser
DEBUG - 2017-02-11 18:45:06 --> Total execution time: 0.0131
INFO - 2017-02-11 20:18:12 --> Config Class Initialized
INFO - 2017-02-11 20:18:12 --> Hooks Class Initialized
DEBUG - 2017-02-11 20:18:12 --> UTF-8 Support Enabled
INFO - 2017-02-11 20:18:12 --> Utf8 Class Initialized
INFO - 2017-02-11 20:18:12 --> URI Class Initialized
INFO - 2017-02-11 20:18:12 --> Router Class Initialized
INFO - 2017-02-11 20:18:12 --> Output Class Initialized
INFO - 2017-02-11 20:18:12 --> Security Class Initialized
DEBUG - 2017-02-11 20:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 20:18:12 --> Input Class Initialized
INFO - 2017-02-11 20:18:12 --> Language Class Initialized
INFO - 2017-02-11 20:18:12 --> Loader Class Initialized
INFO - 2017-02-11 20:18:12 --> Database Driver Class Initialized
INFO - 2017-02-11 20:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 20:18:12 --> Controller Class Initialized
INFO - 2017-02-11 20:18:12 --> Helper loaded: url_helper
DEBUG - 2017-02-11 20:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 20:18:12 --> Final output sent to browser
DEBUG - 2017-02-11 20:18:12 --> Total execution time: 0.0138
INFO - 2017-02-11 20:18:12 --> Config Class Initialized
INFO - 2017-02-11 20:18:12 --> Hooks Class Initialized
DEBUG - 2017-02-11 20:18:12 --> UTF-8 Support Enabled
INFO - 2017-02-11 20:18:12 --> Utf8 Class Initialized
INFO - 2017-02-11 20:18:12 --> URI Class Initialized
DEBUG - 2017-02-11 20:18:12 --> No URI present. Default controller set.
INFO - 2017-02-11 20:18:12 --> Router Class Initialized
INFO - 2017-02-11 20:18:12 --> Output Class Initialized
INFO - 2017-02-11 20:18:12 --> Security Class Initialized
DEBUG - 2017-02-11 20:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-11 20:18:12 --> Input Class Initialized
INFO - 2017-02-11 20:18:12 --> Language Class Initialized
INFO - 2017-02-11 20:18:12 --> Loader Class Initialized
INFO - 2017-02-11 20:18:12 --> Database Driver Class Initialized
INFO - 2017-02-11 20:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-11 20:18:12 --> Controller Class Initialized
INFO - 2017-02-11 20:18:12 --> Helper loaded: url_helper
DEBUG - 2017-02-11 20:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-11 20:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-11 20:18:12 --> Final output sent to browser
DEBUG - 2017-02-11 20:18:12 --> Total execution time: 0.0134

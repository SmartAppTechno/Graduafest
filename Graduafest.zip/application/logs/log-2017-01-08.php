<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-08 06:06:26 --> Config Class Initialized
INFO - 2017-01-08 06:06:26 --> Hooks Class Initialized
DEBUG - 2017-01-08 06:06:26 --> UTF-8 Support Enabled
INFO - 2017-01-08 06:06:26 --> Utf8 Class Initialized
INFO - 2017-01-08 06:06:26 --> URI Class Initialized
INFO - 2017-01-08 06:06:26 --> Router Class Initialized
INFO - 2017-01-08 06:06:26 --> Output Class Initialized
INFO - 2017-01-08 06:06:26 --> Security Class Initialized
DEBUG - 2017-01-08 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-08 06:06:26 --> Input Class Initialized
INFO - 2017-01-08 06:06:26 --> Language Class Initialized
INFO - 2017-01-08 06:06:26 --> Loader Class Initialized
INFO - 2017-01-08 06:06:27 --> Database Driver Class Initialized
INFO - 2017-01-08 06:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-08 06:06:27 --> Controller Class Initialized
INFO - 2017-01-08 06:06:27 --> Helper loaded: url_helper
DEBUG - 2017-01-08 06:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-08 06:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-08 06:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-08 06:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-08 06:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-08 06:06:27 --> Final output sent to browser
DEBUG - 2017-01-08 06:06:27 --> Total execution time: 2.0239
INFO - 2017-01-08 06:28:07 --> Config Class Initialized
INFO - 2017-01-08 06:28:07 --> Hooks Class Initialized
DEBUG - 2017-01-08 06:28:07 --> UTF-8 Support Enabled
INFO - 2017-01-08 06:28:07 --> Utf8 Class Initialized
INFO - 2017-01-08 06:28:07 --> URI Class Initialized
INFO - 2017-01-08 06:28:07 --> Router Class Initialized
INFO - 2017-01-08 06:28:07 --> Output Class Initialized
INFO - 2017-01-08 06:28:07 --> Security Class Initialized
DEBUG - 2017-01-08 06:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-08 06:28:07 --> Input Class Initialized
INFO - 2017-01-08 06:28:07 --> Language Class Initialized
INFO - 2017-01-08 06:28:07 --> Loader Class Initialized
INFO - 2017-01-08 06:28:08 --> Database Driver Class Initialized
INFO - 2017-01-08 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-08 06:28:08 --> Controller Class Initialized
INFO - 2017-01-08 06:28:08 --> Helper loaded: url_helper
DEBUG - 2017-01-08 06:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-08 06:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-08 06:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-08 06:28:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-08 06:28:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-08 06:28:09 --> Final output sent to browser
DEBUG - 2017-01-08 06:28:09 --> Total execution time: 1.7406
INFO - 2017-01-08 06:28:09 --> Config Class Initialized
INFO - 2017-01-08 06:28:09 --> Hooks Class Initialized
DEBUG - 2017-01-08 06:28:09 --> UTF-8 Support Enabled
INFO - 2017-01-08 06:28:09 --> Utf8 Class Initialized
INFO - 2017-01-08 06:28:09 --> URI Class Initialized
INFO - 2017-01-08 06:28:09 --> Router Class Initialized
INFO - 2017-01-08 06:28:09 --> Output Class Initialized
INFO - 2017-01-08 06:28:09 --> Security Class Initialized
DEBUG - 2017-01-08 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-08 06:28:09 --> Input Class Initialized
INFO - 2017-01-08 06:28:09 --> Language Class Initialized
ERROR - 2017-01-08 06:28:09 --> 404 Page Not Found: Well-known/apple-app-site-association
INFO - 2017-01-08 06:43:09 --> Config Class Initialized
INFO - 2017-01-08 06:43:09 --> Hooks Class Initialized
DEBUG - 2017-01-08 06:43:09 --> UTF-8 Support Enabled
INFO - 2017-01-08 06:43:09 --> Utf8 Class Initialized
INFO - 2017-01-08 06:43:09 --> URI Class Initialized
INFO - 2017-01-08 06:43:09 --> Router Class Initialized
INFO - 2017-01-08 06:43:09 --> Output Class Initialized
INFO - 2017-01-08 06:43:09 --> Security Class Initialized
DEBUG - 2017-01-08 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-08 06:43:09 --> Input Class Initialized
INFO - 2017-01-08 06:43:09 --> Language Class Initialized
INFO - 2017-01-08 06:43:09 --> Loader Class Initialized
INFO - 2017-01-08 06:43:10 --> Database Driver Class Initialized
INFO - 2017-01-08 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-08 06:43:10 --> Controller Class Initialized
INFO - 2017-01-08 06:43:10 --> Helper loaded: url_helper
DEBUG - 2017-01-08 06:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-08 06:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-08 06:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-08 06:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-08 06:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-08 06:43:10 --> Final output sent to browser
DEBUG - 2017-01-08 06:43:10 --> Total execution time: 1.7543
INFO - 2017-01-08 18:30:59 --> Config Class Initialized
INFO - 2017-01-08 18:30:59 --> Hooks Class Initialized
DEBUG - 2017-01-08 18:31:00 --> UTF-8 Support Enabled
INFO - 2017-01-08 18:31:00 --> Utf8 Class Initialized
INFO - 2017-01-08 18:31:00 --> URI Class Initialized
DEBUG - 2017-01-08 18:31:00 --> No URI present. Default controller set.
INFO - 2017-01-08 18:31:00 --> Router Class Initialized
INFO - 2017-01-08 18:31:00 --> Output Class Initialized
INFO - 2017-01-08 18:31:00 --> Security Class Initialized
DEBUG - 2017-01-08 18:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-08 18:31:00 --> Input Class Initialized
INFO - 2017-01-08 18:31:00 --> Language Class Initialized
INFO - 2017-01-08 18:31:00 --> Loader Class Initialized
INFO - 2017-01-08 18:31:00 --> Database Driver Class Initialized
INFO - 2017-01-08 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-08 18:31:01 --> Controller Class Initialized
INFO - 2017-01-08 18:31:01 --> Helper loaded: url_helper
DEBUG - 2017-01-08 18:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-08 18:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-08 18:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-08 18:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-08 18:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-08 18:31:02 --> Final output sent to browser
DEBUG - 2017-01-08 18:31:02 --> Total execution time: 2.2499
INFO - 2017-01-08 19:11:20 --> Config Class Initialized
INFO - 2017-01-08 19:11:20 --> Hooks Class Initialized
DEBUG - 2017-01-08 19:11:21 --> UTF-8 Support Enabled
INFO - 2017-01-08 19:11:21 --> Utf8 Class Initialized
INFO - 2017-01-08 19:11:21 --> URI Class Initialized
INFO - 2017-01-08 19:11:21 --> Router Class Initialized
INFO - 2017-01-08 19:11:21 --> Output Class Initialized
INFO - 2017-01-08 19:11:21 --> Security Class Initialized
DEBUG - 2017-01-08 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-08 19:11:21 --> Input Class Initialized
INFO - 2017-01-08 19:11:21 --> Language Class Initialized
INFO - 2017-01-08 19:11:21 --> Loader Class Initialized
INFO - 2017-01-08 19:11:21 --> Database Driver Class Initialized
INFO - 2017-01-08 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-08 19:11:21 --> Controller Class Initialized
INFO - 2017-01-08 19:11:21 --> Helper loaded: url_helper
DEBUG - 2017-01-08 19:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-08 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-08 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-08 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-08 19:11:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-08 19:11:22 --> Final output sent to browser
DEBUG - 2017-01-08 19:11:22 --> Total execution time: 1.5342

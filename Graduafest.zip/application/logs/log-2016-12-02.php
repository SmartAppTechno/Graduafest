<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-02 00:01:31 --> Config Class Initialized
INFO - 2016-12-02 00:01:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 00:01:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 00:01:31 --> Utf8 Class Initialized
INFO - 2016-12-02 00:01:31 --> URI Class Initialized
DEBUG - 2016-12-02 00:01:31 --> No URI present. Default controller set.
INFO - 2016-12-02 00:01:31 --> Router Class Initialized
INFO - 2016-12-02 00:01:31 --> Output Class Initialized
INFO - 2016-12-02 00:01:31 --> Security Class Initialized
DEBUG - 2016-12-02 00:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 00:01:31 --> Input Class Initialized
INFO - 2016-12-02 00:01:31 --> Language Class Initialized
INFO - 2016-12-02 00:01:31 --> Loader Class Initialized
INFO - 2016-12-02 00:01:31 --> Database Driver Class Initialized
INFO - 2016-12-02 00:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 00:01:31 --> Controller Class Initialized
INFO - 2016-12-02 00:01:31 --> Helper loaded: url_helper
DEBUG - 2016-12-02 00:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 00:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 00:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 00:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 00:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 00:01:31 --> Final output sent to browser
DEBUG - 2016-12-02 00:01:31 --> Total execution time: 0.2481
INFO - 2016-12-02 00:01:31 --> Config Class Initialized
INFO - 2016-12-02 00:01:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 00:01:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 00:01:31 --> Utf8 Class Initialized
INFO - 2016-12-02 00:01:31 --> URI Class Initialized
INFO - 2016-12-02 00:01:31 --> Router Class Initialized
INFO - 2016-12-02 00:01:31 --> Output Class Initialized
INFO - 2016-12-02 00:01:31 --> Security Class Initialized
DEBUG - 2016-12-02 00:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 00:01:31 --> Input Class Initialized
INFO - 2016-12-02 00:01:31 --> Language Class Initialized
ERROR - 2016-12-02 00:01:31 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 00:01:31 --> Config Class Initialized
INFO - 2016-12-02 00:01:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 00:01:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 00:01:31 --> Utf8 Class Initialized
INFO - 2016-12-02 00:01:31 --> URI Class Initialized
INFO - 2016-12-02 00:01:31 --> Router Class Initialized
INFO - 2016-12-02 00:01:31 --> Output Class Initialized
INFO - 2016-12-02 00:01:31 --> Security Class Initialized
DEBUG - 2016-12-02 00:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 00:01:31 --> Input Class Initialized
INFO - 2016-12-02 00:01:31 --> Language Class Initialized
ERROR - 2016-12-02 00:01:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 00:01:31 --> Config Class Initialized
INFO - 2016-12-02 00:01:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 00:01:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 00:01:31 --> Utf8 Class Initialized
INFO - 2016-12-02 00:01:31 --> URI Class Initialized
INFO - 2016-12-02 00:01:31 --> Router Class Initialized
INFO - 2016-12-02 00:01:31 --> Output Class Initialized
INFO - 2016-12-02 00:01:31 --> Security Class Initialized
DEBUG - 2016-12-02 00:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 00:01:31 --> Input Class Initialized
INFO - 2016-12-02 00:01:31 --> Language Class Initialized
ERROR - 2016-12-02 00:01:31 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 01:52:38 --> Config Class Initialized
INFO - 2016-12-02 01:52:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 01:52:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 01:52:38 --> Utf8 Class Initialized
INFO - 2016-12-02 01:52:38 --> URI Class Initialized
DEBUG - 2016-12-02 01:52:38 --> No URI present. Default controller set.
INFO - 2016-12-02 01:52:38 --> Router Class Initialized
INFO - 2016-12-02 01:52:38 --> Output Class Initialized
INFO - 2016-12-02 01:52:38 --> Security Class Initialized
DEBUG - 2016-12-02 01:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 01:52:38 --> Input Class Initialized
INFO - 2016-12-02 01:52:38 --> Language Class Initialized
INFO - 2016-12-02 01:52:38 --> Loader Class Initialized
INFO - 2016-12-02 01:52:38 --> Database Driver Class Initialized
INFO - 2016-12-02 01:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 01:52:38 --> Controller Class Initialized
INFO - 2016-12-02 01:52:38 --> Helper loaded: url_helper
DEBUG - 2016-12-02 01:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 01:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 01:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 01:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 01:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 01:52:38 --> Final output sent to browser
DEBUG - 2016-12-02 01:52:38 --> Total execution time: 0.0631
INFO - 2016-12-02 01:52:39 --> Config Class Initialized
INFO - 2016-12-02 01:52:39 --> Hooks Class Initialized
DEBUG - 2016-12-02 01:52:39 --> UTF-8 Support Enabled
INFO - 2016-12-02 01:52:39 --> Utf8 Class Initialized
INFO - 2016-12-02 01:52:39 --> URI Class Initialized
INFO - 2016-12-02 01:52:39 --> Config Class Initialized
INFO - 2016-12-02 01:52:39 --> Hooks Class Initialized
DEBUG - 2016-12-02 01:52:39 --> UTF-8 Support Enabled
INFO - 2016-12-02 01:52:39 --> Utf8 Class Initialized
INFO - 2016-12-02 01:52:39 --> URI Class Initialized
INFO - 2016-12-02 01:52:39 --> Router Class Initialized
INFO - 2016-12-02 01:52:39 --> Output Class Initialized
INFO - 2016-12-02 01:52:39 --> Security Class Initialized
DEBUG - 2016-12-02 01:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 01:52:39 --> Input Class Initialized
INFO - 2016-12-02 01:52:39 --> Language Class Initialized
ERROR - 2016-12-02 01:52:39 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 01:52:39 --> Router Class Initialized
INFO - 2016-12-02 01:52:39 --> Output Class Initialized
INFO - 2016-12-02 01:52:39 --> Security Class Initialized
DEBUG - 2016-12-02 01:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 01:52:39 --> Input Class Initialized
INFO - 2016-12-02 01:52:39 --> Language Class Initialized
ERROR - 2016-12-02 01:52:39 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 01:52:40 --> Config Class Initialized
INFO - 2016-12-02 01:52:40 --> Hooks Class Initialized
DEBUG - 2016-12-02 01:52:40 --> UTF-8 Support Enabled
INFO - 2016-12-02 01:52:40 --> Utf8 Class Initialized
INFO - 2016-12-02 01:52:40 --> URI Class Initialized
INFO - 2016-12-02 01:52:40 --> Router Class Initialized
INFO - 2016-12-02 01:52:40 --> Output Class Initialized
INFO - 2016-12-02 01:52:40 --> Security Class Initialized
DEBUG - 2016-12-02 01:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 01:52:40 --> Input Class Initialized
INFO - 2016-12-02 01:52:40 --> Language Class Initialized
INFO - 2016-12-02 01:52:40 --> Loader Class Initialized
INFO - 2016-12-02 01:52:40 --> Database Driver Class Initialized
INFO - 2016-12-02 01:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 01:52:40 --> Controller Class Initialized
INFO - 2016-12-02 01:52:40 --> Helper loaded: url_helper
DEBUG - 2016-12-02 01:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 01:52:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 01:52:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 01:52:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 01:52:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 01:52:40 --> Final output sent to browser
DEBUG - 2016-12-02 01:52:40 --> Total execution time: 0.0215
INFO - 2016-12-02 02:59:29 --> Config Class Initialized
INFO - 2016-12-02 02:59:29 --> Hooks Class Initialized
DEBUG - 2016-12-02 02:59:29 --> UTF-8 Support Enabled
INFO - 2016-12-02 02:59:29 --> Utf8 Class Initialized
INFO - 2016-12-02 02:59:29 --> URI Class Initialized
DEBUG - 2016-12-02 02:59:29 --> No URI present. Default controller set.
INFO - 2016-12-02 02:59:29 --> Router Class Initialized
INFO - 2016-12-02 02:59:29 --> Output Class Initialized
INFO - 2016-12-02 02:59:29 --> Security Class Initialized
DEBUG - 2016-12-02 02:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 02:59:29 --> Input Class Initialized
INFO - 2016-12-02 02:59:29 --> Language Class Initialized
INFO - 2016-12-02 02:59:29 --> Loader Class Initialized
INFO - 2016-12-02 02:59:29 --> Database Driver Class Initialized
INFO - 2016-12-02 02:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 02:59:29 --> Controller Class Initialized
INFO - 2016-12-02 02:59:29 --> Helper loaded: url_helper
DEBUG - 2016-12-02 02:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 02:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 02:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 02:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 02:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 02:59:29 --> Final output sent to browser
DEBUG - 2016-12-02 02:59:29 --> Total execution time: 0.0131
INFO - 2016-12-02 02:59:31 --> Config Class Initialized
INFO - 2016-12-02 02:59:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 02:59:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 02:59:31 --> Utf8 Class Initialized
INFO - 2016-12-02 02:59:31 --> URI Class Initialized
INFO - 2016-12-02 02:59:31 --> Router Class Initialized
INFO - 2016-12-02 02:59:31 --> Output Class Initialized
INFO - 2016-12-02 02:59:31 --> Security Class Initialized
DEBUG - 2016-12-02 02:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 02:59:31 --> Input Class Initialized
INFO - 2016-12-02 02:59:31 --> Language Class Initialized
INFO - 2016-12-02 02:59:31 --> Loader Class Initialized
INFO - 2016-12-02 02:59:31 --> Database Driver Class Initialized
INFO - 2016-12-02 02:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 02:59:31 --> Controller Class Initialized
INFO - 2016-12-02 02:59:31 --> Helper loaded: url_helper
DEBUG - 2016-12-02 02:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 02:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 02:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 02:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 02:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 02:59:31 --> Final output sent to browser
DEBUG - 2016-12-02 02:59:31 --> Total execution time: 0.0139
INFO - 2016-12-02 02:59:44 --> Config Class Initialized
INFO - 2016-12-02 02:59:44 --> Hooks Class Initialized
DEBUG - 2016-12-02 02:59:44 --> UTF-8 Support Enabled
INFO - 2016-12-02 02:59:44 --> Utf8 Class Initialized
INFO - 2016-12-02 02:59:44 --> URI Class Initialized
DEBUG - 2016-12-02 02:59:44 --> No URI present. Default controller set.
INFO - 2016-12-02 02:59:44 --> Router Class Initialized
INFO - 2016-12-02 02:59:44 --> Output Class Initialized
INFO - 2016-12-02 02:59:44 --> Security Class Initialized
DEBUG - 2016-12-02 02:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 02:59:44 --> Input Class Initialized
INFO - 2016-12-02 02:59:44 --> Language Class Initialized
INFO - 2016-12-02 02:59:44 --> Loader Class Initialized
INFO - 2016-12-02 02:59:44 --> Database Driver Class Initialized
INFO - 2016-12-02 02:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 02:59:44 --> Controller Class Initialized
INFO - 2016-12-02 02:59:44 --> Helper loaded: url_helper
DEBUG - 2016-12-02 02:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 02:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 02:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 02:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 02:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 02:59:44 --> Final output sent to browser
DEBUG - 2016-12-02 02:59:44 --> Total execution time: 0.0411
INFO - 2016-12-02 02:59:45 --> Config Class Initialized
INFO - 2016-12-02 02:59:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 02:59:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 02:59:45 --> Utf8 Class Initialized
INFO - 2016-12-02 02:59:45 --> URI Class Initialized
INFO - 2016-12-02 02:59:45 --> Router Class Initialized
INFO - 2016-12-02 02:59:45 --> Output Class Initialized
INFO - 2016-12-02 02:59:45 --> Security Class Initialized
DEBUG - 2016-12-02 02:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 02:59:45 --> Input Class Initialized
INFO - 2016-12-02 02:59:45 --> Language Class Initialized
ERROR - 2016-12-02 02:59:45 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 02:59:45 --> Config Class Initialized
INFO - 2016-12-02 02:59:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 02:59:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 02:59:45 --> Utf8 Class Initialized
INFO - 2016-12-02 02:59:45 --> URI Class Initialized
INFO - 2016-12-02 02:59:45 --> Router Class Initialized
INFO - 2016-12-02 02:59:45 --> Output Class Initialized
INFO - 2016-12-02 02:59:45 --> Security Class Initialized
DEBUG - 2016-12-02 02:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 02:59:45 --> Input Class Initialized
INFO - 2016-12-02 02:59:45 --> Language Class Initialized
ERROR - 2016-12-02 02:59:45 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 02:59:46 --> Config Class Initialized
INFO - 2016-12-02 02:59:46 --> Hooks Class Initialized
DEBUG - 2016-12-02 02:59:46 --> UTF-8 Support Enabled
INFO - 2016-12-02 02:59:46 --> Utf8 Class Initialized
INFO - 2016-12-02 02:59:46 --> URI Class Initialized
INFO - 2016-12-02 02:59:46 --> Router Class Initialized
INFO - 2016-12-02 02:59:46 --> Output Class Initialized
INFO - 2016-12-02 02:59:46 --> Security Class Initialized
DEBUG - 2016-12-02 02:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 02:59:46 --> Input Class Initialized
INFO - 2016-12-02 02:59:46 --> Language Class Initialized
INFO - 2016-12-02 02:59:46 --> Loader Class Initialized
INFO - 2016-12-02 02:59:46 --> Database Driver Class Initialized
INFO - 2016-12-02 02:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 02:59:46 --> Controller Class Initialized
INFO - 2016-12-02 02:59:46 --> Helper loaded: url_helper
DEBUG - 2016-12-02 02:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 02:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 02:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 02:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 02:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 02:59:46 --> Final output sent to browser
DEBUG - 2016-12-02 02:59:46 --> Total execution time: 0.0131
INFO - 2016-12-02 03:36:12 --> Config Class Initialized
INFO - 2016-12-02 03:36:12 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:36:12 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:36:12 --> Utf8 Class Initialized
INFO - 2016-12-02 03:36:12 --> URI Class Initialized
DEBUG - 2016-12-02 03:36:12 --> No URI present. Default controller set.
INFO - 2016-12-02 03:36:12 --> Router Class Initialized
INFO - 2016-12-02 03:36:12 --> Output Class Initialized
INFO - 2016-12-02 03:36:12 --> Security Class Initialized
DEBUG - 2016-12-02 03:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:36:12 --> Input Class Initialized
INFO - 2016-12-02 03:36:12 --> Language Class Initialized
INFO - 2016-12-02 03:36:12 --> Loader Class Initialized
INFO - 2016-12-02 03:36:12 --> Database Driver Class Initialized
INFO - 2016-12-02 03:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:36:12 --> Controller Class Initialized
INFO - 2016-12-02 03:36:12 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:36:12 --> Final output sent to browser
DEBUG - 2016-12-02 03:36:12 --> Total execution time: 0.0131
INFO - 2016-12-02 03:36:14 --> Config Class Initialized
INFO - 2016-12-02 03:36:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:36:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:36:14 --> Utf8 Class Initialized
INFO - 2016-12-02 03:36:14 --> URI Class Initialized
INFO - 2016-12-02 03:36:14 --> Router Class Initialized
INFO - 2016-12-02 03:36:14 --> Output Class Initialized
INFO - 2016-12-02 03:36:14 --> Security Class Initialized
DEBUG - 2016-12-02 03:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:36:14 --> Input Class Initialized
INFO - 2016-12-02 03:36:14 --> Language Class Initialized
ERROR - 2016-12-02 03:36:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:36:15 --> Config Class Initialized
INFO - 2016-12-02 03:36:15 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:36:15 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:36:15 --> Utf8 Class Initialized
INFO - 2016-12-02 03:36:15 --> URI Class Initialized
INFO - 2016-12-02 03:36:15 --> Router Class Initialized
INFO - 2016-12-02 03:36:15 --> Output Class Initialized
INFO - 2016-12-02 03:36:15 --> Security Class Initialized
DEBUG - 2016-12-02 03:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:36:15 --> Input Class Initialized
INFO - 2016-12-02 03:36:15 --> Language Class Initialized
ERROR - 2016-12-02 03:36:15 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:36:16 --> Config Class Initialized
INFO - 2016-12-02 03:36:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:36:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:36:16 --> Utf8 Class Initialized
INFO - 2016-12-02 03:36:16 --> URI Class Initialized
INFO - 2016-12-02 03:36:16 --> Router Class Initialized
INFO - 2016-12-02 03:36:16 --> Output Class Initialized
INFO - 2016-12-02 03:36:16 --> Security Class Initialized
DEBUG - 2016-12-02 03:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:36:16 --> Input Class Initialized
INFO - 2016-12-02 03:36:16 --> Language Class Initialized
INFO - 2016-12-02 03:36:16 --> Loader Class Initialized
INFO - 2016-12-02 03:36:16 --> Database Driver Class Initialized
INFO - 2016-12-02 03:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:36:16 --> Controller Class Initialized
INFO - 2016-12-02 03:36:16 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:36:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:36:16 --> Final output sent to browser
DEBUG - 2016-12-02 03:36:16 --> Total execution time: 0.0126
INFO - 2016-12-02 03:38:30 --> Config Class Initialized
INFO - 2016-12-02 03:38:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:30 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:30 --> URI Class Initialized
DEBUG - 2016-12-02 03:38:30 --> No URI present. Default controller set.
INFO - 2016-12-02 03:38:30 --> Router Class Initialized
INFO - 2016-12-02 03:38:30 --> Output Class Initialized
INFO - 2016-12-02 03:38:30 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:30 --> Input Class Initialized
INFO - 2016-12-02 03:38:30 --> Language Class Initialized
INFO - 2016-12-02 03:38:30 --> Loader Class Initialized
INFO - 2016-12-02 03:38:30 --> Database Driver Class Initialized
INFO - 2016-12-02 03:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:38:30 --> Controller Class Initialized
INFO - 2016-12-02 03:38:30 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:38:30 --> Final output sent to browser
DEBUG - 2016-12-02 03:38:30 --> Total execution time: 0.0209
INFO - 2016-12-02 03:38:30 --> Config Class Initialized
INFO - 2016-12-02 03:38:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:30 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:30 --> URI Class Initialized
INFO - 2016-12-02 03:38:30 --> Router Class Initialized
INFO - 2016-12-02 03:38:30 --> Output Class Initialized
INFO - 2016-12-02 03:38:30 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:30 --> Input Class Initialized
INFO - 2016-12-02 03:38:30 --> Language Class Initialized
ERROR - 2016-12-02 03:38:30 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:38:30 --> Config Class Initialized
INFO - 2016-12-02 03:38:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:30 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:30 --> URI Class Initialized
INFO - 2016-12-02 03:38:30 --> Router Class Initialized
INFO - 2016-12-02 03:38:30 --> Output Class Initialized
INFO - 2016-12-02 03:38:30 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:30 --> Input Class Initialized
INFO - 2016-12-02 03:38:30 --> Language Class Initialized
ERROR - 2016-12-02 03:38:30 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:38:30 --> Config Class Initialized
INFO - 2016-12-02 03:38:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:30 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:30 --> URI Class Initialized
INFO - 2016-12-02 03:38:30 --> Router Class Initialized
INFO - 2016-12-02 03:38:30 --> Output Class Initialized
INFO - 2016-12-02 03:38:30 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:30 --> Input Class Initialized
INFO - 2016-12-02 03:38:30 --> Language Class Initialized
INFO - 2016-12-02 03:38:30 --> Loader Class Initialized
INFO - 2016-12-02 03:38:30 --> Database Driver Class Initialized
INFO - 2016-12-02 03:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:38:30 --> Controller Class Initialized
INFO - 2016-12-02 03:38:30 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:38:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:38:30 --> Final output sent to browser
DEBUG - 2016-12-02 03:38:30 --> Total execution time: 0.0143
INFO - 2016-12-02 03:38:34 --> Config Class Initialized
INFO - 2016-12-02 03:38:34 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:34 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:34 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:34 --> URI Class Initialized
DEBUG - 2016-12-02 03:38:34 --> No URI present. Default controller set.
INFO - 2016-12-02 03:38:34 --> Router Class Initialized
INFO - 2016-12-02 03:38:34 --> Output Class Initialized
INFO - 2016-12-02 03:38:34 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:34 --> Input Class Initialized
INFO - 2016-12-02 03:38:34 --> Language Class Initialized
INFO - 2016-12-02 03:38:34 --> Loader Class Initialized
INFO - 2016-12-02 03:38:34 --> Database Driver Class Initialized
INFO - 2016-12-02 03:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:38:34 --> Controller Class Initialized
INFO - 2016-12-02 03:38:34 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:38:34 --> Final output sent to browser
DEBUG - 2016-12-02 03:38:34 --> Total execution time: 0.0134
INFO - 2016-12-02 03:38:35 --> Config Class Initialized
INFO - 2016-12-02 03:38:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:35 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:35 --> URI Class Initialized
INFO - 2016-12-02 03:38:35 --> Router Class Initialized
INFO - 2016-12-02 03:38:35 --> Output Class Initialized
INFO - 2016-12-02 03:38:35 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:35 --> Input Class Initialized
INFO - 2016-12-02 03:38:35 --> Language Class Initialized
ERROR - 2016-12-02 03:38:35 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:38:35 --> Config Class Initialized
INFO - 2016-12-02 03:38:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:35 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:35 --> URI Class Initialized
INFO - 2016-12-02 03:38:35 --> Router Class Initialized
INFO - 2016-12-02 03:38:35 --> Output Class Initialized
INFO - 2016-12-02 03:38:35 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:35 --> Input Class Initialized
INFO - 2016-12-02 03:38:35 --> Language Class Initialized
ERROR - 2016-12-02 03:38:35 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:38:35 --> Config Class Initialized
INFO - 2016-12-02 03:38:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:35 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:35 --> URI Class Initialized
INFO - 2016-12-02 03:38:35 --> Router Class Initialized
INFO - 2016-12-02 03:38:35 --> Output Class Initialized
INFO - 2016-12-02 03:38:35 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:35 --> Input Class Initialized
INFO - 2016-12-02 03:38:35 --> Language Class Initialized
INFO - 2016-12-02 03:38:35 --> Loader Class Initialized
INFO - 2016-12-02 03:38:35 --> Database Driver Class Initialized
INFO - 2016-12-02 03:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:38:35 --> Controller Class Initialized
INFO - 2016-12-02 03:38:35 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:38:35 --> Final output sent to browser
DEBUG - 2016-12-02 03:38:35 --> Total execution time: 0.0136
INFO - 2016-12-02 03:38:57 --> Config Class Initialized
INFO - 2016-12-02 03:38:57 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:38:57 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:38:57 --> Utf8 Class Initialized
INFO - 2016-12-02 03:38:57 --> URI Class Initialized
INFO - 2016-12-02 03:38:57 --> Router Class Initialized
INFO - 2016-12-02 03:38:57 --> Output Class Initialized
INFO - 2016-12-02 03:38:57 --> Security Class Initialized
DEBUG - 2016-12-02 03:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:38:57 --> Input Class Initialized
INFO - 2016-12-02 03:38:57 --> Language Class Initialized
ERROR - 2016-12-02 03:38:57 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:40:24 --> Config Class Initialized
INFO - 2016-12-02 03:40:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:40:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:40:24 --> Utf8 Class Initialized
INFO - 2016-12-02 03:40:24 --> URI Class Initialized
DEBUG - 2016-12-02 03:40:24 --> No URI present. Default controller set.
INFO - 2016-12-02 03:40:24 --> Router Class Initialized
INFO - 2016-12-02 03:40:24 --> Output Class Initialized
INFO - 2016-12-02 03:40:24 --> Security Class Initialized
DEBUG - 2016-12-02 03:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:40:24 --> Input Class Initialized
INFO - 2016-12-02 03:40:24 --> Language Class Initialized
INFO - 2016-12-02 03:40:24 --> Loader Class Initialized
INFO - 2016-12-02 03:40:24 --> Database Driver Class Initialized
INFO - 2016-12-02 03:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:40:24 --> Controller Class Initialized
INFO - 2016-12-02 03:40:24 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:40:24 --> Final output sent to browser
DEBUG - 2016-12-02 03:40:24 --> Total execution time: 0.0130
INFO - 2016-12-02 03:40:24 --> Config Class Initialized
INFO - 2016-12-02 03:40:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:40:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:40:24 --> Utf8 Class Initialized
INFO - 2016-12-02 03:40:24 --> URI Class Initialized
INFO - 2016-12-02 03:40:24 --> Router Class Initialized
INFO - 2016-12-02 03:40:24 --> Output Class Initialized
INFO - 2016-12-02 03:40:24 --> Security Class Initialized
DEBUG - 2016-12-02 03:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:40:24 --> Input Class Initialized
INFO - 2016-12-02 03:40:24 --> Language Class Initialized
ERROR - 2016-12-02 03:40:24 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:40:24 --> Config Class Initialized
INFO - 2016-12-02 03:40:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:40:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:40:24 --> Utf8 Class Initialized
INFO - 2016-12-02 03:40:24 --> URI Class Initialized
INFO - 2016-12-02 03:40:24 --> Router Class Initialized
INFO - 2016-12-02 03:40:24 --> Output Class Initialized
INFO - 2016-12-02 03:40:24 --> Security Class Initialized
DEBUG - 2016-12-02 03:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:40:24 --> Input Class Initialized
INFO - 2016-12-02 03:40:24 --> Language Class Initialized
ERROR - 2016-12-02 03:40:24 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:40:24 --> Config Class Initialized
INFO - 2016-12-02 03:40:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:40:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:40:24 --> Utf8 Class Initialized
INFO - 2016-12-02 03:40:24 --> URI Class Initialized
INFO - 2016-12-02 03:40:24 --> Router Class Initialized
INFO - 2016-12-02 03:40:24 --> Output Class Initialized
INFO - 2016-12-02 03:40:24 --> Security Class Initialized
DEBUG - 2016-12-02 03:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:40:24 --> Input Class Initialized
INFO - 2016-12-02 03:40:24 --> Language Class Initialized
INFO - 2016-12-02 03:40:24 --> Loader Class Initialized
INFO - 2016-12-02 03:40:24 --> Database Driver Class Initialized
INFO - 2016-12-02 03:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:40:24 --> Controller Class Initialized
INFO - 2016-12-02 03:40:24 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:40:24 --> Final output sent to browser
DEBUG - 2016-12-02 03:40:24 --> Total execution time: 0.0128
INFO - 2016-12-02 03:41:03 --> Config Class Initialized
INFO - 2016-12-02 03:41:03 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:03 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:03 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:03 --> URI Class Initialized
DEBUG - 2016-12-02 03:41:03 --> No URI present. Default controller set.
INFO - 2016-12-02 03:41:03 --> Router Class Initialized
INFO - 2016-12-02 03:41:03 --> Output Class Initialized
INFO - 2016-12-02 03:41:03 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:03 --> Input Class Initialized
INFO - 2016-12-02 03:41:03 --> Language Class Initialized
INFO - 2016-12-02 03:41:03 --> Loader Class Initialized
INFO - 2016-12-02 03:41:03 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:03 --> Controller Class Initialized
INFO - 2016-12-02 03:41:03 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:03 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:03 --> Total execution time: 0.0131
INFO - 2016-12-02 03:41:03 --> Config Class Initialized
INFO - 2016-12-02 03:41:03 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:03 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:03 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:03 --> URI Class Initialized
INFO - 2016-12-02 03:41:03 --> Router Class Initialized
INFO - 2016-12-02 03:41:03 --> Output Class Initialized
INFO - 2016-12-02 03:41:03 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:03 --> Input Class Initialized
INFO - 2016-12-02 03:41:03 --> Language Class Initialized
ERROR - 2016-12-02 03:41:03 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:03 --> Config Class Initialized
INFO - 2016-12-02 03:41:03 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:03 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:03 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:03 --> URI Class Initialized
INFO - 2016-12-02 03:41:03 --> Router Class Initialized
INFO - 2016-12-02 03:41:03 --> Output Class Initialized
INFO - 2016-12-02 03:41:03 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:03 --> Input Class Initialized
INFO - 2016-12-02 03:41:03 --> Language Class Initialized
ERROR - 2016-12-02 03:41:03 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:03 --> Config Class Initialized
INFO - 2016-12-02 03:41:03 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:03 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:03 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:03 --> URI Class Initialized
INFO - 2016-12-02 03:41:03 --> Router Class Initialized
INFO - 2016-12-02 03:41:03 --> Output Class Initialized
INFO - 2016-12-02 03:41:03 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:03 --> Input Class Initialized
INFO - 2016-12-02 03:41:03 --> Language Class Initialized
INFO - 2016-12-02 03:41:03 --> Loader Class Initialized
INFO - 2016-12-02 03:41:03 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:03 --> Controller Class Initialized
INFO - 2016-12-02 03:41:03 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:03 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:03 --> Total execution time: 0.0131
INFO - 2016-12-02 03:41:07 --> Config Class Initialized
INFO - 2016-12-02 03:41:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:07 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:07 --> URI Class Initialized
DEBUG - 2016-12-02 03:41:07 --> No URI present. Default controller set.
INFO - 2016-12-02 03:41:07 --> Router Class Initialized
INFO - 2016-12-02 03:41:07 --> Output Class Initialized
INFO - 2016-12-02 03:41:07 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:07 --> Input Class Initialized
INFO - 2016-12-02 03:41:07 --> Language Class Initialized
INFO - 2016-12-02 03:41:07 --> Loader Class Initialized
INFO - 2016-12-02 03:41:07 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:07 --> Controller Class Initialized
INFO - 2016-12-02 03:41:07 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:07 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:07 --> Total execution time: 0.0134
INFO - 2016-12-02 03:41:07 --> Config Class Initialized
INFO - 2016-12-02 03:41:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:07 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:07 --> URI Class Initialized
INFO - 2016-12-02 03:41:07 --> Router Class Initialized
INFO - 2016-12-02 03:41:07 --> Output Class Initialized
INFO - 2016-12-02 03:41:07 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:07 --> Input Class Initialized
INFO - 2016-12-02 03:41:07 --> Language Class Initialized
ERROR - 2016-12-02 03:41:07 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:08 --> Config Class Initialized
INFO - 2016-12-02 03:41:08 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:08 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:08 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:08 --> URI Class Initialized
INFO - 2016-12-02 03:41:08 --> Router Class Initialized
INFO - 2016-12-02 03:41:08 --> Output Class Initialized
INFO - 2016-12-02 03:41:08 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:08 --> Input Class Initialized
INFO - 2016-12-02 03:41:08 --> Language Class Initialized
ERROR - 2016-12-02 03:41:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:08 --> Config Class Initialized
INFO - 2016-12-02 03:41:08 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:08 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:08 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:08 --> URI Class Initialized
INFO - 2016-12-02 03:41:08 --> Router Class Initialized
INFO - 2016-12-02 03:41:08 --> Output Class Initialized
INFO - 2016-12-02 03:41:08 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:08 --> Input Class Initialized
INFO - 2016-12-02 03:41:08 --> Language Class Initialized
INFO - 2016-12-02 03:41:08 --> Loader Class Initialized
INFO - 2016-12-02 03:41:08 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:08 --> Controller Class Initialized
INFO - 2016-12-02 03:41:08 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:08 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:08 --> Total execution time: 0.0133
INFO - 2016-12-02 03:41:10 --> Config Class Initialized
INFO - 2016-12-02 03:41:10 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:10 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:10 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:10 --> URI Class Initialized
DEBUG - 2016-12-02 03:41:10 --> No URI present. Default controller set.
INFO - 2016-12-02 03:41:10 --> Router Class Initialized
INFO - 2016-12-02 03:41:10 --> Output Class Initialized
INFO - 2016-12-02 03:41:10 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:10 --> Input Class Initialized
INFO - 2016-12-02 03:41:10 --> Language Class Initialized
INFO - 2016-12-02 03:41:10 --> Loader Class Initialized
INFO - 2016-12-02 03:41:10 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:10 --> Controller Class Initialized
INFO - 2016-12-02 03:41:10 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:10 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:10 --> Total execution time: 0.0135
INFO - 2016-12-02 03:41:11 --> Config Class Initialized
INFO - 2016-12-02 03:41:11 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:11 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:11 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:11 --> URI Class Initialized
INFO - 2016-12-02 03:41:11 --> Router Class Initialized
INFO - 2016-12-02 03:41:11 --> Output Class Initialized
INFO - 2016-12-02 03:41:11 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:11 --> Input Class Initialized
INFO - 2016-12-02 03:41:11 --> Language Class Initialized
ERROR - 2016-12-02 03:41:11 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:11 --> Config Class Initialized
INFO - 2016-12-02 03:41:11 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:11 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:11 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:11 --> URI Class Initialized
INFO - 2016-12-02 03:41:11 --> Router Class Initialized
INFO - 2016-12-02 03:41:11 --> Output Class Initialized
INFO - 2016-12-02 03:41:11 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:11 --> Input Class Initialized
INFO - 2016-12-02 03:41:11 --> Language Class Initialized
ERROR - 2016-12-02 03:41:11 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:11 --> Config Class Initialized
INFO - 2016-12-02 03:41:11 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:11 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:11 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:11 --> URI Class Initialized
INFO - 2016-12-02 03:41:11 --> Router Class Initialized
INFO - 2016-12-02 03:41:11 --> Output Class Initialized
INFO - 2016-12-02 03:41:11 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:11 --> Input Class Initialized
INFO - 2016-12-02 03:41:11 --> Language Class Initialized
INFO - 2016-12-02 03:41:11 --> Loader Class Initialized
INFO - 2016-12-02 03:41:11 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:11 --> Controller Class Initialized
INFO - 2016-12-02 03:41:11 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:11 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:11 --> Total execution time: 0.0129
INFO - 2016-12-02 03:41:16 --> Config Class Initialized
INFO - 2016-12-02 03:41:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:16 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:16 --> URI Class Initialized
INFO - 2016-12-02 03:41:16 --> Router Class Initialized
INFO - 2016-12-02 03:41:16 --> Output Class Initialized
INFO - 2016-12-02 03:41:16 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:16 --> Input Class Initialized
INFO - 2016-12-02 03:41:16 --> Language Class Initialized
ERROR - 2016-12-02 03:41:16 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:41:53 --> Config Class Initialized
INFO - 2016-12-02 03:41:53 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:53 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:53 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:53 --> URI Class Initialized
DEBUG - 2016-12-02 03:41:53 --> No URI present. Default controller set.
INFO - 2016-12-02 03:41:53 --> Router Class Initialized
INFO - 2016-12-02 03:41:53 --> Output Class Initialized
INFO - 2016-12-02 03:41:53 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:53 --> Input Class Initialized
INFO - 2016-12-02 03:41:53 --> Language Class Initialized
INFO - 2016-12-02 03:41:53 --> Loader Class Initialized
INFO - 2016-12-02 03:41:53 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:53 --> Controller Class Initialized
INFO - 2016-12-02 03:41:53 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:53 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:53 --> Total execution time: 0.0129
INFO - 2016-12-02 03:41:54 --> Config Class Initialized
INFO - 2016-12-02 03:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:54 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:54 --> URI Class Initialized
INFO - 2016-12-02 03:41:54 --> Router Class Initialized
INFO - 2016-12-02 03:41:54 --> Output Class Initialized
INFO - 2016-12-02 03:41:54 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:54 --> Input Class Initialized
INFO - 2016-12-02 03:41:54 --> Language Class Initialized
ERROR - 2016-12-02 03:41:54 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:41:54 --> Config Class Initialized
INFO - 2016-12-02 03:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:54 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:54 --> URI Class Initialized
INFO - 2016-12-02 03:41:54 --> Router Class Initialized
INFO - 2016-12-02 03:41:54 --> Output Class Initialized
INFO - 2016-12-02 03:41:54 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:54 --> Input Class Initialized
INFO - 2016-12-02 03:41:54 --> Language Class Initialized
ERROR - 2016-12-02 03:41:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:54 --> Config Class Initialized
INFO - 2016-12-02 03:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:54 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:54 --> URI Class Initialized
INFO - 2016-12-02 03:41:54 --> Router Class Initialized
INFO - 2016-12-02 03:41:54 --> Output Class Initialized
INFO - 2016-12-02 03:41:54 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:54 --> Input Class Initialized
INFO - 2016-12-02 03:41:54 --> Language Class Initialized
ERROR - 2016-12-02 03:41:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:41:54 --> Config Class Initialized
INFO - 2016-12-02 03:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:41:54 --> Utf8 Class Initialized
INFO - 2016-12-02 03:41:54 --> URI Class Initialized
INFO - 2016-12-02 03:41:54 --> Router Class Initialized
INFO - 2016-12-02 03:41:54 --> Output Class Initialized
INFO - 2016-12-02 03:41:54 --> Security Class Initialized
DEBUG - 2016-12-02 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:41:54 --> Input Class Initialized
INFO - 2016-12-02 03:41:54 --> Language Class Initialized
INFO - 2016-12-02 03:41:54 --> Loader Class Initialized
INFO - 2016-12-02 03:41:54 --> Database Driver Class Initialized
INFO - 2016-12-02 03:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:41:54 --> Controller Class Initialized
INFO - 2016-12-02 03:41:54 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:41:54 --> Final output sent to browser
DEBUG - 2016-12-02 03:41:54 --> Total execution time: 0.0403
INFO - 2016-12-02 03:42:36 --> Config Class Initialized
INFO - 2016-12-02 03:42:36 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:42:36 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:42:36 --> Utf8 Class Initialized
INFO - 2016-12-02 03:42:36 --> URI Class Initialized
DEBUG - 2016-12-02 03:42:36 --> No URI present. Default controller set.
INFO - 2016-12-02 03:42:36 --> Router Class Initialized
INFO - 2016-12-02 03:42:36 --> Output Class Initialized
INFO - 2016-12-02 03:42:36 --> Security Class Initialized
DEBUG - 2016-12-02 03:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:42:36 --> Input Class Initialized
INFO - 2016-12-02 03:42:36 --> Language Class Initialized
INFO - 2016-12-02 03:42:36 --> Loader Class Initialized
INFO - 2016-12-02 03:42:36 --> Database Driver Class Initialized
INFO - 2016-12-02 03:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:42:36 --> Controller Class Initialized
INFO - 2016-12-02 03:42:36 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:42:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:42:36 --> Final output sent to browser
DEBUG - 2016-12-02 03:42:36 --> Total execution time: 0.0141
INFO - 2016-12-02 03:42:36 --> Config Class Initialized
INFO - 2016-12-02 03:42:36 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:42:36 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:42:36 --> Utf8 Class Initialized
INFO - 2016-12-02 03:42:36 --> URI Class Initialized
INFO - 2016-12-02 03:42:36 --> Router Class Initialized
INFO - 2016-12-02 03:42:36 --> Output Class Initialized
INFO - 2016-12-02 03:42:36 --> Security Class Initialized
DEBUG - 2016-12-02 03:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:42:36 --> Input Class Initialized
INFO - 2016-12-02 03:42:36 --> Language Class Initialized
ERROR - 2016-12-02 03:42:36 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:42:37 --> Config Class Initialized
INFO - 2016-12-02 03:42:37 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:42:37 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:42:37 --> Utf8 Class Initialized
INFO - 2016-12-02 03:42:37 --> URI Class Initialized
INFO - 2016-12-02 03:42:37 --> Router Class Initialized
INFO - 2016-12-02 03:42:37 --> Output Class Initialized
INFO - 2016-12-02 03:42:37 --> Security Class Initialized
DEBUG - 2016-12-02 03:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:42:37 --> Input Class Initialized
INFO - 2016-12-02 03:42:37 --> Language Class Initialized
ERROR - 2016-12-02 03:42:37 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:42:37 --> Config Class Initialized
INFO - 2016-12-02 03:42:37 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:42:37 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:42:37 --> Utf8 Class Initialized
INFO - 2016-12-02 03:42:37 --> URI Class Initialized
INFO - 2016-12-02 03:42:37 --> Router Class Initialized
INFO - 2016-12-02 03:42:37 --> Output Class Initialized
INFO - 2016-12-02 03:42:37 --> Security Class Initialized
DEBUG - 2016-12-02 03:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:42:37 --> Input Class Initialized
INFO - 2016-12-02 03:42:37 --> Language Class Initialized
ERROR - 2016-12-02 03:42:37 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:42:37 --> Config Class Initialized
INFO - 2016-12-02 03:42:37 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:42:37 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:42:37 --> Utf8 Class Initialized
INFO - 2016-12-02 03:42:37 --> URI Class Initialized
INFO - 2016-12-02 03:42:37 --> Router Class Initialized
INFO - 2016-12-02 03:42:37 --> Output Class Initialized
INFO - 2016-12-02 03:42:37 --> Security Class Initialized
DEBUG - 2016-12-02 03:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:42:37 --> Input Class Initialized
INFO - 2016-12-02 03:42:37 --> Language Class Initialized
INFO - 2016-12-02 03:42:37 --> Loader Class Initialized
INFO - 2016-12-02 03:42:37 --> Database Driver Class Initialized
INFO - 2016-12-02 03:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:42:37 --> Controller Class Initialized
INFO - 2016-12-02 03:42:37 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:42:37 --> Final output sent to browser
DEBUG - 2016-12-02 03:42:37 --> Total execution time: 0.0132
INFO - 2016-12-02 03:43:26 --> Config Class Initialized
INFO - 2016-12-02 03:43:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:43:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:43:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:43:26 --> URI Class Initialized
DEBUG - 2016-12-02 03:43:26 --> No URI present. Default controller set.
INFO - 2016-12-02 03:43:26 --> Router Class Initialized
INFO - 2016-12-02 03:43:26 --> Output Class Initialized
INFO - 2016-12-02 03:43:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:43:26 --> Input Class Initialized
INFO - 2016-12-02 03:43:26 --> Language Class Initialized
INFO - 2016-12-02 03:43:26 --> Loader Class Initialized
INFO - 2016-12-02 03:43:26 --> Database Driver Class Initialized
INFO - 2016-12-02 03:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:43:26 --> Controller Class Initialized
INFO - 2016-12-02 03:43:26 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:43:26 --> Final output sent to browser
DEBUG - 2016-12-02 03:43:26 --> Total execution time: 0.0130
INFO - 2016-12-02 03:43:26 --> Config Class Initialized
INFO - 2016-12-02 03:43:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:43:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:43:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:43:26 --> URI Class Initialized
INFO - 2016-12-02 03:43:26 --> Router Class Initialized
INFO - 2016-12-02 03:43:26 --> Output Class Initialized
INFO - 2016-12-02 03:43:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:43:26 --> Input Class Initialized
INFO - 2016-12-02 03:43:26 --> Language Class Initialized
ERROR - 2016-12-02 03:43:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:43:26 --> Config Class Initialized
INFO - 2016-12-02 03:43:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:43:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:43:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:43:26 --> URI Class Initialized
INFO - 2016-12-02 03:43:26 --> Router Class Initialized
INFO - 2016-12-02 03:43:26 --> Output Class Initialized
INFO - 2016-12-02 03:43:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:43:26 --> Input Class Initialized
INFO - 2016-12-02 03:43:26 --> Language Class Initialized
ERROR - 2016-12-02 03:43:26 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:43:26 --> Config Class Initialized
INFO - 2016-12-02 03:43:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:43:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:43:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:43:26 --> URI Class Initialized
INFO - 2016-12-02 03:43:26 --> Router Class Initialized
INFO - 2016-12-02 03:43:26 --> Output Class Initialized
INFO - 2016-12-02 03:43:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:43:26 --> Input Class Initialized
INFO - 2016-12-02 03:43:26 --> Language Class Initialized
ERROR - 2016-12-02 03:43:26 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:43:26 --> Config Class Initialized
INFO - 2016-12-02 03:43:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:43:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:43:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:43:26 --> URI Class Initialized
INFO - 2016-12-02 03:43:26 --> Router Class Initialized
INFO - 2016-12-02 03:43:26 --> Output Class Initialized
INFO - 2016-12-02 03:43:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:43:26 --> Input Class Initialized
INFO - 2016-12-02 03:43:26 --> Language Class Initialized
INFO - 2016-12-02 03:43:26 --> Loader Class Initialized
INFO - 2016-12-02 03:43:26 --> Database Driver Class Initialized
INFO - 2016-12-02 03:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:43:26 --> Controller Class Initialized
INFO - 2016-12-02 03:43:26 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:43:26 --> Final output sent to browser
DEBUG - 2016-12-02 03:43:26 --> Total execution time: 0.0145
INFO - 2016-12-02 03:43:30 --> Config Class Initialized
INFO - 2016-12-02 03:43:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:43:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:43:30 --> Utf8 Class Initialized
INFO - 2016-12-02 03:43:30 --> URI Class Initialized
DEBUG - 2016-12-02 03:43:30 --> No URI present. Default controller set.
INFO - 2016-12-02 03:43:30 --> Router Class Initialized
INFO - 2016-12-02 03:43:30 --> Output Class Initialized
INFO - 2016-12-02 03:43:30 --> Security Class Initialized
DEBUG - 2016-12-02 03:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:43:30 --> Input Class Initialized
INFO - 2016-12-02 03:43:30 --> Language Class Initialized
INFO - 2016-12-02 03:43:30 --> Loader Class Initialized
INFO - 2016-12-02 03:43:30 --> Database Driver Class Initialized
INFO - 2016-12-02 03:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:43:30 --> Controller Class Initialized
INFO - 2016-12-02 03:43:30 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:43:30 --> Final output sent to browser
DEBUG - 2016-12-02 03:43:30 --> Total execution time: 0.0131
INFO - 2016-12-02 03:46:31 --> Config Class Initialized
INFO - 2016-12-02 03:46:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:31 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:31 --> URI Class Initialized
DEBUG - 2016-12-02 03:46:31 --> No URI present. Default controller set.
INFO - 2016-12-02 03:46:31 --> Router Class Initialized
INFO - 2016-12-02 03:46:31 --> Output Class Initialized
INFO - 2016-12-02 03:46:31 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:31 --> Input Class Initialized
INFO - 2016-12-02 03:46:31 --> Language Class Initialized
INFO - 2016-12-02 03:46:31 --> Loader Class Initialized
INFO - 2016-12-02 03:46:32 --> Database Driver Class Initialized
INFO - 2016-12-02 03:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:46:32 --> Controller Class Initialized
INFO - 2016-12-02 03:46:32 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:46:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:46:32 --> Final output sent to browser
DEBUG - 2016-12-02 03:46:32 --> Total execution time: 0.0133
INFO - 2016-12-02 03:46:38 --> Config Class Initialized
INFO - 2016-12-02 03:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:38 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:38 --> URI Class Initialized
DEBUG - 2016-12-02 03:46:38 --> No URI present. Default controller set.
INFO - 2016-12-02 03:46:38 --> Router Class Initialized
INFO - 2016-12-02 03:46:38 --> Output Class Initialized
INFO - 2016-12-02 03:46:38 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:38 --> Input Class Initialized
INFO - 2016-12-02 03:46:38 --> Language Class Initialized
INFO - 2016-12-02 03:46:38 --> Loader Class Initialized
INFO - 2016-12-02 03:46:38 --> Database Driver Class Initialized
INFO - 2016-12-02 03:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:46:38 --> Controller Class Initialized
INFO - 2016-12-02 03:46:38 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:46:38 --> Final output sent to browser
DEBUG - 2016-12-02 03:46:38 --> Total execution time: 0.0139
INFO - 2016-12-02 03:46:38 --> Config Class Initialized
INFO - 2016-12-02 03:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:38 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:38 --> URI Class Initialized
INFO - 2016-12-02 03:46:38 --> Router Class Initialized
INFO - 2016-12-02 03:46:38 --> Output Class Initialized
INFO - 2016-12-02 03:46:38 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:38 --> Input Class Initialized
INFO - 2016-12-02 03:46:38 --> Language Class Initialized
ERROR - 2016-12-02 03:46:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:46:38 --> Config Class Initialized
INFO - 2016-12-02 03:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:38 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:38 --> URI Class Initialized
INFO - 2016-12-02 03:46:38 --> Router Class Initialized
INFO - 2016-12-02 03:46:38 --> Output Class Initialized
INFO - 2016-12-02 03:46:38 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:38 --> Input Class Initialized
INFO - 2016-12-02 03:46:38 --> Language Class Initialized
ERROR - 2016-12-02 03:46:38 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:46:39 --> Config Class Initialized
INFO - 2016-12-02 03:46:39 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:39 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:39 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:39 --> URI Class Initialized
INFO - 2016-12-02 03:46:39 --> Router Class Initialized
INFO - 2016-12-02 03:46:39 --> Output Class Initialized
INFO - 2016-12-02 03:46:39 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:39 --> Input Class Initialized
INFO - 2016-12-02 03:46:39 --> Language Class Initialized
ERROR - 2016-12-02 03:46:39 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:46:39 --> Config Class Initialized
INFO - 2016-12-02 03:46:39 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:39 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:39 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:39 --> URI Class Initialized
INFO - 2016-12-02 03:46:39 --> Router Class Initialized
INFO - 2016-12-02 03:46:39 --> Output Class Initialized
INFO - 2016-12-02 03:46:39 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:39 --> Input Class Initialized
INFO - 2016-12-02 03:46:39 --> Language Class Initialized
INFO - 2016-12-02 03:46:39 --> Loader Class Initialized
INFO - 2016-12-02 03:46:39 --> Database Driver Class Initialized
INFO - 2016-12-02 03:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:46:39 --> Controller Class Initialized
INFO - 2016-12-02 03:46:39 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:46:39 --> Final output sent to browser
DEBUG - 2016-12-02 03:46:39 --> Total execution time: 0.0695
INFO - 2016-12-02 03:46:50 --> Config Class Initialized
INFO - 2016-12-02 03:46:50 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:50 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:50 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:50 --> URI Class Initialized
INFO - 2016-12-02 03:46:50 --> Router Class Initialized
INFO - 2016-12-02 03:46:50 --> Output Class Initialized
INFO - 2016-12-02 03:46:50 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:50 --> Input Class Initialized
INFO - 2016-12-02 03:46:50 --> Language Class Initialized
ERROR - 2016-12-02 03:46:50 --> 404 Page Not Found: Mail/contact_me.php
INFO - 2016-12-02 03:46:52 --> Config Class Initialized
INFO - 2016-12-02 03:46:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:46:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:46:52 --> Utf8 Class Initialized
INFO - 2016-12-02 03:46:52 --> URI Class Initialized
DEBUG - 2016-12-02 03:46:52 --> No URI present. Default controller set.
INFO - 2016-12-02 03:46:52 --> Router Class Initialized
INFO - 2016-12-02 03:46:52 --> Output Class Initialized
INFO - 2016-12-02 03:46:52 --> Security Class Initialized
DEBUG - 2016-12-02 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:46:52 --> Input Class Initialized
INFO - 2016-12-02 03:46:52 --> Language Class Initialized
INFO - 2016-12-02 03:46:52 --> Loader Class Initialized
INFO - 2016-12-02 03:46:52 --> Database Driver Class Initialized
INFO - 2016-12-02 03:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:46:52 --> Controller Class Initialized
INFO - 2016-12-02 03:46:52 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:46:52 --> Final output sent to browser
DEBUG - 2016-12-02 03:46:52 --> Total execution time: 0.0141
INFO - 2016-12-02 03:48:40 --> Config Class Initialized
INFO - 2016-12-02 03:48:40 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:48:40 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:48:40 --> Utf8 Class Initialized
INFO - 2016-12-02 03:48:40 --> URI Class Initialized
DEBUG - 2016-12-02 03:48:40 --> No URI present. Default controller set.
INFO - 2016-12-02 03:48:40 --> Router Class Initialized
INFO - 2016-12-02 03:48:40 --> Output Class Initialized
INFO - 2016-12-02 03:48:40 --> Security Class Initialized
DEBUG - 2016-12-02 03:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:48:40 --> Input Class Initialized
INFO - 2016-12-02 03:48:40 --> Language Class Initialized
INFO - 2016-12-02 03:48:40 --> Loader Class Initialized
INFO - 2016-12-02 03:48:40 --> Database Driver Class Initialized
INFO - 2016-12-02 03:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:48:41 --> Controller Class Initialized
INFO - 2016-12-02 03:48:41 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:48:41 --> Final output sent to browser
DEBUG - 2016-12-02 03:48:41 --> Total execution time: 0.0137
INFO - 2016-12-02 03:48:41 --> Config Class Initialized
INFO - 2016-12-02 03:48:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:48:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:48:41 --> Utf8 Class Initialized
INFO - 2016-12-02 03:48:41 --> URI Class Initialized
INFO - 2016-12-02 03:48:41 --> Router Class Initialized
INFO - 2016-12-02 03:48:41 --> Output Class Initialized
INFO - 2016-12-02 03:48:41 --> Security Class Initialized
DEBUG - 2016-12-02 03:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:48:41 --> Input Class Initialized
INFO - 2016-12-02 03:48:41 --> Language Class Initialized
ERROR - 2016-12-02 03:48:41 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:48:41 --> Config Class Initialized
INFO - 2016-12-02 03:48:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:48:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:48:41 --> Utf8 Class Initialized
INFO - 2016-12-02 03:48:41 --> URI Class Initialized
INFO - 2016-12-02 03:48:41 --> Router Class Initialized
INFO - 2016-12-02 03:48:41 --> Output Class Initialized
INFO - 2016-12-02 03:48:41 --> Security Class Initialized
DEBUG - 2016-12-02 03:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:48:41 --> Input Class Initialized
INFO - 2016-12-02 03:48:41 --> Language Class Initialized
ERROR - 2016-12-02 03:48:41 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:48:41 --> Config Class Initialized
INFO - 2016-12-02 03:48:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:48:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:48:41 --> Utf8 Class Initialized
INFO - 2016-12-02 03:48:41 --> URI Class Initialized
INFO - 2016-12-02 03:48:41 --> Router Class Initialized
INFO - 2016-12-02 03:48:41 --> Output Class Initialized
INFO - 2016-12-02 03:48:41 --> Security Class Initialized
DEBUG - 2016-12-02 03:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:48:41 --> Input Class Initialized
INFO - 2016-12-02 03:48:41 --> Language Class Initialized
ERROR - 2016-12-02 03:48:41 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:48:41 --> Config Class Initialized
INFO - 2016-12-02 03:48:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:48:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:48:41 --> Utf8 Class Initialized
INFO - 2016-12-02 03:48:41 --> URI Class Initialized
INFO - 2016-12-02 03:48:41 --> Router Class Initialized
INFO - 2016-12-02 03:48:41 --> Output Class Initialized
INFO - 2016-12-02 03:48:41 --> Security Class Initialized
DEBUG - 2016-12-02 03:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:48:41 --> Input Class Initialized
INFO - 2016-12-02 03:48:41 --> Language Class Initialized
INFO - 2016-12-02 03:48:41 --> Loader Class Initialized
INFO - 2016-12-02 03:48:41 --> Database Driver Class Initialized
INFO - 2016-12-02 03:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:48:41 --> Controller Class Initialized
INFO - 2016-12-02 03:48:41 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:48:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:48:41 --> Final output sent to browser
DEBUG - 2016-12-02 03:48:41 --> Total execution time: 0.0147
INFO - 2016-12-02 03:48:47 --> Config Class Initialized
INFO - 2016-12-02 03:48:47 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:48:47 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:48:47 --> Utf8 Class Initialized
INFO - 2016-12-02 03:48:47 --> URI Class Initialized
INFO - 2016-12-02 03:48:47 --> Router Class Initialized
INFO - 2016-12-02 03:48:47 --> Output Class Initialized
INFO - 2016-12-02 03:48:47 --> Security Class Initialized
DEBUG - 2016-12-02 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:48:47 --> Input Class Initialized
INFO - 2016-12-02 03:48:47 --> Language Class Initialized
ERROR - 2016-12-02 03:48:47 --> 404 Page Not Found: Mail/contact_me.php
INFO - 2016-12-02 03:48:49 --> Config Class Initialized
INFO - 2016-12-02 03:48:49 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:48:49 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:48:49 --> Utf8 Class Initialized
INFO - 2016-12-02 03:48:49 --> URI Class Initialized
DEBUG - 2016-12-02 03:48:49 --> No URI present. Default controller set.
INFO - 2016-12-02 03:48:49 --> Router Class Initialized
INFO - 2016-12-02 03:48:49 --> Output Class Initialized
INFO - 2016-12-02 03:48:49 --> Security Class Initialized
DEBUG - 2016-12-02 03:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:48:49 --> Input Class Initialized
INFO - 2016-12-02 03:48:49 --> Language Class Initialized
INFO - 2016-12-02 03:48:49 --> Loader Class Initialized
INFO - 2016-12-02 03:48:49 --> Database Driver Class Initialized
INFO - 2016-12-02 03:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:48:49 --> Controller Class Initialized
INFO - 2016-12-02 03:48:49 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:48:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:48:49 --> Final output sent to browser
DEBUG - 2016-12-02 03:48:49 --> Total execution time: 0.0133
INFO - 2016-12-02 03:49:47 --> Config Class Initialized
INFO - 2016-12-02 03:49:47 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:49:47 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:49:47 --> Utf8 Class Initialized
INFO - 2016-12-02 03:49:47 --> URI Class Initialized
INFO - 2016-12-02 03:49:47 --> Router Class Initialized
INFO - 2016-12-02 03:49:47 --> Output Class Initialized
INFO - 2016-12-02 03:49:47 --> Security Class Initialized
DEBUG - 2016-12-02 03:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:49:47 --> Input Class Initialized
INFO - 2016-12-02 03:49:47 --> Language Class Initialized
INFO - 2016-12-02 03:49:47 --> Loader Class Initialized
INFO - 2016-12-02 03:49:47 --> Database Driver Class Initialized
INFO - 2016-12-02 03:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:49:47 --> Controller Class Initialized
INFO - 2016-12-02 03:49:47 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:49:47 --> Final output sent to browser
DEBUG - 2016-12-02 03:49:47 --> Total execution time: 0.0131
INFO - 2016-12-02 03:49:48 --> Config Class Initialized
INFO - 2016-12-02 03:49:48 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:49:48 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:49:48 --> Utf8 Class Initialized
INFO - 2016-12-02 03:49:48 --> URI Class Initialized
INFO - 2016-12-02 03:49:48 --> Router Class Initialized
INFO - 2016-12-02 03:49:48 --> Output Class Initialized
INFO - 2016-12-02 03:49:48 --> Security Class Initialized
DEBUG - 2016-12-02 03:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:49:48 --> Input Class Initialized
INFO - 2016-12-02 03:49:48 --> Language Class Initialized
ERROR - 2016-12-02 03:49:48 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:49:48 --> Config Class Initialized
INFO - 2016-12-02 03:49:48 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:49:48 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:49:48 --> Utf8 Class Initialized
INFO - 2016-12-02 03:49:48 --> URI Class Initialized
INFO - 2016-12-02 03:49:48 --> Router Class Initialized
INFO - 2016-12-02 03:49:48 --> Output Class Initialized
INFO - 2016-12-02 03:49:48 --> Security Class Initialized
DEBUG - 2016-12-02 03:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:49:48 --> Input Class Initialized
INFO - 2016-12-02 03:49:48 --> Language Class Initialized
ERROR - 2016-12-02 03:49:48 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:49:48 --> Config Class Initialized
INFO - 2016-12-02 03:49:48 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:49:48 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:49:48 --> Utf8 Class Initialized
INFO - 2016-12-02 03:49:48 --> URI Class Initialized
INFO - 2016-12-02 03:49:48 --> Router Class Initialized
INFO - 2016-12-02 03:49:48 --> Output Class Initialized
INFO - 2016-12-02 03:49:48 --> Security Class Initialized
DEBUG - 2016-12-02 03:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:49:48 --> Input Class Initialized
INFO - 2016-12-02 03:49:48 --> Language Class Initialized
INFO - 2016-12-02 03:49:48 --> Loader Class Initialized
INFO - 2016-12-02 03:49:48 --> Database Driver Class Initialized
INFO - 2016-12-02 03:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:49:48 --> Controller Class Initialized
INFO - 2016-12-02 03:49:48 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:49:48 --> Final output sent to browser
DEBUG - 2016-12-02 03:49:48 --> Total execution time: 0.0140
INFO - 2016-12-02 03:50:02 --> Config Class Initialized
INFO - 2016-12-02 03:50:02 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:02 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:02 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:02 --> URI Class Initialized
INFO - 2016-12-02 03:50:02 --> Router Class Initialized
INFO - 2016-12-02 03:50:02 --> Output Class Initialized
INFO - 2016-12-02 03:50:02 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:02 --> Input Class Initialized
INFO - 2016-12-02 03:50:02 --> Language Class Initialized
INFO - 2016-12-02 03:50:02 --> Loader Class Initialized
INFO - 2016-12-02 03:50:02 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:02 --> Controller Class Initialized
INFO - 2016-12-02 03:50:02 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:02 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:02 --> Total execution time: 0.0135
INFO - 2016-12-02 03:50:02 --> Config Class Initialized
INFO - 2016-12-02 03:50:02 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:02 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:02 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:02 --> URI Class Initialized
INFO - 2016-12-02 03:50:02 --> Router Class Initialized
INFO - 2016-12-02 03:50:02 --> Output Class Initialized
INFO - 2016-12-02 03:50:02 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:02 --> Input Class Initialized
INFO - 2016-12-02 03:50:02 --> Language Class Initialized
ERROR - 2016-12-02 03:50:02 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:02 --> Config Class Initialized
INFO - 2016-12-02 03:50:02 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:02 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:02 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:02 --> URI Class Initialized
INFO - 2016-12-02 03:50:02 --> Router Class Initialized
INFO - 2016-12-02 03:50:02 --> Output Class Initialized
INFO - 2016-12-02 03:50:02 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:02 --> Input Class Initialized
INFO - 2016-12-02 03:50:02 --> Language Class Initialized
ERROR - 2016-12-02 03:50:02 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:03 --> Config Class Initialized
INFO - 2016-12-02 03:50:03 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:03 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:03 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:03 --> URI Class Initialized
INFO - 2016-12-02 03:50:03 --> Router Class Initialized
INFO - 2016-12-02 03:50:03 --> Output Class Initialized
INFO - 2016-12-02 03:50:03 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:03 --> Input Class Initialized
INFO - 2016-12-02 03:50:03 --> Language Class Initialized
INFO - 2016-12-02 03:50:03 --> Loader Class Initialized
INFO - 2016-12-02 03:50:03 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:03 --> Controller Class Initialized
INFO - 2016-12-02 03:50:03 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:03 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:03 --> Total execution time: 0.0139
INFO - 2016-12-02 03:50:13 --> Config Class Initialized
INFO - 2016-12-02 03:50:13 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:13 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:13 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:13 --> URI Class Initialized
INFO - 2016-12-02 03:50:13 --> Router Class Initialized
INFO - 2016-12-02 03:50:13 --> Output Class Initialized
INFO - 2016-12-02 03:50:13 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:13 --> Input Class Initialized
INFO - 2016-12-02 03:50:13 --> Language Class Initialized
INFO - 2016-12-02 03:50:13 --> Loader Class Initialized
INFO - 2016-12-02 03:50:13 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:13 --> Controller Class Initialized
INFO - 2016-12-02 03:50:13 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:13 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:13 --> Total execution time: 0.0513
INFO - 2016-12-02 03:50:14 --> Config Class Initialized
INFO - 2016-12-02 03:50:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:14 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:14 --> URI Class Initialized
INFO - 2016-12-02 03:50:14 --> Router Class Initialized
INFO - 2016-12-02 03:50:14 --> Output Class Initialized
INFO - 2016-12-02 03:50:14 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:14 --> Input Class Initialized
INFO - 2016-12-02 03:50:14 --> Language Class Initialized
ERROR - 2016-12-02 03:50:14 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:50:14 --> Config Class Initialized
INFO - 2016-12-02 03:50:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:14 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:14 --> URI Class Initialized
INFO - 2016-12-02 03:50:14 --> Router Class Initialized
INFO - 2016-12-02 03:50:14 --> Output Class Initialized
INFO - 2016-12-02 03:50:14 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:14 --> Input Class Initialized
INFO - 2016-12-02 03:50:14 --> Language Class Initialized
ERROR - 2016-12-02 03:50:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:14 --> Config Class Initialized
INFO - 2016-12-02 03:50:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:14 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:14 --> URI Class Initialized
INFO - 2016-12-02 03:50:14 --> Router Class Initialized
INFO - 2016-12-02 03:50:14 --> Output Class Initialized
INFO - 2016-12-02 03:50:14 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:14 --> Input Class Initialized
INFO - 2016-12-02 03:50:14 --> Language Class Initialized
ERROR - 2016-12-02 03:50:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:14 --> Config Class Initialized
INFO - 2016-12-02 03:50:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:14 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:14 --> URI Class Initialized
INFO - 2016-12-02 03:50:14 --> Router Class Initialized
INFO - 2016-12-02 03:50:14 --> Output Class Initialized
INFO - 2016-12-02 03:50:14 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:14 --> Input Class Initialized
INFO - 2016-12-02 03:50:14 --> Language Class Initialized
INFO - 2016-12-02 03:50:14 --> Loader Class Initialized
INFO - 2016-12-02 03:50:14 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:14 --> Controller Class Initialized
INFO - 2016-12-02 03:50:14 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:14 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:14 --> Total execution time: 0.0147
INFO - 2016-12-02 03:50:19 --> Config Class Initialized
INFO - 2016-12-02 03:50:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:19 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:19 --> URI Class Initialized
DEBUG - 2016-12-02 03:50:19 --> No URI present. Default controller set.
INFO - 2016-12-02 03:50:19 --> Router Class Initialized
INFO - 2016-12-02 03:50:19 --> Output Class Initialized
INFO - 2016-12-02 03:50:19 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:19 --> Input Class Initialized
INFO - 2016-12-02 03:50:19 --> Language Class Initialized
INFO - 2016-12-02 03:50:19 --> Loader Class Initialized
INFO - 2016-12-02 03:50:19 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:19 --> Controller Class Initialized
INFO - 2016-12-02 03:50:19 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:19 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:19 --> Total execution time: 0.0126
INFO - 2016-12-02 03:50:19 --> Config Class Initialized
INFO - 2016-12-02 03:50:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:19 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:19 --> URI Class Initialized
INFO - 2016-12-02 03:50:19 --> Router Class Initialized
INFO - 2016-12-02 03:50:19 --> Output Class Initialized
INFO - 2016-12-02 03:50:19 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:19 --> Input Class Initialized
INFO - 2016-12-02 03:50:19 --> Language Class Initialized
ERROR - 2016-12-02 03:50:19 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:19 --> Config Class Initialized
INFO - 2016-12-02 03:50:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:19 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:19 --> URI Class Initialized
INFO - 2016-12-02 03:50:19 --> Router Class Initialized
INFO - 2016-12-02 03:50:19 --> Output Class Initialized
INFO - 2016-12-02 03:50:19 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:19 --> Input Class Initialized
INFO - 2016-12-02 03:50:19 --> Language Class Initialized
ERROR - 2016-12-02 03:50:19 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:19 --> Config Class Initialized
INFO - 2016-12-02 03:50:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:19 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:19 --> URI Class Initialized
INFO - 2016-12-02 03:50:19 --> Router Class Initialized
INFO - 2016-12-02 03:50:19 --> Output Class Initialized
INFO - 2016-12-02 03:50:19 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:19 --> Input Class Initialized
INFO - 2016-12-02 03:50:19 --> Language Class Initialized
INFO - 2016-12-02 03:50:19 --> Loader Class Initialized
INFO - 2016-12-02 03:50:19 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:19 --> Controller Class Initialized
INFO - 2016-12-02 03:50:19 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:19 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:19 --> Total execution time: 0.0133
INFO - 2016-12-02 03:50:25 --> Config Class Initialized
INFO - 2016-12-02 03:50:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:25 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:25 --> URI Class Initialized
INFO - 2016-12-02 03:50:25 --> Router Class Initialized
INFO - 2016-12-02 03:50:25 --> Output Class Initialized
INFO - 2016-12-02 03:50:25 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:25 --> Input Class Initialized
INFO - 2016-12-02 03:50:25 --> Language Class Initialized
INFO - 2016-12-02 03:50:25 --> Loader Class Initialized
INFO - 2016-12-02 03:50:25 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:25 --> Controller Class Initialized
INFO - 2016-12-02 03:50:25 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:25 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:25 --> Total execution time: 0.0137
INFO - 2016-12-02 03:50:26 --> Config Class Initialized
INFO - 2016-12-02 03:50:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:26 --> URI Class Initialized
INFO - 2016-12-02 03:50:26 --> Router Class Initialized
INFO - 2016-12-02 03:50:26 --> Output Class Initialized
INFO - 2016-12-02 03:50:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:26 --> Input Class Initialized
INFO - 2016-12-02 03:50:26 --> Language Class Initialized
ERROR - 2016-12-02 03:50:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:50:26 --> Config Class Initialized
INFO - 2016-12-02 03:50:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:26 --> URI Class Initialized
INFO - 2016-12-02 03:50:26 --> Router Class Initialized
INFO - 2016-12-02 03:50:26 --> Output Class Initialized
INFO - 2016-12-02 03:50:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:26 --> Input Class Initialized
INFO - 2016-12-02 03:50:26 --> Language Class Initialized
ERROR - 2016-12-02 03:50:26 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:26 --> Config Class Initialized
INFO - 2016-12-02 03:50:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:26 --> URI Class Initialized
INFO - 2016-12-02 03:50:26 --> Router Class Initialized
INFO - 2016-12-02 03:50:26 --> Output Class Initialized
INFO - 2016-12-02 03:50:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:26 --> Input Class Initialized
INFO - 2016-12-02 03:50:26 --> Language Class Initialized
ERROR - 2016-12-02 03:50:26 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:50:26 --> Config Class Initialized
INFO - 2016-12-02 03:50:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:50:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:50:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:50:26 --> URI Class Initialized
INFO - 2016-12-02 03:50:26 --> Router Class Initialized
INFO - 2016-12-02 03:50:26 --> Output Class Initialized
INFO - 2016-12-02 03:50:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:50:26 --> Input Class Initialized
INFO - 2016-12-02 03:50:26 --> Language Class Initialized
INFO - 2016-12-02 03:50:26 --> Loader Class Initialized
INFO - 2016-12-02 03:50:26 --> Database Driver Class Initialized
INFO - 2016-12-02 03:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:50:26 --> Controller Class Initialized
INFO - 2016-12-02 03:50:26 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:50:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:50:26 --> Final output sent to browser
DEBUG - 2016-12-02 03:50:26 --> Total execution time: 0.0161
INFO - 2016-12-02 03:55:18 --> Config Class Initialized
INFO - 2016-12-02 03:55:18 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:55:18 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:55:18 --> Utf8 Class Initialized
INFO - 2016-12-02 03:55:18 --> URI Class Initialized
DEBUG - 2016-12-02 03:55:18 --> No URI present. Default controller set.
INFO - 2016-12-02 03:55:18 --> Router Class Initialized
INFO - 2016-12-02 03:55:18 --> Output Class Initialized
INFO - 2016-12-02 03:55:18 --> Security Class Initialized
DEBUG - 2016-12-02 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:55:18 --> Input Class Initialized
INFO - 2016-12-02 03:55:18 --> Language Class Initialized
INFO - 2016-12-02 03:55:18 --> Loader Class Initialized
INFO - 2016-12-02 03:55:18 --> Database Driver Class Initialized
INFO - 2016-12-02 03:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:55:18 --> Controller Class Initialized
INFO - 2016-12-02 03:55:18 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:55:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:55:18 --> Final output sent to browser
DEBUG - 2016-12-02 03:55:18 --> Total execution time: 0.0128
INFO - 2016-12-02 03:55:19 --> Config Class Initialized
INFO - 2016-12-02 03:55:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:55:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:55:19 --> Utf8 Class Initialized
INFO - 2016-12-02 03:55:19 --> URI Class Initialized
INFO - 2016-12-02 03:55:19 --> Router Class Initialized
INFO - 2016-12-02 03:55:19 --> Output Class Initialized
INFO - 2016-12-02 03:55:19 --> Security Class Initialized
DEBUG - 2016-12-02 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:55:19 --> Input Class Initialized
INFO - 2016-12-02 03:55:19 --> Language Class Initialized
ERROR - 2016-12-02 03:55:19 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 03:55:19 --> Config Class Initialized
INFO - 2016-12-02 03:55:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:55:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:55:19 --> Utf8 Class Initialized
INFO - 2016-12-02 03:55:19 --> URI Class Initialized
INFO - 2016-12-02 03:55:19 --> Router Class Initialized
INFO - 2016-12-02 03:55:19 --> Output Class Initialized
INFO - 2016-12-02 03:55:19 --> Security Class Initialized
DEBUG - 2016-12-02 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:55:19 --> Input Class Initialized
INFO - 2016-12-02 03:55:19 --> Language Class Initialized
ERROR - 2016-12-02 03:55:19 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:55:19 --> Config Class Initialized
INFO - 2016-12-02 03:55:19 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:55:19 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:55:19 --> Utf8 Class Initialized
INFO - 2016-12-02 03:55:19 --> URI Class Initialized
INFO - 2016-12-02 03:55:19 --> Router Class Initialized
INFO - 2016-12-02 03:55:19 --> Output Class Initialized
INFO - 2016-12-02 03:55:19 --> Security Class Initialized
DEBUG - 2016-12-02 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:55:19 --> Input Class Initialized
INFO - 2016-12-02 03:55:19 --> Language Class Initialized
ERROR - 2016-12-02 03:55:19 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 03:55:20 --> Config Class Initialized
INFO - 2016-12-02 03:55:20 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:55:20 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:55:20 --> Utf8 Class Initialized
INFO - 2016-12-02 03:55:20 --> URI Class Initialized
INFO - 2016-12-02 03:55:20 --> Router Class Initialized
INFO - 2016-12-02 03:55:20 --> Output Class Initialized
INFO - 2016-12-02 03:55:20 --> Security Class Initialized
DEBUG - 2016-12-02 03:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:55:20 --> Input Class Initialized
INFO - 2016-12-02 03:55:20 --> Language Class Initialized
INFO - 2016-12-02 03:55:20 --> Loader Class Initialized
INFO - 2016-12-02 03:55:20 --> Database Driver Class Initialized
INFO - 2016-12-02 03:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:55:20 --> Controller Class Initialized
INFO - 2016-12-02 03:55:20 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:55:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:55:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:55:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:55:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:55:20 --> Final output sent to browser
DEBUG - 2016-12-02 03:55:20 --> Total execution time: 0.0134
INFO - 2016-12-02 03:55:26 --> Config Class Initialized
INFO - 2016-12-02 03:55:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:55:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:55:26 --> Utf8 Class Initialized
INFO - 2016-12-02 03:55:26 --> URI Class Initialized
INFO - 2016-12-02 03:55:26 --> Router Class Initialized
INFO - 2016-12-02 03:55:26 --> Output Class Initialized
INFO - 2016-12-02 03:55:26 --> Security Class Initialized
DEBUG - 2016-12-02 03:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:55:26 --> Input Class Initialized
INFO - 2016-12-02 03:55:26 --> Language Class Initialized
ERROR - 2016-12-02 03:55:26 --> 404 Page Not Found: Mail/contact_me.php
INFO - 2016-12-02 03:55:29 --> Config Class Initialized
INFO - 2016-12-02 03:55:29 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:55:29 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:55:29 --> Utf8 Class Initialized
INFO - 2016-12-02 03:55:29 --> URI Class Initialized
DEBUG - 2016-12-02 03:55:29 --> No URI present. Default controller set.
INFO - 2016-12-02 03:55:29 --> Router Class Initialized
INFO - 2016-12-02 03:55:29 --> Output Class Initialized
INFO - 2016-12-02 03:55:29 --> Security Class Initialized
DEBUG - 2016-12-02 03:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:55:29 --> Input Class Initialized
INFO - 2016-12-02 03:55:29 --> Language Class Initialized
INFO - 2016-12-02 03:55:29 --> Loader Class Initialized
INFO - 2016-12-02 03:55:29 --> Database Driver Class Initialized
INFO - 2016-12-02 03:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:55:29 --> Controller Class Initialized
INFO - 2016-12-02 03:55:29 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:55:29 --> Final output sent to browser
DEBUG - 2016-12-02 03:55:29 --> Total execution time: 0.4935
INFO - 2016-12-02 03:56:35 --> Config Class Initialized
INFO - 2016-12-02 03:56:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:56:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:56:35 --> Utf8 Class Initialized
INFO - 2016-12-02 03:56:35 --> URI Class Initialized
INFO - 2016-12-02 03:56:35 --> Router Class Initialized
INFO - 2016-12-02 03:56:35 --> Output Class Initialized
INFO - 2016-12-02 03:56:35 --> Security Class Initialized
DEBUG - 2016-12-02 03:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:56:35 --> Input Class Initialized
INFO - 2016-12-02 03:56:35 --> Language Class Initialized
ERROR - 2016-12-02 03:56:35 --> 404 Page Not Found: Mail/contact_me.php
INFO - 2016-12-02 03:57:41 --> Config Class Initialized
INFO - 2016-12-02 03:57:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:57:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:57:41 --> Utf8 Class Initialized
INFO - 2016-12-02 03:57:41 --> URI Class Initialized
DEBUG - 2016-12-02 03:57:41 --> No URI present. Default controller set.
INFO - 2016-12-02 03:57:41 --> Router Class Initialized
INFO - 2016-12-02 03:57:41 --> Output Class Initialized
INFO - 2016-12-02 03:57:41 --> Security Class Initialized
DEBUG - 2016-12-02 03:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:57:41 --> Input Class Initialized
INFO - 2016-12-02 03:57:41 --> Language Class Initialized
INFO - 2016-12-02 03:57:41 --> Loader Class Initialized
INFO - 2016-12-02 03:57:41 --> Database Driver Class Initialized
INFO - 2016-12-02 03:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:57:41 --> Controller Class Initialized
INFO - 2016-12-02 03:57:41 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 03:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 03:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 03:57:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 03:57:41 --> Final output sent to browser
DEBUG - 2016-12-02 03:57:41 --> Total execution time: 0.0128
INFO - 2016-12-02 03:59:00 --> Config Class Initialized
INFO - 2016-12-02 03:59:00 --> Hooks Class Initialized
DEBUG - 2016-12-02 03:59:00 --> UTF-8 Support Enabled
INFO - 2016-12-02 03:59:00 --> Utf8 Class Initialized
INFO - 2016-12-02 03:59:00 --> URI Class Initialized
INFO - 2016-12-02 03:59:00 --> Router Class Initialized
INFO - 2016-12-02 03:59:00 --> Output Class Initialized
INFO - 2016-12-02 03:59:00 --> Security Class Initialized
DEBUG - 2016-12-02 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 03:59:00 --> Input Class Initialized
INFO - 2016-12-02 03:59:00 --> Language Class Initialized
INFO - 2016-12-02 03:59:00 --> Loader Class Initialized
INFO - 2016-12-02 03:59:00 --> Database Driver Class Initialized
INFO - 2016-12-02 03:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 03:59:00 --> Controller Class Initialized
INFO - 2016-12-02 03:59:00 --> Helper loaded: url_helper
DEBUG - 2016-12-02 03:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 03:59:00 --> Final output sent to browser
DEBUG - 2016-12-02 03:59:00 --> Total execution time: 0.0129
INFO - 2016-12-02 04:02:52 --> Config Class Initialized
INFO - 2016-12-02 04:02:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:52 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:52 --> URI Class Initialized
INFO - 2016-12-02 04:02:52 --> Router Class Initialized
INFO - 2016-12-02 04:02:52 --> Output Class Initialized
INFO - 2016-12-02 04:02:52 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:52 --> Input Class Initialized
INFO - 2016-12-02 04:02:52 --> Language Class Initialized
INFO - 2016-12-02 04:02:52 --> Loader Class Initialized
INFO - 2016-12-02 04:02:52 --> Database Driver Class Initialized
INFO - 2016-12-02 04:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:02:52 --> Controller Class Initialized
INFO - 2016-12-02 04:02:52 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:02:52 --> Final output sent to browser
DEBUG - 2016-12-02 04:02:52 --> Total execution time: 0.0134
INFO - 2016-12-02 04:02:52 --> Config Class Initialized
INFO - 2016-12-02 04:02:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:52 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:52 --> URI Class Initialized
INFO - 2016-12-02 04:02:52 --> Router Class Initialized
INFO - 2016-12-02 04:02:52 --> Output Class Initialized
INFO - 2016-12-02 04:02:52 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:52 --> Input Class Initialized
INFO - 2016-12-02 04:02:52 --> Language Class Initialized
ERROR - 2016-12-02 04:02:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:02:52 --> Config Class Initialized
INFO - 2016-12-02 04:02:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:52 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:52 --> URI Class Initialized
INFO - 2016-12-02 04:02:52 --> Router Class Initialized
INFO - 2016-12-02 04:02:52 --> Output Class Initialized
INFO - 2016-12-02 04:02:52 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:52 --> Input Class Initialized
INFO - 2016-12-02 04:02:52 --> Language Class Initialized
ERROR - 2016-12-02 04:02:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:02:52 --> Config Class Initialized
INFO - 2016-12-02 04:02:52 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:52 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:52 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:52 --> URI Class Initialized
INFO - 2016-12-02 04:02:52 --> Router Class Initialized
INFO - 2016-12-02 04:02:52 --> Output Class Initialized
INFO - 2016-12-02 04:02:52 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:52 --> Input Class Initialized
INFO - 2016-12-02 04:02:52 --> Language Class Initialized
INFO - 2016-12-02 04:02:52 --> Loader Class Initialized
INFO - 2016-12-02 04:02:52 --> Database Driver Class Initialized
INFO - 2016-12-02 04:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:02:52 --> Controller Class Initialized
INFO - 2016-12-02 04:02:52 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:02:52 --> Final output sent to browser
DEBUG - 2016-12-02 04:02:52 --> Total execution time: 0.0132
INFO - 2016-12-02 04:02:56 --> Config Class Initialized
INFO - 2016-12-02 04:02:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:56 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:56 --> URI Class Initialized
DEBUG - 2016-12-02 04:02:56 --> No URI present. Default controller set.
INFO - 2016-12-02 04:02:56 --> Router Class Initialized
INFO - 2016-12-02 04:02:56 --> Output Class Initialized
INFO - 2016-12-02 04:02:56 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:56 --> Input Class Initialized
INFO - 2016-12-02 04:02:56 --> Language Class Initialized
INFO - 2016-12-02 04:02:56 --> Loader Class Initialized
INFO - 2016-12-02 04:02:56 --> Database Driver Class Initialized
INFO - 2016-12-02 04:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:02:56 --> Controller Class Initialized
INFO - 2016-12-02 04:02:56 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:02:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:02:56 --> Final output sent to browser
DEBUG - 2016-12-02 04:02:56 --> Total execution time: 0.0131
INFO - 2016-12-02 04:02:56 --> Config Class Initialized
INFO - 2016-12-02 04:02:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:56 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:56 --> URI Class Initialized
INFO - 2016-12-02 04:02:56 --> Router Class Initialized
INFO - 2016-12-02 04:02:56 --> Output Class Initialized
INFO - 2016-12-02 04:02:56 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:56 --> Input Class Initialized
INFO - 2016-12-02 04:02:56 --> Language Class Initialized
ERROR - 2016-12-02 04:02:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 04:02:56 --> Config Class Initialized
INFO - 2016-12-02 04:02:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:56 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:56 --> URI Class Initialized
INFO - 2016-12-02 04:02:56 --> Router Class Initialized
INFO - 2016-12-02 04:02:56 --> Output Class Initialized
INFO - 2016-12-02 04:02:56 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:56 --> Input Class Initialized
INFO - 2016-12-02 04:02:56 --> Language Class Initialized
ERROR - 2016-12-02 04:02:56 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:02:56 --> Config Class Initialized
INFO - 2016-12-02 04:02:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:56 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:56 --> URI Class Initialized
INFO - 2016-12-02 04:02:56 --> Router Class Initialized
INFO - 2016-12-02 04:02:56 --> Output Class Initialized
INFO - 2016-12-02 04:02:56 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:56 --> Input Class Initialized
INFO - 2016-12-02 04:02:56 --> Language Class Initialized
ERROR - 2016-12-02 04:02:56 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:02:56 --> Config Class Initialized
INFO - 2016-12-02 04:02:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:56 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:56 --> URI Class Initialized
INFO - 2016-12-02 04:02:56 --> Router Class Initialized
INFO - 2016-12-02 04:02:56 --> Output Class Initialized
INFO - 2016-12-02 04:02:56 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:56 --> Input Class Initialized
INFO - 2016-12-02 04:02:56 --> Language Class Initialized
ERROR - 2016-12-02 04:02:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 04:02:57 --> Config Class Initialized
INFO - 2016-12-02 04:02:57 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:02:57 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:02:57 --> Utf8 Class Initialized
INFO - 2016-12-02 04:02:57 --> URI Class Initialized
INFO - 2016-12-02 04:02:57 --> Router Class Initialized
INFO - 2016-12-02 04:02:57 --> Output Class Initialized
INFO - 2016-12-02 04:02:57 --> Security Class Initialized
DEBUG - 2016-12-02 04:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:02:57 --> Input Class Initialized
INFO - 2016-12-02 04:02:57 --> Language Class Initialized
INFO - 2016-12-02 04:02:57 --> Loader Class Initialized
INFO - 2016-12-02 04:02:57 --> Database Driver Class Initialized
INFO - 2016-12-02 04:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:02:57 --> Controller Class Initialized
INFO - 2016-12-02 04:02:57 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:02:57 --> Final output sent to browser
DEBUG - 2016-12-02 04:02:57 --> Total execution time: 0.0157
INFO - 2016-12-02 04:03:07 --> Config Class Initialized
INFO - 2016-12-02 04:03:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:07 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:07 --> URI Class Initialized
INFO - 2016-12-02 04:03:07 --> Router Class Initialized
INFO - 2016-12-02 04:03:07 --> Output Class Initialized
INFO - 2016-12-02 04:03:07 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:07 --> Input Class Initialized
INFO - 2016-12-02 04:03:07 --> Language Class Initialized
ERROR - 2016-12-02 04:03:07 --> 404 Page Not Found: Mail/contact_me.php
INFO - 2016-12-02 04:03:10 --> Config Class Initialized
INFO - 2016-12-02 04:03:10 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:10 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:10 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:10 --> URI Class Initialized
DEBUG - 2016-12-02 04:03:10 --> No URI present. Default controller set.
INFO - 2016-12-02 04:03:10 --> Router Class Initialized
INFO - 2016-12-02 04:03:10 --> Output Class Initialized
INFO - 2016-12-02 04:03:10 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:10 --> Input Class Initialized
INFO - 2016-12-02 04:03:10 --> Language Class Initialized
INFO - 2016-12-02 04:03:10 --> Loader Class Initialized
INFO - 2016-12-02 04:03:10 --> Database Driver Class Initialized
INFO - 2016-12-02 04:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:03:10 --> Controller Class Initialized
INFO - 2016-12-02 04:03:10 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:03:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:03:10 --> Final output sent to browser
DEBUG - 2016-12-02 04:03:10 --> Total execution time: 0.0464
INFO - 2016-12-02 04:03:35 --> Config Class Initialized
INFO - 2016-12-02 04:03:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:35 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:35 --> URI Class Initialized
DEBUG - 2016-12-02 04:03:35 --> No URI present. Default controller set.
INFO - 2016-12-02 04:03:35 --> Router Class Initialized
INFO - 2016-12-02 04:03:35 --> Output Class Initialized
INFO - 2016-12-02 04:03:35 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:35 --> Input Class Initialized
INFO - 2016-12-02 04:03:35 --> Language Class Initialized
INFO - 2016-12-02 04:03:35 --> Loader Class Initialized
INFO - 2016-12-02 04:03:35 --> Database Driver Class Initialized
INFO - 2016-12-02 04:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:03:35 --> Controller Class Initialized
INFO - 2016-12-02 04:03:35 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:03:35 --> Final output sent to browser
DEBUG - 2016-12-02 04:03:35 --> Total execution time: 0.0133
INFO - 2016-12-02 04:03:35 --> Config Class Initialized
INFO - 2016-12-02 04:03:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:35 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:35 --> URI Class Initialized
INFO - 2016-12-02 04:03:35 --> Router Class Initialized
INFO - 2016-12-02 04:03:35 --> Output Class Initialized
INFO - 2016-12-02 04:03:35 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:35 --> Input Class Initialized
INFO - 2016-12-02 04:03:35 --> Language Class Initialized
ERROR - 2016-12-02 04:03:35 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:03:35 --> Config Class Initialized
INFO - 2016-12-02 04:03:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:35 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:35 --> URI Class Initialized
INFO - 2016-12-02 04:03:35 --> Router Class Initialized
INFO - 2016-12-02 04:03:35 --> Output Class Initialized
INFO - 2016-12-02 04:03:35 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:35 --> Input Class Initialized
INFO - 2016-12-02 04:03:35 --> Language Class Initialized
ERROR - 2016-12-02 04:03:35 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:03:35 --> Config Class Initialized
INFO - 2016-12-02 04:03:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:35 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:35 --> URI Class Initialized
INFO - 2016-12-02 04:03:35 --> Router Class Initialized
INFO - 2016-12-02 04:03:35 --> Output Class Initialized
INFO - 2016-12-02 04:03:35 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:35 --> Input Class Initialized
INFO - 2016-12-02 04:03:35 --> Language Class Initialized
INFO - 2016-12-02 04:03:35 --> Loader Class Initialized
INFO - 2016-12-02 04:03:35 --> Database Driver Class Initialized
INFO - 2016-12-02 04:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:03:35 --> Controller Class Initialized
INFO - 2016-12-02 04:03:35 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:03:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:03:35 --> Final output sent to browser
DEBUG - 2016-12-02 04:03:35 --> Total execution time: 0.0137
INFO - 2016-12-02 04:03:41 --> Config Class Initialized
INFO - 2016-12-02 04:03:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:41 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:41 --> URI Class Initialized
INFO - 2016-12-02 04:03:41 --> Router Class Initialized
INFO - 2016-12-02 04:03:41 --> Output Class Initialized
INFO - 2016-12-02 04:03:41 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:41 --> Input Class Initialized
INFO - 2016-12-02 04:03:41 --> Language Class Initialized
ERROR - 2016-12-02 04:03:41 --> 404 Page Not Found: Mail/contact_me.php
INFO - 2016-12-02 04:03:50 --> Config Class Initialized
INFO - 2016-12-02 04:03:50 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:50 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:50 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:50 --> URI Class Initialized
DEBUG - 2016-12-02 04:03:50 --> No URI present. Default controller set.
INFO - 2016-12-02 04:03:50 --> Router Class Initialized
INFO - 2016-12-02 04:03:50 --> Output Class Initialized
INFO - 2016-12-02 04:03:50 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:50 --> Input Class Initialized
INFO - 2016-12-02 04:03:50 --> Language Class Initialized
INFO - 2016-12-02 04:03:50 --> Loader Class Initialized
INFO - 2016-12-02 04:03:50 --> Database Driver Class Initialized
INFO - 2016-12-02 04:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:03:50 --> Controller Class Initialized
INFO - 2016-12-02 04:03:50 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:03:50 --> Final output sent to browser
DEBUG - 2016-12-02 04:03:50 --> Total execution time: 0.0135
INFO - 2016-12-02 04:03:58 --> Config Class Initialized
INFO - 2016-12-02 04:03:58 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:03:58 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:03:58 --> Utf8 Class Initialized
INFO - 2016-12-02 04:03:58 --> URI Class Initialized
INFO - 2016-12-02 04:03:58 --> Router Class Initialized
INFO - 2016-12-02 04:03:58 --> Output Class Initialized
INFO - 2016-12-02 04:03:58 --> Security Class Initialized
DEBUG - 2016-12-02 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:03:58 --> Input Class Initialized
INFO - 2016-12-02 04:03:58 --> Language Class Initialized
ERROR - 2016-12-02 04:03:58 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 04:05:13 --> Config Class Initialized
INFO - 2016-12-02 04:05:13 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:05:13 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:05:13 --> Utf8 Class Initialized
INFO - 2016-12-02 04:05:13 --> URI Class Initialized
DEBUG - 2016-12-02 04:05:13 --> No URI present. Default controller set.
INFO - 2016-12-02 04:05:13 --> Router Class Initialized
INFO - 2016-12-02 04:05:13 --> Output Class Initialized
INFO - 2016-12-02 04:05:13 --> Security Class Initialized
DEBUG - 2016-12-02 04:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:05:13 --> Input Class Initialized
INFO - 2016-12-02 04:05:13 --> Language Class Initialized
INFO - 2016-12-02 04:05:13 --> Loader Class Initialized
INFO - 2016-12-02 04:05:13 --> Database Driver Class Initialized
INFO - 2016-12-02 04:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:05:13 --> Controller Class Initialized
INFO - 2016-12-02 04:05:13 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:05:13 --> Final output sent to browser
DEBUG - 2016-12-02 04:05:13 --> Total execution time: 0.0129
INFO - 2016-12-02 04:05:14 --> Config Class Initialized
INFO - 2016-12-02 04:05:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:05:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:05:14 --> Utf8 Class Initialized
INFO - 2016-12-02 04:05:14 --> URI Class Initialized
INFO - 2016-12-02 04:05:14 --> Router Class Initialized
INFO - 2016-12-02 04:05:14 --> Output Class Initialized
INFO - 2016-12-02 04:05:14 --> Security Class Initialized
DEBUG - 2016-12-02 04:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:05:14 --> Input Class Initialized
INFO - 2016-12-02 04:05:14 --> Language Class Initialized
ERROR - 2016-12-02 04:05:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:05:14 --> Config Class Initialized
INFO - 2016-12-02 04:05:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:05:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:05:14 --> Utf8 Class Initialized
INFO - 2016-12-02 04:05:14 --> URI Class Initialized
INFO - 2016-12-02 04:05:14 --> Router Class Initialized
INFO - 2016-12-02 04:05:14 --> Output Class Initialized
INFO - 2016-12-02 04:05:14 --> Security Class Initialized
DEBUG - 2016-12-02 04:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:05:14 --> Input Class Initialized
INFO - 2016-12-02 04:05:14 --> Language Class Initialized
ERROR - 2016-12-02 04:05:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:05:14 --> Config Class Initialized
INFO - 2016-12-02 04:05:14 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:05:14 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:05:14 --> Utf8 Class Initialized
INFO - 2016-12-02 04:05:14 --> URI Class Initialized
INFO - 2016-12-02 04:05:14 --> Router Class Initialized
INFO - 2016-12-02 04:05:14 --> Output Class Initialized
INFO - 2016-12-02 04:05:14 --> Security Class Initialized
DEBUG - 2016-12-02 04:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:05:14 --> Input Class Initialized
INFO - 2016-12-02 04:05:14 --> Language Class Initialized
INFO - 2016-12-02 04:05:14 --> Loader Class Initialized
INFO - 2016-12-02 04:05:14 --> Database Driver Class Initialized
INFO - 2016-12-02 04:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:05:14 --> Controller Class Initialized
INFO - 2016-12-02 04:05:14 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:05:14 --> Final output sent to browser
DEBUG - 2016-12-02 04:05:14 --> Total execution time: 0.0131
INFO - 2016-12-02 04:05:23 --> Config Class Initialized
INFO - 2016-12-02 04:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:05:23 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:05:23 --> Utf8 Class Initialized
INFO - 2016-12-02 04:05:23 --> URI Class Initialized
INFO - 2016-12-02 04:05:23 --> Router Class Initialized
INFO - 2016-12-02 04:05:23 --> Output Class Initialized
INFO - 2016-12-02 04:05:23 --> Security Class Initialized
DEBUG - 2016-12-02 04:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:05:23 --> Input Class Initialized
INFO - 2016-12-02 04:05:23 --> Language Class Initialized
ERROR - 2016-12-02 04:05:23 --> 404 Page Not Found: Mail/contact_me.php
INFO - 2016-12-02 04:05:25 --> Config Class Initialized
INFO - 2016-12-02 04:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:05:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:05:25 --> Utf8 Class Initialized
INFO - 2016-12-02 04:05:25 --> URI Class Initialized
DEBUG - 2016-12-02 04:05:25 --> No URI present. Default controller set.
INFO - 2016-12-02 04:05:25 --> Router Class Initialized
INFO - 2016-12-02 04:05:25 --> Output Class Initialized
INFO - 2016-12-02 04:05:25 --> Security Class Initialized
DEBUG - 2016-12-02 04:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:05:25 --> Input Class Initialized
INFO - 2016-12-02 04:05:25 --> Language Class Initialized
INFO - 2016-12-02 04:05:25 --> Loader Class Initialized
INFO - 2016-12-02 04:05:25 --> Database Driver Class Initialized
INFO - 2016-12-02 04:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:05:25 --> Controller Class Initialized
INFO - 2016-12-02 04:05:25 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:05:25 --> Final output sent to browser
DEBUG - 2016-12-02 04:05:25 --> Total execution time: 0.0134
INFO - 2016-12-02 04:05:33 --> Config Class Initialized
INFO - 2016-12-02 04:05:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:05:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:05:33 --> Utf8 Class Initialized
INFO - 2016-12-02 04:05:33 --> URI Class Initialized
INFO - 2016-12-02 04:05:33 --> Router Class Initialized
INFO - 2016-12-02 04:05:33 --> Output Class Initialized
INFO - 2016-12-02 04:05:33 --> Security Class Initialized
DEBUG - 2016-12-02 04:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:05:33 --> Input Class Initialized
INFO - 2016-12-02 04:05:33 --> Language Class Initialized
ERROR - 2016-12-02 04:05:33 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 04:06:11 --> Config Class Initialized
INFO - 2016-12-02 04:06:11 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:06:11 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:06:11 --> Utf8 Class Initialized
INFO - 2016-12-02 04:06:11 --> URI Class Initialized
INFO - 2016-12-02 04:06:11 --> Router Class Initialized
INFO - 2016-12-02 04:06:11 --> Output Class Initialized
INFO - 2016-12-02 04:06:11 --> Security Class Initialized
DEBUG - 2016-12-02 04:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:06:11 --> Input Class Initialized
INFO - 2016-12-02 04:06:11 --> Language Class Initialized
INFO - 2016-12-02 04:06:11 --> Loader Class Initialized
INFO - 2016-12-02 04:06:11 --> Database Driver Class Initialized
INFO - 2016-12-02 04:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:06:11 --> Controller Class Initialized
INFO - 2016-12-02 04:06:11 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:06:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:06:11 --> Final output sent to browser
DEBUG - 2016-12-02 04:06:11 --> Total execution time: 0.0141
INFO - 2016-12-02 04:07:18 --> Config Class Initialized
INFO - 2016-12-02 04:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:07:18 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:07:18 --> Utf8 Class Initialized
INFO - 2016-12-02 04:07:18 --> URI Class Initialized
DEBUG - 2016-12-02 04:07:18 --> No URI present. Default controller set.
INFO - 2016-12-02 04:07:18 --> Router Class Initialized
INFO - 2016-12-02 04:07:18 --> Output Class Initialized
INFO - 2016-12-02 04:07:18 --> Security Class Initialized
DEBUG - 2016-12-02 04:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:07:18 --> Input Class Initialized
INFO - 2016-12-02 04:07:18 --> Language Class Initialized
INFO - 2016-12-02 04:07:18 --> Loader Class Initialized
INFO - 2016-12-02 04:07:18 --> Database Driver Class Initialized
INFO - 2016-12-02 04:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:07:18 --> Controller Class Initialized
INFO - 2016-12-02 04:07:18 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:07:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:07:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:07:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:07:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:07:18 --> Final output sent to browser
DEBUG - 2016-12-02 04:07:18 --> Total execution time: 0.0131
INFO - 2016-12-02 04:07:25 --> Config Class Initialized
INFO - 2016-12-02 04:07:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:07:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:07:25 --> Utf8 Class Initialized
INFO - 2016-12-02 04:07:25 --> URI Class Initialized
INFO - 2016-12-02 04:07:25 --> Router Class Initialized
INFO - 2016-12-02 04:07:25 --> Output Class Initialized
INFO - 2016-12-02 04:07:25 --> Security Class Initialized
DEBUG - 2016-12-02 04:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:07:25 --> Input Class Initialized
INFO - 2016-12-02 04:07:25 --> Language Class Initialized
ERROR - 2016-12-02 04:07:25 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:07:25 --> Config Class Initialized
INFO - 2016-12-02 04:07:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:07:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:07:25 --> Utf8 Class Initialized
INFO - 2016-12-02 04:07:25 --> URI Class Initialized
INFO - 2016-12-02 04:07:25 --> Router Class Initialized
INFO - 2016-12-02 04:07:25 --> Output Class Initialized
INFO - 2016-12-02 04:07:25 --> Security Class Initialized
DEBUG - 2016-12-02 04:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:07:25 --> Input Class Initialized
INFO - 2016-12-02 04:07:25 --> Language Class Initialized
ERROR - 2016-12-02 04:07:25 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:07:32 --> Config Class Initialized
INFO - 2016-12-02 04:07:32 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:07:32 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:07:32 --> Utf8 Class Initialized
INFO - 2016-12-02 04:07:32 --> URI Class Initialized
INFO - 2016-12-02 04:07:32 --> Router Class Initialized
INFO - 2016-12-02 04:07:32 --> Output Class Initialized
INFO - 2016-12-02 04:07:32 --> Security Class Initialized
DEBUG - 2016-12-02 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:07:32 --> Input Class Initialized
INFO - 2016-12-02 04:07:32 --> Language Class Initialized
INFO - 2016-12-02 04:07:32 --> Loader Class Initialized
INFO - 2016-12-02 04:07:32 --> Database Driver Class Initialized
INFO - 2016-12-02 04:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:07:32 --> Controller Class Initialized
INFO - 2016-12-02 04:07:32 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:07:32 --> Final output sent to browser
DEBUG - 2016-12-02 04:07:32 --> Total execution time: 0.0981
INFO - 2016-12-02 04:08:09 --> Config Class Initialized
INFO - 2016-12-02 04:08:09 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:08:09 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:08:09 --> Utf8 Class Initialized
INFO - 2016-12-02 04:08:09 --> URI Class Initialized
INFO - 2016-12-02 04:08:09 --> Router Class Initialized
INFO - 2016-12-02 04:08:09 --> Output Class Initialized
INFO - 2016-12-02 04:08:09 --> Security Class Initialized
DEBUG - 2016-12-02 04:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:08:09 --> Input Class Initialized
INFO - 2016-12-02 04:08:09 --> Language Class Initialized
INFO - 2016-12-02 04:08:09 --> Loader Class Initialized
INFO - 2016-12-02 04:08:09 --> Database Driver Class Initialized
INFO - 2016-12-02 04:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:08:09 --> Controller Class Initialized
INFO - 2016-12-02 04:08:09 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:08:09 --> Final output sent to browser
DEBUG - 2016-12-02 04:08:09 --> Total execution time: 0.0132
INFO - 2016-12-02 04:19:15 --> Config Class Initialized
INFO - 2016-12-02 04:19:15 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:19:15 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:19:15 --> Utf8 Class Initialized
INFO - 2016-12-02 04:19:15 --> URI Class Initialized
DEBUG - 2016-12-02 04:19:15 --> No URI present. Default controller set.
INFO - 2016-12-02 04:19:15 --> Router Class Initialized
INFO - 2016-12-02 04:19:15 --> Output Class Initialized
INFO - 2016-12-02 04:19:15 --> Security Class Initialized
DEBUG - 2016-12-02 04:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:19:15 --> Input Class Initialized
INFO - 2016-12-02 04:19:15 --> Language Class Initialized
INFO - 2016-12-02 04:19:15 --> Loader Class Initialized
INFO - 2016-12-02 04:19:15 --> Database Driver Class Initialized
INFO - 2016-12-02 04:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:19:15 --> Controller Class Initialized
INFO - 2016-12-02 04:19:15 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:19:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:19:15 --> Final output sent to browser
DEBUG - 2016-12-02 04:19:15 --> Total execution time: 0.0131
INFO - 2016-12-02 04:19:16 --> Config Class Initialized
INFO - 2016-12-02 04:19:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:19:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:19:16 --> Utf8 Class Initialized
INFO - 2016-12-02 04:19:16 --> URI Class Initialized
INFO - 2016-12-02 04:19:16 --> Router Class Initialized
INFO - 2016-12-02 04:19:16 --> Output Class Initialized
INFO - 2016-12-02 04:19:16 --> Security Class Initialized
DEBUG - 2016-12-02 04:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:19:16 --> Input Class Initialized
INFO - 2016-12-02 04:19:16 --> Language Class Initialized
ERROR - 2016-12-02 04:19:16 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:19:16 --> Config Class Initialized
INFO - 2016-12-02 04:19:16 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:19:16 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:19:16 --> Utf8 Class Initialized
INFO - 2016-12-02 04:19:16 --> URI Class Initialized
INFO - 2016-12-02 04:19:16 --> Router Class Initialized
INFO - 2016-12-02 04:19:16 --> Output Class Initialized
INFO - 2016-12-02 04:19:16 --> Security Class Initialized
DEBUG - 2016-12-02 04:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:19:16 --> Input Class Initialized
INFO - 2016-12-02 04:19:16 --> Language Class Initialized
ERROR - 2016-12-02 04:19:16 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:19:56 --> Config Class Initialized
INFO - 2016-12-02 04:19:56 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:19:56 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:19:56 --> Utf8 Class Initialized
INFO - 2016-12-02 04:19:56 --> URI Class Initialized
INFO - 2016-12-02 04:19:56 --> Router Class Initialized
INFO - 2016-12-02 04:19:56 --> Output Class Initialized
INFO - 2016-12-02 04:19:56 --> Security Class Initialized
DEBUG - 2016-12-02 04:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:19:56 --> Input Class Initialized
INFO - 2016-12-02 04:19:56 --> Language Class Initialized
INFO - 2016-12-02 04:19:56 --> Loader Class Initialized
INFO - 2016-12-02 04:19:56 --> Database Driver Class Initialized
INFO - 2016-12-02 04:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:19:56 --> Controller Class Initialized
INFO - 2016-12-02 04:19:56 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:19:56 --> Final output sent to browser
DEBUG - 2016-12-02 04:19:56 --> Total execution time: 0.0197
INFO - 2016-12-02 04:20:07 --> Config Class Initialized
INFO - 2016-12-02 04:20:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:20:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:20:07 --> Utf8 Class Initialized
INFO - 2016-12-02 04:20:07 --> URI Class Initialized
DEBUG - 2016-12-02 04:20:07 --> No URI present. Default controller set.
INFO - 2016-12-02 04:20:07 --> Router Class Initialized
INFO - 2016-12-02 04:20:07 --> Output Class Initialized
INFO - 2016-12-02 04:20:07 --> Security Class Initialized
DEBUG - 2016-12-02 04:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:20:07 --> Input Class Initialized
INFO - 2016-12-02 04:20:07 --> Language Class Initialized
INFO - 2016-12-02 04:20:07 --> Loader Class Initialized
INFO - 2016-12-02 04:20:07 --> Database Driver Class Initialized
INFO - 2016-12-02 04:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:20:07 --> Controller Class Initialized
INFO - 2016-12-02 04:20:07 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:20:07 --> Final output sent to browser
DEBUG - 2016-12-02 04:20:07 --> Total execution time: 0.0132
INFO - 2016-12-02 04:20:08 --> Config Class Initialized
INFO - 2016-12-02 04:20:08 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:20:08 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:20:08 --> Utf8 Class Initialized
INFO - 2016-12-02 04:20:08 --> URI Class Initialized
INFO - 2016-12-02 04:20:08 --> Router Class Initialized
INFO - 2016-12-02 04:20:08 --> Output Class Initialized
INFO - 2016-12-02 04:20:08 --> Security Class Initialized
DEBUG - 2016-12-02 04:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:20:08 --> Input Class Initialized
INFO - 2016-12-02 04:20:08 --> Language Class Initialized
ERROR - 2016-12-02 04:20:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:20:08 --> Config Class Initialized
INFO - 2016-12-02 04:20:08 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:20:08 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:20:08 --> Utf8 Class Initialized
INFO - 2016-12-02 04:20:08 --> URI Class Initialized
INFO - 2016-12-02 04:20:08 --> Router Class Initialized
INFO - 2016-12-02 04:20:08 --> Output Class Initialized
INFO - 2016-12-02 04:20:08 --> Security Class Initialized
DEBUG - 2016-12-02 04:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:20:08 --> Input Class Initialized
INFO - 2016-12-02 04:20:08 --> Language Class Initialized
ERROR - 2016-12-02 04:20:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 04:20:09 --> Config Class Initialized
INFO - 2016-12-02 04:20:09 --> Hooks Class Initialized
DEBUG - 2016-12-02 04:20:09 --> UTF-8 Support Enabled
INFO - 2016-12-02 04:20:09 --> Utf8 Class Initialized
INFO - 2016-12-02 04:20:09 --> URI Class Initialized
INFO - 2016-12-02 04:20:09 --> Router Class Initialized
INFO - 2016-12-02 04:20:09 --> Output Class Initialized
INFO - 2016-12-02 04:20:09 --> Security Class Initialized
DEBUG - 2016-12-02 04:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 04:20:09 --> Input Class Initialized
INFO - 2016-12-02 04:20:09 --> Language Class Initialized
INFO - 2016-12-02 04:20:09 --> Loader Class Initialized
INFO - 2016-12-02 04:20:09 --> Database Driver Class Initialized
INFO - 2016-12-02 04:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 04:20:09 --> Controller Class Initialized
INFO - 2016-12-02 04:20:09 --> Helper loaded: url_helper
DEBUG - 2016-12-02 04:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 04:20:09 --> Final output sent to browser
DEBUG - 2016-12-02 04:20:09 --> Total execution time: 0.0156
INFO - 2016-12-02 16:26:24 --> Config Class Initialized
INFO - 2016-12-02 16:26:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:24 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:24 --> URI Class Initialized
INFO - 2016-12-02 16:26:24 --> Router Class Initialized
INFO - 2016-12-02 16:26:24 --> Output Class Initialized
INFO - 2016-12-02 16:26:24 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:25 --> Input Class Initialized
INFO - 2016-12-02 16:26:25 --> Language Class Initialized
ERROR - 2016-12-02 16:26:25 --> 404 Page Not Found: Imagenes_portada/A76V4669.jpg
INFO - 2016-12-02 16:26:30 --> Config Class Initialized
INFO - 2016-12-02 16:26:30 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:30 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:30 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:30 --> URI Class Initialized
DEBUG - 2016-12-02 16:26:30 --> No URI present. Default controller set.
INFO - 2016-12-02 16:26:30 --> Router Class Initialized
INFO - 2016-12-02 16:26:30 --> Output Class Initialized
INFO - 2016-12-02 16:26:30 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:30 --> Input Class Initialized
INFO - 2016-12-02 16:26:30 --> Language Class Initialized
INFO - 2016-12-02 16:26:30 --> Loader Class Initialized
INFO - 2016-12-02 16:26:30 --> Database Driver Class Initialized
INFO - 2016-12-02 16:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:26:30 --> Controller Class Initialized
INFO - 2016-12-02 16:26:30 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:26:31 --> Final output sent to browser
DEBUG - 2016-12-02 16:26:31 --> Total execution time: 1.0219
INFO - 2016-12-02 16:26:31 --> Config Class Initialized
INFO - 2016-12-02 16:26:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:31 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:31 --> URI Class Initialized
INFO - 2016-12-02 16:26:31 --> Router Class Initialized
INFO - 2016-12-02 16:26:31 --> Output Class Initialized
INFO - 2016-12-02 16:26:31 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:31 --> Input Class Initialized
INFO - 2016-12-02 16:26:31 --> Language Class Initialized
ERROR - 2016-12-02 16:26:31 --> 404 Page Not Found: Imagenes_portada/A76V4669.jpg
INFO - 2016-12-02 16:26:31 --> Config Class Initialized
INFO - 2016-12-02 16:26:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:31 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:31 --> URI Class Initialized
INFO - 2016-12-02 16:26:31 --> Router Class Initialized
INFO - 2016-12-02 16:26:31 --> Output Class Initialized
INFO - 2016-12-02 16:26:31 --> Config Class Initialized
INFO - 2016-12-02 16:26:31 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:31 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:31 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:31 --> URI Class Initialized
INFO - 2016-12-02 16:26:31 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:31 --> Input Class Initialized
INFO - 2016-12-02 16:26:31 --> Language Class Initialized
ERROR - 2016-12-02 16:26:31 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:26:31 --> Router Class Initialized
INFO - 2016-12-02 16:26:31 --> Output Class Initialized
INFO - 2016-12-02 16:26:31 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:31 --> Input Class Initialized
INFO - 2016-12-02 16:26:31 --> Language Class Initialized
ERROR - 2016-12-02 16:26:31 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:26:32 --> Config Class Initialized
INFO - 2016-12-02 16:26:32 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:32 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:32 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:32 --> URI Class Initialized
INFO - 2016-12-02 16:26:32 --> Router Class Initialized
INFO - 2016-12-02 16:26:32 --> Output Class Initialized
INFO - 2016-12-02 16:26:32 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:32 --> Input Class Initialized
INFO - 2016-12-02 16:26:32 --> Language Class Initialized
INFO - 2016-12-02 16:26:32 --> Loader Class Initialized
INFO - 2016-12-02 16:26:32 --> Database Driver Class Initialized
INFO - 2016-12-02 16:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:26:32 --> Controller Class Initialized
INFO - 2016-12-02 16:26:32 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:26:32 --> Final output sent to browser
DEBUG - 2016-12-02 16:26:32 --> Total execution time: 0.0129
INFO - 2016-12-02 16:26:43 --> Config Class Initialized
INFO - 2016-12-02 16:26:43 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:43 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:43 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:43 --> URI Class Initialized
DEBUG - 2016-12-02 16:26:43 --> No URI present. Default controller set.
INFO - 2016-12-02 16:26:43 --> Router Class Initialized
INFO - 2016-12-02 16:26:43 --> Output Class Initialized
INFO - 2016-12-02 16:26:43 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:43 --> Input Class Initialized
INFO - 2016-12-02 16:26:43 --> Language Class Initialized
INFO - 2016-12-02 16:26:43 --> Loader Class Initialized
INFO - 2016-12-02 16:26:43 --> Database Driver Class Initialized
INFO - 2016-12-02 16:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:26:43 --> Controller Class Initialized
INFO - 2016-12-02 16:26:43 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:26:43 --> Final output sent to browser
DEBUG - 2016-12-02 16:26:43 --> Total execution time: 0.0170
INFO - 2016-12-02 16:26:44 --> Config Class Initialized
INFO - 2016-12-02 16:26:44 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:44 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:44 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:44 --> URI Class Initialized
INFO - 2016-12-02 16:26:44 --> Router Class Initialized
INFO - 2016-12-02 16:26:44 --> Output Class Initialized
INFO - 2016-12-02 16:26:44 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:44 --> Input Class Initialized
INFO - 2016-12-02 16:26:44 --> Language Class Initialized
ERROR - 2016-12-02 16:26:44 --> 404 Page Not Found: Imagenes_portada/A76V4669.jpg
INFO - 2016-12-02 16:26:44 --> Config Class Initialized
INFO - 2016-12-02 16:26:44 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:44 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:44 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:44 --> URI Class Initialized
INFO - 2016-12-02 16:26:44 --> Router Class Initialized
INFO - 2016-12-02 16:26:44 --> Output Class Initialized
INFO - 2016-12-02 16:26:44 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:44 --> Input Class Initialized
INFO - 2016-12-02 16:26:44 --> Language Class Initialized
ERROR - 2016-12-02 16:26:44 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:26:44 --> Config Class Initialized
INFO - 2016-12-02 16:26:44 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:44 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:44 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:44 --> URI Class Initialized
INFO - 2016-12-02 16:26:44 --> Router Class Initialized
INFO - 2016-12-02 16:26:44 --> Output Class Initialized
INFO - 2016-12-02 16:26:44 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:44 --> Input Class Initialized
INFO - 2016-12-02 16:26:44 --> Language Class Initialized
ERROR - 2016-12-02 16:26:44 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:26:45 --> Config Class Initialized
INFO - 2016-12-02 16:26:45 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:26:45 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:26:45 --> Utf8 Class Initialized
INFO - 2016-12-02 16:26:45 --> URI Class Initialized
INFO - 2016-12-02 16:26:45 --> Router Class Initialized
INFO - 2016-12-02 16:26:45 --> Output Class Initialized
INFO - 2016-12-02 16:26:45 --> Security Class Initialized
DEBUG - 2016-12-02 16:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:26:45 --> Input Class Initialized
INFO - 2016-12-02 16:26:45 --> Language Class Initialized
INFO - 2016-12-02 16:26:45 --> Loader Class Initialized
INFO - 2016-12-02 16:26:45 --> Database Driver Class Initialized
INFO - 2016-12-02 16:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:26:45 --> Controller Class Initialized
INFO - 2016-12-02 16:26:45 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:26:45 --> Final output sent to browser
DEBUG - 2016-12-02 16:26:45 --> Total execution time: 0.0137
INFO - 2016-12-02 16:27:24 --> Config Class Initialized
INFO - 2016-12-02 16:27:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:24 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:24 --> URI Class Initialized
DEBUG - 2016-12-02 16:27:24 --> No URI present. Default controller set.
INFO - 2016-12-02 16:27:24 --> Router Class Initialized
INFO - 2016-12-02 16:27:24 --> Output Class Initialized
INFO - 2016-12-02 16:27:24 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:24 --> Input Class Initialized
INFO - 2016-12-02 16:27:24 --> Language Class Initialized
INFO - 2016-12-02 16:27:24 --> Loader Class Initialized
INFO - 2016-12-02 16:27:24 --> Database Driver Class Initialized
INFO - 2016-12-02 16:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:27:24 --> Controller Class Initialized
INFO - 2016-12-02 16:27:24 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:27:24 --> Final output sent to browser
DEBUG - 2016-12-02 16:27:24 --> Total execution time: 0.0229
INFO - 2016-12-02 16:27:24 --> Config Class Initialized
INFO - 2016-12-02 16:27:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:24 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:24 --> URI Class Initialized
INFO - 2016-12-02 16:27:24 --> Router Class Initialized
INFO - 2016-12-02 16:27:24 --> Output Class Initialized
INFO - 2016-12-02 16:27:24 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:24 --> Input Class Initialized
INFO - 2016-12-02 16:27:24 --> Language Class Initialized
ERROR - 2016-12-02 16:27:24 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:27:24 --> Config Class Initialized
INFO - 2016-12-02 16:27:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:24 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:24 --> URI Class Initialized
INFO - 2016-12-02 16:27:24 --> Router Class Initialized
INFO - 2016-12-02 16:27:24 --> Output Class Initialized
INFO - 2016-12-02 16:27:24 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:24 --> Input Class Initialized
INFO - 2016-12-02 16:27:24 --> Language Class Initialized
ERROR - 2016-12-02 16:27:24 --> 404 Page Not Found: Imagenes_portada/A76V4669.jpg
INFO - 2016-12-02 16:27:24 --> Config Class Initialized
INFO - 2016-12-02 16:27:24 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:24 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:24 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:24 --> URI Class Initialized
INFO - 2016-12-02 16:27:24 --> Router Class Initialized
INFO - 2016-12-02 16:27:24 --> Output Class Initialized
INFO - 2016-12-02 16:27:24 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:24 --> Input Class Initialized
INFO - 2016-12-02 16:27:24 --> Language Class Initialized
ERROR - 2016-12-02 16:27:24 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:27:25 --> Config Class Initialized
INFO - 2016-12-02 16:27:25 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:25 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:25 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:25 --> URI Class Initialized
INFO - 2016-12-02 16:27:25 --> Router Class Initialized
INFO - 2016-12-02 16:27:25 --> Output Class Initialized
INFO - 2016-12-02 16:27:25 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:25 --> Input Class Initialized
INFO - 2016-12-02 16:27:25 --> Language Class Initialized
INFO - 2016-12-02 16:27:25 --> Loader Class Initialized
INFO - 2016-12-02 16:27:25 --> Database Driver Class Initialized
INFO - 2016-12-02 16:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:27:25 --> Controller Class Initialized
INFO - 2016-12-02 16:27:25 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:27:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:27:25 --> Final output sent to browser
DEBUG - 2016-12-02 16:27:25 --> Total execution time: 0.0144
INFO - 2016-12-02 16:27:34 --> Config Class Initialized
INFO - 2016-12-02 16:27:34 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:34 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:34 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:34 --> URI Class Initialized
DEBUG - 2016-12-02 16:27:34 --> No URI present. Default controller set.
INFO - 2016-12-02 16:27:34 --> Router Class Initialized
INFO - 2016-12-02 16:27:34 --> Output Class Initialized
INFO - 2016-12-02 16:27:34 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:34 --> Input Class Initialized
INFO - 2016-12-02 16:27:34 --> Language Class Initialized
INFO - 2016-12-02 16:27:34 --> Loader Class Initialized
INFO - 2016-12-02 16:27:34 --> Database Driver Class Initialized
INFO - 2016-12-02 16:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:27:34 --> Controller Class Initialized
INFO - 2016-12-02 16:27:34 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:27:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:27:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:27:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:27:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:27:34 --> Final output sent to browser
DEBUG - 2016-12-02 16:27:34 --> Total execution time: 0.0301
INFO - 2016-12-02 16:27:35 --> Config Class Initialized
INFO - 2016-12-02 16:27:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:35 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:35 --> URI Class Initialized
INFO - 2016-12-02 16:27:35 --> Router Class Initialized
INFO - 2016-12-02 16:27:35 --> Output Class Initialized
INFO - 2016-12-02 16:27:35 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:35 --> Input Class Initialized
INFO - 2016-12-02 16:27:35 --> Language Class Initialized
ERROR - 2016-12-02 16:27:35 --> 404 Page Not Found: Imagenes_portada/A76V4669.jpg
INFO - 2016-12-02 16:27:35 --> Config Class Initialized
INFO - 2016-12-02 16:27:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:35 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:35 --> URI Class Initialized
INFO - 2016-12-02 16:27:35 --> Router Class Initialized
INFO - 2016-12-02 16:27:35 --> Output Class Initialized
INFO - 2016-12-02 16:27:35 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:35 --> Input Class Initialized
INFO - 2016-12-02 16:27:35 --> Language Class Initialized
ERROR - 2016-12-02 16:27:35 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:27:35 --> Config Class Initialized
INFO - 2016-12-02 16:27:35 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:35 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:35 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:35 --> URI Class Initialized
INFO - 2016-12-02 16:27:35 --> Router Class Initialized
INFO - 2016-12-02 16:27:35 --> Output Class Initialized
INFO - 2016-12-02 16:27:35 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:35 --> Input Class Initialized
INFO - 2016-12-02 16:27:35 --> Language Class Initialized
ERROR - 2016-12-02 16:27:35 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:27:36 --> Config Class Initialized
INFO - 2016-12-02 16:27:36 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:36 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:36 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:36 --> URI Class Initialized
INFO - 2016-12-02 16:27:36 --> Router Class Initialized
INFO - 2016-12-02 16:27:36 --> Output Class Initialized
INFO - 2016-12-02 16:27:36 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:36 --> Input Class Initialized
INFO - 2016-12-02 16:27:36 --> Language Class Initialized
INFO - 2016-12-02 16:27:36 --> Loader Class Initialized
INFO - 2016-12-02 16:27:36 --> Database Driver Class Initialized
INFO - 2016-12-02 16:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:27:36 --> Controller Class Initialized
INFO - 2016-12-02 16:27:36 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:27:36 --> Final output sent to browser
DEBUG - 2016-12-02 16:27:36 --> Total execution time: 0.0143
INFO - 2016-12-02 16:27:41 --> Config Class Initialized
INFO - 2016-12-02 16:27:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:27:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:27:41 --> Utf8 Class Initialized
INFO - 2016-12-02 16:27:41 --> URI Class Initialized
INFO - 2016-12-02 16:27:41 --> Router Class Initialized
INFO - 2016-12-02 16:27:41 --> Output Class Initialized
INFO - 2016-12-02 16:27:41 --> Security Class Initialized
DEBUG - 2016-12-02 16:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:27:41 --> Input Class Initialized
INFO - 2016-12-02 16:27:41 --> Language Class Initialized
ERROR - 2016-12-02 16:27:41 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 16:28:17 --> Config Class Initialized
INFO - 2016-12-02 16:28:17 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:28:17 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:28:17 --> Utf8 Class Initialized
INFO - 2016-12-02 16:28:17 --> URI Class Initialized
INFO - 2016-12-02 16:28:17 --> Router Class Initialized
INFO - 2016-12-02 16:28:17 --> Output Class Initialized
INFO - 2016-12-02 16:28:17 --> Security Class Initialized
DEBUG - 2016-12-02 16:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:28:17 --> Input Class Initialized
INFO - 2016-12-02 16:28:17 --> Language Class Initialized
ERROR - 2016-12-02 16:28:17 --> 404 Page Not Found: Imagenes_portada/.jpg
INFO - 2016-12-02 16:28:22 --> Config Class Initialized
INFO - 2016-12-02 16:28:22 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:28:22 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:28:22 --> Utf8 Class Initialized
INFO - 2016-12-02 16:28:22 --> URI Class Initialized
DEBUG - 2016-12-02 16:28:22 --> No URI present. Default controller set.
INFO - 2016-12-02 16:28:22 --> Router Class Initialized
INFO - 2016-12-02 16:28:22 --> Output Class Initialized
INFO - 2016-12-02 16:28:22 --> Security Class Initialized
DEBUG - 2016-12-02 16:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:28:22 --> Input Class Initialized
INFO - 2016-12-02 16:28:22 --> Language Class Initialized
INFO - 2016-12-02 16:28:22 --> Loader Class Initialized
INFO - 2016-12-02 16:28:22 --> Database Driver Class Initialized
INFO - 2016-12-02 16:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:28:22 --> Controller Class Initialized
INFO - 2016-12-02 16:28:22 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:28:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:28:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:28:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:28:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:28:22 --> Final output sent to browser
DEBUG - 2016-12-02 16:28:22 --> Total execution time: 0.0486
INFO - 2016-12-02 16:28:22 --> Config Class Initialized
INFO - 2016-12-02 16:28:22 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:28:22 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:28:22 --> Utf8 Class Initialized
INFO - 2016-12-02 16:28:22 --> URI Class Initialized
INFO - 2016-12-02 16:28:22 --> Router Class Initialized
INFO - 2016-12-02 16:28:22 --> Output Class Initialized
INFO - 2016-12-02 16:28:22 --> Security Class Initialized
DEBUG - 2016-12-02 16:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:28:22 --> Input Class Initialized
INFO - 2016-12-02 16:28:22 --> Language Class Initialized
ERROR - 2016-12-02 16:28:22 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:28:23 --> Config Class Initialized
INFO - 2016-12-02 16:28:23 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:28:23 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:28:23 --> Utf8 Class Initialized
INFO - 2016-12-02 16:28:23 --> URI Class Initialized
INFO - 2016-12-02 16:28:23 --> Router Class Initialized
INFO - 2016-12-02 16:28:23 --> Output Class Initialized
INFO - 2016-12-02 16:28:23 --> Security Class Initialized
DEBUG - 2016-12-02 16:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:28:23 --> Input Class Initialized
INFO - 2016-12-02 16:28:23 --> Language Class Initialized
ERROR - 2016-12-02 16:28:23 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:28:23 --> Config Class Initialized
INFO - 2016-12-02 16:28:23 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:28:23 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:28:23 --> Utf8 Class Initialized
INFO - 2016-12-02 16:28:23 --> URI Class Initialized
INFO - 2016-12-02 16:28:23 --> Router Class Initialized
INFO - 2016-12-02 16:28:23 --> Output Class Initialized
INFO - 2016-12-02 16:28:23 --> Security Class Initialized
DEBUG - 2016-12-02 16:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:28:23 --> Input Class Initialized
INFO - 2016-12-02 16:28:23 --> Language Class Initialized
ERROR - 2016-12-02 16:28:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 16:28:23 --> Config Class Initialized
INFO - 2016-12-02 16:28:23 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:28:23 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:28:23 --> Utf8 Class Initialized
INFO - 2016-12-02 16:28:23 --> URI Class Initialized
INFO - 2016-12-02 16:28:23 --> Router Class Initialized
INFO - 2016-12-02 16:28:23 --> Output Class Initialized
INFO - 2016-12-02 16:28:23 --> Security Class Initialized
DEBUG - 2016-12-02 16:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:28:23 --> Input Class Initialized
INFO - 2016-12-02 16:28:23 --> Language Class Initialized
INFO - 2016-12-02 16:28:23 --> Loader Class Initialized
INFO - 2016-12-02 16:28:23 --> Database Driver Class Initialized
INFO - 2016-12-02 16:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:28:23 --> Controller Class Initialized
INFO - 2016-12-02 16:28:23 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:28:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:28:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:28:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:28:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:28:23 --> Final output sent to browser
DEBUG - 2016-12-02 16:28:23 --> Total execution time: 0.0125
INFO - 2016-12-02 16:29:55 --> Config Class Initialized
INFO - 2016-12-02 16:29:55 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:29:55 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:29:55 --> Utf8 Class Initialized
INFO - 2016-12-02 16:29:55 --> URI Class Initialized
INFO - 2016-12-02 16:29:55 --> Router Class Initialized
INFO - 2016-12-02 16:29:55 --> Output Class Initialized
INFO - 2016-12-02 16:29:55 --> Security Class Initialized
DEBUG - 2016-12-02 16:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:29:55 --> Input Class Initialized
INFO - 2016-12-02 16:29:55 --> Language Class Initialized
ERROR - 2016-12-02 16:29:55 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-02 16:30:32 --> Config Class Initialized
INFO - 2016-12-02 16:30:32 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:32 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:32 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:32 --> URI Class Initialized
INFO - 2016-12-02 16:30:32 --> Router Class Initialized
INFO - 2016-12-02 16:30:32 --> Output Class Initialized
INFO - 2016-12-02 16:30:32 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:32 --> Input Class Initialized
INFO - 2016-12-02 16:30:32 --> Language Class Initialized
INFO - 2016-12-02 16:30:32 --> Loader Class Initialized
INFO - 2016-12-02 16:30:32 --> Database Driver Class Initialized
INFO - 2016-12-02 16:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:30:32 --> Controller Class Initialized
INFO - 2016-12-02 16:30:32 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:30:32 --> Final output sent to browser
DEBUG - 2016-12-02 16:30:32 --> Total execution time: 0.0267
INFO - 2016-12-02 16:30:33 --> Config Class Initialized
INFO - 2016-12-02 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:33 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:33 --> URI Class Initialized
INFO - 2016-12-02 16:30:33 --> Router Class Initialized
INFO - 2016-12-02 16:30:33 --> Output Class Initialized
INFO - 2016-12-02 16:30:33 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:33 --> Input Class Initialized
INFO - 2016-12-02 16:30:33 --> Language Class Initialized
ERROR - 2016-12-02 16:30:33 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-02 16:30:33 --> Config Class Initialized
INFO - 2016-12-02 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:33 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:33 --> URI Class Initialized
INFO - 2016-12-02 16:30:33 --> Router Class Initialized
INFO - 2016-12-02 16:30:33 --> Output Class Initialized
INFO - 2016-12-02 16:30:33 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:33 --> Input Class Initialized
INFO - 2016-12-02 16:30:33 --> Language Class Initialized
ERROR - 2016-12-02 16:30:33 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-02 16:30:33 --> Config Class Initialized
INFO - 2016-12-02 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:33 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:33 --> URI Class Initialized
INFO - 2016-12-02 16:30:33 --> Router Class Initialized
INFO - 2016-12-02 16:30:33 --> Output Class Initialized
INFO - 2016-12-02 16:30:33 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:33 --> Input Class Initialized
INFO - 2016-12-02 16:30:33 --> Language Class Initialized
ERROR - 2016-12-02 16:30:33 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-02 16:30:33 --> Config Class Initialized
INFO - 2016-12-02 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:33 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:33 --> Config Class Initialized
INFO - 2016-12-02 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:33 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:33 --> URI Class Initialized
INFO - 2016-12-02 16:30:33 --> Router Class Initialized
INFO - 2016-12-02 16:30:33 --> URI Class Initialized
INFO - 2016-12-02 16:30:33 --> Router Class Initialized
INFO - 2016-12-02 16:30:33 --> Output Class Initialized
INFO - 2016-12-02 16:30:33 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:33 --> Input Class Initialized
INFO - 2016-12-02 16:30:33 --> Language Class Initialized
ERROR - 2016-12-02 16:30:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:30:33 --> Config Class Initialized
INFO - 2016-12-02 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:33 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:33 --> Output Class Initialized
INFO - 2016-12-02 16:30:33 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:33 --> Input Class Initialized
INFO - 2016-12-02 16:30:33 --> Language Class Initialized
ERROR - 2016-12-02 16:30:33 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-02 16:30:33 --> URI Class Initialized
INFO - 2016-12-02 16:30:33 --> Router Class Initialized
INFO - 2016-12-02 16:30:33 --> Output Class Initialized
INFO - 2016-12-02 16:30:33 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:33 --> Input Class Initialized
INFO - 2016-12-02 16:30:33 --> Language Class Initialized
ERROR - 2016-12-02 16:30:33 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2016-12-02 16:30:33 --> Config Class Initialized
INFO - 2016-12-02 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:33 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:33 --> URI Class Initialized
INFO - 2016-12-02 16:30:33 --> Router Class Initialized
INFO - 2016-12-02 16:30:33 --> Output Class Initialized
INFO - 2016-12-02 16:30:33 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:33 --> Input Class Initialized
INFO - 2016-12-02 16:30:33 --> Language Class Initialized
ERROR - 2016-12-02 16:30:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-02 16:30:34 --> Config Class Initialized
INFO - 2016-12-02 16:30:34 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:30:34 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:30:34 --> Utf8 Class Initialized
INFO - 2016-12-02 16:30:34 --> URI Class Initialized
INFO - 2016-12-02 16:30:34 --> Router Class Initialized
INFO - 2016-12-02 16:30:34 --> Output Class Initialized
INFO - 2016-12-02 16:30:34 --> Security Class Initialized
DEBUG - 2016-12-02 16:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:30:34 --> Input Class Initialized
INFO - 2016-12-02 16:30:34 --> Language Class Initialized
INFO - 2016-12-02 16:30:34 --> Loader Class Initialized
INFO - 2016-12-02 16:30:34 --> Database Driver Class Initialized
INFO - 2016-12-02 16:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:30:34 --> Controller Class Initialized
INFO - 2016-12-02 16:30:34 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:30:34 --> Final output sent to browser
DEBUG - 2016-12-02 16:30:34 --> Total execution time: 0.0636
INFO - 2016-12-02 16:46:57 --> Config Class Initialized
INFO - 2016-12-02 16:46:57 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:46:57 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:46:57 --> Utf8 Class Initialized
INFO - 2016-12-02 16:46:57 --> URI Class Initialized
INFO - 2016-12-02 16:46:57 --> Router Class Initialized
INFO - 2016-12-02 16:46:57 --> Output Class Initialized
INFO - 2016-12-02 16:46:57 --> Security Class Initialized
DEBUG - 2016-12-02 16:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:46:57 --> Input Class Initialized
INFO - 2016-12-02 16:46:57 --> Language Class Initialized
ERROR - 2016-12-02 16:46:57 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-02 16:52:58 --> Config Class Initialized
INFO - 2016-12-02 16:52:58 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:52:58 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:52:58 --> Utf8 Class Initialized
INFO - 2016-12-02 16:52:58 --> URI Class Initialized
DEBUG - 2016-12-02 16:52:58 --> No URI present. Default controller set.
INFO - 2016-12-02 16:52:58 --> Router Class Initialized
INFO - 2016-12-02 16:52:58 --> Output Class Initialized
INFO - 2016-12-02 16:52:58 --> Security Class Initialized
DEBUG - 2016-12-02 16:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:52:58 --> Input Class Initialized
INFO - 2016-12-02 16:52:58 --> Language Class Initialized
INFO - 2016-12-02 16:52:58 --> Loader Class Initialized
INFO - 2016-12-02 16:52:58 --> Database Driver Class Initialized
INFO - 2016-12-02 16:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:52:58 --> Controller Class Initialized
INFO - 2016-12-02 16:52:58 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:52:58 --> Final output sent to browser
DEBUG - 2016-12-02 16:52:58 --> Total execution time: 0.0142
INFO - 2016-12-02 16:52:59 --> Config Class Initialized
INFO - 2016-12-02 16:52:59 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:52:59 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:52:59 --> Utf8 Class Initialized
INFO - 2016-12-02 16:52:59 --> URI Class Initialized
INFO - 2016-12-02 16:52:59 --> Router Class Initialized
INFO - 2016-12-02 16:52:59 --> Output Class Initialized
INFO - 2016-12-02 16:52:59 --> Security Class Initialized
DEBUG - 2016-12-02 16:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:52:59 --> Input Class Initialized
INFO - 2016-12-02 16:52:59 --> Language Class Initialized
INFO - 2016-12-02 16:52:59 --> Loader Class Initialized
INFO - 2016-12-02 16:52:59 --> Database Driver Class Initialized
INFO - 2016-12-02 16:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:52:59 --> Controller Class Initialized
INFO - 2016-12-02 16:52:59 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:52:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:52:59 --> Final output sent to browser
DEBUG - 2016-12-02 16:52:59 --> Total execution time: 0.0143
INFO - 2016-12-02 16:53:26 --> Config Class Initialized
INFO - 2016-12-02 16:53:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:53:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:53:26 --> Utf8 Class Initialized
INFO - 2016-12-02 16:53:26 --> URI Class Initialized
DEBUG - 2016-12-02 16:53:26 --> No URI present. Default controller set.
INFO - 2016-12-02 16:53:26 --> Router Class Initialized
INFO - 2016-12-02 16:53:26 --> Output Class Initialized
INFO - 2016-12-02 16:53:26 --> Security Class Initialized
DEBUG - 2016-12-02 16:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:53:26 --> Input Class Initialized
INFO - 2016-12-02 16:53:26 --> Language Class Initialized
INFO - 2016-12-02 16:53:26 --> Loader Class Initialized
INFO - 2016-12-02 16:53:26 --> Database Driver Class Initialized
INFO - 2016-12-02 16:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:53:26 --> Controller Class Initialized
INFO - 2016-12-02 16:53:26 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:53:26 --> Final output sent to browser
DEBUG - 2016-12-02 16:53:26 --> Total execution time: 0.0134
INFO - 2016-12-02 16:53:26 --> Config Class Initialized
INFO - 2016-12-02 16:53:26 --> Hooks Class Initialized
DEBUG - 2016-12-02 16:53:26 --> UTF-8 Support Enabled
INFO - 2016-12-02 16:53:26 --> Utf8 Class Initialized
INFO - 2016-12-02 16:53:26 --> URI Class Initialized
INFO - 2016-12-02 16:53:26 --> Router Class Initialized
INFO - 2016-12-02 16:53:26 --> Output Class Initialized
INFO - 2016-12-02 16:53:26 --> Security Class Initialized
DEBUG - 2016-12-02 16:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 16:53:26 --> Input Class Initialized
INFO - 2016-12-02 16:53:26 --> Language Class Initialized
INFO - 2016-12-02 16:53:26 --> Loader Class Initialized
INFO - 2016-12-02 16:53:26 --> Database Driver Class Initialized
INFO - 2016-12-02 16:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 16:53:26 --> Controller Class Initialized
INFO - 2016-12-02 16:53:26 --> Helper loaded: url_helper
DEBUG - 2016-12-02 16:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 16:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 16:53:26 --> Final output sent to browser
DEBUG - 2016-12-02 16:53:26 --> Total execution time: 0.0137
INFO - 2016-12-02 17:30:21 --> Config Class Initialized
INFO - 2016-12-02 17:30:21 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:30:21 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:30:21 --> Utf8 Class Initialized
INFO - 2016-12-02 17:30:21 --> URI Class Initialized
DEBUG - 2016-12-02 17:30:21 --> No URI present. Default controller set.
INFO - 2016-12-02 17:30:21 --> Router Class Initialized
INFO - 2016-12-02 17:30:21 --> Output Class Initialized
INFO - 2016-12-02 17:30:21 --> Security Class Initialized
DEBUG - 2016-12-02 17:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:30:21 --> Input Class Initialized
INFO - 2016-12-02 17:30:21 --> Language Class Initialized
INFO - 2016-12-02 17:30:21 --> Loader Class Initialized
INFO - 2016-12-02 17:30:21 --> Database Driver Class Initialized
INFO - 2016-12-02 17:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:30:21 --> Controller Class Initialized
INFO - 2016-12-02 17:30:21 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 17:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 17:30:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 17:30:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 17:30:22 --> Final output sent to browser
DEBUG - 2016-12-02 17:30:22 --> Total execution time: 1.2515
INFO - 2016-12-02 17:30:27 --> Config Class Initialized
INFO - 2016-12-02 17:30:27 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:30:27 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:30:27 --> Utf8 Class Initialized
INFO - 2016-12-02 17:30:27 --> URI Class Initialized
INFO - 2016-12-02 17:30:27 --> Router Class Initialized
INFO - 2016-12-02 17:30:27 --> Output Class Initialized
INFO - 2016-12-02 17:30:27 --> Security Class Initialized
DEBUG - 2016-12-02 17:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:30:27 --> Input Class Initialized
INFO - 2016-12-02 17:30:27 --> Language Class Initialized
INFO - 2016-12-02 17:30:27 --> Loader Class Initialized
INFO - 2016-12-02 17:30:27 --> Database Driver Class Initialized
INFO - 2016-12-02 17:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:30:27 --> Controller Class Initialized
INFO - 2016-12-02 17:30:27 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 17:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 17:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 17:30:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 17:30:27 --> Final output sent to browser
DEBUG - 2016-12-02 17:30:27 --> Total execution time: 0.0204
INFO - 2016-12-02 17:31:06 --> Config Class Initialized
INFO - 2016-12-02 17:31:06 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:31:06 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:31:06 --> Utf8 Class Initialized
INFO - 2016-12-02 17:31:06 --> URI Class Initialized
DEBUG - 2016-12-02 17:31:06 --> No URI present. Default controller set.
INFO - 2016-12-02 17:31:06 --> Router Class Initialized
INFO - 2016-12-02 17:31:06 --> Output Class Initialized
INFO - 2016-12-02 17:31:06 --> Security Class Initialized
DEBUG - 2016-12-02 17:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:31:06 --> Input Class Initialized
INFO - 2016-12-02 17:31:06 --> Language Class Initialized
INFO - 2016-12-02 17:31:06 --> Loader Class Initialized
INFO - 2016-12-02 17:31:06 --> Database Driver Class Initialized
INFO - 2016-12-02 17:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:31:06 --> Controller Class Initialized
INFO - 2016-12-02 17:31:06 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 17:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 17:31:06 --> Final output sent to browser
DEBUG - 2016-12-02 17:31:06 --> Total execution time: 0.0214
INFO - 2016-12-02 17:31:07 --> Config Class Initialized
INFO - 2016-12-02 17:31:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:31:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:31:07 --> Utf8 Class Initialized
INFO - 2016-12-02 17:31:07 --> URI Class Initialized
INFO - 2016-12-02 17:31:07 --> Router Class Initialized
INFO - 2016-12-02 17:31:07 --> Output Class Initialized
INFO - 2016-12-02 17:31:07 --> Security Class Initialized
DEBUG - 2016-12-02 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:31:07 --> Input Class Initialized
INFO - 2016-12-02 17:31:07 --> Language Class Initialized
ERROR - 2016-12-02 17:31:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 17:31:07 --> Config Class Initialized
INFO - 2016-12-02 17:31:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:31:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:31:07 --> Utf8 Class Initialized
INFO - 2016-12-02 17:31:07 --> URI Class Initialized
INFO - 2016-12-02 17:31:07 --> Router Class Initialized
INFO - 2016-12-02 17:31:07 --> Output Class Initialized
INFO - 2016-12-02 17:31:07 --> Security Class Initialized
DEBUG - 2016-12-02 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:31:07 --> Input Class Initialized
INFO - 2016-12-02 17:31:07 --> Language Class Initialized
ERROR - 2016-12-02 17:31:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-02 17:31:07 --> Config Class Initialized
INFO - 2016-12-02 17:31:07 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:31:07 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:31:07 --> Utf8 Class Initialized
INFO - 2016-12-02 17:31:07 --> URI Class Initialized
INFO - 2016-12-02 17:31:07 --> Router Class Initialized
INFO - 2016-12-02 17:31:07 --> Output Class Initialized
INFO - 2016-12-02 17:31:07 --> Security Class Initialized
DEBUG - 2016-12-02 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:31:07 --> Input Class Initialized
INFO - 2016-12-02 17:31:07 --> Language Class Initialized
INFO - 2016-12-02 17:31:07 --> Loader Class Initialized
INFO - 2016-12-02 17:31:07 --> Database Driver Class Initialized
INFO - 2016-12-02 17:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:31:07 --> Controller Class Initialized
INFO - 2016-12-02 17:31:07 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:31:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 17:31:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 17:31:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 17:31:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 17:31:07 --> Final output sent to browser
DEBUG - 2016-12-02 17:31:07 --> Total execution time: 0.0187
INFO - 2016-12-02 17:32:09 --> Config Class Initialized
INFO - 2016-12-02 17:32:09 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:09 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:09 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:09 --> URI Class Initialized
INFO - 2016-12-02 17:32:09 --> Router Class Initialized
INFO - 2016-12-02 17:32:09 --> Output Class Initialized
INFO - 2016-12-02 17:32:09 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:09 --> Input Class Initialized
INFO - 2016-12-02 17:32:09 --> Language Class Initialized
INFO - 2016-12-02 17:32:09 --> Loader Class Initialized
INFO - 2016-12-02 17:32:09 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:09 --> Controller Class Initialized
INFO - 2016-12-02 17:32:09 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:09 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:09 --> Total execution time: 0.0447
INFO - 2016-12-02 17:32:09 --> Config Class Initialized
INFO - 2016-12-02 17:32:09 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:09 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:09 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:09 --> URI Class Initialized
INFO - 2016-12-02 17:32:09 --> Router Class Initialized
INFO - 2016-12-02 17:32:09 --> Output Class Initialized
INFO - 2016-12-02 17:32:09 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:09 --> Input Class Initialized
INFO - 2016-12-02 17:32:09 --> Language Class Initialized
INFO - 2016-12-02 17:32:09 --> Loader Class Initialized
INFO - 2016-12-02 17:32:09 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:09 --> Controller Class Initialized
INFO - 2016-12-02 17:32:09 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 17:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 17:32:09 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:09 --> Total execution time: 0.0154
INFO - 2016-12-02 17:32:13 --> Config Class Initialized
INFO - 2016-12-02 17:32:13 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:13 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:13 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:13 --> URI Class Initialized
DEBUG - 2016-12-02 17:32:13 --> No URI present. Default controller set.
INFO - 2016-12-02 17:32:13 --> Router Class Initialized
INFO - 2016-12-02 17:32:13 --> Output Class Initialized
INFO - 2016-12-02 17:32:13 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:13 --> Input Class Initialized
INFO - 2016-12-02 17:32:13 --> Language Class Initialized
INFO - 2016-12-02 17:32:13 --> Loader Class Initialized
INFO - 2016-12-02 17:32:13 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:13 --> Controller Class Initialized
INFO - 2016-12-02 17:32:13 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 17:32:13 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:13 --> Total execution time: 0.0138
INFO - 2016-12-02 17:32:13 --> Config Class Initialized
INFO - 2016-12-02 17:32:13 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:13 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:13 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:13 --> URI Class Initialized
INFO - 2016-12-02 17:32:13 --> Router Class Initialized
INFO - 2016-12-02 17:32:13 --> Output Class Initialized
INFO - 2016-12-02 17:32:13 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:13 --> Input Class Initialized
INFO - 2016-12-02 17:32:13 --> Language Class Initialized
INFO - 2016-12-02 17:32:13 --> Loader Class Initialized
INFO - 2016-12-02 17:32:13 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:13 --> Controller Class Initialized
INFO - 2016-12-02 17:32:13 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 17:32:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 17:32:13 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:13 --> Total execution time: 0.0129
INFO - 2016-12-02 17:32:39 --> Config Class Initialized
INFO - 2016-12-02 17:32:39 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:39 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:39 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:39 --> URI Class Initialized
INFO - 2016-12-02 17:32:39 --> Router Class Initialized
INFO - 2016-12-02 17:32:39 --> Output Class Initialized
INFO - 2016-12-02 17:32:39 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:39 --> Input Class Initialized
INFO - 2016-12-02 17:32:39 --> Language Class Initialized
INFO - 2016-12-02 17:32:39 --> Loader Class Initialized
INFO - 2016-12-02 17:32:39 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:39 --> Controller Class Initialized
INFO - 2016-12-02 17:32:39 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:40 --> Config Class Initialized
INFO - 2016-12-02 17:32:40 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:40 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:40 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:40 --> URI Class Initialized
INFO - 2016-12-02 17:32:40 --> Router Class Initialized
INFO - 2016-12-02 17:32:40 --> Output Class Initialized
INFO - 2016-12-02 17:32:40 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:40 --> Input Class Initialized
INFO - 2016-12-02 17:32:40 --> Language Class Initialized
INFO - 2016-12-02 17:32:40 --> Loader Class Initialized
INFO - 2016-12-02 17:32:40 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:40 --> Controller Class Initialized
INFO - 2016-12-02 17:32:40 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:41 --> Config Class Initialized
INFO - 2016-12-02 17:32:41 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:41 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:41 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:41 --> URI Class Initialized
INFO - 2016-12-02 17:32:41 --> Router Class Initialized
INFO - 2016-12-02 17:32:41 --> Output Class Initialized
INFO - 2016-12-02 17:32:41 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:41 --> Input Class Initialized
INFO - 2016-12-02 17:32:41 --> Language Class Initialized
INFO - 2016-12-02 17:32:41 --> Loader Class Initialized
INFO - 2016-12-02 17:32:41 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:41 --> Controller Class Initialized
INFO - 2016-12-02 17:32:41 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:42 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:42 --> Total execution time: 3.0607
INFO - 2016-12-02 17:32:42 --> Config Class Initialized
INFO - 2016-12-02 17:32:42 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:42 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:42 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:42 --> URI Class Initialized
INFO - 2016-12-02 17:32:42 --> Router Class Initialized
INFO - 2016-12-02 17:32:42 --> Output Class Initialized
INFO - 2016-12-02 17:32:42 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:42 --> Input Class Initialized
INFO - 2016-12-02 17:32:42 --> Language Class Initialized
INFO - 2016-12-02 17:32:42 --> Loader Class Initialized
INFO - 2016-12-02 17:32:42 --> Config Class Initialized
INFO - 2016-12-02 17:32:42 --> Hooks Class Initialized
DEBUG - 2016-12-02 17:32:42 --> UTF-8 Support Enabled
INFO - 2016-12-02 17:32:42 --> Utf8 Class Initialized
INFO - 2016-12-02 17:32:42 --> URI Class Initialized
INFO - 2016-12-02 17:32:42 --> Router Class Initialized
INFO - 2016-12-02 17:32:42 --> Output Class Initialized
INFO - 2016-12-02 17:32:42 --> Security Class Initialized
DEBUG - 2016-12-02 17:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 17:32:42 --> Input Class Initialized
INFO - 2016-12-02 17:32:42 --> Language Class Initialized
INFO - 2016-12-02 17:32:42 --> Loader Class Initialized
INFO - 2016-12-02 17:32:42 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:42 --> Database Driver Class Initialized
INFO - 2016-12-02 17:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:42 --> Controller Class Initialized
INFO - 2016-12-02 17:32:42 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 17:32:42 --> Controller Class Initialized
INFO - 2016-12-02 17:32:42 --> Helper loaded: url_helper
DEBUG - 2016-12-02 17:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 17:32:45 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:45 --> Total execution time: 5.0105
INFO - 2016-12-02 17:32:50 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:50 --> Total execution time: 7.7174
INFO - 2016-12-02 17:32:50 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:50 --> Total execution time: 7.6603
INFO - 2016-12-02 17:32:50 --> Final output sent to browser
DEBUG - 2016-12-02 17:32:50 --> Total execution time: 9.0466
INFO - 2016-12-02 20:03:18 --> Config Class Initialized
INFO - 2016-12-02 20:03:18 --> Hooks Class Initialized
DEBUG - 2016-12-02 20:03:18 --> UTF-8 Support Enabled
INFO - 2016-12-02 20:03:18 --> Utf8 Class Initialized
INFO - 2016-12-02 20:03:18 --> URI Class Initialized
DEBUG - 2016-12-02 20:03:19 --> No URI present. Default controller set.
INFO - 2016-12-02 20:03:19 --> Router Class Initialized
INFO - 2016-12-02 20:03:19 --> Output Class Initialized
INFO - 2016-12-02 20:03:19 --> Security Class Initialized
DEBUG - 2016-12-02 20:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-02 20:03:19 --> Input Class Initialized
INFO - 2016-12-02 20:03:19 --> Language Class Initialized
INFO - 2016-12-02 20:03:19 --> Loader Class Initialized
INFO - 2016-12-02 20:03:19 --> Database Driver Class Initialized
INFO - 2016-12-02 20:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-02 20:03:19 --> Controller Class Initialized
INFO - 2016-12-02 20:03:19 --> Helper loaded: url_helper
DEBUG - 2016-12-02 20:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-02 20:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-02 20:03:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-02 20:03:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-02 20:03:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-02 20:03:20 --> Final output sent to browser
DEBUG - 2016-12-02 20:03:20 --> Total execution time: 1.2174
